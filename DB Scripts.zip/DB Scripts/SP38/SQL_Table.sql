USE Globalfs
GO

IF not exists (select * from information_schema.tables where table_name='ad_gb_default_corres_bks_crncy' )
BEGIN

CREATE TABLE [dbo].ad_gb_default_corres_bks_crncy(
	[local_crn_id] [smallint]  NOT NULL,
	[bank_id] [int] NOT NULL,
	[Tran_id] [int] NULL)
	
End
GO
------------------------------------------------------------------------------------------------------------------------------------
--**Devolper	:	Shaimaa AbdElnasser
--**Date		:	[14/07/2020]		
--**For	        :   GFSY00802 - AJF - Employer List Classification

------------------------------------------------------------
--//Add new column to table ICSR_ENL_EMPLOYER_NAMES_LIST//--
------------------------------------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'ICSR_ENL_EMPLOYER_NAMES_LIST' AND Column_Name = 'Certification')
BEGIN
    ALTER TABLE ICSR_ENL_EMPLOYER_NAMES_LIST
    ADD Certification nvarchar(50) NULL
END
GO

IF NOT EXISTS (SELECT column_name FROM INFORMATION_SCHEMA.columns WHERE table_name = 'OverrideRequests'  and column_name = 'OverrideRepairFields')
BEGIN
	ALTER TABLE OverrideRequests
	ADD OverrideRepairFields xml null
END
GO
USE [Globalfs]
GO
/****** Object:  UserDefinedTableType [dbo].[T_MsgRefNo]    Script Date: 06/21/2020 15:43:11 ******/
IF NOT EXISTS (SELECT * FROM sys.all_objects WHERE name like '%T_MsgRefNo%' AND type in (N'TT'))
BEGIN

CREATE TYPE [dbo].[T_MsgRefNo] AS TABLE(
	[MsgRefNo] [varchar](50) NULL
)
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LockRolls]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LockRolls](
	[LockRoll] [nvarchar](200) NOT NULL,
	[ToStatus] [nvarchar](200)  NULL ,
	[Creator] [dbo].[OperatorID] DEFAULT (suser_sname()) NOT NULL,
	[Updator] [dbo].[OperatorID] NOT NULL  DEFAULT (suser_sname()),
	[Created] [datetime] NOT NULL DEFAULT (getdate()),
	[LastChanged] [datetime] NOT NULL  DEFAULT (getdate()),
	CONSTRAINT uq_LockRolls UNIQUE  ([LockRoll],[ToStatus])
) 
END
GO
--************************************************************************************************************************
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LockAccountStatus]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[LockAccountStatus](
	[RimNumber] [nvarchar](50) NOT NULL,
	[AccountNumber] [nvarchar](50) NOT NULL,
	[UserID] [nvarchar](50) NOT NULL,
	[LockRoll] [nvarchar](200) NOT NULL,
	[ToStatus] [nvarchar](200) NOT NULL ,
	[Creator] [dbo].[OperatorID] DEFAULT (suser_sname()) NOT NULL,
	[Updator] [dbo].[OperatorID] NOT NULL  DEFAULT (suser_sname()),
	[Created] [datetime] NOT NULL DEFAULT (getdate()),
	[LastChanged] [datetime] NOT NULL  DEFAULT (getdate())
) 
END
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00813 Table Script'
GO

---------------------------------
-- Alter Table RulesTranConfig --
---------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'RulesTranConfig' AND COLUMN_NAME = 'PostTranAsSupervisor')
	BEGIN
		ALTER TABLE RulesTranConfig
		ADD PostTranAsSupervisor bit DEFAULT 0 WITH VALUES
	END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'RulesTranConfig' AND COLUMN_NAME = 'CancelTranAsSupervisor')
	BEGIN
		ALTER TABLE RulesTranConfig
		ADD CancelTranAsSupervisor bit DEFAULT 0 WITH VALUES
	END
GO

PRINT 'End... Script for CR# GFSY00813 Table Script'
GO
--==================================================================================================================================================================
-- =============================================
-- Author:		Aya Tarek
-- Create date: 26/7/2020
-- Description:	Setup Table  For PurposeCode
-- =============================================
USE Globalfs
GO

IF not exists (select * from information_schema.tables where table_name='PurposeCodeMapping')
BEGIN

CREATE TABLE [dbo].PurposeCodeMapping(
	[PurposeCode] varchar(30) NOT NULL Primary Key,
	[PurposeDescription] nvarchar(max) NOT NULL,
	[CashCredit] BIT  Not Null DEFAULT(0),
	[CashDebit] BIT Not Null DEFAULT(0),
	[CashTransfer] BIT Not Null DEFAULT(0),
	[Currency]  char(1) Not NULL)
	
End
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00804 Table Script'
GO
 
---------------------------------------
-- Create Table ResendControlsEvents --
---------------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'ResendControlsEvents')
	BEGIN
		CREATE TABLE dbo.ResendControlsEvents
			(
			    TransactionName	TransactionName	NOT NULL,
			    ControlName		nvarchar(max)	NOT NULL,
			    EventName		nvarchar(max)	NOT NULL,
				EventType		nvarchar(max)	NOT NULL,
				ControlValue	nvarchar(max)	NULL,
			)
	END
GO

-------------------------------
-- Alter Table TellerConfig --
-------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'TellerConfig' AND COLUMN_NAME = 'DisplaySupervisorGrid')
	BEGIN
		ALTER TABLE TellerConfig
		ADD DisplaySupervisorGrid bit DEFAULT 0 WITH VALUES
	END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'TellerConfig' AND COLUMN_NAME = 'DisplayTellerGrid')
	BEGIN
		ALTER TABLE TellerConfig
		ADD DisplayTellerGrid bit DEFAULT 0 WITH VALUES
	END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'TellerConfig' AND COLUMN_NAME = 'IntervalTimeToRefreshGrid')
	BEGIN
		ALTER TABLE TellerConfig
		ADD IntervalTimeToRefreshGrid int DEFAULT 0 WITH VALUES
	END
GO

-------------------------------
-- Alter Table TellerConfig --
-------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'RulesTranConfig' AND COLUMN_NAME = 'PostTranAsSupervisor')
	BEGIN
		ALTER TABLE RulesTranConfig
		ADD PostTranAsSupervisor bit DEFAULT 0 WITH VALUES
	END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'RulesTranConfig' AND COLUMN_NAME = 'CancelTranAsSupervisor')
	BEGIN
		ALTER TABLE RulesTranConfig
		ADD CancelTranAsSupervisor bit DEFAULT 0 WITH VALUES
	END
GO

PRINT 'End... Script for CR# GFSY00804 Table Script'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Mostafa Helmy
--Date		:	[11/08/2020]		
--Reason	:	Enh GFSY00806 BARWA_ACM18595_Inward Transfers_Part1
--=====================================================================

PRINT 'Start. Script for CR# GFSY00806 Table Script'
GO


---------------------------------------------
-- Alter Table Local_Inward_Messages_Detail--
---------------------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'Local_Inward_Messages_Detail' AND Column_Name = 'ReferenceNumber')
BEGIN
	ALTER TABLE Local_Inward_Messages_Detail
	ADD ReferenceNumber nvarchar(50) NULL
	
END
GO

PRINT 'End... Script for CR# GFSY00806 Table Script'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/08/2020]		
--Reason	:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
--===============================================================

PRINT 'Start. Script for CR# GFSY00807 Table Script'
GO

-----------------------------------------
-- Create Table IR_QueueOptionsMapping --
-----------------------------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'IR_QueueOptionsMapping')
	BEGIN
		CREATE TABLE dbo.IR_QueueOptionsMapping
			(
			    QueueType	NVARCHAR(MAX)	NOT NULL,
			    IRStatusID	INT				NOT NULL
			)
	END
GO

------------------------------------------
-- Create Table IR_CurrencyRimException --
------------------------------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'IR_DynamicException')
	BEGIN
		CREATE TABLE dbo.IR_DynamicException
			(
			    ID						INT NOT NULL IDENTITY(1, 1),
			    ExceptionDescription	NVARCHAR(MAX) NOT NULL,
				IsHoldValidation		BIT NOT NULL,
				IsSpecificExceptions 	BIT NOT NULL,
			)
	END
GO

---------------------------------------------------
-- Create Table IR_CurrencyRimExceptionCondition --
---------------------------------------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'IR_DynamicExceptionCondition')
	BEGIN
		CREATE TABLE dbo.IR_DynamicExceptionCondition
			(
			    ExceptionID			INT NOT NULL,
			    Seq					INT NOT NULL,
			    IRColumnName		NVARCHAR(MAX) NOT NULL,
				Value				NVARCHAR(MAX) NOT NULL,
				LogicalOperator		NVARCHAR(MAX) NOT NULL,
			)
	END
GO

----------------------------
-- Create TYPE IRMessages --
----------------------------
IF NOT EXISTS(SELECT * FROM sys.types WHERE name = 'IRMessages')
BEGIN 
 CREATE TYPE IRMessages AS TABLE 
	(
		[DrAccountNo]				[varchar](60) NULL,
		[DrAccountNo_AcctType]		[varchar](5) NULL,
		[DrAccountNo_ApplType]		[varchar](5) NULL,
		[DrAccountName]				[nvarchar](max) NULL,
		[Ordering_IBAN]				[nvarchar](max) NULL,
		[DrAccountNo_DepLoan]		[varchar](5) NULL,
		[DrCurrency]				[varchar](5) NULL,
		[DrAmount]					[decimal](21, 6) NULL,
		[DrCommission]				[decimal](21, 6) NULL,
		[DrExchangeRate]			[decimal](21, 6) NULL,
		[DrSellExchangeRate]		[decimal](21, 6) NULL,
		[DrValueDate]				[smalldatetime] NULL,
		[DrNarrative]				[nvarchar](max) NULL,
		[GTDTicket]					[nvarchar](max) NULL,
		[CrAccountNo]				[varchar](60) NULL,
		[CrAccountNo_AcctType]		[varchar](5) NULL,
		[CrAccountNo_ApplType]		[varchar](5) NULL,
		[CrAccountName]				[nvarchar](max) NULL,
		[IBAN]						[nvarchar](max) NULL,
		[CrRimNo]					[nvarchar](50) NULL,
		[CrAccountNo_DepLoan]		[varchar](5) NULL,
		[CrCurrency]				[varchar](5) NULL,
		[CrAmount]					[decimal](21, 6) NULL,
		[CrCommission]				[decimal](21, 6) NULL,
		[CrBuyExchangeRate]			[decimal](21, 6) NULL,
		[CrExchangeRate]			[decimal](21, 6) NULL,
		[CrValueDate]				[smalldatetime] NULL,
		[CrNarrative]				[nvarchar](max) NULL,
		[BeneficiaryGTDTicket]		[nvarchar](max) NULL,
		[OldDrAccountNo]			[nvarchar](max) NULL,
		[OldDrAccountNo_AcctType]	[nvarchar](max) NULL,
		[OldDrAccountNo_ApplType]	[nvarchar](max) NULL,
		[OldDrAccountName]			[nvarchar](max) NULL,
		[OldDrAccountNo_DepLoan]	[nvarchar](max) NULL,
		[OldDrCurrency]				[nvarchar](max) NULL,
		[OldDrAmount]				[decimal](21, 6) NULL,
		[OldDrCommission]			[decimal](21, 6) NULL,
		[OldDrExchangeRate]			[decimal](21, 6) NULL,
		[OldDrValueDate]			[nvarchar](max) NULL,
		[OldDrNarrative]			[nvarchar](max) NULL,
		[OldCrAccountNo]			[nvarchar](max) NULL,
		[OldCrAccountNo_AcctType]	[nvarchar](max) NULL,
		[OldCrAccountNo_ApplType]	[nvarchar](max) NULL,
		[OldCrAccountName]			[nvarchar](max) NULL,
		[OldCrAccountNo_DepLoan]	[nvarchar](max) NULL,
		[OldCrCurrency]				[nvarchar](max) NULL,
		[OldCrAmount]				[decimal](21, 6) NULL,
		[OldCrCommission]			[decimal](21, 6) NULL,
		[OldCrExchangeRate]			[decimal](21, 6) NULL,
		[OldCrValueDate]			[nvarchar](max) NULL,
		[OldCrNarrative]			[nvarchar](max) NULL,
		[OldStatusID]				[int] NULL,
		[ActionID]					[int] NULL,
		[StatusID]					[int] NULL,
		[PaymentMethodID]			[int] NULL,
		[ExceptionList]				[nvarchar](max) NULL,
		[Updator]					[varchar](1000) NULL,
		[ReverseReason]				[nvarchar](max) NULL,
		[OtherReason]				[nvarchar](max) NULL,
		[HostRefNo]					[nvarchar](max) NULL,
		[MsgRefNo]					[char](13) NULL
	)
END
GO

---------------------
-- Create TRIGGERS --
---------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE [name] = N'Delete_IR_DynamicException_ID' AND [type] = 'TR')
BEGIN
EXEC dbo.sp_executesql @statement = N'
	CREATE TRIGGER Delete_IR_DynamicException_ID ON IR_DynamicException
	FOR DELETE
	AS
		DELETE FROM IR_DynamicExceptionCondition WHERE IR_DynamicExceptionCondition.ExceptionID IN(SELECT DELETED.id FROM DELETED )
'
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE [name] = N'Insert_IR_DynamicExceptionCondition_ExceptionID' AND [type] = 'TR')
BEGIN
EXEC dbo.sp_executesql @statement = N'
	CREATE TRIGGER Insert_IR_DynamicExceptionCondition_ExceptionID ON IR_DynamicExceptionCondition
	AFTER INSERT
	AS
		IF NOT EXISTS(SELECT * FROM IR_DynamicException INNER JOIN INSERTED ON ID = INSERTED.ExceptionID)
		BEGIN
			raiserror(''ExceptionID column value must be already exists before in table IR_DynamicException in column ID'',16,1) with log
		    ROLLBACK transaction
		END 
'
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE [name] = N'Update_IR_DynamicExceptionCondition_ExceptionID' AND [type] = 'TR')
BEGIN
EXEC dbo.sp_executesql @statement = N'
	CREATE TRIGGER Update_IR_DynamicExceptionCondition_ExceptionID ON IR_DynamicExceptionCondition
	AFTER UPDATE
	AS
		IF NOT EXISTS(SELECT * FROM IR_DynamicException INNER JOIN INSERTED ON ID = INSERTED.ExceptionID)
		BEGIN
			raiserror(''ExceptionID column value must be already exists before in table IR_DynamicException in column ID'',16,1) with log
		    ROLLBACK transaction
		END 
'
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE [name] = N'Insert_IR_DynamicExceptionCondition_IRColumnName' AND [type] = 'TR')
BEGIN
EXEC dbo.sp_executesql @statement = N'
	CREATE TRIGGER Insert_IR_DynamicExceptionCondition_IRColumnName ON IR_DynamicExceptionCondition
	AFTER INSERT
	AS
		IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns INNER JOIN INSERTED ON Column_Name = INSERTED.IRColumnName WHERE Table_Name = ''IR'')
		BEGIN
			raiserror(''IRColumnName value must be a column in IR table'',16,1) with log
		    ROLLBACK transaction
		END 
'
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE [name] = N'Update_IR_DynamicExceptionCondition_IRColumnName' AND [type] = 'TR')
BEGIN
EXEC dbo.sp_executesql @statement = N'
	CREATE TRIGGER Update_IR_DynamicExceptionCondition_IRColumnName ON IR_DynamicExceptionCondition
	AFTER UPDATE
	AS
		IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns INNER JOIN INSERTED ON Column_Name = INSERTED.IRColumnName WHERE Table_Name = ''IR'')
		BEGIN
			raiserror(''IRColumnName value must be a column in IR table'',16,1) with log
		    ROLLBACK transaction
		END 
'
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE [name] = N'Insert_IR_DynamicExceptionCondition_LogicalOperator' AND [type] = 'TR')
BEGIN
EXEC dbo.sp_executesql @statement = N'
	CREATE TRIGGER Insert_IR_DynamicExceptionCondition_LogicalOperator ON IR_DynamicExceptionCondition
	AFTER INSERT
	AS
		IF EXISTS(SELECT * FROM INSERTED WHERE INSERTED.LogicalOperator NOT IN (''AND'' , ''OR'' , ''''))
		BEGIN
			raiserror(''LogicalOperator coulmn value must be [AND] or [OR]'',16,1) with log
		    ROLLBACK transaction
		END 
'
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE [name] = N'Update_IR_DynamicExceptionCondition_LogicalOperator' AND [type] = 'TR')
BEGIN
EXEC dbo.sp_executesql @statement = N'
	CREATE TRIGGER Update_IR_DynamicExceptionCondition_LogicalOperator ON IR_DynamicExceptionCondition
	AFTER UPDATE
	AS
		IF EXISTS(SELECT * FROM INSERTED WHERE INSERTED.LogicalOperator NOT IN (''AND'' , ''OR'' , ''''))
		BEGIN
			raiserror(''LogicalOperator coulmn value must be [AND] or [OR]'',16,1) with log
		    ROLLBACK transaction
		END 
'
END
GO

--------------------
-- Alter Table IR --
--------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'ReverseReaason')
BEGIN
    ALTER TABLE IR
    ADD ReverseReaason nvarchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'OtherReason')
BEGIN
    ALTER TABLE IR
    ADD OtherReason nvarchar(max) NULL
END
GO

PRINT 'End... Script for CR# GFSY00807 Table Script'
GO
--==================================================================================================================================================================
