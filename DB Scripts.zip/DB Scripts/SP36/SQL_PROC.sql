drop_old_function 'GetLocalDescForHajjTransferType'
GO

CREATE function GetLocalDescForHajjTransferType (@decr varchar(50), @LCID int)
returns nvarchar(50)
as
 /*              
  CreationDate: 29-Oct-2019  
  OriginalName: dbo.GetLocalDescForHajjTransferType              
  Programmer: Mostafa Helmy
  Description: Select local description of the (HAJJ_TRANSFER_TYPE) picklist entries descriptors
*/
begin
declare
@Local nvarchar(50)

SELECT @Local=  isnull( LocalDescription,@decr)
from PickList_Entries,RulesDescriptor,RulesDescriptorLocal
where Name=DescriptorName
AND RulesDescriptor.DescriptorID=RulesDescriptorLocal.DescriptorID
and PickListID=378 
AND lower(Descriptor)=lower(@decr)
AND LCID=@LCID

return @Local

end

GO
drop_old_proc 'HCS_UPDATECHEQUES'
go
Create procedure dbo.HCS_UPDATECHEQUES 
 @Updator DeveloperID
as   
/*Version : 2.00.46.1811, Modification Date : 23-11-2016 */  
/*   
	Rokaia Kadry CR#GFSY00614   23-11-2016 
	/*   
 CreationDate:  23-11-2016       
 Programmer: Rokaia Kadry    
 Description:  CR#GFSY00614 ADIB_CRQ7501_xp Cmdshell Alternative-  Core System Intregration -   
 Scripts were included in SSIS Packages by "Osama Nabil"  Run the Globalfs_DownloadAddress Scripts on Globalfs                           
 
 Modification Date: 15-10-2019
 Programmer: Mostafa Helmy
 Description: #GFSX13824 - send the @Updator as a parameter to update the Updator Column
*/  
*/            
	UPDATE CertifiedCheques
	SET ChequeStatus = 2 , Updator=@Updator
	from AutoDebit INNER JOIN [~autodebit]
		ON AutoDebit.UserId			= [~autodebit].USERID
		AND AutoDebit.Branch		= [~autodebit].Branch
		AND AutoDebit.Created		= [~autodebit].Created
		AND AutoDebit.LoadFileName	= [~autodebit].LoadFileName
		AND AutoDebit.RecordType	= [~autodebit].RecordType
		AND AutoDebit.DrAccountNo	= [~autodebit].DrAccountNo
		AND AutoDebit.ChequeNo		= [~autodebit].ChequeNo
	WHERE [~autodebit].STATUS = 1 AND [~autodebit].RecordType = 90
		AND CertifiedCheques.DraweeAcctNo	= [~autodebit].DrAccountNo
		AND CertifiedCheques.ChequeNo		= [~autodebit].ChequeNo
		AND CertifiedCheques.ChequeStatus 		= 1

	UPDATE CashierOrderCheques
	SET ChequeStatusID = 2, /*Paid*/
		ChequeStatus = 'Paid'
	from AutoDebit INNER JOIN [~autodebit]
		ON AutoDebit.UserId			= [~autodebit].USERID
		AND AutoDebit.Branch		= [~autodebit].Branch
		AND AutoDebit.Created		= [~autodebit].Created
		AND AutoDebit.LoadFileName	= [~autodebit].LoadFileName
		AND AutoDebit.RecordType	= [~autodebit].RecordType
		AND AutoDebit.DrAccountNo	= [~autodebit].DrAccountNo
		AND AutoDebit.ChequeNo		= [~autodebit].ChequeNo
	WHERE [~autodebit].STATUS = 1 AND [~autodebit].RecordType = 70 /*CasherOrderChqs*/
		AND CashierOrderCheques.COChequeNumber		= [~autodebit].ChequeNo
		AND CashierOrderCheques.ChequeStatusID = 1

GO
--exec Select_HajjCheques_To_Stop
drop_old_proc 'Select_HajjCheques_To_Stop'
Go

CREATE procedure [dbo].[Select_HajjCheques_To_Stop] --Select_HajjCheques_To_Stop '8'
	@ChequeNumber char (15) = null,
	@ChequeType int  = null,
	@TransferType nvarchar(50) = null,
	@CorrepondentBank nvarchar(40) = null,
	@ChequeCCY varchar(4) = null,
	@ChequeAmount decimal(21, 6) = 0,
	@BeneficiaryName nvarchar(120) = null,
	@IDNumber char(25) = null,
	@PassportNumber char(25) = null,
	@HomeTelNumber varchar(25) = null,
	@MobileNumber varchar(25) = null,
	@DebitAccount varchar(60) = null,
	@PurchaserName nvarchar(120) = null,
	@PurchaserIDType int = null,
	@PurchaserIDNo char(25)= null,
	@PurchaserAddress nvarchar(50) = null,
    @ChequeStatusID int = null,
    @LCID int =1033
    

/*
Modifier: Amr Salah El-din
Date: 18-5-2014
Reason: add the ability to search using part of the text 

Modifier: Nada Elshafie
Date: 25-11-2014
Reason: GFSX07954- Search using part of the text for only beneficiary Name ,search by the whole text for the rest to enhance performance 

Modifier: Mostafa Helmy
Date: 29-10-2019
Reason: GFSX13845 - allow user to add new Hajj Cheque tranfer types with local description
*/
As
--select Hajj.ChequeNumber as [ChequeNumber],RD.Descriptor as [ChequeType],Hajj.TransferType as [TransferType],Correspondant.name as [CorrespondantBank],Correspondant.bank_id as BankID,Hajj.ChequeCCY as [CCY],Hajj.ChequeAmount as [Amount],Hajj.BeneficiaryName as [BeneficiaryName],Hajj.IDNumber as [IDNumber]
--,Hajj.PassportNumber as [PassportNumber],Hajj.HomeTelNumber as [HomeNumber],Hajj.MobileNumber as [MobileNumber],Hajj.DebitAccount as [DebitAccount],Hajj.PurchaserName as [PurchaserName],Hajj.PurchaserIDType,Hajj.PurchaserIDNo,
--Hajj.PurchaserAddress,Hajj.ChequeStatusID,Hajj.Narrative as [Narrative],
--Hajj.ReasonCode as [ReasonCode],Hajj.OtherReason as [OtherReason]
--from BankChequeDetails As Hajj
--inner join ad_gb_corres_bks as Correspondant
--on Hajj.CorrepondentBank = Correspondant.bank_id
--inner join InventoryType as InvenType
--on Hajj.ChequeType = InvenType.id
--INNER  JOIN RulesDescriptor as RD      
-- ON RD.DescriptorID = InvenType.DescriptorID 
--where 
--(@ChequeNumber is NULL or @ChequeNumber = '' or Hajj.ChequeNumber like '%' + ltrim(rtrim(@ChequeNumber)) + '%')
--and (@ChequeType is NULL or ChequeType = Hajj.ChequeType)
--and (@TransferType is NULL or @TransferType = '' or @TransferType = Hajj.TransferType)
--and (@CorrepondentBank  is NULL or @CorrepondentBank = '' or @CorrepondentBank  = Correspondant.name)
--and (@ChequeCCY is NULL or @ChequeCCY = '' or @ChequeCCY = Hajj.ChequeCCY)
--and (@ChequeAmount is NULL or @ChequeAmount = 0 or @ChequeAmount = Hajj.ChequeAmount)
--and (@BeneficiaryName is NULL or @BeneficiaryName = '' or Hajj.BeneficiaryName like '%' + ltrim(rtrim(@BeneficiaryName)) + '%')
--and (@IDNumber is NULL or @IDNumber = '' or Hajj.IDNumber like '%' + ltrim(rtrim(@IDNumber)) + '%')
--and (@PassportNumber  is NULL or @PassportNumber = '' or Hajj.PassportNumber like '%' + ltrim(rtrim(@PassportNumber)) + '%' )
--and (@HomeTelNumber is NULL or @HomeTelNumber = '' or Hajj.HomeTelNumber like '%' + ltrim(rtrim(@HomeTelNumber)) + '%' )
--and (@MobileNumber is NULL or @MobileNumber = ''  or Hajj.MobileNumber like '%' + ltrim(rtrim(@MobileNumber)) + '%' )
--and (@DebitAccount is NULL or @DebitAccount = ''   or @DebitAccount = Hajj.DebitAccount)
--and (@PurchaserName is NULL or @PurchaserName = ''  or @PurchaserName = Hajj.PurchaserName)
--and (@PurchaserIDType is NULL or @PurchaserIDType = 0 or @PurchaserIDType = Hajj.PurchaserIDType)
--and (@PurchaserIDNo is NULL or @PurchaserIDNo = '' or @PurchaserIDNo = Hajj.PurchaserIDNo)
--and (@PurchaserAddress is NULL or @PurchaserAddress = '' or @PurchaserAddress = Hajj.PurchaserAddress)
--and (@ChequeStatusID is NULL  or @ChequeStatusID = Hajj.ChequeStatusID)
declare @sql nvarchar(4000)  

set @sql=N'  

select    
Hajj.ChequeNumber  as [ChequeNumber],  
RD.Descriptor   as [ChequeType],  
CASE '+CONVERT(varchar(10),@LCID)+' 
WHEN 1033 THEN Hajj.TransferType 
ELSE  dbo.GetLocalDescForHajjTransferType(Hajj.TransferType,'+CONVERT(varchar(10),@LCID)+')
 END  as [TransferType] , 
Correspondant.name  as [CorrespondantBank],  
Correspondant.bank_id as BankID,  
Hajj.ChequeCCY   as [CCY],  
Hajj.ChequeAmount  as [Amount],  
Hajj.BeneficiaryName as [BeneficiaryName],  
Hajj.IDNumber   as [IDNumber],  
Hajj.PassportNumber  as [PassportNumber],  
Hajj.HomeTelNumber  as [HomeNumber],  
Hajj.MobileNumber  as [MobileNumber],  
Hajj.DebitAccount  as [DebitAccount],  
Hajj.PurchaserName  as [PurchaserName],  
Hajj.PurchaserIDType,  
Hajj.PurchaserIDNo,    
Hajj.PurchaserAddress,  
Hajj.ChequeStatusID,  
Hajj.Narrative   as [Narrative],    
Hajj.ReasonCode   as [ReasonCode],  
Hajj.OtherReason  as [OtherReason]    
from BankChequeDetails As Hajj   
inner join ad_gb_corres_bks as Correspondant    
on Hajj.CorrepondentBank =  Correspondant.bank_id    
inner join InventoryType as InvenType    
on Hajj.ChequeType   =  InvenType.id    
INNER  JOIN RulesDescriptor as RD          
ON RD.DescriptorID   =  InvenType.DescriptorID   
where  1=1'  
  
if(@ChequeNumber is not NULL and @ChequeNumber <> '')  
Begin  
 select @sql=@sql+'and( Hajj.ChequeNumber =ltrim(rtrim('+@ChequeNumber+')) )  '  
End  
  
if(@ChequeType is not NULL )  
Begin  
 select @sql = @sql + ' and (''' + cast(@ChequeType as nvarchar(32)) + ''' = cast(Hajj.ChequeType as nvarchar(32)))'  
End  
  
if(@TransferType is not NULL and @TransferType <> '' )  
Begin  
 select @sql = @sql + ' and (''' + @TransferType + ''' = Hajj.TransferType)'  
End  
  
if(@CorrepondentBank is not NULL and @CorrepondentBank <> '' )  
Begin  
 select @sql = @sql + ' and (''' + @CorrepondentBank + ''' = Correspondant.name)'  
End  
  
if(@ChequeCCY is not NULL and @ChequeCCY <> '' )  
Begin  
 select @sql = @sql + ' and (''' + @ChequeCCY + ''' = Hajj.ChequeCCY)'  
End  
  
if(@ChequeAmount is not NULL  and @ChequeAmount <>0)  
Begin  
 select @sql = @sql + ' and (''' +cast(@ChequeAmount as nvarchar(32)) + ''' = cast(Hajj.ChequeAmount as nvarchar(32)))'  
End  
  
if(@BeneficiaryName is not NULL and @BeneficiaryName <> '' )  
Begin  
 set @BeneficiaryName =  LTRIM(rtrim(@BeneficiaryName))
 select @sql = @sql + ' and (Hajj.BeneficiaryName like ''%'' + N'''+ @BeneficiaryName+''' + ''%'')'  
End  
  
if(@IDNumber is not NULL and @IDNumber <> '' )  
Begin  
 select @sql = @sql + ' and (Hajj.IDNumber = ltrim(rtrim('+@IDNumber+')) )'  
End  
  
if(@PassportNumber is not NULL and @PassportNumber <> '' )  
Begin  
 select @sql = @sql + ' and (Hajj.PassportNumber = ltrim(rtrim('+@PassportNumber+')) )'  
End  
  
if(@HomeTelNumber is not NULL and @HomeTelNumber <> '' )  
Begin  
 select @sql = @sql + ' and (Hajj.HomeTelNumber = ltrim(rtrim('+@HomeTelNumber+')) )'  
End  
  
if(@MobileNumber is not NULL and @MobileNumber <> '' )  
Begin  
 select @sql = @sql + ' and (Hajj.MobileNumber =  ltrim(rtrim('+@MobileNumber+')) )'  
End  

 
if(@DebitAccount is not NULL and @DebitAccount <> '' )  
Begin  
 select @sql = @sql + ' and (''' + @DebitAccount + ''' = Hajj.DebitAccount)'  
End  

  
if(@PurchaserName is not NULL and @PurchaserName <> '' )  
Begin  
 select @sql = @sql + ' and (''' + @PurchaserName + ''' = Hajj.PurchaserName)'  
End  
  
if(@PurchaserIDType is not NULL and @PurchaserIDType<>0)  
Begin  
 select @sql = @sql + ' and (''' + cast(@PurchaserIDType as nvarchar(32))+ ''' = cast(Hajj.PurchaserIDType as nvarchar(32)))'  
End  
  

if(@PurchaserIDNo is not NULL and @PurchaserIDNo <> '' )  
Begin  
 select @sql = @sql + ' and (''' + @PurchaserIDNo + ''' = Hajj.PurchaserIDNo)'  
End  
 

if(@PurchaserAddress is not NULL and @PurchaserAddress <> '' )  
Begin
 select @sql = @sql + ' and (''' + @PurchaserAddress + ''' = Hajj.PurchaserAddress)'  
End  
 

if(@ChequeStatusID is not NULL)  
Begin  
 select @sql = @sql + ' and (''' + cast(@ChequeStatusID as nvarchar(32)) + ''' =  cast(Hajj.ChequeStatusID as nvarchar(32)))'  
End  

  
exec sp_executesql @sql  

--exec(@sql)  

--print(@sql)  


GO
DROP_OLD_PROC 'dbo.Select_RulesTranAcctStatusType'
go
/****** Object:  Stored Procedure dbo.Select_RulesTranAcctStatusType    Script Date: 08/03/2019 4:36:59 PM ******/    
CREATE PROC dbo.Select_RulesTranAcctStatusType       
 @TranName TransactionName,      
 @FieldName varchar(100),      
 @Status  varchar(50),  
 @Type nvarchar (10)= 'Acct' ,
 @AccountType char(3)=Null,
 @ApplicationType varchar (50)= NULL
AS      
      
/*      
CreationDate: 2019-08-03      
OriginalName: dbo.Select_RulesTranAcctStatusType      
Programmer: Sara Badwy     
Description: get the Type "Rim" to a transaction according to the Rim status      
Output:        
Assumption:       
        
*/      
      
SET NOCOUNT ON      
      
IF EXISTS      
(      
 SELECT *      
 FROM    dbo.RulesTranAcctStatus       
 INNER  JOIN      
                dbo.RulesTranName       
 ON  RulesTranAcctStatus.TranID  = RulesTranName.TranID      
 WHERE   (RulesTranName.TransactionName = @TranName)       
 AND  (FieldName    = @FieldName)      
)      
 BEGIN    
   
  
   IF 
   EXISTS(SELECT *   FROM    dbo.RulesTranAcctStatus       
   INNER  JOIN  dbo.RulesTranName    
  ON  RulesTranAcctStatus.TranID  = RulesTranName.TranID      
   WHERE   (RulesTranName.TransactionName = @TranName)      
    AND  (FieldName    = @FieldName)  
    and ([type]=@Type)  
    and ((AccountType is not null and (AccountType = @AccountType and @AccountType is not null)) OR (AccountType is  null OR AccountType ='' ))  --Setup for account type found and matched  OR no account type setup(Available for any type)
    and (ApplicationType is null or (ApplicationType = @ApplicationType))) 
    Begin
          IF Exists (SELECT *      
  
   FROM    dbo.RulesTranAcctStatus       
  
    INNER  JOIN      
  
     dbo.RulesTranName    
  
   ON  RulesTranAcctStatus.TranID  = RulesTranName.TranID      
  
   WHERE   (RulesTranName.TransactionName = @TranName)      
    AND  (FieldName    = @FieldName)  
    and ([type]=@Type)  
    and ((AccountType is not null and (AccountType = @AccountType and @AccountType is not null)) OR (AccountType is  null OR AccountType =''  )) 
    and (ApplicationType is null or (ApplicationType = @ApplicationType))
    and  Status =@Status)              -- Record found status for setup is matched
          return 1
   Else  IF Exists (SELECT *      
  
   FROM    dbo.RulesTranAcctStatus       
  
    INNER  JOIN      
  
     dbo.RulesTranName    
  
   ON  RulesTranAcctStatus.TranID  = RulesTranName.TranID      
  
   WHERE   (RulesTranName.TransactionName = @TranName)      
    AND  (FieldName    = @FieldName)  
    and ([type]=@Type)  
     and ((AccountType is not null and (AccountType = @AccountType and @AccountType is not null)) OR (AccountType is  null OR AccountType ='' ))
    and (ApplicationType is null or (ApplicationType = @ApplicationType))
    and  Status <>@Status)              --  status for setup is not matched
          return -1
    End
    else if
      EXISTS(SELECT *      
  
   FROM    dbo.RulesTranAcctStatus       
  
    INNER  JOIN      
  
     dbo.RulesTranName    
  
   ON  RulesTranAcctStatus.TranID  = RulesTranName.TranID      
  
   WHERE   (RulesTranName.TransactionName = @TranName)      
  
   AND  (FieldName    = @FieldName)   
    and ([type]=@Type)    
    and (AccountType is not null and  @AccountType is not null and AccountType<>@AccountType )   --Setup for account type found but not matched 
    and (ApplicationType is null or (ApplicationType = @ApplicationType)))    
    RETURN 0 
    else    
    IF 
  not EXISTS(SELECT *   FROM    dbo.RulesTranAcctStatus       
   INNER  JOIN  dbo.RulesTranName    
  ON  RulesTranAcctStatus.TranID  = RulesTranName.TranID      
   WHERE   (RulesTranName.TransactionName = @TranName)      
    AND  (FieldName    = @FieldName)  
    and ([type]=@Type)  and (ApplicationType is null or (ApplicationType = @ApplicationType)))   
    RETURN 2                                        --No Rim Setup At all 
    Else 
    Return -2    --Otherwise     
 END   
 Else
 Return 3 -- setup for transaction and FieldName not found
          
 go
drop_old_proc 'dbo.Get_Processed_ClearDetails'
GO
CREATE PROCEDURE dbo.Get_Processed_ClearDetails
(
	 @ClearBankBranchID varchar(20),                
	 @BankName varchar(50),                
	 @BranchName  varchar(35),                
	 @DateFrom smalldatetime,                 
	 @DateTo smalldatetime ,                 
	 @DepositBranchID nvarchar(20)  = '',            
	 @DepositDateFrom nvarchar(100) = '',            
	 @DepositDateTo nvarchar(100)   = '',            
	 @ChequeNumber nvarchar(20)     = '',   
	 @IDs nvarchar(max)  
)
AS
	/*
	Developer	: Mostafa Sayed
	Date		: [7/10/2019]
	Reason		: CR#GFSY00769 - BLOM_ACM18385_Out Clearing Settlement Bulk .....
    */
    
	DECLARE @x XML   
	SELECT @x = CAST('<A>'+ REPLACE(@IDs,',','</A><A>')+ '</A>' AS XML)       
   
	DECLARE @NoOfRows int    
	SELECT @NoOfRows = 1000     
	SELECT @NoOfRows = convert( nvarchar(10),Value)         
	FROM RulesTranFldParam with(nolock)        
	WHERE  TranName = 'OutwardClChequeSettlement' And Param = 'NoOfRows' And Param = 'NoOfRows' And IsNumeric(Value) = 1       
   
	IF(@ChequeNumber='')  
		SET @ChequeNumber = -1  
          
	if (@ClearBankBranchID <>'')                
	Begin      
		SELECT Top(@NoOfRows) 
			ChequeNumber as 'ChequeNumber',
			ChequeAmount as 'ChequeAmount', 
			Status.ShortDescription as 'Status', 
			ClearBankName as 'ClearBankName', 
			RIM_No as 'RIM_No'
		FROM   ClearDetail inner JOIN Status
		ON ClearDetail.Status = Status.id
		WHERE ClearBankBranchID=@ClearBankBranchID                
		AND ValueDate BETWEEN cast(@DateFrom as date) AND CAST( @DateTo  as DATE)                
		AND (@DepositBranchID ='' OR Branch = @DepositBranchID)          
		AND (@DepositDateFrom ='' OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))               
		AND (@ChequeNumber = convert (varchar, -1) OR ChequeNumber = @ChequeNumber)            
		AND ClearDetail.ID in ( SELECT t.value('.', 'int') AS inVal  FROM @x.nodes('/A') AS x(T))
		AND Status.StatusTypeID=1
	End                
	Else                
	Begin           
		SELECT Top(@NoOfRows) 
			ChequeNumber as 'ChequeNumber',
			ChequeAmount as 'ChequeAmount', 
			Status.ShortDescription as 'Status', 
			ClearBankName as 'ClearBankName', 
			RIM_No as 'RIM_No'
		FROM ClearDetail inner JOIN Status
		ON ClearDetail.Status = Status.id
		WHERE ValueDate BETWEEN cast(@DateFrom as date) AND CAST( @DateTo  as DATE) 
		AND (@DepositBranchID ='' OR Branch = @DepositBranchID)        
		AND (@DepositDateFrom ='' OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))      
		AND (@ChequeNumber = convert (varchar,-1) OR ChequeNumber = @ChequeNumber)    
		AND ClearDetail.ID in ( SELECT t.value('.', 'int') AS inVal  FROM @x.nodes('/A') AS x(T))
		AND Status.StatusTypeID=1
	END
GO
Drop_Old_Proc 'Insert_ClearDetail'
GO
Create PROCEDURE dbo.Insert_ClearDetail                  
 @Grid    as varchar(8000),                                
 @AccountNumber  as AccountNumber,                                
 @Branch    as BranchID,                                
 @User_Number  as internal_user_ID,                                
 @Narrative   as nvarchar(40),                                
 @ChequeTypeStatusID as int,                                
 @BusinessDate   as BusinessDate='1900/01/01',                                
 @ShadowAccType  as char(3)='',  --Marwa Arafat                                
 @ShadowAccNo  as AccountNumber='',--Marwa Arafat                                
 @AccountCurrency as CurrencyType='', --Marwa Arafat                                
 @AccountType  as char(3)='',  --Marwa Arafat                                
 @AccountAppType  as varchar(50)='', --Marwa Arafat                                
 @ShadowAccCurrency as CurrencyType='', --Marwa Arafat                                
 @ShadowAccAppType as varchar(50),  --Marwa Arafat                                
 @AccountStatus  as varchar(30),    --Marwa Arafat                        
 @FloatWithProfile     as bit = 0,  --Kareem Ezz                                    
 @ForUtility   as bit = 0,                                      
 @ForCreditCardPayment   as bit = 0,                            
 @ForStockMarketPayment   as bit = 0,              
 @AccountBranch      as BranchID = NULL,--mfarouk. save OutClearing account branch no to be used in FloatDatesAmend transaction              
 --@RefNo  as varchar(20)  
  @RimNumber as  int  = -1                               
AS                                
/*Version 2.00.46.20.11 Modification Date : 2016-08-15*/

/*                                
CreationDate: 2004-11-18                                
OriginalName: dbo.Insert_ClearDetail                                
Programmer: Mahmoud Elkabary                                
Description: Insert Out of Clear Cheques into ClearDetail and set status by Deposited                                
Output:                                  
Assumption:                                 
                                
ModifiedDate: 21/5/2006                                
Modifer:  mkandiel                                
ModifyReason: CR 31 BIB                                
                                
ModifiedDate: 06/12/2006                                
Modifer  :Mfattah                                
ModifyReason: Convert all text status to numbers                                
                                
ModifiedDate: 27/12/2006                                
Modifer: Ahmed Rafat                                
ModifyReason: Add GL and Routing numbers                                
                                
ModifiedDate: 11/01/2007                                
Modifer: Mohamed Gad                                
ModifyReason: Replacing the stars in the GL number with the current branch code                                 
                                
ModifiedDate: 12/02/2007                                
Modifer: Maie kandiel                                
ModifyReason: adding refno to tgrid as it is updated in the TPI step                                 
                                
ModifiedDate: 19/3/2007                                
Modifer: arafat                                
ModifyReason: cancel check if cheques exist                                
                                
ModifiedDate: 20/6/2007                                
Modifer: mzaatar                                
ModifyReason: cancel check if cheques exist                                
                                
ModifiedDate: 29/8/2007                                
Modifer: Marwa Arafat                                
ModifyReason: Update Shadow Account No and Type                                
                              
ModifiedDate: 05/12/2007                                
Modifer: Shimaa Saeed                                
ModifyReason: Add Chequedate And Creator to the grid                          
                          
Changed by:      Alaa Amer                          
Changed Date:    24-04-2008                          
Changed Reasons: Performance Enhancement                              
                        
Changed by:      Hatem Noaman                        
Changed Date:    07-06-2008                          
Changed Reasons: Add @ForCreditCardPayment,@ForStockMarketPayment                          
                      
Changed by:      Kareem Ezz                      
Changed Date:    14-09-2009                          
Changed Reasons: Add @FloatWithProfile  indicate the account has a profile in table CustomerPurChequesProfile                      
                  
                  
Changed by:      Adel Shaban                  
Changed Date:    12/3/2009                  
Changed Reasons: Uncomment the inserting statements of ChequeDate and Creator Fields                  
                  
Modifier: Hisham Nassef                  
Date:  2009-04-09                  
Reason:  1. Using Next_Table_MaxID procedure to generate id and TxnID                  
   2. Changing the text in proper and readable SQL statements                  
                
Modifier: Hoda Sayed                  
Date:  2010-06-27                
Reason: Insert Customer Cheque Reference                
              
ModifiedDate: 2010-08-04                        
Modifer: Mohammed Farouk                     
ModifyReason:  save customer account branch no, to be used in transaction 'FloatDatesAmend' when updating value date               
    based on account branch criteria ADIB CR 5766              
                
Modifier: Amira kamel                  
Date:  2010-0-08                
Reason:  CR # 5850 --Insert ISCertifiedCheque           
          
Modifier: Mohammed Farouk          
Date:  2012-08-23                
Reason:  CR # 9636 --change   DrawerAccNumber to be varchar (40) to support IBAN numbers  

Modifier: Muhammad Mabrouk            
Date:  2016-01-12                  
Reason:  CR # 9636 -- Adding RIM Number to the insert   

ModifiedDate: 	2016/08/15
Modifer:  		Mahmoud Kamel   
ModifyReason: 	Issue#GFSX10968 -  Setting ClearBankName and RimNumber       

ModifiedDate: 	05-1-2017
Modifer:  		Mostafa Abdlrazek
ModifyReason: 	CR#GFSY00614 ADIB_CRQ7501_xp - Cmdshell Alternative - Core System Intregration 

ModifiedDate: 	08-05-2019
Modifer:  		Mahmoud Saad   
ModifyReason: 	Issue#GFSX13649  

ModifiedDate: 	07-10-2019
Modifer:  		Mostafa Sayed
ModifyReason: 	CR#GFSY00769 - replace ClearDetailName varchar(250) with nvarchar(250)
*/                                
                                
set nocount on                     
                                
begin Transaction                          
                                     
--Declare @Status varchar(30)                                
--set @Status='Deposited'                                
                                
Declare @Status int                                
set @Status=1                                
                                
declare @y int                            
set @y = 0                                
while ((select t.IsInProcess from dbo.TableLock as t Where t.TableName = 'ClearDetail') <> 0 or                         
 (select t.IsInProcess from dbo.TableLock as t Where t.TableName = 'TableID') <> 0 )                                
begin                                
 if(@y = 120) return -1 -- timeout                                
 set @y = @y + 1                                
 waitfor delay '00:00:01'                                
end                                
                                
update dbo.TableLock set dbo.TableLock.IsInProcess = 1 Where dbo.TableLock.TableName = 'ClearDetail'                                
update dbo.TableLock set dbo.TableLock.IsInProcess = 1 Where dbo.TableLock.TableName = 'TableID'                                
                                
                                
declare @RowDelimiter  char(1),                           
 @ColDelimiter  char(1),                                
 @RowPos   int,                                
 @ColPos   int,                                
 @i   int,                                
 @j   int,                                
 @DataRow  varchar(350),                                
 @ColCount  int,                                
 @RowNumber  int,                                
 @ValueDate  smalldatetime,                                
 @tRefNo   varchar(20)  ,
 @ClearBankName	nvarchar(250)                             
                                 
declare @tGrid table (                                
 ChequeNumber  varchar(15)   NULL,                                
 DrawerAccNumber  varchar(40)   NULL,                               
 ChequeAmount  money     NULL,                                
 ClearBankBranchID  int     NULL,                      
                     
                                      
 ValueDate   smalldatetime   NULL,                                
 RowID    int     NULL,                                
 ClearCenter   int     NULL,                                
 ClearBillNumber  varchar(24)   NULL,                                
 SourceOfCheque  varchar(50)   NULL,                                
 Other    varchar(50)   NULL,                                
 Narrative   varchar(40)   NULL,                                
 AfterCutoffTime  varchar(10)   NULL,                                
 RoutingNo   varchar(16)   Null,                                
 GLNumber   varchar(60)   Null,                                
 ProviderID   smallint   NULL,                                
 tRefNo    varchar(20)   NULL,                                
 charges    money    NULL ,--mzaatar                                
                                
        ChequeDate   smalldatetime   NULL ,--ShimaaSaeed                                
        Creator                     nvarchar(40),                
CustomerReference varchar(20),            
ISCertifiedCheque   varchar(10), -- Amira kamel [8/8/2010]  
ClearDetailName      nvarchar(250)--ClearDetailName      varchar(250)                       
 )                                
                                
                                
Declare @RowID     int                                
Declare @Txn    int                                
Declare @ChequeNumber   varchar(15),                                
  @ClearBankBranchID  int,                                
  @DrawerAccNumber  varchar(40)              
               
                                
DECLARE @InputString   varchar(60)                                
DECLARE @InputStringIndex INT;                                
DECLARE @BranchIndex  INT;                                
DECLARE @TempStr    NVARCHAR(1);                            
                                
-- set @RowID = (select b.LastValue from dbo.TableID as b where lower(b.TableName) ='cleardetail' and lower(b.FieldName)='id')                                
                  
exec Next_Table_MaxID 'ClearDetail', 'id', @RowID output                  
                                
--if(@RowID is null)                                
--begin                                
-- insert into dbo.TableID(TableName,FieldName,LastValue) values('cleardetail','id',0)                                
-- if(@@error<>0)                                
-- begin                                
--  Rollback Transaction                                
--  return 0                                
-- end                                
-- set @RowID = 0                                
--end                                
                                
-- set @Txn = (select b.LastValue from dbo.TableID as b where lower(b.TableName) ='cleardetail' and lower(b.FieldName)='txnid')                                
                  
exec Next_Table_MaxID 'ClearDetail', 'TxnID', @Txn output                  
                  
--if(@Txn is null)                                
--begin                                
-- insert into dbo.TableID(TableName,FieldName,LastValue) values('cleardetail','txnid',0)                                
-- if(@@error<>0)                                
-- begin                                
--  Rollback Transaction                                
--  return 0                                
-- end                                
-- set @Txn = 0                                
--end                                
                                
                                
--set @Txn = @Txn + 1                  
                                
set @RowDelimiter = '|'           
set @ColDelimiter = ','                                
set @i = 1                                
set @RowPos = charindex(@RowDelimiter, @Grid, @i)                                
set @ColPos = 0                                
set @ColCount = 0                                
set @RowNumber = 0                                
                                
while (@RowPos > 0) -- row tabel                                
begin                           
 set @j = 1                                
 set @DataRow = substring(@Grid, @i, @RowPos-@i)+@RowDelimiter                                
 set @ColPos = charindex(@ColDelimiter, @DataRow, @j)                                
                              
 insert into @tGrid select null,null, null, null, null, null, null, null, null, null, null , null , null , null , null , null ,null,null,null,null ,null ,null                               
               
 set @ColCount = 0                                
 -- set @RowID = @RowID + 1                  
 set @RowNumber = @RowNumber + 1                                 
                             
 update @tGrid set RowID = @RowID where RowID is null                                
                                
 while (@ColPos > 0) -- column table                  
 begin                  
  set @ColCount = @ColCount + 1                  
                  
  if (@ColCount = 1)                                
  begin               update @tGrid set ChequeNumber = substring(@DataRow, @j, @ColPos-@j) where ChequeNumber is null                                
   set @ChequeNumber = substring(@DataRow, @j, @ColPos-@j)                                
  end                                
  else if (@ColCount = 2)                                
  begin                                
   update @tGrid set DrawerAccNumber = substring(@DataRow, @j, @ColPos-@j) where DrawerAccNumber is null                                
   set @DrawerAccNumber=substring(@DataRow, @j, @ColPos-@j)                                 
  end                                
  else if (@ColCount = 3)                                
  begin                                
   update @tGrid set ChequeAmount = cast(substring(@DataRow, @j, @ColPos-@j) as money) where ChequeAmount is null                                   
  end                                
  else if (@ColCount = 4)                                  
  begin                                  
   update @tGrid set ClearBankBranchID = substring(@DataRow, @j, @ColPos-@j) where ClearBankBranchID is null                                
   set @ClearBankBranchID = substring(@DataRow, @j, @ColPos-@j)  
   --MAhmoud Saad Issue # GFSX13649         
   
   SELECT @ClearBankName = B.ClearBankName
   From   dbo.ClearBank B with(nolock)
   left  Join dbo.ClearBankBranch BR with(nolock)
   On BR.ClearBankCode=B.ClearBankCode
   WHERE BR.ClearBankBranchID = @ClearBankBranchID

  update @tGrid set ClearDetailName = @ClearBankName where ClearDetailName is null                                
   --MAhmoud Saad Issue # GFSX13649             
  end               
  else if (@ColCount = 5)                                  
  begin                                
   update @tGrid set ClearCenter = cast(substring(@DataRow, @j, @ColPos-@j)as int) where ClearCenter is null                                
  end                                
  else if (@ColCount = 6)                                   
  begin                                
   update @tGrid set ValueDate = cast(substring(@DataRow, @j, @ColPos-@j)as smalldatetime) where ValueDate is null                                
  end                                
  else if (@ColCount = 7)                                   
  begin                                
   if (substring(@DataRow, @j, @ColPos-@j) <> 'NULL')                                
    update @tGrid set ClearBillNumber = substring(@DataRow, @j, @ColPos-@j) where ClearBillNumber is null                                
  end                                
  else if (@colCount = 8)                                
  begin                                
   update @tGrid set SourceOfCheque = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where SourceOfCheque is null                                
  end                                
  else if (@colCount = 9)                                
  begin                                
   update @tGrid set Other = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where Other is null                                
  end                                
  else if (@colCount = 10)                                
  begin                                
   update @tGrid set Narrative = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where Narrative is null                                
  end                                
  else if (@colCount = 11)                                
  begin                             
   update @tGrid set AfterCutoffTime = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where AfterCutoffTime is null                                
  end                                
  else if (@colCount = 12)                                
  begin                                
   update @tGrid set ProviderID = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where ProviderID is null                                
  end                                
  else if (@colCount = 13)                                
  begin                                
   update @tGrid set RoutingNo = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where RoutingNo is null                                     
  end                                
  else if (@colCount = 14)                                
  begin                                              
   --Gad 11-1-2007                                
   set @InputString = cast(substring(@DataRow, @j, @ColPos-@j)as varchar)                                
                                  
   set @InputStringIndex = LEN(@InputString)                                
   set @BranchIndex = LEN(@Branch)                                
   set @TempStr = '';                                
                                    
   while(@InputStringIndex >0)                                
   begin                                
    set @TempStr = SUBSTRING(@InputString, @InputStringIndex, 1);                                
                  
    if(@TempStr = '*')                                
    begin                                
     if(@BranchIndex > 0)                                
     begin                                
      set @InputString = STUFF(@InputString, @InputStringIndex, 1, SUBSTRING(CAST ( @Branch AS VARCHAR ), @BranchIndex, 1))                                
      set @BranchIndex = @BranchIndex - 1                                
     end                                
     else                                
     begin                            
      set @InputString = STUFF(@InputString, @InputStringIndex, 1, 0)                                
     end                                
    end                                
                                     
    set @InputStringIndex = @InputStringIndex - 1;                                
   end                                
                                
   update @tGrid set GLNumber = @InputString  where GLNumber is null                                
   ----------------------------------------------------------                                
  end                                
  else if (@ColCount = 15)                                   
  begin                                
   update @tGrid set tRefNo = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where tRefNo is null                 
  end                                
  --Mzaatar 20-6-2007-----                                 
  else if (@ColCount = 16)                                   
  begin                                
   update @tGrid set Charges = cast(substring(@DataRow, @j, @ColPos-@j)as money) where Charges is null                                
  end                                
  -------------------                                
               --ShimaaSaeed 04/12/2007-----                                 
  else if (@ColCount = 17)                                   
  begin                                
   update @tGrid set ChequeDate = cast(substring(@DataRow, @j, @ColPos-@j)as smalldatetime) where ChequeDate is null                                
  end                                
  -------------------                                
                                
               --ShimaaSaeed 04/12/2007-----                                 
  else if (@ColCount = 18)                         begin                                
   update @tGrid set Creator = cast(substring(@DataRow, @j, @ColPos-@j)as nvarchar) where Creator is null                                
  end                                
  -------------------                                    
  --Hoda Sayed [27-06-2010]                
  else if (@ColCount = 19)                                   
  begin                                
   update @tGrid set CustomerReference = cast(substring(@DataRow, @j, @ColPos-@j)as nvarchar) where CustomerReference is null                                
  end                                
  -------------------              
  --Amira kamel [8/8/2010] -- [CR # 5850 -- Add certified routing number ]            
  else if (@colCount = 20)                                
  begin                                
   update @tGrid set ISCertifiedCheque = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where ISCertifiedCheque is null                                
  end                
  ---------------------                                 
   
      
  set @j = @ColPos+1                                
                                
  if (@ColCount < 20)                                
  begin                                
   set @ColPos = charindex(@ColDelimiter, @DataRow, @ColPos+1)                                
  end                                 
  else if (@ColCount = 20)                                
  begin                                
   set @ColPos = 0                                
                                
   if ( @ForUtility = 1)                                
   begin                                
    if exists ( select  cd.ChequeNumber                                
       from dbo.ClearDetail as cd                                
       where cd.ChequeNumber = @ChequeNumber                  
       and  cd.AccountNumber = @AccountNumber                  
       and  cd.ClearBankBranchID = @ClearBankBranchID                  
       and  cd.ChequeTypeStatusID = @ChequeTypeStatusID)                  
    begin                                
     Rollback Transaction                                
     return -1                                
    end                                
   end                                
  end                                
 end -- end of column                                
                                
 set @i = @RowPos+1                                
 set @RowPos = charindex(@RowDelimiter, @Grid, @i+1)                     
                  
 if (@RowPos > 0)                  
  exec Next_Table_MaxID 'ClearDetail', 'id', @RowID output                  
end -- end of rows                  
    --Commented By MAhmoud Saad Issue # GFSX13649                            
--ITS Code Start [Mahmoud Kamel - 2016/08/15] Issue#GFSX10968 -  Setting ClearBankName and RimNumber
--DECLARE @ClearBankName	nvarchar(250);

--SELECT @ClearBankName = B.ClearBankName
--From   dbo.ClearBank B with(nolock)
--left  Join dbo.ClearBankBranch BR with(nolock)
--On BR.ClearBankCode=B.ClearBankCode
--WHERE BR.ClearBankBranchID = @ClearBankBranchID
--ITS Code End [Mahmoud Kamel - 2016/08/15] Issue#GFSX10968 -  Setting ClearBankName and RimNumber                                   
           --Commented By MAhmoud Saad Issue # GFSX13649                 
Insert Into dbo.ClearDetail(                  
  [ID],                                
  ChequeNumber,                                
  DrawerAccNumber,                                
  ChequeAmount,                                  
  TxnID,                                
  AccountNumber,                                
  ClearBankBranchID,                                
  Status,                                
  Branch,                                
  User_Number,                                
  ValueDate,                                
  Narrative,                                
  ChequeTypeStatusID,                            
  BusinessDate,                                
  RefNo,                                
  ClearingCenter,                                
  ClearBillNumber,                         
  SourceOfCheque,                                
  Other,                                
  AfterCutoffTime,                                
  Routing_No,                                
  GLNumber,                                
  ProviderID,                         
  Charges ,                              
  --mzaatar                                
  ChequeDate,                                
  Creator,                                
  ForUtilityPayment,                            
  ForCreditCardPayment, --H. Noaman                                
  ForStockMarketPayment,--H. Noaman                        
  FloatWithProfile,                
  CustomerReference,              
  AccountBranch,            
  ISCertifiedCheque,
  RIM_No,  --- Muhammad Mabrouk ADIB 101_CR_GFSY00544_2_OutClearingCR   12-1-2016                  
  ClearBankName)  --[Mahmoud Kamel - 2016/08/15] Issue#GFSX10968 -  Setting ClearBankName and RimNumber
Select [RowID],                                
  --ChequeNumber,
  CAST(REPLACE(REPLACE(ChequeNumber, CHAR(13), ''), CHAR(10), '') AS DECIMAL(15,0)), -- Mostafa.Abdelrazek CR#GFSY00614 ADIB_CRQ7501_xp -  Cmdshell Alternative-  Core System Intregration 05-1-2017                                  
  DrawerAccNumber,                                
  ChequeAmount,                                  
  @Txn,                                
  @AccountNumber,                                
  ClearBankBranchID,                                
  @Status,                                
  @Branch,                                
  @User_Number,                                
  ValueDate,                                
  @Narrative,                                
  @ChequeTypeStatusID,                                
  @BusinessDate,                                
  tRefNo,                           
  ClearCenter,                                
  ClearBillNumber,                                
  SourceOfCheque,                                
  Other,      
  AfterCutoffTime,--CASE AfterCutoffTime WHEN 'True' THEN 1 else 0 end, --Lamiaa Mostafa                               
  RoutingNo,                                
  GLNumber,                                
  CASE ProviderID WHEN 0 THEN null else ProviderID end,                                
  Charges ,--mzaatar                                
  ChequeDate,                                
  Creator,                                
  @ForUtility,                            
@ForCreditCardPayment,                            
  @ForStockMarketPayment,                       
  @FloatWithProfile ,   --this line added by kareem ezz                                
  CASE CustomerReference WHEN '' THEN NULL ELSE CustomerReference END,              
  @AccountBranch --mfarouk ADIB CR 5766                 
  ,ISCertifiedCheque --CASE ISCertifiedCheque WHEN 'True' THEN 1 ELSE 0 END             
  ,@RIMNumber       --- Muhammad Mabrouk ADIB 101_CR_GFSY00544_2_OutClearingCR   12-1-2016
 -- ,ClearBankName	--[Mahmoud Kamel - 2016/08/15] Issue#GFSX10968 -  Setting ClearBankName and RimNumber
 ,ClearDetailName
From @tGrid                               
                  
-- Added by Marwa Arafat 30/08/2007                                
update ClearDetail                  
set  ClearDetail.ShadowAccountType = @ShadowAccType ,                                 
  ClearDetail.CustomerShadowAcc = @ShadowAccNo,                                 
  ClearDetail.ShadowAccountCurrency = @ShadowAccCurrency,                                
  ClearDetail.ShadowAccApplicationType = @ShadowAccAppType,                                
  ClearDetail.AccountType = @AccountType,                                
  ClearDetail.AccountCurrency = @AccountCurrency,                                
  ClearDetail.AccountApplictopnType = @AccountAppType,                                
  ClearDetail.AccountStatus = @AccountStatus                       
where ClearDetail.TxnID=@Txn                  
-- end                                
                             
--update dbo.TableID set dbo.TableID.LastValue = @RowID  where lower(dbo.TableID.TableName) ='cleardetail' and lower(dbo.TableID.FieldName)='id'                                
--update dbo.TableID set dbo.TableID.LastValue = @Txn  where lower(dbo.TableID.TableName) ='cleardetail' and lower(dbo.TableID.FieldName)='txnid'                      
                                
update dbo.TableLock set dbo.TableLock.IsInProcess = 0 Where dbo.TableLock.TableName = 'ClearDetail'                                
update dbo.TableLock set dbo.TableLock.IsInProcess = 0 Where dbo.TableLock.TableName = 'TableID'                                
               
if(@@error<>0)                                
begin                                
 Rollback Transaction                                
 return 0                                
end                                
else                                
begin                                 
 Commit Transaction                                
 return @Txn                                
end  
GO          
drop_old_proc 'Search_ClearDetails'
GO
CREATE PROC dbo.Search_ClearDetails  --                
  @ClearBankBranchID varchar(20),                  
  @BankName varchar(50),                  
  @BranchName  varchar(35),                  
  @DateFrom smalldatetime,                   
  @DateTo smalldatetime  ,              
   --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
  @DepositBranchID BranchID = -1,                  
  @DepositDateFrom nvarchar(100) = '',                  
  @DepositDateTo nvarchar(100) = '',                  
  @ChequeNumber decimal(15, 0) = -1,
  --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)] 
  @currency CurrencyType                         
as                  
/*                  
 BY : Shimaa Saeed                  
 Date : 2005-08-29                  
 Reason : select from cleardetails                 
               
 Modification Date:   24/04/2012                  
 Modifer:     Asmaa Hafez                   
 Modification Reason: Adding parameters '@DepositBranchID, @DepositDateFrom , @DepositDateTo ,@ChequeNumber'               
       - CR # 6772 (Outward Clearing Off Balance) - ADIB Retrofitting             
               
 Modification Date:   29/04/2012                  
 Modifer:     Asmaa Hafez                   
 Modification Reason: select effective date         
       - CR # 9014 (Amend Effective date to be next valid Effective Date) - ADIB Retrofitting           
  
 Modification Date:   29/09/2012                  
 Modifer:     Lamiaa Mostafa                  
 Modification Reason: Fixing Issue #GFSX01318 -  return EffectiveDate column with default value and in datetime datatype. 
     
 Modification Date:   21/1/2016                
 Modifer:     Moataz Mahsoub 
 Version #1812                 
 Modification Reason: return EffectiveDate column with value From ClearDetail Table.   
 
 Modification Date:   17/12/2018          
 Modifer:     Rokaia Kadry              
 Modification Reason: return ID column issue#GFSX13438.  
 
 Modification Date:   21/11/2019          
 Modifer:     Mostafa Sayed
 Modification Reason: Issue#GFSX13859 - add currency filed to search criteria.
      
*/                  
SET NOCOUNT ON       
         
declare @NoOfRows int        
select @NoOfRows=1000         
select @NoOfRows = convert( nvarchar(10),Value)          
from RulesTranFldParam          
Where  TranName = 'OutwardClChequeSettlement' And Param = 'NoOfRowsProcess'           
          
                  
if (@ClearBankBranchID <>'')                  
Begin                  
                  
    select Top (@NoOfRows)      
            AccountNumber,                  
            AccountType,                  
            AccountCurrency,                  
            ChequeNumber,                  
            DrawerAccNumber,                  
            ValueDate,             
           -- convert(varchar, '1900-08-28 00:00:00', 103) as EffectiveDate,  
            EffectiveDate,                 
            ChequeAmount,                  
            @BankName,                  
            @BranchName,                  
            Branch,                  
            CustomerShadowAcc,                  
            ShadowAccountType,                  
            ShadowAccountCurrency,                  
            AccountApplictopnType,                  
            ShadowAccApplicationType,                  
            AccountStatus ,  
            HostTranResponse,            
            HostTranStatus,
            [ID]
                          
                  
    From   ClearDetail                  
    Where Status=4                  
          AND ClearBankBranchID=@ClearBankBranchID                  
          AND ValueDate BETWEEN @DateFrom AND @DateTo                
          -- Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
          AND (@DepositBranchID = -1 OR Branch = @DepositBranchID)               
          AND ((@DepositDateFrom = '') OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))              
          AND (@ChequeNumber = -1 OR ChequeNumber = @ChequeNumber)              
          -- Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]
          AND (@currency = '' OR AccountCurrency = @currency)
End                  
                  
                  
Else                  
Begin                  
    select Top (@NoOfRows)       
            AccountNumber,               
            AccountType,                  
            AccountCurrency,                
            ChequeNumber,                  
            DrawerAccNumber,                  
            ValueDate,                
            --convert(varchar, '1900-08-28 00:00:00', 103)  as EffectiveDate, 
            EffectiveDate,                    
            ChequeAmount,                  
            @BankName,                  
            @BranchName,                  
            Branch,                  
            CustomerShadowAcc,                  
            ShadowAccountType,                 
            ShadowAccountCurrency,                  
            AccountApplictopnType,                  
            ShadowAccApplicationType,                  
            AccountStatus   ,            
            HostTranResponse,            
            HostTranStatus,
            [ID]  
                     
               
    From ClearDetail                  
    Where Status=4                  
          AND ValueDate BETWEEN @DateFrom AND  @DateTo                
          -- Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
          AND (@DepositBranchID = -1 OR Branch = @DepositBranchID)               
          AND ((@DepositDateFrom = '') OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))              
          AND (@ChequeNumber = -1 OR ChequeNumber = @ChequeNumber)              
          --  Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]
          AND (@currency = '' OR AccountCurrency = @currency)
END        
Go
drop_old_proc 'dbo.Get_Processed_ClearDetails'
GO
CREATE PROCEDURE dbo.Get_Processed_ClearDetails
(
	 @ClearBankBranchID varchar(20),                
	 @BankName varchar(50),                
	 @BranchName  varchar(35),                
	 @DateFrom smalldatetime,                 
	 @DateTo smalldatetime ,                 
	 @DepositBranchID nvarchar(20)  = '',            
	 @DepositDateFrom nvarchar(100) = '',            
	 @DepositDateTo nvarchar(100)   = '',            
	 @ChequeNumber nvarchar(20)     = '',   
	 @IDs nvarchar(max)  
)
AS
	/*
	Developer	: Mostafa Sayed
	Date		: [7/10/2019]
	Reason		: CR#GFSY00769 - BLOM_ACM18385_Out Clearing Settlement Bulk .....
	
	Developer	: Mostafa Sayed
	Date		: [24/12/2019]
	Reason		: Issue#GFSX13897 - Ignore 'NoOfRows' parameter and return all cheques
    */
    
	DECLARE @x XML   
	SELECT @x = CAST('<A>'+ REPLACE(@IDs,',','</A><A>')+ '</A>' AS XML)       
   
	--DECLARE @NoOfRows int    
	--SELECT @NoOfRows = 1000     
	--SELECT @NoOfRows = convert( nvarchar(10),Value)         
	--FROM RulesTranFldParam with(nolock)        
	--WHERE  TranName = 'OutwardClChequeSettlement' And Param = 'NoOfRows' And Param = 'NoOfRows' And IsNumeric(Value) = 1       
   
	IF(@ChequeNumber='')  
		SET @ChequeNumber = -1  
          
	if (@ClearBankBranchID <>'')                
	Begin      
		SELECT --Top(@NoOfRows) 
			ChequeNumber as 'ChequeNumber',
			ChequeAmount as 'ChequeAmount', 
			Status.ShortDescription as 'Status', 
			ClearBankName as 'ClearBankName', 
			RIM_No as 'RIM_No'
		FROM   ClearDetail inner JOIN Status
		ON ClearDetail.Status = Status.id
		WHERE ClearBankBranchID=@ClearBankBranchID                
		AND ValueDate BETWEEN cast(@DateFrom as date) AND CAST( @DateTo  as DATE)                
		AND (@DepositBranchID ='' OR Branch = @DepositBranchID)          
		AND (@DepositDateFrom ='' OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))               
		AND (@ChequeNumber = convert (varchar, -1) OR ChequeNumber = @ChequeNumber)            
		AND ClearDetail.ID in ( SELECT t.value('.', 'int') AS inVal  FROM @x.nodes('/A') AS x(T))
		AND Status.StatusTypeID=1
	End                
	Else                
	Begin           
		SELECT --Top(@NoOfRows) 
			ChequeNumber as 'ChequeNumber',
			ChequeAmount as 'ChequeAmount', 
			Status.ShortDescription as 'Status', 
			ClearBankName as 'ClearBankName', 
			RIM_No as 'RIM_No'
		FROM ClearDetail inner JOIN Status
		ON ClearDetail.Status = Status.id
		WHERE ValueDate BETWEEN cast(@DateFrom as date) AND CAST( @DateTo  as DATE) 
		AND (@DepositBranchID ='' OR Branch = @DepositBranchID)        
		AND (@DepositDateFrom ='' OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))      
		AND (@ChequeNumber = convert (varchar,-1) OR ChequeNumber = @ChequeNumber)    
		AND ClearDetail.ID in ( SELECT t.value('.', 'int') AS inVal  FROM @x.nodes('/A') AS x(T))
		AND Status.StatusTypeID=1
	END
GO
drop_old_proc 'dbo.GetMissingOperatorInfo'
GO
CREATE PROCEDURE dbo.GetMissingOperatorInfo
(  
	  @bank BankID = NULL
	, @region RegionID = NULL
	, @branch BranchID = NULL              
	, @user_number internal_user_id = NULL
)
AS
	/*
	Developer	: Mostafa Sayed
	Date		: [23/12/2019]
	Reason		: CR#GFSX13895 - Get missing operator info after open day
	Notes		: The below procedure logic is following dbo.GetAllOperatorInfo proc
    */
    DECLARE @BusinessDate SmallDate
    DECLARE @StartingCash money
    DECLARE @TCurrency CurrencyType
    DECLARE @CashDrawer CashDrawerNumber
    DECLARE @IsOpenDay bit 
    
    SELECT @BusinessDate=LastBusinessDate, @IsOpenDay=IsOpenDay
    FROM Operator_Status 
	WHERE user_number=@user_number
	
	IF(@IsOpenDay = 1) 
	BEGIN
		SELECT @CashDrawer = CD.CashDrawerNumber           
		FROM dbo.CashDrawer CD              
		JOIN dbo.CashDrawerDefinition CDD 
			ON CD.DrawerType = CDD.DrawerType              
			AND CD.AssignedToTeller = @user_number              
			AND CD.Bank = @bank AND CD.Branch = @branch AND CD.Region = @region              
			AND CD.IsActive = 1 AND CDD.PrimaryOrSecondary = 'P'    
	     
		 -- Discover Currency type from dbo.CashDrawerStart table.              
		SELECT TOP 1 @TCurrency = CurrencyType              
		FROM dbo.CashDrawerStart               
		WHERE Bank = @bank AND Region = @region AND Branch = @branch               
			AND CashDrawerNumber = @CashDrawer               
		ORDER BY LastChanged DESC              
	              
	    -- Discover Currency from branch table.          
		IF @TCurrency IS NULL               
			SELECT @TCurrency = DefaultCurrency              
			FROM dbo.Branch_Static              
			WHERE Bank = @bank AND Region = @region AND Branch = @branch               
	              
		SELECT @StartingCash=StartingCash               
		FROM dbo.CashDrawerStart               
		WHERE Bank = @bank AND Region = @region AND Branch = @branch               
			AND CashDrawerNumber = @CashDrawer               
			AND CurrencyType = @TCurrency
	END
    SELECT BusinessDate= @BusinessDate,IsOpenDay=@IsOpenDay,StartingCash= @StartingCash
GO
drop_old_proc InsertIntoLocalInwardMessages
GO
CREATE PROC dbo.InsertIntoLocalInwardMessages
@MSGID	varchar(35),
@MSGName	varchar(36),
@CreationDateTime	datetime,
@NumberofTrans	int,
@TotalInterbankSettCCY	char(3),
@TotalInterbankSettAMT	money,
@InterBankSettDate	date,
@SettlementMethod	varchar(35),
@Proprietary	varchar(35),
@InstructionPriority_hdr	varchar(35),
@ClearingChannel_hdr	varchar(35),
@CategoryPurpose_hdr	varchar(35),
@InstructionIdentification	varchar(35),
@EndtoEndIdentification	varchar(35),
@TranIdentification	varchar(35),
@InstructionPriority_tran	varchar(35),
@ClearingChannel_tran	varchar(35),
@CategoryPurpose_tran	varchar(35),
@InterbankSettCCY	char(3),
@InterbankSettAMT	money,
@ChargeBearer	varchar(35),
@Debtor	nvarchar(240),
@DebtorAccount	varchar(60),
@DebtorAgent	varchar(12),
@DebtorAgentAccount	varchar(60),
@CreditorAgent	varchar(12),
@CreditorAgentAccount	varchar(60),
@Creditor	nvarchar(240),
@CreditorAccount	varchar(60),
@Purpose	int,
@RemittanceInformation	varchar(140),
@DebtorAgentBIC	varchar(12),
@CreditorAgentBIC	varchar(12),
@Queue	int,
@Status	int,
@ExceptionReason	int,
@NameMatchPercent	varchar(5)

as      

/* Version = '1.61.1524.16702' , Modification Date = '2012/08/23 - 19:67 ' */      

/*  

ModifiedDate: 23-08-2015

Modifer  : Nada Elshafie    

ModifyReason: Adding Local Inward Message  

-----------------------------------------

ModifiedDate: 26-02-2016

Modifer  : Karim Mahmoud    

ModifyReason: Adding Name Matching Percent  

-----------------------------------------
ModifiedDate: 23-12-2019

Modifer  :  Mahmoud  Saad

ModifyReason:Fixing issue GFSX13892 

*/  

set nocount on

IF NOT EXISTS(SELECT * FROM Local_Inward_Messages_Header where MSGID=@MSGID)
BEGIN
insert into Local_Inward_Messages_Header
(
MSGID,
MSGName,
CreationDateTime,
NumberofTrans,
TotalInterbankSettCCY,
TotalInterbankSettAMT,
InterBankSettDate,
SettlementMethod,
Proprietary,
InstructionPriority_hdr,
ClearingChannel_hdr,
CategoryPurpose_hdr)
values
(
@MSGID	,
@MSGName	,
@CreationDateTime	,
@NumberofTrans	,
@TotalInterbankSettCCY	,
@TotalInterbankSettAMT	,
@InterBankSettDate	,
@SettlementMethod	,
@Proprietary	,
@InstructionPriority_hdr	,
@ClearingChannel_hdr	,
@CategoryPurpose_hdr
)
END

insert into Local_Inward_Messages_Detail
(
MSGID,
InstructionIdentification,
EndtoEndIdentification,
TranIdentification,
InstructionPriority_tran,
ClearingChannel_tran,
CategoryPurpose_tran,
InterbankSettCCY,
InterbankSettAMT,
ChargeBearer,
Debtor,
DebtorAccount,
DebtorAgent,
DebtorAgentAccount,
CreditorAgent,
CreditorAgentAccount,
Creditor,
CreditorAccount,
Purpose,
RemittanceInformation,
Queue,
Status,
ExceptionReason,
NameMatchPercent
)
values
(
@MSGID	,
@InstructionIdentification	,
@EndtoEndIdentification	,
@TranIdentification	,
@InstructionPriority_tran	,
@ClearingChannel_tran	,
@CategoryPurpose_tran	,
@InterbankSettCCY	,
@InterbankSettAMT	,
@ChargeBearer	,
@Debtor	,
@DebtorAccount	,
case when @DebtorAgent is  null then @DebtorAgentBIC else  @DebtorAgent end,
@DebtorAgentAccount	,
case when @CreditorAgent is null then @CreditorAgentBIC else @CreditorAgent end,
@CreditorAgentAccount	,
@Creditor	,
@CreditorAccount	,
@Purpose	,
@RemittanceInformation	,
@Queue	,
@Status	,
@ExceptionReason,
@NameMatchPercent
)      

GO