--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc select_ValidationCondition
Go

CREATE   procedure dbo.select_ValidationCondition
@RulesTranValidationId int
As

/* 
name: 		dbo.select_ValidationCondition    
developer: 	Hany A HAssan   
reason: 	Retrofitting from CBD - To select all validations actions related to the incoming tran validation id
data:		4 January 2009 

Modifier: Nada Elshafie
Reason: GFSY00642 - Add Column DBAccessID - WebServiceName - WebServiceMethod
Date: 18 April 2017

updator: 	Nehal Ramadan
reason: 	GFSY00727 Adding Index1,Index2 to the validation 
date:		20 Septemper 2018 
*/

select 
Id,
Seq,
OperandsDataType,
Operand1,
Operator,
Operand2,
LogicalOperator,
DBAccessID,
WebServiceName,
WebServiceMethod,
ArrayIndex1,
ArrayIndex2

from ValidationsConditions

where RulesTranValidationId = @RulesTranValidationId


Go
--End of Automatic Generation
------------------------------------------------------------------------------------------
--  Any customization of SQL files should be contained within one of the following files
--  associated with each application:  CustomProcedures.SQL, CustomViews.SQL,
--  CustomObjects.SQL or CustomPostProcessing.SQL.  The Core application contains an
--  additional file, CustomTypes.SQL
--  Any customization not implemented in this manner will be overlaid with standard code
--  when an upgrade is installed.
------------------------------------------------------------------------------------------

-- Copyright 2005, 2006, 2007, 2008 Getronics USA, INC. All rights reserved.

-------------------------------------------------------------------------------
-- This should be run only in the Globalfs database.
if db_name() not like 'G%' or db_name() like 'G%Archive'
   raiserror('Error in Archive_Journal_Summary.SQL.  Not run in correct database!  Killing the SPID now.'
       ,22,127) with log
go
-------------------------------------------------------------------------------
SET NOCOUNT ON 
exec sp_addmessage 59999, 16,'XXIERR: SQL injection attempt. XXIERR_END'
		,@replace = 'replace' 

exec drop_old_proc Get_Archive_Journal_Summary
GO


CREATE PROC Get_Archive_Journal_Summary 
	@start_date smalldate, @end_date smalldate,
	@criteria nvarchar(3000) = '', 
	@order_time_ascending bit = 0,
	@max_rows int = 9,  -- Zero means return only one row.
	@page_back bit = 0,
	@LCID int = NULL, -- May be used to get local tran Description.
	@view_name sysname = 'Archive_JOURNAL',
	@select_list_name varchar(30) = 'JOURNAL_SUMMARY', -- An AccessName in SQLstrings.
	@history_server sysName = NULL, -- archive database server Name
	@history_database sysName = NULL, -- archive database Name
	@for_user internal_user_ID=0,
	@debug int = 0
AS
-- Query the Teller journal summary view for records that match the criteria.
-- For just the @max_rows that match the criteria, join in the description
--  of the transaction as "Tran_Title".

-- When @page_back is ON, you get the last n rows that match the criteria.

-- This uses the select projection lists from SQLstrings.AccessString, developed by proc SetJnlSummaryColumns2.
-- Copyright 2005 - 2008 Getronics USA, INC. All rights reserved.
-- 27SEP05 Bodhi Densmore Version 1
-- 15JAN07 Diana - Add extra condition to the 'where' clause for checking privileges in OperatorRoles. CR14966
-- 24APR07 D & B - Support smalldate as integer.
-- 16MAR08 DEEPAK D R - Collation cast added CR16728
/*      
Modified By: Mohamed Elabd
Date:		 24-September-2018
Reason:		 Select AccountEntries - CR# GFSY00720
*/  

SET NOCOUNT ON
declare @sql nvarchar(4000), @param_defs nvarchar(1000)
declare @summary_sql nvarchar(4000), @position int, @operator_columns nvarchar(500)
declare @position_of_from int
declare @date_string varchar(30), @date_string2 varchar(30)
declare @normal_descending_order nvarchar(300)
	, @normal_ascending_order nvarchar(300)
	, @inside_order nvarchar(300)
	, @outer_order nvarchar(300)
declare @tran_def_columns nvarchar(200)
declare @start_year_month smallint, @end_year_month smallint
		, @start_day tinyint, @end_day tinyint
declare @table_name sysname, @suffix char(7)
declare @where nvarchar(1000)
declare @history_schema sysname

--Mohamed Elabd [Start: 24-September-2018 - CR# GFSY00720]
declare @AcctEntries_table sysname    
declare @AcctEntries_sql nvarchar(4000) 
--Mohamed Elabd [End: 24-September-2018 - CR# GFSY00720]
  
if @criteria is null set @criteria = ''
if @history_database is null 
	set @history_database = db_name() + '_Archive'

if @history_server is null
	set @history_schema = @history_database + '.dbo.'
else
	set @history_schema = dbo.f_QuoteName(@history_server) + '.'+@history_database + '.dbo.'
	
set @start_year_month = dbo.YYMM_of_SmallDate(@Start_Date)
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)
set @start_day = DatePart(dd, dbo.datetime_of_smalldate(@start_date))
set @end_day = DatePart(dd, dbo.datetime_of_smalldate(@end_date))
if @start_year_month = @end_year_month and @view_name = 'Journal' BEGIN
	set @suffix = dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@start_date))
	set @table_name = 'ZJournal'+ @suffix
 set @AcctEntries_table = 'ZJNL_AccingEnt'+ @suffix  --Mohamed Elabd [24-September-2018 - CR# GFSY00720] 
	set @where = N'WHERE J.year_month = @start_ym' + char(10) 
	+ ' AND J.BusinessDate_Day '
	+ case when @start_day = @end_day 
		then '= @start_day AND J.BusinessDate = @start_date'
		else 'between @start_day and @end_day
		 and J.BusinessDate between @start_date and @end_date'
	  end
END 
ELSE BEGIN
	set @table_name = @view_name
 set @AcctEntries_table = 'JNL_AccingEnt'  --Mohamed Elabd [24-September-2018 - CR# GFSY00720]
	set @where = N'WHERE J.year_month between @start_ym and @end_ym
	and J.BusinessDate between @start_date and @end_date'
END

if @for_user >0 and dbo.operator_has_wildcard_permissions(@for_user)<1
	set @where =@where+' AND dbo.is_BranchAllowed(@for_user,J.Bank,J.Region,J.Branch)=1 '

IF isNULL(@LCID,0) = 0 
--**CR16728 ** S
	set @tran_def_columns = N'

 , Tran_Title = T.Description collate SQL_Latin1_General_CP1_CI_AS, T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable '
else 
--**CR16728 ** E
	set @tran_def_columns = N'

 , Tran_Title = isNULL(isnull(RD.LocalDescription, D.Descriptor), T.Description collate SQL_Latin1_General_CP1_CI_AS), T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable '

exec dbo.journal_summary_columns_string @s = @summary_sql out, @access_name = @select_list_name

--Mohamed Elabd [Start: 24-September-2018 - CR# GFSY00720]
select @AcctEntries_sql =    
 char(10)+N',(select  x.Subscript, x.JNL_Acct_ENT_ACCOUNT,    
x.JNL_Acct_ENT_DB_CURR,    
x.JNL_Acct_ENT_DB_AMOUNT,    
x.JNL_Acct_ENT_CR_CURR,    
x.JNL_Acct_ENT_CR_AMOUNT    
' + char(10)        
+ 'FROM dbo.'+@AcctEntries_table+N' x'    +' where J.BusinessDate = x.BusinessDate    
and J.user_Number= x.user_Number    
and J.Bank = x.Bank     
and J.Region = x.Region     
and J.Branch = x.Branch     
and J.JNLSequence = x.JNLSequence     
for xml path(''AccountEntries'')    
) as AccountEntries'    
--Mohamed Elabd [End: 24-September-2018 - CR# GFSY00720]

set @position = charindex(', dbo.opID_of_U#', @summary_sql, 100)
if @position = 0 begin
		raiserror('Get_Archive_Journal_Summary can not find ", dbo.opID_of_U#" in "%s" SQLstrings.AccessString'
		, 16, 1, @select_list_name)
		return -1
end
set @position_of_from = charindex(' FROM ', @summary_sql, @position) - (@position + 2)
set @operator_columns = substring(@summary_sql, @position+2, @position_of_from)
set @operator_columns = replace(@operator_columns, '(user_number', '(JS.user_number')
set @position = @position -1
if @debug > 0 or @@servername like 'GFS%R'begin
	if dbo.datetime_of_smalldate(@start_date) < dbo.f_Teller_Base_date() or @start_date is null begin
		set @date_string = isNULL(convert(varchar(10), dbo.datetime_of_smalldate(@start_date), 120), '-NULL-')
		set @date_string2 = convert(varchar(10),dbo.f_Teller_Base_date(), 120) 
		raiserror('Get_Archive_Journal_Summary @start_date,"%s" must be > "%s"'
			, 16, 1, @date_string, @date_string2)
		return -1
	end
	if @start_date > @end_date or @end_date is null begin
		set @date_string = isNULL(convert(varchar(10), dbo.datetime_of_smalldate(@end_date), 120), '-NULL-')
		set @date_string2 = convert(varchar(10),dbo.datetime_of_smalldate(@start_date), 120) 

		raiserror('Get_Archive_Journal_Summary @end_date, "%s" must be >= @startdate = "%s"'
			, 16, 1, @date_string, @date_string2)
		return -1
	end
end else
	if @start_date > @end_date begin
		raiserror('Start_date is later than end_date', 16,1)
		return -1
	end

if @criteria is null print 'c NULL'

set @criteria = dbo.TRIM(@criteria)  -- TRIM off left and right spaces.
if @criteria <> '' begin
	if  substring(@criteria,1,8) not like '%where %'
		if left(@criteria, 4) = 'AND ' 
			set @criteria = @where + ' ' + @criteria
		else begin
			raiserror('Get_Archive_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)
			return -1
		end
	if charindex(';', @criteria,4) > 0 
	or patindex('%[^0-9a-z_]go[^0-9a-z_]%', @criteria) > 0 begin
		raiserror('Get_Archive_Journal_Summary @criteria parameter is invalid', 16, 1)
		set @criteria = 'SQL injection attack on Get_Archive_Journal_Summary: '+ @criteria
		exec master.dbo.xp_logevent 59999, @criteria, 'ERROR'
		return -1
	end
end
	
if @criteria = ''
	set @criteria = @where
else begin
	if @criteria like '%[^a-z_0-9.]Bank %' 
		set @criteria = replace (@criteria, 'bank ', 'J.bank')

	if @criteria like '%[^a-z_0-9.]user_number %' 
		set @criteria = replace (@criteria, 'user_number ', 'J.user_number')

	if @criteria like '%[^a-z_0-9.]Region %' 
		set @criteria = replace (@criteria, 'region ', 'J.region')

	if @criteria like '%[^a-z_0-9.]Branch %' 
		set @criteria = replace (@criteria, 'branch ', 'J.branch')

	if substring(@criteria,1,8) not like '%where %' begin
		if left(@criteria, 4) = 'AND ' 
			set @criteria = @where + ' ' + @criteria
		else begin
			raiserror('Get_Archive_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)
			return -1
		end
	end else 
		set @criteria = @where +REPLACE(@criteria,'where', ' AND')
end	
if @max_rows <= 0 begin
	raiserror('Get_Archive_Journal_Summary @max_rows "%d", must be greater than 0', 16, 1, @max_rows)
	return -1
end

set @normal_descending_order = N'
 order by Bank,Region,Branch,user_number,TransactionTime desc, JNLSequence desc'
set @normal_ascending_order = N'
 order by Bank,Region,Branch,user_number,TransactionTime,JnlSequence'
set @inside_order = case 
when @order_time_ascending = 0 and @page_back = 0 then @normal_descending_order
when @order_time_ascending = 0 and @page_back = 1 then N'
 order by Bank desc,Region desc,Branch desc, user_number desc,TransactionTime, JnlSequence'
when @order_time_ascending = 1 and @page_back = 0 then @normal_ascending_order
else N'
 order by Bank desc,Region desc,Branch desc,user_number desc,TransactionTime desc, JNLSequence desc'
end

select @sql = N'SELECT TOP '+cast((@max_rows+1) as nvarchar) 
+ substring(@summary_sql,1, @position) 
+ @AcctEntries_sql  --Mohamed Elabd [24-September-2018 - CR# GFSY00720]
+ char(10)
+ 'FROM '+@history_schema+@table_name+N' J'
+ char(10) + @criteria + @inside_order

if @page_back = 1 begin
	set @outer_order = case @order_time_ascending
          when 0 then @normal_descending_order
	  else @normal_ascending_order
	  end

	set @sql = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql+N') BOTTOM' + @outer_order
end
IF isNULL(@LCID,0) = 0 
	set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns 
+ N'
FROM (' + @sql + ') AS JS
JOIN dbo.RulesTranName T
	on T.TransactionName = JS.TranName'
	
ELSE 
	set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns 
+ N'
FROM (' + @sql + ') AS JS
JOIN dbo.RulesTranName T
  on T.TransactionName = JS.TranName
LEFT OUTER JOIN dbo.RulesDescriptor D
  on D.DescriptorID = T.DSC_Description
LEFT OUTER JOIN dbo.RulesDescriptorLocal RD
  on RD.DescriptorID = D.DescriptorID and LCID = @LCID'
+ char(10)+ + @inside_order
  
  
set @param_defs = N'@LCID int, @start_date smalldate, @end_date smalldate, @start_ym smallint, @end_ym smallint, @start_day tinyint, @end_day tinyint, @for_user internal_user_ID'
if @debug > 0 begin
	print '-------cut here ---------' 
	print 'declare ' + @param_defs + char(10) 
	print 'select @LCID = ' + isnull(cast(@LCID as varchar), 'NULL')
	print '    , @start_date = '''+cast(@start_date as varchar) + ''''
	print '    , @end_date = '''+cast(@end_date as varchar) + ''''
	print '    , @start_ym = '+cast(@start_year_month as varchar)
	print '    , @end_ym = '+cast(@end_year_month as varchar)
	print '    , @start_day = '+cast(@start_day as varchar)
	print '    , @end_day = '+cast(@end_day as varchar)
	print '	,@for_user='+cast(@for_user as varchar)
	/*print '    , @user_number = ' + case @user_number when NULL then ' NULL ' else cast(@user_number as varchar) end*/
	print @sql 
	if @debug > 3 return -1
end
exec dbo.sp_executesql @sql, @param_defs, @LCID, @start_date, @end_date
	, @start_year_month, @end_year_month, @start_day, @end_day, @for_user
GO

if 'testing' is  NULL and object_id(N'Journal')is not null
BEGIN
	DECLARE @archive_server sysname
	set @archive_server = nullif(dbo.Archive_Server_Name(),'')
	--set @archive_server = 'DBmaster'
	declare @start smalldate set @start = dbo.smalldate_of(dateadd(d, -60, getdate()))
	declare @end smalldate set @end = dbo.smalldate_of(getdate() - 31)
	declare @user_number internal_user_ID
	declare @bk bankID
	select @start = min(BusinessDate)
	from dbo.TellerStats 
	where BusinessDate >= @start
	select @user_number = min(user_number) 
	from dbo.TellerStats 
	where BusinessDate between @start and @end
	select @bk = bank 
	from dbo.TellerStats
	where businessdate between @start and @end 
	  AND user_number = @user_number
	declare @user_criteria varchar(50)
	set @user_criteria = 'WHERE user_number = '
	+ cast (@user_number as varchar)
	+ ' and Bank = ' + cast(@bk as varchar)
	EXEC dbo.Get_Archive_Journal_Summary @start, @end, @user_criteria
	, @order_time_ascending=0, @page_back = 1,@LCID=1034
	, @history_server = @archive_server,@debug=1

	EXEC dbo.Get_Archive_Journal_Summary @start, @end, @user_criteria
		, @order_time_ascending=0, @page_back = 1
		, @history_server = @archive_server,@debug=1

	EXEC dbo.Get_Archive_Journal_Summary @start, @end, '', @order_time_ascending=0, @max_rows= 10000
	, @history_server = @archive_server,@for_user=345, @debug=1
	
	-- The next one [commented out] should fail because the dates are reversed.
	--EXEC dbo.Get_Archive_Journal_Summary @end, @start, @user_criteria, @order_time_ascending=0, @debug=1
	set @start = dbo.smalldateadd('dd', -24, @start)  -- go back 24 days to ensure a test with separate month.
	EXEC dbo.Get_Archive_Journal_Summary @start, @end, @user_criteria
		, @order_time_ascending=0, @page_back = 1
	, @history_server = @archive_server,@debug=1

/*
	exec dbo.Get_Archive_Journal_Summary @criteria=' AND dbo.compare_tj_keys(Bank, 465, Region, 1, Branch, 50, user_number, 26, TransactionTime, ''2005-08-17 09:14:14'', JNLSequence, 5, 0)  >= 0'
	, @start_date ='20050817'
	, @end_date= '20050817'
	,  @order_time_ascending=0
	,@max_rows=10,@page_back=0, @LCID=1033
	, @debug = 1
*/
	END
go
drop_old_proc 'FL_DefaultValue'
GO
create  Proc dbo.FL_DefaultValue     
@FieldListNames  nvarchar(max)                     
as                
/*
 CreationDate	:	31-10-2018       
 Programmer		:	Ahmed Osman
 Description	:	Return defualt values for the every field list in field list CR#GFSY00720 || Issue GFSX13342                           
*/   
BEGIN
IF OBJECT_ID('tempdb..#FL_DefualtValue_Results') IS NOT NULL DROP TABLE #FL_DefualtValue_Results
create table #FL_DefualtValue_Results
(
    Name VARCHAR(max), Value VARCHAR(100)
)
END
declare @FieldName nvarchar(200) , @FieldType nvarchar(200) , @FieldValue nvarchar(100)

while len(@FieldListNames) > 0
begin
  set @FieldName = left(@FieldListNames, charindex('|', @FieldListNames+'|')-1)

  set @FieldType = (SELECT DataType FROM RulesDBField WHERE Name = @FieldName)
  
  exec GetTypeDefaultValue @FieldType , @FieldValue output
  
  insert INTO #FL_DefualtValue_Results
  VALUES(@FieldName,@FieldValue)
  
  set @FieldListNames = stuff(@FieldListNames, 1, charindex('|', @FieldListNames+'|'), '')
end

SELECT * FROM #FL_DefualtValue_Results

IF OBJECT_ID('tempdb..#FL_DefualtValue_Results') IS NOT NULL DROP TABLE #FL_DefualtValue_Results
GO
drop_old_proc 'GetTypeDefaultValue'
GO
create  Proc dbo.GetTypeDefaultValue     
 @Type  nvarchar(100),
 @Result nvarchar(100) output                              
as                
/*
 CreationDate	:	31-10-2018       
 Programmer		:	Ahmed Osman
 Description	:	Get Default value for the data type #GFSX13342                            
*/   
declare @SystemTypeID int , 
		@SystemTypeName nvarchar(100)

IF Exists(SELECT * FROM sys.types WHERE is_user_defined = 1 AND name = @Type)
BEGIN
	SET @SystemTypeID = (SELECT system_type_id FROM sys.types WHERE is_user_defined = 1 AND name = @Type)
	SET @SystemTypeName= (SELECT TOP(1)name FROM sys.types WHERE is_user_defined = 0 AND system_type_id = @SystemTypeID)
END	
ELSE
BEGIN
	IF Exists(SELECT * FROM sys.types WHERE is_user_defined = 0 AND name = @Type)
	BEGIN
		SET @SystemTypeName = (SELECT TOP(1)name FROM sys.types WHERE is_user_defined = 0 AND name = @Type)
	END
	else
	BEGIN
		SET @SystemTypeName = 'UnKnown Type'		
	END
END
		
SET @Result =  CASE lower(@SystemTypeName)
	WHEN 'image'			THEN '0x00'
	WHEN 'text'				THEN ''
	WHEN 'uniqueidentifier' THEN ''
	WHEN 'date'				THEN '1900-01-01 12:00:00.000'
	WHEN 'time'				THEN '00:00:00.000'
	WHEN 'datetime2'		THEN '9999-12-12'
	WHEN 'datetimeoffset'	THEN '1900-01-01 12:00:00.000'
	WHEN 'tinyint'			THEN '0'
	WHEN 'smallint'			THEN '0'
	WHEN 'int'				THEN '0'
	WHEN 'smalldatetime'	THEN '1900-01-01'
	WHEN 'real'				THEN '0'
	WHEN 'money'			THEN '0'
	WHEN 'datetime'			THEN '1900-01-01 12:00:00.000'
	WHEN 'float'			THEN '0'
	WHEN 'sql_variant'		THEN '0'
	WHEN 'ntext'			THEN ''
	WHEN 'bit'				THEN '0'
	WHEN 'decimal'			THEN '0'
	WHEN 'numeric'			THEN '0'
	WHEN 'smallmoney'		THEN '0'
	WHEN 'bigint'			THEN '0'
	WHEN 'varbinary'		THEN '0'
	WHEN 'varchar'			THEN ''
	WHEN 'binary'			THEN '0'
	WHEN 'char'				THEN ''
	WHEN 'timestamp'		THEN '1900-01-01 00:00:00.000'
	WHEN 'nvarchar'			THEN ''
	WHEN 'nchar'			THEN ''
	WHEN 'xml'				THEN ''
	WHEN 'sysname'			THEN ''
	WHEN 'unknown type'		THEN '0'
END

go
------------------------------------------------------------------------------------------
-- Copyright GetronicsWang Co., LLC 2000, 2001, 2002, 2003, 2005, 2006. All rights reserved.
------------------------------------------------------------------------------------------
Drop_old_proc 'List_Journal_Cash_Drawers'
GO
CREATE PROCEDURE dbo.List_Journal_Cash_Drawers 
  @bank BankID = 0
, @region RegionID = 0
, @branch BranchID = 0
, @teller OperatorID = ''
, @start_date SmallDate = NULL
, @end_date SmallDate = NULL
, @recursed_call bit = 0  -- used only for recursive call
, @debug bit = 0
, @IgnoreEmptyCashDrawer bit = 0
, @ForRecovery int = 0
, @IsArchiveJournal bit = 0
as 
-- Get Cash drawers and associated dbo.Tellers from Teller Journal 
--  according to variable criteria.
-- If bank parameter is null, region is ignored.
-- If Region parameter is null, branch is ignored.
-- Copyright 1999-2005 GetronicsWang Co., LLC.  All rights reserved.
-- Bodhi 30Oct01
-- 19SEP02 - recoded for better performance.
-- 03March04 - Allow for @Teller to be a User_Number
-- 16SEP05 Allow 255 as a valid bank or region.
-- 31Mar06 Procedure created dynamically to avoid systypes table scan. CR12894

/*
Modification Date:	31-01-2012
Developer:	Adel Shaban
Reason:	    Ignore journalled CashDrawers with value (-1)

ModificationDate: 12/2/2012
Developer: Adel Shaban
Reason Add parameter @ForRecovery

ModificationDate: 01/10/2018
Developer:		  Mohamed Elabd
Reason:			  Add parameter @IsArchiveJournal - KFH_ACM16030_Re-Print Old Voucher - CR# GFSY00720 
*/


set nocount on
declare @sql nvarchar(1600)
declare @where nvarchar(1100)
declare @param_list nvarchar(500) 
declare @user_number internal_user_ID
declare @start_year_month smallint, @end_year_month smallint
declare @viewName varchar(100)

if @recursed_call = 0 
--**CR12894 ** S
	and 0=1
--**CR12894 ** E
begin
	exec dbo.list_character_cash_drawers @bank  -- Sets up a recursive call.
                                  , @region
                                  , @branch
                                  , @teller
                                  , @start_date
                                  , @end_date
                                  , @debug
    RETURN @@error 
end

if @start_date is null
	set @start_date = dbo.SmallDateAdd('d', -7, dbo.smalldate_of(CURRENT_TIMESTAMP))
if dbo.datetime_of_smalldate(@start_date) < dbo.f_Teller_Base_date()
	set @start_date = dbo.smalldate_of(dbo.f_Teller_Base_date())
if @end_date is null 
	set @end_date = dbo.SmallDateAdd('d', +6, dbo.smalldate_of(CURRENT_TIMESTAMP))
if @start_date > @end_date begin
	raiserror('List_Journal_Cash_Drawers start_date > end_date', 16, 1)
	return -1
end
set @user_number = isnull(dbo.f_user_number_of_LoginID(@teller), 0)

set @where = dbo.generic_criteria(@bank, @region, @branch, @user_number, '')
if @where > '' 
	set @where = char(10)+ 'AND '+@where

set @start_year_month = dbo.YYMM_of_Smalldate(@start_date)
set @end_year_month = dbo.YYMM_of_Smalldate(@end_date)
 
IF @IsArchiveJournal = 1 
begin
	set @viewName = 'Globalfs_Archive.dbo.Archive_JOURNAL '
end
else
begin
	set @viewName = 'dbo.Journal '
end
	
 
set @sql = N'SET NOCOUNT ON
select distinct CashDrawer from ' + @viewName +
'WHERE year_month ' +  
case when @start_year_month = @end_year_month 
     THEN N'= '
     ELSE N'BETWEEN ' + cast(@start_year_month as varchar) + N' AND '
end
+ cast (@end_year_month as varchar) + N'
  and BusinessDate >= @start_date and BusinessDate < = @end_date
  and CashDrawer is NOT null '
  
if(@IgnoreEmptyCashDrawer = 1)
Begin
	set @sql = @sql + ' and CashDrawer <> -1 '
End
if(@ForRecovery = 1)
Begin
	set @sql = @sql+ ' and (HostTranStatus not in (100,2,112,114,115,116,117,118,119,120,121,122,123) Or HostTranStatus Is null) '
End
  	
set @param_list = N'@bank bankID, @region regionID, @branch branchID
, @user_number internal_user_ID 
, @start_date smalldate, @end_date smalldate'

set @sql = @sql + @where + N'
ORDER BY 1'

if @debug > 0 begin 
	print '-----------------------------------'
	print 'declare ' + @param_list + char(10) 
	print 'select  @bank = ' + cast(@bank as varchar)
	print '    , @region = ' + cast(@region as varchar)
	print '    , @branch = ' + cast(@branch as varchar)
	print '   , @user_number = ' + cast(@user_number as varchar)
	print '    , @start_date = ''' + cast(@start_date as varchar)+ ''''
	print '    , @end_date = '''+ cast(@end_date as varchar) + ''''
	print @sql 
end
set nocount OFF
exec dbo.sp_executesql @sql, @param_list
	, @bank, @region, @branch, @user_number, @start_date, @end_date

return @@error
GO
drop_old_proc 'dbo.SelectDrawerForService'
GO 
CREATE procedure dbo.SelectDrawerForService

@DrawerCode nvarchar(25)=''

as

/*

CreationDate:	28/1/2019
OriginalName:	dbo.SelectDrawerForService
Programmer:	Mahmoud saad

*/

BEGIN

	SELECT d.DrawerID, d.DrawerName, d.Currency AS DrawerCurrency, d.ExpiryDate AS DrawerExpiryDate, d.DrawerLimit AS DrawerLimit,
	 d.DrawerAmount, d.TotalAssignedAmount, d.UtilizedLimit AS DrawerUtilizedLimit, d.AvailableLimit AS DrawerAvailableLimit, 
	 d.PastDue, d.Remarks AS DrawerRemarks, d.AvailabiltyOfCBRBStatus, d.CommentsOnCBRBStatus,
	 d.CBRBStatusDate, d.Status AS DrawerStatus, d.DateOfDeactivation, d.StartDate AS DrawerStartDate, d.Tenor AS DrawerTenor,
	 d.Period AS DrawerPeriod, d.ModifiedDate ,
	 cd.CommitmentNo, cd.RimNo, cd.Currency  CommitmentDrawerCurrency, cd.DrawerLimit AS CommitmentDrawerLimit,
	 cd.DrawerLimitInAmount, cd.ExpiryDate AS CommitmentDrawerExpiryDate, cd.UtilizedLimit AS CommitmentDrawerUtilizedLimit,
	 cd.AvailableLimit AS CommitmentDrawerAvailableLimit, cd.FOLReferenceNo, cd.FOLDate, cd.Remark AS CommitmentDrawerRemark, 
	 cd.Status AS CommitmentDrawerStatus, cd.Tenor AS CommitmentDrawerTenor, cd.Period AS CommitmentDrawerPeriod, cd.StartDate AS CommitmentDrawerStartDate
   
   
	FROM Drawer d LEFT JOIN CommitmentDrawer  cd

	ON d.DrawerID = cd.DrawerID

	WHERE (@DrawerCode ='' OR  d.DrawerID=@DrawerCode)

END  

GO 
drop_old_proc 'dbo.UpdateDrawerBalances'
go
CREATE PROCEDURE dbo.UpdateDrawerBalances 
@commitmentNo nvarchar(12),



@drawerID varchar(25),



@chequeApprovedAmount decimal(21,6),
@option char ='c'
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2018-10-21
	Reason		: CBD_ACM15892_LBD Drawer
	
	Developer	: Mahmoud Saad
	Date		: 29/1/2019
	Reason		: CBD_ACM15892_LBD Drawer Web Service
    */
	if(LOWER( @option )='c')
		BEGIN
			UPDATE CommitmentDrawer
			SET UtilizedLimit = UtilizedLimit + @chequeApprovedAmount,
				AvailableLimit = AvailableLimit - @chequeApprovedAmount
			WHERE CommitmentNo=@commitmentNo AND DrawerID=@drawerID
			AND (Status='Active' OR Status='Blocked')
	
			UPDATE Drawer
			SET UtilizedLimit = UtilizedLimit + @chequeApprovedAmount,
				AvailableLimit = AvailableLimit - @chequeApprovedAmount
			WHERE DrawerID=@drawerID AND (Status='Active' OR Status='Blocked')
		END
	else 
		begin
			UPDATE CommitmentDrawer
			SET UtilizedLimit = UtilizedLimit - @chequeApprovedAmount,
				AvailableLimit = AvailableLimit + @chequeApprovedAmount
			WHERE CommitmentNo=@commitmentNo AND DrawerID=@drawerID
				AND (Status='Active' OR Status='Blocked')
	
			UPDATE Drawer
			SET UtilizedLimit = UtilizedLimit - @chequeApprovedAmount,
				AvailableLimit = AvailableLimit + @chequeApprovedAmount
			WHERE DrawerID=@drawerID AND (Status='Active' OR Status='Blocked')
		END

GO


drop_old_proc 'dbo.Get_DISC_Cheques'
go
  
CREATE procedure dbo.Get_DISC_Cheques        
   @Ref_No     ReferenceNumber ,                                    
   @Cheque_Status   varchar(10),                                    
   @BranchID varchar(12)      ,                                    
   @User_No      varchar(50),                                       
   @RimNo       varchar(10),                                  
   @BussDate  varchar(70) ,            
   @Track_No ReferenceNumber = null                           
as                                              
                                          
/*                                                  
CreationDate : 07-March-2013                                          
OriginalName : dbo.Get_DISC_Cheques                                               
Programmer   : Aya Mahmoud                    
Description  : Retrofit from CBD  
                      
Modifier :   Aya Mahmoud
Date   :     04-April-2013
Reason   :   Select the DCD.DraweeCustName instead if DiscCheques.CustomerName

Modifier :   May Hassan  
Date   :     27-October-2013  
Reason   :   Fixing Issue# GFSX05264 - Handling Empty String values for FirstName, Middle and LastName in Column 'TLR_USER_NAME_ARRAY'

Modifier :   May Hassan    
Date   :     20-April-2015    
Reason   :   Fixing Issue# GFSX08513 - Adding column 'TLR_PDC_REF_NO_ARRAY' for Loan Account RSM 

Modifier :   Nada Elshafie    
Date   :     03-June-2015    
Reason   :	Get DCD.Int_Amt as TLR_BILL_AMOUNT - GFSY00489

Modifier :   Mostafa Sayed
Date   :     [21/10/2018]		 
Reason   :	Get DCD.Int_Amt as TLR_BILL_AMOUNT and '' to set errors list - GFSY00489
*/                                    
                                    
 Set nocount on                                    
                                    
SELECT               
 '...' as A , ' ' as status , ' ' as COR_STATUS_ARRAY,              
 DiscCheques.Rim_No as TLR_RIM_BRANCH_ARR ,              
 DCD.DraweeCustName as TLR_DRAWERS_NAME   ,                    
 DCD.Ref_No as TLR_IR_MsgRefNo_Array,                               
 DCD.ChequeNo as TLR_PDC_CHEQUE_NUMBER,                              
 DCD.ChequeAmount as TLR_PDC_CHEQUE_AMOUNT,                              
 DCD.ChequeApprovedAmount as TLR_IR_CrAmount_GL_Arr,                               
 DiscCheques.ChequeCurrency as TLR_PDC_CHEQUE_CURRENCY,                              
 CASE OP.FirstName WHEN '' THEN '' ELSE OP.FirstName+' ' END + CASE OP.Middle WHEN '' THEN '' ELSE OP.Middle+' ' END + OP.LastName as TLR_USER_NAME_ARRAY,                        
 DiscCheques.BranchID as TLR_PDC_CLEAR_BRANCH_CODE,                               
 DCD.SendDate as TLR_PDC_SEND_DATE ,                              
 DCD.Track_No as TLR_CR_MODE_OF_PAYMENT,                           
 DCD.ReturnReason as TLR_PDC_COR_ID,                    
 DCD.OtherReturnReason as TLR_PDC_COR_DIRECT_OPT_DSC,                          
 --------------- Params. For TPI                            
 DCD.InterestAmount as TLR_IR_DrExchangeRate_GL_Arr ,                                
 DiscCheques.RSM_ID as TLR_PDC_DRAWER_ACCOUNT_NUMBER ,                          
                           
 DiscCheques.LoanAccountType as TLR_PDC_DR_AC_TYPE,                                 
 DiscCheques.AccountType as TLR_PDC_COL_ACCT_TYPE ,                            
 DiscCheques.LoanClassCode  as TLR_CHEQUE_BOOK_ID_ARRAY ,                            
 DiscCheques.TotalApprovedChequeAmount as TLR_PDC_CHEQUE_AMOUNT_VC,                               
 DCD.MATURITYDate as TLR_SC_Cheque_DATE_ARR,                            
 DiscCheques.CommitmentNumber as TLR_PDC_DR_AC_NUMBER,               
 DiscCheques.CommitmentType as TLR_PDC_PDC_ACCT_APPLI_TYPE,                            
 DCD.CommissionAmount as TLR_TOTAL_CHARGES_ARRAY,                        
 DCD.CommissionDescription as TLR_ExpenseType,                             
 DiscCheques.AccountNumber as TLR_PDC_CHG_AC_NUMBER,                            
 DCD.InterestAmount  as TLR_IR_DrAmount_Array,                      
 DCD.ChequeAmount - DCD.ChequeApprovedAmount as TLR_CHEQUE_AMT_ARR  ,                       
 case when DCD.loanaccountnumber is null then '0' when DCD.loanaccountnumber = '' then '0' else DCD.loanaccountnumber end as TLR_IR_DrAccountNo_Array ,                       
 DCD.Instruction ,                    
 OP.EmployeeID as TLR_INSTALLMENT_TYPE_ARRAY,                      
 DCD. ChequeDate as TLR_PDC_CHEQUE_DATE,                      
 DCD. DestBankAccount as TLR_PDC_DEST_BK_ACCT,                    
 DCD. DestBankAddress1 as TLR_PDC_DEST_ADDRESS1,                      
 DCD. DestBankAddress2 as TLR_PDC_DEST_ADDRESS2,                      
 DCD. DestBankCountry as TLR_PDC_DEST_BK_COUNTRY,                      
 DCD. DestBankDetails as TLR_PDC_DEST_DETAILS,                      
 DCD. DestBankInst as TLR_PDC_DEST_INSTRUCTIONS,                      
 DCD. DestBankName as TLR_PDC_DEST_BK_NAME,                      
 DCD. DirectOption as TLR_PDC_COR_DIRECT_OPT,                      
 DCD. CorrespondentCountry as TLR_ConsDet_CorresAdrs_ln3,                      
 DCD. CorrespondentCity as TLR_PDC_COR_CITY,                      
 DCD. IBCNumber as TLR_CORR_BANK_ARRAY,                      
 DCD. CorrespondantBankID as TLR_PDC_COR_NAME,                      
 DCD. DraweeBankID as TLR_PDC_CLEAR_BANK_CODE,                      
 DCD. DraweeBankName as TLR_PDC_CLEAR_BANK_NAME,                      
 DCD. DraweeBranchName as TLR_PDC_CLEAR_BRANCH_NAME,                      
 DCD. DrAccount as TLR_ConsDet_AccountNo,                      
 DCD. DrAccountCur as TLR_PDC_DR_AC_CUR,                      
 DCD. DrAccountType as TLR_OTHER_ACCT_TYPE_ARRAY,                       
 DCD. DraweeCustName as TLR_ConsDet_CorresAdrs_ln2,                      
 DCD. DraweeAcctNo as TLR_ConsDet_CorresAdrs_ln1,                      
 DCD. InterestAmount as Net_CR_AMT_LOCAL_ARRAY,                      
 DCD. LoanAccountNumber as TLR_IR_CrAccountNo_DP_Arr,                      
 DCD. IsExceptionCheque as TLR_SELECTION   ,              
 DiscCheques.AccountBranch as TLR_ConsDet_AccountType,            
 DCD. ChequeStatus,            
 IsCommissionChanged as TLR_SETTLE_ON_CURRENCY_ARRAY,            
 DCD.routingnumber as  TLR_CORR_BANK_COUNT_ARR  ,          
 datediff(day,@BussDate, DCD.maturitydate ) as TLR_PDC_TYPE_STATUS_ID,          
        dcd.IsInterestChanged as TLR_ICL_Overdraft_Arr,          
 dcd.LateFees as TLR_TOTAL_CHARGES_ARRAY2,          
 dcd.LateFees - dcd.InterestAmount as originalFees,
 ' ' as TLR_PDC_REF_NO_ARRAY ,
 DCD.Int_Amt as TLR_BILL_AMOUNT,
 DR.DrawerID as TLR_ACCT_OFFICER_ARRAY, 
 DR.DrawerName as TLR_COLL_BANK_SETT_INST,
 '' as TLR_Description_ARRAY,
 LPM.EnableCommitmentDrawers as TLR_RECEPIT_STATUS_ARRAY,
 DR.PastDue as PastDue
FROM        DiscChequesDetail as DCD           
   INNER JOIN  DiscCheques           
    ON  DCD.Track_No = DiscCheques.Track_No                      
          
   INNER JOIN Operator OP           
    ON  DCD.User_Number = OP.User_Number  
    
    INNER JOIN LoanProductMap LPM
    on LPM.Acct_Type = DiscCheques.LoanAccountType
   
   LEFT JOIN Drawer DR
   ON DR.DrawerID = DCD.DrawerCode
          
WHERE  (ChequeAmount <> 0  )            
   AND  (DCD.ChequeStatus <> 1)           
   AND  (DCD.ChequeStatus <> 2)                
   AND          
     (@BranchID   is  null or DiscCheques.BranchID = @BranchID) and                 
     (@User_No   is  null or DCD.User_Number   = @User_No)  and                
     (@RimNo    is  null or DiscCheques.Rim_No  = @RimNo)  and                 
     (@Ref_No   is  null or DiscCheques.Ref_No  = @Ref_No)  and                
     (@BussDate   is  null or DCD.MATURITYDate  >=@BussDate) and                
     (@Track_No   is  null or DCD.Track_No =@Track_No) and                 
     (                
     (ChequeStatus =@Cheque_Status  and ChequeStatus is not null) or                 
     (@Cheque_Status  is  null  and ChequeStatus  < 5 )                 
     )   
go

drop_old_proc 'HCS_AddChqBetweenBranches'
GO
CREATE PROCEDURE HCS_AddChqBetweenBranches    
(    
	  @dt AS AddChqbooks READONLY
)    
AS    
--HCS_AddChqBetweenBranches  '14943','14943',  '14943',1,1,1,1,'',1  
/*   
 CreationDate :15-01-2018    
 Programmer   : Abdelrhman Mohamed   
 Description  : KIB_ACM16784_Transfer Cheque Book From Branch To Branch  
*/     
BEGIN    
insert into ChqBookMovementBetweenBranches(   
            
           ChequeBookReference
           ,AccountNumber  
           ,RIMNumber  
           ,PostingBranch  
           ,TellerNumber  
           ,ToBranch  
           ,FromBranch  
           ,PostingDate  
           ,MovementType)  
select 

            
            [@dt].[ChequeBookReference]  
           , [@dt].[AccountNumber]   
           , [@dt].[RIMNumber]    
           , [@dt].[PostingBranch]    
           , [@dt].[TellerNumber]    
           , [@dt].[ToBranch]   
           , [@dt].[FromBranch]   
           , [@dt].[PostingDate]
           , [@dt].[MovementType]
        from   
        @dt
  
if @@ERROR <> 0  
 return 0  
else  
 return 1   
END
go

drop_old_proc 'HCS_ListChqBetweenBranches'
GO  
CREATE PROCEDURE HCS_ListChqBetweenBranches  

AS  
--HCS_ListChqBetweenBranches 
/* 
 CreationDate :17-01-2018  
 Programmer   : Abdelrhman Mohamed 
 Description  : KIB_ACM16784_Transfer Cheque Book From Branch To Branch
*/   
BEGIN  
select  
          ChequeBookReference
           ,AccountNumber
           ,RIMNumber
           ,PostingBranch
           ,TellerNumber
           ,ToBranch
           ,FromBranch
           ,PostingDate
           ,MovementType
           ,LastChanged
from dbo.ChqBookMovementBetweenBranches 

END
go
drop_old_proc 'HCS_UpdateChqBetweenBranches'
GO
CREATE PROCEDURE HCS_UpdateChqBetweenBranches    
(                          
 @ID int,                          
 @movementType int ,
 @fromBranch int ,
 @toBranch int ,
 @Updator varchar (40)
)    
AS    
--HCS_UpdateChqBetweenBranches  '14943','14943',  '14943',1,1,1,1,'',1  
/*   
 CreationDate :15-01-2018    
 Programmer   : Abdelrhman Mohamed   
 Description  : KIB_ACM16784_Transfer Cheque Book From Branch To Branch  
*/     
BEGIN    

Update ChqBookMovementBetweenBranches  set MovementType =@movementType , FromBranch=@fromBranch , ToBranch=@toBranch  , Updator =  @Updator ,LastChanged = GETDATE()  where ChequeBookReference=@ID

  
if @@ERROR <> 0  
 return 0  
else  
 return 1   
END    
go


Drop_old_proc 'dbo.CheckSICCode'  
go

CREATE  procedure dbo.CheckSICCode     --CheckSICCode 2,1
@BranchID  int = null,
@SICCodeID int =null
As    
/*    
CreationDate: 2018-11-11    
OriginalName: dbo.CheckSICCode   
Programmer: Nehal Ramadan  
Description: Check SIC Code Existence
*/    
set nocount on    

declare @result int  
CREATE TABLE #TempTable(
 SICCode int,
 BranchID int)
 
INSERT INTO #TempTable (SICCode, BranchID) 
select SCD.SICCode  as SICCode ,SCR.BranchID as   BranchID from  dbo.SICCodeRestriction as SCR  
				 inner join  dbo.SICCodeCategoryDetails as SCD
				on SCD.SICCodeCategoryID=SCR.SICCodeCategoryID

if exists (select SICCode from   #TempTable where SICCode=@SICCodeID )
Begin
	if exists (select SICCode from   #TempTable where SICCode=@SICCodeID and  BranchID=@BranchID)
		Begin
			set @result =1;  -- pass no validation
		End
	Else
		begin
			set @result =0;  --stop transaction
		End
End
Else
Begin
	set @result =1;  -- pass no validation
End

Drop TABLE #TempTable

if @@error<>0    
begin     
 select -1    
end    
else    
begin       
 select @result    
end    

Go


Drop_old_proc 'Delete_SICCodeCategory'
go

CREATE  procedure dbo.Delete_SICCodeCategory    
  @id int    
as    
    
/*    
CreationDate: 2018-11-8  
OriginalName: dbo.Delete_SICCodeCategory    
Programmer: Nehal Ramadan   
Description: delete from SICCodeCategory table     
  if it doesn't have any records in     
  SICCodeRestriction table    
    
    
*/    
    
set nocount on    
declare @result int    
begin tran    
if  not exists(select SCR.SICCodeCategoryID from dbo.SICCodeRestriction as SCR where SCR.SICCodeCategoryID = @id)    
begin    
 Delete dbo.SICCodeCategoryDetails where SICCodeCategoryID=@id    
 Delete dbo.SICCodeCategory where SICCodeCategoryID=@id    
 set @result =0;    
end    
else    
 set @result =1;    
if @@error<>0    
begin    
 rollback tran    
 return -1    
end    
else    
begin    
 commit tran    
 return @result    
end    
go
    
Drop_old_proc 'Insert_SICCodeCategory'
go
    
CREATE  procedure dbo.Insert_SICCodeCategory    
 @name varchar (50),    
 @Updator OperatorID    
     
as    
    
/*    
CreationDate: 2018-11-8    
OriginalName: dbo.Insert_SICCodeCategory    
Programmer: Nehal Ramadan  
Description: Insert new record in the dbo.SICCodeCategory   table    
Output:  The new Category ID    
Assumption:     
*/    
    
set nocount on    
    
declare @id int    
declare @Result int    
begin tran    
set @id = (select isnull(max(SC.SICCodeCategoryID), 0)+1 from dbo.SICCodeCategory as SC)    
    
if not exists (select SC.SICCodeCategoryID from dbo.SICCodeCategory as SC where SC.SICCodeCategoryName = @name )    
begin    
 insert into dbo.SICCodeCategory(   
 SICCodeCategoryID,    
  SICCodeCategoryName,    
  Creator)     
 select @id,    
  @name,    
  @Updator    
    
 set @Result=@id    
end    
else    
 set @Result=-2    
   
if @@error<>0    
begin    
 rollback tran    
 return -1    
end    
else    
begin    
 commit tran    
 return @Result    
end    
Go
DROP_OLD_PROC 'dbo.Insert_SICCodeCategoryDetail'
GO
Create proc [dbo].[Insert_SICCodeCategoryDetail]                                                                          
 @SICCodeCatgoryID int,    
 @SICCategoryDetails [T_SICCodeCategoryDetail] readonly    
 As                                            
                               
/*                                            
 CreationDate: 11-11-2018    
 OriginalName: dbo.Insert_SICCodeCategoryDetail      
 Creator  : Nehal Ramadan    
 Resone      : GFSY00735    
 Description : insert PM_SICCodeCategoryDetails table    
                           
     
*/                                            
                 
    
          
                              
Begin Transaction Update_SICCodeCategoryDetail                                      
      
delete from  SICCodeCategoryDetails   where SICCodeCategoryID=@SICCodeCatgoryID             
    
select  @SICCodeCatgoryID as  SICCodeCatgoryID,SICCode as SICCode into #tempTable     
from @SICCategoryDetails        
    
INSERT INTO SICCodeCategoryDetails   (SICCodeCategoryID,SICCode)      
SELECT #tempTable.SICCodeCatgoryID ,#tempTable.SICCode    
FROM #tempTable        
      
                 
IF @@error <> 0 BEGIN                                      
                                  
ROLLBACK TRANSACTION Update_SICCodeCategoryDetail                                      
                                  
PRINT N'An Error Occured While Insert_SICCodeCategoryDetail'                                      
                                  
RETURN -1                                
                                  
END ELSE                                
BEGIN                                
COMMIT TRANSACTION Update_SICCodeCategoryDetail                              
RETURN 0                                
END 
 
go
DROP_OLD_PROC 'dbo.Insert_SICCodeRestriction'
GO
Create proc [dbo].[Insert_SICCodeRestriction]                                                                      
 @SICCodeCatgoryID int,
 @Branches [T_Branches] readonly
 As                                        
                           
/*                                        
 CreationDate: 11-11-2018
 OriginalName: dbo.Insert_SICCodeRestriction 
 Creator	 : Nehal Ramadan
 Resone      : GFSY00735
 Description : Insert SICCodeRestriction table
                       
 
*/                                        
             

      
                          
Begin Transaction Update_SICCodeRestriction                                 
  
delete from  SICCodeRestriction   where SICCodeCategoryID=@SICCodeCatgoryID         

select  @SICCodeCatgoryID as  SICCodeCatgoryID,BranchID as BranchID into #tempTable 
from @Branches    

INSERT INTO SICCodeRestriction   (SICCodeCategoryID,BranchID)    
SELECT #tempTable.SICCodeCatgoryID ,#tempTable.BranchID
FROM #tempTable    
  
             
IF @@error <> 0 BEGIN                                  
                              
ROLLBACK TRANSACTION Update_SICCodeRestriction                                  
                              
PRINT N'An Error Occured While Insert_SICCodeRestriction '                                  
                              
RETURN -1                            
                              
END ELSE                            
BEGIN                            
COMMIT TRANSACTION Update_SICCodeRestriction                          
RETURN 0                            
END 
 Go
drop_old_proc 'dbo.Select_SICCodeCategory'  
go
CREATE  procedure dbo.Select_SICCodeCategory  
   
as  
  
/*  
CreationDate: 2018-11-15  
OriginalName: dbo.Select_SICCodeCategory  
Programmer: Nehal Ramadan 
Description: Select all from table AccountClassCategory  
*/  
  
set nocount on  
  
select SC.SICCodeCategoryID,SC.SICCodeCategoryName from dbo.SICCodeCategory as SC order by 1  
  
go
  
  
go
Drop_old_proc 'dbo.Select_SICCodeCategoryDetail'  
go

  
CREATE  procedure dbo.Select_SICCodeCategoryDetail     
@id int     
As    
/*    
CreationDate: 2018-11-11    
OriginalName: dbo.Select_AccountClassCategoryDetail    
Programmer: Nehal Ramadan  
Description: Select SiC Code of specific sic code category  
  
*/    
set nocount on    
select  SCD.SICCode    
from  dbo.SICCodeCategoryDetails as SCD    
where  SCD.SICCodeCategoryID = @id    

go
go
Drop_old_proc 'dbo.Select_SICCodeRestriction'  
go

  
CREATE  procedure dbo.Select_SICCodeRestriction     
@SICCategoryID int =null,
@SICBranchID int = null    
As    
/*    
CreationDate: 2018-11-11    
OriginalName: dbo.Select_SICCodeRestriction    
Programmer: Nehal Ramadan  
Description: Select branches of SIC Code Category 
*/    
set nocount on    
select  SCR.BranchID  as   BranchID,b.Name as BranchName
from  dbo.SICCodeRestriction as SCR 
inner join  dbo.Branch as b
on b.Branch=SCR.BranchID
where  (SCR.SICCodeCategoryID = @SICCategoryID  or @SICCategoryID  is null)    
		and (SCR.BranchID = @SICBranchID  or @SICBranchID  is null)  

go

drop_old_proc 'dbo.Update_SICCodeCategory'
go
  
   
create  procedure dbo.Update_SICCodeCategory    
 @id int,    
 @name varchar (30),    
 @Updator OperatorID    
     
as    
    
/*    
CreationDate: 2018-11-15    
OriginalName: dbo.Update_SICCodeCategory    
Programmer: Nehal Ramadan  
Description: Update  category name record in the  SICCodeCategory   table    
    
*/    
    
set nocount on    
declare @Result int    
begin tran    
if not exists (select SICCat.SICCodeCategoryID from dbo.SICCodeCategory as SICCat where SICCat.SICCodeCategoryName = @name )    
begin    
 update dbo.SICCodeCategory    
 set   SICCodeCategoryName = @name,    
  Updator=@Updator    
 where SICCodeCategoryID = @id    
 set @Result=0    
end    
else    
 set @Result=1    
if @@error<>0    
begin    
 rollback tran    
 return -1    
end    
else    
begin    
 commit tran    
 return @Result    
end  
go
  
  
USE [Globalfs]
GO

drop_old_proc 'dbo.GetClearDetailData'
go
CREATE PROCEDURE dbo.GetClearDetailData
@BatchRefNo varchar(3000),
@TranName varchar(100),
@FieldName varchar(100),
@BussinessDate Date
AS

/*
CreationDate: 14/2/2019     
OriginalName: dbo.GetClearDetailData
Programmer	: Mahmoud saad
Description	: get value date data from clear detail table converting package 'Update_ClearDetail_valueDate.dtsx' to service      

*/

	BEGIN

		CREATE TABLE #RefNoTable(id int,RefNo varchar(30))

		INSERT INTO #RefNoTable EXEC dbo.StringSplit @BatchRefNo,','

		select ID AS 'ID',Value AS 'VALUEDAYS',BatchReferenceNo AS 'BATCHREFERENCENO',@BussinessDate as 'ValueDate'
		from cleardetail cd inner join RulesTranFldParam rfp on (cd.Routing_No = rfp.Param) 
		where BatchReferenceNo in (SELECT RefNo FROM #RefNoTable ) and rfp.TranName = @TranName and FieldName = @FieldName

		DROP table #RefNoTable
	END
GO

--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Update_IR_status
Go

CREATE	proc dbo.Update_IR_status
	@STATUSID		INT,
	@MsgRefNo		ReferenceNumber,
	@LockedByID		OperatorID,
	@BeneficiaryAmount	decimal(21,6),
	@BeneficiaryCurrency	CurrencyType,
	@BeneficiarySellRate	decimal(21,6),
	@BeneficiaryBuyRate	decimal(21,6),
	@BeneficiaryGTDTicket	varchar(20),
	@BeneficiaryName	varchar(40),
	@BeneficiaryIDType	varchar(50),
	@BeneficiaryIDNumber	varchar(50),
	@BeneficiaryPhone	varchar(20),
	@BeneficiaryAddress	varchar(255),
	@BeneficiaryNarrative	varchar(80)
as
/*
	BY	:	Ahmed Fahim
	Date	:	2005-07-10
	Reason	:	Used To update the status of a specific IR


ModifiedDate:   25 January 2009
Modifer		:	Hany A Hassan	   
ModifyReason:   Change the Data Type of @MsgRefNo to ReferenceNumber 

ModifiedDate:   05-04-2017  
Modifer  : 		Mahmoud Kamel      
ModifyReason:   FIB Issue#GFSX11953 - column LockedByID always has value null, therefore we will comment it

ModifiedDate:   07-02-2019  
Modifer  : 		MAhmoud Saad      
ModifyReason:    Issue #GFSX13516 - Prevent updating message if it is already posted
*/

set nocount on

UPDATE	IR
SET	STATUSID = @STATUSID , 
	LockedByID = null,
	BeneficiaryAmount = @BeneficiaryAmount,
	BeneficiaryCurrency = @BeneficiaryCurrency,
	BeneficiarySellRate = @BeneficiarySellRate,
	BeneficiaryBuyRate = @BeneficiaryBuyRate,
	BeneficiaryGTDTicket = @BeneficiaryGTDTicket,
	BeneficiaryName = @BeneficiaryName,
	BeneficiaryIDType = @BeneficiaryIDType,
	BeneficiaryIDNumber = @BeneficiaryIDNumber,
	BeneficiaryPhone = @BeneficiaryPhone,
	BeneficiaryAddress = @BeneficiaryAddress,
	BeneficiaryNarrative = @BeneficiaryNarrative
WHERE	MsgRefNo = @MsgRefNo
--ITS Code Start [Mahmoud Kamel - 2017/04/05] FIB Issue#GFSX11953 - column LockedByID always has value null, therefore we will comment it
--AND LockedByID = @LockedByID  
AND (LockedByID = @LockedByID OR LockedByID IS NULL)

AND StatusID <> 8
--ITS Code End [Mahmoud Kamel - 2017/04/05] FIB Issue#GFSX11953 - column LockedByID always has value null, therefore we will comment it

set nocount off

Go
--End of Automatic Generation

drop_old_proc 'dbo.UpdateValueDate'
GO
CREATE PROCEDURE UpdateValueDate(

	@dt AS ClearDetailValueDateType READONLY

)

AS

/*
 CreationDate : 14/2/2019    
 Programmer   : Mahmoud Saad
 Description  : ConvertPackage to service Update_ClearDetail_valueDate.dtsx                            
*/ 

BEGIN 

	UPDATE ClearDetail  

	SET ClearDetail.ValueDate=ClearDetailGFS.ValueDate

	FROM ClearDetail INNER JOIN @dt AS ClearDetailGFS

	ON ClearDetail.ID = ClearDetailGFS.ID

	WHERE ((ClearDetail.BatchReferenceNo=ClearDetailGFS.BatchReferenceNo) OR ClearDetail.BatchReferenceNo IS NULL)

END
GO 
go
Drop_old_proc 'dbo.Select_SICCodeRestriction'  
go

  
CREATE  procedure dbo.Select_SICCodeRestriction     
@SICCategoryID int =null,
@SICBranchID int = null    
As    
/*    
CreationDate: 2018-11-11    
OriginalName: dbo.Select_SICCodeRestriction    
Programmer: Nehal Ramadan  
Description: Select branches of SIC Code Category 
*/    
set nocount on    
select  SCR.BranchID  as   BranchID,cast(SCR.BranchID as varchar) + ' - ' + b.Name as BranchName
from  dbo.SICCodeRestriction as SCR 
inner join  dbo.Branch as b
on b.Branch=SCR.BranchID
where  (SCR.SICCodeCategoryID = @SICCategoryID  or @SICCategoryID  is null)    
		and (SCR.BranchID = @SICBranchID  or @SICBranchID  is null)  

go

drop_old_proc 'dbo.select_FieldID'
go
CREATE   procedure dbo.select_FieldID  -- select_FieldID 'Amount'  
@FieldName nvarchar(300)  
As    
    
/*     
--Name			:   dbo.select_FieldID        
--Programmer	:	Ahmed Osman
--Date			:	[11/02/2019]		
--Reason		:	CR#GFSY00747 - CBD_ACM16557_Emirates ID Expiry Date
*/    
   
SELECT FieldID FROM RulesDBField WHERE Name = @FieldName
GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc select_TranValidation
Go

CREATE   procedure dbo.select_TranValidation
@TranName TransactionName
As

/* 
name: 		dbo.select_TranValidation    
developer: 	Hany A Hassan   
reason: 	Retrofitting from CBD - To select all validations bound to the incoming transaction name
data:		4 January 2009

Modifier: 	Nada Elshafie   
reason: 	GFSY00642 - Add Transaction Mode to validation, D-DataCollect .. R-Reverse .. B-Both
data:		7 May 2017 

Modifier	:  Ahmed Osman
reason		:  CR#GFSY00747 - CBD_ACM16557_Emirates ID Expiry Date , Get Column ResultDummyField
data		:  11/02/2019   
*/

select 
RulesTranValidations.Id,
RulesTranValidations.TranId,
RulesTranValidations.Seq,
RulesTranValidations.ValidationActionId,
RulesTranValidations.AlertMsg,
RulesTranValidations.RequiredFieldId,
RulesTranValidations.TransactionMode,
RulesTranValidations.ControlField,
RulesTranValidations.ResultField

from RulesTranValidations
inner join RulesTranName
on RulesTranValidations.TranId = RulesTranName.TranId

where RulesTranName.TransactionName = @TranName


Go
--End of Automatic Generation
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc select_ValidationCondition
Go

CREATE   procedure dbo.select_ValidationCondition
@RulesTranValidationId int
As

/* 
name: 		dbo.select_ValidationCondition    
developer: 	Hany A HAssan   
reason: 	Retrofitting from CBD - To select all validations actions related to the incoming tran validation id
data:		4 January 2009 

Modifier: Nada Elshafie
Reason: GFSY00642 - Add Column DBAccessID - WebServiceName - WebServiceMethod
Date: 18 April 2017

Modifier	:  Ahmed Osman
reason		:  CR#GFSY00747 - CBD_ACM16557_Emirates ID Expiry Date , Get Column ResultDummyField
data		:  11/02/2019   
*/

select 
Id,
Seq,
OperandsDataType,
Operand1,
Operator,
Operand2,
LogicalOperator,
DBAccessID,
WebServiceName,
WebServiceMethod,
RulesTranValidationId,
ArrayIndex1,
ArrayIndex2
 
from ValidationsConditions

where RulesTranValidationId = @RulesTranValidationId


Go
--End of Automatic Generation
 Drop_old_proc GetConditionalOperator
GO
 create  procedure dbo.GetConditionalOperator    
AS                                
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetConditionalOperator                                
Programmer: Mostafa Helmy                                
Description: Get Conditional Operator   #GFSY00754   
*/                      
  
If Exists(Select * From ConditionalOperator)   
Begin  
 Select Id,conditional_operator_name From ConditionalOperator   
End  
go
 Drop_old_proc GetCustomFields
GO
 create  procedure dbo.GetCustomFields      
AS                                
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetCustomFields                                
Programmer: Mostafa Helmy                                
Description: Get CUstom Fields || CR#GFSY0051 - ID Expiry Date       
*/                      
  
If Exists(Select * From TransactionValidationCustomField)   
BEGIN  
 SELECT distinct CustomObject,Property FROM TransactionValidationCustomField   
End 
go
 Drop_old_proc GetCustomObjects
GO
 create  procedure dbo.GetCustomObjects      
AS                                
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetCustomObjects                                
Programmer: Mostafa Helmy                                
Description: Get Custom Objects || CR#GFSY0054 - ID Expiry Date       
*/                      
  
If Exists(Select * From TransactionValidationCustomField)   
BEGIN  
  SELECT distinct CustomObject,CustomObject FROM TransactionValidationCustomField 
End 


 go
 Drop_old_proc GetOperandDataType
GO
 create  procedure dbo.GetOperandDataType      
AS                                
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetOperandDataType                                
Programmer: Mostafa Helmy                                
Description: Get Operand DataType || CR#GFSY00754 - ID Expiry Date       
*/                      
  
If Exists(Select * From OperandDataType)   
BEGIN  
 SELECT Id,data_type FROM OperandDataType   
End  
  go
 
Drop_old_proc GetSqlParam
GO
 Create  procedure [dbo].[GetSqlParam]  
 
AS                              
/*                              
CreationDate: 17-03-2019                    
OriginalName: dbo.GetSqlParam                              
Programmer: Mostafa Helmy                              
Description: Get SQL params for Transaction Validation configuration #GFSY00754   
*/                    

If Exists(select * from dbo.ValidationsConditionsSQLParams)	
Begin
 Select DBAccessID,ParamSeq,ParamName,ParamValue,DataType,'Old' as RecordType,'' as ValidationNumber  From ValidationsConditionsSQLParams 
End
go
Drop_old_proc GetTranFields
GO
create  Proc dbo.GetTranFields   
@TranID  int                    
as                  
/*  
 CreationDate : 18-03-2019   
 OriginalName : dbo.GetSqlParam       
 Programmer   : Mostafa Helmy  
 Description  : Get Fileds that attached on specify transaction based on datatype CR#GFSY00754  
*/     
  
SELECT DISTINCT RDBF.FieldID, RDBF.Name, RD.[Descriptor] , RDBF.DataType , 'ScalerField' as FieldType  
 FROM RulesHeaderFields RHF INNER JOIN RulesTranName RTN   
  ON RHF.HeaderID = RTN.HeaderID  
 INNER JOIN RulesTranField RTF  
  ON RTN.TranID = RTF.TranID   
 INNER JOIN RulesDBField RDBF  
  ON RTF.FieldID = RDBF.FieldID OR RHF.FieldID = RDBF.FieldID  
 LEFT JOIN RulesTranField_ex RTF_EX  
  ON RTN.TranID = RTF_EX.TranID AND RDBF.FieldID = RTF_EX.FieldID  
 LEFT JOIN RulesDescriptor RD  
  ON TranFieldDescr COLLATE SQL_Latin1_General_CP1_CS_AS = RD.Name  
   WHERE RTN.TranID = @TranID AND RDBF.TargetTable IS NOT NULL AND RDBF.TargetTable = 1 AND RDBF.MaxArrayIndex = 0  
     
UNION  
  
SELECT DISTINCT RDBF.FieldID, RDBF.Name, RD.[Descriptor] , RDBF.DataType , 'ArrayField' as FieldType  
 FROM RulesHeaderFields RHF INNER JOIN RulesTranName RTN   
  ON RHF.HeaderID = RTN.HeaderID  
 INNER JOIN RulesTranField RTF  
  ON RTN.TranID = RTF.TranID   
 INNER JOIN RulesDBField RDBF  
  ON RTF.FieldID = RDBF.FieldID OR RHF.FieldID = RDBF.FieldID  
 LEFT JOIN RulesTranField_ex RTF_EX  
  ON RTN.TranID = RTF_EX.TranID AND RDBF.FieldID = RTF_EX.FieldID  
 LEFT JOIN RulesDescriptor RD  
  ON TranFieldDescr COLLATE SQL_Latin1_General_CP1_CS_AS = RD.Name  
   WHERE RTN.TranID = @TranID AND RDBF.TargetTable IS NOT NULL AND RDBF.TargetTable > 1 AND RDBF.MaxArrayIndex > 0  
   ORDER BY RDBF.FieldID ASC  
  
  
 go

 
 Drop_old_proc GetWebServiceNameAndMethod
GO
 create  procedure dbo.GetWebServiceNameAndMethod      
AS                                
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetWebServiceNameAndMethod                                
Programmer: Mostafa Helmy                                
Description: Get Web Service Name And its methods || CR#GFSY0054 - ID Expiry Date       
*/                      
  
If Exists(Select * From ExternalWebServiceMethods)   
BEGIN  
 SELECT distinct WebServiceName,Methods FROM ExternalWebServiceMethods   
End 
go
 Drop_old_proc GetWebServiceNames
GO
 create  procedure dbo.GetWebServiceNames      
AS                                
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetWebServiceNames                               
Programmer: Mostafa Helmy                                
Description: Get Web Service Names || CR#GFSY0054 - ID Expiry Date       
*/                      
  
If Exists(Select * From ExternalWebService)   
BEGIN  
 SELECT distinct WebServiceName,WebServiceName FROM ExternalWebService   
End 
go
drop_old_proc 'SaveTranValidationAndValidationCondition'
go
CREATE   procedure dbo.SaveTranValidationAndValidationCondition  
@id INT,
@tranId INT,
@seq INT,
@validationActionId INT,
@alertMsg VARCHAR(MAX),
@requiredFieldId INT,
@transactionMode CHAR,
@controlField VARCHAR(MAX),
@resultField VARCHAR(MAX),
@recordType VARCHAR(MAX),
@tranValidationConditionsDT TransactionValidationConditionsDT READONLY
As  
  
/*   
name		:  dbo.SaveTranValidationAndValidationCondition      
developer	:  Ahmed Osman
reason		:  CR#GFSY00754 - CBD_ACM16557_Emirates ID Expiry Date
date		:  31/03/2019   
*/  

IF(@recordType <> 'Deleted')
	BEGIN  
		IF(@id <> -1)	-- Update 	
			BEGIN
				UPDATE RulesTranValidations 
				SET 
					Seq = @seq, 
					ValidationActionId = @validationActionId,
					AlertMsg = @alertMsg,
					RequiredFieldId = @requiredFieldId,
					TransactionMode = @transactionMode,
					ControlField = @controlField,
					ResultField = @resultField
				WHERE Id = @id
			END
		ELSE	-- New
			BEGIN
				SELECT @id = MAX(Id) + 1 FROM RulesTranValidations
				
				INSERT INTO RulesTranValidations(Id,TranId,Seq,ValidationActionId,AlertMsg,RequiredFieldId,TransactionMode,ControlField,ResultField)
				VALUES (@id,@tranId,@seq,@validationActionId,@alertMsg,@requiredFieldId,@transactionMode,@controlField,@resultField)
			END

		IF(@id <> -1)
			BEGIN
				SELECT * INTO #ValidationConditionsTemp FROM @tranValidationConditionsDT
				
				DECLARE @validationConditionID INT, @VC_Seq INT, @OperandsDataType INT, @DBAccessID INT, @ArrayIndex1 INT, @ArrayIndex2 INT, @RowId INT
				DECLARE @Operand1 VARCHAR(MAX), @Operator VARCHAR(MAX), @Operand2 VARCHAR(MAX), @LogicalOperator VARCHAR(MAX), @WebServiceName VARCHAR(MAX), @WebServiceMethod VARCHAR(MAX), @CondtionRecordType VARCHAR(MAX)
				
				WHILE (SELECT Count(*) FROM #ValidationConditionsTemp) > 0
					BEGIN
					 
						SELECT Top 1 @rowID = RowId						FROM #ValidationConditionsTemp
						SELECT @validationConditionID = Id				FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @VC_Seq = Seq							FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @OperandsDataType = OperandsDataType		FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @Operand1 = Operand1						FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @Operator = Operator						FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @Operand2 = Operand2						FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @LogicalOperator = LogicalOperator		FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @DBAccessID = DBAccessID					FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @WebServiceName = WebServiceName			FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @WebServiceMethod = WebServiceMethod		FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @ArrayIndex1 = ArrayIndex1				FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @ArrayIndex2 = ArrayIndex2				FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @CondtionRecordType = RecordType			FROM #ValidationConditionsTemp WHERE RowId = @rowID
						
						IF(@CondtionRecordType <> 'Deleted')
							BEGIN
								IF(@validationConditionID <> -1)
									BEGIN 
										UPDATE ValidationsConditions 
										SET
												ValidationsConditions.Seq				= @VC_Seq,
												ValidationsConditions.OperandsDataType	= @OperandsDataType,
												ValidationsConditions.Operand1			= @Operand1,
												ValidationsConditions.Operator			= @Operator,
												ValidationsConditions.Operand2			= @Operand2,
												ValidationsConditions.LogicalOperator	= @LogicalOperator,
												ValidationsConditions.DBAccessID		= @DBAccessID,
												ValidationsConditions.WebServiceName	= @WebServiceName,
												ValidationsConditions.WebServiceMethod	= @WebServiceMethod,
												ValidationsConditions.ArrayIndex1		= @ArrayIndex1,
												ValidationsConditions.ArrayIndex2		= @ArrayIndex2
										WHERE	Id										= @validationConditionID
									END
								ELSE
									BEGIN
										SELECT @validationConditionID = MAX(Id) + 1 FROM ValidationsConditions
										
										INSERT INTO ValidationsConditions (Id,RulesTranValidationId,Seq,OperandsDataType,Operand1,Operator,Operand2,LogicalOperator,DBAccessID,WebServiceName,WebServiceMethod,ArrayIndex1,ArrayIndex2)
										VALUES (@validationConditionID,@id,@VC_Seq,@OperandsDataType,@Operand1,@Operator,@Operand2,@LogicalOperator,@DBAccessID,@WebServiceName,@WebServiceMethod,@ArrayIndex1,@ArrayIndex2)
									END
							END
						ELSE
							BEGIN
								DELETE FROM ValidationsConditions WHERE Id = @validationConditionID
							END								

						DELETE #ValidationConditionsTemp Where RowId = @rowID
					END
				IF OBJECT_ID('tempdb..#ValidationConditionsTemp') IS NOT NULL DROP TABLE #ValidationConditionsTemp
			END
	END		
ELSE
	BEGIN
		DELETE FROM RulesTranValidations WHERE Id = @id
	END	
GO
drop_old_proc 'SaveValidationsConditionsSQLParams'
go
CREATE   procedure dbo.SaveValidationsConditionsSQLParams  
@validationsConditionsSQLParamsDT ValidationsConditionsSQLParamsDT READONLY
As  
  
/*   
name:   dbo.SaveValidationsConditionsSQLParams      
developer	:  Ahmed Osman
reason		:  CR#GFSY00754 - CBD_ACM16557_Emirates ID Expiry Date
date		:  31/03/2019   
*/  
  
SELECT * INTO #validationsConditionsSQLParamsTemp from @validationsConditionsSQLParamsDT  
  
DECLARE @DBAccessID INT , @ParamSeq int , @rowID INT  
DECLARE @ParamName VARCHAR(MAX), @ParamValue VARCHAR(MAX), @DataType VARCHAR(MAX), @RecordType VARCHAR(MAX)   
  
WHILE (SELECT Count(*) FROM #validationsConditionsSQLParamsTemp) > 0  
	BEGIN  
		SELECT TOP 1 @rowID = RowId  FROM #validationsConditionsSQLParamsTemp
    
  		SELECT @DBAccessID = DBAccessID FROM #validationsConditionsSQLParamsTemp WHERE RowId = @rowID  
  		SELECT @ParamSeq = ParamSeq  FROM #validationsConditionsSQLParamsTemp WHERE RowId = @rowID  
  		SELECT @ParamName = ParamName FROM #validationsConditionsSQLParamsTemp WHERE RowId = @rowID  
  		SELECT @ParamValue = ParamValue FROM #validationsConditionsSQLParamsTemp WHERE RowId = @rowID  
  		SELECT @DataType = DataType  FROM #validationsConditionsSQLParamsTemp WHERE RowId = @rowID  
  		SELECT @RecordType = RecordType  FROM #validationsConditionsSQLParamsTemp WHERE RowId = @rowID  
    
		IF(@RecordType<> 'Deleted')
			BEGIN
  				IF Exists (SELECT * FROM ValidationsConditionsSQLParams WHERE DBAccessID = @DBAccessID AND ParamSeq = @ParamSeq)  
  					BEGIN  
  						UPDATE ValidationsConditionsSQLParams   
  						SET   
  							ParamName  = @ParamName,  
  							ParamValue  = @ParamValue,  
  							DataType  = @DataType  
  						WHERE DBAccessID  = @DBAccessID AND ParamSeq = @ParamSeq  
  					END  
  				ELSE  
  					BEGIN  
  						INSERT INTO ValidationsConditionsSQLParams (DBAccessID,ParamSeq,ParamName,ParamValue,DataType)  
  						VALUES (@DBAccessID,@ParamSeq,@ParamName,@ParamValue,@DataType)  
  					END  
  			END
  		ELSE
  			BEGIN
  				DELETE FROM ValidationsConditionsSQLParams WHERE DBAccessID  = @DBAccessID AND ParamSeq = @ParamSeq  
  			END
     
		DELETE #validationsConditionsSQLParamsTemp WHERE RowId = @rowID  
	End
  IF OBJECT_ID('tempdb..#validationsConditionsSQLParamsTemp') IS NOT NULL DROP TABLE #validationsConditionsSQLParamsTemp   
go
Drop_old_proc GetTranValidationAction
GO
 Create  procedure [dbo].[GetTranValidationAction] 
 @LCID int  
AS                              
/*                              
CreationDate: 17-03-2019                    
OriginalName: dbo.GetTranValidationAction                              
Programmer: Mostafa Helmy                              
Description: Get Transaction Validation Action    
*/                    

If Exists(select * from dbo.ValidationActions)	
Begin
if(@LCID = 1033)
	Begin
	 Select ActionId as ID,RulesDescriptor.Descriptor as Name From ValidationActions inner join RulesDescriptor on ValidationActions.DescriptorName COLLATE SQL_Latin1_General_CP1_CS_AS=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CS_AS
	End
Else
	Begin
	Select ActionId as ID,RulesDescriptorLocal.LocalDescription as Name From ValidationActions inner join RulesDescriptor on ValidationActions.DescriptorName COLLATE SQL_Latin1_General_CP1_CS_AS=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CS_AS
	inner join RulesDescriptorLocal on RulesDescriptor.DescriptorID = RulesDescriptorLocal.DescriptorID and RulesDescriptorLocal.LCID=@LCID
	End
End
GO

Drop_old_proc GetValidationsConditions
GO
Create proc dbo.GetValidationsConditions
@TranId int
as
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetValidationsConditions                                
Programmer: Mostafa Helmy                                
Description: Get CUstom Fields || CR#GFSY0054 - ID Expiry Date       
*/    

	select 
	ValidationsConditions.Id,
	RulesTranValidationId,
	ValidationsConditions.Seq,
	OperandsDataType,
	Operand1,
	ArrayIndex1,
	Operator,
	Operand2,
	ArrayIndex2,
	LogicalOperator,
	DBAccessID,
	WebServiceName,
	WebServiceMethod,
	'Old' as ConditionRecordType,
	''  as ConditionRowId,
	''  as TranValDS_RowId
	from ValidationsConditions inner join RulesTranValidations 
	on ValidationsConditions.RulesTranValidationId = RulesTranValidations.Id and RulesTranValidations.TranId=@TranId
	
go
Drop_old_proc GetTransactionValidation
GO
Create proc dbo.GetTransactionValidation 
@TranID int
as
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetTransactionValidation                                
Programmer: Mostafa Helmy                                
Description: Get CUstom Fields || CR#GFSY0054 - ID Expiry Date       
*/ 

	select 
	Id,
	TranId,
	Seq,
	ValidationActionId,
	AlertMsg,
	RequiredFieldId,
	TransactionMode,
	ControlField,
	ResultField,
	'Old' as TranValRecordType,
	''  as TranValRowId
	from RulesTranValidations
	where TranId=@TranID

go
Drop_old_proc GetSqlParam
GO
 Create  procedure [dbo].[GetSqlParam]  
 
AS                              
/*                              
CreationDate: 17-03-2019                    
OriginalName: dbo.GetSqlParam                              
Programmer: Mostafa Helmy                              
Description: Get SQL params for Transaction Validation configuration #GFSY00754   
*/                    

Select DBAccessID,ParamSeq,ParamName,ParamValue,DataType,'Old' as RecordType,'' as ValidationNumber  From ValidationsConditionsSQLParams 
go
Drop_old_proc GetOperandDataTypeSQlParam
GO
 create  procedure dbo.GetOperandDataTypeSQlParam        
AS                                  
/*                                  
CreationDate: 2019-03-20                        
OriginalName: dbo.GetOperandDataTypeSQlParam                                  
Programmer: Mostafa Helmy                                  
Description: Get Operand DataType for SQlParam table || CR#GFSY00754 - ID Expiry Date         
*/                        
    
If Exists(Select * From OperandDataType)     
BEGIN    
 SELECT data_type,data_type FROM OperandDataType     
End
go
drop_old_proc 'SaveTranValidationAndValidationCondition'
go
CREATE   procedure dbo.SaveTranValidationAndValidationCondition  
@id INT,
@tranId INT,
@seq INT,
@validationActionId INT,
@alertMsg VARCHAR(MAX),
@requiredFieldId VARCHAR(MAX),
@transactionMode CHAR,
@controlField VARCHAR(MAX),
@resultField VARCHAR(MAX),
@recordType VARCHAR(MAX),
@tranValidationConditionsDT TransactionValidationConditionsDT READONLY
As  
  
/*   
name		:  dbo.SaveTranValidationAndValidationCondition      
developer	:  Ahmed Osman
reason		:  CR#GFSY00754 - CBD_ACM16557_Emirates ID Expiry Date
date		:  31/03/2019   
*/  
IF(@requiredFieldId = N'')
	BEGIN
		set @requiredFieldId = null
	END
IF(@recordType <> 'Deleted')
	BEGIN  
		IF(@id <> -1)	-- Update 	
			BEGIN
				UPDATE RulesTranValidations 
				SET 
					Seq = @seq, 
					ValidationActionId = @validationActionId,
					AlertMsg = @alertMsg,
					RequiredFieldId = @requiredFieldId,
					TransactionMode = @transactionMode,
					ControlField = @controlField,
					ResultField = @resultField
				WHERE Id = @id
			END
		ELSE	-- New
			BEGIN
				SELECT @id = ISNULL(MAX(Id),0) + 1 FROM RulesTranValidations
				
				INSERT INTO RulesTranValidations(Id,TranId,Seq,ValidationActionId,AlertMsg,RequiredFieldId,TransactionMode,ControlField,ResultField)
				VALUES (@id,@tranId,@seq,@validationActionId,@alertMsg,@requiredFieldId,@transactionMode,@controlField,@resultField)
			END

		IF(@id <> -1)
			BEGIN
				SELECT * INTO #ValidationConditionsTemp FROM @tranValidationConditionsDT
				
				DECLARE @validationConditionID INT, @VC_Seq INT, @OperandsDataType INT, @DBAccessID INT, @ArrayIndex1 INT, @ArrayIndex2 INT, @RowId INT
				DECLARE @Operand1 VARCHAR(MAX), @Operator VARCHAR(MAX), @Operand2 VARCHAR(MAX), @LogicalOperator VARCHAR(MAX), @WebServiceName VARCHAR(MAX), @WebServiceMethod VARCHAR(MAX), @CondtionRecordType VARCHAR(MAX)
				
				WHILE (SELECT Count(*) FROM #ValidationConditionsTemp) > 0
					BEGIN
					 
						SELECT Top 1 @rowID = RowId						FROM #ValidationConditionsTemp
						SELECT @validationConditionID = Id				FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @VC_Seq = Seq							FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @OperandsDataType = OperandsDataType		FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @Operand1 = Operand1						FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @Operator = Operator						FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @Operand2 = Operand2						FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @LogicalOperator = LogicalOperator		FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @DBAccessID = DBAccessID					FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @WebServiceName = WebServiceName			FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @WebServiceMethod = WebServiceMethod		FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @ArrayIndex1 = ArrayIndex1				FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @ArrayIndex2 = ArrayIndex2				FROM #ValidationConditionsTemp WHERE RowId = @rowID
						SELECT @CondtionRecordType = RecordType			FROM #ValidationConditionsTemp WHERE RowId = @rowID
						
						IF(@CondtionRecordType <> 'Deleted')
							BEGIN
								IF(@validationConditionID <> -1)
									BEGIN 
										UPDATE ValidationsConditions 
										SET
												ValidationsConditions.Seq				= @VC_Seq,
												ValidationsConditions.OperandsDataType	= @OperandsDataType,
												ValidationsConditions.Operand1			= @Operand1,
												ValidationsConditions.Operator			= @Operator,
												ValidationsConditions.Operand2			= @Operand2,
												ValidationsConditions.LogicalOperator	= @LogicalOperator,
												ValidationsConditions.DBAccessID		= @DBAccessID,
												ValidationsConditions.WebServiceName	= @WebServiceName,
												ValidationsConditions.WebServiceMethod	= @WebServiceMethod,
												ValidationsConditions.ArrayIndex1		= @ArrayIndex1,
												ValidationsConditions.ArrayIndex2		= @ArrayIndex2
										WHERE	Id										= @validationConditionID
									END
								ELSE
									BEGIN
										SELECT @validationConditionID = ISNULL(MAX(Id),0) + 1 FROM ValidationsConditions
										
										INSERT INTO ValidationsConditions (Id,RulesTranValidationId,Seq,OperandsDataType,Operand1,Operator,Operand2,LogicalOperator,DBAccessID,WebServiceName,WebServiceMethod,ArrayIndex1,ArrayIndex2)
										VALUES (@validationConditionID,@id,@VC_Seq,@OperandsDataType,@Operand1,@Operator,@Operand2,@LogicalOperator,@DBAccessID,@WebServiceName,@WebServiceMethod,@ArrayIndex1,@ArrayIndex2)
									END
							END
						ELSE
							BEGIN
								DELETE FROM ValidationsConditions WHERE Id = @validationConditionID
							END								

						DELETE #ValidationConditionsTemp Where RowId = @rowID
					END
				IF OBJECT_ID('tempdb..#ValidationConditionsTemp') IS NOT NULL DROP TABLE #ValidationConditionsTemp
			END
	END		
ELSE
	BEGIN
		DELETE FROM RulesTranValidations WHERE Id = @id
	END	
GO
USE [Globalfs]
GO
/****** Object:  StoredProcedure [dbo].[TLR_SearchDrawer]    Script Date: 03/13/2019 12:10:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[TLR_SearchDrawer]  --TLR_SearchDrawer '','',1033,'600000002535',10462,'EGP'
@DrawerID char(8) = '',
@DrawerName VARCHAR(100) = '',
@LCID int = 1033,
@CommitmentNo nvarchar(12) = '',
@RimNo int = 0,
@Currency char(3) = ''
 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Search table Drawer "LBDDrawer" 

Developer: Mostafa Helmy
Date: 13-03-2019
Reason: get the CD.DrawerLimitInAmount and CD.AvailableLimit 
*/

IF (@CommitmentNo <> '')
BEGIN

select d.DrawerID,DrawerName,d.Currency,d.ExpiryDate,d.DrawerLimit,DrawerAmount,TotalAssignedAmount,
d.UtilizedLimit,d.AvailableLimit,PastDue,Remarks,AvailabiltyOfCBRBStatus,CommentsOnCBRBStatus ,CBRBStatusDate,
Status=CASE @LCID

		WHEN 1033 THEN RulesDescriptor.Descriptor

		ELSE RDL.LocalDescription

		END ,
CBRBStatusDate,DateOfDeactivation,d.StartDate,d.Tenor,d.Period,ModifiedDate
,CD.DrawerLimitInAmount,CD.AvailableLimit as [Total_Available_Limit]
from Drawer d  
LEFT JOIN CommitmentDrawer CD
ON CD.DrawerID = d.DrawerID
 LEFT JOIN
 PickList_Entries pe2 ON pe2.PickListID =526
 AND pe2.[Value] =d.Status
 LEFT JOIN 
 RulesDescriptor ON (pe2.DescriptorName=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CI_AS )
 LEFT JOIN 
 dbo.RulesDescriptorLocal RDL ON RulesDescriptor.DescriptorID =RDL.DescriptorID and RDL.LCID=@LCID
WHERE CD.CommitmentNo = @CommitmentNo        
AND CD.RimNo = @RimNo        
AND CD.Currency = @Currency    
AND CD.Status = 'Active'  
 
END
ELSE
BEGIN

select DrawerID,DrawerName,Currency,ExpiryDate,DrawerLimit,DrawerAmount,TotalAssignedAmount
,UtilizedLimit,AvailableLimit,PastDue,Remarks
,AvailabiltyOfCBRBStatus,
CommentsOnCBRBStatus ,CBRBStatusDate,
Status=CASE @LCID

		WHEN 1033 THEN RulesDescriptor.Descriptor

		ELSE RDL.LocalDescription

		END ,CBRBStatusDate,DateOfDeactivation,StartDate,Tenor,Period,ModifiedDate,
		null as DrawerLimitInAmount,null as [Total_Available_Limit]
		 from Drawer d  
 LEFT JOIN
 PickList_Entries pe2 ON pe2.PickListID =526
 AND pe2.[Value] =d.Status
 LEFT JOIN 
 RulesDescriptor ON (pe2.DescriptorName=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CI_AS )
 LEFT JOIN 
 dbo.RulesDescriptorLocal RDL ON RulesDescriptor.DescriptorID =RDL.DescriptorID and RDL.LCID=@LCID
 where (@DrawerID ='' OR d.DrawerID=@DrawerID)
 and  (@DrawerName ='' or d.DrawerName LIKE '%'+ @DrawerName+'%')

END

END
GO
drop_old_proc 'dbo.ValidateLBDDrawer'
go
CREATE PROCEDURE dbo.ValidateLBDDrawer 

@TranName nvarchar(100),

@RimNumber int, 

@commitmentNo nvarchar(12) = null,  

@drawerID nvarchar(25) = null,  

@chequeAmount decimal(21,6) = null,  

@currentCommitmentBalance decimal(21,6) = null,  

@chequeMaturityDate date = null, 

@currentCommitmentExpiryDate date = null, 

@validateTotalAmount bit = 0  ,

@ChqTenor       float =-1  AS

/* 

Developer: Mostafa Sayed 

Date	 : 2018-10-21 

Reason	 : CBD_ACM15892_LBD Drawer  

  

Developer: MAhmoud Saad 

Date	 : 19/3/2019

Reason	 : GFSY00753 Add Validation to Cheaque tenor in booking transaction

  

Error codes:  

-1  if cheque amount is greater than commitment amount  

-2  if cheque maturity date is greater than commitment maturity date  

-3  if cheque amount is greater than available balance in drawer  

-4  if cheque maturity date is greater than commitment drawer expiry date 

-5  if SA Drawer status is not active 

-6  if link between drawer and commitment status is not active 

-7  if SA Drawer is Past Due 

-8  if totalAmount of cheques is greater than drawer available balance  

-9  if totalAmount of cheques is greater than SA drawer available balance  

-10 if totalAmount of cheques is greater than commitment available balance  

-11 if cheque amount is greater than available balance in SA drawer  

-12 if cheque maturity date is greater than SA drawer expiry date

-13 if UtilizedLimit is greater than DrawerLimitInAmount in CommitmentDrawer

-14 if Cheaque Tenor  is greater than Commitment Drawer Tenor in CommitmentDrawer

Error Types:  

w = warning  

s = stop

 */  

  

CREATE TABLE #Errors  

(ErrorNo int, ErrorType char(1), ErrorDescription nvarchar(max))  



DECLARE @SADrawerAvailableBalance decimal(21,6) 

DECLARE @SADrawerExpiryDate date  

DECLARE @SADrawerStatus char(30)  

DECLARE @SADrawerPastDue bit  



DECLARE @DrawerAvailableBalance decimal(21,6)  

DECLARE @DrawerExpiryDate date  

DECLARE @CommitmentDrawerStatus nvarchar(20)  

DECLARE @DrawerName nvarchar(100)

DECLARE @DrawerLimitInAmount decimal(21,6)

DECLARE @UtilizedLimit decimal(21,6)

DECLARE @CommitmentDrawerTenor float



SELECT @CommitmentDrawerTenor=Tenor

FROM CommitmentDrawer  

WHERE CommitmentNo = @commitmentNo AND DrawerID = @drawerID



  

SELECT @DrawerAvailableBalance = AvailableLimit,  

	   @DrawerExpiryDate = ExpiryDate,  

	   @CommitmentDrawerStatus = Status,

	   @DrawerLimitInAmount = DrawerLimitInAmount,

	   @UtilizedLimit = UtilizedLimit

FROM CommitmentDrawer  

WHERE CommitmentNo = @commitmentNo AND DrawerID = @drawerID



SELECT @SADrawerStatus = Status,  

	   @SADrawerPastDue = PastDue,

       @SADrawerAvailableBalance = AvailableLimit,

       @DrawerName = DrawerName,

       @SADrawerExpiryDate = ExpiryDate

FROM Drawer 

WHERE DrawerID = @drawerID  



SET @UtilizedLimit = @UtilizedLimit + @chequeAmount

  

IF(@TranName = 'DiscountedChequesApproval')  

BEGIN  

	 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   

	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Amount ' + cast(@currentCommitmentBalance as varchar))  

	 END  



	 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND  

	  (@chequeMaturityDate > @currentCommitmentExpiryDate))  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-2,'w',N'Cheque Maturity Date Is Greater Than Commitment ('+@commitmentNo+') Expiry Date')  

	 END  

	   

	 IF(@chequeAmount IS NOT NULL  AND @DrawerAvailableBalance IS NOT NULL AND   

	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ('+@DrawerName+') ' + cast(@DrawerAvailableBalance as varchar))  

	 END  

	   

	 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND  

	  (@chequeMaturityDate > @DrawerExpiryDate))  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DrawerName+') Expiry Date')  

	 END  

	   

	 IF(LOWER(@SADrawerStatus) != 'active' AND @validateTotalAmount = 0)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-5,'s',N'SA Drawer ('+@DrawerName+') Not Active')  

	 END  

	  

	 IF(LOWER(@CommitmentDrawerStatus) != 'active' AND @validateTotalAmount = 0)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-6,'s',N'Drawer ('+@DrawerName+') Linked To Commitment ('+@commitmentNo+') Is Not Active')  

	 END  

	 

	 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-7,'w',N'Drawer ('+@DrawerName+') Is Past Due')  

	 END  

	 

	 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  

	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Drawer ('+@DrawerName+') Available Balance ' + cast(@DrawerAvailableBalance as varchar))  

	 END

	 

	 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  

	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DrawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  

	 END  

	 

	 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  

	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  

	 END 

	 

	 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   

	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  

	 END 

	 

	 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  

	  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DrawerName+') Expiry Date')  

	 END  

	 

	 IF(@UtilizedLimit > @DrawerLimitInAmount AND @validateTotalAmount != 1)

	 BEGIN

		INSERT INTO #Errors  

		VALUES(-13,'w',N'Utilized Amount Will Be Greater Than Drawer Limit In Drawer ('+@DrawerName+') Commitment ('+@commitmentNo+')') 

	 END
	   IF(@CommitmentDrawerTenor < @ChqTenor AND @validateTotalAmount != 1)

	 BEGIN

		INSERT INTO #Errors  

		VALUES(-14,'w',N'Cheaque Tenor Will Be Greater Than Commitment Drawer Tenor In Drawer ('+@DrawerName+') Commitment ('+@commitmentNo+')') 

	 END
END  

ELSE IF(@TranName = 'DiscountedChequeBooking')  

BEGIN  

	 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   

	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment Amount ' + cast(@currentCommitmentBalance as varchar))  

	 END  

	  

	 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND   

	  (@chequeMaturityDate > @currentCommitmentExpiryDate))  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-2,'s',N'Cheque Maturity Date Is Greater Than Commitment Expiry Date')  

	 END  

	   

	 IF(@chequeAmount IS NOT NULL AND @DrawerAvailableBalance IS NOT NULL AND   

	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ' + cast(@DrawerAvailableBalance as varchar))  

	 END  

	   

	 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND   

	  (@chequeMaturityDate > @DrawerExpiryDate))  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DrawerName+') Expiry Date')  

	 END  

	   

	 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-7,'w',N'Drawer ('+@DrawerName+') Is Past Due')  

	 END  

	   

	 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  

	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Drawer Available Balance ' + cast(@DrawerAvailableBalance as varchar))  

	 END

	 

	 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  

	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DrawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  

	 END  

	 

	 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  

	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  

	 END 

	 

	 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   

	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  

	 END   

	 

	 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  

	  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  

	 BEGIN  

		INSERT INTO #Errors  

		VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DrawerName+') Expiry Date')  

	 END  

	 

	 IF(@UtilizedLimit > @DrawerLimitInAmount AND @validateTotalAmount != 1)

	 BEGIN

		INSERT INTO #Errors  

		VALUES(-13,'w',N'Utilized Amount Will Be Greater Than Drawer Limit In Drawer ('+@DrawerName+') Commitment ('+@commitmentNo+')') 

	 END

	  IF(@CommitmentDrawerTenor < @ChqTenor AND @validateTotalAmount != 1)

	 BEGIN

		INSERT INTO #Errors  

		VALUES(-14,'w',N'Cheaque Tenor Will Be Greater Than Commitment Drawer Tenor In Drawer ('+@DrawerName+') Commitment ('+@commitmentNo+')') 

	 END

END  

	SELECT * FROM #Errors 

GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Select_EndOfDay_Movements
Go

CREATE PROC dbo.Select_EndOfDay_Movements        
 @Bank BankID,              
 @Region RegionID ,              
 @Branch BranchID ,        
 @CheckPendingStock bit = 1,        
 @CurrentBusinessDate smalldatetime  = null,
 @CloseForNightly int = 0
AS              
SET NOCOUNT ON              
/*              
CreationDate: 2005-03-03              
OriginalName: dbo.Select_EndOfDay_Movements            
Programmer : Ahmed Fahim              
Description : Return all movement was sent to current branch during the day without recieve              
Output  :                
Assumption :               
              
ModifiedDate: 14/1/2010              
Modifer:      Adel Shaban          
ModifyReason: in case of having cash or stock movement pending to vault: select vault name + branch number              
        
ModifiedDate: 21/1/2010              
Modifer:      Ahmed Helmi        
ModifyReason: Addding new parameter "@CheckPendingStock" to enable or disable Cash and Stock Movement validations        
  
  
ModifiedDate: 26/05/2010              
Modifer:      Mohamed Kamel        
ModifyReason: Enable or Disable Cash and Stock Movement validations according to @CheckPendingStock parameter  

ModifiedDate: 2011-06-28
Modifer:      MOhammed Farouk
ModifyReason: Use of memory temp table instead of the UNION select as the columns are nvarchar, which not supported in UNION

   
ModifiedDate: 2011-07-13
Modifer:      Osama Orabi
ModifyReason: CR# 7513, if @CheckCashSent = 0, Any Pending CashMovenemt between branches or headoffice is allowed
						if @CheckCashSent = 1, Make sure there is no pending cash movement period (between branches)exceeded 
						the @PendingCashDays
						
ModifiedDate: 2011-07-27
Modifer:      Osama Orabi
ModifyReason: CR# 7513, Rework

ModifiedDate: 2017-03-02
Modifer:      Nada Elshafie
ModifyReason: If closing for Nightly Mode return only pending cash send movement - GFSY00630 - CBD_CRQ13504


ModifiedDate: 2019-02-12
Modifer:      osama nabil
ModifyReason: Defect#GFSX13519 Optimize Stored Procedure
*/              
 
 if(@CurrentBusinessDate is null)
	set @CurrentBusinessDate = dbo.now()
declare @CheckCashSent bit,
		@PendingCashDays int
		
SET @CheckCashSent = 1
SET @PendingCashDays = 0

SELECT @CheckCashSent = convert(bit,ISNULL(Value,'True'))
FROM RulesTranFldParam
WHERE TranName = 'EndOfDay'
	AND FieldName = 'CheckPendingCash'
	And Param = 'CheckCashSent'
   
SELECT @PendingCashDays = convert(int,ISNULL(Value,'0'))
FROM RulesTranFldParam
WHERE TranName = 'EndOfDay'
	AND FieldName = 'CheckPendingCash'
	And Param = 'PendingCashDays'
   
 ---
 declare @ListofTCMovementIDs table(    
    ID int not null)
    
INSERT INTO @ListofTCMovementIDs
select max(id) as id              
from tcmovement WITH (NOLOCK)             
group by RefNo

declare @ListofCashMovementIDs table(    
    ID int not null)    
    
INSERT INTO @ListofCashMovementIDs
select max(id) as id              
from cashmovement WITH (NOLOCK)            
group by RefNo

 
 ---
 
    
declare @ListofIDs table(    
    ToFromID int not null)    
  
insert into @ListofIDs values (1)    
insert into @ListofIDs values (4)    
if (@CheckPendingStock = 1)    
begin    
 -- do not insert from branch to branch   
 insert into @ListofIDs values (3)    
 insert into @ListofIDs values (8)    
end    
--=========================================
declare @ListOfIDsForCash table(ToFromID int not null)
insert into @ListOfIDsForCash values (1)    
insert into @ListOfIDsForCash values (4)    
if (@CheckCashSent = 1)    
begin    
 -- do not insert from branch to branch   
 insert into @ListOfIDsForCash values (3)    
 insert into @ListOfIDsForCash values (8)    
end  
--=========================================
declare @result table
(
	[TO]		nvarchar(200),
	Movement	varchar(50),
	Total		int
)
if(@CloseForNightly=0)
Begin
Insert Into @result ([TO],Movement,Total)	           
select 'TO' =              
 case  m.ToFromID              
 /*Teller*/ when '1' then               
 (              
  SELECT     'Teller : ' + FirstName + ' ' + LastName               
  FROM         Operator   WITH (NOLOCK)           
  WHERE     (user_number = m.ToFromCode)              
 )              
              
 /*Branch*/ when '3' then               
 (              
  SELECT     'Branch : ' + Name              
  FROM         Branch              
  WHERE     (Bank = @Bank) and (Region = @Region) and (Branch = ToFromCode)              
 )              
              
 /*Vault*/ when '4' then               
 (          
            
  SELECT     'Vault : ' + Name          
  FROM         Branch     WITH (NOLOCK)       
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
  --SELECT     'Vault : ' +  m.ToFromCode              
 )              
              
 /*HeadOffice*/ when '8' then               
 (              
  SELECT     'Head Office : ' + Name              
  FROM         Branch WITH (NOLOCK)             
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
               
 end,              
 'TC' as 'Movement',              
 count(m.id) as Total              
from tcmovement as m  WITH (NOLOCK)            
--inner join ( select max(id) as id              
--  from tcmovement              
--  group by RefNo) as r              
inner join @ListofTCMovementIDs as r  
on m.id = r.id              
inner join tofrom as f              
on  m.tofromid = f.id              
where m.TCMovementTypeID = 1 -- send              
and m.user_branch = @Branch              
AND m.ToFromID IN (select * from @ListofIDs)--(1,3,4,8)              
group BY m.ToFromID , m.ToFromCode               


  
 ;WITH StockMov as(
 select * 
 from StockMovement WITH (NOLOCK)
 where MovementTypeID = 1 -- send          
 and user_branch = @Branch          
 and ToFromID IN (select * from @ListofIDs)  
 )
          
--UNION    
          
Insert Into @result ([TO],Movement,Total)              
select  'TO' =              
 case  m.ToFromID              
 /*Teller*/ when '1' then               
 (              
  SELECT     'Teller : ' + FirstName + ' ' + LastName               
  FROM         Operator   WITH (NOLOCK)  
  WHERE     (user_number = m.ToFromCode)              
 )              
              
 /*Branch*/ when '3' then               
 (              
  SELECT     'Branch : ' + Name              
  FROM         Branch   WITH (NOLOCK)           
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
              
 /*Vault*/ when '4' then               
 (              
/*  SELECT     'Vault : ' + Name              
  FROM         Branch              
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
*/        
 SELECT   'Vault : ' + op.FirstName+' '+op.LastName+' at Branch#: '+ cast(op.Branch as varchar(10))          
  FROM      v_operator op          
  Where (op.Bank = @Bank) AND (op.Region = @Region)         
 AND op.user_number =(          
      select top 1 AssignedToTeller          
      from CashDrawer   WITH (NOLOCK)        
      where CashDrawerNumber= ToFromCode)        
              
  --SELECT     'Vault : ' +  m.ToFromCode              
 )              
      
 /*HeadOffice*/ when '8' then               
 (              
  SELECT     'Head Office : ' + Name              
  FROM         Branch  WITH (NOLOCK)            
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
               
 end              
 ,              
 s.StockCode AS Movement ,              
 count(m.id) AS Total              
FROM StockMov AS m            
INNER join Stock AS s  WITH (NOLOCK)                    
ON s.lastid = m.id  and m.stockid=s.id      
--WHERE m.MovementTypeID = 1 -- Send              
--AND m.User_Branch = @Branch           
--AND (m.ToFromID IN (select * from @ListofIDs)) --(1,3,4,8)    
GROUP  BY               
 m.ToFromID , m.ToFromCode , s.StockCode              
End              
--UNION              

 ;WITH CashMov as(
 select * 
 from CashMovement WITH (NOLOCK)
 where movementtype = 1           
 and user_branch = @Branch          
 and ToFromID IN (select * from @ListOfIDsForCash)  
 AND (
		 ToFromID in (1,4)
		OR (@CheckCashSent = 1 AND ToFromID in (3,8) AND  dateadd(day,@PendingCashDays,date_time)<= @CurrentBusinessDate)
	)
 )              
-- any cash movement              
Insert Into @result ([TO],Movement,Total)
select  'TO' =              
 case  m.ToFromID              
 /*Teller*/ when '1' then               
 (              
  SELECT     'Teller : ' + FirstName + ' ' + LastName               
  FROM         Operator  WITH (NOLOCK)            
  WHERE     (user_number = m.ToFromCode)              
 )              
              
 /*Branch*/ when '3' then               
 (            
  SELECT     'Branch : ' + Name              
  FROM         Branch  WITH (NOLOCK)            
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
              
 /*Vault*/ when '4' then               
(          
              
  SELECT   'Vault : ' + op.FirstName+' '+op.LastName+' at Branch#: '+ cast(op.Branch as varchar(10))          
  FROM      v_operator op          
  Where (op.Bank = @Bank) AND (op.Region = @Region)         
 AND op.user_number =(          
      select top 1 AssignedToTeller          
      from CashDrawer  WITH (NOLOCK)         
      where CashDrawerNumber= ToFromCode        
      )          
          
  --SELECT     'Vault : ' +  m.ToFromCode              
 )              
              
 /*HeadOffice*/ when '8' then               
 (              
  SELECT     'Head Office : ' + Name              
  FROM         Branch  WITH (NOLOCK)            
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
              
 end              
 , 'Cash' as Movement , count(m.id) as Total              
from CashMov as m              
--inner join ( select max(id) as id              
--  from cashmovement              
--  group by RefNo) as r              
inner join @ListofCashMovementIDs as r
on m.id = r.id              
inner join tofrom as f              
on  m.tofromid = f.id              
--where m.movementtype = 1 -- send              
--and m.user_branch = @Branch              
--AND m.ToFromID IN (select * from @ListOfIDsForCash)--(1,3,4,8) 
--AND (--@CheckCashSent = 0 --(1,4) only will be retrieved
--		--OR
--		 m.ToFromID in (1,4)
--		OR (@CheckCashSent = 1 AND m.ToFromID in (3,8) AND  dateadd(day,@PendingCashDays,m.date_time)<= @CurrentBusinessDate)
--	)
	
group BY m.ToFromID , m.ToFromCode               

Select * From @result

Go
--End of Automatic Generation
