drop_old_proc 'Delete_GL_CategoryDetail_ByGLNumber'
go

CREATE procedure dbo.Delete_GL_CategoryDetail_ByGLNumber  

@id int,
@GLNumber nvarchar(50),
@GLName nvarchar(50)

As  

/*  

CreationDate: 2020-04-08  

OriginalName: dbo.Delete_GL_CategoryDetail_ByGLNumber

Programmer: Mostafa Helmy  

Description: delete from GLCategoryGroupDetail table by GLNumber

    

Output:    

Assumption:    

*/  

  

set nocount on  

declare @Result int  

begin tran  

  
 Delete from GLCategoryDetail where GLCategoryID = @id and GLNumber=@GLNumber and GLName=@GLName 

 set @Result=0  

  

if @@error<>0  

begin  

 rollback tran  

 return -1  

end  

else  

begin  

 commit tran  

 return @Result  

end  

GO


drop_old_proc 'TLR_SELECT_GL_NUMBER_FOR_CATEGORY'
go
create Proc   dbo.TLR_SELECT_GL_NUMBER_FOR_CATEGORY 

@CatID int 

AS

/*

CreationDate:	2007-11-21

OriginalName:	dbo.GET_ALL_GATEGORY

Programmer:	Mariam Moneeb

Description:	Gets All GLs Category 

Output:		

Assumption:	
----------------------
Modification Date: 05-04-2020 
Programmer: Mostafa Helmy    
Description:  ACM000000016934 - KIB - Maker-Checker Adding GL To Category_FRS----

*/

select 'NotChanged'as RowStatus,GLCategoryID,C.Name, GLNumber ,GLName

from GLCategoryDetail D inner join GLCategory C on C.id = D.GLCategoryID

where GLCategoryID=@CatID


GO
drop_old_proc 'Delete_GLCategoryDetail'
go

create procedure [dbo].[Delete_GLCategoryDetail]  
@id	int,
@GLNumber varchar(max)='',
@GLName varchar(max)=''
As
/*
CreationDate:	2004-12-25
OriginalName:	dbo.Delete_FeeCategoryGroupDetail
Programmer:	Ahmed Fahim
Description:	delete from FeeCategoryGroupDetail table 
		
Output:		
Assumption:	

ModifiedDate:	
Modifer:		
ModifyReason:	
*/

set nocount on
declare @Result int
begin tran

	Delete from GLCategoryDetail where GLCategoryID = @id and GLNumber=@GLNumber and GLName=@GLName 
	set @Result=0

if @@error<>0
begin
	rollback tran
	return -1
end
else
begin
	commit tran
	return @Result
end


GO
drop_old_proc 'Delete_GL_CategoryDetail'
go

create procedure [dbo].[Delete_GL_CategoryDetail]  
@id	int,
@GLNumber nvarchar(max)='',
@GLName nvarchar(max)='' 
As  
/*  
CreationDate: 2004-12-25  
OriginalName: dbo.Delete_GL_CategoryDetail
Programmer: Mariam Moneeb  
Description: delete from GLCategoryGroupDetail table   
    
ModificatioDate: 09-04-2020 
Programmer: Mostafa Helmy 
Description: GFSY00787
Output:    
Assumption:    
*/  
  
set nocount on  
declare @Result int  
begin tran  
  
 Delete from GLCategoryDetail where GLCategoryID = @id  and GLNumber=@GLNumber and GLName=@GLName 
 set @Result=0  
  
if @@error<>0  
begin  
 rollback tran  
 return -1  
end  
else  
begin  
 commit tran  
 return @Result  
end  


GO
Drop_old_proc Get_DC_Commission
Go


CREATE procedure dbo.Get_DC_Commission   
@TranName TransactionName,                                 
 @TranAmount decimal(20,2)		= -1,          
 @RimClass int					= -1,          
 @RimNo char(10)				= NULL,        
 @AcctNo varchar(60)			= NULL ,       
 @ProfileId int					= -1,          
 @AcctType AccountTypeCode		= NULL,        
 @AccountCurrency CurrencyType	= NULL,        
 @TranCurrency CurrencyType		= NULL,        
 @AccountClass int				= -1,          
 @DefaultCurr varchar(4)		= NULL         
as                
 /*          
CreationDate: 2008-03-15          
OriginalName: dbo.Get_DC_Commission          
Programmer: Abd El-Samie Hussein    
Description: Select Discounted cheque commission     
Output:            
Assumption:           
          
ModifiedDate: 30-6-2009     
Modifer: Mostafa Essam     
ModifyReason:  add End Amount to the result    

ModifiedDate: 3-7-2009            
Modifer     : Amira Kamel         
ModifyReason: Retrofit proce from CBD To UBS  

ModifiedDate: 20/01/2013
Modifer     : Hatim AlSum         
ModifyReason: Use FeeCategory instead of FeeGroup

ModifiedDate: 06/04/2020
Modifer     : Ahmed Osman         
ModifyReason: Check on Exeption Charges
*/                               
set nocount on  
                        
CREATE TABLE #Result
(
	FeeCode			varchar(max),
    IsFixed			bit,
	AmountPercent	money,
	Min				money,
	Max				money,
	FeeName			varchar(max),
	CoreFeeCode		int,
	PeriodInDays	numeric(18,0),
	ChargeDepLoaN	char(3),
	CorFeeDesc		varchar(max),
	Endamount		money,
	IsReaded		bit 
)   
                   
declare         
 @TranID			tran_ID,                
 @FeeCategoryID		int,
 @FeeCode			FeeID,
 @ExepAmt			money,
 @AmountPercent		money,
 @IsFixed			bit,
 @Min				money,
 @Max				money,
 @DefaultCurrency	tinyint
 
               
set @TranID				= (select TranID from RulesTranName where TransactionName = @TranName)                          
set @FeeCategoryID		= (select TranCommissionGroupID from RulesTranConfig where tranid = @TranID) 
set @DefaultCurrency	= (select DecimalPlaces from CurrencyType where CurrencyType = @DefaultCurr)         
      
INSERT INTO #Result 
  SELECT
  f.FeeCode,
  f.IsFixed,
  f.AmountPercent,
  f.Min,
  f.Max,
  f.FeeName,
  f.CoreFeeCode ,
  f.PeriodInDays,
  f.ChargeDepLoaN,
  f.CorFeeDesc,  
  f.Endamount ,
  0 
 FROM Fee as f 
 INNER JOIN FeeGroupDetail	FGD on f.FeeCode = FGD.FeeCode
 INNER JOIN FeeCategoryGroupDetail FC on FC.FeeGroupID= FGD.FeeGroupID and FC.FeeCategoryID = @FeeCategoryID                

WHILE (SELECT count(*) FROM #Result WHERE IsReaded = 0) > 0
BEGIN
	SET @ExepAmt = -1
	SELECT TOP(1) @FeeCode = FeeCode FROM #Result WHERE IsReaded = 0
		
	SELECT @ExepAmt = CASE WHEN (
					(E.Operator='')																			OR
					(E.Operator ='<'	AND ROUND(@TranAmount,@DefaultCurrency) <	E.TransactionAmount)	OR 
					(E.Operator ='<='	AND ROUND(@TranAmount,@DefaultCurrency) <=	E.TransactionAmount)	OR
					(E.Operator ='>'	AND ROUND(@TranAmount,@DefaultCurrency) >	E.TransactionAmount)	OR
					(E.Operator ='>='	AND ROUND(@TranAmount,@DefaultCurrency) >=	E.TransactionAmount)	OR
					(E.Operator ='='	AND ROUND(@TranAmount,@DefaultCurrency) =	E.TransactionAmount)
					) THEN E.ChargeAmount
					ELSE
						-1           
					END ,
			@AmountPercent = Percentage,
			@IsFixed = IsFixedCharge ,
			@Min = MinimumAmount,
			@Max = MaximumAmount           
	FROM ExceptionCharges E              
		WHERE E.ChargeCode = @FeeCode             
		AND (E.TranID = @TranID)        
		AND ((AccountCurrency		= case when (@AccountCurrency is null OR ltrim(rtrim(@AccountCurrency)) = '') then AccountCurrency Else @AccountCurrency end ) or AccountCurrency is null or AccountCurrency = '')                   
		AND (AccountNumber			= @AcctNo		OR (1 = 1 AND AccountNumber = '') OR (1 = 1 AND AccountNumber is null))         
		AND (AccountType			= @AcctType		OR (1 = 1 AND AccountType is null)  OR (1 = 1 AND AccountType = ''))    
		AND (CustomerNumber			= @RimNo		OR CustomerNumber is null)            
		AND (CustomerClass			= @RimClass		OR CustomerClass is null)            
		AND (CustomerProfileId		= @ProfileID	OR CustomerProfileID is null)    
		AND (TransactionCurrency	= @TranCurrency OR TransactionCurrency is null)   
		AND (AccountClass			= @AccountClass OR AccountClass = -1 Or AccountClass is null)           
		ORDER BY   
			case when AccountNumber			is null then '0' else '1' end,      
			case when AccountCurrency		is null then '0' else '1' end,                  
			case when AccountType			is null then '0' else '1' end,            
			case when CustomerNumber		is null then '0' else '1' end,            
			case when CustomerClass			is null then '0' else '1' end,            
			case when CustomerProfileID		is null then '0' else '1' end,    
			case when TransactionCurrency	is null then '0' else '1' end,     
			case when TransactionOption		is null then '0' else '1' end 

	IF(@ExepAmt <> -1)
	Begin
		UPDATE #Result 
			SET AmountPercent = CASE WHEN @IsFixed = 1 THEN @ExepAmt ELSE @AmountPercent END , IsFixed = @IsFixed , Min = @Min , Max = @Max
			WHERE FeeCode = @FeeCode
	END 

	UPDATE #Result SET IsReaded = 1 WHERE FeeCode IN (SELECT TOP(1) FeeCode FROM #Result WHERE IsReaded = 0)
END

SELECT
  FeeCode,
  IsFixed,
  AmountPercent,
  Min,
  Max,
  FeeName,
  CoreFeeCode ,
  PeriodInDays,
  ChargeDepLoaN,
  CorFeeDesc,  
  Endamount 
FROM #Result

If(OBJECT_ID('tempdb..#Result') Is Not Null)
Begin
    Drop Table #Result
END     
go
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Get_Tran_Names_IDs
Go

create proc dbo.Get_Tran_Names_IDs   --Get_Tran_Names_IDs 1  
@Flag int = null ,  
@LCID LanguageLCID = 1030     
as        
/*      
ModifiedDate: 28-5-2009          
Modifer: Amira kamel          
ModifyReason: Selecting the [Descriptor] to use it in add tranxapi code screen      
    
ModifiedDate: 27-7-2009          
Modifer: Ahmed Hashem    
ModifyReason: select transactions that have exchange type only     
    
ModifiedDate: 30-7-2009          
Modifer: Mostafa Essam    
ModifyReason: make fileration of combo to get transaction that only have    
    charges  or  exchage rate   or all     
    @flage 1- charges  2- rates   Null for all transaction    
    
ModifiedDate: 2010-03-08    
Modifer:  Hisham Nassef    
ModifyReason: Sorting the output by descriptor not tran name since descriptor is what is displayed to the user    
  
Updated BY  : Amira kamel       
Updated Date: 2010-3-22     
Reason   :   select tran desc accourding to LCID  

Updated BY  : Amira kamel       
Updated Date: 2010-4-6     
Reason   :    update selec statment  

Updated BY  : Mostafa Helmy       
Updated Date: 19-04-2020     
Reason   :    GFSY00790 - Select Transactions that have either charge or commission 
*/    
    
set nocount on     
  if @Flag =1     -- Charge
 begin    
 select T.TranID,  
 T.TransactionName,  
 isnull(L.LocalDescription,RD.Descriptor) Descriptor  --RD.Descriptor      
 from dbo.RulesTranName as T      
 inner join dbo.RulesTranConfig as RTC    
 on T.TranID=RTC.TranID        
 and (RTC.FeesCategoryID is not null or RTC.TranCommissionGroupID is not null )
 inner join dbo.RulesDescriptor as RD      
 on T.DSC_Description = RD.DescriptorID   
 Left outer JOIN  RulesDescriptorLocal L     
 on L.DescriptorID = RD.DescriptorID   
 and LCID =  @LCID    
 order by RD.Descriptor       
 End    
else IF  @Flag =2    -- Exchange rate
 begin    
 select T.TranID,  
 T.TransactionName,  
 isnull(L.LocalDescription,RD.Descriptor) Descriptor  --RD.Descriptor         
 from dbo.RulesTranName as T      
 inner join dbo.RulesTranConfig as RTC    
 on T.TranID=RTC.TranID        
 and RTC.exchangetype is not null 
 inner join dbo.RulesDescriptor as RD      
 on T.DSC_Description = RD.DescriptorID    
 Left outer JOIN  RulesDescriptorLocal L     
 on L.DescriptorID = RD.DescriptorID   
 and LCID =  @LCID   
 order by RD.Descriptor    
 End    
Else     -- All
begin    
 select T.TranID,  
 T.TransactionName,  
 isnull(L.LocalDescription,RD.Descriptor) Descriptor  --RD.Descriptor        
 from dbo.RulesTranName as T      
 inner join dbo.RulesDescriptor as RD      
 on T.DSC_Description = RD.DescriptorID   
 Left outer JOIN  RulesDescriptorLocal L     
 on L.DescriptorID = RD.DescriptorID   
 and LCID =  @LCID      
 Order by RD.Descriptor    
End    


Go
--End of Automatic Generation
DROP_OLD_PROC 'GetSideMenuXML'
GO
CREATE proc dbo.GetSideMenuXML 
  @AppGroup AppGroup_Name  
 ,@MenuName sysname  
 ,@user_number internal_user_ID  
 ,@Workstation MachineName  
 ,@LCID LanguageLCID = NULL  
 ,@now datetime = NULL  
 ,@Debug int = 0  
AS  
-- Get menu record set for building a menu for a particular user,  
-- with the Enabled column set according to the users roles.  
-- When there is no row in AuthMenuMap for an action, then all users are authorized.  
-- Copyright 1999 - 2001, 2005, 2006, 2008 Getronics USA Inc.  All rights reserved.  
-- Top level menu choices may be more than one character.    
-- These choice characters don't have to be numeric.  
-- Non-numeric MenuKey values are listed after all numeric values on the same level.    
-- Longer non-numeric keys sort last, within parent.  
-- So, for keys 1,2,15, 999, A, B, AAA  
-- you get them in that order, if they all have the same parent.  
-- It will break if you use non-numeric keys longer than 8 characters.  
-- 21NOV06 Bodhi Version 1 from earlier related code.  
-- 23APR07 Joe Tansy and Bodhi - Disable items that are Transactions   
--        that are not in RulesBranchTrans for the Workstation's branch.  
-- 15MAY08 Juan Hdz - Changed to use new Workstations table (instead of workstation) CR15845  
-- 30Jul08 TimG - Replaced RowStatus check with dbo.isRowActive().  
  
/*  
 Developer: Osama Orabi  
 Date:  2011-06-08  
 Reason: this procedure will call Fuction F_GetSideMenuXML_Recursivly   
   all the menu tree as xml  
  
 considertaion :  temp table can not be accessed from fuction so the @m table should be passed on the fuction calling.  
    to pass a table to a fuction, it must be declared as User Defined Table (Valued-Table)   
    so, a new data type was define dbo.T_GetSideMenuXML to be used  
  
-- 01April2012: Osama Orabi: In case the Menu was disabled in table Menu_Action, return it as disabled regardless of the entry in table AuthMenu      
-- 17Oct12 oorabi - solving issue# GFSX01397: always return the max(lastChanged) so the next time the procdure will return the new added entries.
-- 08-11-2012: ADIB on site: oorab: Return menu is enabled in case it is not disabled in menuAction.
   
 Programmer   :Sara Badwy
 CreationDate : 01-20-2019  
 Description  :Defect : GFSX13894  
*/  
  
SET NOCOUNT ON  
declare @m T_GetSideMenuXML  
--table (AppID int, MenuID int  
--, MenuKey nvarchar(12), Parent nvarchar(12)  
--, CaptionID int, Descriptor nvarchar(500)  
--, MenuActionID int, Actiontype int, MenuAction varchar(128)  
--, Enabled bit, Menu_Key_As_NUMBER int, Image nvarchar(128))  
declare @MenuID Menu_ID  
declare @domain as nvarchar(60)  
declare @computer as nvarchar(100), @BrID internal_branch#  
declare @wsBk bankID, @wsRg regionID, @wsBranch branchID  
--Defect : GFSX13894 Begin 
declare @UseMenuCaching BIT=0
declare @content XML
select @UseMenuCaching= usemenucaching,@BrID=BrID from Operator where user_number=@user_number
IF(@UseMenuCaching=1)
BEGIN
select  @content=XMLContent from MenuCaching where MenuName=@MenuName AND UserNumber=@user_number and BrID=@BrID
    IF( DATALENGTH(@content)is not null)
    Begin
     SELECT @content
     return 
     End
END
--Defect : GFSX13894 End 
if @now is null set @now = getdate()  
  
select @MenuID=MenuID from dbo.Menu   (NOLOCK)
where MenuName = @MenuName and AppGroup = @AppGroup  
if (@MenuID is NULL) begin  
 RAISERROR ('MenuName %s, with AppGroup %s is not in Menu Table.'  
 ,11,1, @MenuName, @AppGroup)  
 return 16  
end   
if patindex('%\%', @Workstation) > 0   
begin  
 set @domain = substring(@Workstation, 1, patindex('%\%', @Workstation)-1)  
 set @computer = substring(@Workstation, patindex('%\%', @Workstation)+1, len(@Workstation))  
end else begin  
 set @computer = @Workstation  
end  
-- ** CR14330 ** S  
-- Check if the Workstation is in the Workstation table  
-- and if it is, use its bank, region, branch properties.  
select @BrID = BrID   
from dbo.Workstations W  (NOLOCK)
where Workstation = @computer  -- Workstation column is a unique key.  
  AND W.ExpirationDate > @now and W.EffectiveDate < @Now  
if @@rowcount = 0 Begin  
 raiserror(52771, 16, 1,@Workstation)  
 return -52771  
End  
select @wsBk = Bank, @wsRg = Region, @wsBranch = Branch   
from dbo.Branch_Static  (NOLOCK)
where BrID= @BrID   
  
insert @m  
SELECT DISTINCT MA.AppID, MD.MenuID, MD.MenuKey  
, ISNULL(MD.Parent, '') as Parent -- Substitute empty string for null.  
, MA.CaptionID  
, isNULL(LD.LocalDescription,RD.Descriptor) as Descriptor -- Descriptor is Caption.  
, MA.MenuActionID, MA.ActionType, MA.MenuAction  
, case when MA.Enabled = 0 then 0 else null end as Enabled  
, CASE WHEN isnumeric(MD.MenuKey) = 1   
  THEN Convert(int, MD.MenuKey)   
        ELSE (100 * Len(MD.MenuKey)) +29 -- (Make up some number.)  
  END as Menu_Key_As_NUMBER  
, MA.[Image]   
FROM dbo.Menu_Definition MD		(NOLOCK) 
JOIN dbo.Menu_Action MA			(NOLOCK)
 on MD.MenuID = @MenuID   
 and MA.MenuActionID = MD.MenuActionID   
 -- ** CR17002 ** S  
 and dbo.isRowActiveEx(MD.RowStatus, MD.Created, MD.EffectiveDate,MD.ExpirationDate, @now) = 1  
 and dbo.isRowActiveEx(MA.RowStatus, MA.Created, MA.EffectiveDate, MA.ExpirationDate, @now) = 1  
 -- ** CR17002 ** E  
LEFT OUTER JOIN dbo.RulesDescriptor RD	(NOLOCK)  
  on MA.CaptionID = RD.DescriptorID  
LEFT OUTER JOIN dbo.RulesDescriptorLocal LD		(NOLOCK) 
  on LD.DescriptorID= RD.DescriptorID   
 and LD.LCID = @LCID  
order by Parent, MenuKey  
  
UPDATE @m set Enabled = 1  
where MenuActionID not in (select menuActionID from dbo.AuthMenuMap (NOLOCK))   
and Enabled is null  
  
UPDATE @m set Enabled = 1  
--Mostafa El-Barbary  Fixing Issue #116142  ADIB  Start  
where --(Enabled = 0 or  // 2012-11-08
	Enabled is null--)  
  and MenuActionID in (select menuActionID from dbo.AuthMenuMap  (NOLOCK) 
    where dbo.IsUserInThisRole(@user_number,RoleName,@wsBk,@wsRg,@wsBranch) = 1  
 )   
 --Mostafa El-Barbary  Fixing Issue #116142  ADIB  END  
 --and Enabled is null  
-- ** CR15324 ** S  
-----------------------------------------------  
-- Disable MenuActionIds not found in RulesBranchTrans  
-----------------------------------------------  
DECLARE @actionType int  
SELECT @actionType = MenuActionTypeId FROM dbo.Menu_ActionType WHERE Name = 'TRANS_FUNCTION'  
-------------  
UPDATE @m   
SET  Enabled = 0  
WHERE Enabled = 1   
AND  Actiontype = @actionType  
AND  MenuAction IN  
    (SELECT TransactionName from dbo.RulesTranName T   (NOLOCK)
   -- ** CR17002 ** S  
   WHERE dbo.isRowActive(T.RowStatus, T.Created, T.ExpirationDate, @now) = 1)  
   -- ** CR17002 ** E  
AND  MenuActionID NOT IN  
  (  
   SELECT DISTINCT MA.MenuActionID--, T.TranId, T.*   
   FROM  dbo.Menu_Action MA		(NOLOCK)
   JOIN dbo.Menu_ActionType MAT		(NOLOCK)
     ON MA.ActionType = MAT.MenuActionTypeID  
   JOIN dbo.RulesTranName T		(NOLOCK)
     ON T.TransactionName = MA.MenuAction  
   JOIN dbo.RulesBranchTrans RBT	(NOLOCK)
     ON T.TranId = RBT.TranId  
    AND (RBT.Bank = @wsBk OR RBT.Bank = 0)  
    AND (RBT.Region = @wsRg OR RBT.Region = 0)  
    AND (RBT.Branch = @wsBranch OR RBT.Branch = 0)  
    AND RBT.EffectiveDate <= @now  
    AND RBT.ExpirationDate >= @now  
   --WHERE MA.MenuActionID = M.MenuActionID   
  )  
   
--  Disable all menu Enabled = null after the previous Update Statement.  
UPDATE @m set Enabled = 0  
where Enabled is null  
  
------------------------------------------------------  
-- IF(Debugging) Look at what records SHOULD be enabled because they exist in RulesBranchTrans -- currently there are none  
--     if no record are returned by this query, then no records exist in RulesBranchTrans to enable MenuItems returned by this proc call  
IF(@Debug > 1)  
BEGIN  
   SELECT DISTINCT MA.MenuActionID  
     , MA.MenuAction  
     , T.TranId  
     , MA.ActionType  
     , RBT.ROW_ID  
     , RBT.*   
   FROM  dbo.Menu_Action MA		(NOLOCK) 
   JOIN dbo.Menu_ActionType MAT		(NOLOCK)
     ON MA.ActionType = MAT.MenuActionTypeID  
    AND Actiontype = @actionType  
   JOIN dbo.RulesTranName T		(NOLOCK)
     ON T.TransactionName = MA.MenuAction  
   JOIN dbo.RulesBranchTrans RBT  (NOLOCK)
     ON T.TranId = RBT.TranId  
    AND (RBT.Bank = @wsBk OR RBT.Bank = 0)  
    AND (RBT.Region = @wsRg OR RBT.Region = 0)  
    AND (RBT.Branch = @wsBranch OR RBT.Branch = 0)  
    AND RBT.EffectiveDate <= @now  
    AND RBT.ExpirationDate >= @now  
   JOIN @m M  
     ON M.MenuActionID = MA.MenuActionID  
   ORDER   
      BY MA.MenuActionID  
END  
-----------------------------------------------  
-- ** CR15324 ** E  
/*  
select  
(  
 select   
  cast(MenuID as nvarchar) + '_' + MenuKey as "SubMenu0/@ID"  
  ,MenuKey as "SubMenu0/@MenuKey"  
  ,Descriptor as "SubMenu0/@Caption"  
  ,Actiontype as "SubMenu0/@ActionType"  
  ,MenuAction as "SubMenu0/@Action"  
  ,Enabled as "SubMenu0/@Enabled"  
  ,1 as "SubMenu0/@Visible"  
  ,'' as "SubMenu0/@KeyCode"  
  ,(select cast(MenuID as nvarchar) + '_' + MenuKey as "SubMenu1/@ID"  
   ,MenuKey as "SubMenu1/@MenuKey"  
   ,Descriptor as "SubMenu1/@Caption"  
   ,Actiontype as "SubMenu1/@ActionType"  
   ,MenuAction as "SubMenu1/@Action"  
   ,Enabled as "SubMenu1/@Enabled"  
   ,1 as "SubMenu1/@Visible"  
   ,'' as "SubMenu1/@KeyCode"  
   from @m child  
   where isnull(parent,'') <> '' and child.parent = parentmenu.menukey  
   for xml path(''), type) as "SubMenu0"  
  from (  
    select  MenuID, MenuKey, Descriptor, Actiontype, MenuAction,   
      Enabled, Menu_Key_As_NUMBER  
    from @m   
    where isnull(parent,'') = ''  
    ) parentmenu  
  --order by 2, 3  
  for xml path(''), type  
) as "Menu"  
for xml path(''), root('Menus')  
*/  
--declare @nxxx T_GetSideMenuXML  
--insert into @nxxx (AppID , MenuID , MenuKey , Parent)  
--select 2501 as appID , MenuID , MenuKey , Parent  
--from Menu_Definition  
  
select (  
  select  (  
    select 0 as '@level'  
    ,cast(m1.MenuID as nvarchar) + '_' + m1.MenuKey as "@ID"  
    ,m1.MenuKey as "@MenuKey"  
    ,m1.Descriptor as "@Caption"  
    ,m1.Actiontype as "@ActionType"  
    ,m1.MenuAction as "@Action"  
    ,m1.Enabled as "@Enabled"  
    ,1 as "@Visible"  
    ,'' as "@KeyCode"  
    ,dbo.F_GetSideMenuXML_Recursivly(1,m1.MenuKey,@m) --for XML path(''),type  
    from @m as m1  
    where m1.MenuKey = Menu_Definition.MenuKey  
    for XML path('SubMenu0'),type  
    )   
  from @m as Menu_Definition  
  where isnull(Parent,'') = ''  
  for xml Path(''),Root('Menu'),type  
) for xml path(''), Root('Menus')  
  

GO
USE [Globalfs]
GO
/*
 CreationDate : 01-20-2020     
 Programmer   :Sara Badwy
 Description  :Defect : GFSX13894                         
*/ 
drop_old_proc 'dbo.GetSideMenuXML_Caching'
GO
CREATE proc [dbo].[GetSideMenuXML_Caching]      
  @AppGroup AppGroup_Name        
 ,@MenuName sysname        
 ,@user_number internal_user_ID           
 ,@LCID LanguageLCID = NULL        
 , @xmlcontent xml out
         
AS       
SET NOCOUNT ON        
declare @m T_GetSideMenuXML        
declare @MenuID Menu_ID           
declare  @BrID internal_branch#        
declare @wsBk bankID, @wsRg regionID, @wsBranch branchID        
declare @xx nvarchar(3000) 
declare @now datetime  = getdate()   
   
--if @now is null set @now = getdate()        
        
select @MenuID=MenuID from dbo.Menu   (NOLOCK)      
where MenuName = @MenuName and AppGroup = @AppGroup        

  
select @BrID = BrID         
from Operator  (NOLOCK)      
where user_number= @user_number
       
select @wsBk = Bank, @wsRg = Region, @wsBranch = Branch         
from dbo.Branch_Static  (NOLOCK)      
where BrID= @BrID         
        
insert @m        
SELECT DISTINCT MA.AppID, MD.MenuID, MD.MenuKey       
, ISNULL(MD.Parent, '') as Parent -- Substitute empty string for null.        
, MA.CaptionID        
, isNULL(LD.LocalDescription,RD.Descriptor) as Descriptor -- Descriptor is Caption.        
, MA.MenuActionID, MA.ActionType, MA.MenuAction        
, case when MA.Enabled = 0 then 0 else null end as Enabled        
, CASE WHEN isnumeric(MD.MenuKey) = 1         
  THEN Convert(int, MD.MenuKey)         
        ELSE (100 * Len(MD.MenuKey)) +29 -- (Make up some number.)        
  END as Menu_Key_As_NUMBER        
, MA.[Image]         
FROM dbo.Menu_Definition MD  (NOLOCK)       
JOIN dbo.Menu_Action MA   (NOLOCK)      
 on MD.MenuID = @MenuID         
 and MA.MenuActionID = MD.MenuActionID         
 -- ** CR17002 ** S        
 and dbo.isRowActiveEx(MD.RowStatus, MD.Created, MD.EffectiveDate,MD.ExpirationDate, @now) = 1        
 and dbo.isRowActiveEx(MA.RowStatus, MA.Created, MA.EffectiveDate, MA.ExpirationDate, @now) = 1        
 -- ** CR17002 ** E        
LEFT OUTER JOIN dbo.RulesDescriptor RD (NOLOCK)        
  on MA.CaptionID = RD.DescriptorID        
LEFT OUTER JOIN dbo.RulesDescriptorLocal LD  (NOLOCK)       
  on LD.DescriptorID= RD.DescriptorID         
 and LD.LCID = @LCID        
order by Parent, MenuKey        
        
UPDATE @m set Enabled = 1        
where MenuActionID not in (select menuActionID from dbo.AuthMenuMap (NOLOCK))         
and Enabled is null        
        
UPDATE @m set Enabled = 1              
where     
 Enabled is null--)        
  and MenuActionID in (select menuActionID from dbo.AuthMenuMap  (NOLOCK)       
    where dbo.IsUserInThisRole(@user_number,RoleName,@wsBk,@wsRg,@wsBranch) = 1      
 )             
DECLARE @actionType int        
SELECT @actionType = MenuActionTypeId FROM dbo.Menu_ActionType WHERE Name = 'TRANS_FUNCTION'        
-------------        
UPDATE @m         
SET  Enabled = 0        
WHERE Enabled = 1         
AND  Actiontype = @actionType        
AND  MenuAction IN        
    (SELECT TransactionName from dbo.RulesTranName T   (NOLOCK)      
   -- ** CR17002 ** S        
   WHERE dbo.isRowActive(T.RowStatus, T.Created, T.ExpirationDate, @now) = 1)        
   -- ** CR17002 ** E        
AND  MenuActionID NOT IN        
  (        
   SELECT DISTINCT MA.MenuActionID      
   FROM  dbo.Menu_Action MA  (NOLOCK)      
   JOIN dbo.Menu_ActionType MAT  (NOLOCK)      
     ON MA.ActionType = MAT.MenuActionTypeID        
   JOIN dbo.RulesTranName T  (NOLOCK)      
     ON T.TransactionName = MA.MenuAction        
   JOIN dbo.RulesBranchTrans RBT (NOLOCK)      
     ON T.TranId = RBT.TranId        
    AND (RBT.Bank = @wsBk OR RBT.Bank = 0)        
    AND (RBT.Region = @wsRg OR RBT.Region = 0)        
    AND (RBT.Branch = @wsBranch OR RBT.Branch = 0)        
    AND RBT.EffectiveDate <= @now        
    AND RBT.ExpirationDate >= @now              
  )        
         
--  Disable all menu Enabled = null after the previous Update Statement.        
UPDATE @m set Enabled = 0        
where Enabled is null        
       
     
set @xmlcontent= (
select (  
  select  (  
    select 0 as '@level'  
    ,cast(m1.MenuID as nvarchar) + '_' + m1.MenuKey as "@ID"  
    ,m1.MenuKey as "@MenuKey"  
    ,m1.Descriptor as "@Caption"  
    ,m1.Actiontype as "@ActionType"  
    ,m1.MenuAction as "@Action"  
    ,m1.Enabled as "@Enabled"  
    ,1 as "@Visible"  
    ,'' as "@KeyCode"  
    ,dbo.F_GetSideMenuXML_Recursivly(1,m1.MenuKey,@m) --for XML path(''),type  
    from @m as m1  
    where m1.MenuKey = Menu_Definition.MenuKey  
    for XML path('SubMenu0'),type  
    )   
  from @m as Menu_Definition  
  where isnull(Parent,'') = ''  
  for xml Path(''),Root('Menu'),type  
) for xml path(''), Root('Menus')  )
GO
USE [Globalfs]
GO
/*
 CreationDate : 01-20-2020     
 Programmer   :Sara Badwy
 Description  :Defect : GFSX13894                         
*/ 
drop_old_proc 'dbo.Insert_Menu_Caching'
GO
create proc Insert_Menu_Caching 
as 
begin
declare @menuItem nvarchar(50),@machineName nvarchar(50),@BrID nvarchar(10) 
declare @usernumber [dbo].[internal_user_ID],@LCID INT,@count int, @contentXML XML ,@operatorCount int
DELETE  FROM MenuCaching
Declare @tempContent Table (content nvarchar(max))

SELECT MenuName into #MenuItems FROM menu WHERE MenuID IN (2501,2502,2503)
SELECT 
   ROW_NUMBER() OVER (
 ORDER BY user_number
   ) ID,user_number,Workstation_ID,LanguageLCID,BrID INTO #OpertaorData from Operator where  UseMenuCaching=1 and LanguageLCID is not null
SELECT @operatorCount= COUNT(1) FROM #OpertaorData
while ((SELECT COUNT(1) FROM #MenuItems) >0)
begin
    SELECT TOP(1)@menuItem=#MenuItems.MenuName FROM #MenuItems
    set @count=1
while(@count<=@operatorCount)
Begin   
    select @usernumber=#OpertaorData.user_number,@LCID=#OpertaorData.LanguageLCID ,@BrID=#OpertaorData.BRID from #OpertaorData where ID=@count
    exec GetSideMenuXML_Caching 'Teller',@menuItem,@usernumber,@LCID,@contentXML out  
    if (DATALENGTH(@contentXML)>0)
    insert into MenuCaching values(@usernumber,@BrID,@menuItem,@contentXML)  
    set @count=@count+1  
End
delete top(1) from #MenuItems
end
drop table #OpertaorData
drop table #MenuItems
end

go
drop_old_proc 'AddUpdateEmployee'
go
Create procedure [dbo].[AddUpdateEmployee]      
@LoginID as OperatorID ,      
@BankID as BankID ,      
@RegionID as RegionID ,      
@BranchID as BranchID ,      
@EmployeeID as varchar(16) ,      
@Title as string_30 ,      
@Title_DSC as varchar(30) ,      
@LastName as LastName,      
@FirstName as FirstName ,      
@Middle as MiddleName ,      
@EmailAddress as EmailAddress ,      
@Phone as Phone ,      
@windows_domain as varchar(60),      
@LanguageLCID as LanguageLCID ,     
@UserClassID as user_class_id,      
@UserGroup as int ,   --@TellerLimitCategory as int ,      
@IR_Supervisor as bit ,      
@DenomRequired as bit ,      
@DenomMandetory as bit ,      
@AccountingEntries as bit ,      
@IR_Modifier as bit ,      
@donotcheckpassbookpendingtrn as bit ,      
@DepartmentID as int ,      
@UserLevelID as int ,      
@MrkChkOpt as tinyint ,      
@ScreenLockInterval as int ,      
@NOofFailedTrials as int ,  
@Developer OperatorID      
      
as      
/*      
Creator : Mohamed Kamel       
Date    : 25/10/2009      
Reason  : add/update employee in single admin.      
*/     
/*  
Modifier : Ahmed Helmy  
Date  : 16/05/2012  
Reason   : Add To Get NextUserNumber  
*/  
/*  
Modifier : Mostafa ElBarbary   
Date  : 27/02/2013  
Reason   : Modify The Insert Statemnet and handle the Domain Side (On Site KIB)  
*/  
/*  
Modifier : May Hassan   
Date  : 3/03/2013  
Reason   : CR# 10945 - DTM Enhancement User Definition   
     Updating column UserGroup in table [TellerConfig] with null value     
       
Modifier : Mohammed Farouk  
Date  : 2013-05-19  
Reason   : Defect GFSX04103, correct AddUpdateEmployee Behavior  
  
Modifier : Ahmed Helmy  
Date  : 28-08-2013  
Reason  : Check constrains on operator table before update or insert it. to return to the user readable message.  
  
Modifier : Hatim AlSum   
Date  : 23-12-2013  
Reason  : Remove Paramter @TellerLimitCategory  
     and replace it with @UserGroup  
     Update TellerConfig column UserGroup with Value  
       
Modifier : Mahmoud Kamel   
Date  : 2016-08-14  
Reason  : Issue#GFSX10970 - allow LoginID to be numeric  
  
Modifier :  Mahmoud saad
Date  : 2019-10-16
Reason  :  Issuee #GFSX14024 -Ethix Frame: Teller unable to sent cash to Cash Officer 
*/  
  
declare @NextUserNumber internal_user_ID  
  
 declare @LoginID_Includes_Domain int  
 select @LoginID_Includes_Domain = value from RulesEnvironment where value_name = 'LoginID_Includes_Domain'  
 if (len(@windows_domain) > 0 and @LoginID_Includes_Domain = 1)  
  select @LoginID  = @windows_domain + '\' + @LoginID  
  
SELECT @NextUserNumber =user_number FROM [dbo].[Operator] WHERE [LoginID] =@LoginID    
  
if(@NextUserNumber is null OR @NextUserNumber = 0)  
 select @NextUserNumber =  (max(user_number) + 1) from operator  
   
IF(EXISTS(SELECT [Bank] FROM [dbo].[Branch] WHERE [Bank] = @BankID and [Region] = @RegionID  and [Branch] = @BranchID))  
BEGIN  
begin  
if @EmployeeID is null    
begin    
set @EmployeeID = ''    
end     
    
if @Title is null    
begin    
set @Title = ''    
end     
  
if @Title_DSC = ''  
begin    
set @Title_DSC = null    
end   
    
if @FirstName is null    
begin    
set @FirstName = ''    
end     
    
if @Middle is null    
begin    
set @Middle = ''    
end     
    
if @EmailAddress is null    
begin    
set @EmailAddress = ''    
end    
if @Phone is null    
begin    
set @Phone = ''    
end     
declare @BrId integer     
select @BrId =  dbo.id_of_branch(@BankID,@RegionID,@BranchID)       
------------  
if not(patindex('%[^a-z0-9\_.-]%',@LoginID)=(0))  
begin  
 RaisError('Unrecognized Login ID (%s), Login ID cannot contain special characters',16,-1,@LoginID)  
 return   
end  
-- CK_Operator_LoginID_NOT_Blank  
if not (@LoginID is null OR @LoginID>'')  
begin  
 RaisError('Login ID (%s) cannot be a blank',16,-1,@LoginID)  
 return   
end  
-- CK_Operator_LoginID_Not_Integer  
--ITS Code Start [Mahmoud Kamel - 2016/08/14] Issue#GFSX10970 - remove this block to allow LoginID to be numeric  
/*  
if not ([dbo].[is_integer]([dbo].[simple_name_of_LoginID](@LoginID))=(0))  
begin  
 RaisError('Login ID (%s) cannot be numberic',16,-1,@LoginID)  
 return   
end  
*/  
--ITS Code End [Mahmoud Kamel - 2016/08/14] Issue#GFSX10970 - remove this block to allow LoginID to be numeric  
--  
-- CK_Operator_UserClassID_ZERO_IS_Not_A_VALID_CHOICE  
if not (@UserClassID>(0))  
begin  
 RaisError('User class cannot be blank',16,-1)   
 return   
end  
-- Rules  
-- isValid_user_class_id  
--  Change as needed.  
if not(@UserClassID <= 99 or @UserClassID is null)  
begin  
 RaisError('Only two digits allowed for user class id',16,-1)   
 return   
end  
-- no_new_line_or_tab  
if not (patindex('%['+char(9) + char(10)+char(12)+char(13)+']%',@Title) = 0)  
begin  
 RaisError('Title (%s) cannot contain new line or tab',16,-1,@Title)   
 return   
end  
--------------    
begin tran IF EXISTS(SELECT * FROM [dbo].[Operator] WHERE [LoginID] = @LoginID)           
       BEGIN 
	   if exists (select * from Operator_Status WHERE user_number=@NextUserNumber)
	   BEGIN
		 DELETE FROM Operator_Status WHERE user_number=@NextUserNumber
	   END  
	   UPDATE [dbo].[Operator] SET       
      [BrID]   = @BrId,      
      [EmployeeID] = @EmployeeID,      
      [Title] = @Title,      
      [Title_DSC] = @Title_DSC,      
      [LastName] = @LastName,      
      [FirstName] = @FirstName,      
      [Middle] = @Middle,      
      [EmailAddress] = @EmailAddress,      
      [Phone] = @Phone,      
      [windows_domain] = @windows_domain,      
      [LanguageLCID] = @LanguageLCID,   
      [Updator]=@Developer  
       WHERE [LoginID] = @LoginID      
      
      IF EXISTS(SELECT * FROM [dbo].[Tellers] WHERE [User_Number] = @NextUserNumber)      
       BEGIN       
       UPDATE [Operator] SET [UserClassID] = @UserClassID      
       WHERE [User_Number] = @NextUserNumber       
       END       
      
      If Exists(select * FROM [TellerConfig] WHERE [User_ID] = @NextUserNumber)      
       begin       
       UPDATE [dbo].[TellerConfig] SET [TellerLimitCategory] = NULL  --@TellerLimitCategory    
      ,[IR_Supervisor] = @IR_Supervisor      
      ,[DenomRequired] = @DenomRequired      
      ,[DenomMandetory] = @DenomMandetory      
      ,[AccountingEntries] = @AccountingEntries      
      ,[IR_Modifier] = @IR_Modifier      
      ,[donotcheckpassbookpendingtrn] = @donotcheckpassbookpendingtrn      
      ,[DepartmentID] = @DepartmentID      
      ,[UserLevelID] = @UserLevelID      
      ,[MrkChkOpt] = @MrkChkOpt      
      ,[ScreenLockInterval] = @ScreenLockInterval      
      ,[NOofFailedTrials] = @NOofFailedTrials  
      ,[Updator]   =@Developer  
      ,[UserGroup] = @UserGroup --Null  
       WHERE [User_ID] = @NextUserNumber      
       END       
      
   END       
   ELSE       
   BEGIN INSERT INTO [dbo].[Operator]([LoginID],[BrID],[EmployeeID],[Title],[Title_DSC],[LastName],[FirstName],[Middle],      
      [EmailAddress],[Phone],  
      [windows_domain],[LanguageLCID],[Creator],[Updator],[UserClassID])       
      VALUES (  @LoginID,  
        @BrId,       
        @EmployeeID,      
        @Title,      
        @Title_DSC,      
        @LastName,      
        @FirstName,      
        @Middle,      
        @EmailAddress,      
        @Phone,          
        @windows_domain,      
        @LanguageLCID,  
        @Developer   ,  
        @Developer  ,  
        @UserClassID  
        )        
  
  SELECT @NextUserNumber =user_number FROM [dbo].[Operator] WHERE [LoginID] =@LoginID  
    
     If Not Exists(select * FROM [TellerConfig] WHERE [User_ID] = @NextUserNumber)      
     begin  
  Insert Into [dbo].[TellerConfig]([User_ID],[TellerLimitCategory],[IR_Supervisor],[DenomRequired],[DenomMandetory],[AccountingEntries]  
          ,[IR_Modifier],[donotcheckpassbookpendingtrn],[DepartmentID],[UserLevelID],[MrkChkOpt]  
          ,[ScreenLockInterval],[NOofFailedTrials],[Updator],[UserGroup])  
  Values(@NextUserNumber,/*@TellerLimitCategory*/NULL,@IR_Supervisor,@DenomRequired,@DenomMandetory,@AccountingEntries,      
     @IR_Modifier,@donotcheckpassbookpendingtrn,@DepartmentID,@UserLevelID,@MrkChkOpt,  
     @ScreenLockInterval,@NOofFailedTrials,@Developer,/*NULL*/@UserGroup)  
     END       
   END       
   if @@error<>0 begin rollback tran end else begin commit tran   
   end     
   END  
END   
ELSE     
BEGIN  
RaisError('Bank, Region or Branch does not exist',16,1)  
END  
GO
drop_old_proc 'HCS_ClearDetail_Check'
GO
  
CREATE PROCEDURE HCS_ClearDetail_Check                             
   @ClearBankBranchID varchar(20),                                        
   @BankName varchar(50),                                          
   @BranchName  varchar(35),                                          
   @DateFrom nvarchar(50),                                        
   @DateTo nvarchar(50),                                                                                                                        
   @CashDrawer varchar(10) = '-1',                                                                                                              
   @DepositBranchID varchar(20) = '-1',                                          
   @DepositDateFrom nvarchar(100) = '',                                          
   @DepositDateTo nvarchar(100) = '',                                          
   @ChequeNumber varchar(20) = '-1',                                                         
   @EffectiveDate nvarchar(50) ,                              
   @Created nvarchar(1000),
   @return_val int                                                                                                
AS                                                                                                                                                                   
/*
 CreationDate : 15-12-2016       
 Programmer   : Mostafa Sayed
 Description  : CR#GFSY00614 ADIB_CRQ7501_xp Cmdshell Alternative-  Core System Intregration -                          

 Modification Date:   22/03/2020          
 Modifer:     Sara Badwy
 Modification Reason: Issue#GFSX13986 -INC000000272180 - Out clearing chq settle by file :add status 15 to search criteria.
  
*/                                                               
IF @CashDrawer = ''                                             
 SET @Cashdrawer = '-1'                                                                              
DECLARE @IDs nvarchar(4000)                                          
declare @includeFailedStatus bit =0                                         
SET @IDs = ''                                          
   CREATE TABLE #TempStatus(
 ID int)  
  select @includeFailedStatus =case when Value='true' then 1 else 0 end         
 from RulesTranFldParam          
Where  TranName = 'OutwardClChequeSettlement' And Param = 'IncludeSettelmentFailed'    
  if(@includeFailedStatus=1)
  begin 
  insert into #TempStatus (ID)values (4)
  insert into #TempStatus (ID)values (15)
   end
    else 
    begin
   insert into #TempStatus (ID)values (4) 
   end                                          
IF( lower(@DepositDateFrom) ='')                                          
BEGIN                                          
SELECT  TOP 30 @IDs = @IDs+','+ cast(ID as varchar(20))                                          
 FROM ClearDetail               
 WHERE Status in (select ID from #TempStatus)                                       
  and(ValueDate BETWEEN convert(datetime,@DateFrom) and convert(datetime,@DateTo))                                          
 and  ( lower(@ClearBankBranchID) = '' OR cast(ClearBankBranchID as varchar(20)) = @ClearBankBranchID )                                            
 AND (lower(@DepositBranchID)= '' OR cast(dbo.ClearDetail.Branch as varchar(20)) = @DepositBranchID)                                 
 AND (lower(@ChequeNumber) = '' OR cast(dbo.ClearDetail.ChequeNumber as varchar(20)) = @ChequeNumber )                                     
END   
                                       
ELSE                                          
BEGIN                                          
SELECT  TOP 30 @IDs = @IDs+',' + cast(ID as varchar(20))                                          
 FROM ClearDetail                
 WHERE Status in (select ID from #TempStatus)                                         
 and  ( lower(@ClearBankBranchID) = '' OR cast(ClearBankBranchID as varchar(20))= @ClearBankBranchID)                                           
 and ValueDate BETWEEN convert(datetime,@DateFrom) and convert(datetime,@DateTo)                                          
 AND (lower(@DepositBranchID)= '' OR cast(dbo.ClearDetail.Branch as varchar(20)) = @DepositBranchID)                                 
 AND (dbo.ClearDetail.BusinessDate BETWEEN Convert(datetime, @DepositDateFrom) AND Convert(datetime,@DepositDateTo))                             
 AND (lower(@ChequeNumber) = '' OR cast(dbo.ClearDetail.ChequeNumber as varchar(20)) = @ChequeNumber )                                 
END                                          
                                          
IF(len(@IDs) > 0 and @IDs like ',%')                                          
BEGIN                                          
SET @IDs = substring(@IDs,2,len(@IDs)-1)                                          
END                                                
            
DECLARE @Statement nvarchar(4000)                                          
  print @return_val                                         
                                          
IF(@return_val <> 0)                                          
BEGIN                                                                               
 SELECT                                          
  '-1' as TLR_INWARD_ACCOUNTS1,                                          
  '' as TLR_ACCOUNT_TYPE,                                          
  '' as TLR_OUTWARD_CURRENCY_ARRAY1,                                          
   0 as TLR_CHEQUE_NUMBER_ARRAY1,                                          
  '' as TLR_DRAWER_ACC_NUMBER,                                          
  '' as TLR_CEQUE_DATE_ARRAY1,                                  
  '' as TLR_SC_Cheque_DATE_ARR,                                           
  '' as TLR_IN_CHEQUE_AMOUNT_ARRAY,                                          
  '' as TLR_CLEARING_BANK_NAME_ARRAY1,                                          
  '' as TLR_CLEARING_BRANCH_NAME_ARRAY1,                                          
  '' as TLR_BRANCH_NAME_ARRAY1,                                          
  '' as TLR_OTHER_ACCOUNT_NUMBER_ARRAY1,                                          
  '' as TLR_SHADOW_ACCOUNT_TYPE_ARR,                                          
  '' as TLR_INWARD_CURRENCY_ARRAY1,                                          
  '' as TLR_ACC_APP_TYPE_ARR,                                         
  '' as TLR_SHADOW_APP_TYPE_ARR,                                          
  '' as TLR_ACC_STATUS_ARR,                                          
  '' as TLR_PDC_HOST_TRAN_RESPONSE,                                          
  '' as TLR_PDC_HOST_TRAN_STATUS                                                                             
END
                                          
ELSE                                          
IF( ltrim(rtrim(@IDs)) <> '')                                          
BEGIN                                          
	DECLARE @NoOfRows int                                           
                                       
	IF exists (select *from RulesTranFldParam                                          
	Where  TranName = 'OutwardClChequeSettlement' And Param = 'NoOfRows' )                                      
	begin                                      
                                      
		select @NoOfRows = isnull(convert(int,Value), 30)                                          
		from RulesTranFldParam                                          
		Where  TranName = 'OutwardClChequeSettlement' And Param = 'NoOfRows'                                       
	end                                       
ELSE 
BEGIN                                      
	SET @NoOfRows =30                                       
END                                       

SET @Statement = 'select  top '+ cast(@NoOfRows as nvarchar(10))+                                          
'dbo.ClearDetail.AccountNumber as TLR_INWARD_ACCOUNTS1,                                          
dbo.ClearDetail.AccountType as TLR_ACCOUNT_TYPE,                                          
dbo.ClearDetail.AccountCurrency as TLR_OUTWARD_CURRENCY_ARRAY1,                            
dbo.ClearDetail.ChequeNumber as TLR_CHEQUE_NUMBER_ARRAY1,                                          
dbo.ClearDetail.DrawerAccNumber as TLR_DRAWER_ACC_NUMBER,                                          
dbo.ClearDetail.ValueDate as TLR_CEQUE_DATE_ARRAY1,                                  
dbo.ClearDetail.EffectiveDate as TLR_SC_Cheque_DATE_ARR,                                       
dbo.ClearDetail.ChequeAmount as TLR_IN_CHEQUE_AMOUNT_ARRAY,                                          
'''+@BankName+''' as TLR_CLEARING_BANK_NAME_ARRAY1,                                          
'''+@BranchName+''' as TLR_CLEARING_BRANCH_NAME_ARRAY1,                                          
dbo.ClearDetail.Branch as TLR_BRANCH_NAME_ARRAY1,                                          
dbo.ClearDetail.CustomerShadowAcc as TLR_OTHER_ACCOUNT_NUMBER_ARRAY1,                                          
dbo.ClearDetail.ShadowAccountType as  TLR_SHADOW_ACCOUNT_TYPE_ARR,                                          
dbo.ClearDetail.ShadowAccountCurrency as TLR_INWARD_CURRENCY_ARRAY1,                                          
dbo.ClearDetail.AccountApplictopnType as  TLR_ACC_APP_TYPE_ARR,                                          
dbo.ClearDetail.ShadowAccApplicationType as TLR_SHADOW_APP_TYPE_ARR,                                          
dbo.ClearDetail.AccountStatus as TLR_ACC_STATUS_ARR,                                          
dbo.ClearDetail.HostTranResponse as TLR_PDC_HOST_TRAN_RESPONSE,                                          
dbo.ClearDetail.HostTranStatus as TLR_PDC_HOST_TRAN_STATUS                                     
from ClearDetail                               
where ID in ('+@IDs+')'                                          
                                  
EXEC(@Statement)                                     
                                
END   
GO
drop_old_proc 'HCS_Search_ClearDetails_all'
GO

CREATE PROC [dbo].[HCS_Search_ClearDetails_all]          
--Search_ClearDetails_all 001,'Ba','asd','11/9/2008','11/9/2008',01,'11/9/2008','11/9/2008',123            
        
 @ClearBankBranchID varchar(20),              
 @BankName varchar(50),              
 @BranchName  varchar(35),              
 @DateFrom smalldatetime,               
 @DateTo smalldatetime ,        
 --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
 @DepositBranchID nvarchar(20)  = '',          
 @DepositDateFrom nvarchar(100) = '',          
 @DepositDateTo nvarchar(100)   = '',          
 @ChequeNumber nvarchar(20)     = '',              
 --Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
 --@IDs nvarchar(4000)
 @IDs nvarchar(max)
as              
/*              
 BY : Shimaa Saeed              
 Date : 2005-08-29              
 Reason : select from cleardetails              
              
 BY : alaa zain               
 Date : 2008-04-21              
 Reason : select from cleardetails              
         
 Modification Date:   24/04/2012            
 Modifer:     Asmaa Hafez             
 Modification Reason: Adding parameters '@DepositBranchID, @DepositDateFrom , @DepositDateTo ,@ChequeNumber'         
       - CR # 6772 (Outward Clearing Off Balance) - ADIB Retrofitting
       
 Modification Date:   25/09/2016            
 Modifer:     May Hassan             
 Modification Reason:   Change @ChequeNumber = -1 to @ChequeNumber = convert (varchar,-1) , so that @ChequeNumber will not be casted as integer 
						and throws an error when the ChequeNumber length is greater than 10 - Issue# GFSX10987
 CreationDate		 : 15-12-2016       
 Programmer			 : Mostafa Sayed
 Description		 : CR#GFSY00614 ADIB_CRQ7501_xp Cmdshell Alternative-  Core System Intregration - 
 Modification Reason : Change in selection criteria
 
 Modification Date:   17/12/2018          
 Modifer:     Rokaia Kadry              
 Modification Reason: return ID column issue#GFSX13438 add @IDs to filter by id.  
 
 Modification Date	:[7/08/2019] 
 Modifer			:Mostafa Sayed
 Modification Reason:replace @IDs nvarchar(4000) with @IDs nvarchar(max)
 
 Modification Date:   22/03/2020          
 Modifer:     Sara Badwy
 Modification Reason: Issue#GFSX13986 -INC000000272180 - Out clearing chq settle by file : add status 15 to search criteria.
 
*/              
SET NOCOUNT ON     

-------------------------------  Rokaia Kadry Begin issue#GFSX13438 -------------------------  
	  DECLARE @x XML 
      SELECT @x = CAST('<A>'+ REPLACE(@IDs,',','</A><A>')+ '</A>' AS XML)     
-------------------------------  Rokaia Kadry End issue#GFSX13438 -------------------------
	
declare @NoOfRows int  
declare @includeFailedStatus bit =0
select @NoOfRows = 1000   
select @NoOfRows = convert( nvarchar(10),Value)       
from RulesTranFldParam with(nolock)      
Where  TranName = 'OutwardClChequeSettlement' And Param = 'NoOfRows' And Param = 'NoOfRows' And IsNumeric(Value) = 1     
  
 if(@ChequeNumber='')
 set @ChequeNumber = -1
  CREATE TABLE #TempStatus(
 ID int)   
 select @includeFailedStatus =case when Value='true' then 1 else 0 end         
 from RulesTranFldParam          
Where  TranName = 'OutwardClChequeSettlement' And Param = 'IncludeSettelmentFailed'  
  if(@includeFailedStatus=1)
  begin 
  insert into #TempStatus (ID)values (4)
  insert into #TempStatus (ID)values (15)
   end
    else 
    begin
   insert into #TempStatus (ID)values (4) 
   end                
if (@ClearBankBranchID <>'')              
Begin              
       
    select Top(@NoOfRows) ID,TxnID,ClearBankBranchID,AccountNumber,ChequeNumber,DrawerAccNumber ,ChequeAmount , PrevStatus ,Status , ValueDate , Branch , User_Number , Narrative ,ChequeTypeStatusID , BusinessDate ,RefNo , ClearingCenter , ClearBillNumber ,BatchReferenceNo , SourceOfCheque , Other , PrevValueDate , AfterCutoffTime ,Routing_No , GLNumber , ProviderID , Charges , ForUtilityPayment , ShadowAccountType , CustomerShadowAcc , ShadowAccApplicationType ,AccountType , AccountApplictopnType , AccountCurrency , ShadowAccountCurrency ,AccountStatus , ChequeDate , Creator , HostTranStatus , HostTranResponse ,Send_Host_RefNo , return_code1 , ClearBankName,CustomerReference , EffectiveDate              
    From   ClearDetail             
    Where Status in (select ID from #TempStatus)               
          AND ClearBankBranchID=@ClearBankBranchID              
          AND ValueDate BETWEEN cast(@DateFrom as date) AND CAST( @DateTo  as DATE)        
          --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
          AND (@DepositBranchID ='' OR Branch = @DepositBranchID)        
          AND (@DepositDateFrom ='' OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))             
		  AND (@ChequeNumber = convert (varchar, -1) OR ChequeNumber = @ChequeNumber)    
          --Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
        and ID in ( SELECT t.value('.', 'int') AS inVal  FROM @x.nodes('/A') AS x(T)) -- Rokaia Kadry Begin issue#GFSX13438
End              
Else              
Begin  
              
    select Top(@NoOfRows) ID,TxnID,ClearBankBranchID,AccountNumber,ChequeNumber,DrawerAccNumber ,ChequeAmount , PrevStatus ,Status , ValueDate , Branch , User_Number , Narrative ,ChequeTypeStatusID , BusinessDate ,RefNo , ClearingCenter , ClearBillNumber ,BatchReferenceNo , SourceOfCheque , Other , PrevValueDate , AfterCutoffTime ,Routing_No , GLNumber , ProviderID , Charges , ForUtilityPayment , ShadowAccountType , CustomerShadowAcc , ShadowAccApplicationType ,AccountType , AccountApplictopnType , AccountCurrency , ShadowAccountCurrency ,AccountStatus , ChequeDate , Creator , HostTranStatus , HostTranResponse ,Send_Host_RefNo , return_code1 , ClearBankName,CustomerReference , EffectiveDate             
    From ClearDetail              
    Where Status in (select ID from #TempStatus)              
  AND ValueDate BETWEEN cast(@DateFrom as date) AND CAST( @DateTo  as DATE)  
  --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
  AND (@DepositBranchID ='' OR Branch = @DepositBranchID)      
  AND (@DepositDateFrom ='' OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))    
  AND (@ChequeNumber = convert (varchar,-1) OR ChequeNumber = @ChequeNumber)  
    
  --Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)] 
  and ID in ( SELECT t.value('.', 'int') AS inVal  FROM @x.nodes('/A') AS x(T)) -- Rokaia Kadry Begin issue#GFSX13438
            
END 
GO
drop_old_proc 'Search_ClearDetails'
GO
CREATE PROC dbo.Search_ClearDetails  --                
  @ClearBankBranchID varchar(20),                  
  @BankName varchar(50),                  
  @BranchName  varchar(35),                  
  @DateFrom smalldatetime,                   
  @DateTo smalldatetime  ,              
   --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
  @DepositBranchID BranchID = -1,                  
  @DepositDateFrom nvarchar(100) = '',                  
  @DepositDateTo nvarchar(100) = '',                  
  @ChequeNumber decimal(15, 0) = -1,
  --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)] 
  @currency CurrencyType
                          
as                  
/*                  
 BY : Shimaa Saeed                  
 Date : 2005-08-29                  
 Reason : select from cleardetails                 
               
 Modification Date:   24/04/2012                  
 Modifer:     Asmaa Hafez                   
 Modification Reason: Adding parameters '@DepositBranchID, @DepositDateFrom , @DepositDateTo ,@ChequeNumber'               
       - CR # 6772 (Outward Clearing Off Balance) - ADIB Retrofitting             
               
 Modification Date:   29/04/2012                  
 Modifer:     Asmaa Hafez                   
 Modification Reason: select effective date         
       - CR # 9014 (Amend Effective date to be next valid Effective Date) - ADIB Retrofitting           
  
 Modification Date:   29/09/2012                  
 Modifer:     Lamiaa Mostafa                  
 Modification Reason: Fixing Issue #GFSX01318 -  return EffectiveDate column with default value and in datetime datatype. 
     
 Modification Date:   21/1/2016                
 Modifer:     Moataz Mahsoub 
 Version #1812                 
 Modification Reason: return EffectiveDate column with value From ClearDetail Table.   
 
 Modification Date:   17/12/2018          
 Modifer:     Rokaia Kadry              
 Modification Reason: return ID column issue#GFSX13438.  
 
 Modification Date:   21/11/2019          
 Modifer:     Mostafa Sayed
 Modification Reason: Issue#GFSX13859 - add currency filed to search criteria.
 
 
 Modification Date:   19/03/2020          
 Modifer:     Sara Badwy
 Modification Reason: Issue#GFSX13986 -INC000000272180 - Out clearing chq settle by file : add status 15 to search criteria.
      
*/                  
SET NOCOUNT ON       
         
declare @NoOfRows int
declare @includeFailedStatus bit =0
 CREATE TABLE #TempStatus(
 ID int)        
select @NoOfRows=1000         
select @NoOfRows = convert( nvarchar(10),Value)          
from RulesTranFldParam          
Where  TranName = 'OutwardClChequeSettlement' And Param = 'NoOfRowsProcess'           
 select @includeFailedStatus =case when Value='true' then 1 else 0 end         
 from RulesTranFldParam          
Where  TranName = 'OutwardClChequeSettlement' And Param = 'IncludeSettelmentFailed'     
  if(@includeFailedStatus=1)
  begin 
  insert into #TempStatus (ID)values (4)
  insert into #TempStatus (ID)values (15)
   end
    else 
    begin
   insert into #TempStatus (ID)values (4) 
   end             
if (@ClearBankBranchID <>'')                  
Begin            
    select Top (@NoOfRows)      
            AccountNumber,                  
            AccountType,                  
            AccountCurrency,                  
            ChequeNumber,                  
            DrawerAccNumber,                  
            ValueDate,             
           -- convert(varchar, '1900-08-28 00:00:00', 103) as EffectiveDate,  
            EffectiveDate,                 
            ChequeAmount,                  
            @BankName,                  
            @BranchName,                  
            Branch,                  
            CustomerShadowAcc,                  
            ShadowAccountType,                  
            ShadowAccountCurrency,                  
            AccountApplictopnType,                  
            ShadowAccApplicationType,                  
            AccountStatus ,  
            HostTranResponse,            
            HostTranStatus,
            [ID]
                          
                  
    From   ClearDetail                  
    Where Status in (select ID from #TempStatus)              
          AND ClearBankBranchID=@ClearBankBranchID                  
          AND ValueDate BETWEEN @DateFrom AND @DateTo                
          -- Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
          AND (@DepositBranchID = -1 OR Branch = @DepositBranchID)               
          AND ((@DepositDateFrom = '') OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))              
          AND (@ChequeNumber = -1 OR ChequeNumber = @ChequeNumber)              
          -- Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]
          AND (@currency = '' OR AccountCurrency = @currency)
     End
                 
                  
                  
Else 
 Begin                  
    select Top (@NoOfRows)       
            AccountNumber,               
            AccountType,                  
            AccountCurrency,                
            ChequeNumber,                  
            DrawerAccNumber,                  
            ValueDate,                
            --convert(varchar, '1900-08-28 00:00:00', 103)  as EffectiveDate, 
            EffectiveDate,                    
            ChequeAmount,                  
            @BankName,                  
            @BranchName,                  
            Branch,                  
            CustomerShadowAcc,                  
            ShadowAccountType,                 
            ShadowAccountCurrency,                  
            AccountApplictopnType,                  
            ShadowAccApplicationType,                  
            AccountStatus   ,            
            HostTranResponse,            
            HostTranStatus,
            [ID]  
                     
               
    From ClearDetail                  
    Where Status  in (select ID from #TempStatus)                 
          AND ValueDate BETWEEN @DateFrom AND  @DateTo                
          -- Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
          AND (@DepositBranchID = -1 OR Branch = @DepositBranchID)               
          AND ((@DepositDateFrom = '') OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))              
          AND (@ChequeNumber = -1 OR ChequeNumber = @ChequeNumber)              
          --  Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]
          AND (@currency = '' OR AccountCurrency = @currency)
     End
        
Go
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 Proc Script - dbo.AMLInfo_InsertAndUpdate'
GO

drop_old_proc 'AMLInfo_InsertAndUpdate'
GO
create proc dbo.AMLInfo_InsertAndUpdate
@Mode						int, -- 0 for insert , 1 for update AML Data , 2 for update Rim Data
@ReferenceNumber			ReferenceNumber		= NULL,
@IsPersonal					bit					= NULL,
@ClientName					varchar(80)			= NULL,
@TelephoneNumber			varchar(20)			= NULL,
@PlaceOfBirth				char(5)				= NULL,
@DateOfBirth				datetime			= NULL,
@Nationality				int					= NULL,
@CountryOfIncorporation		char(5)				= NULL,
@Country					char(5)				= NULL,
@PostalCode					varchar(10)			= NULL,
@AddressLine1				varchar(40)			= NULL,
@AddressLine2				varchar(40)			= NULL,
@Governorate				int					= NULL,
@IDType						int					= NULL,
@IDNumber					varchar(25)			= NULL,
@IssueDate					datetime			= NULL,
@ExpirationDate				datetime			= NULL,
@CountryOfIssuance			char(5)				= NULL,
@DateOfUpdate				datetime			= NULL,
@AMLReferenceID				varchar(16)			= NULL,
@RiskRating					varchar(20)			= NULL,
@OpeningStatus				varchar(40)			= NULL,
@RimCreated					bit					= NULL,
@CardReaderLogId			int					= NULL,
@TransactionType			TransactionName		= NULL,
@ResidencyStatus			varchar(20)			= NULL,
@RimClass					int					= NULL,
@RimNumber					varchar(max)		= NULL,
@AccountNumber				varchar(max)		= NULL,
@AccountType				varchar(max)		= NULL,
@Occupation					int					= NULL,
@IsPEP						bit					= NULL,
@NationalityCode			varchar(100)		= NULL,
@EconomicSector				varchar(max)		= NULL,
@BusinessDomain				char(1)				= NULL,
@ProductAndSerivce			char(2)				= NULL,
@RequestID					varchar(max)		= NULL
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[11/05/2020]		
	Reason		:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
	Description	:	Insert and Update table AML_Info
*/     

IF @Mode = 0
	BEGIN
		IF NOT EXISTS(SELECT * FROM AML_Info WHERE ReferenceNumber = @ReferenceNumber)
			BEGIN
				Insert Into AML_Info(ReferenceNumber,IsPersonal,ClientName,TelephoneNumber,PlaceOfBirth,DateOfBirth,Nationality,CountryOfIncorporation,Country,PostalCode,AddressLine1,AddressLine2,Governorate,IDType,IDNumber,IssueDate,ExpirationDate,CountryOfIssuance,DateOfUpdate,AMLReferenceID,RiskRating,OpeningStatus,RimCreated,CardReaderLogId,TransactionType,ResidencyStatus,RimClass,RimNumber,AccountNumber,AccountType,Occupation,IsPEP,NationalityCode,EconomicSector,BusinessDomain,ProductAndSerivce,RequestID)
				Values (@ReferenceNumber,@IsPersonal,@ClientName,@TelephoneNumber,@PlaceOfBirth,@DateOfBirth,@Nationality,@CountryOfIncorporation,@Country,@PostalCode,@AddressLine1,@AddressLine2,@Governorate,@IDType,@IDNumber,@IssueDate,@ExpirationDate,@CountryOfIssuance,@DateOfUpdate,@AMLReferenceID,@RiskRating,@OpeningStatus,@RimCreated,@CardReaderLogId,@TransactionType,@ResidencyStatus,@RimClass,@RimNumber,@AccountNumber,@AccountType,@Occupation,@IsPEP,@NationalityCode,@EconomicSector,@BusinessDomain,@ProductAndSerivce,@RequestID)
			END		
	END
ELSE IF @Mode = 1
	BEGIN
		UPDATE AML_Info
			SET 
				AMLReferenceID	= CASE WHEN @AMLReferenceID IS NULL THEN AMLReferenceID ELSE @AMLReferenceID END   
				,RiskRating		= CASE WHEN @RiskRating IS NULL THEN RiskRating ELSE @RiskRating END 
				,OpeningStatus	= CASE WHEN @OpeningStatus IS NULL THEN OpeningStatus ELSE @OpeningStatus END 
				,RimCreated		= CASE WHEN @RimCreated IS NULL THEN RimCreated ELSE @RimCreated END 
				,RimNumber		= CASE WHEN @RimNumber IS NULL THEN RimNumber ELSE @RimNumber END  
				,AccountNumber	= CASE WHEN @AccountNumber IS NULL THEN AccountNumber ELSE @AccountNumber END  
				,AccountType	= CASE WHEN @AccountType IS NULL THEN AccountType ELSE @AccountType END  
				WHERE RequestID	= @RequestID
	END

IF(@@error<>0)            
     BEGIN            
		RETURN -1          
     END  
ELSE          
     BEGIN              
		RETURN 1     
     END            
GO

PRINT 'End... Script for CR# GFSY00793 Proc Script - dbo.AMLInfo_InsertAndUpdate'
GO
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 Proc Script - dbo.GetAMLPendingRequests'
GO

drop_old_proc 'GetAMLPendingRequests'
GO
create proc dbo.GetAMLPendingRequests
@IDType				int				= NULL,
@IDNumber			varchar(25)		= NULL,
@TransactionType	TransactionName	= NULL,
@Status				varchar(100)	= NULL
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[11/05/2020]		
	Reason		:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
	Description	:	Get AML Pending Requests
*/          

SELECT RequestID AS 'RequestID' FROM AML_Info WHERE IDType = @IDType AND IDNumber = @IDNumber AND TransactionType = @TransactionType AND OpeningStatus = @Status

GO

PRINT 'End... Script for CR# GFSY00793 Proc Script - dbo.GetAMLPendingRequests'
GO
--==================================================================================================================================================================
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 Proc Script - dbo.Select_AML_CustomerTypeMapping'
GO

drop_old_proc 'Select_AML_CustomerTypeMapping'
GO
create proc dbo.Select_AML_CustomerTypeMapping
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[11/05/2020]		
	Reason		:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
	Description	:	SELECT data FROM AML_CustomerTypeMapping table 
*/          

SELECT * FROM AML_CustomerTypeMapping 

GO

PRINT 'End... Script for CR# GFSY00793 Proc Script - dbo.Select_AML_CustomerTypeMapping'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 Proc Script - dbo.Select_AML_NationalityMapping'
GO

drop_old_proc 'Select_AML_NationalityMapping'
GO
create proc dbo.Select_AML_NationalityMapping
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[11/05/2020]		
	Reason		:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
	Description	:	SELECT data FROM AML_NationalityMapping table 
*/          

SELECT * FROM AML_NationalityMapping 

GO

PRINT 'End... Script for CR# GFSY00793 Proc Script - dbo.Select_AML_NationalityMapping'
GO
   

drop_old_proc 'SelectAML_Info_OnBoard'

GO

CREATE PROCEDURE dbo.SelectAML_Info_OnBoard
 

@AMLReferenceID varchar(16) = null,  

@IsPersonal   bit = null,        

@ClientName   varchar(80) = null,        

@TelephoneNumber varchar(20) = null,        



@IDNumber   varchar(25) = null,  

@OpeningStatus      varchar(40) = null,  

@RimCreated   bit = null     ,

@IDType int = null,

@TransactionType varchar(40)='All',

@RimNumber varchar(max) = null

AS             

/*         

/*Version 2.00.46.13.01 Modification Date : 20140922*/               

 CreationDate: 22/09/2014              

 OriginalName: dbo.SelectAML_Info_OnBoard              

 Programmer:  Mostafa Helmy             

 Description: Select from table AML_Info                     

 Reason:   Barwa  Ethix Branch Integration With AML (GFSY00793) 

 */              

SET NOCOUNT ON                 

             

SELECT ReferenceNumber    

      ,IsPersonal  

      ,ClientName    

      ,TelephoneNumber   

      ,PlaceOfBirth 

      ,DateOfBirth  

	  ,Nationality  

      ,CountryOfIncorporation  

      ,Country  

      ,PostalCode  

      ,AddressLine1  

      ,AddressLine2  

      ,Governorate  

      ,IDType  

      ,IDNumber  

      ,IssueDate  

      ,ExpirationDate  

      ,CountryOfIssuance  

      ,DateOfUpdate 

      ,AMLReferenceID   

      ,RiskRating    

      ,OpeningStatus   

	  ,RimCreated

      ,CardReaderLogID
	   
	 ,TransactionType,
	 
	 RimClass,
	 
	 RimNumber,
	 
	 AccountNumber,
	 
	 AccountType,
	 
	 Occupation,
	 
	 IsPEP,
	 
	 NationalityCode,
	 
	 EconomicSector,
	 
	 BusinessDomain,
	 
	 ProductAndSerivce,
	 
	 RequestID,

	 ResidencyStatus

       

  FROM AML_Info      

  where (@AMLReferenceID is null or AMLReferenceID = @AMLReferenceID)   

    and (@IsPersonal is null or IsPersonal = @IsPersonal )     

    and (@ClientName is null or ClientName like '%'+@ClientName+'%' )    

    and (@TelephoneNumber is null or TelephoneNumber = @TelephoneNumber )   

    and ((@IDNumber is null and @IDType is null ) or (IDNumber = @IDNumber and IDType=@IDType))

    and (@OpeningStatus is null or  Charindex(','+OpeningStatus+',', @OpeningStatus) > 0)   

    and (@RimCreated is null or RimCreated = @RimCreated ) 
	
	and(@TransactionType='All' or TransactionType=@TransactionType)   

	and(@RimNumber is null or RimNumber =@RimNumber)

ORDER  BY  ReferenceNumber   
GO
drop_old_proc 'HCS_Update_outrejectedcheque'
go
CREATE proc  HCS_Update_outrejectedcheque  -- HCS_Update_outrejectedcheque '001OR00001120',1526    
 @FileRefNo nvarchar(max) ,
 @UserID int 
as        
    
/*        
CreationDate: 2012-05-07       
Programmer:  osama nabil       
Description: update AutoDebit table which accessed by pkg_AutoDebit       
Output:              
      
Programmer	: Ahmed Osman     
Description	: Check if the matched cheques count in outrejectedcheques table match the same cheques count in ClearDetail table,
				1. in case not matched that mean that the update query will update wrong data, so return null to stop loading file
				2. in case matching, complete the update query
Date		: 16-03-2020
Reason		: Issue No.GFSX13981 
*/    
  
begin        
 
declare @LoadedChqs int     
declare @MatchedChqs int    
declare @TotalAmt money     

DECLARE  @ClearDetailCount int
 
Update outrejectedcheques 
set outrejectedcheques.ClearBankBranchID=CD.ClearBankBranchID,
outrejectedcheques.ChequeAmount=CD.ChequeAmount,
outrejectedcheques.CustomerAccNumber=CD.AccountNumber,
outrejectedcheques.CustomerShadowAcc=CD.CustomerShadowAcc,
outrejectedcheques.ShadowAccountCurrency=CD.ShadowAccountCurrency,
outrejectedcheques.ShadowAccountType=CD.ShadowAccountType,
outrejectedcheques.GLNumber=CD.GLNumber,
outrejectedcheques.DrawerAccNumber=CD.DrawerAccNumber
from  outrejectedcheques outrejectedcheques,
 ClearDetail CD,ClearBankBranch CBB
WHERE outrejectedcheques.ClearBankCode=CBB.ClearBankCode
AND outrejectedcheques.ClearBranchCode=CBB.ClearBranchCode
And CD.ClearBankBranchID=CBB.ClearBankBranchID
and CD.ChequeNumber=outrejectedcheques.ChequeNumber
AND CD.Status=4
AND outrejectedcheques.FileReferenceNumber=@FileRefNo    
end  

 
 select @LoadedChqs=count(ChequeNumber) FROM OutRejectedCheques WHERE FileReferenceNumber=@FileRefNo    
 select @TotalAmt=SUM(ChequeAmount) FROM OutRejectedCheques WHERE FileReferenceNumber=@FileRefNo    
    
 
 UPDATE outrejectedcheques       
 SET status=3    
 WHERE FileReferenceNumber=@FileRefNo     
 AND  UserID=@UserID    
 AND NOT EXISTS((select 1 from ClearBankBranch CBB where CBB.ClearBankCode=outrejectedcheques.ClearBankCode AND CBB.ClearBranchCode=outrejectedcheques.ClearBranchCode))    
 AND outrejectedcheques.Status=0    
    
 UPDATE outrejectedcheques       
 SET status=4    
 WHERE FileReferenceNumber=@FileRefNo     
 AND  UserID=@UserID    
 AND NOT EXISTS((select 1 from ClearDetail CD where   CD.Status=4 AND CD.ChequeNumber=outrejectedcheques.ChequeNumber     
      AND CD.ClearBankBranchID=outrejectedcheques.ClearBankBranchID     
         ))    
 AND outrejectedcheques.Status=0    
    
select @MatchedChqs=count(outrejectedcheques.ChequeNumber)     
     from  outrejectedcheques outrejectedcheques    
     WHERE FileReferenceNumber=@FileRefNo AND Status=0 and processed=0     
    
SELECT @ClearDetailCount = count(*) FROM outrejectedcheques outrejectedcheques, ClearDetail CD, ClearBankBranch CBB
	WHERE outrejectedcheques.ClearBankCode = CBB.ClearBankCode
		AND outrejectedcheques.ClearBranchCode = CBB.ClearBranchCode
		AND CD.ClearBankBranchID = CBB.ClearBankBranchID
		AND CD.ChequeNumber = outrejectedcheques.ChequeNumber
		AND CD.STATUS = 4
		AND outrejectedcheques.FileReferenceNumber = @FileRefNo
		AND outrejectedcheques.STATUS = 0 
		AND outrejectedcheques.processed = 0 

IF(@MatchedChqs <> @ClearDetailCount)
BEGIN
	return NULL
END 
   
select @LoadedChqs loadedCheques ,@MatchedChqs MatchedCheques, isnull( @TotalAmt,0.0) TotalAmount       

GO
drop_old_proc 'Select_Addresses_For_SO'
GO
CREATE proc dbo.Select_Addresses_For_SO    
    @BankID     int = -1,    
    @BranchID   int = -1,
    @SwiftCode nvarchar(max) = null    
    
as    
/*    
CreationDate: 2005-03-26    
OriginalName: dbo.Select_Addresses_For_SO    
Programmer: Ahmed Fahim    
Description: Select the correspndent bank address     
Output:      
Assumption:     
    
ModifiedDate: 04-05-2008  
Modifer:    mahmoud abdelwahed  
ModifyReason:   performance tuning  

ModifiedDate: 18-02-2020  
Modifer		: Ahmed Osman	 
ModifyReason: Issue GFSX13952 - Search with swift code in case it sent , otherwise search with bank id 
*/    
    
set nocount on    
    IF(@SwiftCode is null)
    BEGIN 
		if @BranchID = -1    
			begin    
				select  add_ln1 , add_ln2, add_ln3 , country_code , city_code    
				from    dbo.ad_gb_corres_bks    
				where   bank_id = @BankID    
    
			end    
		else    
			begin    
				select  add_ln1 , add_ln2, add_ln3 , country_code , city_code    
				from    dbo.ad_gb_corres_br    
				where   bank_id = @BankID    
				and     branch_id = @BranchID    
			end    
    end
    else
    begin 
			select  add_ln1 , add_ln2, add_ln3 , country_code , city_code    
			from    dbo.ad_gb_corres_bks  
			where Swift_code = @SwiftCode
			UNION 
			select  add_ln1 , add_ln2, add_ln3 , country_code , city_code    
			from    dbo.ad_gb_non_corres_bks  
			where Swift_code = @SwiftCode
    end
GO
 drop_old_proc 'dbo.Sel_CashDrawerDefinitions'
 go
  
create Proc dbo.Sel_CashDrawerDefinitions    
/*    
 Creator : Hassan E. Halim    
 Date  : 2010-04-13    
 Reason  : used to select all available drawer types defined in table CashDrawerDefinition.    
     
 Modifier : Aya Mahmoud
 Date  :    2014-04-07
 Reason  :  Fix issue# GFSX06981

 Modifier : Mostafa Helmy
 Date : 15-03-2020
 Reason: Fix issue GFSX13973
     
 */    
 @LCID int =1033
as    

begin    
if(@LCID = 1033)
begin
 select DrawerType,'' as LocalDescription    

    from CashDrawerDefinition  

    order by DrawerType asc  
End
else		
begin
select CD.DrawerType as DrawerType   ,RDL.LocalDescription 

    from CashDrawerDefinition  CD inner join RulesDescriptor RD on CD.DrawerType=RD.Name
	left join RulesDescriptorLocal RDL on RD.DescriptorID = RDL.DescriptorID
	and RDL.LCID=@LCID
    order by DrawerType asc
end
end    
GO
 drop_old_proc 'dbo.SelectAML_Info_OnBoard'
 go 

Create PROC dbo.SelectAML_Info_OnBoard  
/*    
 Creator : Mostafa Helmy   
 Date  : 10-06-2020
 Reason  :#GFSY00793 used to search in AML_Info Table in case of  using AML On Boarding Web Service.    
 */
@AMLReferenceID varchar(16) = null,  

@IsPersonal   bit = null,        

@ClientName   varchar(80) = null,        

@TelephoneNumber varchar(20) = null,        



@IDNumber   varchar(25) = null,  

@OpeningStatus      varchar(40) = null,  

@RimCreated   bit = null     ,

@IDType int = null,

@TransactionType varchar(40)='All',

@RimNumber varchar(max) = null

AS             

/*         

/*Version 2.00.46.13.01 Modification Date : 20140922*/               

 CreationDate: 22/09/2014              

 OriginalName: dbo.SelectAML_Info_OnBoard              

 Programmer:  Mostafa Helmy             

 Description: Select from table AML_Info                     

 Reason:   Barwa  Ethix Branch Integration With AML (GFSY00793) 

 */              

SET NOCOUNT ON                 

             

SELECT ReferenceNumber    

      ,IsPersonal  

      ,ClientName    

      ,TelephoneNumber   

      ,PlaceOfBirth 

      ,DateOfBirth  

	  ,Nationality  

      ,CountryOfIncorporation  

      ,Country  

      ,PostalCode  

      ,AddressLine1  

      ,AddressLine2  

      ,Governorate  

      ,IDType  

      ,IDNumber  

      ,IssueDate  

      ,ExpirationDate  

      ,CountryOfIssuance  

      ,DateOfUpdate 

      ,AMLReferenceID   

      ,RiskRating    

      ,OpeningStatus   

	  ,RimCreated

      ,CardReaderLogID
	   
	 ,TransactionType,
	 
	 RimClass,
	 
	 RimNumber,
	 
	 AccountNumber,
	 
	 AccountType,
	 
	 Occupation,
	 
	 IsPEP,
	 
	 NationalityCode,
	 
	 EconomicSector,
	 
	 BusinessDomain,
	 
	 ProductAndSerivce,
	 
	 RequestID,

	 ResidencyStatus

       

  FROM AML_Info      

  where (@AMLReferenceID is null or AMLReferenceID = @AMLReferenceID)   

    and (@IsPersonal is null or IsPersonal = @IsPersonal )     

    and (@ClientName is null or ClientName like '%'+@ClientName+'%' )    

    and (@TelephoneNumber is null or TelephoneNumber = @TelephoneNumber )   

    and ((@IDNumber is null and @IDType is null ) or (IDNumber = @IDNumber and IDType=@IDType))

    and (@OpeningStatus is null or  Charindex(','+OpeningStatus+',', @OpeningStatus) > 0)   

    and (@RimCreated is null or RimCreated = @RimCreated ) 
	
	and(@TransactionType='All' or TransactionType=@TransactionType)   

	and(@RimNumber is null or RimNumber =@RimNumber)

ORDER  BY  ReferenceNumber   
GO
--Programmer :	Ahmed Osman
--Date       :	[08/07/2019]		
--Reason     :	CR#GFSY00761 - BIsB_ACM16832_Customer Balances Audit Trail
--=========================================================================
PRINT 'Start. Script for CR# GFSY00761 Proc Script -- TLR_DeleteBalanceAudit_SpecifyTrans'
GO

drop_old_proc 'TLR_DeleteBalanceAudit_SpecifyTrans'
GO
create  Proc dbo.TLR_DeleteBalanceAudit_SpecifyTrans
@RimsDT			RimsTable READONLY,
@ChargesAcctsDT	ChargesAccountsTable READONLY,
@RefNo			nvarchar(max),
@Rim_Cr			nvarchar(max),
@Rim_Dr			nvarchar(max)
as                

/*
 CreationDate	:	[08/07/2019]       
 Programmer		:	Ahmed Osman
 Description	:	Delete From Table BalanceAuditTrails - CR#GFSY00761
*/   

DECLARE @RimNo nvarchar(max) , @ChargeAcct nvarchar(max) 

SELECT * INTO #RimsTemp from @RimsDT
SELECT * INTO #ChargesAcctsTemp from @ChargesAcctsDT

IF(@Rim_Cr IS NOT NULL)
	BEGIN
		DELETE FROM BalanceAuditTrails WHERE RefNo = @RefNo AND RimNo = @Rim_Cr
	END

IF(@Rim_Dr IS NOT NULL)
	BEGIN
		DELETE FROM BalanceAuditTrails WHERE RefNo = @RefNo AND RimNo = @Rim_Dr
	END

WHILE (SELECT Count(*) FROM #RimsTemp) > 0
	BEGIN
		SET @RimNo = NULL
		
		SELECT DISTINCT TOP 1 @RimNo = RimNo FROM #RimsTemp

		DELETE FROM BalanceAuditTrails WHERE RefNo = @RefNo AND RimNo = @RimNo

		Delete #RimsTemp Where RimNo = @RimNo
	END

WHILE (SELECT Count(*) FROM #ChargesAcctsTemp) > 0
	BEGIN
		SET @ChargeAcct = null
		
		SELECT DISTINCT TOP 1 @ChargeAcct = AccountNo FROM #ChargesAcctsTemp

		DELETE FROM BalanceAuditTrails WHERE RefNo = @RefNo AND AccountNo = @ChargeAcct

		Delete #ChargesAcctsTemp Where AccountNo = @ChargeAcct
	END

IF OBJECT_ID('tempdb..#RimsTemp') IS NOT NULL DROP TABLE #RimsTemp
IF OBJECT_ID('tempdb..#ChargesAcctsTemp') IS NOT NULL DROP TABLE #ChargesAcctsTemp

GO

PRINT 'End... Script for CR# GFSY00761 DML Script -- TLR_DeleteBalanceAudit_SpecifyTrans'
GO

--Devolper	:	Ahmed Osman
--Date		:	[10/02/2020]		
--Reason	:	Issue#GFSX13935 - BDL - UAT - Sold Remittance reversal issue
--==============================================================================
drop_old_proc 'CheckRemittanceStatus'
go
create proc dbo.CheckRemittanceStatus	--CheckRemittanceStatus  '001BR00001320'
 @ReferenceNO  varchar(max) 
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[10/02/2020]		
	Reason		:	Issue#GFSX13935 - BDL - UAT - Sold Remittance reversal issue    
*/    
        
set nocount on        
        
SELECT Status FROM SoldRemittance WHERE ReferenceNO = @ReferenceNO
        
set nocount off        
GO
    
  


drop_old_proc 'SelSolidRemittanceData'
GO
CREATE   procedure   [dbo].[SelSolidRemittanceData]  -- SelSolidRemittanceData '',2,'Pay','','' ,'' 
@BenefName nvarchar (200) ,  
@TranMode int    = 1 ,  
@TranAction varchar(10)='',  
@ClearBank varchar(5)='' ,  
@ClearBranch varchar(5)='',
@ReferenceNo  varchar(50) = ''

as  
  
/*  
CreationDate: 2008-10-21  
OriginalName: dbo.SelSolidRemittanceData  
Programmer: Shimaa Saeed  
Description: select from SelSolidRemittanceData  
Output:    
Assumption:   

Modify Date	:	2011-10-25  
Modifier	:	Mohammed Farouk
Reason		:	G8 Porting, Add Reference Number,Security Question and Secuirty Answer to result set


Modify Date	:	2016-07-19  
Modifier	:	Ahmed Abd Elhakeem
Reason		:	Update new coulmn (BeneficiaryPhone)

Modify Date	:	26/02/2020
Modifier	:	Ahmed Osman
Reason		:	Issue GFSX13945 | BDL - UAT - Layout Issue [returen '' in case SerialNO = -1 else return SerialNO and change datetime format of IssueDate column]
*/  
  
set nocount on  
if (@TranMode =1) --Local Bank  
BEGIN  
	if (@TranAction='Verify')  
	BEGIN  
		SELECT
		CASE
			WHEN s.SerialNO = -1 THEN ''
			ELSE s.SerialNO
		END AS 'SerialNO'
		,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
		,s.IssuerName
		,s.RemittanceAmount
		,s.RemittanceCurrency  
		,s.BeneficiaryName  
		,s.BeneficiaryIDType  
		,s.BeneficiaryIDNumber  
		,s.Notes  
		,s.IssuerBranch  
		,s.PaymentClearBankID  
		,s.PaymentClearBranchID  
		,s.PaymentClearGL
		,s.ReferenceNO
		,s.SecurityQuestion  
		,s.SecurityAnswer
        ,s.BeneficiaryPhone
		from    dbo.SoldRemittance as s   
		where   s.BeneficiaryName like '%'+@BenefName+'%'
		and		s.ReferenceNO like '%'+@ReferenceNo+'%'
		and s.Status='Issued'  
		and s.ToLocalBank=1  
		and s.IsExternalIssued=0  
		and(@ClearBank is null or @ClearBank ='' or PaymentClearBankID=@ClearBank)  
		and(@ClearBranch is null or @ClearBranch ='' or PaymentClearBranchID=@ClearBranch)  
	END  
	ELSE IF (@TranAction='Pay')  
	BEGIN  
		select  
		CASE
			WHEN s.SerialNO = -1 THEN ''
			ELSE s.SerialNO
		END AS 'SerialNO'
		,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
		,s.IssuerName
		,s.RemittanceAmount
		,s.RemittanceCurrency  
		,s.BeneficiaryName  
		,s.BeneficiaryIDType  
		,s.BeneficiaryIDNumber  
		,s.Notes  
		,s.IssuerBranch  
		,s.PaymentClearBankID  
		,s.PaymentClearBranchID  
		,s.PaymentClearGL  
		,s.ReferenceNO
		,s.SecurityQuestion  
		,s.SecurityAnswer
		,s.BeneficiaryPhone
		from    dbo.SoldRemittance as s   
		where   s.BeneficiaryName like '%'+@BenefName+'%'
		and		s.ReferenceNO like '%'+@ReferenceNo+'%'  
		and s.Status in ('Issued','Verify')  
		and s.ToLocalBank=1  
		and s.IsExternalIssued=0  
		and(@ClearBank is null or @ClearBank ='' or PaymentClearBankID=@ClearBank)  
		and(@ClearBranch is null or @ClearBranch ='' or PaymentClearBranchID=@ClearBranch)  
	END  
END  
ELSE IF(@TranMode =0) --Our branch  
BEGIN  
	select  
	CASE
		WHEN s.SerialNO = -1 THEN ''
		ELSE s.SerialNO
	END AS 'SerialNO'
	,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
	,s.IssuerName
	,s.RemittanceAmount
	,s.RemittanceCurrency  
	,s.BeneficiaryName  
	,s.BeneficiaryIDType  
	,s.BeneficiaryIDNumber  
	,s.Notes  
	,s.IssuerBranch  
	,s.PaymentClearBankID  
	,s.PaymentClearBranchID  
	,s.PaymentClearGL  
	,s.ReferenceNO
	,s.SecurityQuestion  
	,s.SecurityAnswer
	,s.BeneficiaryPhone	
	from    dbo.SoldRemittance as s   
	where   s.BeneficiaryName like '%'+@BenefName+'%'
	and		s.ReferenceNO like '%'+@ReferenceNo+'%'  
	and s.Status='Issued'  
	and s.ToLocalBank=0 
END  

ELSE IF(@TranMode =2) --External Issuing  
BEGIN  
	if (@TranAction='Settlement')  
	BEGIN  
		select  
		CASE
			WHEN s.SerialNO = -1 THEN ''
			ELSE s.SerialNO
		END AS 'SerialNO'
		,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
		,s.IssuerName
		,s.RemittanceAmount
		,s.RemittanceCurrency  
		,s.BeneficiaryName  
		,s.BeneficiaryIDType  
		,s.BeneficiaryIDNumber  
		,s.Notes  
		,s.IssuerBranch  
		,s.PaymentClearBankID  
		,s.PaymentClearBranchID  
		,s.PaymentClearGL
		,s.ReferenceNO
		,s.SecurityQuestion  
		,s.SecurityAnswer  
        ,s.BeneficiaryPhone
		from    dbo.SoldRemittance as s   
		where   s.BeneficiaryName like '%'+@BenefName+'%'
		and		s.ReferenceNO like '%'+@ReferenceNo+'%'  
		and s.Status='Pay'  
		 and s.IsExternalIssued=1  
		and(@ClearBank is null or @ClearBank ='' or PaymentClearBankID=@ClearBank)  
		and(@ClearBranch is null or @ClearBranch ='' or PaymentClearBranchID=@ClearBranch)  
	END  
	ELSE IF(@TranAction='Pay')  
	BEGIN  
		select  
		CASE
			WHEN s.SerialNO = -1 THEN ''
			ELSE s.SerialNO
		END AS 'SerialNO'
		,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
		,s.IssuerName
		,s.RemittanceAmount
		,s.RemittanceCurrency  
		,s.BeneficiaryName  
		,s.BeneficiaryIDType  
		,s.BeneficiaryIDNumber  
		,s.Notes  
		,s.IssuerBranch  
		,s.PaymentClearBankID  
		,s.PaymentClearBranchID  
		,s.PaymentClearGL  
		,s.ReferenceNO
		,s.SecurityQuestion  
		,s.SecurityAnswer
		,s.BeneficiaryPhone
		from    dbo.SoldRemittance as s   
		where   s.BeneficiaryName like '%'+@BenefName+'%'
		and		s.ReferenceNO like '%'+@ReferenceNo+'%'  
		and s.Status='Issued'  
		 and s.IsExternalIssued=1  
		and(@ClearBank is null or @ClearBank ='' or PaymentClearBankID=@ClearBank)  
		and(@ClearBranch is null or @ClearBranch ='' or PaymentClearBranchID=@ClearBranch)  
	END
	
END  
GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc getAllVaultItems
Go

CREATE proc dbo.getAllVaultItems       
@VaultTypes int = null        
/*                    
CreationDate: 3-12-2007                  
OriginalName: dbo.getAllVaultItems                  
Programmer: Hany A. Hassan                 
Description: Retrieves all VaultItems according to the vaulttype flag        
Output:                      
Assumption:                     
                    
ModifiedDate: 25-07-2012                      
Modifer: Doaa Nassar                      
ModifyReason: fixing defect# GFSX00714, Remove 'action' from group by   

Programmer : Mostafa Sayed
Date       : [24/06/2020]
Reason     : Issue#GFSX14107 - Required fields to enter in journal .....               
*/                    
As        
if(@VaultTypes=1) -- items exist in the vault      
begin      
      
select VI.VaultItemDescription,VID.VaultItemId from VaultItemDetails VID inner join     
(select VaultItemId, max(DateTimeStamp) as maxdate from VaultItemDetails group by VaultItemId) Details on     
 VID.VaultItemId = Details.VaultItemId   
 inner join vaultItem VI on VI.VaultItemId = VID.VaultItemId  
 where ( VID.action = 0 or VID.action = 2) and DateTimeStamp = maxdate  
      
end      
      
if(@VaultTypes=-1) -- items exited from the vault      
begin      
      
select VI.VaultItemDescription,VID.VaultItemId from VaultItemDetails VID  
 inner join vaultItem VI on VI.VaultItemId = VID.VaultItemId  
 inner join (select VaultItemId, max(DateTimeStamp) as maxdate from VaultItemDetails group by VaultItemId) Details   
on VID.VaultItemId = Details.VaultItemId   
 where ( VID.action = 1) and DateTimeStamp = Details.maxdate  
  
end      

if(@VaultTypes is null) -- get all items  
begin      
      
select VI.VaultItemDescription,VID.VaultItemId from VaultItemDetails VID  
 inner join vaultItem VI on VI.VaultItemId = VID.VaultItemId  
 inner join (select VaultItemId, max(DateTimeStamp) as maxdate from VaultItemDetails group by VaultItemId) Details   
on VID.VaultItemId = Details.VaultItemId   
 where DateTimeStamp = Details.maxdate  
  
end   

Go
--End of Automatic Generation
