﻿USE [Globalfs]
GO
       
If Not Exists(Select * From ServicePacks Where BasePackageName = 'ETHIX-Branch_2.00.46' And SP_Number = 42)
Begin
Insert Into ServicePacks(BasePackageName,SP_Number,SP_Name, LastPackageName, BriefDescription, DetailedDescription,IncludeWholeFilesOnly,DontRemoveTmpFldrWhenFinished,OptionalSourceList,Comments,PatchNumber)
Values('ETHIX-Branch_2.00.46', 42,'SP42_ETHIX-Branch_2.0.46.0','SP41_ETHIX-Branch_2.0.46.0','SP42_ETHIX-Branch_2.0.46.0','', 1, 0, '', '',0)
End
GO
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby & Aya Tarek
--Date		:	{13/09/2021}
--Reason	:	Enh GFSY00876 - ACM000000019682 -Dukhan - External Liability Settlement
--=============================================================
PRINT 'Start. Script for CR# GFSY00876 DML Script'
GO

If Not Exists(Select * From BANKCONFIG Where  Name = 'UseWF')
Begin
	exec dbo.BANK_CONFIG_INSERT @Name= 'UseWF',@Value = '0',@DataType = 'int',@ShortDescr = 'TLR_WF_SD',@LongDescr = 'TLR_WF_LD',@MaxVal = '1',@MinVal='0',@MinFldLength='0',@MaxFldLength='2',@ErrDescr='TLR_INVALID_DATA'
End
go


-------------------------------------------------------------------
----------------------------WFProcessTask--------------------
-------------------------------------------------------------------

If Not Exists(Select * From WFProcessTask Where TaskId=51080 )
Begin
	Insert into WFProcessTask(TaskId,TaskName) 
	values(51080,'Issue CO')
End
go


If Not Exists(Select * From WFProcessTask Where TaskId=51070 )
Begin
	Insert into WFProcessTask(TaskId,TaskName) 
	values(51070,'Issue TT')
End
GO

------------------
-- RulesTranName -
------------------
-- CO account = 185
-- CO GL = 281
-- TT ACC = 277
-- TT GL = 296
--
If  not Exists(Select * From RulesTranName Where TranID = 185 and  taskid = 51080)
Begin
 update RulesTranName set taskid = 51080 where  TranID = 185
End
GO

If not Exists(Select * From RulesTranName Where TranID = 281 and  taskid = 51080)
Begin
 update RulesTranName set taskid = 51080 where  TranID = 281
End
GO

If not Exists(Select * From RulesTranName Where TranID = 277 and  taskid = 51070 )
Begin
 update RulesTranName set taskid = 51070 where  TranID = 277
End
GO

If not Exists(Select * From RulesTranName Where TranID = 296 and  taskid = 51070 )
Begin
 update RulesTranName set taskid = 51070 where  TranID = 296
End
GO

--**********************************************************************************
--**********************************************************************************
--**********************************************************************************
-- issue CO ACCount
If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 2020 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,2020,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 2021 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,2021,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 2022 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,2022,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 2023 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,2023,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 2024 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,2024,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 2025 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,2025,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 2026 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,2026,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 2031 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,2031,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 2033 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,2033,1)
End
go
--**************************************************************************************************
-- issue CO GL
If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 2020 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,2020,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 2021 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,2021,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 2022 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,2022,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 2023 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,2023,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 2024 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,2024,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 2025 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,2025,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 2026 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,2026,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 2031 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,2031,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 2033 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,2033,1)
End
go


--**************************************************************************************************
-- issue TT GL
If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 2020 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,2020,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 2021 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,2021,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 2022 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,2022,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 2023 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,2023,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 2024 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,2024,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 2025 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,2025,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 2026 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,2026,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 2031 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,2031,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 2033 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,2033,1)
End
go


go

--**************************************************************************************************
-- issue TT ACCOUNT
If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 2020 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,2020,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 2021 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,2021,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 2022 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,2022,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 2023 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,2023,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 2024 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,2024,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 2025 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,2025,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 2026 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,2026,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 2031 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,2031,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 2033 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,2033,1)
End
go
--**************************************************************************************************

--------------------
-- RulesStepAction -
--------------------
If Not Exists(Select * From RulesStepAction Where Action = 'SendToPhoenixThenReIssueCheque&SignalWF' And StepType = 413)
Begin
 Insert Into RulesStepAction(Action,StepType,AppID,WritesJournal)
 Values ('SendToPhoenixThenReIssueCheque&SignalWF',413,1,0)
End
GO

If Not Exists(Select * From RulesStepAction Where Action = 'SendToPhoenixThenCreateSwiftMsg&SignalWF' And StepType = 413)
Begin
 Insert Into RulesStepAction(Action,StepType,AppID,WritesJournal)
 Values ('SendToPhoenixThenCreateSwiftMsg&SignalWF',413,1,0)
End
GO


If  Exists(Select * From RulesStepAction Where Action = 'CreateSwiftMsg' And StepType = 103)
Begin
 update RulesStepAction set stepType = 106 Where Action = 'CreateSwiftMsg' And StepType = 103
End
GO

If Not Exists(Select * From RulesStepAction Where Action = 'CreateSwiftMsg' And StepType = 106)
Begin
 Insert Into RulesStepAction(Action,StepType,AppID,WritesJournal)
 Values ('CreateSwiftMsg',106,1,0)
End
GO




-------------
-- RulesTranSteps -
-------------------

--IssueCOAgainstAccount
If not Exists(Select * From RulesTranSteps Where TranID = 185 AND [Action] = 'SendToPhoenixThenReIssueCheque&SignalWF')
Begin
 UPDATE RulesTranSteps SET StepSequence = StepSequence + 10 WHERE TranID = 185 AND [Action] = 'JournalUpdate'
End
GO

DECLARE @StepSequence int
select @StepSequence = StepSequence from RulesTranSteps where TranID = 185 and  [Action] = 'JournalUpdate'
If not Exists(Select * From RulesTranSteps Where TranID = 185 AND [Action] = 'SendToPhoenixThenReIssueCheque&SignalWF')
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action)
 Values (185,@StepSequence - 10 ,413,1,0,'SendToPhoenixThenReIssueCheque&SignalWF')
End
GO


--IssueCOAgainstGL
If not Exists(Select * From RulesTranSteps Where TranID = 281 AND [Action] = 'SendToPhoenixThenReIssueCheque&SignalWF')
Begin
 UPDATE RulesTranSteps SET StepSequence = StepSequence + 10 WHERE TranID = 281 AND [Action] = 'JournalUpdate'
End
GO
DECLARE @StepSequence int
select @StepSequence = StepSequence from RulesTranSteps where TranID = 281 and  [Action] = 'JournalUpdate'
If not Exists(Select * From RulesTranSteps Where TranID = 281  AND [Action] = 'SendToPhoenixThenReIssueCheque&SignalWF')
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action)
 Values (281,@StepSequence - 10,413,1,0,'SendToPhoenixThenReIssueCheque&SignalWF')
End
GO


--IssueTTAgainstAccount
If not Exists(Select * From RulesTranSteps Where TranID = 277 AND [Action] = 'SendToPhoenixThenCreateSwiftMsg&SignalWF')
Begin
 UPDATE RulesTranSteps SET StepSequence = StepSequence + 10 WHERE TranID = 277 AND [Action] = 'JournalUpdate'
End
GO
DECLARE @StepSequence int
select @StepSequence = StepSequence from RulesTranSteps where TranID = 277 and  [Action] = 'JournalUpdate'
If not Exists(Select * From RulesTranSteps Where TranID = 277 AND [Action] = 'SendToPhoenixThenCreateSwiftMsg&SignalWF')
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action) 
 Values (277,@StepSequence - 10,413,1,0,'SendToPhoenixThenCreateSwiftMsg&SignalWF')
End
GO

--IssueTTAgainstGL
If not Exists(Select * From RulesTranSteps Where TranID = 296 AND [Action] = 'SendToPhoenixThenCreateSwiftMsg&SignalWF')
Begin
 UPDATE RulesTranSteps SET StepSequence = StepSequence + 10 WHERE TranID = 296 AND [Action] = 'JournalUpdate'
End
GO
DECLARE @StepSequence int
select @StepSequence = StepSequence from RulesTranSteps where TranID = 296 and  [Action] = 'JournalUpdate'
If not Exists(Select * From RulesTranSteps Where TranID = 296 AND [Action] = 'SendToPhoenixThenCreateSwiftMsg&SignalWF')
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action) 
 Values (296,@StepSequence - 10,413,1,0,'SendToPhoenixThenCreateSwiftMsg&SignalWF')
End
GO


PRINT 'End... Script for CR# GFSY00876 DML Script'
GO
--Devolper	 :	Ahmed Aliwa & Aya Tarek 
--Date       :	[19/9/2021]		
--Reason     :	CR#GFSY00879 [Barwa So Execution]
PRINT 'Start. Script for CR# GFSY00879 DML Script...Ahmed.eliwa'
GO
--*****************************************************************************************************************************************************
--********************************************** insert tran name descriptor in RulesDescriptor *******************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS (SELECT *FROM RulesDescriptor WHERE NAME = 'SoPaymentExecutionService' AND DescriptorID = 1106034)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor , Creator , Updator )  
	values (1 , 1106034 , 'SoPaymentExecutionService' , 0 , 'Labels' , 'So Payment Execution Service' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO
--*****************************************************************************************************************************************************
--********************************************** insert tran name in RulesTranName   ******************************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS ( Select * From  dbo.RulesTranName Where  TransactionName   = 'SoPaymentExecutionService' AND  TranID   =  874   ) 
BEGIN 
 INSERT INTO dbo.RulesTranName ( TransactionName        , TranID  , Description                              , Developer             , DSC_Description  , TranCategory  , HostTranType  , HeaderID  , AppID  , TranMnemonic  , isDupable  , isCorrectable  , isOpenDayRequired  , isHostTran  , isOnlineOnly  , isUITranOnly  , isTestable  , Updator                    , TrackForStats  , VisitRequired  , Minimizable  , CanBeSaved  , ShowCustomerInTitle  , isCTR  , isMIEL  , Linkable  , SignOnRequired  , SupervisorRequired  , CanRunInLocalMode  , SideMenuName  , SideMenuAppName  , SideMenuXSL      , isBPOnly     , HostTranCode  , isSuperDupable  , TotalsType        , IsImagingTran   , IsExternalTran  , CanBeDeferred  , Task_DSC        , TaskID   , ShowInDWH  )  
               values ( 'SoPaymentExecutionService'  ,   874   ,  'So Payment Execution Service'  ,  'ITSOFT\ahmed.eliwa'  ,   1106034        ,   101          ,  'Teller'      ,   101  ,   1     ,  'pmTrns' ,   1       ,   1            ,   1                ,    0        ,   0           ,   0            ,   1         ,  'ITSOFT\ahmed.eliwa'     ,   0            ,   0           ,   0           ,   0         ,   1                  ,   0     ,   0    ,   0      ,   1               ,   0                ,   1                 ,    NULL      ,    NULL          ,    NULL          ,   0          ,    NULL       ,   0              ,    NULL           ,   0            ,   0             ,   0             ,    NULL        ,    NULL    ,   1 )
END   
GO
--****************************************************************************************************************************************************          
--********************************************** insert in RulesContainerTrans ************************************************************************
--*****************************************************************************************************************************************************
If Not Exists(Select * From RulesContainerTrans Where container_name = 'Teller' And TranName = 'SoPaymentExecutionService')
Begin
 Insert Into RulesContainerTrans(container_name,TranName,Updator,RowStatus)
 Values ('Teller','SoPaymentExecutionService',N'ITSOFT\ahmed.eliwa',1)
End
go
--*****************************************************************************************************************************************************          
--********************************************** insert in RulesTranConfig ***********************************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS ( Select * From  RulesTranConfig Where  TranID = 874   ) 
BEGIN 

	INSERT INTO RulesTranConfig (TranID , DenomRequired , AccountingEntries , DrAccountCategoryID , CrAccountCategoryID , LimitCategoryID , FeesCategoryID , ExchangeType , OffLineAmount , AllowEmptyAccountingEntries , VerifySignatrue , ReadAllAccountingEntries , ShowInAdmin , Updator , OD_DrAccountCategoryID , PrintOption , ForcePositioning , EnableCharges , SalesMessageActive , FutureStaleChequeDays , BackDatedStaleChequeDays , ValidateStaleCheque , StaleChequeAction , StaleChequeDefaultDate , EscWarningEnabled , ChqRngVal , ChqRngAction , Blacklisted , BlacklistedAction , BenPmtStrict , BenPmtWarning , HasCheckList , CheckListCategoryID , ShowAvlBal , AutoPrintPassBook , TranCommissionGroupID , UseSimpleChargeControl , GLCategoryID , DaysAllowedForReversal , TranLimitID , ChequeType , CashFollowAcctCurr , useFX , CheckDrawerTypeRestrictions , use_XPath_app , SameRIMForCharge , SameCurrencyForCharge , PrimaryIDExpiryVal , PrimaryIDExpiryAction , Channel_Id , RecoveryReversal , Pack_ID , CustomerInquiry , TransOptPickListID , ReviewVouchersBeforePrinting , OpenSessionRequired , Charge_AcctCategoryID , UpdDateReqired , UpdDateValue , UpdDateAction , IsFinancialTran , ShortDescription , TranOptionFLD , CHK_IncludeAccumilative , CHK_AccumilativeInfoMessage , WorkOnNightlyModeAllowed )  
	values (874 , 0 , 0 , NULL , NULL , NULL , NULL , '' , 0.00 , 1 , 0 , 0 , 1 , 'ITSOFT\ahmed.eliwa' , NULL , 1 , 0 , 0 , 0 , 0 , 0 , 0 , 'Warning' , 0 , 1 , 0 , 'Warning' , 0 , '' , 0 , 0 , 0 , 0 , 0 , 0 , NULL , 0 , NULL , 0 , NULL , 0 , 1 , 1 , 1 , 0 , 1 , 0 , 1 , 'Warning' , NULL , 0 , NULL , 0 , NULL , 1 , 1 , NULL , 0 , 1 , '0' , 0 , 'PM_B' , '' , 0 , 0 , 0)
END 
GO
--****************************************************************************************************************************************************          
--********************************************** insert in TransactionScopes ************************************************************************
--*****************************************************************************************************************************************************
If Not Exists(Select * From TransactionScopes Where Scope = 1001 And TranID = 874)
Begin
 Insert Into TransactionScopes(Scope,TranID,Developer,Updator,RowStatus)
 Values (1001,874,N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa',1)
End
go

--******************************************************************************************************************************************
--********************************************** insert in HostCoreService******************************************************************
--******************************************************************************************************************************************
If Not Exists(Select * From HostCoreService Where ServiceId = 332)
Begin
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
 Values (332,'ListSODuePaymentForSoService','StandingOrderInquiry','list So due payment for SoExcecution service')
End
go  
--******************************************************************************************************************************************
--********************************************** insert in HostCoreServiceFields************************************************************
--******************************************************************************************************************************************
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=1 and FieldName='SoType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,1,'SoType','varchar',0,0,'I', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=2 and FieldName='BusinessDate')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,2,'BusinessDate','datetime',0,0,'I', '1900-01-01')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=3 and FieldName='TransferIdNumber')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,3,'TransferIdNumber','int',999,0,'O','0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=4 and FieldName='TransferDescription')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,4,'TransferDescription','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=5 and FieldName='AccountNumber')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,5,'AccountNumber','varchar',999,0,'O','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=6 and FieldName='AccountType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,6,'AccountType','varchar',999,0,'O','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=7 and FieldName='RimNumber')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,7,'RimNumber','int',999,0,'O',0)
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=8 and FieldName='TransferStatus')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,8,'TransferStatus','varchar',999,0,'O','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=9 and FieldName='TransferAmount')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,9,'TransferAmount','decimal',999,0,'O','0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=10 and FieldName='SOType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,10,'SOType','varchar',999,0,'O','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=11 and FieldName='NextTransferDate')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,11,'NextTransferDate','datetime',999,0,'O','1900-01-01')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=12 and FieldName='TransferCurrency')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,12,'TransferCurrency','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=13 and FieldName='CorrespondentBank')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,13,'CorrespondentBank','int',0,0,'I', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=14 and FieldName='PaymentStatus')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,14,'PaymentStatus','int',0,0,'I', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=15 and FieldName='BranchNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,15,'BranchNo','int',999,0,'O', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=16 and FieldName='ErrorId')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,16,'ErrorId','int',999,0,'O', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=17 and FieldName='AttemptNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,17,'AttemptNo','int',999,0,'O', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=18 and FieldName='DepositLoan')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,18,'DepositLoan','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=19 and FieldName='NumberOfRetries')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,19,'NumberOfRetries','int',999,0,'O', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=20 and FieldName='InAccountType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,20,'InAccountType','varchar',0,0,'I','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=21 and FieldName='FatcaStatus')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,21,'FatcaStatus','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=22 and FieldName='CRSStatus')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,22,'CRSStatus','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=23 and FieldName='SwiftCode')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,23,'SwiftCode','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=24 and FieldName='CountryCode')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,24,'CountryCode','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=25 and FieldName='crs_participate')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,25,'crs_participate','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=26 and FieldName='morning_processing')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,26,'morning_processing','varchar',999,0,'O', '')
End
go
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=27 and FieldName='is_morning_processing')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,27,'is_morning_processing','varchar',0,0,'I', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=29 and FieldName='ApplicationType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,29,'ApplicationType','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=28 and FieldName='FromAccountCurrency')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,28,'FromAccountCurrency','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=30 and FieldName='ToAccountCurrency')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,30,'ToAccountCurrency','varchar',999,0,'O', '')
End
go
--******************************************************************************************************************************************
--********************************************** insert in SQLstrings***********************************************************************
--******************************************************************************************************************************************
/*If Not Exists(Select * From SQLstrings Where AccessID = 1100135)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName             ,CommandType ,GetsRows    , DataSource        ,AccessString                       ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose                                ,RowStatus ,RScmdType ,RScmd ,ReadOnly ,CacheMinutes ,UseNewCacheRules ,CacheGroup ,CacheByUser, SkipTest, ExpirationDays, is_development_only, CommandTimeout)
 Values                (1    ,  1100135  ,'HS_ListSOForSoService' ,'s'         ,1           ,'GFSOLEDB'         ,'dbo.HS_ListSOForSoService'        ,0          ,''               ,''               ,'list du payments for so exe Service ' ,1         ,' '       ,''    ,0        ,0            ,1                ,NULL       ,NULL       , 0       , 0             , 0                  , 0             )
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100137)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName            ,CommandType ,GetsRows    , DataSource        ,AccessString                      ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose                    ,RowStatus ,RScmdType ,RScmd ,ReadOnly ,CacheMinutes ,UseNewCacheRules ,CacheGroup ,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values                (1    ,  1100137  ,'InsertSOPaymentSvcErrorLog' ,'p'         ,0           ,'Globalfs'   ,'dbo.InsertSOPaymentSvcErrorLog'  ,0          ,''               ,''               ,'sql InsertSOPaymentSvcErrorLog' ,1         ,' '       ,''    ,0        ,0            ,1                ,NULL       ,0          ,0       ,0             ,0                  ,0)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100138)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName            ,CommandType ,GetsRows    , DataSource        ,AccessString                      ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose                    ,RowStatus ,RScmdType ,RScmd ,ReadOnly ,CacheMinutes ,UseNewCacheRules ,CacheGroup ,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values                (1    ,  1100138  ,'InsertSOPaymentServiceLog' ,'p'         ,0           ,'Globalfs'         ,'dbo.InsertSOPaymentServiceLog'        ,0          ,''               ,''               ,'sql InsertSOPaymentServiceLog' ,1         ,' '       ,''    ,0        ,0            ,1                ,NULL       ,0          ,0       ,0             ,0                  ,0)
End
GO*/
--******************************************************************************************************************************************
--********************************************** insert in BankConfig***********************************************************************
--******************************************************************************************************************************************
IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'SoService_StartProcessTime')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'SoService_StartProcessTime',@Value = '0559', @DataType = 'time', @ShortDescr = 'SoService_StartProcessTime', @LongDescr = 'SoService_StartProcessTime', @MaxVal = '255',@MinVal='0'
END
GO
IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'SoService_EndProcessTime')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'SoService_EndProcessTime',@Value = '2359', @DataType = 'time', @ShortDescr = 'SoService_EndProcessTime', @LongDescr = 'SoService_EndProcessTime', @MaxVal = '255',@MinVal='0'
END
GO
--*****************************************************************************************************************************************************          
--********************************************** insert in RulesTranField *****************************************************************************
--*****************************************************************************************************************************************************
If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = -1099996)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     -1099996     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = -1099995)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     -1099995     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = -1099994)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     -1099994     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 9)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     9     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 195)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     195     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 236)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     236     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 236)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     236     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 247)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     247     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 248)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     248     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 271)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     271     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 276)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     276     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 319)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     319     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 366)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     366     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 396)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     396     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 397)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     397     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 492)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     492     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 509)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     509     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 589)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     589     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 846)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     846     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 905)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     905     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 906)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     906     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 951)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     951     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 952)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     952     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 953)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     953     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 983)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     983     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1122)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1122     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1151)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1151     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1167)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1167     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1183)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1183     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1251)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1251     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1268)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1268     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1277)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1277     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1324)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1324     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1418)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1418     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1419)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1419     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1508)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1508     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1519)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1519     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1661)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1661     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1748)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1748     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1778)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1778     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1782)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1782     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,'LegID'     ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1815)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1815     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1973)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1973     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1998)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1998     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1000057)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1000057 ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 246)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     246 ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go
--*****************************************************************************************************************************************************          
--********************************************** insert in RulesTranSteps *****************************************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS(SELECT * FROM RulesTranSteps WHERE TranID = 874 AND Action = 'SendToPhoenix')
BEGIN
	INSERT INTO RulesTranSteps (TranID , StepSequence , StepType , StepDisabled , ReEntryStep , Action           , Developer            , Updator )  
	       VALUES              ( 874   , 20           ,  413      , 0            , 1           , 'SendToPhoenix' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

--*****************************************************************************************************************************************************          
--********************************************** insert in RulesParam **************************************************************************
--*****************************************************************************************************************************************************
declare @paramid int
select @paramid=MAX(paramid)+1 from RulesParam

 If Not Exists(Select * From RulesParam Where ParamName = 'nsf_flag_for_so_service')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
 Values (@paramid,'nsf_flag_for_so_service','get nsf flag for so service',NULL,0,0,0,'','Static    ','','Sep  22 2021 8:22AM',N'ITSOFT\ahmed.eliwa','Sep  22 1900 12:00AM','Dec 31 9999 12:00AM',1)
End 

--*****************************************************************************************************************************************************          
--********************************************** insert in RulesTranFldParam **************************************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'SoPaymentExecutionService' AND FieldName = '' AND Param = 'CurrencyCategoryID')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('SoPaymentExecutionService','','CurrencyCategoryID','69',N'ITSOFT\ahmed.eliwa','int',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'SoPaymentExecutionService' AND FieldName = '' AND Param = 'nsf_flag_for_so_service')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('SoPaymentExecutionService','','nsf_flag_for_so_service','false',N'ITSOFT\ahmed.eliwa','nvarchar',NULL)
END
GO

PRINT 'End... Script for CR# GFSY00879 DML Script....Ahmed.eliwa'
GO

PRINT 'Start. Script for CR# GFSY00879 DML Script...Aya.Tarek'
GO
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--------------------------RulesDescriptor & RulesDesceiptorLocal--------------------------------
------------------------------------------------------------------------------------------------
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105972 and Name = 'TLR_Morning_Processing' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105972,'TLR_Morning_Processing',0,'Labels','Morning Processing','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105972 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105972,1025,N'المعالجة الصباحية','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105973 and Name = 'TLR_Special_Rates' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105973,'TLR_Special_Rates',0,'Labels','Special Rates','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105973 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105973,1025,N'أسعار خاصة','Mar 10 2021 10:19AM')
End
go



If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105974 and Name = 'TLR_Add_Spec_Rates' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105974,'TLR_Add_Spec_Rates',0,'Labels','Add Special Rates','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105974 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105974,1025,N'إضافة أسعار خاصة','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105975 and Name = 'TLR_Proc_In_The_Same_Month' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105975,'TLR_Proc_In_The_Same_Month',0,'Labels','Process In The Same Month','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105975 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105975,1025,N'العملية في نفس الشهر','Mar 10 2021 10:19AM')
End
go


--Popup Descriptors
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106002 and Name = 'TLR_Default_Rates' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106002,'TLR_Default_Rates',0,'Labels','Default Rates','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106002 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106002,1025,N'المعدلات الافتراضية','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106003 and Name = 'TLR_Default_Buy_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106003,'TLR_Default_Buy_Rate',0,'Labels','Default Buy Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106003 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106003,1025,N'سعر الشراء الافتراضي','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106004 and Name = 'TLR_Default_Sell_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106004,'TLR_Default_Sell_Rate',0,'Labels','Default Sell Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106004 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106004,1025,N'سعر البيع الافتراضي','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106005 and Name = 'TLR_FI_Default_Sell_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106005,'TLR_FI_Default_Sell_Rate',0,'Labels','FI Default Sell Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106005 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106005,1025,N'معدل البيع الافتراضي FI','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106006 and Name = 'TLR_FI_Default_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106006,'TLR_FI_Default_Rate',0,'Labels','Default FI Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106006 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106006,1025,N'الافتراضى FI معدل','Mar 10 2021 10:19AM')
End
go
---------------
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106007 and Name = 'TLR_Special_Buy_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106007,'TLR_Special_Buy_Rate',0,'Labels','Special Buy Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106007 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106007,1025,N'سعر الشراء الخاص','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106008 and Name = 'TLR_Special_Sell_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106008,'TLR_Special_Sell_Rate',0,'Labels','Special Sell Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106008 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106008,1025,N'سعر البيع الخاص','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106009 and Name = 'TLR_FI_Special_Sell_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106009,'TLR_FI_Special_Sell_Rate',0,'Labels','FI Special Sell Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106009 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106009,1025,N'معدل البيع الخاص FI','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106010 and Name = 'TLR_FI_Special_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106010,'TLR_FI_Special_Rate',0,'Labels','Special FI Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106010 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106010,1025,N'الخاص FI معدل','Mar 10 2021 10:19AM')
End
go

--------------------------------------------------------------------------------------------------
-------------------------------------RulesErrorDescription && RulesLocalErrorDescription ---------
---------------------------------------------------------------------------------------------------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1823)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID)
 Values (1823,'SpecialRates_Mandatory_FLD','You have to Complete Special Rates Values','You have to Complete Special Rates Values',4,'ErrDesc.hlp',1)
End
go

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'AddNewSO' AND  Error_Name   = 'SpecialRates_Mandatory_FLD'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'AddNewSO'  ,  'SpecialRates_Mandatory_FLD'   )
END 
GO

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1823 And LanguageLCID = 1025)
BEGIN
 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
 Values (1823,1025,N'يجب عليك إكمال قيم الأسعار الخاصة',N'يجب عليك إكمال قيم الأسعار الخاصة')
END
GO

--------------------------------------------------------------------------------------------------
-------------------------------------Picklists Enteries Lables------------------------------------
---------------------------------------------------------------------------------------------------

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105976 and Name = 'TLR_INTER_DET_DOM01' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105976,'TLR_INTER_DET_DOM01',0,'Labels','DOM 01','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105976 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105976,1025,N'DOM 01','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105977 and Name = 'TLR_INTER_DET_DOM02' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105977,'TLR_INTER_DET_DOM02',0,'Labels','DOM 02','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105977 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105977,1025,N'DOM 02','Mar 10 2021 10:19AM')
End
go
-------------------------------------------------------------------------------------

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106038 and Name = 'TLR_INTER_DET_DOM03' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106038,'TLR_INTER_DET_DOM03',0,'Labels','DOM 03','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106038 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106038,1025,N'DOM 03','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106039 and Name = 'TLR_INTER_DET_DOM04' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106039,'TLR_INTER_DET_DOM04',0,'Labels','DOM 04','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106039 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106039,1025,N'DOM 04','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106040 and Name = 'TLR_INTER_DET_DOM05' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106040,'TLR_INTER_DET_DOM05',0,'Labels','DOM 05','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106040 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106040,1025,N'DOM 05','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106041 and Name = 'TLR_INTER_DET_DOM06' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106041,'TLR_INTER_DET_DOM06',0,'Labels','DOM 06','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106041 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106041,1025,N'DOM 06','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106042 and Name = 'TLR_INTER_DET_DOM07' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106042,'TLR_INTER_DET_DOM07',0,'Labels','DOM 07','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106042 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106042,1025,N'DOM 07','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106043 and Name = 'TLR_INTER_DET_DOM08' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106043,'TLR_INTER_DET_DOM08',0,'Labels','DOM 08','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106043 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106043,1025,N'DOM 08','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106044 and Name = 'TLR_INTER_DET_DOM09' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106044,'TLR_INTER_DET_DOM09',0,'Labels','DOM 09','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106044 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106044,1025,N'DOM 09','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106045 and Name = 'TLR_INTER_DET_DOM10' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106045,'TLR_INTER_DET_DOM10',0,'Labels','DOM 10','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106045 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106045,1025,N'DOM 10','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106046 and Name = 'TLR_INTER_DET_DOM11' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106046,'TLR_INTER_DET_DOM11',0,'Labels','DOM 11','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106046 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106046,1025,N'DOM 11','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106047 and Name = 'TLR_INTER_DET_DOM12' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106047,'TLR_INTER_DET_DOM12',0,'Labels','DOM 12','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106047 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106047,1025,N'DOM 12','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106048 and Name = 'TLR_INTER_DET_DOM13' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106048,'TLR_INTER_DET_DOM13',0,'Labels','DOM 13','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106048 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106048,1025,N'DOM 13','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106049 and Name = 'TLR_INTER_DET_DOM14' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106049,'TLR_INTER_DET_DOM14',0,'Labels','DOM 14','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106049 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106049,1025,N'DOM 14','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106050 and Name = 'TLR_INTER_DET_DOM15' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106050,'TLR_INTER_DET_DOM15',0,'Labels','DOM 15','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106050 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106050,1025,N'DOM 15','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106051 and Name = 'TLR_INTER_DET_DOM16' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106051,'TLR_INTER_DET_DOM16',0,'Labels','DOM 16','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106051 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106051,1025,N'DOM 16','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106052 and Name = 'TLR_INTER_DET_DOM17' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106052,'TLR_INTER_DET_DOM17',0,'Labels','DOM 17','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106052 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106052,1025,N'DOM 17','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106053 and Name = 'TLR_INTER_DET_DOM18' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106053,'TLR_INTER_DET_DOM18',0,'Labels','DOM 18','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106053 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106053,1025,N'DOM 18','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106054 and Name = 'TLR_INTER_DET_DOM19' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106054,'TLR_INTER_DET_DOM19',0,'Labels','DOM 19','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106054 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106054,1025,N'DOM 19','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106055 and Name = 'TLR_INTER_DET_DOM20' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106055,'TLR_INTER_DET_DOM20',0,'Labels','DOM 20','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106055 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106055,1025,N'DOM 20','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106056 and Name = 'TLR_INTER_DET_DOM21' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106056,'TLR_INTER_DET_DOM21',0,'Labels','DOM 21','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106056 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106056,1025,N'DOM 21','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106057 and Name = 'TLR_INTER_DET_DOM22' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106057,'TLR_INTER_DET_DOM22',0,'Labels','DOM 22','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106057 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106057,1025,N'DOM 22','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106058 and Name = 'TLR_INTER_DET_DOM23' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106058,'TLR_INTER_DET_DOM23',0,'Labels','DOM 23','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106058 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106058,1025,N'DOM 23','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106059 and Name = 'TLR_INTER_DET_DOM24' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106059,'TLR_INTER_DET_DOM24',0,'Labels','DOM 24','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106059 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106059,1025,N'DOM 24','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106060 and Name = 'TLR_INTER_DET_DOM25' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106060,'TLR_INTER_DET_DOM25',0,'Labels','DOM 25','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106060 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106060,1025,N'DOM 25','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106061 and Name = 'TLR_INTER_DET_DOM26' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106061,'TLR_INTER_DET_DOM26',0,'Labels','DOM 26','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106061 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106061,1025,N'DOM 26','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106062 and Name = 'TLR_INTER_DET_DOM27' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106062,'TLR_INTER_DET_DOM27',0,'Labels','DOM 27','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106062 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106062,1025,N'DOM 27','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106063 and Name = 'TLR_INTER_DET_DOM28' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106063,'TLR_INTER_DET_DOM28',0,'Labels','DOM 28','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106063 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106063,1025,N'DOM 28','Mar 10 2021 10:19AM')
End
go
------------------------------------------------------------------------------------------------
--------------------------RulesTranDescriptors-------------------------------------------------------
---------------------------------------------------------------------------------------------
--MORNINGG PROCESS
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Morning_Processing'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Morning_Processing' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Morning_Processing'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Morning_Processing' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Special_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Special_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Special_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Special_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Add_Spec_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Add_Spec_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Add_Spec_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Add_Spec_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Proc_In_The_Same_Month'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Proc_In_The_Same_Month' ,'ITSOFT\aya.tarek'  ) 
END
Go



IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Proc_In_The_Same_Month'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Proc_In_The_Same_Month' ,'ITSOFT\aya.tarek'  ) 
END
Go

--Popup
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Default_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Default_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Default_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Default_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Default_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Default_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Default_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Default_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Default_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Default_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Default_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Default_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_FI_Default_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_FI_Default_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_FI_Default_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_FI_Default_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_FI_Default_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_FI_Default_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_FI_Default_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_FI_Default_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Special_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Special_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Special_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Special_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Special_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Special_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Special_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Special_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_FI_Special_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_FI_Special_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_FI_Special_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_FI_Special_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_FI_Special_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_FI_Special_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_FI_Special_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_FI_Special_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

-----------------------------RulesTranField_ex-----------
--------------------------------------------------------------
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_chkTLR_MORNING_PROCESSING')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_chkTLR_MORNING_PROCESSING' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_chkTLR_MORNING_PROCESSING')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_chkTLR_MORNING_PROCESSING' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_chkTLR_SPECIAL_RATES')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_chkTLR_SPECIAL_RATES' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_chkTLR_SPECIAL_RATES')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_chkTLR_SPECIAL_RATES' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_chkTLR_PROCESS_IN_THE_SAME_MONTH')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_chkTLR_PROCESS_IN_THE_SAME_MONTH' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_chkTLR_PROCESS_IN_THE_SAME_MONTH')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_chkTLR_PROCESS_IN_THE_SAME_MONTH' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_btnAddSpecialRates')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_btnAddSpecialRates' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_btnAddSpecialRates')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_btnAddSpecialRates' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

--Popup
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_Default_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_Default_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_Default_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_Default_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_Default_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_Default_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_Default_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_Default_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_FIDefault_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_FIDefault_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_FIDefault_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_FIDefault_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_Special_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_Special_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_Special_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_Special_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_Special_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_Special_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_Special_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_Special_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_FISpecial_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_FISpecial_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_FISpecial_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_FISpecial_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO
------------
-- PickLists
------------
IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 575)
BEGIN
 INSERT INTO PickLists(AppID,PickListID,PickList_Name,Updator,Creator,RowStatus)
 VALUES (1,575,'TLR_CUSTOMSCHEDULE_PERIOD',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1)
END
GO

-------------------
-- PickList_Entries
-------------------
IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 0)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,0,'TLR_INTER_DET_DAYS','Day(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 1)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,1,'TLR_INTER_DET_WEEKS','Week(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 2)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,2,'TLR_INTER_DET_MONTH','Month(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 3)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,3,'TLR_INTER_DET_YEAR','Year(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 4)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,4,'TLR_INTER_DET_DOM29','DOM 29',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 5)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,5,'TLR_INTER_DET_DOM30','DOM 30',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 6)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,6,'TLR_INTER_DET_EOM','EOM(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 7)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,7,'TLR_INTER_DET_EOQ','EOQ',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO
-----------------------------------------------------------------------------------------------------
---------------------HostCoreService&& IT'S HostCoreServiceFields -------
-----------------------------------------------------------------------------------------------------
-- GetAutoDefAndSpecialRates
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription, Developer , Updator )
	Values(@serviceID,N'GetAutoDefAndSpecialRates',N'MiscellaneousInquiry',N'Get Default Rates and Special Rates for AUTO_TFR','ITSOFT\AyaTarek' , 'ITSOFT\AyaTarek')
END
GO
--SO_ID
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='SO_ID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SO_ID',N'int',0,1,'Null',N'I')
END
GO

--From_currency_ID
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='From_currency_ID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'From_currency_ID',N'int',0,0,'Null',N'I')
END
GO

--TO_currency_ID
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='TO_currency_ID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'TO_currency_ID',N'int',0,0,'Null',N'I')
END
GO

--Foreign_Index_currency
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='Foreign_Index_currency')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'Foreign_Index_currency',N'int',0,1,'NUll',N'I')
END
GO

--default_buy_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='default_buy_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'default_buy_rate',N'decimal',0,0,0,N'O')
END
GO


--default_sell_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='default_sell_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'default_sell_rate',N'decimal',0,0,0,N'O')
END
GO

--default_fi_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='default_fi_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'default_fi_rate',N'decimal',0,0,0,N'O')
END
GO

--special_buy_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='special_buy_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'special_buy_rate',N'decimal',0,0,0,N'O')
END
GO


--special_sell_rate 
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='special_sell_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'special_sell_rate',N'decimal',0,0,0,N'O')
END
GO

--special_fi_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='special_fi_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'special_fi_rate',N'decimal',0,0,0,N'O')
END
GO

--buy_rate_type
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='buy_rate_type')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'buy_rate_type',N'char',0,0,'NUll',N'O')
END
GO

--sell_rate_type
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='sell_rate_type')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'sell_rate_type',N'char',0,0,'NUll',N'O')
END
GO

--fi_rate_type
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='fi_rate_type')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'fi_rate_type',N'char',0,0,'NUll',N'O')
END
GO


--ListStandingOrders
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders') AND FieldName='MorningProcessing')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'MorningProcessing',N'char',N'999',0,'N',N'O')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders') AND FieldName='ProcessSameMonth')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'ProcessSameMonth',N'char',N'999',0,'N',N'O')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders') AND FieldName='SpecialRates')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SpecialRates',N'char',N'999',0,'N',N'O')
END
GO

--ListTransfersDates
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListTransfersDates') AND FieldName='psTfrProcSmMn')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListTransfersDates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'psTfrProcSmMn',N'char',N'999',1,'N',N'I')
END
GO

--------------------------------------------------SQLstrings----------------------------------------------------------------------
IF Not Exists(select * from SQLstrings where AccessID = 1100133)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile , Developer , Updator , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100133 , 'HS_GETAUTODEFANDSPECIALRATES' , 'p' , 1, 'GFSOLEDB' , 'dbo.HS_GETAUTODEFANDSPECIALRATES' , 0 , '' , '' , 'ITSOFT\aya.tarek' , 'ITSOFT\aya.tarek' , 'Get Default Rates and Special Rates for Auto TFR ' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO

-----------------------------TPI---------------------------------
If  Exists(Select * From BankTPIInterface Where  FieldCode = 'AUT')
Begin
 update  BankTPIInterface  set NoOfParameters =125  
 where  FieldCode = 'AUT'
End
go

PRINT 'End... Script for CR# GFSY00879 DML Script....Aya.Tarek'
GO
print 'start DML GFSX14831, GFSX14832 Script...'
print 'start... adding new descriptors'
IF NOT EXISTS (SELECT *  FROM RulesDescriptor WHERE NAME = 'So_StartProcessTime_LD' AND DescriptorID = 1106083)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor , Creator , Updator )  
	values (1 , 1106083 , 'So_StartProcessTime_LD' , 0 , 'Labels' , 'Specify Start Time for processing SO Service\r\nTime Format : HHmm\r\nMin Value =0000 MaxVlaue=2359' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

IF NOT EXISTS (SELECT *  FROM RulesDescriptor WHERE NAME = 'So_StartProcessTime_SD' AND DescriptorID = 1106084)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor , Creator , Updator )  
	values (1 , 1106084 , 'So_StartProcessTime_SD' , 0 , 'Labels' , 'So Start Process Time' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

IF NOT EXISTS (SELECT * FROM RulesDescriptor WHERE NAME = 'So_EndProcessTime_SD' AND DescriptorID = 1106085)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor , Creator , Updator )  
	values (1 , 1106085 , 'So_EndProcessTime_SD' , 0 , 'Labels' , 'So End Process Time' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

IF NOT EXISTS (SELECT * FROM RulesDescriptor WHERE NAME = 'So_EndProcessTime_LD' AND DescriptorID = 1106086)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor , Creator , Updator )  
	values (1 , 1106086 , 'So_EndProcessTime_LD' , 0 , 'Labels' , 'Specify End Time for processing SO Service\r\nTime Format : HHmm\r\nMin Value =0000 MaxVlaue=2359' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO
print 'end... adding new descriptors'
Go 
Print 'start... deleting old bank config'
delete from BankConfig where name  = 'SoService_StartProcessTime'
delete from BankConfig where name  = 'SoService_EndProcessTime'
Print 'End... deleting old bank config'

Print 'start... Adding new bank configs'
IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'SoService_StartProcessTime')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'SoService_StartProcessTime',@Value = '0559', @DataType = 'time', @ShortDescr = 'So_StartProcessTime_SD', @LongDescr = 'So_StartProcessTime_LD', @MaxVal = '255',@MinVal='0'
END
GO
IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'SoService_EndProcessTime')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'SoService_EndProcessTime',@Value = '2359', @DataType = 'time', @ShortDescr = 'So_EndProcessTime_SD', @LongDescr = 'So_EndProcessTime_LD', @MaxVal = '255',@MinVal='0'
END
GO
Print 'End... Adding new bank configs'
Print 'Start... Adding Rules Tran Descriptors'
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 1000006 AND  Dsc_name =  'So_StartProcessTime_SD'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 1000006   ,'So_StartProcessTime_SD' ,'ITSOFT\ahmed.eliwa'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 1000006 AND  Dsc_name =  'So_StartProcessTime_LD'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 1000006   ,'So_StartProcessTime_LD' ,'ITSOFT\ahmed.eliwa'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 1000006 AND  Dsc_name =  'So_EndProcessTime_SD'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 1000006   ,'So_EndProcessTime_SD' ,'ITSOFT\ahmed.eliwa'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 1000006 AND  Dsc_name =  'So_EndProcessTime_LD'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 1000006   ,'So_EndProcessTime_LD' ,'ITSOFT\ahmed.eliwa'  ) 
END
Go
Print 'End... Adding Rules Tran Descriptors'
Print 'Start... Adding Rules Descriptor Local'
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106083 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106083,1025,N'تحديد وقت البدء لخدمة الدفع','Mar 10 2021 10:19AM')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106084 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106084,1025,N'وقت البدء لخدمة الدفع','Mar 10 2021 10:19AM')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106085 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106085,1025,N'وقت الانتهاء لخدمة الدفع','Mar 10 2021 10:19AM')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106086 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106086,1025,N'وقت البدء لخدمة الدفع','Mar 10 2021 10:19AM')
End
go
Print 'End... Adding Rules Descriptor Local'
Print 'End... GFSX14831, GFSX14832 DML Script'
GO
--Devolper	 :	Ahmed Aliwa & Aya Tarek 
--Date       :	[19/9/2021]		
--Reason     :	CR#GFSY00879 [Barwa So Execution]
PRINT 'Start. Script for CR# GFSY00879 DML Script...Ahmed.eliwa'
GO
--*****************************************************************************************************************************************************
--********************************************** insert tran name descriptor in RulesDescriptor *******************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS (SELECT *FROM RulesDescriptor WHERE NAME = 'SoPaymentExecutionService' AND DescriptorID = 1106034)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor , Creator , Updator )  
	values (1 , 1106034 , 'SoPaymentExecutionService' , 0 , 'Labels' , 'So Payment Execution Service' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO
--*****************************************************************************************************************************************************
--********************************************** insert tran name in RulesTranName   ******************************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS ( Select * From  dbo.RulesTranName Where  TransactionName   = 'SoPaymentExecutionService' AND  TranID   =  874   ) 
BEGIN 
 INSERT INTO dbo.RulesTranName ( TransactionName        , TranID  , Description                              , Developer             , DSC_Description  , TranCategory  , HostTranType  , HeaderID  , AppID  , TranMnemonic  , isDupable  , isCorrectable  , isOpenDayRequired  , isHostTran  , isOnlineOnly  , isUITranOnly  , isTestable  , Updator                    , TrackForStats  , VisitRequired  , Minimizable  , CanBeSaved  , ShowCustomerInTitle  , isCTR  , isMIEL  , Linkable  , SignOnRequired  , SupervisorRequired  , CanRunInLocalMode  , SideMenuName  , SideMenuAppName  , SideMenuXSL      , isBPOnly     , HostTranCode  , isSuperDupable  , TotalsType        , IsImagingTran   , IsExternalTran  , CanBeDeferred  , Task_DSC        , TaskID   , ShowInDWH  )  
               values ( 'SoPaymentExecutionService'  ,   874   ,  'So Payment Execution Service'  ,  'ITSOFT\ahmed.eliwa'  ,   1106034        ,   101          ,  'Teller'      ,   101  ,   1     ,  'pmTrns' ,   1       ,   1            ,   1                ,    0        ,   0           ,   0            ,   1         ,  'ITSOFT\ahmed.eliwa'     ,   0            ,   0           ,   0           ,   0         ,   1                  ,   0     ,   0    ,   0      ,   1               ,   0                ,   1                 ,    NULL      ,    NULL          ,    NULL          ,   0          ,    NULL       ,   0              ,    NULL           ,   0            ,   0             ,   0             ,    NULL        ,    NULL    ,   1 )
END   
GO
--****************************************************************************************************************************************************          
--********************************************** insert in RulesContainerTrans ************************************************************************
--*****************************************************************************************************************************************************
If Not Exists(Select * From RulesContainerTrans Where container_name = 'Teller' And TranName = 'SoPaymentExecutionService')
Begin
 Insert Into RulesContainerTrans(container_name,TranName,Updator,RowStatus)
 Values ('Teller','SoPaymentExecutionService',N'ITSOFT\ahmed.eliwa',1)
End
go
--*****************************************************************************************************************************************************          
--********************************************** insert in RulesTranConfig ***********************************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS ( Select * From  RulesTranConfig Where  TranID = 874   ) 
BEGIN 

	INSERT INTO RulesTranConfig (TranID , DenomRequired , AccountingEntries , DrAccountCategoryID , CrAccountCategoryID , LimitCategoryID , FeesCategoryID , ExchangeType , OffLineAmount , AllowEmptyAccountingEntries , VerifySignatrue , ReadAllAccountingEntries , ShowInAdmin , Updator , OD_DrAccountCategoryID , PrintOption , ForcePositioning , EnableCharges , SalesMessageActive , FutureStaleChequeDays , BackDatedStaleChequeDays , ValidateStaleCheque , StaleChequeAction , StaleChequeDefaultDate , EscWarningEnabled , ChqRngVal , ChqRngAction , Blacklisted , BlacklistedAction , BenPmtStrict , BenPmtWarning , HasCheckList , CheckListCategoryID , ShowAvlBal , AutoPrintPassBook , TranCommissionGroupID , UseSimpleChargeControl , GLCategoryID , DaysAllowedForReversal , TranLimitID , ChequeType , CashFollowAcctCurr , useFX , CheckDrawerTypeRestrictions , use_XPath_app , SameRIMForCharge , SameCurrencyForCharge , PrimaryIDExpiryVal , PrimaryIDExpiryAction , Channel_Id , RecoveryReversal , Pack_ID , CustomerInquiry , TransOptPickListID , ReviewVouchersBeforePrinting , OpenSessionRequired , Charge_AcctCategoryID , UpdDateReqired , UpdDateValue , UpdDateAction , IsFinancialTran , ShortDescription , TranOptionFLD , CHK_IncludeAccumilative , CHK_AccumilativeInfoMessage , WorkOnNightlyModeAllowed )  
	values (874 , 0 , 0 , NULL , NULL , NULL , NULL , '' , 0.00 , 1 , 0 , 0 , 1 , 'ITSOFT\ahmed.eliwa' , NULL , 1 , 0 , 0 , 0 , 0 , 0 , 0 , 'Warning' , 0 , 1 , 0 , 'Warning' , 0 , '' , 0 , 0 , 0 , 0 , 0 , 0 , NULL , 0 , NULL , 0 , NULL , 0 , 1 , 1 , 1 , 0 , 1 , 0 , 1 , 'Warning' , NULL , 0 , NULL , 0 , NULL , 1 , 1 , NULL , 0 , 1 , '0' , 0 , 'PM_B' , '' , 0 , 0 , 0)
END 
GO
--****************************************************************************************************************************************************          
--********************************************** insert in TransactionScopes ************************************************************************
--*****************************************************************************************************************************************************
If Not Exists(Select * From TransactionScopes Where Scope = 1001 And TranID = 874)
Begin
 Insert Into TransactionScopes(Scope,TranID,Developer,Updator,RowStatus)
 Values (1001,874,N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa',1)
End
go

--******************************************************************************************************************************************
--********************************************** insert in HostCoreService******************************************************************
--******************************************************************************************************************************************
If Not Exists(Select * From HostCoreService Where ServiceId = 332)
Begin
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
 Values (332,'ListSODuePaymentForSoService','StandingOrderInquiry','list So due payment for SoExcecution service')
End
go  
--******************************************************************************************************************************************
--********************************************** insert in HostCoreServiceFields************************************************************
--******************************************************************************************************************************************
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=1 and FieldName='SoType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,1,'SoType','varchar',0,0,'I', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=2 and FieldName='BusinessDate')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,2,'BusinessDate','datetime',0,0,'I', '1900-01-01')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=3 and FieldName='TransferIdNumber')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,3,'TransferIdNumber','int',999,0,'O','0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=4 and FieldName='TransferDescription')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,4,'TransferDescription','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=5 and FieldName='AccountNumber')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,5,'AccountNumber','varchar',999,0,'O','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=6 and FieldName='AccountType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,6,'AccountType','varchar',999,0,'O','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=7 and FieldName='RimNumber')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,7,'RimNumber','int',999,0,'O',0)
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=8 and FieldName='TransferStatus')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,8,'TransferStatus','varchar',999,0,'O','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=9 and FieldName='TransferAmount')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,9,'TransferAmount','decimal',999,0,'O','0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=10 and FieldName='SOType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,10,'SOType','varchar',999,0,'O','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=11 and FieldName='NextTransferDate')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,11,'NextTransferDate','datetime',999,0,'O','1900-01-01')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=12 and FieldName='TransferCurrency')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,12,'TransferCurrency','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=13 and FieldName='CorrespondentBank')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,13,'CorrespondentBank','int',0,0,'I', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=14 and FieldName='PaymentStatus')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,14,'PaymentStatus','int',0,0,'I', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=15 and FieldName='BranchNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,15,'BranchNo','int',999,0,'O', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=16 and FieldName='ErrorId')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,16,'ErrorId','int',999,0,'O', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=17 and FieldName='AttemptNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,17,'AttemptNo','int',999,0,'O', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=18 and FieldName='DepositLoan')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,18,'DepositLoan','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=19 and FieldName='NumberOfRetries')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,19,'NumberOfRetries','int',999,0,'O', '0')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=20 and FieldName='InAccountType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,20,'InAccountType','varchar',0,0,'I','')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=21 and FieldName='FatcaStatus')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,21,'FatcaStatus','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=22 and FieldName='CRSStatus')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,22,'CRSStatus','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=23 and FieldName='SwiftCode')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,23,'SwiftCode','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=24 and FieldName='CountryCode')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,24,'CountryCode','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=25 and FieldName='crs_participate')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,25,'crs_participate','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=26 and FieldName='morning_processing')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,26,'morning_processing','varchar',999,0,'O', '')
End
go
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=27 and FieldName='is_morning_processing')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,27,'is_morning_processing','varchar',0,0,'I', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=29 and FieldName='ApplicationType')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,29,'ApplicationType','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=28 and FieldName='FromAccountCurrency')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,28,'FromAccountCurrency','varchar',999,0,'O', '')
End
go

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = 332 and FieldId=30 and FieldName='ToAccountCurrency')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,Direction, DefaultValue)
 Values (332,30,'ToAccountCurrency','varchar',999,0,'O', '')
End
go
--******************************************************************************************************************************************
--********************************************** insert in SQLstrings***********************************************************************
--******************************************************************************************************************************************
If Not Exists(Select * From SQLstrings Where AccessID = 1100135)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName             ,CommandType ,GetsRows    , DataSource        ,AccessString                       ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose                                ,RowStatus ,RScmdType ,RScmd ,ReadOnly ,CacheMinutes ,UseNewCacheRules ,CacheGroup ,CacheByUser, SkipTest, ExpirationDays, is_development_only, CommandTimeout)
 Values                (1    ,  1100135  ,'HS_ListSOForSoService' ,'P'         ,1           ,'GFSOLEDB'         ,'dbo.HS_ListSOForSoService'        ,0          ,''               ,''               ,'list du payments for so exe Service ' ,1         ,' '       ,''    ,0        ,0            ,1                ,NULL       ,NULL       , 0       , 0             , 0                  , 0             )
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100137)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName            ,CommandType ,GetsRows    , DataSource        ,AccessString                      ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose                    ,RowStatus ,RScmdType ,RScmd ,ReadOnly ,CacheMinutes ,UseNewCacheRules ,CacheGroup ,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values                (1    ,  1100137  ,'InsertSOPaymentSvcErrorLog' ,'p'         ,0           ,'Globalfs'   ,'dbo.InsertSOPaymentSvcErrorLog'  ,0          ,''               ,''               ,'sql InsertSOPaymentSvcErrorLog' ,1         ,' '       ,''    ,0        ,0            ,1                ,NULL       ,0          ,0       ,0             ,0                  ,0)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100138)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName            ,CommandType ,GetsRows    , DataSource        ,AccessString                      ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose                    ,RowStatus ,RScmdType ,RScmd ,ReadOnly ,CacheMinutes ,UseNewCacheRules ,CacheGroup ,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values                (1    ,  1100138  ,'InsertSOPaymentServiceLog' ,'p'         ,0           ,'Globalfs'         ,'dbo.InsertSOPaymentServiceLog'        ,0          ,''               ,''               ,'sql InsertSOPaymentServiceLog' ,1         ,' '       ,''    ,0        ,0            ,1                ,NULL       ,0          ,0       ,0             ,0                  ,0)
End
GO
--******************************************************************************************************************************************
--********************************************** insert in BankConfig***********************************************************************
--******************************************************************************************************************************************
IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'SoService_StartProcessTime')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'SoService_StartProcessTime',@Value = '0559', @DataType = 'time', @ShortDescr = 'SoService_StartProcessTime', @LongDescr = 'SoService_StartProcessTime', @MaxVal = '255',@MinVal='0'
END
GO
IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'SoService_EndProcessTime')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'SoService_EndProcessTime',@Value = '2359', @DataType = 'time', @ShortDescr = 'SoService_EndProcessTime', @LongDescr = 'SoService_EndProcessTime', @MaxVal = '255',@MinVal='0'
END
GO
--*****************************************************************************************************************************************************          
--********************************************** insert in RulesTranField *****************************************************************************
--*****************************************************************************************************************************************************
If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = -1099996)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     -1099996     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = -1099995)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     -1099995     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = -1099994)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     -1099994     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 9)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     9     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 195)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     195     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 236)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     236     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 236)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     236     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 247)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     247     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 248)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     248     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 271)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     271     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 276)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     276     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 319)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     319     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 366)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     366     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 396)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     396     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 397)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     397     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 492)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     492     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 509)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     509     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 589)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     589     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 846)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     846     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 905)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     905     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 906)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     906     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 951)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     951     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 952)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     952     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 953)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     953     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 983)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     983     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1122)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1122     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1151)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1151     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1167)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1167     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1183)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1183     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1251)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1251     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1268)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1268     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1277)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1277     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1324)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1324     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1418)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1418     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1419)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1419     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1508)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1508     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1519)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1519     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1661)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1661     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1748)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1748     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1778)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1778     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1782)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1782     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,'LegID'     ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1815)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1815     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1973)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1973     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1998)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1998     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 1000057)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     1000057 ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 874 And FieldID = 246)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged            ,isDupable ,MaxArray ,Notes  ,Created              ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (874,     246 ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa' ,'Sep 14 2017 12:59PM'    ,1         ,NULL     ,''    ,'Sep 14 2017 12:59PM' ,N'ITSOFT\ahmed.eliwa' ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,NULL       ,1          ,-1)
End
go
--*****************************************************************************************************************************************************          
--********************************************** insert in RulesTranSteps *****************************************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS(SELECT * FROM RulesTranSteps WHERE TranID = 874 AND Action = 'SendToPhoenix')
BEGIN
	INSERT INTO RulesTranSteps (TranID , StepSequence , StepType , StepDisabled , ReEntryStep , Action           , Developer            , Updator )  
	       VALUES              ( 874   , 20           ,  413      , 0            , 1           , 'SendToPhoenix' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

--*****************************************************************************************************************************************************          
--********************************************** insert in RulesParam **************************************************************************
--*****************************************************************************************************************************************************
declare @paramid int
select @paramid=MAX(paramid)+1 from RulesParam

 If Not Exists(Select * From RulesParam Where ParamName = 'nsf_flag_for_so_service')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
 Values (@paramid,'nsf_flag_for_so_service','get nsf flag for so service',NULL,0,0,0,'','Static    ','','Sep  22 2021 8:22AM',N'ITSOFT\ahmed.eliwa','Sep  22 1900 12:00AM','Dec 31 9999 12:00AM',1)
End 

--*****************************************************************************************************************************************************          
--********************************************** insert in RulesTranFldParam **************************************************************************
--*****************************************************************************************************************************************************
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'SoPaymentExecutionService' AND FieldName = '' AND Param = 'CurrencyCategoryID')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('SoPaymentExecutionService','','CurrencyCategoryID','69',N'ITSOFT\ahmed.eliwa','int',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'SoPaymentExecutionService' AND FieldName = '' AND Param = 'nsf_flag_for_so_service')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('SoPaymentExecutionService','','nsf_flag_for_so_service','false',N'ITSOFT\ahmed.eliwa','nvarchar',NULL)
END
GO

PRINT 'End... Script for CR# GFSY00879 DML Script....Ahmed.eliwa'
GO

PRINT 'Start. Script for CR# GFSY00879 DML Script...Aya.Tarek'
GO
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--------------------------RulesDescriptor & RulesDesceiptorLocal--------------------------------
------------------------------------------------------------------------------------------------
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105972 and Name = 'TLR_Morning_Processing' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105972,'TLR_Morning_Processing',0,'Labels','Morning Processing','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105972 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105972,1025,N'المعالجة الصباحية','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105973 and Name = 'TLR_Special_Rates' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105973,'TLR_Special_Rates',0,'Labels','Special Rates','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105973 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105973,1025,N'أسعار خاصة','Mar 10 2021 10:19AM')
End
go



If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105974 and Name = 'TLR_Add_Spec_Rates' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105974,'TLR_Add_Spec_Rates',0,'Labels','Add Special Rates','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105974 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105974,1025,N'إضافة أسعار خاصة','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105975 and Name = 'TLR_Proc_In_The_Same_Month' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105975,'TLR_Proc_In_The_Same_Month',0,'Labels','Process In The Same Month','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105975 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105975,1025,N'العملية في نفس الشهر','Mar 10 2021 10:19AM')
End
go


--Popup Descriptors
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106002 and Name = 'TLR_Default_Rates' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106002,'TLR_Default_Rates',0,'Labels','Default Rates','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106002 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106002,1025,N'المعدلات الافتراضية','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106003 and Name = 'TLR_Default_Buy_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106003,'TLR_Default_Buy_Rate',0,'Labels','Default Buy Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106003 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106003,1025,N'سعر الشراء الافتراضي','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106004 and Name = 'TLR_Default_Sell_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106004,'TLR_Default_Sell_Rate',0,'Labels','Default Sell Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106004 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106004,1025,N'سعر البيع الافتراضي','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106005 and Name = 'TLR_FI_Default_Sell_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106005,'TLR_FI_Default_Sell_Rate',0,'Labels','FI Default Sell Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106005 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106005,1025,N'معدل البيع الافتراضي FI','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106006 and Name = 'TLR_FI_Default_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106006,'TLR_FI_Default_Rate',0,'Labels','Default FI Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106006 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106006,1025,N'الافتراضى FI معدل','Mar 10 2021 10:19AM')
End
go
---------------
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106007 and Name = 'TLR_Special_Buy_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106007,'TLR_Special_Buy_Rate',0,'Labels','Special Buy Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106007 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106007,1025,N'سعر الشراء الخاص','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106008 and Name = 'TLR_Special_Sell_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106008,'TLR_Special_Sell_Rate',0,'Labels','Special Sell Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106008 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106008,1025,N'سعر البيع الخاص','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106009 and Name = 'TLR_FI_Special_Sell_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106009,'TLR_FI_Special_Sell_Rate',0,'Labels','FI Special Sell Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106009 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106009,1025,N'معدل البيع الخاص FI','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106010 and Name = 'TLR_FI_Special_Rate' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106010,'TLR_FI_Special_Rate',0,'Labels','Special FI Rate','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106010 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106010,1025,N'الخاص FI معدل','Mar 10 2021 10:19AM')
End
go

--------------------------------------------------------------------------------------------------
-------------------------------------RulesErrorDescription && RulesLocalErrorDescription ---------
---------------------------------------------------------------------------------------------------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1823)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID)
 Values (1823,'SpecialRates_Mandatory_FLD','You have to Complete Special Rates Values','You have to Complete Special Rates Values',4,'ErrDesc.hlp',1)
End
go

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'AddNewSO' AND  Error_Name   = 'SpecialRates_Mandatory_FLD'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'AddNewSO'  ,  'SpecialRates_Mandatory_FLD'   )
END 
GO

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1823 And LanguageLCID = 1025)
BEGIN
 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
 Values (1823,1025,N'يجب عليك إكمال قيم الأسعار الخاصة',N'يجب عليك إكمال قيم الأسعار الخاصة')
END
GO

--------------------------------------------------------------------------------------------------
-------------------------------------Picklists Enteries Lables------------------------------------
---------------------------------------------------------------------------------------------------

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105976 and Name = 'TLR_INTER_DET_DOM01' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105976,'TLR_INTER_DET_DOM01',0,'Labels','DOM 01','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105976 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105976,1025,N'DOM 01','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105977 and Name = 'TLR_INTER_DET_DOM02' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105977,'TLR_INTER_DET_DOM02',0,'Labels','DOM 02','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105977 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105977,1025,N'DOM 02','Mar 10 2021 10:19AM')
End
go
-------------------------------------------------------------------------------------

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106038 and Name = 'TLR_INTER_DET_DOM03' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106038,'TLR_INTER_DET_DOM03',0,'Labels','DOM 03','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106038 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106038,1025,N'DOM 03','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106039 and Name = 'TLR_INTER_DET_DOM04' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106039,'TLR_INTER_DET_DOM04',0,'Labels','DOM 04','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106039 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106039,1025,N'DOM 04','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106040 and Name = 'TLR_INTER_DET_DOM05' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106040,'TLR_INTER_DET_DOM05',0,'Labels','DOM 05','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106040 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106040,1025,N'DOM 05','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106041 and Name = 'TLR_INTER_DET_DOM06' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106041,'TLR_INTER_DET_DOM06',0,'Labels','DOM 06','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106041 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106041,1025,N'DOM 06','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106042 and Name = 'TLR_INTER_DET_DOM07' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106042,'TLR_INTER_DET_DOM07',0,'Labels','DOM 07','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106042 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106042,1025,N'DOM 07','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106043 and Name = 'TLR_INTER_DET_DOM08' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106043,'TLR_INTER_DET_DOM08',0,'Labels','DOM 08','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106043 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106043,1025,N'DOM 08','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106044 and Name = 'TLR_INTER_DET_DOM09' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106044,'TLR_INTER_DET_DOM09',0,'Labels','DOM 09','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106044 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106044,1025,N'DOM 09','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106045 and Name = 'TLR_INTER_DET_DOM10' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106045,'TLR_INTER_DET_DOM10',0,'Labels','DOM 10','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106045 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106045,1025,N'DOM 10','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106046 and Name = 'TLR_INTER_DET_DOM11' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106046,'TLR_INTER_DET_DOM11',0,'Labels','DOM 11','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106046 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106046,1025,N'DOM 11','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106047 and Name = 'TLR_INTER_DET_DOM12' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106047,'TLR_INTER_DET_DOM12',0,'Labels','DOM 12','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106047 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106047,1025,N'DOM 12','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106048 and Name = 'TLR_INTER_DET_DOM13' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106048,'TLR_INTER_DET_DOM13',0,'Labels','DOM 13','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106048 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106048,1025,N'DOM 13','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106049 and Name = 'TLR_INTER_DET_DOM14' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106049,'TLR_INTER_DET_DOM14',0,'Labels','DOM 14','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106049 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106049,1025,N'DOM 14','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106050 and Name = 'TLR_INTER_DET_DOM15' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106050,'TLR_INTER_DET_DOM15',0,'Labels','DOM 15','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106050 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106050,1025,N'DOM 15','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106051 and Name = 'TLR_INTER_DET_DOM16' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106051,'TLR_INTER_DET_DOM16',0,'Labels','DOM 16','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106051 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106051,1025,N'DOM 16','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106052 and Name = 'TLR_INTER_DET_DOM17' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106052,'TLR_INTER_DET_DOM17',0,'Labels','DOM 17','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106052 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106052,1025,N'DOM 17','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106053 and Name = 'TLR_INTER_DET_DOM18' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106053,'TLR_INTER_DET_DOM18',0,'Labels','DOM 18','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106053 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106053,1025,N'DOM 18','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106054 and Name = 'TLR_INTER_DET_DOM19' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106054,'TLR_INTER_DET_DOM19',0,'Labels','DOM 19','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106054 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106054,1025,N'DOM 19','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106055 and Name = 'TLR_INTER_DET_DOM20' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106055,'TLR_INTER_DET_DOM20',0,'Labels','DOM 20','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106055 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106055,1025,N'DOM 20','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106056 and Name = 'TLR_INTER_DET_DOM21' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106056,'TLR_INTER_DET_DOM21',0,'Labels','DOM 21','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106056 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106056,1025,N'DOM 21','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106057 and Name = 'TLR_INTER_DET_DOM22' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106057,'TLR_INTER_DET_DOM22',0,'Labels','DOM 22','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106057 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106057,1025,N'DOM 22','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106058 and Name = 'TLR_INTER_DET_DOM23' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106058,'TLR_INTER_DET_DOM23',0,'Labels','DOM 23','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106058 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106058,1025,N'DOM 23','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106059 and Name = 'TLR_INTER_DET_DOM24' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106059,'TLR_INTER_DET_DOM24',0,'Labels','DOM 24','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106059 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106059,1025,N'DOM 24','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106060 and Name = 'TLR_INTER_DET_DOM25' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106060,'TLR_INTER_DET_DOM25',0,'Labels','DOM 25','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106060 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106060,1025,N'DOM 25','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106061 and Name = 'TLR_INTER_DET_DOM26' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106061,'TLR_INTER_DET_DOM26',0,'Labels','DOM 26','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106061 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106061,1025,N'DOM 26','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106062 and Name = 'TLR_INTER_DET_DOM27' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106062,'TLR_INTER_DET_DOM27',0,'Labels','DOM 27','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106062 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106062,1025,N'DOM 27','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106063 and Name = 'TLR_INTER_DET_DOM28' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106063,'TLR_INTER_DET_DOM28',0,'Labels','DOM 28','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106063 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106063,1025,N'DOM 28','Mar 10 2021 10:19AM')
End
go
------------------------------------------------------------------------------------------------
--------------------------RulesTranDescriptors-------------------------------------------------------
---------------------------------------------------------------------------------------------
--MORNINGG PROCESS
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Morning_Processing'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Morning_Processing' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Morning_Processing'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Morning_Processing' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Special_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Special_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Special_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Special_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Add_Spec_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Add_Spec_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Add_Spec_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Add_Spec_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Proc_In_The_Same_Month'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Proc_In_The_Same_Month' ,'ITSOFT\aya.tarek'  ) 
END
Go



IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Proc_In_The_Same_Month'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Proc_In_The_Same_Month' ,'ITSOFT\aya.tarek'  ) 
END
Go

--Popup
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Default_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Default_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Default_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Default_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Default_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Default_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Default_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Default_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Default_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Default_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Default_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Default_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_FI_Default_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_FI_Default_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_FI_Default_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_FI_Default_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_FI_Default_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_FI_Default_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_FI_Default_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_FI_Default_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Special_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Special_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Special_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Special_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_Special_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_Special_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_Special_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_Special_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_FI_Special_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_FI_Special_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_FI_Special_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_FI_Special_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_FI_Special_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_FI_Special_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_FI_Special_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_FI_Special_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go

-----------------------------RulesTranField_ex-----------
--------------------------------------------------------------
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_chkTLR_MORNING_PROCESSING')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_chkTLR_MORNING_PROCESSING' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_chkTLR_MORNING_PROCESSING')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_chkTLR_MORNING_PROCESSING' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_chkTLR_SPECIAL_RATES')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_chkTLR_SPECIAL_RATES' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_chkTLR_SPECIAL_RATES')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_chkTLR_SPECIAL_RATES' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_chkTLR_PROCESS_IN_THE_SAME_MONTH')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_chkTLR_PROCESS_IN_THE_SAME_MONTH' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_chkTLR_PROCESS_IN_THE_SAME_MONTH')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_chkTLR_PROCESS_IN_THE_SAME_MONTH' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_btnAddSpecialRates')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_btnAddSpecialRates' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_btnAddSpecialRates')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_btnAddSpecialRates' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

--Popup
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_Default_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_Default_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_Default_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_Default_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_Default_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_Default_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_Default_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_Default_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_FIDefault_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_FIDefault_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_FIDefault_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_FIDefault_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_Special_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_Special_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_Special_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_Special_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_Special_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_Special_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_Special_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_Special_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_txtTLR_FISpecial_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_txtTLR_FISpecial_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_txtTLR_FISpecial_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_txtTLR_FISpecial_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO
------------
-- PickLists
------------
IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 575)
BEGIN
 INSERT INTO PickLists(AppID,PickListID,PickList_Name,Updator,Creator,RowStatus)
 VALUES (1,575,'TLR_CUSTOMSCHEDULE_PERIOD',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1)
END
GO

-------------------
-- PickList_Entries
-------------------
IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 0)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,0,'TLR_INTER_DET_DAYS','Day(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 1)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,1,'TLR_INTER_DET_WEEKS','Week(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 2)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,2,'TLR_INTER_DET_MONTH','Month(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 3)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,3,'TLR_INTER_DET_YEAR','Year(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 4)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,4,'TLR_INTER_DET_DOM29','DOM 29',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 5)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,5,'TLR_INTER_DET_DOM30','DOM 30',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 6)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,6,'TLR_INTER_DET_EOM','EOM(s)',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO

IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID = 575 AND DisplayOrder = 7)
BEGIN
 INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 VALUES (575,1,7,'TLR_INTER_DET_EOQ','EOQ',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
END
GO
-----------------------------------------------------------------------------------------------------
---------------------HostCoreService&& IT'S HostCoreServiceFields -------
-----------------------------------------------------------------------------------------------------
-- GetAutoDefAndSpecialRates
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription, Developer , Updator )
	Values(@serviceID,N'GetAutoDefAndSpecialRates',N'MiscellaneousInquiry',N'Get Default Rates and Special Rates for AUTO_TFR','ITSOFT\AyaTarek' , 'ITSOFT\AyaTarek')
END
GO
--SO_ID
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='SO_ID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SO_ID',N'int',0,1,'Null',N'I')
END
GO

--From_currency_ID
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='From_currency_ID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'From_currency_ID',N'int',0,0,'Null',N'I')
END
GO

--TO_currency_ID
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='TO_currency_ID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'TO_currency_ID',N'int',0,0,'Null',N'I')
END
GO

--Foreign_Index_currency
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='Foreign_Index_currency')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'Foreign_Index_currency',N'int',0,1,'NUll',N'I')
END
GO

--default_buy_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='default_buy_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'default_buy_rate',N'decimal',0,0,0,N'O')
END
GO


--default_sell_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='default_sell_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'default_sell_rate',N'decimal',0,0,0,N'O')
END
GO

--default_fi_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='default_fi_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'default_fi_rate',N'decimal',0,0,0,N'O')
END
GO

--special_buy_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='special_buy_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'special_buy_rate',N'decimal',0,0,0,N'O')
END
GO


--special_sell_rate 
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='special_sell_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'special_sell_rate',N'decimal',0,0,0,N'O')
END
GO

--special_fi_rate
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='special_fi_rate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'special_fi_rate',N'decimal',0,0,0,N'O')
END
GO

--buy_rate_type
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='buy_rate_type')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'buy_rate_type',N'char',0,0,'NUll',N'O')
END
GO

--sell_rate_type
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='sell_rate_type')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'sell_rate_type',N'char',0,0,'NUll',N'O')
END
GO

--fi_rate_type
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates') AND FieldName='fi_rate_type')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='GetAutoDefAndSpecialRates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'fi_rate_type',N'char',0,0,'NUll',N'O')
END
GO


--ListStandingOrders
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders') AND FieldName='MorningProcessing')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'MorningProcessing',N'char',N'999',0,'N',N'O')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders') AND FieldName='ProcessSameMonth')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'ProcessSameMonth',N'char',N'999',0,'N',N'O')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders') AND FieldName='SpecialRates')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListStandingOrders'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SpecialRates',N'char',N'999',0,'N',N'O')
END
GO

--ListTransfersDates
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListTransfersDates') AND FieldName='psTfrProcSmMn')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListTransfersDates'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'psTfrProcSmMn',N'char',N'999',1,'N',N'I')
END
GO

--------------------------------------------------SQLstrings----------------------------------------------------------------------
IF Not Exists(select * from SQLstrings where AccessID = 1100133)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile , Developer , Updator , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100133 , 'HS_GETAUTODEFANDSPECIALRATES' , 'p' , 1, 'GFSOLEDB' , 'dbo.HS_GETAUTODEFANDSPECIALRATES' , 0 , '' , '' , 'ITSOFT\aya.tarek' , 'ITSOFT\aya.tarek' , 'Get Default Rates and Special Rates for Auto TFR ' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO

-----------------------------TPI---------------------------------
If  Exists(Select * From BankTPIInterface Where  FieldCode = 'AUT')
Begin
 update  BankTPIInterface  set NoOfParameters =125  
 where  FieldCode = 'AUT'
End
go

PRINT 'End... Script for CR# GFSY00879 DML Script....Aya.Tarek'
GO
--===============================================================================
--Devolper	:	Ahmed Atef
--Date		:	[03/10/2021]
--Reason	:	Enh GFSY00875 - ACM000000019714 - ITS - Card Less Withdrawal-Part2
--================================================================================
--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1105966 and Name = 'TLR_SOLD_REM_CANCEL')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1105966	,'TLR_SOLD_REM_CANCEL',1,'Labels','Sold Remittance Cancellation','ITSOFT\ahmed.atef','2021-09-09 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000',	'2021-09-09 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1105966 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1105966 , 1025, N'الغاء التحويلات المباعة'	,'ITSOFT\ahmed.atef','2021-09-09 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1105967 and Name = 'TLR_CANCEL_METHOD')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1105967	,'TLR_CANCEL_METHOD',1,'Labels','Cancellation Method','ITSOFT\ahmed.atef','2021-09-09 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000',	'2021-09-09 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1105967 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1105967 , 1025, N'طريقة الالغاء'	,'ITSOFT\ahmed.atef','2021-09-09 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106030 and Name = 'TLR_REM_PAID')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106030	,'TLR_REM_PAID',1,'Labels','Remittance Status updated successfully with Paid','ITSOFT\ahmed.atef','2021-11-03 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000',	'2021-11-03 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106030 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106030 , 1025, N'تم تحديث بيانات الحوالة لدي ETHIX Net To Paid'	,'ITSOFT\ahmed.atef','2021-11-03 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106031 and Name = 'TLR_REM_CANCEL')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106031	,'TLR_REM_CANCEL',1,'Labels','Remittance Status updated successfully with Cancelled','ITSOFT\ahmed.atef','2021-11-03 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000',	'2021-11-03 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106031 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106031 , 1025, N'تم تحديث بيانات الحوالة لدي ETHIX Net To cancelled'	,'ITSOFT\ahmed.atef','2021-11-03 03:27:00')
End
GO

----------------------------------
-- Menu_Action & Menu_Definition -
----------------------------------
IF NOT EXISTS (SELECT * FROM Menu_Action WHERE MenuActionID = 891)
BEGIN
    INSERT INTO Menu_Action (MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Enabled,LastChanged,Created,RowStatus,EffectiveDate,ExpirationDate,Updator,Creator) 
    VALUES(891,1,1105966,'Sold Remittance Cancellation',2,'SoldRemittanceCancellation',1,'2021-09-09','2021-09-09',1,'1901-01-01 00:00','9998-12-31 00:00','ITSOFT\ahmed.atef','ITSOFT\ahmed.atef')
END
GO

IF NOT EXISTS (SELECT * FROM Menu_Definition WHERE MenuActionID = 891)
BEGIN
INSERT INTO Menu_Definition (MenuID,MenuKey,Parent,MenuActionID,LastChanged,Created,RowStatus,EffectiveDate,ExpirationDate,Updator,Creator) 
    VALUES(2501,485,48,891,'2021-09-09','2021-09-09',1,'1901-01-01 00:00','9998-12-31 00:00','ITSOFT\ahmed.atef','ITSOFT\ahmed.atef')
END
GO

--------------------
-- RulesTotalsType -
--------------------
IF NOT EXISTS (SELECT * FROM RulesTotalsType WHERE TotalsID = 270)
BEGIN
INSERT INTO RulesTotalsType(TotallingName,TotallingName_DSC,TotalsID,AppID,Developer,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created)
	VALUES('SoldRemmitanceCancel', 'TLR_SOLD_REM_CANCEL', 270, 1, 'ITSOFT\ahmed.atef','2021-09-09',1,'1901-01-01 00:00:00.000','9999-12-31 00:00:00.000','2021-09-09')
END
GO
------------------
-- RulesTranName -
------------------
IF NOT EXISTS (SELECT * FROM RulesTranName WHERE TranID = 868)
BEGIN
INSERT INTO RulesTranName(TransactionName,TranID,Description,Developer,DSC_Description,LastChanged,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,RowStatus,EffectiveDate,ExpirationDate,Created,Updator,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,TotalsType,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
	VALUES('SoldRemittanceCancellation', 868, 'Sold Remittance Cancellation','ITSOFT\ahmed.atef',1105966,'2021-09-09',101,'DDA',101,1,'RemCnl',1,1,1,1,0,0,0,1,'1901-01-01 00:00:00.000','9999-12-31 00:00:00.000','2021-09-09',N'ITSOFT\ahmed.atef',0,0,0,0,1,0,0,0,1,0,0,NULL,NULL,NULL,0,NULL,0,'SoldRemmitanceCancel',0,0,0,NULL,868,1)
END
GO
------------------
-- RulesTotals   -
------------------
IF Not EXISTS ( Select * From  RulesTotals Where  TotalsID = 591 and TranField = 1000140 and CurrencyFieldID = 1000068) 
BEGIN 
 INSERT INTO RulesTotals ( TotalsID ,Sequence,AppID ,TranField,CurrencyFieldID,Bucket,BumpBy)  
 Values( 591, 3, 1,1000140,1000068,'Cash Out',1)
END 
GO
IF Not EXISTS ( Select * From  RulesTotals Where  TotalsID = 270 and TranField = 1786 and CurrencyFieldID = 1784) 
BEGIN 
 INSERT INTO RulesTotals ( TotalsID ,Sequence,AppID ,TranField,CurrencyFieldID,Bucket,BumpBy)  
 Values( 270, 1, 1,1786,1784,'Cash Out',1)
END 
GO
IF Not EXISTS ( Select * From  RulesTotals Where  TotalsID = 270 and TranField = 1129 and CurrencyFieldID = 1921) 
BEGIN 
 INSERT INTO RulesTotals ( TotalsID ,Sequence,AppID ,TranField,CurrencyFieldID,Bucket,BumpBy)  
 Values( 270, 2, 1,1129,1921,'Cash In',1)
END
GO
IF Not EXISTS ( Select * From  RulesTotals Where  TotalsID = 270 and TranField = 1000140 and CurrencyFieldID = 1000068) 
BEGIN 
 INSERT INTO RulesTotals ( TotalsID ,Sequence,AppID ,TranField,CurrencyFieldID,Bucket,BumpBy)
 Values( 270, 3, 1,1000140,1000068,'Cash Out',1)
END
GO
--------------
-- Component -
--------------
If Not Exists(Select * From Component Where ComponentID = 312)
Begin
 Insert Into Component(ComponentID,AppID,ComponentName,ComponentType,Description,ProjectDirectory,ProjectFile,ProjectType,ProjectTarget,ProductionGroup,isSourceShipped,TargetDirectory,TypeLibrary,TypeLibVersion,GUID,VersionInfoFile,FileVersion,ComponentSize,Developer,InstallDirectory,Updator,ProductionGroup2,InstallDirectory2,RowStatus,WiseProject,BuildChangesOnly,SymbolsFile,ProjectGUID)
 Values (312,1,N'SoldRemmitanceCancel','DLL','',N'Teller.Net\Source\BP\Custom\SoldRemittanceCancellation',N'SoldRemittanceCancellation.csproj','C#2010',N'Debug','Client_NonRegistered',0,N'..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\',NULL,NULL,NULL,NULL,'2.0.46.0',57344,N'ITSOFT\ahmed.atef',N'shared.net\Source\bin\Common\Teller',N'ITSOFT\ahmed.atef',NULL,NULL,1,N'GFSTellerdotNetClient.wsm',1,N'SoldRemittanceCancellation.pdb',NULL)
End
go

------------------------
-- RulesContainerTrans -
------------------------
If Not Exists(Select * From RulesContainerTrans WHERE TranName = 'SoldRemittanceCancellation')
Begin
 Insert Into RulesContainerTrans(container_name,TranName,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('Teller','SoldRemittanceCancellation','2021-09-09 19:17:03',N'ITSOFT\ahmed.atef',1,'9998-12-31 00:00:00.000','2021-09-09 19:17:03')
End
go

--------------------
-- RulesTranConfig -
--------------------
If Not Exists(SELECT * FROM RulesTranConfig WHERE TranID =  868)
Begin
 Insert Into RulesTranConfig(TranID,DenomRequired,AccountingEntries,AllowEmptyAccountingEntries,ReadAllAccountingEntries,LastChanged,Updator,PrintOption,ForcePositioning,EnableCharges,SalesMessageActive,FutureStaleChequeDays,BackDatedStaleChequeDays,ValidateStaleCheque,StaleChequeAction,StaleChequeDefaultDate,EscWarningEnabled,Blacklisted,BlacklistedAction,BenPmtStrict,BenPmtWarning,HasCheckList,CheckListCategoryID,ShowAvlBal,AutoPrintPassBook,DaysAllowedForReversal,CashFollowAcctCurr,useFX,CheckDrawerTypeRestrictions,use_XPath_app,SameRIMForCharge,SameCurrencyForCharge,PrimaryIDExpiryAction,PrimaryIDExpiryVal,RecoveryReversal,CustomerInquiry,ReviewVouchersBeforePrinting,UpdDateReqired,UpdDateValue,UpdDateAction,IsFinancialTran,CHK_AccumilativeInfoMessage,CHK_IncludeAccumilative,OpenSessionRequired,SupportResend,CheckBillPastDueDT,PastDueDTAction,UseExpressions,WorkOnNightlyModeAllowed)
 Values (868,1,1,1,1,'2021-09-09 12:15:00',N'ITSOFT\ahmed.atef',1,0,0,0,0,0,0,'Warning',0,0,1,'STOP', 0,0,0,0,1,0,10,1,1,0,0,0,0,'Warning',0,1,0,1,0,1,0,0,0,0,1,0,0,'Warning',1,0)   
End
go

----------------------
-- TransactionScopes -
----------------------
If Not Exists(Select * From TransactionScopes Where  TranID = 868)
Begin
 Insert Into TransactionScopes(Scope,TranID,Developer,Updator,RowStatus)
 Values (1001,868,N'ITSOFT\ahmed.atef',N'ITSOFT\ahmed.atef',1)
End
GO

-------------------
-- RulesTranField -
-------------------
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = -1099996)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, Row_ID, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, -1099996, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), 1, NULL, 'L1Node', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-09 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 'E6D3A950-8808-EB11-810D-005056974FD8', 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = -1099995)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, -1099995, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), 1, NULL, 'L2Node', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-09 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = -1099994)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, -1099994, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), 1, NULL, 'L3Node', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-09 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = -129980)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, -129980, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), 1, NULL, 'Totals_Amount', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-09 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = -129979)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, -129979, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), 1, NULL, 'Totals_Batch', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-09 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = -129975)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, -129975, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), 1, NULL, 'Totals_Bucket', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-09 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = -129974)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, -129974, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), 1, NULL, 'Totals_BumpBy', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-09 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = -129973)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, -129973, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), 1, NULL, 'Totals_Currency_Type', CONVERT(DATETIME, '2021-09-09 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-09 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 9)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 9, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'RemittanceAmount', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 145)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 145, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'IDType', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 146)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 146, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'IDNumber', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 186)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 186, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'GTDDealTicket', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 191)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 191, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'ReferenceNo', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 209)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 209, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'BeneficiaryName', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 210)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 210, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'RemittanceIssuer', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1480)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1480, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2021-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'CancellationMethod', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 345)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 345, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'RemittanceCharges', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 384)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 384, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'SerialNumber', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 389)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 389, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'SecuirtyQuestion', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 395)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 395, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'Notes', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 458)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 458, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'ClearBankGL', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1074)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1074, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'IssuerName', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1092)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1092, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'LocalBankOption', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1103)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1103, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'RemittancCurrency', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1131)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1131, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'IssueDate', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1250)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1250, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1302)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1302, 0, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'BeneficiaryPhone', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1450)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868,1450 , 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1595)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868,1595 , 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1783)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1783, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'PaymentAmount', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1786)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1786, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2021-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1784)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868,1784 , 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1842)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1842, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'SecuirtyAnswer', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1000041)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1000041, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'TotalCharges', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1000042)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868,1000042 , 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'PrintOption', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 1000140)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868, 1000140, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2020-09-14 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2020-09-14 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 868 AND FieldID = 238)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(868,238 , 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2021-11-11 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2021-11-11 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2021-11-11 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, NULL, 1, - 1, NULL, NULL, NULL)
END
GO
-------------------------
-- RulesTranDescriptors -
-------------------------

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_SOLD_REM_CANCEL')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_SOLD_REM_CANCEL', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_CANCEL_METHOD')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_CANCEL_METHOD', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_ACCOUNT')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_ACCOUNT', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_CASH_DENOM')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_CASH_DENOM', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'COR_CANCEL')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'COR_CANCEL', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'COR_OK')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'COR_OK', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'COR_PRINT_OPTION')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'COR_PRINT_OPTION', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'IssueDate')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'IssueDate', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_AMOUNT')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_AMOUNT', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_ANSWER')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_ANSWER', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_BANK_CODE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_BANK_CODE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_BANK_NAME')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_BANK_NAME', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_BENEFICIARY_ID')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_BENEFICIARY_ID', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_BENEFICIARY_ID1')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_BENEFICIARY_ID1', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_BENEFICIARY_NAME')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_BENEFICIARY_NAME', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_BRANCH_CODE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_BRANCH_CODE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_BRANCH_NAME')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_BRANCH_NAME', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_Change')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_Change', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_CORR_BRANCH_DETAILS')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_CORR_BRANCH_DETAILS', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_CURRENCY')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_CURRENCY', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_CUSTOMER_ID_NUMBER')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_CUSTOMER_ID_NUMBER', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_CUSTOMER_ID_TYPE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_CUSTOMER_ID_TYPE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_DD_CO_STYPE_BENNAME')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_DD_CO_STYPE_BENNAME', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_EXTERNAL_ISSUING')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_EXTERNAL_ISSUING', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_GL_NUMBER')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_GL_NUMBER', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_GTD_TKT')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_GTD_TKT', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_IR_AMOUNT')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_IR_AMOUNT', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_IR_CURRENCY')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_IR_CURRENCY', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_ISSUER_DETAILS')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_ISSUER_DETAILS', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_ISSUER_NAME')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_ISSUER_NAME', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_IssuerBranch')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_IssuerBranch', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_LOCAL_BANK')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_LOCAL_BANK', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_MODE_OF_OPERATION')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_MODE_OF_OPERATION', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_NOTES')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_NOTES', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_OUR_BANK_BRANCH')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_OUR_BANK_BRANCH', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_PAYMENT_CURRENCY')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_PAYMENT_CURRENCY', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_PAYMENT_DETAIL')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_PAYMENT_DETAIL', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_PAYMENTAMOUNT')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_PAYMENTAMOUNT', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_PaymentClearBankID')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_PaymentClearBankID', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_PaymentClearBranchID')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_PaymentClearBranchID', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_PHONE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_PHONE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_Reference_No')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_Reference_No', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_REMITTANCE_CHARGES')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_REMITTANCE_CHARGES', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_REMITTANCE_DETAILS')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_REMITTANCE_DETAILS', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_RESULT_OTHERS')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_RESULT_OTHERS', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_SEARCH')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_SEARCH', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_SEARCH_BY')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_SEARCH_BY', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_SECUIRTY_QUES')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_SECUIRTY_QUES', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_Serial')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_Serial', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_SoldReM_Posted')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_SoldReM_Posted', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 868 AND DSC_Name = 'TLR_TOTAL_CHARGES')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(868, 'TLR_TOTAL_CHARGES', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

----------------------
-- RulesTranField_ex -
----------------------
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lbl_option')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lbl_option',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lblSerialNum')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lblSerialNum',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lblTLR_REFERENCE_NUMBER')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lblTLR_REFERENCE_NUMBER',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lblTLR_BeneficiaryName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lblTLR_BeneficiaryName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lblTLR_IDTYPE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lblTLR_IDTYPE',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lblTLR_ID_NUM')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lblTLR_ID_NUM',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lbl_IssueDate')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lbl_IssueDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lblTLR_IssuerName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lblTLR_IssuerName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lbl_Notes')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lbl_Notes',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = 'lbl_SecurityQuestion')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','lbl_SecurityQuestion',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = 'lbl_Answer')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','lbl_Answer',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = 'lblPhone')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','lblPhone',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lblTLR_CURRENCY')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lblTLR_CURRENCY',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lblTLR_AMOUNT')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lblTLR_AMOUNT',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lbl_Paym_Curr')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lbl_Paym_Curr',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lbl_Paym_Amount')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lbl_Paym_Amount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lbl_Change')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lbl_Change',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_lblGTDDealTicket')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_lblGTDDealTicket',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_cbo_Local_option')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_cbo_Local_option',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_cboPaymentCurrType')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_cboPaymentCurrType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_chargeControl')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_chargeControl',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_datTLR_Issue_VALUE_DATE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_datTLR_Issue_VALUE_DATE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_exchangeRates')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_exchangeRates',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_OptPrint')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_OptPrint',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_optRemittanceIssuer')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_optRemittanceIssuer',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_optCancelMethod')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_optCancelMethod',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_optCancelMethod')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_optCancelMethod',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_PaymentAmount')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_PaymentAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_RemAmount')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_RemAmount',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_txt_Change')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_txt_Change',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_txt_ID_Type')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_txt_ID_Type',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_txt_Notes')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_txt_Notes',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_txt_RemCurr')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_txt_RemCurr',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_txt_Serial_Num')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_txt_Serial_Num',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_txtBeneficiaryName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_txtBeneficiaryName',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_txtGTDDealTicket')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_txtGTDDealTicket',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_txtTLR_DEPOSITER_ID_NUMBER')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_txtTLR_DEPOSITER_ID_NUMBER',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = '_txtTLR_IssuerName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','_txtTLR_IssuerName',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = 'cbo_SecuirtyQuestion')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','cbo_SecuirtyQuestion',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = 'txt_Answer')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','txt_Answer',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = 'txt_ReferenceNo')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','txt_ReferenceNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = 'txt_RefNo')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','txt_RefNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 868 And FieldID Is Null And FieldIDInPage = 'txtBeneficiaryPhone')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (868,NULL,'Teller','txtBeneficiaryPhone',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
----------------------
-- RulesTranFldParam -
----------------------
IF NOT EXISTS (SELECT * FROM dbo.RulesTranFldParam Where TranName = 'SoldRemittanceCancellation' AND FieldName = 'AmountCurrType' AND Param = 'CurrencyCategoryID' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'SoldRemittanceCancellation' , 'AmountCurrType' , 'CurrencyCategoryID' , Null ,N'ITSOFT\ahmed.atef' , 'nvarchar')
END
---------------
-- SQLstrings -
---------------
IF NOT EXISTS(Select * From SQLstrings Where AccessID = 1100123)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES(1,1100123,'TLR_GETSOLDREMITTANCEDATA','p',1,'Globalfs','dbo.Get_SoldRemittanceData',0,'','','ITSOFT\ahmed.atef','ITSOFT\ahmed.atef','Select all sold remittances with status Issued only and other criteria',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
END
GO

-------------------
-- RulesTranSteps -
-------------------
IF NOT EXISTS ( Select * From  dbo.RulesTranSteps Where  TranID = 868  AND  StepSequence =  20   ) 
BEGIN 
	INSERT INTO dbo.RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  )  
	SELECT 868   ,   20   ,   305   ,   0   ,   0   ,  'JournalInsert'  ,  'ITSOFT\\ahmed.atef'  ,  'ITSOFT\\ahmed.atef' 
END 
GO
IF NOT EXISTS ( Select * From  dbo.RulesTranSteps Where  TranID = 868  AND  StepSequence =  40   ) 
BEGIN 
	INSERT INTO dbo.RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  )  
	SELECT 868   ,   40   ,   413   ,   0   ,   1   ,  'SendToPhoenix'  ,  'ITSOFT\ahmed.atef'  ,  'ITSOFT\ahmed.atef' 
END 
GO
IF NOT EXISTS ( Select * From  dbo.RulesTranSteps Where  TranID = 868  AND  StepSequence =  60   ) 
BEGIN 
	INSERT INTO dbo.RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  )  
	SELECT 868   ,   60   ,   305   ,   0   ,   1   ,  'JournalUpdate'  ,  'ITSOFT\ahmed.atef'  ,  'ITSOFT\ahmed.atef' 
END

-------------------------------------------------------------------------------------
-- RulesErrorDescription && RulesLocalErrorDescription && RulesTranErrorDescriptions-
-------------------------------------------------------------------------------------

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1814)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID)
 Values (1814,'WITHDRAWAL_STATUS_ERR','Failed to update ETHIX Net with status','Failed to update ETHIX Net with status',4,'ErrDesc.hlp',1)
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1814 And LanguageLCID = 1025)
BEGIN
 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
 Values (1814,1025,N'خطأ في تحديث بيانات الحوالة لدي ETHIX Net',N'خطأ في تحديث بيانات الحوالة لدي ETHIX Net')
END
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'OnUsRemittanceAganistAccount' AND  Error_Name   = 'WITHDRAWAL_STATUS_ERR'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'OnUsRemittanceAganistAccount'  ,  'WITHDRAWAL_STATUS_ERR'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'OnUsRemittanceAganistCash' AND  Error_Name   = 'WITHDRAWAL_STATUS_ERR'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'OnUsRemittanceAganistCash'  ,  'WITHDRAWAL_STATUS_ERR'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'SoldRemittanceCancellation' AND  Error_Name   = 'WITHDRAWAL_STATUS_ERR'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'SoldRemittanceCancellation'  ,  'WITHDRAWAL_STATUS_ERR'   )
END 
GO
--Devolper	 :	Aya Tarek 
--Date       :	[23/11/2021]		
--Reason     :	CR#GFSY00884 [Barwa So Execution US3]
------------------------------------------------------------------------------------------------
--RulesParam-----------
--------------------------------
If Not Exists(Select * From RulesParam Where ParamName='MaxRetrievedRecords')
Begin
    DECLARE @paramID1 int
    SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
    Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
    Values (@paramID1,'MaxRetrievedRecords','which represent the max. number of retrieved records in the data grid','',0,1,0,'','Static','')
End
--------------------------------
------------------------------------------------------------------------------------------------
--------------------------RulesDescriptor & RulesDesceiptorLocal--------------------------------
------------------------------------------------------------------------------------------------
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106080 and Name = 'TLR_PAYMENT_DUE_DATE' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106080,'TLR_PAYMENT_DUE_DATE',0,'Labels','Payment Due Date','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106080 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106080,1025,N'التاريخ المحدد للدفع','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106081 and Name = 'TLR_PROCESS_IN_MORNING' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106081,'TLR_PROCESS_IN_MORNING',0,'Labels','Process IN Morning','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106081 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106081,1025,N'العملية في الصباح','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106090 and Name = 'TLR_Max_Retrieved_Records' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106090,'TLR_Max_Retrieved_Records',0,'Labels','Cannot Exceed {0} Selected Rows Max','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106090 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106090,1025,N'عدد الصفوف المختارة {0} كحد اقصى ','Mar 10 2021 10:19AM')
End
go
------------------------------------------------------------------------------------------------
--------------------------RulesTranDescriptors-------------------------------------------------------
---------------------------------------------------------------------------------------------
--MORNINGG PROCESS
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_RIM_NUM'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_RIM_NUM' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_PAYMENT_DUE_DATE'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_PAYMENT_DUE_DATE' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_PROCESS_IN_MORNING'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272  ,'TLR_PROCESS_IN_MORNING' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_Special_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_Special_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_Add_Spec_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_Add_Spec_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go


--Popup
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_Default_Rates'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_Default_Rates' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_Default_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_Default_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_Default_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_Default_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_FI_Default_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_FI_Default_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_Special_Buy_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_Special_Buy_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_Special_Sell_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_Special_Sell_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 272 AND  Dsc_name =  'TLR_FI_Special_Rate'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 272   ,'TLR_FI_Special_Rate' ,'ITSOFT\aya.tarek'  ) 
END
Go
-----------------------------RulesTranField-----------
--------------------------------------------------------------
--TLR_PROCESSING_TYPE (Process in Moring)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  460  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   460   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
--TLR_BENEFICIARY_SEQUENCE_NO (Rim No)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  316  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   316   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
--TLR_SO_NEXT_TRANSFER_DATE (Payment Due Date)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  1162  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   1162   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
-- TLR_CLIENT_SEGMENT_ARRAY(Gridview(Morningprocessing))
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  1882  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   1882   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
--TLR_ExpensesCurrency (GridView(SpecialRates)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  238  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   238   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_INWARD_ACCT_FLAGE (FromCurrency)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  969  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   969   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_RIM_BRANCH_ARR (tocurrency)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  1637  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   1637   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_BUY_RATE_ARRAY (specialBuyRate)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  585  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   585   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go


--TLR_SELL_RATE_ARRAY (specialsellRate)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  586  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   586   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_BUY_RATE_ARRAY2 (specialFIRate)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 272  AND  FieldID   =  988  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 272   ,   988   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
-----------------------------RulesTranField_ex-----------
--------------------------------------------------------------
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_cboTLR_SO_SearchTypeRimNumber')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_cboTLR_SO_SearchTypeRimNumber' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_lblPaymentDueDate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_lblPaymentDueDate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_datTLR_PAYMENT_DUE_DATE')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_datTLR_PAYMENT_DUE_DATE' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_chkTLR_MORNING_PROCESSING')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_chkTLR_MORNING_PROCESSING' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_lblRIMNOOptionset')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_lblRIMNOOptionset' , -1 , -1 , -1 , 0 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_txtTLR_RIM_NO_Optionset')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_txtTLR_RIM_NO_Optionset' , -1 , -1 , -1 , 0 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_btnAddSpecialRates')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_btnAddSpecialRates' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

--Popup
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_txtTLR_Default_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_txtTLR_Default_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO



IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_txtTLR_Default_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_txtTLR_Default_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO


IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_txtTLR_FIDefault_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_txtTLR_FIDefault_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_txtTLR_Special_Buy_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_txtTLR_Special_Buy_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO


IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_txtTLR_Special_Sell_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_txtTLR_Special_Sell_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO



IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=272 AND FieldIDInPage='_txtTLR_FISpecial_Rate')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 272 , NULL , 'Teller' , '_txtTLR_FISpecial_Rate' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

--------------------------------
--RulesTranFldParam-----------
--------------------------------
-- MaxNumberOfTransfer SOpayment

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'SoPaymentExecution' AND FieldName ='NoOFRetrievedRecords' AND Param = 'MaxRetrievedRecords' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'SoPaymentExecution' , 'NoOFRetrievedRecords' , 'MaxRetrievedRecords' , 30 ,'ITSOFT\aya.tarek' , 'int')
 END 
GO

-----------------------------------------------------------------------------------------------------
---------------------HostCoreService&& IT'S HostCoreServiceFields -------
-----------------------------------------------------------------------------------------------------
--ListSODuePayment 121
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment') AND FieldName='MorningProcessing')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'MorningProcessing',N'char',N'999',0,'N',N'O')
END
GO


IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment') AND FieldName='SpecialRates')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SpecialRates',N'char',N'999',0,'N',N'O')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment') AND FieldName='FromCrncyID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'FromCrncyID',N'int',N'999',0,NULL,N'O')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment') AND FieldName='ToCrncyID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'ToCrncyID',N'int',N'999',0,NULL,N'O')
END
GO



IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment') AND FieldName='SpecialBuyRate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SpecialBuyRate',N'decimal',N'999',0,NULL,N'O')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment') AND FieldName='SpecialSellRate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SpecialSellRate',N'decimal',N'999',0,NULL,N'O')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment') AND FieldName='SpecialFIRate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SpecialFIRate',N'decimal',N'999',0,NULL,N'O')
END
GO

--CallExecuteSOPayment 124
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CallExecuteSOPayment') AND FieldName='SpecialBuyRate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CallExecuteSOPayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SpecialBuyRate',N'decimal',N'999',0,0,N'I')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CallExecuteSOPayment') AND FieldName='SpecialSellRate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CallExecuteSOPayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SpecialSellRate',N'decimal',N'999',0,0,N'I')
END
GO


IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CallExecuteSOPayment') AND FieldName='SpecialFIRate')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CallExecuteSOPayment'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'SpecialFIRate',N'decimal',N'999',0,0,N'I')
END
GO

GO
------------------------ 
------ GFSY00887
------ Shaimaa AbdelNasser Mohamed 
------ 06/12/2021
----------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------************ RulesDescriptor 

	If Not Exists(Select * From RulesDescriptor  Where  DescriptorID = 1106087)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106087,'TLR_RELATION_PICKLIST',0,'Labels','Relation',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go  
----------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------************ RulesTranDescriptors
------BBKChequeDeposit

	If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'lbl_DocumentsReceived' AND TranID = 211 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (211,'lbl_DocumentsReceived',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
------IssueCOAgainstAccount
	If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'lbl_DocumentsReceived' AND TranID = 185 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (185,'lbl_DocumentsReceived',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
------AccountToAccountTransfer
	If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_RELATION_PICKLIST' AND TranID = 192 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (192,'TLR_RELATION_PICKLIST',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
------AddNewSO
	If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_RELATION_PICKLIST' AND TranID = 257 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (257,'TLR_RELATION_PICKLIST',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
------ModifyExistingSO
	If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_RELATION_PICKLIST' AND TranID = 260 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (260,'TLR_RELATION_PICKLIST',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
----------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------************ RulesTranField_ex
------BBKChequeDeposit
	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 211 AND FieldIDInPage='cbo_DocumentsReceived')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(211,NULL,N'Teller',N'cbo_DocumentsReceived',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO 

	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 211 AND FieldIDInPage='_lblDocumentsReceived')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(211,NULL,N'Teller',N'_lblDocumentsReceived',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO
------IssueCOAgainstAccount
	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 185 AND FieldIDInPage='cbo_DocumentsReceived')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(185,NULL,N'Teller',N'cbo_DocumentsReceived',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO

	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 185 AND FieldIDInPage='_lblDocumentsReceived')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(185,NULL,N'Teller',N'_lblDocumentsReceived',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO
------AccountToAccountTransfer
	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 192 AND FieldIDInPage='cbo_Relation')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(192,NULL,N'Teller',N'cbo_Relation',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO

	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 192 AND FieldIDInPage='_lblRelation')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(192,NULL,N'Teller',N'_lblRelation',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO
	GO
------AddNewSO
	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 257 AND FieldIDInPage='cbo_Relation')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(257,NULL,N'Teller',N'cbo_Relation',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO

	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 257 AND FieldIDInPage='_lblRelation')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(257,NULL,N'Teller',N'_lblRelation',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO
------ModifyExistingSO
	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 260 AND FieldIDInPage='cbo_Relation')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(260,NULL,N'Teller',N'cbo_Relation',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO

	IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 260 AND FieldIDInPage='_lblRelation')
	BEGIN
		INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
		Values(260,NULL,N'Teller',N'_lblRelation',-1,-1,-1,1,0,N'100',N'',N'',0)
	END
	GO
----------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------************ RulesTranField
------BBKChequeDeposit
	IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 211 AND FieldID = 264)--cbo_DocumentsReceived
	BEGIN
		 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
		 VALUES (211,264,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'DocumentsReceived',0,-1)
	END
	GO
------IssueCOAgainstAccount
	IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 185 AND FieldID = 264)--cbo_DocumentsReceived
	BEGIN
		 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
		 VALUES (185,264,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'DocumentsReceived',0,-1)
	END
	GO
------AccountToAccountTransfer
	IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 192 AND FieldID = 264)--Relation
	BEGIN
		 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
		 VALUES (192,264,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'Relation',0,-1)
	END
	GO

----------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------************ RulesParam

declare @paramid int
	select @paramid=MAX(paramid)+1 from RulesParam 
	 If Not Exists(Select * From RulesParam Where ParamName = 'Allowed_Doc.RecievedEntries')
	Begin
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@paramid,'Allowed_Doc.RecievedEntries','get allawed entries for DocumentReceived picklist.',NULL,0,0,0,'','Static    ','','Sep  22 2021 8:22AM',N'ITSOFT\shaimaa.nasser','Sep  22 1900 12:00AM','Dec 31 9999 12:00AM',1)
	End

------BBKChequeDeposit
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'BBKChequeDeposit' And Param = 'Allowed_Doc.RecievedEntries')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('BBKChequeDeposit','DocumentsReceived','Allowed_Doc.RecievedEntries','',N'ITSOFT\shaimaa.nasser','nvarchar','Dec  22 2021 8:22AM','get allawed entries for DocumentReceived picklist.')
	End

------IssueCOAgainstAccount
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'IssueCOAgainstAccount' And Param = 'Allowed_Doc.RecievedEntries')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('IssueCOAgainstAccount','DocumentsReceived','Allowed_Doc.RecievedEntries','',N'ITSOFT\shaimaa.nasser','nvarchar','Dec  22 2021 8:22AM','get allawed entries for DocumentReceived picklist.')
	End 

------CashDeposit
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'CashDeposit' And Param = 'Allowed_Doc.RecievedEntries')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('CashDeposit','DocumentsReceived','Allowed_Doc.RecievedEntries','',N'ITSOFT\shaimaa.nasser','nvarchar','Dec  22 2021 8:22AM','get allawed entries for DocumentReceived picklist.')
	End 

GO
--===========================================================
--Devolper	:	Ahmed Atef
--Date		:	[21/12/2021]
--Reason	:	Enh GFSY00888 [AUB Issue CO Reason Picklist]
--===========================================================
--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106088 and Name = 'TLR_OTHER_PURPOSE')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106088	,'TLR_OTHER_PURPOSE',1,'Labels','Other Purpose','ITSOFT\ahmed.atef','2021-12-07 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000',	'2021-12-07 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106088 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106088 , 1025, N'غرض أخر'	,'ITSOFT\ahmed.atef','2021-12-07 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106093 and Name = 'TLR_PURPOSE_4_PICKLIST' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus)
 Values (1,1106093,'TLR_PURPOSE_4_PICKLIST',0,'PickLists','Other','ITSoft\ahmed.atef','Dec 10 2021 10:19AM',1)
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106093 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106093,1025,N'أخري','Dec 10 2021 10:19AM')
End
GO
---------------------
-- PickList_Entries -
---------------------
If Not Exists(Select * From PickList_Entries Where PickListID = 168 And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (168,1,3,'TLR_PURPOSE_4_PICKLIST','Other','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Mar 10 2021 10:19AM','Mar 10 2021 10:19AM',N'ITSOFT\ahmed.atef',N'ahmed.atef',1,NULL)
End
-------------------------
-- RulesTranDescriptors -
-------------------------
--IssueCOAgainstAccount
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 185 AND DSC_Name = 'TLR_OTHER_PURPOSE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(185, 'TLR_OTHER_PURPOSE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
--IssueCOAgainstCash
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 183 AND DSC_Name = 'TLR_OTHER_PURPOSE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(183, 'TLR_OTHER_PURPOSE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
--IssueCOAgainstCheque
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 186 AND DSC_Name = 'TLR_OTHER_PURPOSE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(186, 'TLR_OTHER_PURPOSE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
--IssueCOAgainstGL
IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 281 AND DSC_Name = 'TLR_OTHER_PURPOSE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(281, 'TLR_OTHER_PURPOSE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
----------------------
-- RulesTranField_ex -
----------------------
--IssueCOAgainstAccount
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 185 And FieldID Is Null And FieldIDInPage = '_lblTLR_OTHER_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (185,NULL,'Teller','_lblTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstCash
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 183 And FieldID Is Null And FieldIDInPage = '_lblTLR_OTHER_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (183,NULL,'Teller','_lblTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstCheque
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 186 And FieldID Is Null And FieldIDInPage = '_lblTLR_OTHER_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (186,NULL,'Teller','_lblTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstGL
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 281 And FieldID Is Null And FieldIDInPage = '_lblTLR_OTHER_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (281,NULL,'Teller','_lblTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstAccount
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 185 And FieldID Is Null And FieldIDInPage = '_txtTLR_OTHER_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (185,NULL,'Teller','_txtTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstCash
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 183 And FieldID Is Null And FieldIDInPage = '_txtTLR_OTHER_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (183,NULL,'Teller','_txtTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstCheque
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 186 And FieldID Is Null And FieldIDInPage = '_txtTLR_OTHER_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (186,NULL,'Teller','_txtTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstGL
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 281 And FieldID Is Null And FieldIDInPage = '_txtTLR_OTHER_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (281,NULL,'Teller','_txtTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstAccount
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 185 And FieldIDInPage = '_lblTLR_RIm_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (185,NULL,'Teller','_lblTLR_RIm_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstCash
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 183 And FieldIDInPage = '_lblTLR_RIm_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (183,NULL,'Teller','_lblTLR_RIm_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstCheque
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 186 And FieldIDInPage = '_lblTLR_RIm_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (186,NULL,'Teller','_lblTLR_RIm_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
--IssueCOAgainstGL
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 281 And FieldIDInPage = '_lblTLR_RIm_PURPOSE')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (281,NULL,'Teller','_lblTLR_RIm_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
-------------------
-- RulesTranField -
-------------------  TLR_CHEQUE_BOOK_TYPE
--IssueCOAgainstAccount
If Not Exists(select * From RulesTranField Where TranID = 185 And FieldID = 270 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (185,270,1)
End
go
--IssueCOAgainstCash
If Not Exists(select * From RulesTranField Where TranID = 183 And FieldID = 270 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (183,270,1)
End
go

--IssueCOAgainstCheque
If Not Exists(select * From RulesTranField Where TranID = 186 And FieldID = 270 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (186,270,1)
End
go

--IssueCOAgainstGL
If Not Exists(select * From RulesTranField Where TranID = 281 And FieldID = 270 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (281,270,1)
End
go
--==============================================================================
--Devolper	:	Ahmed Atef
--Date		:	[09/01/2022]
--Reason	:	Enh GFSY00893 - ACM000000020069 - AJF - Passport Expiration Date Retrofit
--==============================================================================

--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106109 and Name = 'TLR_PASS_EXP_DT_VALID')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106109	,'TLR_PASS_EXP_DT_VALID',1,'Labels','Expiration Date is less than or equal system date','ITSOFT\ahmed.atef','2021-12-30 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000',	'2021-12-30 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106109 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106109 , 1025, N'تاريخ الصلاحية أقل من أو يساوي تاريخ اليوم','ITSOFT\ahmed.atef','2021-12-30 03:27:00')
End
GO
-----------------------------------
-- RulesParam & RulesTranFldParam -
-----------------------------------

IF NOT EXISTS(Select * From RulesParam Where ParamName='ExpiredIDValidationAction')
BEGIN
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'ExpiredIDValidationAction','Validation Action For Expiration Date of ID1 Or ID2 will be a Stop or Warning','',0,1,0,'','Static','')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'EditPersonalRim' AND FieldName = 'ExpiredIDValidationAction' AND Param = 'ExpiredIDValidationAction' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'EditPersonalRim' , 'ExpiredIDValidationAction' , 'ExpiredIDValidationAction' , 'Stop' ,'ITSOFT\ahmed.atef' , 'nvarchar')
END
GO
--==================================================================================
 -- Developer : Mostafa Helmy 
 -- Date :      12-01-2022
 -- Purpose :   Retrofit-Fix issue# GFSX14792 - Retrieve PaymentType column as NULL
--===================================================================================

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetLNAcctInfoWithCustInfo') AND FieldName='PaymentType')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetLNAcctInfoWithCustInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PaymentType','nvarchar',0,0,N'0','O')
END
GO
/*
Developer: Mostafa Helmy
Issue : Retrofit - BDL-GFSX14806
Date:13-01-2022
*/


IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1106022)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1106022,N'TLR_Descriptionn',1,N'Labels',N'Description')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106022 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106022,1025,N'الوصف')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106022 AND LCID=1036)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106022,1036,N'description')
END
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_Descriptionn')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (534,'TLR_Descriptionn')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 544 And DSC_Name = 'TLR_Descriptionn')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (544,'TLR_Descriptionn')
End
go
--Devolper	 :	Aya Tarek 
--Date       :	[29/12/2021]		
--Reason     :	CR#GFSY00886 [AUB_PurposeCode]
------------------------------------------------------------------------------------------------
--RulesParam-----------
--------------------------------
If Not Exists(Select * From RulesParam Where ParamName='EmptyFields')
Begin
    DECLARE @paramID1 int
    SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
    Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
    Values (@paramID1,'EmptyFields','Validation when changed field (57) For PurposeCode  to know the fields will be empty or not','',0,1,0,'','Static','')
End
GO

If Not Exists(Select * From RulesParam Where ParamName='DefineEmptyFields')
Begin
    DECLARE @paramID1 int
    SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
    Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
    Values (@paramID1,'DefineEmptyFields','Validation when changed field (57) For PurposeCode  to know the fields will be empty or not','',0,1,0,'','Static','')
End
GO
--------------------------------
------------------------------------------------------------------------------------------------
--------------------------RulesDescriptor & RulesDesceiptorLocal--------------------------------
------------------------------------------------------------------------------------------------
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1106110 and Name = 'TLR_SEARCH_Purpose_Code' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106110,'TLR_SEARCH_Purpose_Code',0,'Labels','Search Purpose Code','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106110 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1106110,1025,N'بحث رمز الغرض','Mar 10 2021 10:19AM')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1105890 and Name = 'TLR_Purpose_Desc' )
Begin
Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
Values (1,1105890,'TLR_Purpose_Desc',0,'Labels','Purpose Description','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan 1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105890 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
Values (1105890,1025,N'وصف الغرض ','Mar 10 2021 10:19AM')
End
GO
--------------------------------------------------------------------------------------------------
-------------------------------------RulesErrorDescription && RulesLocalErrorDescription ---------
---------------------------------------------------------------------------------------------------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1824)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID)
 Values (1824,'PurposeCode_Mandatory_Select','"Purpose Code" Should Be Selected from Its Pick List','"Purpose Code" Should Be Selected from Its Pick List',4,'ErrDesc.hlp',1)
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1824 And LanguageLCID = 1025)
BEGIN
 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
 Values (1824,1025,N'يجب تحديد "كود الغرض" من قائمة الاختيار الخاصة به',N'يجب تحديد "كود الغرض" من قائمة الاختيار الخاصة به')
END
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstAccount' AND  Error_Name   = 'PurposeCode_Mandatory_Select'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueTTAgainstAccount'  ,  'PurposeCode_Mandatory_Select'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstCash' AND  Error_Name   = 'PurposeCode_Mandatory_Select'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueTTAgainstCash'  ,  'PurposeCode_Mandatory_Select'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstCheque' AND  Error_Name   = 'PurposeCode_Mandatory_Select'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueTTAgainstCheque'  ,  'PurposeCode_Mandatory_Select'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstGL' AND  Error_Name   = 'PurposeCode_Mandatory_Select'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueTTAgainstGL'  ,  'PurposeCode_Mandatory_Select'   )
END 
GO
--------------------------RulesTranDescriptors-----------------------------------------------
---------------------------------------------------------------------------------------------
--PurposeCode
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_Purpose_Code'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_Purpose_Code' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_Purpose_Code'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278  ,'TLR_Purpose_Code' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_Purpose_Code'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_Purpose_Code' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_Purpose_Code'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_Purpose_Code' ,'ITSOFT\aya.tarek'  ) 
END
Go
--PurposeDesc
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_Purpose_Desc'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_Purpose_Desc' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_Purpose_Desc'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278  ,'TLR_Purpose_Desc' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_Purpose_Desc'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_Purpose_Desc' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_Purpose_Desc'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_Purpose_Desc' ,'ITSOFT\aya.tarek'  ) 
END
Go
--77B
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_77B_REGULATORY_REPORTING'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_77B_REGULATORY_REPORTING' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_77B_REGULATORY_REPORTING'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278  ,'TLR_77B_REGULATORY_REPORTING' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_77B_REGULATORY_REPORTING'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_77B_REGULATORY_REPORTING' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_77B_REGULATORY_REPORTING'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_77B_REGULATORY_REPORTING' ,'ITSOFT\aya.tarek'  ) 
END
Go
--searchPurposeode
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_SEARCH_Purpose_Code'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_SEARCH_Purpose_Code' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_SEARCH_Purpose_Code'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278  ,'TLR_SEARCH_Purpose_Code' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_SEARCH_Purpose_Code'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_SEARCH_Purpose_Code' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_SEARCH_Purpose_Code'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_SEARCH_Purpose_Code' ,'ITSOFT\aya.tarek'  ) 
END
Go
--search Result
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_SEARCH_RESULTS'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_SEARCH_RESULTS' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_SEARCH_RESULTS'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278  ,'TLR_SEARCH_RESULTS' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_SEARCH_RESULTS'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_SEARCH_RESULTS' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_SEARCH_RESULTS'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_SEARCH_RESULTS' ,'ITSOFT\aya.tarek'  ) 
END
Go
--search Btn
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_SEARCH'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_SEARCH' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_SEARCH'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278  ,'TLR_SEARCH' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_SEARCH'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_SEARCH' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_SEARCH'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_SEARCH' ,'ITSOFT\aya.tarek'  ) 
END
Go
--select btn
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_SELECT'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_SELECT' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_SELECT'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278  ,'TLR_SELECT' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_SELECT'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_SELECT' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_SELECT'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_SELECT' ,'ITSOFT\aya.tarek'  ) 
END
Go
--Cancel butt
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_SO_CANCEL'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_SO_CANCEL' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_SO_CANCEL'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278  ,'TLR_SO_CANCEL' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_SO_CANCEL'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_SO_CANCEL' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_SO_CANCEL'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_SO_CANCEL' ,'ITSOFT\aya.tarek'  ) 
END
Go
--
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_INVALID_PURPOSE_CODE'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_INVALID_PURPOSE_CODE' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_INVALID_PURPOSE_CODE'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278  ,'TLR_INVALID_PURPOSE_CODE' ,'ITSOFT\aya.tarek'  ) 
END
Go

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_INVALID_PURPOSE_CODE'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_INVALID_PURPOSE_CODE' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_INVALID_PURPOSE_CODE'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_INVALID_PURPOSE_CODE' ,'ITSOFT\aya.tarek'  ) 
END
Go
-----------------------------RulesTranField-----------
--------------------------------------------------------------
--TLR_CRSPNDNT_COUNTRY_CODE REGULATORY_LINE_1_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 277  AND  FieldID   =  579  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 277   ,   579   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_1_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_DEST_BANK_NAME REGULATORY_LINE_2_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 277  AND  FieldID   =  607  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 277   ,   607   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_2_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_LOCAL_BANK_NAME REGULATORY_LINE_3_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 277  AND  FieldID   =  462  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 277   ,   462   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_3_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
--
--TLR_CRSPNDNT_COUNTRY_CODE REGULATORY_LINE_1_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 278  AND  FieldID   =  579  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 278   ,   579   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_1_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_DEST_BANK_NAME REGULATORY_LINE_2_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 278  AND  FieldID   =  607  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 278   ,   607   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_2_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_LOCAL_BANK_NAME REGULATORY_LINE_3_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 278  AND  FieldID   =  462  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 278  ,   462   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_3_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
--
--TLR_CRSPNDNT_COUNTRY_CODE REGULATORY_LINE_1_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 279  AND  FieldID   =  579  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 279  ,   579   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_1_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_DEST_BANK_NAME REGULATORY_LINE_2_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 279  AND  FieldID   =  607  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 279   ,   607   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_2_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_LOCAL_BANK_NAME REGULATORY_LINE_3_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 279  AND  FieldID   =  462  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 279  ,   462   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_3_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
--
--TLR_CRSPNDNT_COUNTRY_CODE REGULATORY_LINE_1_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 296  AND  FieldID   =  579  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 296  ,   579   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_1_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_DEST_BANK_NAME REGULATORY_LINE_2_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 296  AND  FieldID   =  607  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 296  ,   607   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_2_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--TLR_LOCAL_BANK_NAME REGULATORY_LINE_3_77B(77b)
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 296  AND  FieldID   =  462  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 296   ,   462   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    'REGULATORY_LINE_3_77B'    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
-----------------------------RulesTranField_ex-----------
--------------------------------------------------------------
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_lblTLR_77B_REGULATORY_REPORTING')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 277 , NULL , 'Teller' , '_lblTLR_77B_REGULATORY_REPORTING' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_1')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 277 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_1' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 277 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO



IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_3')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 277 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_3' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_btnPurposeCode')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 277 , NULL , 'Teller' , '_btnPurposeCode' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO
--
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_lblTLR_77B_REGULATORY_REPORTING')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 278 , NULL , 'Teller' , '_lblTLR_77B_REGULATORY_REPORTING' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_1')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 278 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_1' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 278 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_3')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 278 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_3' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_btnPurposeCode')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 278 , NULL , 'Teller' , '_btnPurposeCode' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO
--
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_lblTLR_77B_REGULATORY_REPORTING')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 279 , NULL , 'Teller' , '_lblTLR_77B_REGULATORY_REPORTING' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_1')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 279 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_1' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 279 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_3')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 279 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_3' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_btnPurposeCode')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 279 , NULL , 'Teller' , '_btnPurposeCode' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO
--
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_lblTLR_77B_REGULATORY_REPORTING')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 296 , NULL , 'Teller' , '_lblTLR_77B_REGULATORY_REPORTING' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_1')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 296 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_1' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 296 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_txtTLR_77B_REGULATORY_LINE_3')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 296 , NULL , 'Teller' , '_txtTLR_77B_REGULATORY_LINE_3' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_btnPurposeCode')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 296 , NULL , 'Teller' , '_btnPurposeCode' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO
--------------------------------
--RulesTranFldParam-----------
--------------------------------
-- EmptyFields 
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'IssueTTAgainstAccount' AND FieldName ='AccountWithInstitution' AND Param = 'EmptyFields' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'IssueTTAgainstAccount' , 'AccountWithInstitution' , 'EmptyFields' , 0 ,'ITSOFT\aya.tarek' , 'int')
 END 
GO
--DefineEmptyFields
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where TranName   = 'IssueTTAgainstAccount' AND FieldName ='AccountWithInstitution' AND Param = 'DefineEmptyFields' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'IssueTTAgainstAccount' , 'AccountWithInstitution' , 'DefineEmptyFields' , '' ,'ITSOFT\aya.tarek' , 'nvarchar')
 END 
GO

-- EmptyFields 
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'IssueTTAgainstCash' AND FieldName ='AccountWithInstitution' AND Param = 'EmptyFields' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'IssueTTAgainstCash' , 'AccountWithInstitution' , 'EmptyFields' , 0 ,'ITSOFT\aya.tarek' , 'int')
 END 
GO
--DefineEmptyFields
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where TranName   = 'IssueTTAgainstCash' AND FieldName ='AccountWithInstitution' AND Param = 'DefineEmptyFields' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'IssueTTAgainstCash' , 'AccountWithInstitution' , 'DefineEmptyFields' , '' ,'ITSOFT\aya.tarek' , 'nvarchar')
 END 
GO

-- EmptyFields 
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'IssueTTAgainstCheque' AND FieldName ='AccountWithInstitution' AND Param = 'EmptyFields' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'IssueTTAgainstCheque' , 'AccountWithInstitution' , 'EmptyFields' , 0 ,'ITSOFT\aya.tarek' , 'int')
 END 
GO
--DefineEmptyFields
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where TranName   = 'IssueTTAgainstCheque' AND FieldName ='AccountWithInstitution' AND Param = 'DefineEmptyFields' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'IssueTTAgainstCheque' , 'AccountWithInstitution' , 'DefineEmptyFields' , '' ,'ITSOFT\aya.tarek' , 'nvarchar')
 END 
GO

-- EmptyFields 
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'IssueTTAgainstGL' AND FieldName ='AccountWithInstitution' AND Param = 'EmptyFields' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'IssueTTAgainstGL' , 'AccountWithInstitution' , 'EmptyFields' , 0 ,'ITSOFT\aya.tarek' , 'int')
 END 
GO
--DefineEmptyFields
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where TranName   = 'IssueTTAgainstGL' AND FieldName ='AccountWithInstitution' AND Param = 'DefineEmptyFields' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'IssueTTAgainstGL' , 'AccountWithInstitution' , 'DefineEmptyFields' , '' ,'ITSOFT\aya.tarek' , 'nvarchar')
 END 
GO
--------------------------------------------------SQLstrings----------------------------------------------------------------------
IF Not Exists(select * from SQLstrings where AccessID = 1100177)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile , Developer , Updator , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100177 , 'SEARCH_PURPOSECODE' , 'p' , 1, 'Globalfs' , 'dbo.Search_PurposeCode' , 0 , '' , '' , 'ITSOFT\aya.tarek' , 'ITSOFT\aya.tarek' , 'Retrieves the PurposeCode,PurposeDesc,SwiftFields From TT_PurposeCode Table according to isocode' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO
