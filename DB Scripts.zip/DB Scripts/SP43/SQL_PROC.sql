Go
drop_old_proc 'dbo.GetErrorCodeDetails'
Go
CREATE PROC dbo.GetErrorCodeDetails  
@ErrorCode   [nvarchar](50)
As  
			/*   
			CreationDate: 09/03/2022 
			OriginalName: dbo.GetErrorCodeDetails   
			Programmer: Shaimaa Nasser      
			Description: Get Error details by code   
			*/  

Begin
IF(@ErrorCode = Null)
	BEGIN
	  SELECT ErrorCode , Description, Reversal_Type FROM EFTS_ResponseCode 
	END 
ELSE
	BEGIN 
	  SELECT ErrorCode , Description, Reversal_Type FROM EFTS_ResponseCode 
	   WHERE ErrorCode = @ErrorCode
	END
END
GO
PRINT 'Start. Script for CR# GFSY00901 DML Script GetErrorSetupEnabled'
Go
drop_old_proc 'dbo.GetErrorSetupEnabled'
Go
CREATE PROC dbo.GetErrorSetupEnabled  
@TranName nvarchar(50)
As  
			/*   
			CreationDate: 09/03/2022 
			OriginalName: dbo.GetErrorCodeDetails   
			Programmer: Shaimaa Nasser      
			Description: Get Error details by code   
			*/  

Begin
declare @res   varchar(100) 

SELECT @res = Value FROM RulesTranFldParam WHERE  TranName = @TranName And Param = 'Enable_ErrorCode_Setup'
IF(@res = Null)
	BEGIN
	  return 0;
	END 
ELSE IF(@res = 'y')
	BEGIN 
	 return 1;
	END
ELSE
	BEGIN
	return 0;
	END
END
GO

PRINT 'END. Script for CR# GFSY00901 Proc Script GetErrorSetupEnabled'
-- =============================================
-- Author:		Aya Tarek
-- Create date:8/4/2022
-- Description:	Retrieves prefix from table BranchConfig
-- =============================================
go
drop_old_proc 'Select_Prefix_For_BranchBank' -- Select_Prefix_For_BranchBank 1, 1,1  
GO
Create Proc Select_Prefix_For_BranchBank
		 @Bank BankID,              
         @Region int ,
		 @Branch int              
As
-- =============================================
-- Author:		Aya Tarek
-- Create date:29/12/20201
-- Description:	Retrieves prefix from table BranchConfig
-- =============================================
Begin
set nocount on
     
 select  Bc.Prefix    
 from  dbo.Branches as B     
 Inner join dbo.BranchConfig BC  
 on B.Bank = BC.Bank   
 AND B.Region = BC.Region  
 AND B.Branch = BC.Branch              
 where B.Bank=@Bank and B.Branch=@Branch  and B.Region=@Region order by Name asc      

End
GO


--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc setTranFieldCurrCategory
Go

create Procedure dbo.setTranFieldCurrCategory
    @TranName   [varchar](60),
	--@TranName	TransactionName,
	@FieldName	field__Name,
	@CategoryID	int,
	@Updator	OperatorID
As
/*
	Creation Date	: 30 Aug 2004
	Original Name	: dbo.setTranFieldCurrCategory
	Programmer	: Mohammed Mustafa Al-Ogail
	Description	: Update a Transaction's Field Currency-Category
	Output		: 
	Assumption	: 
	  
	ModifiedDate:  7-5-2008
	Modifer:  hany nasr
	ModifyReason:  performance tunning

	Modified: mohgaber
	Modified Date: 12-10-2008
	Modification Reasoan: Add the updator parameter cause the System should send the current globalfs user as an updator parameter.

    Modified: Osama Orabi
	Modified Date: 2008-8-11
	Modification Reasoan: Add  the condition of "and fp.fieldname = @FieldName", to not update all the currency category of the transaction
                          Solving issue# 43943 

	Modified: shaimaa abdelnasser 
	Modified Date: 08-06-2022
	Modification Reasoan: Solve Issue # GFSX15082 to give transaction name param larger length.

*/
	set nocount on

	declare @name	varchar(255)
	if not exists 
	(
		SELECT	*
		FROM	dbo.RulesTranFldParam fp 
		INNER 	join dbo.CurrencyCategory cat
		ON	fp.param = 'CurrencyCategoryID'-- and
		INNER	join dbo.RulesDescriptor rd
		ON	rd.Descriptor = @TranName
		inner	join dbo.RulesTranName rtn
		on	rtn.DSC_Description = rd.DescriptorID
		where	fp.Value = cat.[id]		and
			fp.TranName = rtn.TransactionName and--@TranName
			fp.FieldName = @FieldName
	)
	Begin
		select	@name = rtn.TransactionName
		from	dbo.RulesDescriptor rd 
		inner	join 
			dbo.RulesTranName rtn
		on	rtn.DSC_Description = rd.DescriptorID
		and	rd.Descriptor = @TranName

		INSERT INTO dbo.RulesTranFldParam
			(	TranName, 
				FieldName, 
				Param, 
				Value,
				Updator
			)
		VALUES	(
				@name,
				@FieldName,
				'CurrencyCategoryID',
				@CategoryID,
				@Updator
			)
	End
	Else
	Begin
		Update	fp
 		SET	fp.value = @CategoryID
		FROM	RulesTranFldParam fp 
		INNER 	join CurrencyCategory cat
		ON	fp.param = 'CurrencyCategoryID'-- and
		INNER	join RulesDescriptor rd
		ON	rd.Descriptor = @TranName
		inner	join RulesTranName rtn
		on	rtn.DSC_Description = rd.DescriptorID
		where	fp.Value = cat.[id]		and
			fp.TranName = rtn.TransactionName--@TranName
            and fp.fieldname = @FieldName
			
	End



Go
--End of Automatic Generation
Drop_Old_Proc '[Get_Journal_Summary_For_Printing]' 
GO  
Create PROC [dbo].[Get_Journal_Summary_For_Printing]      
 @criteria nvarchar(max) = '',
 @criteria2 nvarchar(max) = '',
 @start_date smalldate,     
 @end_date smalldate,   
 @order_time_ascending bit = 0,      
 @max_rows int = 9,  -- Zero means return only one row.      
 @page_back bit = 0,      
 @LCID int = NULL, -- May be used to get local tran Description.      
 @for_user internal_user_ID =0,      
 @debug int = 0 -- Set to Zero, 1 For Developing Issues   //Ahmed Atef [Fix issue# GFSX15117][13-06-2022]
AS      
-- Query the Teller journal summary view for records that match the criteria.      
-- For just the @max_rows that match the criteria, join in the description      
--  of the transaction as "Tran_Title".      
      
-- When @page_back is ON, you get the last n rows that match the criteria.      
      
-- This uses the select projection list developed by proc SetJnlSummaryColumns2.      
-- Copyright 2003, 2004, 2005, 2006, 2007, 2008 Getronics USA, INC. All rights reserved.      
-- Created 05Feb03 by Bodhi Densmore      
-- 07FEB03 Bodhi added start_date and end_date parameters to ensure quick retrieval.      
-- 02APR03 Bodhi - To improve performance, don'T use RulesDecriptorLOCAL table when it is not useful.      
-- 02JUL03 Bodhi - Join in isDupable and isCorrectable from RulesTranName, per request from Mike Chandler.      
-- 11JUL03 Bodhi - Normal order is ascending by operator and descending by time and jnlSequence.      
-- 10Mar04 Bodhi - Support having only user_number and not LoginID (Operator) in Journal.      
--                 Using a late-binding join to the Operator table for best performance.      
-- 22Apr04 Bodhi - Fix syntax bug in retrieving local descriptors for transaction name.      
-- 21May04 Bodhi - Support conversion of user_numbers to login IDS.      
-- 06JUL04 Bodhi - Join in isSuperDupable from RulesTranName, per CR9728.      
-- 31JAN04 Bodhi - Support additional fields like "Supervisor" as interual_user_ID. CR10172      
-- 27Jul05 Kevens - Support additional column names like bank, region and branch that are not exactly those names.      
-- 17Aug05 Bodhi - Support queries with only date criteria, - initial value of @criteria empty.      
-- 23SEP05 Bodhi - For better performance, calculate table name when only one month is used.      
--                 Replace f_OperatorID_of_user_number with opID_of_U#      
-- 31AUG06 Bodhi - Use nolock hint when number of @max_rows is small, indicating not-for-report.       
-- 15JAN07 Diana - Add extra condition to the 'where' clause for checking privileges in OperatorRoles. CR14966      
-- 22Apr07 Bodhi - Use "inside order" for ORDER BY after the final join.      
-- 22Apr07 B & D - Support SmallDate as integer.      
-- 22May07 Bodhi - Complain about start_date too early on DBMaster or if debugging.      
-- 16MAR08 DEEPAK D R - Collation cast added CR16728      
-- 08APR10 Bodhi - Forgive dates less than minimum when minimum is today (because Journal is empty).      
    
/*    
Modified by: Adel Shaban    
Date: 9/2/2011    
Reason: Fixing issue when table doesn't exist in database - issue#103687    
  
Modified by: Amira Kamel  
Date: 28/12/2013   
Reason: Selact Accounting Entries, host ref no , cheque no  
  
Modified by: Ibrahim Harby  
Date: 20/01/2021   
Reason: add @Sql2 , @where2 , @criteria2 for union sql2 with sql one   
 to get old behaviour data with new PostingFromSupervisor data   
*/    
    
SET NOCOUNT ON      
declare @sql nvarchar(max), @sql2 nvarchar(max), @param_defs nvarchar(1000)      
declare @summary_sql nvarchar(4000), @position int, @operator_columns nvarchar(500)      
declare @position_of_from int      
declare @date_string varchar(30), @date_string2 varchar(30)      
declare @normal_descending_order nvarchar(300)      
 , @normal_ascending_order nvarchar(300)      
 , @inside_order nvarchar(300)      
 , @outer_order nvarchar(300)      
declare @tran_def_columns nvarchar(200)      
declare @start_year_month smallint, @end_year_month smallint, @start_day tinyint, @end_day tinyint      
declare @table_name sysname, @suffix char(7)      
declare @where nvarchar(1000) , @where2 nvarchar(max)  
declare @AcctEntries_table sysname  
declare @AcctEntries_sql nvarchar(4000)    
-- Begin Ibrahim Harby  (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value  
declare @LikeParamFirstPart nvarchar(100)  
set @LikeParamFirstPart =   '''%n="PostingFromSupervisor_RequesterUserNumber" v="'  
declare @LikeParamLastPart nvarchar(100)  
set @LikeParamLastPart =  '"%'''  
-- End Ibrahim Harby (17-12-2020)   
-- ** CR14330 ** S      
declare @no_lock_hint nvarchar(14)      
if @max_rows < 22      
 set @no_lock_hint = N' WITH (NOLOCK)' -- Read uncommitted when not for a print report.      
else      
 set @no_lock_hint = ''      
-- ** CR14330 ** E      
set @start_year_month = dbo.YYMM_of_SmallDate(@Start_Date)      
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)      
set @start_day = DatePart(dd, dbo.datetime_of_smalldate(@start_date))      
set @end_day = DatePart(dd, dbo.datetime_of_smalldate(@end_date))      
if @start_year_month = @end_year_month BEGIN      
 set @suffix = dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@start_date))      
 set @table_name = 'ZJournal'+ @suffix     
  set @AcctEntries_table = 'ZJNL_AccingEnt'+ @suffix    
 -- Adel Shaban - Fixing issue when table doesn't exist in database    
 if(Not Exists( Select 1 from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @table_name))    
 BEGIN    
 select * FROM Journal WHERE 1 = 2 -- return dataset with correct schema and no rows    
 RETURN -1 -- exist from proc     
 END    
 -- End of Adel Shaban - Fixing issue when table doesn't exist in database  
 
Declare @Expression varchar(max) = null
Declare @individual varchar(max) = null
Declare @usernumber varchar(max) = NULL

SET @Expression = @criteria
SET @Expression = REPLACE(@Expression, 'and', ',')
SET @Expression = REPLACE(@Expression, ' ', '')

WHILE LEN(@Expression) > 0
BEGIN
    IF PATINDEX('%,%', @Expression) > 0
		BEGIN
		    SET @individual = SUBSTRING(@Expression, 0, PATINDEX('%,%', @Expression))

		    IF @individual LIKE 'user_number=%'
				BEGIN
					SET @usernumber = @individual
				END

		    SET @Expression = SUBSTRING(@Expression, LEN(@individual + ',') + 1, LEN(@Expression))
		END
    ELSE
		BEGIN
			SET @individual = @Expression
			SET @Expression = NULL
			
			IF @individual LIKE 'user_number=%'
				BEGIN
					SET @usernumber = @individual
				END
		END
END
SET @usernumber = REPLACE(@usernumber, 'user_number=', '')

 --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value  
  -- @where2 for union criteria   
 set @where2 = N'WHERE  J.TLR_DUMMY_FIELDS like '+ @LikeParamFirstPart +cast (@usernumber as nvarchar(10))  +@LikeParamLastPart  
   +' AND J.year_month = @start_ym' + char(10)     
 + ' AND J.BusinessDate_Day '      
 + case when @start_day = @end_day       
  then '= @start_day AND J.BusinessDate = @start_date'      
  else 'between @start_day and @end_day       
  and J.BusinessDate between @start_date and @end_date'      
  end      
  
   set @where = N'WHERE   J.year_month = @start_ym' + char(10)     
 + ' AND J.BusinessDate_Day '      
 + case when @start_day = @end_day       
  then '= @start_day AND J.BusinessDate = @start_date'      
  else 'between @start_day and @end_day       
  and J.BusinessDate between @start_date and @end_date'      
  end      
     -- End Ibrahim Harby (17-12-2020)   
  -------------*******---  
  
END       
ELSE BEGIN      
 set @table_name = 'Journal'     
 set @AcctEntries_table = 'JNL_AccingEnt'    
  --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value  
 set @where2 = N'WHERE J.year_month between @start_ym and @end_ym      
 and J.BusinessDate between @start_date and @end_date'    
  + ' and   J.TLR_DUMMY_FIELDS like '+  @LikeParamFirstPart +cast (@for_user as nvarchar(10))  +@LikeParamLastPart   
  
  set @where = N'WHERE J.year_month between @start_ym and @end_ym      
 and J.BusinessDate between @start_date and @end_date'    
   -- End Ibrahim Harby (17-12-2020)  
END      
      
if @for_user >0 and dbo.operator_has_wildcard_permissions(@for_user)<1      
 set @where =@where+' AND dbo.is_BranchAllowed(@for_user,J.Bank,J.Region,J.Branch)=1 '      
      
IF isNULL(@LCID,0) = 0       
--**CR16728 ** S      
 set @tran_def_columns = N'      
 , Tran_Title = T.Description collate SQL_Latin1_General_CP1_CI_AS, T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable '      
else      
 --**CR16728 ** E      
 set @tran_def_columns = N'      
 , Tran_Title = isNULL(isnull(RD.LocalDescription, D.Descriptor), T.Description collate SQL_Latin1_General_CP1_CI_AS), T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable '      
      
select @summary_sql =       
 substring(dbo.f_insert_new_lines(AccessString,72),7,3990)       
from dbo.SQLstrings       
where AccessName = 'JOURNAL_SUMMARY'      
    
select @AcctEntries_sql =  
 char(10)+N',(select   
x.Subscript,  
x.JNL_Acct_ENT_ACCOUNT,  
x.JNL_Acct_ENT_DB_CURR,  
x.JNL_Acct_ENT_DB_AMOUNT,  
x.JNL_Acct_ENT_CR_CURR,  
x.JNL_Acct_ENT_CR_AMOUNT  
'  
+ char(10)      
+ 'FROM dbo.'+@AcctEntries_table+N' x'     
+'  
where J.BusinessDate = x.BusinessDate  
and J.user_Number= x.user_Number  
and J.Bank = x.Bank   
and J.Region = x.Region   
and J.Branch = x.Branch   
and J.JNLSequence = x.JNLSequence   
for xml path(''AccountEntries'')  
) as AccountEntries  
'      
set @position = charindex(', dbo.opID_of_U#', @summary_sql, 100)      
if @position = 0 begin      
  raiserror('Get_Journal_Summary can not find ", dbo.opID_of_U#" in JOURNAL_SUMMARY SQLstrings.AccessString', 16, 1)      
  return -1      
end      
set @position_of_from = charindex(' FROM ', @summary_sql, @position) - (@position + 2)      
set @operator_columns = substring(@summary_sql, @position+2, @position_of_from)      
set @operator_columns = replace(@operator_columns, '(user_number', '(JS.user_number')      
set @position = @position -1      
if @debug > 0 or @@servername like '%DBMASTER%'begin      
 declare @min_date smalldate      
 if db_name() like '%archive'      
  set @min_date = dbo.smalldate_of(dbo.f_Teller_Base_date())      
 else      
  set @min_date = dbo.f_min_journal_business_date(dbo.smalldate_of(getdate()))      
       
 if @start_date < @min_date begin      
  if @min_date < dbo.smalldate_of(getdate()) begin      
   set @date_string = isNULL(cast (@start_date as varchar), '-NULL-')      
   set @date_string2 = convert(varchar(10), @min_date)      
   raiserror('Get_Journal_Summary @start_date,"%s" must be > "%s"'      
    , 16, 1, @date_string, @date_string2)      
   return -1      
  end      
 end      
 if @start_date > @end_date or @end_date is null begin      
  set @date_string = isNULL(cast(@end_date as varchar), '-NULL-')      
  set @date_string2 = cast(@start_date as varchar)       
      
  raiserror('Get_Journal_Summary @end_date, "%s" must be >= @startdate = "%s"'      
   , 16, 1, @date_string, @date_string2)      
  return -1      
 end      
end      
set @criteria = dbo.TRIM(@criteria)  -- TRIM off left and right spaces.      
if @criteria <> '' and substring(@criteria,1,8) not like '%where %' begin      
 if left(@criteria, 4) = 'AND '       
  set @criteria = @where + ' ' + @criteria      
 else begin      
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)      
  return -1      
 end      
end     
       
if @criteria = ''      
 set @criteria = @where      
else begin      
 if @criteria like '%[^a-z_0-9.]Bank %'       
  set @criteria = replace (@criteria, 'bank ', 'J.Bank ')      
      
 if @criteria like '%[^a-z_0-9.]user_number %'       set @criteria = replace (@criteria, 'user_number ', 'J.user_number')      
      
 if @criteria like '%[^a-z_0-9.]Region %'       
  set @criteria = replace (@criteria, 'region ', 'J.Region ')      
      
 if @criteria like '%[^a-z_0-9.]Branch %'       
  set @criteria = replace (@criteria, 'branch ', 'J.Branch ')      
      
 if substring(@criteria,1,8) not like '%where %' begin      
  if left(@criteria, 4) = 'AND '       
   set @criteria = @where + ' ' + @criteria      
  else begin      
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)      
   return -1      
  end      
 end else       
  set @criteria = @where +REPLACE(@criteria,'where', ' AND')      
end       
--*****************  
--***************  for union criteria  
set @criteria2 = dbo.TRIM(@criteria2)  -- TRIM off left and right spaces.      
if @criteria2 <> '' and substring(@criteria2,1,8) not like '%where %' begin      
 if left(@criteria2, 4) = 'AND '       
  set @criteria2 = @where2 + ' ' + @criteria2      
 else begin      
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)      
  return -1      
 end      
end     
       
if @criteria2 = ''      
 set @criteria2 = @where2      
else begin      
 if @criteria2 like '%[^a-z_0-9.]Bank %'       
  set @criteria2 = replace (@criteria2, 'bank ', 'J.Bank ')      
      
 if @criteria2 like '%[^a-z_0-9.]user_number %'       set @criteria2 = replace (@criteria2, 'user_number ', 'J.user_number')      
      
 if @criteria2 like '%[^a-z_0-9.]Region %'       
  set @criteria2 = replace (@criteria2, 'region ', 'J.Region ')      
      
 if @criteria2 like '%[^a-z_0-9.]Branch %'       
  set @criteria2 = replace (@criteria2, 'branch ', 'J.Branch ')      
      
 if substring(@criteria2,1,8) not like '%where %' begin      
  if left(@criteria2, 4) = 'AND '       
   set @criteria2 = @where2 + ' ' + @criteria2      
  else begin      
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)      
   return -1      
  end      
 end else       
  set @criteria2 = @where2 +REPLACE(@criteria2,'where', ' AND') 
end   
---***************************  
--------------------------------      
if @max_rows < 0 begin      
 raiserror('Get_Journal_Summary @max_rows "%d", must be at least 0', 16, 1, @max_rows)      
 return -1      
end      
      
set @normal_descending_order = N'      
 order by Bank,Region,Branch,user_number,TransactionTime desc, JNLSequence desc'      
set @normal_ascending_order = N'      
 order by Bank,Region,Branch,user_number,TransactionTime,JNLSequence'      
set @inside_order = case       
when @order_time_ascending = 0 and @page_back = 0 then @normal_descending_order      
when @order_time_ascending = 0 and @page_back = 1 then N'      
 order by Bank desc,Region desc,Branch desc, user_number desc,TransactionTime, JNLSequence'      
when @order_time_ascending = 1 and @page_back = 0 then @normal_ascending_order      
else N'      
 order by Bank desc,Region desc,Branch desc,user_number desc,TransactionTime desc, JNLSequence desc'      
end      
      
select @sql = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)       
+ substring(@summary_sql,1, @position)  
+ @AcctEntries_sql        
+ char(10)      
-- ** CR14330 ** S      
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint      
-- ** CR14330 ** E      
+ char(10) + @criteria + @inside_order      
      
--*****************  
--***************  for union   
 select @sql2 = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)       
+ substring(@summary_sql,1, @position)  
+ @AcctEntries_sql        
+ char(10)      
-- ** CR14330 ** S      
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint      
-- ** CR14330 ** E      
+ char(10) + @criteria2 + @inside_order      
--*****************  
if @page_back = 1 begin      
 set @outer_order = case @order_time_ascending      
          when 0 then @normal_descending_order      
   else @normal_ascending_order      
   end      
      
 set @sql = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql+N') BOTTOM' + @outer_order      
  
--***************  for union   
set @sql2 = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql2+N') BOTTOM' + @outer_order      
--*****************  
end      
IF isNULL(@LCID,0) = 0   
begin  
 --Begin Ibrahim Harby (20-01-2021)  
set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns   ++ N' FROM (' + @sql +   
                     '    union all '  
                     + @sql2 + ' ) AS JS    JOIN dbo.RulesTranName T     on T.TransactionName = JS.TranName'    
 end  
ELSE       
 set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns      
+ N'      
FROM (' + @sql + '   
union all  
  '+ @sql2 + ' ) AS JS      
JOIN dbo.RulesTranName T      
  on T.TransactionName = JS.TranName      
LEFT OUTER JOIN dbo.RulesDescriptor D      
  on D.DescriptorID = T.DSC_Description      
LEFT OUTER JOIN dbo.RulesDescriptorLocal RD      
  on RD.DescriptorID = D.DescriptorID and LCID = @LCID'      
-- ** CR15838 ** S      
+ char(10) + @inside_order      
-- ** CR15838 ** E      
   --End Ibrahim Harby (20-01-2021)      
set @param_defs = N'@LCID int, @start_date smalldate, @end_date smalldate, @start_ym smallint, @end_ym smallint, @start_day tinyint, @end_day tinyint, @for_user internal_user_ID'      
if @debug > 0 begin      
 print '-------cut here ---------'       
 print 'declare ' + @param_defs + char(10)       
 print 'select @LCID = ' + isnull(cast(@LCID as varchar), 'NULL')      
 print '    , @start_date = '''+cast(@start_date as varchar) + ''''      
 print '    , @end_date = '''+cast(@end_date as varchar) + ''''      
 print '    , @start_ym = '+cast(@start_year_month as varchar)      
 print '    , @end_ym = '+cast(@end_year_month as varchar)      
 print '    , @start_day = '+cast(@start_day as varchar)      
 print '    , @end_day = '+cast(@end_day as varchar)      
 print ' ,@for_user='+cast(@for_user as varchar)      
 /*print '    , @user_number = ' + case @user_number when NULL then ' NULL ' else cast(@user_number as varchar) end*/      
 print @sql      
 if @debug > 3 return -1      
end      
exec dbo.sp_executesql @sql, @param_defs, @LCID, @start_date, @end_date      
 , @start_year_month, @end_year_month, @start_day, @end_day, @for_user     
GO