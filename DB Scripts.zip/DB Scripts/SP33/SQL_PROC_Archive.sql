------------------------------------------------------------------------------------------
-----  Developer     : Mohamed Elabd -----------------------------------------------------
-----  Creation Date : 26-September-2018  ------------------------------------------------
-----  Purpose       : KFH_ACM16030_Re-Print Old Voucher - CR# GFSY00720 -----------------
------------------------------------------------------------------------------------------
USE Globalfs_Archive
GO
set nocount on
go

if db_name() not like 'G%archive'
   raiserror('Not in correct database!  Killing the SPID now.'
            ,22,127) with log
GO

------------------------------------------------------------------------------------------
drop_old_proc aJnlDetail
GO
CREATE PROC aJnlDetail
@Bank BankID,
@Region RegionID,
@Branch BranchID,
@user_number internal_user_ID,
@BusinessDate SmallDate, 
@JnlSequence integer = 1,
@TranName TransactionName = '',
@debug int = 0
as
-- Retrieve from Journal the columns values relevant to a particular transaction.
-- Returns date column values in canonical form.
-- Selects empty record set when transaction specified does not exist.
-- Most useful for journal scan operations.
-- Returns 0 on success,
--         -1 when TranID can not be determined,
--         @@error on other errors.
-- Copyright 1999, 2000, 2001, 2002, 2003, 2004, 2005 GetronicsWang Co., LLC.  All rights reserved.
-- This is the archive version.
-- 10OCT05 Bodhi - Version 1 for archive.
SET NOCOUNT ON 
declare @SQL nvarchar(4000), @param_list nvarchar(1000)
declare @errno int, @proc_name sysname
declare @date SmallDate, @date_look varchar(100)
	, @year_month smallint, @day tinyint

SET @date = @BusinessDate -- Truncate hours and minutes.
set @year_month = dbo.YYMM_of_SmallDate(@date)
set @day = DatePart(dd, dbo.datetime_of_smalldate(@date))
if @TranName is null 
	set @TranName = ''
if (@TranName = '') 
	select @TranName = J.TranName
	from dbo.Archive_JOURNAL J 
	where J.Bank = @Bank and J.Region = @Region and J.Branch = @Branch
	  and J.JNLSequence = @JNLSequence
	  and J.user_number = @user_number
	  and J.year_month = @year_month and J.BusinessDate_Day = @day
	  
if @debug > 0 begin
	if (@TranName is null) print '-- TranName cannot be determined'
        else print '-- TranName is ' +@TranName
end
if @TranName = '' begin
   select * from dbo.Archive_JOURNAL where Bank is null -- return an empty set
   return -1
end
set @proc_name = 'Get_'+@TranName +'_Detail'

set @sql = N'exec dbo.'+ @proc_name + N' @bank, @branch, @BusinessDate_Day
, @JnlSequence, @region
, @user_number, @Year_Month'
set @param_list = N'@bank BankID
, @branch BranchID
, @BusinessDate_Day tinyint
, @JnlSequence int
, @region RegionID
, @user_number internal_user_ID
, @Year_Month smallint'

if @debug <> 0 begin
	print '-- Len(@sql) = ' + cast(len(@sql) as varchar)
	print 'declare ' + @param_list
	print 'select @bank = ' + cast (@bank as varchar)
	print ' , @region = ' + cast (@region as varchar)
	print ' , @branch = ' + cast (@branch as varchar)
	print ' , @user_number = ' + cast (@user_number as varchar)
	print ' , @jnlsequence = ' + cast (@jnlsequence as varchar)
	print ' , @BusinessDate_day = ' +  cast(@day as varchar)
	print ' , @year_month = ' + cast (@year_month as varchar)
	print isnull(@sql, 'NULL @sql')
end
exec dbo.sp_executesql @sql, @param_list
,@bank, @branch, @day, @JnlSequence, @region
, @user_number, @Year_Month

select @errno = @@error
if @errno <> 0 print @sql
return @errno
go
---------------------------	
if 'testing' is null
begin
	set nocount off
	declare @ret_code int
	declare @bnk bankID, @reg RegionID, @br BranchID, @u internal_user_id
	declare @seq int, @date SmallDate, @tran_name TransactionName
	select @date = min(BusinessDate) FROM dbo.Archive_Journal
	select @u = min(user_number) 
	FROM dbo.Archive_JOURNAL J 
	where J.BusinessDate = @date
	select @seq = JNLSequence, @bnk = J.Bank, @reg = J.Region, @br = J.Branch
	, @tran_name = J.TranName 
	FROM dbo.Archive_JOURNAL J 
	where J.user_number = @u and J.BusinessDate = @date 
	 and J.JNLSequence = 1

	select @tran_name TranName, @bnk as Bank, @reg as Region, @br as Branch
		, @u as user_number, @date as BusinessDate, @seq as JNLSequence
	exec @ret_code = dbo.aJnlDetail @bnk,@reg,@br,@u
	, @BusinessDate = @date, @JnlSequence = @seq, @TranName = @tran_name, @debug =1
	print 'return_code is '+cast(@ret_code as varchar)
--

	exec @ret_code = aJnlDetail @Bank=1,@Region =10,@Branch =100,
		@user_number=42,@BusinessDate ='2005-04-05', @JnlSequence = 2
end
GO
-------------------------------------------------------------------------------
drop_old_function opID_of_U#
go
create function opID_of_U#(@user_number internal_user_id)
returns varchar(12)
as
-- For archival purposes the user number need not be interpreted.
-- Copyright 2005 GetronicsWang Co., LLC.  All rights reserved.
-- This is the archive version.
-- 03Nov05 Bodhi - Version 1 for archive.
begin
	return cast(@user_number as varchar(12))
end
go
grant execute on opID_of_U# to public
go




------------------------------------------------------------------------------------------
--  Any customization of SQL files should be contained within one of the following files
--  associated with each application:  CustomProcedures.SQL, CustomViews.SQL,
--  CustomObjects.SQL or CustomPostProcessing.SQL.  The Core application contains an
--  additional file, CustomTypes.SQL
--  Any customization not implemented in this manner will be overlaid with standard code
--  when an upgrade is installed.
------------------------------------------------------------------------------------------

-- Copyright GetronicsWang Co., LLC 2005, 2006, 2007 . All rights reserved.
set nocount on
go

if db_name() not like 'G%archive'
   raiserror('Not in correct database!  Killing the SPID now.'
            ,22,127) with log
GO
--------------------------------------------------------------------------------
drop_old_proc aJNL_GenSelect
GO

CREATE PROCEDURE aJNL_GenSelect @tblname sysname,
@Bank BankID,
@Region RegionID,
@Branch BranchID,
@user_number internal_user_ID,
@Business_Date smalldate,
@JnlSequence integer
, @debug bit = 0
as
-- Retrieve from Analytical-Archive Journal or a related sub table, 
-- all rows and column values for one transaction.
-- Most useful for retrieval from sub-tables of the Journal.
-- Copyright 1999, 2000, 2002, 2004, 2005, 2007 GetronicsWang Co., LLC.  All rights reserved.
-- 10OCT05 Bodhi - Version 1 for Archive
-- 07MAY07 Diana - Support for Smalldate as int

SET NOCOUNT ON
declare @q nvarchar(750)
declare @ym_suffix char(7), @day tinyint
declare @year_month smallint
if charindex('J', @tblname) <> 1 or PATINDEX('%[^A-Z0-9_]%',@tblname) <> 0 begin -- Test to prevent some SQL injection.
	raiserror('Invalid table Name "%s" for aJNL_GenSelect', 16, 1, @tblName)
	return -16
end

set @ym_suffix = dbo.jnl_partition_suffix(dbo.datetime_of_smalldate(@business_date))
set @year_month = dbo.YYMM_of_SmallDate(@business_date)
set @day = day(dbo.datetime_of_smalldate(@business_date))

set @q = N'SET NOCOUNT ON
select * from dbo.Z' + @tblname + @ym_suffix+N' where year_month = @year_month
AND BusinessDate_day = @day 
AND user_number = @user_number
AND Bank = @bank and Region = @region
AND Branch = @Branch 
and JNLSequence = @sequence'
+ case when @tblname = 'JNL_HostResponse'
then N' AND Subscript = 0'
else ''
end
if @debug =1 begin
	print 'DECLARE @year_month smallint, @bank BankID, @region RegionID, @branch BranchID, @user_number internal_user_ID, @day tinyint, @sequence int'
	print 'set @year_month = '+cast(@year_month as varchar)
	print 'set @bank = '+cast(@bank as varchar)
	print 'set @region = '+cast(@region as varchar)
	print 'set @branch = '+cast(@branch as varchar)
	print 'set @user_number = '+cast(@user_number as varchar)
	print 'set @day = '+cast(@day as varchar)
	print 'set @sequence = '+cast(@JnlSequence as varchar)
	print @q
end
exec dbo.sp_executesql @q, 
N'@year_month smallint, @bank BankID, @region RegionID, @branch BranchID, @user_number internal_user_ID, @day tinyint, @sequence int',
@year_month, @bank, @region, @branch, @user_number, @day, @JnlSequence
go
if 'testing' is null BEGIN

	DECLARE @bk BankID, @reg RegionID, @br BranchID, @u internal_user_ID
	declare @d smalldate, @yesterday smalldate
	declare @sqltxt nvarchar(500)
	declare @dbName varchar(100), @ArchiveDBName varchar(100)
	--CHANGE THIS TO YOUR CURRENT Globalfs database name.
	set @dbName='Globalfs'

	set @yesterday = dbo.smalldate_of(getdate()) -1
	set @sqltxt = N'select @d1 = Min(BusinessDate)' +  
	' from ' +  @dbName + '.dbo.JNL_HostResponse where BusinessDate <= @STyesterday'
	print @sqltxt
	exec dbo.sp_executesql @sqltxt,
	N'@STyesterday smalldate, @d1 smalldate output',
	@STyesterday=@yesterday, @d1 = @d output

	set @sqltxt =N'select top 1 @bk1 = Bank, @reg1 = Region, @br1 = Branch, @u1 =user_number'+
	' from '+ @dbName +'.dbo.JNL_HostResponse where BusinessDate = @d1' +
	' order by Bank, Region, Branch, user_number'
	execute sp_executesql @sqltxt,
		N'@bk1 BankID output, @reg1 RegionID output, @br1 BranchID output, @u1 internal_user_ID output,@d1 smalldate',
		@bk1=@bk, @reg1 =@reg output, @br1 =@br output, @u1 = @u output,@d1 =@d
	if @@rowcount > 0 begin
		select @bk, @reg, @br, @u, @d
		--set statistics io on
		exec dbo.aJNL_GenSelect 'Jnl_HostResponse'
			, @bk, @reg, @br, @u, @d, 1,@debug = 1
		set statistics io oFF
	end
	else
		print 'no rows in JNL_HostResponse before today''s date'

	exec dbo.aJNL_GenSelect 'Jnl_Checks', 1, 10, 100, @JnlSequence =1,
					@Business_Date = @d,
					@user_number = @u, @debug = 1
END
go
--------------------------------------------------------------------------------



if db_name() not like 'G%archive'
   raiserror('Not in correct database!  Killing the SPID now.'
            ,22,127) with log
GO
--------------------------------------------------------------------------------
drop_old_proc Last_Journal_Archive_Date
go
create PROC Last_Journal_Archive_Date @debug int = 0
AS
-- RETURN the last business date in the Archive_Journal as an integer 20YYMMDD.
-- Return -2 when Journal has no rows.
-- Copyright 2006 GetronicsWang Co., LLC.  All rights reserved.
-- 09MAR06 by Bodhi Densmore - Version 1
-- 24APR07 Bodhi - Support smalldate as int.
SET NOCOUNT ON
DECLARE @businessdate smalldate
declare @int_date int
select @businessdate = MAX(BusinessDate) FROM dbo.Archive_JOURNAL
if @businessdate is null
	return -2
set @int_date = (100 * dbo.year_month_of_date(dbo.datetime_of_smalldate(@BusinessDate))) 
+ datepart(d, dbo.datetime_of_smalldate(@BusinessDate)) 
RETURN @int_date
go
if 'testing' is null begin
	declare @d int
	exec @d = dbo.Last_Journal_Archive_Date 
	print @d
end
go
--------------------------------------------------------------------------------
if db_name() not like  'G%archive' and db_name() not like 'Old%'
   raiserror('Error.  Not in correct database!  Killing the SPID now.'
            ,22,127) with log
GO

exec drop_old_function min_archive_business_date
go
create function min_archive_business_date()
RETURNS smalldate
AS
-- Returns earliest business date for any transaction in the Teller Journal Archive
-- Returns 99981231 when Archive_Journal is empty.
-- 10Oct07 Bodhi - version 1.
BEGIN	
	DECLARE @date smalldate
	SELECT @date = min(BusinessDate)
	FROM dbo.Archive_Journal
	RETURN isnull(@date, 99981231) 
END
go
if 'Testing' is null
	select dbo.min_archive_business_date()

GO
--------------------------------------------------------------------------------
drop_old_proc List_Business_Dates_in_Archive
go
CREATE PROC List_Business_Dates_in_Archive @bank BankID = 0,
  @region RegionID = 0
, @branch BranchID = 0
, @user_number internal_user_ID = 0
, @cashdrawer CashDrawerNumber = NULL
, @start_date SmallDate = null
, @end_date SmallDate = null
, @debug int = 0
as 
-- List business dates from Archive_Journal according to variable criteria.
-- Copyright 2005, 2006 GetronicsWang Co., LLC.  All rights reserved.
-- 04Nov05 Bodhi - Version 1
-- 24APR07 Bodhi - Support smalldate as int.
set nocount on
declare @sql nvarchar(2000)
declare @where nvarchar(1000)
declare @param_list nvarchar(300)
declare @start_year_month smallint, @end_year_month smallint
declare @table_name sysname

set @param_list = N'@bank bankID, @region regionID, @branch branchID
,@user_number internal_user_ID, @cashdrawer CashDrawerNumber
, @start_date smalldate, @end_date smalldate'

if @start_date is null 
	set @start_date = dbo.SmallDateAdd('d', -28, dbo.smalldate_of(CURRENT_TIMESTAMP))
if @end_date is null 
	set @end_date = dbo.SmallDateAdd('d', -1, dbo.smalldate_of(CURRENT_TIMESTAMP))
if @start_date > @end_date begin
	raiserror('List_Business_Dates_in_Archive start_date > end_date', 16, 1)
	return -1
end

set @start_year_month = dbo.YYMM_of_SmallDate(@start_date)
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)
if @start_year_month = @end_year_month
	set @table_name = 'Zjournal'+ dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@end_date))
else
	set @table_name = 'Archive_Journal'
set @sql = N'SET NOCOUNT ON 
select distinct BusinessDate from dbo.'+@table_name + N'
WHERE year_month ' +
case when @start_year_month = @end_year_month 
     THEN N'= '
     ELSE N'BETWEEN ' + cast(@start_year_month as varchar) + N' AND '
end
+ cast (@end_year_month as varchar) + N'
  and BusinessDate >= @start_date and BusinessDate <= @end_date '

if @cashdrawer is null set @cashdrawer = ''
-- '' gives zero if CashDrawerNumber type is numeric.

set @where = dbo.generic_criteria(@bank, @region, @branch, @user_number, '')
if @where > '' 
	set @where = char(10)+ 'AND '+@where
if @cashdrawer <> ''
	set @where = @where + char(10) + N' and CashDrawer = @cashdrawer'
set @sql = @sql + @where + N'
ORDER BY 1'

if @debug > 0 begin 
	print '-----------------------------------'
	print 'declare ' + @param_list + char(10) 
	print 'select  @bank = ' + cast(@bank as varchar)
	print '    , @region = ' + cast(@region as varchar)
	print '    , @branch = ' + cast(@branch as varchar)
	print '    , @user_number = ' + cast(@user_number as varchar)
	print '    , @cashdrawer = ''' + cast(@cashdrawer as varchar) + ''''
	print '    , @start_date = ''' + cast(@start_date as varchar)+ ''''
	print '    , @end_date = ''' + cast(@end_date as varchar) + ''''
	print @sql 
end
set nocount OFF
exec dbo.sp_executesql @sql, @param_list,
	@bank, @region, @branch, @user_number , @cashdrawer , @start_date, @end_date

return @@error
go

if 'testing' is  null begin
	declare @op OperatorID, @d smalldate, @u internal_user_ID, @bk bankID, @r regionID
	select @d = dbo.smalldate_of(max(BusinessDate)) 
	from Archive_Journal
	select @u = max(user_number) from Archive_Journal 
	where BusinessDate = dbo.datetime_of_smalldate(@d)
	select @bk = Bank, @r = Region
		from Archive_Journal where user_number = @u and BusinessDate = @d
	select @d as end_date, @u as user_number
	exec dbo.List_Business_Dates_in_Archive @bank=@bk, @region=@r
		, @user_number = @u
	, @cashdrawer=100, @start_date ='19900101', @end_date=@d, @debug =1
	exec dbo.List_Business_Dates_in_Archive @bank=1, @region=10, @branch=100
		, @user_number = @u
	, @cashdrawer=100, @start_date ='20070101', @end_date=@d, @debug =1
	exec dbo.List_Business_Dates_in_Archive 
	@start_date ='20070101', @end_date= @d, @debug =1
	exec dbo.List_Business_Dates_in_Archive 
	@start_date =@d, @end_date= @d, @debug =1
end
go


-------------------------------------------------------------------------------------
drop_old_proc List_Archive_Transaction_Names
go
CREATE PROCEDURE List_Archive_Transaction_Names @bank BankID = 0,
  @region RegionID = 0
, @branch BranchID = 0
, @user_number internal_user_id = 0
, @cashdrawer CashDrawerNumber = NULL
, @start_date SmallDate = null
, @end_date SmallDate = null
, @LCID LanguageLCID = 1033
, @debug int = 0
as 
-- Get transaction names from Archive_Journal according to variable criteria.
-- Copyright 005, 2006 GetronicsWang Co., LLC.  All rights reserved.
-- See Also: List_Journal_Transaction_Names
-- 04Nov05 Bodhi - Version 1
set nocount on
declare @operational_instance sysname, @operational_db sysname, @op_schema sysname
declare @need_locale bit
declare @start_year_month smallint, @end_year_month smallint
declare @sql nvarchar(3000), @column_list nvarchar(500)
declare @where nvarchar(1000)
declare @table_name sysname, @suffix char(7), @months int
declare @param_list nvarchar(300)
set @param_list = N'@bank bankID, @region regionID, @branch branchID
, @cashdrawer CashDrawerNumber
, @start_date smalldate, @end_date smalldate, @LCID int, @user_number internal_user_ID'

if @start_date is null begin
	set @start_date = dbo.SmallDateAdd('dd', -28, dbo.smalldate_of(CURRENT_TIMESTAMP))
	set @months = 0
end else
	set @months = dbo.SmallDateDiff('m', @start_date, dbo.smalldate_of(CURRENT_TIMESTAMP))
	
if @end_date is null 
	set @end_date = dbo.SmallDateAdd('dd', -1, dbo.smalldate_of(CURRENT_TIMESTAMP))
else
	if @end_date > dbo.smalldate_of(CURRENT_TIMESTAMP) begin
		raiserror('List_Archive_Transaction_Names @end_date must be less than today,', 16, 1)
		return -1
	end
if @start_date > @end_date begin
	raiserror('List_Archive_Transaction_Names start_date > end_date', 16, 1)
	return -1
end
set @start_year_month = dbo.YYMM_of_SmallDate(@start_date)
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)
if @start_year_month = @end_year_month BEGIN
	set @table_name = 'Zjournal'+ dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@end_date))
	set @where = N'WHERE year_month = ' + cast(@start_year_month as varchar)
END
else BEGIN
	set @table_name = 'Archive_Journal'
	set @where = N'WHERE year_month between ' + cast(@start_year_month as varchar) 
					+ N' AND '+ cast(@end_year_month as varchar)
END
set @where = @where + char(10) 
	+ N' and BusinessDate between @start_date and  @end_date'
if @cashdrawer is null set @cashdrawer = ''
	-- '' gives zero if CashDrawerNumber Type is numeric.
if @bank is null
	set @bank = 0
if @Region is null 
	set @region = 0
if @Branch is null 
	set @branch = 0
if (@bank > 0)
	set @where = @where + N' and Bank = @bank'
if @region > 0
 	set @where = @where + N' and Region = @region'
if @branch > 0
	set @where = @where + N' and Branch = @branch'
if @cashdrawer <> ''
	set @where = @where + N' and CashDrawer = @cashdrawer'

if @user_number is null or @user_number = 0
	set @user_number = 0
else 
	set @where = @where + N' and user_number = @user_number'

set @operational_db = db_name()
set @operational_db = left(@operational_db, len(@operational_db) - len('_Archive'))
select @operational_instance = value 
	from dbo.RulesEnvironmentArchive where value_name = 'OperationalDBInstance'
if @operational_instance is null set @operational_instance = 'missing_in_RulesEnvironmentArchive'
set @op_schema = dbo.f_QuoteName(@operational_instance) 
	+ '.'+dbo.f_QuoteName(@operational_db)+'.dbo.'
SET @need_locale = 1
SET @column_list 
	= N'select J.TranName, isNULL(RDL.LocalDescription,RD.Descriptor) Descriptor, T.DSC_Description '

SET @sql = N'SET NOCOUNT ON'+char(10)+@column_list + N'
from  (SELECT DISTINCT TranName from dbo.'+@table_name +N' WITH (NOLOCK)
 '+@where +N') as J
LEFT JOIN '+@op_schema+'RulesTranName T on T.TransactionName = J.TranName
LEFT JOIN '+@op_schema+'RulesDescriptor RD
 on T.DSC_Description = RD.DescriptorID'
 + case  @need_locale when 1 then N'
LEFT JOIN '+@op_schema+'RulesDescriptorLocal RDL
 on T.DSC_Description = RDL.DescriptorID and RDL.LCID = @LCID
'
	else '' 
	end
+ N'
ORDER BY 2'

if @debug > 0 begin 
	print 'declare ' + @param_list + char(10) 
	print 'select  @bank = ' + cast(@bank as varchar)
	print '    , @region = ' + cast(@region as varchar)
	print '    , @branch = ' + cast(@branch as varchar)
	print '    , @user_number = ' + cast(@user_number as varchar)
	print '    , @cashdrawer = ''' + cast(@cashdrawer as varchar) + ''''
	print '    , @start_date = ''' + cast(@start_date as varchar)+ ''''
	print '    , @end_date = ''' + cast(@end_date as varchar) + ''''
	print @sql 
end
set nocount OFF
exec dbo.sp_executesql @sql, @param_list,
	@bank, @region, @branch, @cashdrawer , @start_date, @end_date, @LCID, @user_number

return @@error
GO
if 'testing' is null begin
	declare @op OperatorID, @d smalldate, @u internal_user_ID
	declare @bk bankID, @rg regionID, @br branchID, @drawer CashDrawerNumber
	select @d = max(BusinessDate) from Archive_Journal
	select @u = min(user_number)
	from dbo.Archive_JOURNAL where BusinessDate = @d
	select top 1 @bk = bank, @rg =Region, @br = branch, @drawer = CashDrawer 
	from dbo.Archive_JOURNAL 
	where user_number = @u
	and BusinessDate = dbo.datetime_of_smalldate(@d)
	order by Bank, Region, Branch
	select @d as BusinessDate, @u as U#, @bk as Bank, @rg as Region, @br as Branch, @Drawer as Drawer
	exec dbo.List_Archive_Transaction_Names @bank= @bk, @region= @rg, @branch= @br
	, @user_number = @u
	, @cashdrawer= @drawer, @start_date ='20060101', @end_date= @d, @debug=1
	exec dbo.List_Archive_Transaction_Names 
	@start_date ='20060101', @end_date= @d, @lcid=1025,@debug=1
	exec dbo.List_Archive_Transaction_Names 
	@start_date ='20060801', @end_date='20060829', @lcid=1025,@debug=1
	exec dbo.List_Archive_Transaction_Names 
	@start_date ='20060601', @end_date='20060903', @lcid=1025,@debug=1
end
go
-------------------------------------------------------------------------------------
drop_old_proc Last_Archive_Date_of_Teller
go
create PROC Last_Archive_Date_of_Teller @user_number internal_user_ID
	, @debug int = 0
AS
-- RETURN the last business date for the user in the Archive_Journal as an integer 20YYMMDD.
-- Return -2 when Journal has no rows for the parameter user.
-- Copyright 2006 GetronicsWang Co., LLC.  All rights reserved.
-- 09MAR06 by Bodhi Densmore - Version 1
-- 24APR07 Bodhi - Support smalldate as int.
SET NOCOUNT ON
DECLARE @businessdate smalldate
declare @int_date int
select @businessdate = MAX(BusinessDate) FROM dbo.Archive_JOURNAL
where user_number = @user_number
if @businessdate is null
	return -2
set @int_date = (100 * dbo.year_month_of_date(dbo.datetime_of_smalldate(@BusinessDate))) 
+ datepart(d, dbo.datetime_of_smalldate(@BusinessDate)) 
RETURN @int_date
go
if 'testing' is null begin
	declare @d int, @u# internal_user_ID
	select @u# = min(user_number) from dbo.Archive_Journal
	exec @d = dbo.Last_Archive_Date_of_Teller @u#
	print @d
end
go
