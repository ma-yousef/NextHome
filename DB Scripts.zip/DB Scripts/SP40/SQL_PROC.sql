drop_old_proc '[dbo].[GetAccingEntFlagForTeller]'
GO
CREATE PROCEDURE [dbo].[GetAccingEntFlagForTeller]        
@TranName Nvarchar(max),
@userNumber int
AS    
              
/*     
name:  GetAccingEntFlagForTeller    
developer:  Ahmed Osman      
reason:  Get Accounts Entries Flag from teller config  
data:  21/6/2018  
*/    

declare @TranID int , @AccountingEntries bit
    
select @TranID = TranID from RulesTranName where TransactionName = @TranName

SELECT @AccountingEntries = AccountingEntries FROM RulesTranConfig WHERE TranID = @TranID 

IF @AccountingEntries=1 
BEGIN
	SELECT AccountingEntries FROM TellerConfig WHERE User_ID = @userNumber  
END
ELSE
BEGIN
	SELECT @AccountingEntries
END
GO
--Devolper	 :	Ahmed Osman
--Date       :	[08/07/2019]		
--Reason     :	CR#GFSY00765 - KFH_ACM17509_Override Upon Customer Age
--====================================================================
PRINT 'Start. Script for CR# GFSY00765 Proc Script -- GetOverrideAndTranValidationOperands'
GO

drop_old_proc 'GetOverrideAndTranValidationOperands'
GO
create  Proc dbo.GetOverrideAndTranValidationOperands -- GetOverrideAndTranValidationOperands 'CashDeposit' 
@TranName		nvarchar(max)
as                
/*
 CreationDate	:	[08/07/2019]       
 Programmer		:	Ahmed Osman
 Description	:	Select All Override Condition Operands and all Transaction Validation Operands that related to specify transaction - CR#GFSY00765
*/   

Declare @OverrideConditions table(ConditionID int, OverrideID int, OverrideIDType int, Seq int, OperandDataTypeID int, OperandDataType nvarchar(max), Operand1 nvarchar(max),
ConditionalOperandId int, ConditionalOperator nvarchar(max), Operand2 nvarchar(max), LogicalOperator nvarchar(max), LastChanged datetime, Updator nvarchar(max))

DECLARE @TranID int , @TranOverrideRequestID int, @RulesTranValidationId int

SELECT @TranID = TranID FROM RulesTranName WHERE TransactionName = @TranName

SELECT @TranOverrideRequestID = TranOverrideRequestID FROM TranOverrideRequest WHERE TranId = @TranID

SELECT @RulesTranValidationId = Id FROM RulesTranValidations WHERE TranId = @TranID

insert into @OverrideConditions EXEC dbo.Select_Override_Conditions @TranOverrideRequestID,0,1

SELECT Operand1,Operand2 FROM @OverrideConditions 
	WHERE Operand1 LIKE 'CUSCR_%' OR Operand1 LIKE 'CUSDR_%'OR Operand1 LIKE 'ACCTCR_%' OR Operand1 LIKE 'ACCTDR_%'
		OR Operand2 LIKE 'CUSCR_%' OR Operand2 LIKE 'CUSDR_%'OR Operand2 LIKE 'ACCTCR_%' OR Operand2 LIKE 'ACCTDR_%'
UNION
SELECT Operand1,Operand2 FROM ValidationsConditions 
	WHERE RulesTranValidationId = @RulesTranValidationId
		AND	Operand1 LIKE 'CUSCR_%' OR Operand1 LIKE 'CUSDR_%'OR Operand1 LIKE 'ACCTCR_%' OR Operand1 LIKE 'ACCTDR_%'
		OR Operand2 LIKE 'CUSCR_%' OR Operand2 LIKE 'CUSDR_%'OR Operand2 LIKE 'ACCTCR_%' OR Operand2 LIKE 'ACCTDR_%'

GO

PRINT 'End... Script for CR# GFSY00765 Proc Script -- GetOverrideAndTranValidationOperands'
GO
drop_old_proc 'Select_RulesTranConfigOne'
Go
create  PROCEDURE [dbo].[Select_RulesTranConfigOne] --exec  Select_RulesTranConfigOne 'CashDeposit'                      
 @TranName varchar(30),  
 @OnlyShowInAdmin smallint = 1                          
                            
As                                
/*                                
 CreationDate: 18 June 2008                              
 OriginalName: dbo.Select_RulesTranConfigOne                                
 Programmer: Mohamed Zaatar                               
 Description: Select Transaction Configuration from RulesTranConfig For One Tran                          
 Assumption:                               
                          
 Modified by : Mohamed Gad                          
 Modification Date : 10-8-2008                          
 Reason : Adding DaysAllowedForRevesral to the result set                            
                          
                          
modifier : Mariam moneeb                           
date : 22-12-2008                            
reason : Remove pre & post sending flags from rulestrancong                          
                        
modifier : Ahmed Hashem                         
date : 14-09-2009                            
reason : Adding cashfollowacctcurr to the result set                        
                          
ModifiedDate: 20-April-2010                        
Modifer: Ahmed Helmi                        
ModifyReason: Add UseFX column to the result.                        
                      
ModifiedDate: 26-April-2010                        
Modifer: Aya Mahmoud                      
ModifyReason: select the CheckDrawerTypeRestrictions from RulesTranConfig                      
                      
Modifying Date: Sept-11-2011                      
Modifer: Mahmod Anis                      
ModifyReason: Selecting the flag (Use_XPath_app) indicating wether CR#7304 should be used or not - from RulesTranConfig                      
               
Modifying Date: 2011-10-09              
Modifer: Mostafa Elbarbary              
ModifyReason: change the order of Use_XPath_app to be the last retrieved column              
                       
Modifying Date: 11-10-2011                      
Modifer: Lamiaa Mostafa                    
ModifyReason: Adding Channel_Id to the result                   
                
Modifying Date: 12-10-2011                      
Modifer: Doaa Nassar                   
ModifyReason: CR# 7438, Adding PrimaryIDExpiryVal and PrimaryIDExpiryAction to the result                  
              
Modifying Date: 19-10-2011                      
Modifer: Hatim Al Sum                    
ModifyReason: CR# 7862, Adding Blacklisted, BlacklistedAction to the result                                  
          
Modifying Date: 22-12-2011                      
Modifer: Lamiaa Mostafa                    
ModifyReason: Adding Pack_ID to the result             
        
Modifying Date: 13/2/2012        
Modifer: Adel Shaban                    
ModifyReason: Adding DaysAllowedForRecovery to the result ==>> Rolled back on 16/2/2012            
    
Modifier: Mohammed Farouk    
Date : 2012-05-28    
Reason  : Retrive ReviewVouchersBeforePrinting   
  
Modifier: Amr Salah El-din    
Date : 2012-07-17    
Reason  : Retrive OpenSessionRequired Column added for CR#9626 KIB   

Modifier: Mohammed El-Masry    
Date : 2012-10-07    
Reason  : Replace LimitCategory with LimitType

Modifier: Mohammed Farouk    
Date : 2013-05-15
Reason  : Retrive ExchangeTypeId, defect GFSX03787

Modifier: Amr Salah El-din    
Date : 2013-08-27
Reason  : Retrive  rtc.UpdDateReqired, rtc.UpdDateValue, rtc.UpdDateAction, rtn.TranCategory --Enhancement #GFSY00273 

Modifier: Mohamed Sobhy
Date : 2013-12-19
Reason  : Retrive  rtc.CHK_IncludeAccumilative, rtc.CHK_AccumilativeInfoMessage

Modifier: Mohammed Farouk   
Date : 2014-01-09  
Reason  : Retrive SupportResend, CBD CR GFSY00321

Modifer: May Hassan 
Date: 2015-01-18  
ModifyReason: Add column PastDueDtAction, CheckBillPastDueDt  

Modifer: May Hassan   
Date: 2015-01-11    
ModifyReason: Add column UseExpressions  

Modifier : Nada Elshafie    
Date  : 2017-03-06
Reason  : Retrieve WorkOnNightlyModeAllowed for CBD - CRQ0000000013504 (retrofit KFH-CRQ000000001959)    

Modifier : Nada Elshafie    
Date  : 2017-07-09
Reason  : Retrieve StaffsRelativeValidation for BIsB  - CRQ13394

Modifier : Mostafa Sayed  
Date  : 2019-02-12
Reason  : CR#GFSY00749 - Retrieve UseTCR column

Modifier : Mostafa Helmy    
Date  : 2020-11-03       
Reason  : Retrieve KYCExpiryVal,KYCExpiryValAction for GFSY00800 - KFH - ACM000000018096 KYC Rim Field-Retrofit
*/                
                          
set nocount on                                
                                
 SELECT distinct rtc.TranID,                                
   rd.Descriptor,                      
   rtc.DenomRequired,                      
   rtc.AccountingEntries,                                
   rtc.DrAccountCategoryID,                                
   ac.name,                                
   rtc.CrAccountCategoryID,                                
   ac2.name,  
                                 
   --rtc.LimitCategoryID,                                
   rtc.TranLimitID,
   --lc.category,                                
   lt.LimitTypeName ,
   
   rtc.FeesCategoryID,                                
   fc.name as FeesCategory,                              
   rtc.ExchangeType,                                
   et.ExchangeName,                                
   rtc.OffLineAmount,                       
   rtc.VerifySignatrue,                                
   rtc.PrintOption,                                
   rtn.TransactionName,             
   rtc.EnableCharges,                                
   rtc.Blacklisted,                                
   rtc.BlacklistedAction,                                
   rtc.BenPmtStrict,                                
   rtc.BenPmtWarning,                                
   rtc.ShowAvlBal,                  
   GLc.id ,                                
   GLc.Name,                                
                                
   rtc.AllowEmptyAccountingEntries ,                                
   rtc.ReadAllAccountingEntries ,                          
   rtc.SalesMessageActive ,                                
   rtc.ValidateStaleCheque ,          
   rtc.StaleChequeDefaultDate ,                                
   rtc.EscWarningEnabled ,                                
   rtc.ChqRngVal ,                                
   rtc.HasCheckList ,                      
   rtc.AutoPrintPassBook ,                                
   --rtc.PreSendPrinting ,                                
  -- rtc.PostSendPrinting ,                                
   rtc.UseSimpleChargeControl ,                                
   rtc.ForcePositioning ,                                
   rtc.OD_DrAccountCategoryID ,                      
   ac3.Name ,                                
   rtc.CheckListCategoryID ,                                
   chklst.CategoryName ,                                
   rtc.StaleChequeAction ,                                
   rtc.ChqRngAction ,                                
   rtc.FutureStaleChequeDays ,                                
   rtc.BackDatedStaleChequeDays  ,                              
   rtc.TranCommissionGroupID    ,                          
   rtc.DaysAllowedForReversal ,                        
   rtc.cashfollowacctcurr ,                        
   rtc.UseFX  ,                      
   rtc.CheckDrawerTypeRestrictions ,                    
   rtc.use_XPath_app,                  
   rtc.Channel_Id,                
   rtc.PrimaryIDExpiryVal,                
   rtc.PrimaryIDExpiryAction,              
   --CR7862 : start              
   rtc.Blacklisted,              
   rtc.BlacklistedAction,              
   --CR7862 : finish              
   rtc.Pack_ID RimRestrictionID,    
   rtc.ReviewVouchersBeforePrinting,  
   rtc.OpenSessionRequired,
   et.ExchangeID,
   --Amr Salah El-din, 27/8/2013, Apply Enhancement #GFSY00273, Start
   rtc.UpdDateReqired,
   rtc.UpdDateValue,
   rtc.UpdDateAction,
   rtn.TranCategory ,
   --Amr Salah El-din, 27/8/2013, Apply Enhancement #GFSY00273, End
   rtc.CHK_IncludeAccumilative,
   rtc.CHK_AccumilativeInfoMessage,
   rtc.SupportResend,  --CBD CR GFSY00321   
   rtc.CheckBillPastDueDT,
   rtc.PastDueDTAction,
   rtc.UseExpressions,
   rtc.WorkOnNightlyModeAllowed,
   rtc.staffsRelativeValidation,
   rtc.UseTCR,
   rtc.KYCExpiryVal,
   rtc.KYCExpiryValAction               
                                
 FROM   dbo.RulesTranName as rtn                                
 inner join dbo.RulesTranConfig as rtc                                
 on   rtn.TranID=rtc.TranID                                
 INNER JOIN dbo.RulesDescriptor rd                                
 on  rtn.DSC_Description = rd.DescriptorID                                
 left join       dbo.GlCategory as GLc                 
 on              GLc.id=rtc.GLCategoryID                                
 left   outer join dbo.AccountCategory as ac                                
 on  ac.id=rtc.DrAccountCategoryID                                
 left   outer join dbo.AccountCategory as ac2                                
 on  ac2.id=rtc.CrAccountCategoryID                                
                                
 left   outer join dbo.AccountCategory as ac3                                
 on  ac3.id=rtc.OD_DrAccountCategoryID                                
 left   outer join dbo.CheckListCategory as chklst                                
 on  chklst.id=rtc.CheckListCategoryID                                
                                
 --left  outer join dbo.LimitCategory as lc                                
 --on  lc.id=rtc.LimitCategoryID 
  left outer join dbo.LimitsType as lt
  on lt.LimitTypeID = rtc.TranLimitID
                                 
 left  outer join dbo.FeeCategory as fc                                
 on  fc.id=rtc.FeesCategoryID                              
 left  outer join dbo.ExchangeType_2 as et                                
 on  et.ExchangeType=rtc.ExchangeType                                
 where rtc.TranID = ( select Tranid from dbo.Rulestranname where Transactionname = @TranName )                            
and                                  
   ((rtc.ShowInAdmin =  @OnlyShowInAdmin) or @OnlyShowInAdmin = -1)                               
 order by                                 
   rd.Descriptor       
go

drop_old_proc 'select_PrintTranFields'
Go
create procedure [dbo].[select_PrintTranFields]   
@TranName TransactionName,  
@GridName varchar(100)  
as  
  
/*  
  
Creator : Abdelrhman Mohamed  
Date: 14-01-2021   retorfit 3-1-2021
Reason: Print journal Grid in printing transaction   
*/  
  
set nocount on  
  
SELECT  *  
FROM  
 PrintTranDocsGridsFields  
WHERE   
 TranName = @TranName  
 AND GridName = @GridName  
   
GO
drop_old_proc 'select_PrintTranFields'
Go
create procedure [dbo].[select_PrintTranFields]   
@TranName TransactionName,  
@GridName varchar(100)  
as  
  
/*  
  
Creator : Abdelrhman Mohamed  
Date: 14-01-2021   retorfit 3-1-2021
Reason: Print journal Grid in printing transaction   
*/  
  
set nocount on  
  
SELECT  *  
FROM  
 PrintTranDocsGridsFields  
WHERE   
 TranName = @TranName  
 AND GridName = @GridName  
   GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/03/2021]		
--Reason	:	Issue GFSX14469
--=============================

PRINT 'Start. Script for Issue GFSX14469 Proc Script - dbo.MarkIRMessagesAsUsed'
GO

drop_old_proc 'MarkIRMessagesAsUsed'
GO
create proc dbo.MarkIRMessagesAsUsed			--MarkIRMessagesAsUsed '001IR00004221',0
@MessagesRefNo varchar(max),
@Mark bit
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/03/2021]		
	Reason		:	Issue GFSX14469
	Description	:	Mark the IR messages as used by teller or not based on sent flag @Mark
*/          

IF EXISTS (SELECT * FROM IR WHERE IR.MsgRefNo = @MessagesRefNo)
	BEGIN
		UPDATE IR SET MarkedAsUsed = @Mark WHERE IR.MsgRefNo = @MessagesRefNo
	END
GO

PRINT 'End... Script for Issue GFSX14469 Proc Script - dbo.MarkIRMessagesAsUsed'
GO
drop_old_proc 'dbo.GetPhoenixLanguageCode'
go
CREATE PROCEDURE dbo.GetPhoenixLanguageCode
(
	@LCID int
)
AS
	/*
	Developer	: Ahmed Atef
	Date		: [31/03/2021]
	Reason		: CR#GFSY00762 - KFH_ACM17057_KYC_Retrofit
    */
    select PhoenixLanguageID from RulesLanguages where LanguageLCID=@LCID
GO
drop_old_proc 'Select_SIC_Codes'
go
create  procedure dbo.Select_SIC_Codes  
@Rim_Type char(11),  
@Parent_sic_code int = NULL,
@LCID int = -1
   
/*        
 CreationDate: 17 Nov 2014  
 OriginalName: dbo.Select_SIC_Codes        
 Programmer: Islam Hussein Aly  
 Description: return all SIC Code        
 Assumption:    
     
 CreationDate: 08 Aug 2016  
 OriginalName: dbo.Select_SIC_Codes        
 Programmer: Rokaia Kadry
 Description: return all SIC Code        
 Retrofit CR:GFSY00579  
 
 CreationDate: 24 March 2021  
         
 Programmer:  Mostafa Helmy  
 Description: return all SIC Code  with siccode +'-' +Description translation     
 Retrofit CR:GFSY00762            
*/        
  
as    
IF(@Parent_sic_code is NULL) -- retrieve all parents Sic Codes   
BEGIN  
 SELECT 
 CASE
    WHEN rl.LocalDescription is not null THEN convert(varchar ,sic_code)+'- '+ rl.LocalDescription 
    ELSE convert(varchar ,sic_code)+'- '+r.Descriptor 
   END AS DisplayedSIC,*
 FROM ad_gb_sic  a
 inner join   RulesDescriptor r
 on  a.DescriptorName COLLATE DATABASE_DEFAULT = r.Name COLLATE DATABASE_DEFAULT
 left join   RulesDescriptorLocal rl
 on r.DescriptorID=rl.DescriptorID and rl.LCID=@LCID
 where status ='Active' AND parent_sic_code IS NULL AND Rim_Type IS NOT NULL AND (Rim_Type = 'Both' OR Rim_Type = @Rim_Type)  
END  
ELSE IF (@Parent_sic_code = -1) -- retrieve all Sic Codes  
BEGIN  
 SELECT 
 CASE
    WHEN rl.LocalDescription is not null THEN convert(varchar ,sic_code)+'- '+ rl.LocalDescription 
    ELSE convert(varchar ,sic_code)+'- '+r.Descriptor 
   END AS DisplayedSIC,
 *
 FROM ad_gb_sic  a
 inner join   RulesDescriptor r
 on  a.DescriptorName COLLATE DATABASE_DEFAULT = r.Name COLLATE DATABASE_DEFAULT
 left join   RulesDescriptorLocal rl
 on r.DescriptorID=rl.DescriptorID and rl.LCID=1025
 where a.status ='Active'  AND Rim_Type IS NOT NULL AND (Rim_Type = 'Both' OR Rim_Type = @Rim_Type)  
END   
ELSE -- retrieve Childs Sic Codes  
BEGIN  
 SELECT 
 CASE
    WHEN rl.LocalDescription is not null THEN convert(varchar ,sic_code)+'- '+ rl.LocalDescription 
    ELSE convert(varchar ,sic_code)+'- '+r.Descriptor 
   END AS DisplayedSIC,
 *
 FROM ad_gb_sic  a
 inner join   RulesDescriptor r
 on  a.DescriptorName COLLATE DATABASE_DEFAULT = r.Name COLLATE DATABASE_DEFAULT
 left join   RulesDescriptorLocal rl
 on r.DescriptorID=rl.DescriptorID and rl.LCID=1025
 where a.status ='Active'  AND parent_sic_code = @Parent_sic_code AND Rim_Type IS NOT NULL AND (Rim_Type = 'Both' OR Rim_Type = @Rim_Type)  
END   


go
drop_old_proc 'selSentCashRefNo'
go
CREATE PROCEDURE dbo.selSentCashRefNo		--exec dbo.selSentCashRefNo 1,4,'17',0,11 
     @CurBranch    BranchID, -- Current Branch ID                      
     @ToID        int,  -- 1 Branch(3)     or User(1)                     
     @ToCode    varchar(20), -- 269 CurrentBranchID  or UserNumber                      
     @CB        bit = 0,   --0         
     @CashDrawerNumber  CashDrawerNumber  = null -- cd number    
AS     
/* Version : 2.00.0046.2103 , Date : 2016/09/06 */                 
/*                      
 Creation Date     : 21 Oct 2004                      
 Original Name     : dbo.selSentCashRefNo                      
 Programmer     : Mohammed Mustafa                       
 Description     : gets RefNo of all sent transaction to @CurrentBranch                      
 Output      : All Reference Number of Sent Cash                      
 Assumption     : Run on main Branch Database                      
                 All Operators are stored in main Branch Database                      
                                   
 ModifiedDate : 15 Mar 2005                    
 Modifer      :    Mohammed Mustafa                       
 ModifyReason :    Added UserName Column                    
                    
 ModifiedDate : 14 May 2006                    
 Modifer      :    Mohammed Mustafa                       
 ModifyReason :    Added ToID = 0 (Central Bank) for Central Bank Receive                    
        Change made In Arbift for new transaction Central Cash Movement Receive                    
                
ModifiedDate : 14 January 2008                    
 Modifer      :    Hany A. Hassan                
 ModifyReason :    Added ToID = 9 (Lead Teller) For using New configurations                    
              
Modified date:05/05/2008            
Modifer: Mostafa Elbarbary            
Resaon:To impove Sp code performance                   
            
            
Modified date:19/05/2008            
Modifer: Hany A Hassan            
Resaon:To add cashdrawer number in selection criteria      
    
Modified date:29/05/2008            
Modifer: Hany A Hassan            
Resaon:To get leadteller's vault     
    
Modified date:2010-04-29    
Modifer   : Hassan E. Halim          
Resaon   : in teller to teller movement there will be restriction such that;     
    the sender drawer type = the reciever drawer type.    
    
Modified date: 2010-05-04    
Modifer   : Osama Orabi    
Resaon   : Performance Enhanement    
    
     
 ModifiedDate : 2011-06 - 22     
 Modifer   : Mohammed El-Masry     
 ModifyReason : Change Column LinkedServer from Branch.LinkedServer into BranchConfig.LinkedServer  
   
 ModifiedDate : 2013-04-02  
 Modifer   : Mohammed Farouk  
 ModifyReason : CBD CR  GFSY00210, Cash movement rejection  
   
 ModifiedDate : 2014-07-07  
 Modifer   : Amr Salah El-din  
 ModifyReason : Solve defect #GFSX07416, retirn ToFromCode column  
  
  
 ModifiedDate : 2014-08-03  
 Modifer   : Lamiaa Mostafa  
 ModifyReason : select MovementType to check rejected movements - GFSX07495  
 
 ModifiedDate 	: 2014-09-06  
 Modifer   		: Mahmoud Kamel
 ModifyReason 	: Issue#GFSX11029 - Performance Issue
 
 ModifiedDate 	: 19-December-2016  
 Modifer   		: Mohamed Elabd
 ModifyReason 	: Issue# GFSX11493 - Add where condition AssignedToTeller = @ToCode
 
 ModifiedDate 	: 06-06-2018  
 Modifer   		: Osama Nabil
 ModifyReason 	: Issue# GFSX13055 - 

  ModifiedDate 	: 19-04-2021  
 Modifer   		: Mostafa Sayed
 ModifyReason 	: Issue# GFSX14515 - INC000000306548 - Enhancing performance by adding clustered primary key for temp table.
 
*/                      
                    
set nocount on                    

--ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
create table #TempCashMovement
(
[RefNo] nvarchar(20) NOT NULL,
[LastID] [int] NOT NULL,
PRIMARY KEY CLUSTERED ([RefNo] ASC)
)

insert into #TempCashMovement
select cshMve2.RefNo, max(cshMve2.id)
from CashMovement (NOLOCK) cshMve2    
group by cshMve2.RefNo

--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue

if(@ToID = 0) -- CentralBank                      
begin                      
 select  cm1.RefNo,                      
    cm1.currency,                      
    cm1.amount,                      
    cm1.FromSeal,                      
    cm1.ToSeal,                      
    cm1.CashSealMsgrCode,                      
    cm1.User_Branch, -- Sender Branch                       
    cm1.User_Number,                    
    cm1.isVault,                      
    cm1.date_time,                      
    op.LoginID as UserName,  
 cm1.ToFromCode,    
 cm1.MovementType                    
    from  dbo.CashMovement as cm1                    
    INNER join dbo.Operator op                    
    on   op.user_number = cm1.User_number  
	--ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
	/*
    Where  cm1.id in( select max(cshMve2.id) as LastID     
       from dbo.CashMovement cshMve2    
       WHERE cshMve2.RefNo = cm1.RefNo    
       group by cshMve2.RefNo)
	*/
	Where  cm1.id in (select LastID     
       from #TempCashMovement (NOLOCK) cshMve2    
       WHERE cshMve2.RefNo = cm1.RefNo)    
	--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
    AND   cm1.Movementtype in( 1,10) -- send , rejected                     
    AND   cm1.ToFromID  = 0 -- CentralBank(0)                      
    AND   cm1.User_Branch  = @CurBranch -- Central Bank Receive From the Same Branch                    
end    
Else if(@ToID = 4) -- To Vault                      
begin
	
    select  cm1.RefNo,                      
    cm1.currency,                      
    cm1.amount,                      
    cm1.FromSeal,      
    cm1.ToSeal,                      
    cm1.CashSealMsgrCode,                      
    cm1.User_Branch, -- Sender Branch                       
    cm1.User_Number,                    
    cm1.isVault,                      
    cm1.date_time,                      
    op.LoginID as UserName ,            
    cm1.CashDrawerNumber,  
 cm1.ToFromCode,  
 cm1.MovementType                          
    from  dbo.CashMovement as cm1                    
    inner join  dbo.Operator op                    
    on   op.user_number = cm1.User_number            
    inner join  dbo.CashDrawer cd           
    ON   (cd.AssignedToTeller = cm1.User_Number     
    and   cm1.CashDrawerNumber =  cd.cashdrawerNumber     
    and   cd.Branch = cm1.User_Branch )           
    and   cd.AttachedToVault = @CashDrawerNumber            
    --ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
	/*
    Where  cm1.id in( select max(cshMve2.id) as LastID     
       from CashMovement cshMve2    
       WHERE cshMve2.RefNo = cm1.RefNo    
       group by cshMve2.RefNo)
	*/
	Where  cm1.id in (select LastID     
       from #TempCashMovement (NOLOCK) cshMve2    
       WHERE cshMve2.RefNo = cm1.RefNo)    
	--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
    and   cm1.Movementtype in( 1,10) -- send , rejected  
    and   cm1.ToFromID  = 4 -- Vault(4)                      
    and   cm1.User_Branch  = @CurBranch -- TELLER sent to his BRANCH VAULT            
end                      
else if(@ToID =  3) -- To Branch                    
Begin                    
    if(@CB = 0) -- From Branch / HO                    
    Begin                    
        select  cm1.RefNo,                      
		 cm1.currency,                      
		 cm1.amount,                      
		 cm1.FromSeal,                      
		 cm1.ToSeal,                      
		 cm1.CashSealMsgrCode,                 
		 cm1.User_Branch, -- Sender Branch                       
		 cm1.User_Number,                    
		 cm1.isVault,                      
		 cm1.date_time,                
		 op.LoginID as UserName,  
		 cm1.ToFromCode,  
		 cm1.MovementType                        
		from  dbo.CashMovement as cm1                    
		inner join  dbo.Operator op    
		on   op.user_number = cm1.User_number                    
		--ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
		/*
		Where  cm1.id in( select max(cshMve2.id) as LastID     
		   from CashMovement cshMve2    
		   WHERE cshMve2.RefNo = cm1.RefNo    
		   group by cshMve2.RefNo)
		*/
		Where  cm1.id in (select LastID     
		   from #TempCashMovement (NOLOCK) cshMve2    
		   WHERE cshMve2.RefNo = cm1.RefNo)    
		--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
        and   cm1.Movementtype in( 1,10) -- send , rejected  
        and   cm1.ToFromID    = @ToID -- Teller(1),Branch(3)                      
        and   cm1.ToFromCode  = @ToCode -- CurrentBranchID                      
        and   cm1.User_Branch =@CurBranch    
    end    
    else-- (@CB <> 0)From CentralBank                    
    Begin                    
        select  cm1.RefNo,                      
		 cm1.currency,                      
		 cm1.amount,                      
		 cm1.FromSeal,                      
		 cm1.ToSeal,                      
		 cm1.CashSealMsgrCode,                      
		 cm1.User_Branch, -- Sender Branch                       
		 cm1.User_Number,                    
		 cm1.isVault,                      
		 cm1.date_time,                     
		 op.LoginID as UserName   ,  
		 cm1.ToFromCode,  
		 cm1.MovementType                     
        from  dbo.CashMovement as cm1                    
        inner join  dbo.Operator op                    
        on   op.user_number = cm1.User_number                    
        --ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
		/*
		Where  cm1.id in( select max(cshMve2.id) as LastID     
		   from CashMovement cshMve2    
		   WHERE cshMve2.RefNo = cm1.RefNo    
		   group by cshMve2.RefNo)
		*/
		Where  cm1.id in (select LastID     
		   from #TempCashMovement (NOLOCK) cshMve2    
		   WHERE cshMve2.RefNo = cm1.RefNo)    
		--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
        and   cm1.Movementtype   in( 1,10) -- send , rejected          
		and   cm1.User_Branch    = 0                    
        and   cm1.ToFromID    = @ToID -- Teller(1),Branch(3)                      
        and   cm1.ToFromCode    = @ToCode -- CurrentBranchID                    
    End                    
End                    
Else if(@ToID =  1) -- to Teller    
begin                      
    declare @ReceiverVault int,    
   @ReceiverDrawerType varchar(40)    
    select  @ReceiverVault = AttachedToVault ,    
    @ReceiverDrawerType = DrawerType    
    from  CashDrawer            
    where  CashDrawerNumber = @CashDrawerNumber
       and AssignedToTeller = @ToCode -- Mohamed Elabd[19-December-2016 - Issue# GFSX11493]
        
    select  cm1.RefNo,    
		cm1.currency,    
		cm1.amount,    
		cm1.FromSeal,    
		cm1.ToSeal,    
		cm1.CashSealMsgrCode,                      
		cm1.User_Branch, -- Sender Branch                       
		cm1.User_Number,    
		cm1.isVault,    
		cm1.date_time,     
		op.LoginID as UserName,            
		cm1.CashDrawerNumber  ,  
		cm1.ToFromCode,  
		cm1.MovementType      
	 from  dbo.CashMovement as cm1                    
    inner join  dbo.Operator op    
    on   op.user_number = cm1.User_number            
    inner join  dbo.CashDrawer cd                
	on   (cd.AssignedToTeller = cm1.User_Number and cm1.CashDrawerNumber = cd.cashdrawerNumber and cd.Branch = cm1.User_Branch )    
   --ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
	/*
	Where  cm1.id in( select max(cshMve2.id) as LastID     
	   from CashMovement cshMve2    
	   WHERE cshMve2.RefNo = cm1.RefNo    
	   group by cshMve2.RefNo)
	*/
	Where  cm1.id in (select LastID     
	   from #TempCashMovement (NOLOCK) cshMve2    
	   WHERE cshMve2.RefNo = cm1.RefNo)    
	--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
    and   cm1.Movementtype in( 1,10) -- send , rejected  
    and   cm1.ToFromID  = @ToID -- Teller(1),Branch(3)                      
    and   cm1.ToFromCode   = @ToCode -- CurrentBranchID  or UserNumber                      
    and   cm1.User_Branch = @CurBranch                    
    and   @ToID = 1  -- When sender is User Movement is from Same Branch            
    and   ((cm1.isVault = 1 and cm1.CashDrawerNumber =  @ReceiverVault) or ( cm1.isVault = 0 and @ReceiverVault = cd.AttachedToVault) )    
    and   ( (cd.DrawerType = @ReceiverDrawerType and cm1.isVault = 0) or cm1.isVault= 1)    
end                    
Else if(@ToID = 9) -- To LeadTeller                      
begin        
 declare  @Vault int            
    select  @Vault = AttachedToVault            
    from  CashDrawer            
    where  CashDrawerNumber = @CashDrawerNumber    
	select  cm1.RefNo,                      
		cm1.currency,                      
		cm1.amount,
		cm1.FromSeal,             
		cm1.ToSeal,                      
		cm1.CashSealMsgrCode,                      
		cm1.User_Branch, -- Sender Branch                       
		cm1.User_Number,                    
		cm1.isVault,                      
		cm1.date_time,                      
		op.LoginID as UserName,            
		cm1.CashDrawerNumber   ,  
		cm1.ToFromCode,  
		cm1.MovementType                     
    from  dbo.CashMovement as cm1                    
    inner join dbo.Operator op                    
    on   op.user_number = cm1.User_number               
    inner join dbo.CashDrawer cd                
	on   (cd.AssignedToTeller = cm1.User_Number and   cm1.CashDrawerNumber =  cd.cashdrawerNumber and cd.Branch = cm1.User_Branch )    
    --ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
	/*
	Where  cm1.id in( select max(cshMve2.id) as LastID     
	   from CashMovement cshMve2    
	   WHERE cshMve2.RefNo = cm1.RefNo    
	   group by cshMve2.RefNo)
	*/
	Where  cm1.id in (select LastID     
	   from #TempCashMovement (NOLOCK) cshMve2    
	   WHERE cshMve2.RefNo = cm1.RefNo)    
	--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
     and  cm1.Movementtype in( 1,10) -- send , rejected  
     and  cm1.ToFromID  = 9 -- LeadTeller(4)                      
     and  cm1.User_Branch  = @CurBranch -- TELLER sent to his Lead Teller                      
     and  ((cm1.isVault = 1 and cm1.CashDrawerNumber =  @Vault) or ( cm1.isVault = 0 and @Vault = cd.AttachedToVault) )            
end 

--ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
DROP Table #TempCashMovement
--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
go
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[14/04/2021]		
--Reason	:	CR# GFSY00848 - BBK_ACM19292_Certification With Windows Server 2019 and Sybase 16
--=============================

PRINT 'Start. Script for CR# GFSY00848 Proc Script - dbo.RebuildIndex'
GO

drop_old_proc 'RebuildIndex'
GO
Create proc RebuildIndex     -- RebuildIndex 'Weekdays','',0,0  
 @table_name varchar(128)    
    , @index_name varchar(255) = ''    
    , @fill_factor int = 0    
    , @debug int = 0   -- If @debug > 1 then don't really do anything, just show.    
    AS    
    -- Rebuild a table index.    
    -- 31JAN07 Erick - Version 1  
	-- 14-04-2021 Ahmed Osman - Version 2 - check if the SQL version is sql standard set online with value offline as online mode not valid with sql standard version
    
    -- Make sure that the fill_factor is smaller or equal to 100    
    declare @adjusted_fill_factor int    
    if (@fill_factor > 100)    
        set @adjusted_fill_factor = 100    
    else    
        set @adjusted_fill_factor = @fill_factor    
    
    -- If the index name is empty, replace it with the keyword ALL to get all the indexes    
    if (@index_name = '')    
        set @index_name = 'ALL'    
    
    -- Check if the table contains columns that can not be build online:    
    --  text, ntext, image, varchar(max), nvarchar(max), varbinary(max), xml    
    declare @online as varchar(3)    
    set @online = 'ON'    
    if exists (    
        select 1 from information_schema.columns     
        where table_name = @table_name     
        and (character_maximum_length = -1 or data_type = 'text' or data_type = 'image' or data_type = 'ntext')    
        )    
        set @online = 'OFF'  
	
	IF serverproperty('EditionID') = -1534726760	-- -1534726760 = Standard
		BEGIN
			set @online = 'OFF' 
		END
    
    DECLARE @execstr   VARCHAR (2000)    
    SET @execstr = 'ALTER INDEX ' + RTRIM(@index_name) + ' ON ' + RTRIM(@table_name) + ' REBUILD WITH ('    
    if (@adjusted_fill_factor > 0)    
        -- Adjust the fillfactor if it is > 0    
        SET @execstr = @execstr + 'FILLFACTOR = ' + CONVERT(varchar(5), @adjusted_fill_factor) + ', '    
    SET @execstr = @execstr + 'ONLINE=' + @online + ')'    
    
    -- Rebuild indexes on the table, using the existing fill factor.     
    if @debug > 1     
        print @execstr    
    else    
        EXEC (@execstr)
GO
PRINT 'End... Script for CR# GFSY00848 Proc Script - dbo.RebuildIndex'
GO
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	[19/05/2021]		
--Reason	:	CR# GFSY00853 - BBK - TT- Correspondent Charges
--=============================

PRINT 'Start. Script for CR# GFSY00853 '
GO

drop_old_proc 'dbo.Select_corres_charges'
GO
Create Procedure dbo.Select_corres_charges   
@bankname nvarchar(40) = null,          
 @currency nvarchar(3) = null,              
 @type  nvarchar(3) = null
AS              
/*              
CreationDate: 17-May-2021              
OriginalName: dbo.Select_corres_charges            
Programmer: Ibrahim Harby             
Description: Select Corres charges according to the Bankname , Currency and charge type              
Output:                
Assumption:               

*/              
  SET NOCOUNT ON        
         
Select top(1) C.corres_charges As Charges
From dbo.CorrespondentCharges as C   
Where C.bnkname  = @bankname        
and   C.currency = @currency        
and	  C.charge_type = @type       

GO
PRINT 'End... Script for CR# GFSY00853'
GO
Drop_Old_Proc '[Get_Journal_Summary_For_Printing]' 
GO  
Create PROC [dbo].[Get_Journal_Summary_For_Printing]      
 @criteria nvarchar(max) = '',
 @criteria2 nvarchar(max) = '',
 @start_date smalldate,     
 @end_date smalldate,   
 @order_time_ascending bit = 0,      
 @max_rows int = 9,  -- Zero means return only one row.      
 @page_back bit = 0,      
 @LCID int = NULL, -- May be used to get local tran Description.      
 @for_user internal_user_ID =0,      
 @debug int = 1    
AS      
-- Query the Teller journal summary view for records that match the criteria.      
-- For just the @max_rows that match the criteria, join in the description      
--  of the transaction as "Tran_Title".      
      
-- When @page_back is ON, you get the last n rows that match the criteria.      
      
-- This uses the select projection list developed by proc SetJnlSummaryColumns2.      
-- Copyright 2003, 2004, 2005, 2006, 2007, 2008 Getronics USA, INC. All rights reserved.      
-- Created 05Feb03 by Bodhi Densmore      
-- 07FEB03 Bodhi added start_date and end_date parameters to ensure quick retrieval.      
-- 02APR03 Bodhi - To improve performance, don'T use RulesDecriptorLOCAL table when it is not useful.      
-- 02JUL03 Bodhi - Join in isDupable and isCorrectable from RulesTranName, per request from Mike Chandler.      
-- 11JUL03 Bodhi - Normal order is ascending by operator and descending by time and jnlSequence.      
-- 10Mar04 Bodhi - Support having only user_number and not LoginID (Operator) in Journal.      
--                 Using a late-binding join to the Operator table for best performance.      
-- 22Apr04 Bodhi - Fix syntax bug in retrieving local descriptors for transaction name.      
-- 21May04 Bodhi - Support conversion of user_numbers to login IDS.      
-- 06JUL04 Bodhi - Join in isSuperDupable from RulesTranName, per CR9728.      
-- 31JAN04 Bodhi - Support additional fields like "Supervisor" as interual_user_ID. CR10172      
-- 27Jul05 Kevens - Support additional column names like bank, region and branch that are not exactly those names.      
-- 17Aug05 Bodhi - Support queries with only date criteria, - initial value of @criteria empty.      
-- 23SEP05 Bodhi - For better performance, calculate table name when only one month is used.      
--                 Replace f_OperatorID_of_user_number with opID_of_U#      
-- 31AUG06 Bodhi - Use nolock hint when number of @max_rows is small, indicating not-for-report.       
-- 15JAN07 Diana - Add extra condition to the 'where' clause for checking privileges in OperatorRoles. CR14966      
-- 22Apr07 Bodhi - Use "inside order" for ORDER BY after the final join.      
-- 22Apr07 B & D - Support SmallDate as integer.      
-- 22May07 Bodhi - Complain about start_date too early on DBMaster or if debugging.      
-- 16MAR08 DEEPAK D R - Collation cast added CR16728      
-- 08APR10 Bodhi - Forgive dates less than minimum when minimum is today (because Journal is empty).      
    
/*    
Modified by: Adel Shaban    
Date: 9/2/2011    
Reason: Fixing issue when table doesn't exist in database - issue#103687    
  
Modified by: Amira Kamel  
Date: 28/12/2013   
Reason: Selact Accounting Entries, host ref no , cheque no  
  
Modified by: Ibrahim Harby  
Date: 20/01/2021   
Reason: add @Sql2 , @where2 , @criteria2 for union sql2 with sql one   
 to get old behaviour data with new PostingFromSupervisor data   
*/    
    
SET NOCOUNT ON      
declare @sql nvarchar(max), @sql2 nvarchar(max), @param_defs nvarchar(1000)      
declare @summary_sql nvarchar(4000), @position int, @operator_columns nvarchar(500)      
declare @position_of_from int      
declare @date_string varchar(30), @date_string2 varchar(30)      
declare @normal_descending_order nvarchar(300)      
 , @normal_ascending_order nvarchar(300)      
 , @inside_order nvarchar(300)      
 , @outer_order nvarchar(300)      
declare @tran_def_columns nvarchar(200)      
declare @start_year_month smallint, @end_year_month smallint, @start_day tinyint, @end_day tinyint      
declare @table_name sysname, @suffix char(7)      
declare @where nvarchar(1000) , @where2 nvarchar(max)  
declare @AcctEntries_table sysname  
declare @AcctEntries_sql nvarchar(4000)    
-- Begin Ibrahim Harby  (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value  
declare @LikeParamFirstPart nvarchar(100)  
set @LikeParamFirstPart =   '''%n="PostingFromSupervisor_RequesterUserNumber" v="'  
declare @LikeParamLastPart nvarchar(100)  
set @LikeParamLastPart =  '"%'''  
-- End Ibrahim Harby (17-12-2020)   
-- ** CR14330 ** S      
declare @no_lock_hint nvarchar(14)      
if @max_rows < 22      
 set @no_lock_hint = N' WITH (NOLOCK)' -- Read uncommitted when not for a print report.      
else      
 set @no_lock_hint = ''      
-- ** CR14330 ** E      
set @start_year_month = dbo.YYMM_of_SmallDate(@Start_Date)      
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)      
set @start_day = DatePart(dd, dbo.datetime_of_smalldate(@start_date))      
set @end_day = DatePart(dd, dbo.datetime_of_smalldate(@end_date))      
if @start_year_month = @end_year_month BEGIN      
 set @suffix = dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@start_date))      
 set @table_name = 'ZJournal'+ @suffix     
  set @AcctEntries_table = 'ZJNL_AccingEnt'+ @suffix    
 -- Adel Shaban - Fixing issue when table doesn't exist in database    
 if(Not Exists( Select 1 from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @table_name))    
 BEGIN    
 select * FROM Journal WHERE 1 = 2 -- return dataset with correct schema and no rows    
 RETURN -1 -- exist from proc     
 END    
 -- End of Adel Shaban - Fixing issue when table doesn't exist in database  
 
Declare @Expression varchar(max) = null
Declare @individual varchar(max) = null
Declare @usernumber varchar(max) = NULL

SET @Expression = @criteria
SET @Expression = REPLACE(@Expression, 'and', ',')
SET @Expression = REPLACE(@Expression, ' ', '')

WHILE LEN(@Expression) > 0
BEGIN
    IF PATINDEX('%,%', @Expression) > 0
		BEGIN
		    SET @individual = SUBSTRING(@Expression, 0, PATINDEX('%,%', @Expression))

		    IF @individual LIKE 'user_number=%'
				BEGIN
					SET @usernumber = @individual
				END

		    SET @Expression = SUBSTRING(@Expression, LEN(@individual + ',') + 1, LEN(@Expression))
		END
    ELSE
		BEGIN
			SET @individual = @Expression
			SET @Expression = NULL
			
			IF @individual LIKE 'user_number=%'
				BEGIN
					SET @usernumber = @individual
				END
		END
END
SET @usernumber = REPLACE(@usernumber, 'user_number=', '')

 --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value  
  -- @where2 for union criteria   
 set @where2 = N'WHERE  J.TLR_DUMMY_FIELDS like '+ @LikeParamFirstPart +cast (@usernumber as nvarchar(10))  +@LikeParamLastPart  
   +' AND J.year_month = @start_ym' + char(10)     
 + ' AND J.BusinessDate_Day '      
 + case when @start_day = @end_day       
  then '= @start_day AND J.BusinessDate = @start_date'      
  else 'between @start_day and @end_day       
  and J.BusinessDate between @start_date and @end_date'      
  end      
  
   set @where = N'WHERE   J.year_month = @start_ym' + char(10)     
 + ' AND J.BusinessDate_Day '      
 + case when @start_day = @end_day       
  then '= @start_day AND J.BusinessDate = @start_date'      
  else 'between @start_day and @end_day       
  and J.BusinessDate between @start_date and @end_date'      
  end      
     -- End Ibrahim Harby (17-12-2020)   
  -------------*******---  
  
END       
ELSE BEGIN      
 set @table_name = 'Journal'     
 set @AcctEntries_table = 'JNL_AccingEnt'    
  --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value  
 set @where2 = N'WHERE J.year_month between @start_ym and @end_ym      
 and J.BusinessDate between @start_date and @end_date'    
  + ' and   J.TLR_DUMMY_FIELDS like '+  @LikeParamFirstPart +cast (@for_user as nvarchar(10))  +@LikeParamLastPart   
  
  set @where = N'WHERE J.year_month between @start_ym and @end_ym      
 and J.BusinessDate between @start_date and @end_date'    
   -- End Ibrahim Harby (17-12-2020)  
END      
      
if @for_user >0 and dbo.operator_has_wildcard_permissions(@for_user)<1      
 set @where =@where+' AND dbo.is_BranchAllowed(@for_user,J.Bank,J.Region,J.Branch)=1 '      
      
IF isNULL(@LCID,0) = 0       
--**CR16728 ** S      
 set @tran_def_columns = N'      
 , Tran_Title = T.Description collate SQL_Latin1_General_CP1_CI_AS, T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable '      
else      
 --**CR16728 ** E      
 set @tran_def_columns = N'      
 , Tran_Title = isNULL(isnull(RD.LocalDescription, D.Descriptor), T.Description collate SQL_Latin1_General_CP1_CI_AS), T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable '      
      
select @summary_sql =       
 substring(dbo.f_insert_new_lines(AccessString,72),7,3990)       
from dbo.SQLstrings       
where AccessName = 'JOURNAL_SUMMARY'      
    
select @AcctEntries_sql =  
 char(10)+N',(select   
x.Subscript,  
x.JNL_Acct_ENT_ACCOUNT,  
x.JNL_Acct_ENT_DB_CURR,  
x.JNL_Acct_ENT_DB_AMOUNT,  
x.JNL_Acct_ENT_CR_CURR,  
x.JNL_Acct_ENT_CR_AMOUNT  
'  
+ char(10)      
+ 'FROM dbo.'+@AcctEntries_table+N' x'     
+'  
where J.BusinessDate = x.BusinessDate  
and J.user_Number= x.user_Number  
and J.Bank = x.Bank   
and J.Region = x.Region   
and J.Branch = x.Branch   
and J.JNLSequence = x.JNLSequence   
for xml path(''AccountEntries'')  
) as AccountEntries  
'      
set @position = charindex(', dbo.opID_of_U#', @summary_sql, 100)      
if @position = 0 begin      
  raiserror('Get_Journal_Summary can not find ", dbo.opID_of_U#" in JOURNAL_SUMMARY SQLstrings.AccessString', 16, 1)      
  return -1      
end      
set @position_of_from = charindex(' FROM ', @summary_sql, @position) - (@position + 2)      
set @operator_columns = substring(@summary_sql, @position+2, @position_of_from)      
set @operator_columns = replace(@operator_columns, '(user_number', '(JS.user_number')      
set @position = @position -1      
if @debug > 0 or @@servername like '%DBMASTER%'begin      
 declare @min_date smalldate      
 if db_name() like '%archive'      
  set @min_date = dbo.smalldate_of(dbo.f_Teller_Base_date())      
 else      
  set @min_date = dbo.f_min_journal_business_date(dbo.smalldate_of(getdate()))      
       
 if @start_date < @min_date begin      
  if @min_date < dbo.smalldate_of(getdate()) begin      
   set @date_string = isNULL(cast (@start_date as varchar), '-NULL-')      
   set @date_string2 = convert(varchar(10), @min_date)      
   raiserror('Get_Journal_Summary @start_date,"%s" must be > "%s"'      
    , 16, 1, @date_string, @date_string2)      
   return -1      
  end      
 end      
 if @start_date > @end_date or @end_date is null begin      
  set @date_string = isNULL(cast(@end_date as varchar), '-NULL-')      
  set @date_string2 = cast(@start_date as varchar)       
      
  raiserror('Get_Journal_Summary @end_date, "%s" must be >= @startdate = "%s"'      
   , 16, 1, @date_string, @date_string2)      
  return -1      
 end      
end      
set @criteria = dbo.TRIM(@criteria)  -- TRIM off left and right spaces.      
if @criteria <> '' and substring(@criteria,1,8) not like '%where %' begin      
 if left(@criteria, 4) = 'AND '       
  set @criteria = @where + ' ' + @criteria      
 else begin      
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)      
  return -1      
 end      
end     
       
if @criteria = ''      
 set @criteria = @where      
else begin      
 if @criteria like '%[^a-z_0-9.]Bank %'       
  set @criteria = replace (@criteria, 'bank ', 'J.Bank ')      
      
 if @criteria like '%[^a-z_0-9.]user_number %'       set @criteria = replace (@criteria, 'user_number ', 'J.user_number')      
      
 if @criteria like '%[^a-z_0-9.]Region %'       
  set @criteria = replace (@criteria, 'region ', 'J.Region ')      
      
 if @criteria like '%[^a-z_0-9.]Branch %'       
  set @criteria = replace (@criteria, 'branch ', 'J.Branch ')      
      
 if substring(@criteria,1,8) not like '%where %' begin      
  if left(@criteria, 4) = 'AND '       
   set @criteria = @where + ' ' + @criteria      
  else begin      
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)      
   return -1      
  end      
 end else       
  set @criteria = @where +REPLACE(@criteria,'where', ' AND')      
end       
--*****************  
--***************  for union criteria  
set @criteria2 = dbo.TRIM(@criteria2)  -- TRIM off left and right spaces.      
if @criteria2 <> '' and substring(@criteria2,1,8) not like '%where %' begin      
 if left(@criteria2, 4) = 'AND '       
  set @criteria2 = @where2 + ' ' + @criteria2      
 else begin      
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)      
  return -1      
 end      
end     
       
if @criteria2 = ''      
 set @criteria2 = @where2      
else begin      
 if @criteria2 like '%[^a-z_0-9.]Bank %'       
  set @criteria2 = replace (@criteria2, 'bank ', 'J.Bank ')      
      
 if @criteria2 like '%[^a-z_0-9.]user_number %'       set @criteria2 = replace (@criteria2, 'user_number ', 'J.user_number')      
      
 if @criteria2 like '%[^a-z_0-9.]Region %'       
  set @criteria2 = replace (@criteria2, 'region ', 'J.Region ')      
      
 if @criteria2 like '%[^a-z_0-9.]Branch %'       
  set @criteria2 = replace (@criteria2, 'branch ', 'J.Branch ')      
      
 if substring(@criteria2,1,8) not like '%where %' begin      
  if left(@criteria2, 4) = 'AND '       
   set @criteria2 = @where2 + ' ' + @criteria2      
  else begin      
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)      
   return -1      
  end      
 end else       
  set @criteria2 = @where2 +REPLACE(@criteria2,'where', ' AND') 
end   
---***************************  
--------------------------------      
if @max_rows < 0 begin      
 raiserror('Get_Journal_Summary @max_rows "%d", must be at least 0', 16, 1, @max_rows)      
 return -1      
end      
      
set @normal_descending_order = N'      
 order by Bank,Region,Branch,user_number,TransactionTime desc, JNLSequence desc'      
set @normal_ascending_order = N'      
 order by Bank,Region,Branch,user_number,TransactionTime,JNLSequence'      
set @inside_order = case       
when @order_time_ascending = 0 and @page_back = 0 then @normal_descending_order      
when @order_time_ascending = 0 and @page_back = 1 then N'      
 order by Bank desc,Region desc,Branch desc, user_number desc,TransactionTime, JNLSequence'      
when @order_time_ascending = 1 and @page_back = 0 then @normal_ascending_order      
else N'      
 order by Bank desc,Region desc,Branch desc,user_number desc,TransactionTime desc, JNLSequence desc'      
end      
      
select @sql = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)       
+ substring(@summary_sql,1, @position)  
+ @AcctEntries_sql        
+ char(10)      
-- ** CR14330 ** S      
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint      
-- ** CR14330 ** E      
+ char(10) + @criteria + @inside_order      
      
--*****************  
--***************  for union   
 select @sql2 = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)       
+ substring(@summary_sql,1, @position)  
+ @AcctEntries_sql        
+ char(10)      
-- ** CR14330 ** S      
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint      
-- ** CR14330 ** E      
+ char(10) + @criteria2 + @inside_order      
--*****************  
if @page_back = 1 begin      
 set @outer_order = case @order_time_ascending      
          when 0 then @normal_descending_order      
   else @normal_ascending_order      
   end      
      
 set @sql = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql+N') BOTTOM' + @outer_order      
  
--***************  for union   
set @sql2 = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql2+N') BOTTOM' + @outer_order      
--*****************  
end      
IF isNULL(@LCID,0) = 0   
begin  
 --Begin Ibrahim Harby (20-01-2021)  
set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns   ++ N' FROM (' + @sql +   
                     '    union all '  
                     + @sql2 + ' ) AS JS    JOIN dbo.RulesTranName T     on T.TransactionName = JS.TranName'    
 end  
ELSE       
 set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns      
+ N'      
FROM (' + @sql + '   
union all  
  '+ @sql2 + ' ) AS JS      
JOIN dbo.RulesTranName T      
  on T.TransactionName = JS.TranName      
LEFT OUTER JOIN dbo.RulesDescriptor D      
  on D.DescriptorID = T.DSC_Description      
LEFT OUTER JOIN dbo.RulesDescriptorLocal RD      
  on RD.DescriptorID = D.DescriptorID and LCID = @LCID'      
-- ** CR15838 ** S      
+ char(10) + @inside_order      
-- ** CR15838 ** E      
   --End Ibrahim Harby (20-01-2021)      
set @param_defs = N'@LCID int, @start_date smalldate, @end_date smalldate, @start_ym smallint, @end_ym smallint, @start_day tinyint, @end_day tinyint, @for_user internal_user_ID'      
if @debug > 0 begin      
 print '-------cut here ---------'       
 print 'declare ' + @param_defs + char(10)       
 print 'select @LCID = ' + isnull(cast(@LCID as varchar), 'NULL')      
 print '    , @start_date = '''+cast(@start_date as varchar) + ''''      
 print '    , @end_date = '''+cast(@end_date as varchar) + ''''      
 print '    , @start_ym = '+cast(@start_year_month as varchar)      
 print '    , @end_ym = '+cast(@end_year_month as varchar)      
 print '    , @start_day = '+cast(@start_day as varchar)      
 print '    , @end_day = '+cast(@end_day as varchar)      
 print ' ,@for_user='+cast(@for_user as varchar)      
 /*print '    , @user_number = ' + case @user_number when NULL then ' NULL ' else cast(@user_number as varchar) end*/      
 print @sql      
 if @debug > 3 return -1      
end      
exec dbo.sp_executesql @sql, @param_defs, @LCID, @start_date, @end_date      
 , @start_year_month, @end_year_month, @start_day, @end_day, @for_user     
GO
drop_old_proc 'Select_TellerConfig'
go
create  procedure dbo.Select_TellerConfig                
As                
                
/*                
CreationDate: 2004-08-10                
OriginalName: dbo.Select_TellerConfig                
Programmer: Mahmoud Elkabary                
Description: Select Teller Configration from TellerConfig                
Output:  User_Number,FirstName,LastName,DenomRequired,DenomMandetory                
Assumption:                 
                
ModifiedDate: 2004-09-12                
Modifer:  Mahmoud Elkabary                
ModifyReason: Add AccountingEntries column                
            
ModifiedDate: 2008-02-23            
Modifer:  Mahmoud El Banna            
ModifyReason: change the inner join departmnet to left join            
            
modifier : hany nasr            
date : 8-5-2008            
reason : performance tunning              
          
ModifiedDate: 2009-05-13            
Modifer:  Amira Kamel          
ModifyReason: Replace tellerlimitcategory with usergroup          
        
modifier : Amira Kamel        
date : 4-10-2009        
reason : CR: Passbook History : Select New Column to check on passbook        
        
ModifiedDate: 2011-10-31        
Modifer:  Hatim Al Sum         
ModifyReason: Add Gender to Teller Information        
      
ModifiedDate: 2013-2-28        
Modifer:  May Hassan         
ModifyReason: Add CashMax_Notify and UserGroup to Teller Information     
    
ModifiedDate: 2015-1-4          
Modifer:  May Hassan           
ModifyReason: Enhancement# GFSY00439, Add EnableOTPLogin to Teller Information    
    
ModifiedDate: 2016-05-17          
Modifer:  Reem Mandour        
ModifyReason: Enhancement# GFSY00502, ADD First Name , Middle Name, Last Name , LoginID to Teller Information   
   
  
ModifiedDate: 2016-22-5          
Modifer     : Asmaa Gamal         
ModifyReason: Enhancement# GFSY00566, retrive value of StopValidateGLRestriction   

ModifiedDate: 2016-8-5          
Modifer     : Amira Kamel      
ModifyReason: Enhancement# GFSY00584, retrive value of StopValidateGLRestriction     

ModifiedDate: 2021-05-13          
Modifer     : Ahmed Osman    
ModifyReason: Enh GFSY00850 - BARWA - ACM19129 - General Enhancement II

*/                
set nocount on                
select o.User_Number,                  
 o.FirstName +' ' +o.LastName as Full_Name,                  
 t.DenomRequired,                  
 t.DenomMandetory,                  
 t.AccountingEntries ,                  
 t.TellerLimitCategory,                  
 ug.GroupName as [User Group],--[Teller Limit Category]  ,      --          
 t.IR_Supervisor,                
 t.IR_Modifier ,                
 t.DepartmentID,                
 t.UserLevelID,                
 t.MrkChkOpt,                
 t.ScreenLockInterval,                
 d.DescriptorName,        
 t.donotcheckpassbookpendingtrn,        
 CASE o.Gender         
   WHEN 'F' Then 'Female'        
   WHEN 'M' Then 'Male'           
   Else 'Male'         
End As Gender ,      
tcl.Name AS [Teller Limit Category] ,      
t.UserGroup,      
t.CashMax_Notify,    
t.EnableOTPLogin ,    
o.FirstName,     
o.Middle as MiddleName,    
o.LastName,     
o.LoginID,  
t.StopValidateGLRestriction,
t.CustomerClassGroup   ,
CCG.GroupName,
t.HideOverrideNotification
      
from dbo.operator as o                  
inner join dbo.tellerconfig as t                  
on o.user_number = t.user_id                  
left join dbo.Department as d                
on d.id = t.DepartmentID                
left join                
 dbo.UserGroup ug                
on ug.GroupID = t.UserGroup           
left join                  
 dbo.TellerLimitCategory tcl                  
on tcl.id = t.TellerLimitCategory     
left join 
dbo.CustomerClassGroup CCG
on CCG.GroupID  = t.CustomerClassGroup
go
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00804 Proc Script - dbo.SelectTellerConfig'
GO 
 
drop_old_proc 'SelectTellerConfig'
GO
create proc dbo.SelectTellerConfig		--SelectTellerConfig 1526
@UserNumber int
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
	Description	:	Select Teller Config
*/          

SELECT * FROM TellerConfig WHERE User_ID = @UserNumber
 
GO

PRINT 'End... Script for CR# GFSY00804 Proc Script - dbo.SelectTellerConfig'
GO 
drop_old_proc'Update_TellerConfig'        
go
 create  procedure dbo.Update_TellerConfig          
@User_ID  varchar(1000),          
@DenomRequired bit,          
@DenomMandetory bit,          
@AccountingEntries bit,          
@UserGroup int,         
@Updator OperatorID  ,        
@IRSupervisor bit,          
@IRModifier bit,          
@UserDepartment int,        
@UserLevel int,        
@MarkCheck int,        
@ScreenLockInterval int ,      
@DontCheckPassbook bit = 0 ,    
@NotifyCashMax bit,    
@TellerLimitCategory int    
--[Asmaa Gamal][BEGIN: KIB - INC000000049352 - GFSX07982][2014-12-29]        
,@Workstation_ID MachineName = Null ,         
--[Asmaa Gamal][END: KIB - INC000000049352 - GFSX07982][2014-12-29]       
@EnableOTPLogin bit =0  ,  
@StopValidateGLRestriction bit  ,
@CustClassGroup int = -1,
@HideOverrideNotification bit = 0
             
As          
/*          
CreationDate: 2004-08-10          
OriginalName: dbo.Update_TellerConfig          
Programmer: Mahmoud Elkabary          
Description: Update Teller Configration at TellerConfig          
Output:            
Assumption:           
          
ModifiedDate: 2004-09-12          
Modifer:  Mahmoud ELkabary          
ModifyReason: Add column AccountingEntries          
          
          
ModifiedDate: 2007-02-20          
Modifer:      Mohamed Gad          
ModifyReason: Adding Updator  parameter to the procedure          
          
modifier : hany nasr        
date : 8-5-2008        
reason : performance tunnning        
      
modifier : Amira Kamel      
date : 4-10-2009      
reason : CR: Passbook History : Update New Column to check on passbook      
    
modifier : May Hassan      
date : 28-2-2013      
reason : CR: DTM Enhancement-UserConfiguartion : Adding CashMax_Notify, and UserGroup column to be updated    
    
modifier : Asmaa Gamal              
date : 29/12/2014              
reason :   [KIB - INC000000049352 - GFSX07982][2014-12-29]     
    
modifier : May Hassan          
date : 4-1-2015         
reason : CR: Zenith_GFS_XXXX_Dual Factor Authentication - Enhancement# GFSY00439 : Adding EnableOTPLogin column to be updated      
  
  
ModifiedDate: 2016-07-08          
Modifer     : Asmaa Gamal         
ModifyReason: Enhancement# GFSY00566, update value of StopValidateGLRestriction      

ModifiedDate: 2016-08-02          
Modifer     : Amira Kamel     
ModifyReason: Enhancement# GFSY00584, RIM Associated To Customer Segment attach class group to teller    

ModifiedDate: 2021-05-13          
Modifer     : ahmed osman   
ModifyReason: Enh GFSY00850 - BARWA - ACM19129 - General Enhancement II

*/        
    
--[Asmaa Gamal][BEGIN: KIB - INC000000049352 - GFSX07982][2014-12-29]        
 select @Workstation_ID = REPLACE(@Workstation_ID,'\DOMAIN\','\')           
--[Asmaa Gamal][END: KIB - INC000000049352 - GFSX07982][2014-12-29]       
      
set nocount on          
declare @stmt varchar(8000)          
          
set @stmt = '          
update TellerConfig           
set DenomRequired='+convert(char(1),@DenomRequired)+' ,          
 DenomMandetory='+convert(char(1),@DenomMandetory)+',          
 AccountingEntries='+convert(char(1),@AccountingEntries)+',          
 TellerLimitCategory = '+convert(varchar(20),@TellerLimitCategory)+',        
 IR_Supervisor = '+convert(varchar(20),@IRSupervisor )+',        
 IR_Modifier = '+convert(varchar(20),@IRModifier)+',        
 DepartmentID = '+convert(varchar(20),@UserDepartment)+',        
 UserLevelID = '+convert(varchar(20),@UserLevel)+',        
 MrkChkOpt = '+convert(varchar(20),@MarkCheck)+',        
 ScreenLockInterval ='+convert(varchar(20), @ScreenLockInterval )+',        
 donotcheckpassbookpendingtrn ='+convert(char(1), @DontCheckPassbook )+',       
 CashMax_Notify = '+convert(char(1),@NotifyCashMax)+',    
 UserGroup = '+convert(varchar(20),@UserGroup)+',  
 StopValidateGLRestriction ='+convert(char(1),@StopValidateGLRestriction)+' ,    
 EnableOTPLogin = '+convert(char(1),@EnableOTPLogin)+',     
 Updator = '''+@Updator+''',
 Workstation_ID = '''+@Workstation_ID+''',
 HideOverrideNotification = '+convert(char(1),@HideOverrideNotification)+', 
 CustomerClassGroup = '+convert(varchar(20),@CustClassGroup)+'     
where  [User_ID] in (' + @User_ID + ')'          

--print (@stmt)
exec (@stmt)          
--set nocount off                

go    
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 Proc Script - dbo.AMLInfo_InsertAndUpdate'
GO

drop_old_proc 'AMLInfo_InsertAndUpdate'
GO
create proc dbo.AMLInfo_InsertAndUpdate
@Mode						int, -- 0 for insert , 1 for update AML Data , 2 for update Rim Data
@ReferenceNumber			ReferenceNumber		= NULL,
@IsPersonal					bit					= NULL,
@ClientName					varchar(80)			= NULL,
@TelephoneNumber			varchar(20)			= NULL,
@PlaceOfBirth				char(5)				= NULL,
@DateOfBirth				datetime			= NULL,
@Nationality				int					= NULL,
@CountryOfIncorporation		char(5)				= NULL,
@Country					char(5)				= NULL,
@PostalCode					varchar(10)			= NULL,
@AddressLine1				varchar(40)			= NULL,
@AddressLine2				varchar(40)			= NULL,
@Governorate				int					= NULL,
@IDType						int					= NULL,
@IDNumber					varchar(25)			= NULL,
@IssueDate					datetime			= NULL,
@ExpirationDate				datetime			= NULL,
@CountryOfIssuance			char(5)				= NULL,
@DateOfUpdate				datetime			= NULL,
@AMLReferenceID				varchar(16)			= NULL,
@RiskRating					varchar(20)			= NULL,
@OpeningStatus				varchar(40)			= NULL,
@RimCreated					bit					= NULL,
@CardReaderLogId			int					= NULL,
@TransactionType			TransactionName		= NULL,
@ResidencyStatus			varchar(20)			= NULL,
@RimClass					int					= NULL,
@RimNumber					varchar(max)		= NULL,
@AccountNumber				varchar(max)		= NULL,
@AccountType				varchar(max)		= NULL,
@Occupation					int					= NULL,
@IsPEP						bit					= NULL,
@NationalityCode			varchar(100)		= NULL,
@EconomicSector				varchar(max)		= NULL,
@BusinessDomain				char(1)				= NULL,
@ProductAndSerivce			varchar(100)		= NULL,
@RequestID					varchar(max)		= NULL,
@Branch						varchar(100)		= NULL,
@UserName					varchar(100)		= NULL,
@RequestDate				DateTime			= NULL,
@Cahnnel					varchar(50)			= NULL,
@OwnerShip					varchar(100)		= NULL,
@CivilIDFormat				varchar(max)		= NULL,
@CivilID					varchar(max)		= NULL,
@RIMStatus					varchar(max)		= NULL,
@EmployeeID					varchar(max)		= NULL,
@EmployeeName				varchar(max)		= NULL
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[11/05/2020]		
	Reason		:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
	Description	:	Insert and Update table AML_Info

	Devolper	:	Ahmed Osman
	Date		:	[19/05/2021]		
	Reason		:	Enh GFSY00849 - BARWA - ACM19131- KYC Enhancement
	Description	:	Add columns [BranchName,UserName,RequestDate,Cahnnel,OwnerShip,CivilIDFormat,CivilID,RIMStatus,EmployeeID,EmployeeName] to insert and update statment
*/     

IF @Mode = 0
	BEGIN
		IF NOT EXISTS(SELECT * FROM AML_Info WHERE ReferenceNumber = @ReferenceNumber)
			BEGIN
				Insert Into AML_Info(ReferenceNumber,IsPersonal,ClientName,TelephoneNumber,PlaceOfBirth,DateOfBirth,Nationality,CountryOfIncorporation,Country,PostalCode,AddressLine1,AddressLine2,Governorate,IDType,IDNumber,IssueDate,ExpirationDate,CountryOfIssuance,DateOfUpdate,AMLReferenceID,RiskRating,OpeningStatus,RimCreated,CardReaderLogId,TransactionType,ResidencyStatus,RimClass,RimNumber,AccountNumber,AccountType,Occupation,IsPEP,NationalityCode,EconomicSector,BusinessDomain,ProductAndSerivce,RequestID,Branch,UserName,RequestDate,Cahnnel,OwnerShip,CivilIDFormat,CivilID,RIMStatus,EmployeeID,EmployeeName)
				Values (@ReferenceNumber,@IsPersonal,@ClientName,@TelephoneNumber,@PlaceOfBirth,@DateOfBirth,@Nationality,@CountryOfIncorporation,@Country,@PostalCode,@AddressLine1,@AddressLine2,@Governorate,@IDType,@IDNumber,@IssueDate,@ExpirationDate,@CountryOfIssuance,@DateOfUpdate,@AMLReferenceID,@RiskRating,@OpeningStatus,@RimCreated,@CardReaderLogId,@TransactionType,@ResidencyStatus,@RimClass,@RimNumber,@AccountNumber,@AccountType,@Occupation,@IsPEP,@NationalityCode,@EconomicSector,@BusinessDomain,@ProductAndSerivce,@RequestID,@Branch,@UserName,@RequestDate,@Cahnnel,@OwnerShip,@CivilIDFormat,@CivilID,@RIMStatus,@EmployeeID,@EmployeeName)
			END		
	END
ELSE IF @Mode = 1
	BEGIN
		UPDATE AML_Info
			SET 
				AMLReferenceID	= CASE WHEN @AMLReferenceID IS NULL THEN AMLReferenceID ELSE @AMLReferenceID END   
				,RiskRating		= CASE WHEN @RiskRating IS NULL THEN RiskRating ELSE @RiskRating END 
				,OpeningStatus	= CASE WHEN @OpeningStatus IS NULL THEN OpeningStatus ELSE @OpeningStatus END 
				,RimCreated		= CASE WHEN @RimCreated IS NULL THEN RimCreated ELSE @RimCreated END 
				,RimNumber		= CASE WHEN @RimNumber IS NULL THEN RimNumber ELSE @RimNumber END  
				,AccountNumber	= CASE WHEN @AccountNumber IS NULL THEN AccountNumber ELSE @AccountNumber END  
				,AccountType	= CASE WHEN @AccountType IS NULL THEN AccountType ELSE @AccountType END  
				WHERE RequestID	= @RequestID
	END

IF(@@error<>0)            
     BEGIN            
		RETURN -1          
     END  
ELSE          
     BEGIN              
		RETURN 1     
     END            
GO

PRINT 'End... Script for CR# GFSY00793 Proc Script - dbo.AMLInfo_InsertAndUpdate'
GO
Go
drop_old_proc 'dbo.GetAMLPendingRequests'
Go
create proc dbo.GetAMLPendingRequests  
@IDType    int    = NULL,  
@IDNumber   varchar(25)  = NULL,  
@TransactionType TransactionName = NULL,  
@Status    varchar(100) = NULL  
as          
      
/*      
 Devolper : Ahmed Osman  Date  : [11/05/2020]    Reason  : Enh GFSY00793 - BARWA - ACM000000018134 AML Integration  
 Description : Get AML Pending Requests  
*/            
 SELECT RequestID AS 'RequestID',
        Branch AS 'Branch' 
 FROM AML_Info 
 WHERE IDType = @IDType 
   AND IDNumber = @IDNumber 
   AND TransactionType = @TransactionType 
   AND OpeningStatus = @Status  
GO
Go
drop_old_proc 'dbo.SelectAML_Info_OnBoard'
Go
Create PROC dbo.SelectAML_Info_OnBoard    
/*      
 Creator : Mostafa Helmy     
 Date  : 10-06-2020  
 Reason  :#GFSY00793 used to search in AML_Info Table in case of  using AML On Boarding Web Service.    
 */  
  
@AMLReferenceID varchar(16) = null,    
  
@IsPersonal   bit = null,          
  
@ClientName   varchar(80) = null,          
  
@TelephoneNumber varchar(20) = null,          
 
@IDNumber   varchar(25) = null,    
  
@OpeningStatus      varchar(40) = null,    
  
@RimCreated   bit = null     ,  
  
@IDType int = null,  
  
@TransactionType varchar(40)='All',  
  
@RimNumber varchar(max) = null,

@Branch	   varchar(100) = null
AS               
  
/*         
/*Version 2.00.46.13.01 Modification Date : 20140922*/                 
  
 CreationDate: 22/09/2014                
  
 OriginalName: dbo.SelectAML_Info_OnBoard                
  
 Programmer:  Mostafa Helmy               
  
 Description: Select from table AML_Info                       
  
 Reason:   Barwa  Ethix Branch Integration With AML (GFSY00793)   
  

MdificationDate: 2021-April-28    
OriginalName: dbo.SelectAML_Info_OnBoard   
Programmer: Ahmed Eliwa       
Description: Adding barnch name to retrived data Enh: GFSY00849  


MdificationDate	: {19/05/2021}      
Programmer		: Ahmed Osman
Description		: Select * from table AML_Info instead of columns names
*/                
  
SET NOCOUNT ON                   
  
               
  
SELECT *

  FROM AML_Info        
  
  where (@AMLReferenceID is null or AMLReferenceID = @AMLReferenceID)     
  
    and (@IsPersonal is null or IsPersonal = @IsPersonal )       
  
    and (@ClientName is null or ClientName like '%'+@ClientName+'%' )      
  
    and (@TelephoneNumber is null or TelephoneNumber = @TelephoneNumber )     
  
    and ((@IDNumber is null and @IDType is null ) or (IDNumber = @IDNumber and IDType=@IDType))  
  
    and (@OpeningStatus is null or  Charindex(','+OpeningStatus+',', @OpeningStatus) > 0)     
  
    and (@RimCreated is null or RimCreated = @RimCreated )   
   
 and(@TransactionType='All' or TransactionType=@TransactionType)     
  
 and(@RimNumber is null or RimNumber =@RimNumber)  

 and(@Branch is null or Branch =@Branch)  
  
ORDER  BY  ReferenceNumber     
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[19/05/2021]		
--Reason	:	Enh GFSY00849 - BARWA - ACM19131- KYC Enhancement
--===============================================================

PRINT 'Start. Script for CR# GFSY00807 Proc Script - dbo.SelectEmployeeName'
GO

drop_old_proc 'SelectEmployeeName'
GO
create proc dbo.SelectEmployeeName		-- SelectEmployeeName 0
@EmpID int 
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[19/05/2021]	
	Reason		:	Enh GFSY00849 - BARWA - ACM19131- KYC Enhancement
	Description	:	select employee name from table ad_gb_rsm using employee_id
*/          

SELECT user_name AS 'EmployeeName' FROM ad_gb_rsm WHERE employee_id = @EmpID

GO

PRINT 'End... Script for CR# GFSY00807 Proc Script - dbo.SelectEmployeeName'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 Proc Script - dbo.AMLInfo_InsertAndUpdate'
GO

drop_old_proc 'AMLInfo_InsertAndUpdate'   
GO
create proc dbo.AMLInfo_InsertAndUpdate
@Mode						int, -- 0 for insert , 1 for update AML Data , 2 for update Rim Data
@ReferenceNumber			ReferenceNumber		= NULL,
@IsPersonal					bit					= NULL,
@ClientName					varchar(80)			= NULL,
@TelephoneNumber			varchar(20)			= NULL,
@PlaceOfBirth				char(5)				= NULL,
@DateOfBirth				datetime			= NULL,
@Nationality				int					= NULL,
@CountryOfIncorporation		char(5)				= NULL,
@Country					char(5)				= NULL,
@PostalCode					varchar(10)			= NULL,
@AddressLine1				varchar(40)			= NULL,
@AddressLine2				varchar(40)			= NULL,
@Governorate				int					= NULL,
@IDType						int					= NULL,
@IDNumber					varchar(25)			= NULL,
@IssueDate					datetime			= NULL,
@ExpirationDate				datetime			= NULL,
@CountryOfIssuance			char(5)				= NULL,
@DateOfUpdate				datetime			= NULL,
@AMLReferenceID				varchar(16)			= NULL,
@RiskRating					varchar(20)			= NULL,
@OpeningStatus				varchar(40)			= NULL,
@RimCreated					bit					= NULL,
@CardReaderLogId			int					= NULL,
@TransactionType			TransactionName		= NULL,
@ResidencyStatus			varchar(20)			= NULL,
@RimClass					int					= NULL,
@RimNumber					varchar(max)		= NULL,
@AccountNumber				varchar(max)		= NULL,
@AccountType				varchar(max)		= NULL,
@Occupation					int					= NULL,
@IsPEP						bit					= NULL,
@NationalityCode			varchar(100)		= NULL,
@EconomicSector				varchar(max)		= NULL,
@BusinessDomain				char(1)				= NULL,
@ProductAndSerivce			varchar(100)		= NULL,
@RequestID					varchar(max)		= NULL,
@Branch						varchar(100)		= NULL,
@UserName					varchar(100)		= NULL,
@RequestDate				DateTime			= NULL,
@Cahnnel					varchar(50)			= NULL,
@OwnerShip					varchar(100)		= NULL,
@CivilIDFormat				varchar(max)		= NULL,
@CivilID					varchar(max)		= NULL,
@RIMStatus					varchar(max)		= NULL,
@EmployeeID					varchar(max)		= NULL,
@EmployeeName				varchar(max)		= NULL
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[11/05/2020]		
	Reason		:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
	Description	:	Insert and Update table AML_Info

	Devolper	:	Ahmed Osman
	Date		:	[19/05/2021]		
	Reason		:	Enh GFSY00849 - BARWA - ACM19131- KYC Enhancement
	Description	:	Add columns [BranchName,UserName,RequestDate,Cahnnel,OwnerShip,CivilIDFormat,CivilID,RIMStatus,EmployeeID,EmployeeName] to insert and update statment
*/     

IF @Mode = 0
	BEGIN
		IF NOT EXISTS(SELECT * FROM AML_Info WHERE ReferenceNumber = @ReferenceNumber)
			BEGIN
				Insert Into AML_Info(ReferenceNumber,IsPersonal,ClientName,TelephoneNumber,PlaceOfBirth,DateOfBirth,Nationality,CountryOfIncorporation,Country,PostalCode,AddressLine1,AddressLine2,Governorate,IDType,IDNumber,IssueDate,ExpirationDate,CountryOfIssuance,DateOfUpdate,AMLReferenceID,RiskRating,OpeningStatus,RimCreated,CardReaderLogId,TransactionType,ResidencyStatus,RimClass,RimNumber,AccountNumber,AccountType,Occupation,IsPEP,NationalityCode,EconomicSector,BusinessDomain,ProductAndSerivce,RequestID,Branch,UserName,RequestDate,Cahnnel,OwnerShip,CivilIDFormat,CivilID,RIMStatus,EmployeeID,EmployeeName)
				Values (@ReferenceNumber,@IsPersonal,@ClientName,@TelephoneNumber,@PlaceOfBirth,@DateOfBirth,@Nationality,@CountryOfIncorporation,@Country,@PostalCode,@AddressLine1,@AddressLine2,@Governorate,@IDType,@IDNumber,@IssueDate,@ExpirationDate,@CountryOfIssuance,@DateOfUpdate,@AMLReferenceID,@RiskRating,@OpeningStatus,@RimCreated,@CardReaderLogId,@TransactionType,@ResidencyStatus,@RimClass,@RimNumber,@AccountNumber,@AccountType,@Occupation,@IsPEP,@NationalityCode,@EconomicSector,@BusinessDomain,@ProductAndSerivce,@RequestID,@Branch,@UserName,@RequestDate,@Cahnnel,@OwnerShip,@CivilIDFormat,@CivilID,@RIMStatus,@EmployeeID,@EmployeeName)
			END		
	END
ELSE IF @Mode = 1
	BEGIN
		UPDATE AML_Info
			SET 
				AMLReferenceID	= CASE WHEN @AMLReferenceID IS NULL THEN AMLReferenceID ELSE @AMLReferenceID END   
				,RiskRating		= CASE WHEN @RiskRating IS NULL THEN RiskRating ELSE @RiskRating END 
				,OpeningStatus	= CASE WHEN @OpeningStatus IS NULL THEN OpeningStatus ELSE @OpeningStatus END 
				,RimCreated		= CASE WHEN @RimCreated IS NULL THEN RimCreated ELSE @RimCreated END 
				,RimNumber		= CASE WHEN @RimNumber IS NULL THEN RimNumber ELSE @RimNumber END  
				,AccountNumber	= CASE WHEN @AccountNumber IS NULL THEN AccountNumber ELSE @AccountNumber END  
				,AccountType	= CASE WHEN @AccountType IS NULL THEN AccountType ELSE @AccountType END  
				WHERE RequestID	= @RequestID
	END

IF(@@error<>0)            
     BEGIN            
		RETURN -1          
     END  
ELSE          
     BEGIN              
		RETURN 1     
     END            
GO

PRINT 'End... Script for CR# GFSY00793 Proc Script - dbo.AMLInfo_InsertAndUpdate'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[20/01/2021]		
--Reason	:	Issue GFSX14415
--=============================

PRINT 'Start. Script for Issue GFSX14415 Proc Script - dbo.CheckIRMessagesStatus'
GO

drop_old_proc 'CheckIRMessagesStatus'
GO
create proc dbo.CheckIRMessagesStatus		
@MessagesRefNo IRMessagesRefNo READONLY,
@PostOrReverse bit
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[20/01/2021]		
	Reason		:	Issue GFSX14415
	Description	:	Check the IR messages status before posting the transaction InwardTransfersHOSwiftProcess
*/          

IF @PostOrReverse = 1 -- post messages
	BEGIN
		IF EXISTS (SELECT * FROM IR JOIN @MessagesRefNo MSGRefNo
								ON IR.MsgRefNo = MSGRefNo.MsgRefNo
								WHERE IR.MsgRefNo = MSGRefNo.MsgRefNo AND StatusID = 8)
			BEGIN
				RETURN 1
			END
		ELSE
			BEGIN
				RETURN 0
			END
	END
ELSE IF @PostOrReverse = 0 -- reverse messages
	BEGIN
		IF EXISTS (SELECT * FROM IR JOIN @MessagesRefNo MSGRefNo
								ON IR.MsgRefNo = MSGRefNo.MsgRefNo
								WHERE IR.MsgRefNo = MSGRefNo.MsgRefNo AND StatusID = 15)
			BEGIN
				RETURN 1
			END
		ELSE
			BEGIN
				RETURN 0
			END
	END
GO

PRINT 'End... Script for Issue GFSX14415 Proc Script - dbo.CheckIRMessagesStatus'
GO
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	[19/05/2021]		
--Reason	:	CR# GFSY00857 
--=============================



drop_old_proc 'dbo.Insert_TT_Remitter'
GO


CREATE Procedure dbo.Insert_TT_Remitter        
@Remitter_Name nvarchar(200),        
@Nationality varchar(10),        
@Purpose varchar(10),        
@Phone_no varchar(12),        
@ID_Type varchar(3),        
@ID_Number varchar(25),        
@Address nvarchar(40)=null,        
@Name  nvarchar(35)=null,        
@Account varchar(35),         
@TT_Crncy CurrencyType,        
@MT202  bit,        
@bank_id int,        
@Pmt_mode varchar(8),        
@Debit_acct_no AccountNumber=null,        
@Debit_acct_Type varchar(3)=null,        
@Address_1 nvarchar(35)=null,        
@Address_2 nvarchar(35)=null,        
@IsCorres bit,        
@Corres_bk varchar(40),  
@Residence int =0,  
@PrintRemitter bit = 0 ,
@GlCurrency currencytype = NULL 
--[Start - 2013/10/23] Mahmoud Kamel - CR#GFSY00290 - Audit Trail
,@Workstation_ID MachineName = Null
--[End - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail
,@updator OperatorID 
--ITS Code Start [Karim Mahmoud - 2016/11/28] ADIB - Adding parameter @Address2 to insert its value into column "Address_2" in table table "TT_Remitter"
	,@Address2	varchar(40)=null
--ITS Code End [Karim Mahmoud - 2016/11/28] ADIB - Adding parameter @Address2 to insert its value into column "Address_2" in table table "TT_Remitter"
As        
        
/*        
CreationDate: 2005-03-23        
OriginalName: dbo.Insert_TT_Remitter        
Programmer: Mahmoud Elkabary        
Description: Insert new Remitter and new Beneficiary for this Remitter        
Output:          
Assumption:         
        
ModifiedDate: 2009-12-28        
Modifer:      Mohamed Gad    
ModifyReason: Changing Phone_no from varchar(10) to be varchar(12)  

ModifiedDate: 2013-03-12          
Modifer:      Mohammed El-Masry      
ModifyReason: Check on Column Debit_Acct_no in case DP Account and check on column GlNumber in case GL Account       

ModifiedDate: 11/11/2013    
Modifer: Mahmoud Kamel
ModifyReason: CR#GFSY00290 - Audit Trail  

ModifiedDate: 2013-12-25         
Modifer: Doaa Nassar    
ModifyReason: Fixing defect# GFSX05830, Add updator to parameters as anonymous inserts are not allowed on audited tables

ModifiedDate:	2016-11-28
Modifer:		Karim Mahmoud
ModifyReason:	ADIB - Adding parameter @Address2 to insert its value into column "Address_2" in table "TT_Remitter"


ModifiedDate:	2021-06-17
Modifer:		Ibrahim Harby
ModifyReason:	GFSY00857 change remitter name to allow 70 char

*/        
        
begin Tran        
set nocount on   

--[Start - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail
select @Workstation_ID = REPLACE(@Workstation_ID,'\DOMAIN\','\')
--[End - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail     
        
declare @y int        
set @y = 0        
while ((select IsInProcess from TableLock Where TableName = 'TT_Remitter') <> 0)        
begin        
 if(@y = 120) return -1 -- timeout        
 set @y = @y + 1        
 waitfor delay '00:00:01'        
end        
        
update TableLock set IsInProcess = 1 Where TableName = 'TT_Remitter'        
         
declare @maxid as numeric    
exec dbo.Next_Table_MaxID 'TT_Remitter','Remitter_NO',@maxid output    
    
Insert Into TT_Remitter(Remitter_NO,      
   Remitter_Name,        
   Nationality,        
   Purpose,        
   Phone_no,        
   ID_Type,        
   ID_Number,        
   Address ,  
   Residence,  
   PrintRemitter
   --[Start - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail   
   ,Workstation_ID
   --[Start - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail
   ,Creator
   ,Updator  
   --ITS Code Start [Karim Mahmoud - 2016/11/28] ADIB - Adding parameter @Address2 to insert its value into column "Address_2" in table "TT_Remitter"
   ,Address_2
   --ITS Code End [Karim Mahmoud - 2016/11/28] ADIB - Adding parameter @Address2 to insert its value into column "Address_2" in table "TT_Remitter" 
   )Values(       
   @maxid ,      
   @Remitter_Name,        
   @Nationality,        
   @Purpose,        
   @Phone_no,        
   @ID_Type,        
   @ID_Number,        
   @Address,  
   @Residence ,  
   @PrintRemitter 
   --[Start - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail   
   ,@Workstation_ID
   --[Start - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail 
   ,@updator
   ,@updator  
   --ITS Code Start [Karim Mahmoud - 2016/11/28] ADIB - Adding parameter @Address2 to insert its value into column "Address_2" in table "TT_Remitter" 
   ,@Address2 
   --ITS Code End [Karim Mahmoud - 2016/11/28] ADIB - Adding parameter @Address2 to insert its value into column "Address_2" in table "TT_Remitter" 
   )        
if (@@error<>0)        
begin        
 rollback tran        
 return -1        
        
end        
declare @Remitter_NO int        
set @Remitter_NO = (select MAX(Remitter_NO) from TT_Remitter)        
 
 if( @Debit_acct_Type ='GL')      
Insert Into TT_Beneficiary(Remitter_NO,        
    Seq,        
    [Name],        
    Account,        
    TT_Crncy,        
    MT202,        
    CorresBankID,        
    Pmt_mode,        
    GLNumber,        
    Debit_acct_Type,        
    Address_1,        
    Address_2,        
    IsCorres,        
    Corres_bk,
    GLCurrency       
    )Values(        
    @Remitter_NO,        
    1,        
    @Name,        
    @Account,        
    @TT_Crncy,        
    @MT202,        
    @bank_id,        
    @Pmt_mode,        
    @Debit_acct_no,        
    @Debit_acct_Type,        
    @Address_1,        
    @Address_2,        
    @IsCorres,        
    @Corres_bk,
    @GlCurrency        
    )         
else 
  Insert Into TT_Beneficiary(Remitter_NO,        
    Seq,        
    [Name],        
    Account,        
    TT_Crncy,        
    MT202,        
    CorresBankID,        
    Pmt_mode,        
    Debit_acct_no,        
    Debit_acct_Type,        
    Address_1,        
    Address_2,        
    IsCorres,        
    Corres_bk        
    )Values(        
    @Remitter_NO,        
    1,        
    @Name,        
    @Account,        
    @TT_Crncy,        
    @MT202,        
    @bank_id,        
    @Pmt_mode,        
    @Debit_acct_no,        
    @Debit_acct_Type,        
    @Address_1,        
    @Address_2,        
    @IsCorres,        
    @Corres_bk        
    )     
if (@@error<>0)        
begin        
 rollback tran        
 return -1        
        
end        
        
update TableLock set IsInProcess = 0 Where TableName = 'TT_Remitter'        
        
if (@@error<>0)        
begin        
 rollback tran        
 return -1        
        
end        
else        
begin        
 commit tran        
 return @Remitter_NO        
end        

GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{19/06/2021}	
--Reason	:	Issue GFSX14603
--====================================================

PRINT 'Start. Script for Proc Script - dbo.ChangeOverrideRequestAndReasons'
GO

drop_old_proc 'ChangeOverrideRequestAndReasons'		
GO
create proc dbo.ChangeOverrideRequestAndReasons			
@RequestID int,
@ReasonIDs ReasonIDsType READONLY,
@LoginID OperatorID,
@SupComments nvarchar(max)
as

CREATE TABLE #ReasonIDs
(
    ReasonID	int,
	reasonLevel int,
	GrpName		nvarchar(max),
	Processed	bit DEFAULT 0
)

INSERT INTO #ReasonIDs (ReasonID, reasonLevel, GrpName) 
	SELECT ReasonID, reasonLevel, GrpName
	FROM @ReasonIDs

DECLARE @Forward int , @AffectedRows int, @NewRequestStatus int, @NewReasonStatus int , @ReasonIDsCount int

SET @Forward = 6   
SELECT @NewReasonStatus = id FROM Status WHERE StatusTypeID IN (SELECT id FROM StatusType WHERE StatusType.Description = 'TLR_OverrideStatus') AND ShortDescription = 'OverridePostedBySupervisor'
SELECT @NewRequestStatus = id FROM Status WHERE StatusTypeID IN (SELECT id FROM StatusType WHERE StatusType.Description = 'TLR_OverrideStatus') AND ShortDescription = 'OverrideAccepted'
Select @ReasonIDsCount = Count(*) From #ReasonIDs

BEGIN TRY
    BEGIN TRANSACTION
		While (Select Count(*) From #ReasonIDs Where Processed = 0) > 0
			BEGIN
				DECLARE @ReasonID int , @reasonLevel int , @GrpName nvarchar(max)
				SELECT Top 1 @ReasonID		= ReasonID		From #ReasonIDs Where Processed = 0 ORDER BY ReasonID ASC
				SELECT Top 1 @reasonLevel	= reasonLevel	From #ReasonIDs Where Processed = 0 ORDER BY ReasonID ASC
				SELECT Top 1 @GrpName		= GrpName		From #ReasonIDs Where Processed = 0 ORDER BY ReasonID ASC

				UPDATE OverrideRequestReasons  WITH (ROWLOCK)      
				SET	Status = @NewReasonStatus,
					SupervisorUserID = @LoginID,        
					SupervisorComments = @SupComments,
					IsProcessing = 0
						WHERE RequestID = @RequestID      
							AND ReasonID = @ReasonID     
							AND GroupName = @GrpName     
							AND Status < @Forward     
							AND Exists(SELECT 1 FROM OverrideRequests as OVR (NOLOCK) WHERE OVR.RequestID = @RequestID AND OVR.Status < @Forward)     
							AND ReasonLevel = @ReasonLevel   
							
				UPDATE #ReasonIDs Set Processed = 1 Where ReasonID = @ReasonID 
			END
		 
		SELECT @AffectedRows = Count(*) FROM OverrideRequestReasons 
											WHERE RequestID = @RequestID 
												AND ReasonID IN (SELECT ReasonID FROM #ReasonIDs)
												AND STATUS = @NewReasonStatus

		IF @AffectedRows = @ReasonIDsCount
			BEGIN
				SET @AffectedRows = 0

				UPDATE OverrideRequests WITH(ROWLOCK)    
					SET Status = @NewRequestStatus
						WHERE  RequestID = @RequestID

				SELECT @AffectedRows = @@RowCount 

				IF @AffectedRows <= 0
					BEGIN
						RAISERROR('Update table OverrideRequests failed ',0,1)
					END
				ELSE
					BEGIN
						UPDATE OverrideRequestReasons SET IsProcessing = 0 WHERE RequestID = @RequestID

						SELECT @AffectedRows = @@RowCount 

						DECLARE @OverrideRequestReasonCount int
						SELECT @OverrideRequestReasonCount = COUNT(*) FROM OverrideRequestReasons WHERE RequestID = @RequestID

						IF @AffectedRows <> @OverrideRequestReasonCount
							BEGIN
								RAISERROR('Update table OverrideRequestReasons failed ',0,1)
							END
					END
			END
		ElSE
			BEGIN
				RAISERROR('Update table OverrideRequestReasons failed ',0,1)
			END
		
    COMMIT TRAN -- Transaction Success!

	RETURN 1
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRAN --RollBack in case of Error
	RETURN 0
END CATCH

If(OBJECT_ID('tempdb..#ReasonIDs') Is Not Null)
	Begin
	    Drop Table #ReasonIDs
	END
GO

PRINT 'End... Script for Issue GFSX14603 Proc Script - dbo.ChangeOverrideRequestAndReasons'
GO
--==================================================================================================================================================================
Go
drop_old_proc 'dbo.InsertOrUpdateIDInfoLog'
GO
drop_old_proc 'dbo.InsertIDInfoLog'
Go
create Proc dbo.InsertOrUpdateIDInfoLog  
@ReaderName [dbo].[reader_device_class] ,  
@TranName [dbo].[TransactionName],  
@TranReferenceNo [dbo].[ReferenceNumber] ,  
@TranDate [datetime],  
@IDInfo [xml], 
@RowId int
As  
/*   
CreationDate: 2017-Dec-12    
OriginalName: dbo.InsertIDInfoLog   
Programmer: Nada Elshafie       
Description: Get Card Data From Card Reader And Insert It Into Table IDInfoLog

CreationDate: 2021-March-12    
OriginalName: dbo.InsertIDInfoLog   
Name: dbo.InsertOrUpdateIDInfoLog   
Programmer: Ahmed Eliwa       
Description: Handle issue GFSX14475 - cancel tran validation error     
*/  
Begin  
if @RowId > 0
Begin
	if Exists (select * from IDInfoLog where id = @RowId)
	BEGIN
		Update IDInfoLog set TranReferenceNo = @TranReferenceNo where id = @RowId
	END
END
else
Begin
	Declare @ID int  
	select @ID=coalesce(max(ID),0)+1 from IDInfoLog  
	INSERT Into IDInfoLog  
	(ID,  
	ReaderName,  
	TranName,  
	TranReferenceNo,  
	TranDate,  
	IDInfo)  
	values  
	(@ID,  
	@ReaderName,  
	@TranName,  
	@TranReferenceNo,  
	@TranDate,  
	@IDInfo)
END
return @ID  
End  
GO
drop_old_proc 'Select_ExternalWSbyParamList'
GO
CREATE PROC dbo.Select_ExternalWSbyParamList  
@TranName    TransactionName,  
@WebServiceMapName  varchar(100),  
@WebMethodMapName  varchar(100),  
@ParamListName   varchar(100)=null  
AS  
/*  
Developer: Adel Shaban  
Creation Date: 10/11/2009  
Description: To Select information related to parameter list of External WebMethod  
  
  
Developer: Osama Orabi  
Creation Date: 2010-04-13  
Description: To Pass the @webServiceMapName and @WebMethodMapName from the code instead of @WebService and @WebMethod  
  
Developer: Osama Orabi  
Creation Date: 2010-05-03  
Description: Compare the @webServiceMapName and @WebMethodMapName using lower character  

Developer: Asmaa Hafez  
Modify Date: 15-03-2016  
Description: Add XSD to select -GFSY00558 
 
Developer: Nada Elshafie  
Modify Date: 06Feb2018  
Description: GFSY00670 - return a record if the TranID=-1 so only one record is needed for a service comon for all transactions
 
Developer: Ahmed Eliwa  
Modify Date: 09-03-2021  
Description: GFSY00832 - CBD EIDA biometric intigration
 
*/  
IF(ltrim(rtrim(@ParamListName))='')  
BEGIN  
 SET @ParamListName=NULL  
END  
  
DECLARE @TranID int  
SELECT @TranID =TranID  
 FROM RulesTranName  
 WHERE TransactionName like @TranName  
  
SELECT WbSrvc.URL,  
  WbSrvcTranParam.ParamName,  
  WbSrvcTranParam.ParamType,  
  WbSrvcTranParam.ParamOrder,  
  WbSrvcTranParam.ParamValue,  
  WbSrvcTranParam.IsInput,  
  WbSrvcTran.WebServiceName,  
  WbSrvcTran.Methods,
  --[Ahmed Eliwa] Begin CR: GFSY00832  {09/03/2021}
  WbSrvcTran.HttpMethod,
  WbSrvcTran.ContentType,
  --[Ahmed Eliwa] END CR: GFSY00832  {09/03/2021}
  --[Begin] :Nada Elshafie -20-10-2014 -GFSY00409
  WbSrvc.Servicetype ,

  --[End] :Nada Elshafie -20-10-2014 -GFSY00409    
  --[Begin] :Asmaa Hafez -15-03-2016 -GFSY00558
    WbSrvcTranParam.XSD 
  --[End] :Asmaa Hafez -15-03-2016 -GFSY00558
 FROM ExternalWebServiceTranParamLst WbSrvcTranParam  
 INNER JOIN ExternalWebServiceTran WbSrvcTran   
  ON WbSrvcTranParam.WSTranMethodID = WbSrvcTran.ID  
 INNER JOIN ExternalWebService WbSrvc  
  ON lower(WbSrvc.WebServiceName)  = lower(WbSrvcTran.WebServiceName)  
 WHERE (WbSrvcTran.TranID=@TranID   or WbSrvcTran.TranID=-1)
  -- AND WbSrvcTran.WebServiceName  = @WebService   
  -- AND WbSrvcTran.Methods    = @WebMethod   
  AND lower(WbSrvc.WebServiceMapName)   = lower(@WebServiceMapName)  
  AND lower(WbSrvcTran.MethodsMapName)  = lower(@WebMethodMapName)  
  AND ((@ParamListName is null and ParamListName is null) or (ParamListName like @ParamListName))  
ORDER BY WbSrvcTranParam.ParamOrder  


GO
