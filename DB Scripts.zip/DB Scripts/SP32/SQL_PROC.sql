drop_old_proc 'UpdateAutoDebit'
go
CREATE proc  UpdateAutoDebit  -- UpdateAutoDebit 1538,1 ,'2018-08-15 00:00:00'
 @userid int ,      
 @branch  int ,      
 @Created datetime      
        
as        

/*        
	CreationDate: 2012-05-07       
	Programmer:  osama nabil       
	Description: update AutoDebit table which accessed by pkg_AutoDebit       
	Output:              
	  
	Modifier : Mahmoud Kamel
	Date    : 22/10/2017
	Reason  : Issue#GFSX12468 - Customize this code as per bank business, so any bank can change the lines between this Issue#GFSX12468

	Modifier: 2018/10/03
	Programmer:  Rokaia Kadry    
	Description:  DrAmount division 1000 will get this value from fld param as setup for each bank 

*/      
begin        
declare  @DividedNumber  int     
  
select @DividedNumber = convert(int,value)
from dbo.RulesTranFldParam
Where TranName = 'InwardClearingMultiple' 
And FieldName = 'AmountDivision' 
And Param = 'AmountDividedNumber'

 Update a        
 set a.UserId  = @userid,        
  a.Branch  = @branch,        
  a.Created  = @Created,
  a.DrAccountNo  = Right(ShortAccountNo,12),
  a.DrAmount  = cast(amount as decimal) /@DividedNumber,
   /* 
  --ITS Code Start [Mahmoud Kamel - 22/10/2017] Issue#GFSX12468 - Customize this code as per bank business
  a.DrAmount  = cast(amount as decimal) /1000,
  /* This Code to be Used by KFHM - Comment above 2 lines and uncomment below 2 lines 
  a.DrAmount  = cast(amount as decimal) /100,
  */
  --ITS Code End [Mahmoud Kamel - 22/10/2017] Issue#GFSX12468 - Customize this code as per bank business
    */
    a.ChequeNo  = cast(DocumentNo as decimal(21)),
    a.Sender_Bank_Name = ( select ClearBankName        
        from clearbank        
        where  cast(a.Sender_Bank as int)  =  cast(ClearBankCode as int))         
 from AutoDebit as a        
end   
Go

--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc TLR_OV_UpdateReasonStatus
Go

CREATE PROCEDURE dbo.TLR_OV_UpdateReasonStatus      
 @UserNum int  ,      
 @ReqID  int  ,      
 @ReasonID int  ,      
 @GrpName RoleName ,      
 @SupID  OperatorID ,      
 @Status  int  ,      
 @SupComment nvarchar(500) ,      
 @CurrFwdGrp RoleName ,      
 @ReasonLevel int,
 @UpdateAll bit=0         
AS      
/*      
CreationDate: 21/6/2007      
OriginalName: dbo.TLR_OV_UpdateReasonStatus      
Programmer: Ahmed Rafat      
Description: update override reason status in HO DB      
Output:        
Assumption:       
      
ModifiedDate: 21/08/2008       
Programmer:  Osama Orabi      
Reason:  Adding ReasonLevel to Primary Key of OverrideRequestReasons      
   Retrieving Date from OverrideRequestReasons by ReqID,ReasonID,GrpName,ReasonLevel      
    
Modification Date: 6/4/2009    
Developer: Adel Shaban    
Reason: Enhancing Performance for logon Operation by preventing inserting all roles    
  
Modifier: Osama Orabi  
Date : 2010-03-23  
Reason : Performance Tuning   

Modifier: Adel Shaban
Date:     20/12/2010
Reason:   Ignoring All levels where no Supervisor online 

Modified By	: Osama Orabi
Date		: 2011-07-18
Reason		: Migrate from UBS3 to G8  

Modified By	: Osama Nabil
Date		: 2013-04-07
Reason		: change @SupComment datatype to be nvarchar 

Modified By	: Osama Nabil
Date		: 2015-02-18
Reason		: Adding parameter @UpdateAll CR#GFSY00461

Modified By	: Rokaia Kadry
Date		: 2018-18-10
Reason		: update all reasons when @UpdateAll=1
Issue		: GFSX13315
*/      
      
--Notes      
-------      
/*      
if status has not been updated yet ( status value < forward status value)      
 this means it's the first update and  so update table without conditions      
else if its status is forward this means that it may be a new update or a not cancelled old request      
 so check if user is in the new forward group (he has permissions to update as a member of new group)      
 -in case he received new request or not as it'll be sent for him in the forward group-      
 so update the request      
else this means it's already accepted or rejected and no way to reUpdate the reason      
or the supervisor tries to update after the request is forwarded by another supervisor.      
*/      
      
-- Declarations      
---------------      
declare       
 @Forward int  ,      
 @CurStatus int ,      
 @ActionID int  ,  
 @AffectedRows int    
      
-- status select * from Status where StatusTypeID = 28      
set @Forward = 6       
      
-- reset action id - if new status is forward      
-- select * from Status where StatusTypeID = 27 "AcceptRejectForward"      
set @ActionID = 2      
      
select @CurStatus = Status   
 from OverrideRequestReasons    (NOLOCK)  
 where RequestID = @ReqID    
  and ReasonID = @ReasonID   
  and GroupName = @GrpName   
  and ReasonLevel =  @ReasonLevel      
  
IF(@CurStatus < @Forward )      
BEGIN   
 SET NOCOUNT OFF  
     
 UPDATE OverrideRequestReasons  WITH (ROWLOCK)    
 SET SupervisorUserID = @SupID   ,      
  Status   = @Status   ,      
  SupervisorComments = @SupComment  ,      
  ActionID  = case @CurrFwdGrp when '' then ActionID else @ActionID end ,      
  CurrentForwardGroup = case @CurrFwdGrp when '' then Null else @CurrFwdGrp end       
 WHERE RequestID  = @ReqID    
 AND ReasonID  = @ReasonID   
 AND GroupName  = @GrpName   
 AND Status   < @Forward   
 AND  
   -- check that the request not sent to teller (rejected or timed out)      
   -- in these cases some reasons may be still valid but all request cycle finished      
   Exists( SELECT 1 -- *  
   FROM OverrideRequests as OVR  (NOLOCK)    
   WHERE OVR.RequestID = @ReqID      
    AND OVR.Status < @Forward )   
 AND ReasonLevel  = @ReasonLevel      
  
 SELECT @AffectedRows = @@RowCount      

-- Start Adel Shaban [Ignoring All levels where no Supervisor online]
if(@Status = @Forward and @AffectedRows > 0)
Begin

Declare @Level int
Declare @NoOfLevelRowsEmpty int
Declare @NoOfLevelRows int

Set @Level = @ReasonLevel

	Select @Level = min(ReasonLevel)
	from OverrideRequestReasons (NOLock)
	where RequestID = @ReqID and ReasonID = @ReasonID and @Level < ReasonLevel

	while(@Level is not NULL)
	Begin
	
		if(exists(select 1 from OverrideRequestReasons (NoLock)
							where	RequestID = @ReqID 
								and ReasonID = @ReasonID 
								and ReasonLevel = @Level
								AND WaitLoggedOffUsers = 0))						
		Begin


			Select @NoOfLevelRowsEmpty = count(ReasonID)
			From OverrideRequestReasons  res (NoLock)
			Inner join OverrideRequests req (NoLock)
			on Req.RequestID = Res.RequestID
			Where res.RequestID = @ReqID and ReasonID = @ReasonID and ReasonLevel = @Level							
							AND	
							(	
								(
									IsUser = 1 AND NOT EXISTS (SELECT 1 FROM V_Operator op
															 INNER JOIN TellerConfig
																	ON op.user_number = TellerConfig.[User_ID]
 															WHERE op.LoginID = res.GroupName 												
																AND SignedOnAt <> ''
																AND (op.Branch	= res.TargetBranch	OR	res.TargetBranch = 0)
																AND ((	IsFilterByDepartment = 0)
																		OR (
																			IsFilterByDepartment = 1 
																			AND (res.UserDepartmentID =  TellerConfig.DepartmentID or res.UserDepartmentID is null)
																			)
																	)
																AND op.user_number <> req.user_number
																AND InLockWhenClose = 0
															)
								)		-- the supervisor is logged-off
							
								OR 
								(
									IsUser = 0 AND NOT EXISTS (SELECT 1 FROM V_OperatorRoles opR
																INNER JOIN V_Operator op
																	ON opR.u# = op.user_number
																	AND SignedOnAt <> ''
																INNER JOIN TellerConfig
																	ON op.user_number = TellerConfig.[User_ID]
																WHERE opR.[RoleName] = res.GroupName
																	AND (op.Branch	= res.TargetBranch	OR	res.TargetBranch = 0)
																	AND ((	IsFilterByDepartment = 0)
																		OR (
																			IsFilterByDepartment = 1 
																			AND (res.UserDepartmentID =  TellerConfig.DepartmentID or res.UserDepartmentID is null)
																			)
																		)
																	AND op.user_number <> req.user_number
																	AND InLockWhenClose = 0
																)-- and all users are LoggedOff
								)
							)

			Select @NoOfLevelRows = Count(ReasonID)
			From OverrideRequestReasons (NoLock)
			Where RequestID = @ReqID and ReasonID = @ReasonID and ReasonLevel = @Level             

			if(@NoOfLevelRows = @NoOfLevelRowsEmpty and @NoOfLevelRows > 0)
			Begin

				Update OverrideRequestReasons with (RowLock)
				set Status = @Forward
				Where RequestID = @ReqID and ReasonID = @ReasonID and ReasonLevel = @Level

				Select @Level = min(ReasonLevel)
				from OverrideRequestReasons (NOLock)
				where RequestID = @ReqID and ReasonID = @ReasonID and @Level < ReasonLevel			
				
			End 
			Else
			Begin
				set @Level = NULL -- To exist loop
			End
		
		End -- End of checking that this level Not Wait for Logged Off supervisors
		Else
		Begin
				set @Level = NULL -- To exist loop
		End
		
	End -- End of  while(@Level is not NULL)

End 
-- End Adel Shaban [Ignoring All levels where no Supervisor online]
  
 EXEC dbo.TLR_OV_CheckFinishedReasons @ReqID, @Status --,@UpdateAll 
 
 SET NOCOUNT ON  
  
 END      
/*  
else if exists(      
  select * from OperatorSession  os    
  inner join OperatorRoles ORoles    
  on os.User_Number=ORoles.User_Number and lower(os.role)='gfsoperators'    
  where os.User_Number = @UserNum and      
   oRoles.Role in      
   (select CurrentForwardGroup from OverrideRequestReasons       
    where RequestID = @ReqID  and      
    ReasonID = @ReasonID and      
    GroupName = @GrpName and      
    ReasonLevel = @ReasonLevel)      
  )      
 Begin      
  update OverrideRequestReasons      
  set      
   SupervisorUserID = @SupID  ,      
   Status   = @Status  ,      
   SupervisorComments = @SupComment ,      
   CurrentForwardGroup = case @CurrFwdGrp when '' then Null      
       else @CurrFwdGrp end       
  where      
  RequestID  = @ReqID  and      
   ReasonID  = @ReasonID and      
   GroupName  = @GrpName and      
   status   = @Forward and      
   -- check that the request not sent to teller (rejected or timed out)      
   -- in these cases some reasons may be still valid but all request cycle finished      
   Exists( select * from OverrideRequests as OVR      
    where OVR.RequestID = @ReqID      
    and OVR.Status < @Forward ) and      
   ReasonLevel  = @ReasonLevel      
 END          
*/  
return @AffectedRows  

Go
--End of Automatic Generation

Drop_old_proc 'TLR_OV_CheckFinishedReasons'
GO
create proc dbo.TLR_OV_CheckFinishedReasons  
@RequestID int,  
@status int 
--,@UpdateAll bit=0   
  
/*  
Modifier: Osama Orabi  
Date : 2010-03-23  
Reason : Performance Tuning  

Modified By	: Osama Nabil
Date		: 2015-02-18
Reason		: update OverrideRequests Status to 8 if @status = 8 and ( @UpdateAll=0 or (@UpdateAll=1 and last reason))

Modified By	: Rokaia Kadry
Date		: 2018-18-10
Reason		: RollBacck UpdateAll which it is not used in case of rejection
Issue		: GFSX13315

*/  
as  
  
SET NOCOUNT ON  
  
declare   
  @approvedReq int,  
  @totalReq int,  
  @CurrentDateTime datetime  
  
 select @CurrentDateTime = getdate()  
  
 if @status = 8 -- rejected reason  
 Begin  
  
 --  IF(@UpdateAll=0)
	--Begin
	  update OverrideRequests WITH (ROWLOCK)  
	  set Status = 8  
	  where RequestID = @RequestID    
	  and Status in (5,6)
	--END
	--ELSE
	--BEGIN
	--	 select @approvedReq = count(distinct(ReasonId))  
	--	 from OverrideRequestReasons (NOLOCK)  
	--	 where RequestID = @RequestID   
	--	  and Status IN(7, 8) 
	--  -- count all requests  
	--  select @totalReq = count(distinct(ReasonId))  
	--  from OverrideRequestReasons (NOLOCK)  
	--  where RequestID = @RequestID   
	
	--  update OverrideRequests WITH (ROWLOCK)  
	--  set Status = 8  
	--  where RequestID = @RequestID   
	--  and @approvedReq = @totalReq  
	--		and Status in (5,6)  
		
	-- END
 End  
  
 Else  
  
 if @status = 7 -- partially approved  
 Begin  
  -- count all approved requests  
  select @approvedReq = count(distinct(ReasonId))  
  from OverrideRequestReasons (NOLOCK)  
  where RequestID = @RequestID   
   and Status = 7 -- approved  
  -- count all requests  
  select @totalReq = count(distinct(ReasonId))  
  from OverrideRequestReasons (NOLOCK)  
  where RequestID = @RequestID   
  -- update all request as partially approced  
  update OverrideRequests WITH (ROWLOCK)  
  set Status = 7  
  where RequestID = @RequestID   
  and @approvedReq = @totalReq  
        and Status in (5,6)  
        
  update OverrideRequests WITH (ROWLOCK)  
  set SendTimeStamp=@CurrentDateTime  
  where RequestID=@RequestID  
 End  
  
 Else  
  
  if(@Status=6) -- Forward  
 Begin  
  update OverrideRequests WITH (ROWLOCK)  
  set SendTimeStamp=@CurrentDateTime   
  where RequestID=@RequestID  
  and Status in (5,6)  
 End  
  
  exec TLR_OV_UpdateIsProcessing @RequestID  

GO

--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc ChequeRepeatedValidation
Go

CREATE  PROCEDURE [dbo].[ChequeRepeatedValidation]                  
@ChequeNumber decimal,            
@DrawerAccNumber varchar(20),         
@ClearBankBranch int ,              
@Status int,
@DrAccNumber varchar(20) = null                
AS            
 /*        
Created by : Mohammed El-Masry         
Creation date : 15-11-2008        
reason : Check that cheque data is repeated or not      
 
Modifyed by : osama nabil    
Creation date : 14-10-2018          
reason : add check for DrAccount to use in transfer mode and allow the rest of paramters to accept null  
		 allow repeated cheques with status in (2,7,8)	  
 
*/      
set nocount on           

select count(dcd.chequeno) from discchequesdetail dcd
where dcd.chequeno = @ChequeNumber
and (dcd.draweeacctno = @DrawerAccNumber or @DrawerAccNumber IS NULL OR @DrawerAccNumber='' )
and (dcd.clearbankbranchid=@ClearBankBranch OR @ClearBankBranch IS NULL )
and (dcd.DrAccount=@DrAccNumber or @DrAccNumber IS NULL OR @DrAccNumber='')
and dcd.chequestatus NOT IN (2,7,8) --@status



Go
--End of Automatic Generation
Drop_old_proc Check_ad_gb_corres_bks   
Go
CREATE  Procedure Check_ad_gb_corres_bks  --Check_ad_gb_corres_bks 'hsbcbank'
@swift_code varchar(40)=null           
AS            
/*            
CreationDate : 2018-10-25           
OriginalName : dbo.Check_ad_gb_corres_bks       
Programmer :nehal.ramadan           
Description : Select Corres. @swift_code           
Output:              
Assumption:             
              
*/                   
set nocount off            
select ad_gb.swift_code as swift_code
from ad_gb_corres_bks as ad_gb
where ad_gb.status='Active' and ad_gb.swift_code= @swift_code 

    
Go
--End of Automatic Generation
DROP_OLD_PROC 'GetCommitmentDrawer'
GO
CREATE PROCEDURE dbo.GetCommitmentDrawer     
@CommitmentNo nvarchar(12),    
@RimNo int,    
@Currency char(3)    
AS    
BEGIN    
/*    
Developer: Mohamed Elabd    
Date:      18-October-2018    
Reason:    Get list of Drawers for Commitment - CR# GFSY00732   
*/      
    
SELECT    
D.DrawerID,    
D.DrawerName,    
CD.DrawerLimit,    
CD.DrawerLimitInAmount,    
CD.ExpiryDate,    
CD.UtilizedLimit,    
CD.AvailableLimit,    
CD.FOLReferenceNo,    
CD.FOLDate,    
CD.Remark,    
CD.Status,
D.PastDue  
FROM CommitmentDrawer CD    
INNER JOIN Drawer D    
ON D.DrawerID = CD.DrawerID    
WHERE CD.CommitmentNo = @CommitmentNo    
AND CD.RimNo = @RimNo    
AND CD.Currency = @Currency  
AND CD.Status = 'Active'     
    
END 
GO
drop_old_proc 'INSERT_DISCOUNT_CHEQUES_DETAIL'
GO  
create PROCEDURE dbo.INSERT_DISCOUNT_CHEQUES_DETAIL                  
 @CHEQUESSTRING   NVarchar(Max),--NTEXT,                                 
 @TRACKINGNUMBER  CHAR (50),                              
 @USER_NUMBER     INT,                              
 @TRANID  INT = -1                            
                                
AS                                  
/*                                    
CREATIONDATE: 13/6/2007                                   
ORIGINALNAME: DBO.INSERT_DISCOUNT_CHEQUES_DETAIL                                    
PROGRAMMER: MOHAMMED EL-MASRY                                    
DESCRIPTION: INSERT DISCOUNT CHEQUES.                                    
OUTPUT:                                    
ASSUMPTION:                          
               
MODIFIEDDATE: 25-02-2013    
MODIFER:  Aya Mahmoud              
MODIFYREASON:  Retrofit from CBD     
  
MODIFIEDDATE: 12-05-2013    
MODIFER:  Aya Mahmoud              
MODIFYREASON:  Insert the new column DiscountType (0=Fixed, 1=Percent)  & the column unDiscPercent


MODIFIEDDATE: 21-08-2014    
MODIFER:  Mohamed Gad              
MODIFYREASON:  Change the data type of @CHEQUESSTRING from Ntext to NVarchar(Max) as this causes a problem while inserting more than 16 cheques (cheques > 16 are not inserted)

MODIFIEDDATE: 21-05-2015    
MODIFER:  Nada Elshafie              
MODIFYREASON:  Insert the new column Int_Amt

MODIFIEDDATE: 09-06-2015    
MODIFER:  Nada Elshafie              
MODIFYREASON:  Change @DATAROW from VARCHAR to NVARCHAR 

MODIFIEDDATE: 23-08-2015    
MODIFER:  Reem Mandour              
MODIFYREASON:  add term column                     
      

MODIFIEDDATE: 28-09-2015    
MODIFER:  osama nabil             
MODIFYREASON:  Change @CHEQUESGRID.Latefees from decimal(6,2) to decimal(8,4)                    

MODIFIEDDATE: 21-October-2018    
MODIFER:	  Mohamed Elabd             
MODIFYREASON: Add DrawerCode column - CR# GFSY00732
*/                               
-----------------                                    
BEGIN TRANSACTION                                    
-----------------                                
                              
DECLARE @ROWDELIMITER  CHAR(1),                                  
 @COLDELIMITER  CHAR(1),                                  
 @ROWPOS   INT,                                  
 @COLPOS   INT,                                  
 @I   INT,                                  
 @J   INT,                                  
 @DATAROW  NVARCHAR(2000),                                  
 @COLCOUNT  INT,                                  
 @ROWNUMBER  INT ,                            
 @TXNID INT  ,                            
 @USER_NAME VARCHAR(200)                          
                            
                               
-- CREATE  CHEQUES GRID                                  
DECLARE @CHEQUESGRID TABLE (                             
  TXNID  INT  NULL,                             
  REFERENCENUMBER   ReferenceNumber NULL,                              
  CHEQUENUMBER    CHAR (20)NULL,                              
  CHEQUETYPE   INT NULL,                              
  CHEQUEAMOUNT   money   NULL,                              
  CHEQUESTATUS   INT    NULL,                              
  CHEQUEAPPROVEDAMOUNT money   NULL,                            
  INTERESTAMT   DECIMAL(18,6)  NULL,                            
  CHEQUEDATE   DATETIME  NULL,                             
  MATURITYDATE   DATETIME NULL,                             
  SENDDATE   DATETIME NULL,                              
  CORRESBANKID INT   NULL,                            
  CORRESCOUNTRY NVARCHAR(50)  NULL,                            
  CORRESCITY NVARCHAR(50)  NULL,                            
  CLEARCENTER SMALLINT  NULL,                            
  CLEARBANKBRANCHID VARCHAR (50) NULL ,                            
  DESTBANKACCOUNT NVARCHAR(50)  NULL,                            
  DESTBANKADDRESS1 NVARCHAR(100)  NULL,                            
  DESTBANKADDRESS2 NVARCHAR(100)   NULL,                            
  DESTBANKCOUNTRY NVARCHAR(50)  NULL,                            
  DESTBANKDETAILS NVARCHAR(100)  NULL,                            
  DESTBANKINST NVARCHAR(500)  NULL,                            
  DESTBANKNAME NVARCHAR(50) NULL,                            
  DIRECTOPTION SMALLINT  NULL,                            
  DRACCOUNT VARCHAR(60)  NULL,                            
  DRACCOUNTCUR VARCHAR(4)  NULL,                            
  DRACCOUNTTYPE CHAR(3)  NULL,                            
  DRACCOUNTDEPLOAN CHAR(3) NULL,                            
  DRAWEEACCTNO NVARCHAR(60)  NULL,                            
  DRAWEECUSTNAME NVARCHAR(100)  NULL,                            
  DRAWEEBANKID VARCHAR(5)  NULL,                            
  DRAWEEBANKNAME NVARCHAR(50)  NULL,                            
  DRAWEEBRANCHNAME NVARCHAR(50)  NULL,                            
  SHADOWDEPLOAN CHAR (3)  NULL,                            
  SHADOWACCOUNT VARCHAR (60)  NULL,                   
  SHADOWACCOUNTCUR VARCHAR(4)  NULL,                            
  SHADOWACCOUNTTYPE CHAR (3)  NULL,                            
  IBCNUMBER VARCHAR(50) NULL,                            
  ROUTINGNUMBER   VARCHAR(12)  NULL  ,                    
  COMMISSIONAMOUNT money   NULL     ,                       
  COMMISSIONDESCRIPTION varchar(50)   NULL ,              
  IsExceptionCheque bit   NULL     ,                       
  DraweeNumber int  NULL    ,            
  IsCommissionChanged bit Null  ,                    
  IsInterestChanged bit Null  ,        
  LateFees decimal(8,4) null,  
  DiscountType smallint null,
  UnDiscPercent decimal(6,2) null,
  INT_AMT   DECIMAL(21,6)  NULL,
  Term INT NULL,    
  DrawerCode NVARCHAR(50) NULL ) -- Mohamed Elabd [21-October-2018 - CR# GFSY00732]                                     
    
 DECLARE CHEQUES_CURSOR CURSOR FOR SELECT DRAWEEACCTNO,DRAWEEBANKNAME FROM @CHEQUESGRID                         
 DECLARE @DRAWEEACCTNO NVARCHAR(60),                            
 @DRAWEEBANKNAME NVARCHAR(50)                            
                                  
SET @ROWDELIMITER = '|'                                  
SET @COLDELIMITER = '~'                      
SET @I = 1                                  
SET @ROWPOS = CHARINDEX(@ROWDELIMITER, @CHEQUESSTRING, @I)                                  
SET @COLPOS = 0                                  
SET @COLCOUNT = 0                                  
SET @ROWNUMBER = 0                                  
SELECT @TXNID = MAX(TXNID) FROM DISCCHEQUESDETAIL                            
IF(@TXNID IS NULL)                            
 BEGIN                            
  SET @TXNID = 1                            
 END                                
ELSE                             
 BEGIN                            
  SET @TXNID = @TXNID + 1                            
 END                            
WHILE (@ROWPOS > 0)                                  
BEGIN                                  
 SET @J = 1                                  
 SET @DATAROW = SUBSTRING(@CHEQUESSTRING, @I, @ROWPOS-@I)                                  
 SET @COLPOS = CHARINDEX(@COLDELIMITER, @DATAROW, @J)                                  
 INSERT INTO @CHEQUESGRID                                   
                                   
 SELECT NULL, NULL, NULL, NULL, NULL,NULL,                                  
 NULL, NULL, NULL, NULL, NULL,NULL,                                  
   NULL, NULL, NULL, NULL, NULL,NULL,                               
  NULL, NULL, NULL, NULL, NULL,NULL,                              
NULL, NULL, NULL, NULL, NULL,NULL,                              
NULL, NULL, NULL, NULL, NULL,NULL,                    
NULL,NULL,NULL,NULL ,NULL ,null,null  , null              
,null , null , null, null,null,NULL,null      
                                  
SET @COLCOUNT = 0                                  
 SET @ROWNUMBER = @ROWNUMBER + 1                                   
                                  
 WHILE (@COLPOS > 0)                                  
 BEGIN                                  
                    
  SET @COLCOUNT = @COLCOUNT + 1                                  
                           
  IF (@COLCOUNT = 1)                                  
   BEGIN                                
    UPDATE @CHEQUESGRID SET TXNID   = @TXNID WHERE TXNID IS NULL                       
 UPDATE @CHEQUESGRID SET REFERENCENUMBER   = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE TXNID =  @TXNID                             
   END                                 
    
  ELSE IF (@COLCOUNT = 2)                                  
   BEGIN                                  
 UPDATE @CHEQUESGRID SET CHEQUENUMBER    = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE TXNID =  @TXNID               
   END                         
    
  ELSE IF (@COLCOUNT = 3)                                  
   BEGIN                                  
 UPDATE @CHEQUESGRID SET CHEQUETYPE    = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE TXNID =  @TXNID                                      
   END                               
    
  ELSE IF (@COLCOUNT = 4)                                    
   BEGIN                                    
 UPDATE @CHEQUESGRID SET CHEQUEAMOUNT    = CAST (SUBSTRING(@DATAROW, @J, @COLPOS-@J) AS MONEY) WHERE TXNID =  @TXNID                                  
   END                              
    
  ELSE IF (@COLCOUNT = 5)                                  
   BEGIN                                  
 UPDATE @CHEQUESGRID SET CHEQUESTATUS    = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE  TXNID =  @TXNID                                      
   END                              
    
  ELSE IF (@COLCOUNT = 6)                                  
   BEGIN                                  
 UPDATE @CHEQUESGRID SET CHEQUEAPPROVEDAMOUNT    = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE  TXNID =  @TXNID                                      
   END                                
    
  ELSE IF (@COLCOUNT =7)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET INTERESTAMT    = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE  TXNID =  @TXNID                                  
   END                       
    
  ELSE IF (@COLCOUNT =8)                                    
   BEGIN                                  
 UPDATE @CHEQUESGRID SET CHEQUEDATE     = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE  TXNID =  @TXNID                                  
   END                                
    
  ELSE IF (@COLCOUNT =9)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET MATURITYDATE     = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE TXNID =  @TXNID                                   
   END                                
    
  ELSE IF (@COLCOUNT = 10)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET SENDDATE     = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE TXNID =  @TXNID                                   
   END                               
    
  ELSE IF (@COLCOUNT = 11 AND @COLPOS  - @J >0)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET CORRESBANKID     = CAST(SUBSTRING(@DATAROW, @J, @COLPOS-@J) AS INT) WHERE TXNID =  @TXNID                                   
   END                               
   
  ELSE IF (@COLCOUNT = 12)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET CORRESCOUNTRY     = SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE TXNID =  @TXNID                                   
   END                              
    
  ELSE IF (@COLCOUNT = 13)                                     
   BEGIN                            
 UPDATE @CHEQUESGRID SET CORRESCITY     =SUBSTRING(@DATAROW, @J, @COLPOS-@J) WHERE TXNID =  @TXNID                                   
   END                              
   
  ELSE IF (@COLCOUNT = 14 AND @COLPOS  - @J >0)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET CLEARCENTER     = CAST(SUBSTRING(@DATAROW, @J, @COLPOS-@J) AS INT) WHERE TXNID =  @TXNID                                   
   END                              
   
  ELSE IF (@COLCOUNT = 15 AND @COLPOS  - @J >0)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET CLEARBANKBRANCHID     = CAST(SUBSTRING(@DATAROW, @J, @COLPOS-@J) AS varchar(5)) WHERE TXNID =  @TXNID                 
   END                              
   
  ELSE IF (@COLCOUNT = 16)                                     
   BEGIN                                
 UPDATE @CHEQUESGRID SET DESTBANKACCOUNT     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                              
  
  ELSE IF (@COLCOUNT = 17)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DESTBANKADDRESS1     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END     
  
  ELSE IF (@COLCOUNT = 18)                  
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DESTBANKADDRESS2     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                              
  
  ELSE IF (@COLCOUNT = 19)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DESTBANKCOUNTRY     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                              
   
  ELSE IF (@COLCOUNT = 20)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DESTBANKDETAILS     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID = @TXNID                                   
   END                              
   
  ELSE IF (@COLCOUNT = 21)                                
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DESTBANKINST     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                             
   
  ELSE IF (@COLCOUNT = 22)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DESTBANKNAME     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                             
   
  ELSE IF (@COLCOUNT = 23 AND @COLPOS  - @J >0)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DIRECTOPTION     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                               
   END                             
   
  ELSE IF (@COLCOUNT = 24)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DRACCOUNT     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                             
   
  ELSE IF (@COLCOUNT = 25)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DRACCOUNTCUR     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 26)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DRACCOUNTTYPE     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 27)                                     
   BEGIN                        
 UPDATE @CHEQUESGRID SET DRACCOUNTDEPLOAN     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 28)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DRAWEEACCTNO     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 29)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DRAWEECUSTNAME     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 30  AND @COLPOS  - @J >0 )                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET DRAWEEBANKID     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END           
  
  ELSE IF (@COLCOUNT = 31)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET DRAWEEBANKNAME     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 32)                                     
   BEGIN                           
 UPDATE @CHEQUESGRID SET DRAWEEBRANCHNAME     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 33)                                     
   BEGIN                                  
 UPDATE @CHEQUESGRID SET SHADOWDEPLOAN     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 34)                                     
   BEGIN                           
    UPDATE @CHEQUESGRID SET SHADOWACCOUNT     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 35)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET SHADOWACCOUNTCUR     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 36)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET SHADOWACCOUNTTYPE     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                
   END                            
  
  ELSE IF (@COLCOUNT = 37)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET IBCNUMBER     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                            
  
  ELSE IF (@COLCOUNT = 38)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET ROUTINGNUMBER     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                           
  
  ELSE IF (@COLCOUNT = 39)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET COMMISSIONAMOUNT     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                           
                    
  ELSE IF (@COLCOUNT = 40)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET COMMISSIONDESCRIPTION     = SUBSTRING(@DATAROW, @J,@COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                      
              
  ELSE IF (@COLCOUNT = 41)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET IsExceptionCheque     = SUBSTRING(@DATAROW, @J, @COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END                  
            
  ELSE IF (@COLCOUNT = 42)                                     
   BEGIN                
    UPDATE @CHEQUESGRID SET DraweeNumber     = CAST(SUBSTRING(@DATAROW, @J, @COLPOS-@J)  AS INT) WHERE TXNID =  @TXNID                                                   
   END                  
            
  ELSE IF (@COLCOUNT = 43)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET IsCommissionChanged     = SUBSTRING(@DATAROW, @J,@COLPOS-@J)  WHERE TXNID =  @TXNID                      
   END                      
        
  ELSE IF (@COLCOUNT = 44)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET IsInterestChanged     = SUBSTRING(@DATAROW, @J,@COLPOS-@J)  WHERE TXNID =  @TXNID                                   
   END          
        
  ELSE IF (@COLCOUNT = 45)                                     
   BEGIN                                  
    UPDATE @CHEQUESGRID SET Latefees     = cast(SUBSTRING(@DATAROW, @J,@COLPOS-@J) as decimal(8,4)) WHERE TXNID =  @TXNID                                   
   END      
     
   ELSE IF (@COLCOUNT = 46)                                     
    BEGIN                                  
     UPDATE @CHEQUESGRID SET DiscountType     = cast(SUBSTRING(@DATAROW, @J,@COLPOS-@J) as smallint) WHERE TXNID =  @TXNID                                   
    END  
    
    ELSE IF (@COLCOUNT = 47)                                     
    BEGIN                                  
     UPDATE @CHEQUESGRID SET UnDiscPercent     = cast(SUBSTRING(@DATAROW, @J,@COLPOS-@J) as decimal(6,2)) WHERE TXNID =  @TXNID                                   
    END
	
	ELSE IF (@COLCOUNT = 48)                                     
    BEGIN                                  
     UPDATE @CHEQUESGRID SET INT_AMT     = cast(SUBSTRING(@DATAROW, @J,@COLPOS-@J) as decimal(21,6)) WHERE TXNID =  @TXNID                                   
    END              
  ELSE IF (@COLCOUNT = 49)                                     
    BEGIN                                  
     UPDATE @CHEQUESGRID SET Term     = cast(SUBSTRING(@DATAROW, @J,@COLPOS-@J) as INT) WHERE TXNID =  @TXNID                                   
    END      
    -- Mohamed Elabd [Start: 21-October-2018 - CR# GFSY00732]   
    ELSE IF (@COLCOUNT = 50)                                           
    BEGIN                                      
     UPDATE @CHEQUESGRID SET DrawerCode     = SUBSTRING(@DATAROW, @J,2000)  WHERE TXNID =  @TXNID                                           
    END  
    -- Mohamed Elabd [End: 21-October-2018 - CR# GFSY00732]   
  SET  @J = @COLPOS + 1                                    
            
  -- GET NEXT COLUMN OR END CURRENT ROW                                     
  IF (@COLCOUNT < 49)                                    
   BEGIN                    
      SET @COLPOS = CHARINDEX(@COLDELIMITER, @DATAROW, @COLPOS+1)                                    
   END                                     
  ELSE IF(@COLCOUNT = 50)                                       
   BEGIN                                    
      SET @COLPOS = 0                                     
   END                                    
                                       
  -- END COLUMNS LOOP                                    
  END                                     
                                                
 SET @I = @ROWPOS + 1                                  
 SET @ROWPOS = CHARINDEX(@ROWDELIMITER, @CHEQUESSTRING, @I+1)                             
 SET @TXNID = @TXNID + 1                                 
END                                  
                        
/*****************************/                               
/* END CREATE AND FILL OF CHEQUES GRID */                               
/*****************************/                                  
-- SELECT * FROM @CHEQUESGRID                             
SELECT @USER_NAME = LOGINID FROM OPERATOR WHERE USER_NUMBER = @USER_NUMBER                            
-- INSERTION OF CHEQUESFORCOLLECTION TABLE DATA                                    
--------------------------------------------------------                        
                      
INSERT INTO DISCCHEQUESDETAIL                              
(                             
TXNID,                            
TRACK_NO,                            
REF_NO,                            
CHEQUENO,                            
CHEQUETYPE,                            
CHEQUEAMOUNT,                            
CHEQUESTATUS,                            
CHEQUEAPPROVEDAMOUNT,                            
INTERESTAMOUNT,                            
CHEQUEDATE,                      
MATURITYDATE,                            
SENDDATE,                            
INSTRUCTION,                            
LOANACCOUNTNUMBER,                            
ISPAIDOFF,                            
CORRESPONDANTBANKID,                            
CORRESPONDENTCOUNTRY,                            
CORRESPONDENTCITY,                            
CLEARCENTER,                            
CLEARBANKBRANCHID,                            
DESTBANKACCOUNT,                            
DESTBANKADDRESS1,                            
DESTBANKADDRESS2,                            
DESTBANKCOUNTRY,                            
DESTBANKDETAILS,                            
DESTBANKINST,                            
DESTBANKNAME,                            
DIRECTOPTION,                            
DRACCOUNT,                            
DRACCOUNTCUR,                            
DRACCOUNTTYPE,                            
DRACCOUNTDEPLOAN,                            
DRAWEEACCTNO,                            
DRAWEECUSTNAME,                            
DRAWEEBANKID,                            
DRAWEEBANKNAME,                            
DRAWEEBRANCHNAME,                            
SHADOWDEPLOAN,                        
SHADOWACCOUNT,                            
SHADOWACCOUNTCUR,                            
SHADOWACCOUNTTYPE,                            
IBCNUMBER,                            
ROUTINGNUMBER,                            
USER_NUMBER,                            
CREATOR,                            
UPDATOR,                    
COMMISSIONAMOUNT,                    
COMMISSIONDESCRIPTION ,              
IsExceptionCheque,              
DraweeNumber,            
IsCommissionChanged   ,        
IsInterestChanged,        
latefees     ,  
DiscountType ,
UnDiscPercent ,
Int_Amt,
Term,
DrawerCode  -- Mohamed Elabd [21-October-2018 - CR# GFSY00732]                   
)                                  
SELECT                              
TXNID,                             
@TRACKINGNUMBER,                              
REFERENCENUMBER ,                             
CHEQUENUMBER,                              
CHEQUETYPE,                             
CHEQUEAMOUNT,                              
CHEQUESTATUS,                             
CHEQUEAPPROVEDAMOUNT,                            
INTERESTAMT,             
CHEQUEDATE,                            
MATURITYDATE,                            
SENDDATE ,                            
'',                            
'',                            
0,                            
CORRESBANKID,                            
CORRESCOUNTRY,                            
CORRESCITY,                            
CLEARCENTER,                            
CLEARBANKBRANCHID,                            
DESTBANKACCOUNT,                            
DESTBANKADDRESS1,                            
DESTBANKADDRESS2,                            
DESTBANKCOUNTRY,                            
DESTBANKDETAILS,                            
DESTBANKINST,                            
DESTBANKNAME,                            
DIRECTOPTION,                            
DRACCOUNT,                          
DRACCOUNTCUR,                            
DRACCOUNTTYPE,                            
DRACCOUNTDEPLOAN,                            
DRAWEEACCTNO,                            
DRAWEECUSTNAME,                            
DRAWEEBANKID,                            
DRAWEEBANKNAME,                            
DRAWEEBRANCHNAME,                            
SHADOWDEPLOAN,                            
SHADOWACCOUNT,                   
SHADOWACCOUNTCUR,                            
SHADOWACCOUNTTYPE,                            
IBCNUMBER,                            
ROUTINGNUMBER,                            
@USER_NUMBER ,                            
@USER_NAME,                            
@USER_NAME  ,                    
COMMISSIONAMOUNT ,                    
COMMISSIONDESCRIPTION   ,              
IsExceptionCheque,              
DraweeNumber  ,            
IsCommissionChanged     ,        
IsInterestChanged,        
latefees       ,  
DiscountType ,
UnDiscPercent ,
INT_AMT,
Term,
DrawerCode  --Mohamed Elabd [21-October-2018 - CR# GFSY00732]  
FROM @CHEQUESGRID                                  
                            
OPEN CHEQUES_CURSOR                       
FETCH NEXT FROM CHEQUES_CURSOR INTO @DRAWEEACCTNO,@DRAWEEBANKNAME                            
                            
WHILE @@FETCH_STATUS = 0                            
BEGIN                            
  EXEC UPDATE_DRAWEE_CHEQUES_COUNT @DRAWEEACCTNO,@DRAWEEBANKNAME,NULL                            
   FETCH NEXT FROM CHEQUES_CURSOR INTO  @DRAWEEACCTNO,@DRAWEEBANKNAME                            
END                            
CLOSE CHEQUES_CURSOR                            
DEALLOCATE CHEQUES_CURSOR                            
                            
--------------------------------------------------------                              
   IF(@@ERROR<> 0)                                    
     BEGIN                                    
                                      
       ROLLBACK TRANSACTION                                     
                            
     END                                    
   ELSE                                    
     BEGIN                                    
                                    
      COMMIT TRANSACTION                              
     END          
go
 
drop_old_proc 'selAccount_Types'
GO
 create  PROCEDURE dbo.selAccount_Types      
@LoanModule char(2) ,    
@Dep_Loan Char(2)= null     
AS      
      
/*      
modifier : hany nasr      
date : 5-5-2008      
reason : performnace tunning      
  
ModifiedDate: 30-6-2009              
Modifer     : Amira Kamel           
ModifyReason: Retrofit proce from CBD To UBS   

ModifiedDate: 21-October-2018  
Modifer     : Mohamed Elabd  
ModifyReason: Select EnableCommitmentDrawers - CR# GFSY00732
*/      
      
set nocount on      
if(@Dep_Loan is null)    
begin    
 select LPM.Acct_Type AS ACCT_TYPE, LPM.Acct_Type + ' ' + LPM.Acct_Description AS DESCRIPTION,
 EnableCommitmentDrawers      
 from dbo.LoanProductMap as LPM      
 where LPM.LoanModule = @LoanModule and RowStatus = 1      
end    
else    
begin    
 select LPM.Acct_Type AS ACCT_TYPE, LPM.Acct_Type + ' ' + LPM.Acct_Description AS DESCRIPTION,
 EnableCommitmentDrawers      
 from dbo.LoanProductMap as LPM      
 where LPM.LoanModule = @LoanModule     
 and Dep_Loan = @Dep_Loan    
 and RowStatus = 1      
end 
Go
Drop_old_proc TLR__UpdateDrawer
Go
CREATE PROCEDURE dbo.TLR__UpdateDrawer
@DrawerID                  VARCHAR(25),
@DrawerName                NVARCHAR(100),
@DrawerCurrency            CHAR(3),
@DrawerExpiryDate          DATE,
@DrawerLimit               float,
@DrawerAmount              decimal(21,6),
@TotalAssignedAmount       decimal(21,6),
@UtilizedLimit             decimal(21,6),
@AvailableLimit            decimal(21,6),
@PastDue                   BIT,
@Remarks                   NVARCHAR(250),
@AvailabiltyOfCBRBStatus   char,
@CommentsOnCBRBStatus      NVARCHAR(30),
@CBRBStatusDate            DATE,
@Status                    char(30),
@DateOfDeactivation        DATE,
@StartDate                 Date,
@Tenor                     int,
@Period                    char(8),
@ModifiedDate              Date 
 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Update table Drawer "LBDDrawer" 
*/
DECLARE @oldStatus nvarchar(30)
SELECT @oldStatus=Status FROM drawer WHERE DrawerID=@DrawerID 
update drawer
SET DrawerName=@DrawerName,Currency=@DrawerCurrency,
ExpiryDate=@DrawerExpiryDate,DrawerLimit=@DrawerLimit,
DrawerAmount=@DrawerAmount,TotalAssignedAmount=@TotalAssignedAmount,
UtilizedLimit=@UtilizedLimit,AvailableLimit=@AvailableLimit,
PastDue=@PastDue,Remarks=@Remarks,
AvailabiltyOfCBRBStatus=@AvailabiltyOfCBRBStatus,
CommentsOnCBRBStatus=@CommentsOnCBRBStatus,
CBRBStatusDate=@CBRBStatusDate,
Status=@Status,DateOfDeactivation=@DateOfDeactivation,
StartDate=@StartDate,Tenor=@Tenor,Period=@Period,
ModifiedDate=@ModifiedDate
WHERE  DrawerID=@DrawerID
	   

	if((@Status='Active' or @oldStatus='Active') and (@Status<>@oldStatus AND @Status<>'Active')) 
		BEGIN
			update CommitmentDrawer SET Status=@Status WHERE DrawerID=@DrawerID AND Status=@oldStatus
		END 
end 
GO       
Drop_old_proc TLR_ActiveLoens
GO
CREATE PROCEDURE dbo.TLR_ActiveLoens 
@DrawerID                 char(25),
@CommitmentNo               VARCHAR(12) = '',
@RimNo                     int =0


 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 1-11-2018
Reason: Get Loens Under Commitment "LBDDrawer" which approved
*/
if(@CommitmentNo<>'')
BEGIN
	 IF EXISTS (SELECT     1

	FROM         DiscCheques INNER JOIN

						  DiscChequesDetail ON DiscCheques.Track_No = DiscChequesDetail.Track_No

	WHERE     (DiscCheques.CommitmentNumber=@CommitmentNo AND DiscChequesDetail.DrawerCode=@DrawerID AND DiscCheques.Rim_No=@RimNo

	AND  DiscChequesDetail.ChequeStatus =1))
		BEGIN
			select 2 AS 'Result'
		END 
	else 
		begin
			select 0 AS 'Result'
		END  
END 
ELSE 
BEGIN 
	IF EXISTS(SELECT 1 FROM DiscChequesDetail WHERE DrawerCode=@DrawerID AND ChequeStatus=1)
		BEGIN
			select 1 AS 'Result'
		END 
	ELSE
	BEGIN 
		SELECT 0 AS 'Result'
	END 
END 




END

go


Drop_old_proc TLR_OperationsTableCMTDRW
GO
Create PROCEDURE dbo.TLR_OperationsTableCMTDRW  
@Mode                   char          ,
@CommitmentNo            NVARCHAR(12)  ,
@DrawerID                VARCHAR(25)   ,
@RimNo                   int           ,
@Currency                char(3)       ,
@DrawerLimit             float         ,
@DrawerLimitInAmount     decimal(21,6) ,
@ExpiryDate              DATE          ,
@UtilizedLimit           decimal(21,6) ,
@AvailableLimit          decimal(21,6) ,
@FOLReferenceNo          NVARCHAR(40)  ,
@FOLDate                 DATE          ,
@Remark                  NVARCHAR(250) ,
@Status                  NVARCHAR(20)  ,
@Tenor                   int           ,
@Period                  char(8)       ,
@StartDate               date          
 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: CRUD Operation on table CommitmentDrawer "LBDDrawer CR" 
*/
DECLARE @TotalAssignedLimit decimal(21,6),
		@OldLimit decimal(21,6),
		@AddedValue decimal(21,6)
if(lower(@Mode)='a')
	BEGIN

		SELECT * FROM CommitmentDrawer 
		INSERT INTO CommitmentDrawer (CommitmentNo,DrawerID,RimNo,Currency,DrawerLimit,DrawerLimitInAmount,ExpiryDate,UtilizedLimit,AvailableLimit,FOLReferenceNo,FOLDate
									,Remark,Status,tenor,period,StartDate)
		VALUES(@CommitmentNo,@DrawerID,@RimNo,@Currency,@DrawerLimit,@DrawerLimitInAmount,@ExpiryDate,@UtilizedLimit,@AvailableLimit,@FOLReferenceNo,@FOLDate
									,@Remark,@Status,@Tenor,@Period,@StartDate)


		select @TotalAssignedLimit= TotalAssignedAmount from Drawer WHERE DrawerID=@DrawerID
		SELECT @TotalAssignedLimit=@TotalAssignedLimit+@DrawerLimitInAmount

		UPDATE Drawer  SET TotalAssignedAmount=@TotalAssignedLimit WHERE DrawerID=@DrawerID
	END
ELSE IF (lower(@Mode)='u')
	BEGIN 

		select @TotalAssignedLimit= TotalAssignedAmount from Drawer WHERE DrawerID=@DrawerID
		SELECT @OldLimit = DrawerLimitInAmount FROM CommitmentDrawer  WHERE CommitmentNo=@CommitmentNo and DrawerID=@DrawerID AND RimNo=@RimNo
		if(@OldLimit <> @DrawerLimitInAmount)
			BEGIN 
				SELECT @AddedValue=@DrawerLimitInAmount-@OldLimit
				select @TotalAssignedLimit=@TotalAssignedLimit+@AddedValue
				UPDATE Drawer  SET TotalAssignedAmount=@TotalAssignedLimit WHERE DrawerID=@DrawerID
			END 


		UPDATE CommitmentDrawer SET CommitmentNo=@CommitmentNo, DrawerID=@DrawerID,
		RimNo=@RimNo,Currency=@Currency,DrawerLimit=@DrawerLimit,DrawerLimitInAmount=@DrawerLimitInAmount,
		ExpiryDate=@ExpiryDate,UtilizedLimit=@UtilizedLimit,AvailableLimit=@AvailableLimit,
		FOLReferenceNo=@FOLReferenceNo,FOLDate=@FOLDate,Remark=@Remark,Status=@Status,Tenor=@Tenor,
		Period=@Period,StartDate=@StartDate
		WHERE CommitmentNo=@CommitmentNo and DrawerID=@DrawerID AND RimNo=@RimNo
	END 
else if(lower(@Mode)='d')
	begin
		SELECT @AddedValue = DrawerLimitInAmount FROM CommitmentDrawer  WHERE CommitmentNo=@CommitmentNo and DrawerID=@DrawerID
		select @TotalAssignedLimit= TotalAssignedAmount from Drawer WHERE DrawerID=@DrawerID
		SELECT @TotalAssignedLimit=@TotalAssignedLimit-@AddedValue
		UPDATE Drawer  SET TotalAssignedAmount=@TotalAssignedLimit WHERE DrawerID=@DrawerID

		delete FROM CommitmentDrawer WHERE CommitmentNo=@CommitmentNo and DrawerID=@DrawerID 
	 
	END 

END


GO
Drop_old_proc TLR_DeleteDrawer
Go
CREATE PROCEDURE dbo.TLR_DeleteDrawer
@DrawerID                 char(8)

 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Delete from  table Drawer "LBDDrawer" 
*/

DELETE FROM Drawer WHERE DrawerID=@DrawerID

END
go
Drop_old_proc TLR_GetCommitmentsUnderDrawer
GO
CREATE PROCEDURE dbo.TLR_GetCommitmentsUnderDrawer  --dbo.TLR_GetCommitmentsUnderDrawer 'ssss0001',1025
@DrawerID                 char(25),
@LCID					  int= 1033 




 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Search table Drawer "LBDDrawer" 
*/
DECLARE @PeriodStatus nvarchar(25)
SELECT @PeriodStatus=CASE @LCID

		WHEN 1033 THEN RulesDescriptor.Descriptor

		ELSE RDL.LocalDescription

		END
 from CommitmentDrawer  cd
 LEFT JOIN
 PickList_Entries pe2 ON pe2.PickListID =529
 AND pe2.[Value] =cd.Period
 LEFT JOIN 
 RulesDescriptor ON (pe2.DescriptorName=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CI_AS )
 LEFT JOIN 
 dbo.RulesDescriptorLocal RDL ON RulesDescriptor.DescriptorID =RDL.DescriptorID and RDL.LCID=@LCID
 where cd.DrawerID = @DrawerID 


SELECT CommitmentNo,DrawerID,RimNo,Currency,DrawerLimit,DrawerLimitInAmount,ExpiryDate,UtilizedLimit,AvailableLimit,FOLReferenceNo
,FOLDate,Remark,Status,Tenor,Period,StartDate
,@PeriodStatus AS PeriodDescriptor,StatusDescriptor =CASE @LCID

		WHEN 1033 THEN RulesDescriptor.Descriptor

		ELSE RDL.LocalDescription

		END
		
 from CommitmentDrawer  cd
 LEFT JOIN
 PickList_Entries pe1 ON pe1.PickListID =526
 AND pe1.[Value] =cd.Status
  LEFT JOIN
 RulesDescriptor ON (pe1.DescriptorName=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CI_AS )
 LEFT JOIN 
 dbo.RulesDescriptorLocal RDL ON RulesDescriptor.DescriptorID =RDL.DescriptorID and RDL.LCID=@LCID
 where cd.DrawerID = @DrawerID 




END

go
Drop_old_proc TLR_InsertDrawer
GO
Create PROCEDURE dbo.TLR_InsertDrawer  
@DrawerID                  VARCHAR(25),
@DrawerName                NVARCHAR(100),
@DrawerCurrency            CHAR(3),
@DrawerExpiryDate          DATE,
@DrawerLimit               float,
@DrawerAmount              decimal(21,6),
@TotalAssignedAmount       decimal(21,6),
@UtilizedLimit             decimal(21,6),
@AvailableLimit            decimal(21,6),
@PastDue                   BIT,
@Remarks                   NVARCHAR(250),
@AvailabiltyOfCBRBStatus   char,
@CommentsOnCBRBStatus      NVARCHAR(30),
@CBRBStatusDate            DATE,
@Status                    char(30),
@DateOfDeactivation        DATE,
@StartDate                 Date,
@Tenor                     int,
@Period                    char(8),
@ModifiedDate              Date 
 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Inser to table Drawer "LBDDrawer" 
*/
insert into Drawer(DrawerID,DrawerName,Currency,ExpiryDate,DrawerLimit,DrawerAmount,TotalAssignedAmount,UtilizedLimit ,AvailableLimit ,PastDue,Remarks,AvailabiltyOfCBRBStatus ,CommentsOnCBRBStatus,CBRBStatusDate,Status,DateOfDeactivation,StartDate,Tenor,Period,ModifiedDate)
values(@DrawerID,@DrawerName,@DrawerCurrency,@DrawerExpiryDate,@DrawerLimit,@DrawerAmount,@TotalAssignedAmount,@UtilizedLimit ,@AvailableLimit ,@PastDue,@Remarks,@AvailabiltyOfCBRBStatus ,@CommentsOnCBRBStatus,@CBRBStatusDate,@Status,@DateOfDeactivation,@StartDate,@Tenor,@Period,@ModifiedDate)
END
go
Drop_old_proc TLR_LoensUnderCommitment
GO
CREATE PROCEDURE dbo.TLR_LoensUnderCommitment 
@DrawerID                 char(25),
@CommitmentNo               VARCHAR(12) = null,
@RimNo                     int =0


 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 1-11-2018
Reason: Get Loens Under Commitment "LBDDrawer" 
*/


SELECT     ChequeStatus

FROM         DiscCheques INNER JOIN

                      DiscChequesDetail ON DiscCheques.Track_No = DiscChequesDetail.Track_No

WHERE     (DiscCheques.CommitmentNumber=@CommitmentNo AND DiscChequesDetail.DrawerCode=@DrawerID AND DiscCheques.Rim_No=@RimNo

AND  DiscChequesDetail.ChequeStatus NOT IN (2,6,7,8)) --Returned & Replaced & Settled & Deleted



END

go


Drop_old_proc TLR_SearchDrawer
GO
CREATE PROCEDURE dbo.TLR_SearchDrawer  --TLR_SearchDrawer '','koko',1025
@DrawerID char(8) = '',
@DrawerName VARCHAR(100) = '',
@LCID int = 1033,
@CommitmentNo nvarchar(12) = '',
@RimNo int = 0,
@Currency char(3) = ''
 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Search table Drawer "LBDDrawer" 
*/

IF (@CommitmentNo <> '')
BEGIN

select d.DrawerID,DrawerName,d.Currency,d.ExpiryDate,d.DrawerLimit,DrawerAmount,TotalAssignedAmount,
d.UtilizedLimit,d.AvailableLimit,PastDue,Remarks,AvailabiltyOfCBRBStatus,CommentsOnCBRBStatus ,CBRBStatusDate,
Status=CASE @LCID

		WHEN 1033 THEN RulesDescriptor.Descriptor

		ELSE RDL.LocalDescription

		END ,
CBRBStatusDate,DateOfDeactivation,d.StartDate,d.Tenor,d.Period,ModifiedDate
from Drawer d  
LEFT JOIN CommitmentDrawer CD
ON CD.DrawerID = d.DrawerID
 LEFT JOIN
 PickList_Entries pe2 ON pe2.PickListID =526
 AND pe2.[Value] =d.Status
 LEFT JOIN 
 RulesDescriptor ON (pe2.DescriptorName=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CI_AS )
 LEFT JOIN 
 dbo.RulesDescriptorLocal RDL ON RulesDescriptor.DescriptorID =RDL.DescriptorID and RDL.LCID=@LCID
WHERE CD.CommitmentNo = @CommitmentNo        
AND CD.RimNo = @RimNo        
AND CD.Currency = @Currency    
AND CD.Status = 'Active'  
 
END
ELSE
BEGIN

select DrawerID,DrawerName,Currency,ExpiryDate,DrawerLimit,DrawerAmount,TotalAssignedAmount
,UtilizedLimit,AvailableLimit,PastDue,Remarks
,AvailabiltyOfCBRBStatus,
CommentsOnCBRBStatus ,CBRBStatusDate,
Status=CASE @LCID

		WHEN 1033 THEN RulesDescriptor.Descriptor

		ELSE RDL.LocalDescription

		END ,CBRBStatusDate,DateOfDeactivation,StartDate,Tenor,Period,ModifiedDate from Drawer d  
 LEFT JOIN
 PickList_Entries pe2 ON pe2.PickListID =526
 AND pe2.[Value] =d.Status
 LEFT JOIN 
 RulesDescriptor ON (pe2.DescriptorName=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CI_AS )
 LEFT JOIN 
 dbo.RulesDescriptorLocal RDL ON RulesDescriptor.DescriptorID =RDL.DescriptorID and RDL.LCID=@LCID
 where (@DrawerID ='' OR d.DrawerID=@DrawerID)
 and  (@DrawerName ='' or d.DrawerName LIKE '%'+ @DrawerName+'%')

END

END
GO
Drop_old_proc TLR_SearchDrawerByNameAndCurr  
GO
CREATE PROCEDURE dbo.TLR_SearchDrawerByNameAndCurr 
@DrawerName                 char(100),
@Currency             VARCHAR(3)


 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 28-10-2018
Reason: Search table Drawer "LBDDrawer" By NAme And Currency 
*/
/*select drawername,currency from Drawer d
 where d.drawername = @DrawerName
 and  d.Currency =@Currency*/

 SELECT 
    CASE 
        WHEN EXISTS(
             SELECT 1 
             FROM Drawer d
              where d.drawername = @DrawerName
			  and  d.Currency =@Currency)
        THEN 1  

        ELSE 0 
END   as 'Result'
end 

go
drop_old_proc 'dbo.ValidateLBDDrawer'
go
CREATE PROCEDURE dbo.ValidateLBDDrawer 
@TranName nvarchar(100),
@RimNumber int, 
@commitmentNo nvarchar(12) = null,  
@drawerID nvarchar(25) = null,  
@chequeAmount decimal(21,6) = null,  
@currentCommitmentBalance decimal(21,6) = null,  
@chequeMaturityDate date = null, 
@currentCommitmentExpiryDate date = null, 
@validateTotalAmount bit = 0 AS 
/* 
Developer: Mostafa Sayed 
Date	 : 2018-10-21 
Reason	 : CBD_ACM15892_LBD Drawer  
  
Error codes:  
-1  if cheque amount is greater than commitment amount  
-2  if cheque maturity date is greater than commitment maturity date  
-3  if cheque amount is greater than available balance in drawer  
-4  if cheque maturity date is greater than drawer expiry date 
-5  if SA Drawer status is not active 
-6  if link between drawer and commitment status is not active 
-7  if SA Drawer is Past Due 
-8  if totalAmount of cheques is greater than available balance  

Error Types:  
w = warning  
s = stop
 */  
  
CREATE TABLE #Errors  
(ErrorNo int, ErrorType char(1), ErrorDescription nvarchar(max))  
  
DECLARE @DrawerAvailableBalance decimal(21,6)  
DECLARE @DrawerExpiryDate date  
DECLARE @SADrawerStatus char(30)  
DECLARE @CommitmentDrawerStatus nvarchar(20)  
DECLARE @SADrawerPastDue bit  
  
SELECT @DrawerAvailableBalance = AvailableLimit,  
    @DrawerExpiryDate = ExpiryDate,  
    @CommitmentDrawerStatus = Status  
FROM CommitmentDrawer  
WHERE CommitmentNo = @commitmentNo  
AND DrawerID = @drawerID  
AND RimNo = @RimNumber  
  
SELECT @SADrawerStatus = Status,  
    @SADrawerPastDue = PastDue  
FROM Drawer  
WHERE DrawerID = @drawerID  
  
IF(@TranName = 'DiscountedChequesApproval')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'w',N'Cheque Maturity Date Is Greater Than Commitment Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL  AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Drawer Expiry Date')  
 END  
   
 IF(LOWER(@SADrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-5,'s',N'SA Drawer Not Active')  
 END  
  
 IF(LOWER(@CommitmentDrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-6,'s',N'Drawer Linked To Commitment Is Not Active')  
 END  
   
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Drawer Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END  
END  
  
IF(@TranName = 'DiscountedChequeBooking')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'s',N'Cheque Amount Is Greater Than Commitment Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'s',N'Cheque Maturity Date Is Greater Than Commitment Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Drawer Expiry Date')  
 END  
   
 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-7,'w',N'Drawer is Past Due')  
 END  
   
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Drawer Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END  
END  
SELECT * FROM #Errors 
GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc GET_corporateCOs_ANDCHARGES
Go

Create	Proc dbo.GET_corporateCOs_ANDCHARGES 
		
		@ReferenceNumber varchar(20),
		@status int =0,
		@FromCO char(15)= null,
		@ToCO Char(15) =null
		
AS
/*
	Developer : Mostafa Essam
	Created   : 27-07-2010

	Developer:  Rokaia KAdry   
	return  :  Get All Account Type By Refernce Number  
	Issue:GFSX13022 27-05-2018  
 
	Developer:  Rokaia KAdry     
	return  :  Get User Signatures User1 Reviewer and Approval User2
	Issue:GFSX13267 30-09-2018    
		 Developer:  Rokaia KAdry       
	 return  :  Add Status Fail To Get two Status of printed & fail after posting @statusFail  
	 Issue:GFSX13302 15-10-2018       
*/
set	nocount on

select   
serial   as  TLR_CHEQUE_BOOK_ID_ARRAY ,  
DebitAccount as   TLR_ACCOUNTS ,  
CONumber  as  TLR_CHEQUE_NUMBER_ARRAY2,  
ChargeAmount   as  TLR_IR_DrCommission_Array,  
COAmount  as  TLR_IR_DrAmount_Array,  
BeneficiaryName as  TLR_CustomerName_ARRAY ,
DebitAccountType   as   TLR_CHEQUE_BOOK_TYPE_ARRAY    
,(SELECT UserSignature FROM  TellerConfig where TellerConfig.User_ID =user1ID) as 'TLR_UserID1_Signature'
,CASE user2signature WHEN 1 THEN (SELECT UserSignature FROM  TellerConfig where TellerConfig.User_ID =user2ID)   ELSE Null  end as 'TLR_UserID2_Signature'    
,[status] as  COR_STATUS_ARRAY  
--,user1ID ,   
--CASE user2signature  WHEN 1 THEN user2ID  ELSE Null  end as user2ID   
from  CorporateCOs    
where  ReferenceNumber=@ReferenceNumber  and status =@status   
and ((@FromCO is null or @ToCO is null  ) or cast (conumber as int)  between cast (@FromCO as int) and  cast (@ToCO as int ))  
Go 
--End of Automatic Generation
drop_old_proc 'HCS_GetCorporateCOsByRefNo'
GO

CREATE PROCEDURE HCS_GetCorporateCOsByRefNo  
(  
@RefernceNumber nvarchar(50)  ,
@CO_From char(15)  ,
@CO_TO  char(15)  
)  
AS  
/*  
		CreationDate : 15-12-2016         
		Programmer   : Mostafa Sayed  
		Description  : CR#GFSY00614 ADIB_CRQ7501_xp Cmdshell Alternative-  Core System Intregration -

		Modifier: Rokaia Kadry    
		Modify Date: 24/09/2018    
		Reason: issue#GFSX13267 update @Host_Ref_No,HostResponse 

*/   
BEGIN  
		 SELECT * FROM CorporateCOs WHERE 
		 referencenumber = @RefernceNumber
		 and CONumber BETWEEN @CO_From and @CO_TO
END  
GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc ReissueBulkCOCheque
Go

Create	Proc dbo.ReissueBulkCOCheque
		
		@ReferenceNumber varchar(20),
		@serial int,
		@OldCOChequeNumber char(15),
		@NewCOChequeNumber char(15),
		@Host_Ref_No varchar(20) = '',  
		@Host_Result varchar(100)= ''
AS
/*
	Developer : Mostafa Essam
	Created   : 2-08-2010


    Modifier: Rokaia Kadry  
    Modify Date: 24/09/2018  
    Reason: issue#GFSX13267 add DebitAccountType,replace count(*) by  max(SERIAL) to get correct next serial
	
*/
set	nocount on
declare  @newserial as int
select @newserial= max(SERIAL)+1 from CorporateCOs where ReferenceNumber =@ReferenceNumber
select @newserial
update CorporateCOs set status =4 where ReferenceNumber =@ReferenceNumber and serial=@serial and CONumber=@OldCOChequeNumber

INSERT INTO CorporateCOs (
CorporateName , 
FileNamePath ,
 LoadingDate , 
ReferenceNumber , 
DebitAccount , 
serial , 
COAmount , 
ChargeAmount , 
BeneficiaryName , 
CONumber , 
status , 
User1ID , 
User2ID , 
User2signature,
DebitAccountType,
Host_RefNo ,
HostResponse 
 ) 

SELECT CorporateName , 
FileNamePath ,
 LoadingDate , 
ReferenceNumber , 
DebitAccount , 
@newserial , 
COAmount , 
ChargeAmount , 
BeneficiaryName , 
@NewCOChequeNumber , 
3 , 
User1ID , 
User2ID , 
User2signature,DebitAccountType,
@Host_Ref_No,
@Host_Result 
from CorporateCOs where ReferenceNumber =@ReferenceNumber and serial=@serial

Go
--End of Automatic Generation
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Update_corporateCOs
Go

Create	Proc dbo.Update_corporateCOs
		@Status int,
		@ReferenceNumber varchar(20),
		@serial int,
		@user1ID smallint,
		@CONumber char(15) = null,
		@ChargeAmount decimal = null,
		@Reissue int =0
AS
/*
	Developer : Mostafa Essam
	Created   : 21-07-2010


    Modifier: Rokaia Kadry  
    Modify Date: 24/09/2018  
    Reason: issue#GFSX13267 update @Host_Ref_No,HostResponse  	

*/
set	nocount on
if (@Reissue =0)
	begin
		update CorporateCOs set status = @status ,user1ID =@user1ID,CONumber =@CONumber,ChargeAmount=@ChargeAmount
		where ReferenceNumber =@ReferenceNumber and	serial=@serial 
	end
ELSE
	begin
		update CorporateCOs set CONumber_Reissue =@CONumber
		where ReferenceNumber =@ReferenceNumber and	serial=@serial 
	end


Go
--End of Automatic Generation
drop_old_proc 'Update_corporateCOs_Status'
 GO
Create Proc dbo.Update_corporateCOs_Status  
  @Status int,  
  @ReferenceNumber varchar(20),  
  @serial int,  
  @user1ID smallint,
  @Host_Ref_No varchar(20),  
  @Host_Result varchar(100)
AS  
/*  
 Developer : Rokaia Kadry  
 Created   : 20/09/2018
 Description  : Issue:GFSX13267 issue and print CO transaction Enhancement                  
*/  
set nocount on  
  
update CorporateCOs   set status = @status ,Host_RefNo = @Host_Ref_No,HostResponse  =@Host_Result
	
where ReferenceNumber =@ReferenceNumber and  serial=@serial   
  
GO



drop_old_proc AddUpdateStatementRequestNo
go
CREATE Procedure dbo.AddUpdateStatementRequestNo
	@RIMClass [nvarchar](50),
	@AccountNumber [nvarchar](50),
	@Correction [bit]=0
AS      

/*  Version = '1' , Modification Date = '2018/11/26' */             
/*                
	CreationDate : 26-11-2018          
	OriginalName : dbo.AddUpdateStatementRequestNo               
	Programmer   : Nada Elshafie               
	Description  : Insert or Update record for RIMClass and AccountNumber with statement requests ordered.	
*/        
          

SET NOCOUNT ON

 IF EXISTS ( SELECT * FROM AccountStatementRequest WHERE RIMClass = @RIMClass AND AccountNumber = @AccountNumber )
 Begin
	if(@Correction=0)
			update AccountStatementRequest set No_of_Requests=No_of_Requests+1 WHERE RIMClass = @RIMClass AND AccountNumber = @AccountNumber
	else
			update AccountStatementRequest set No_of_Requests=No_of_Requests-1 WHERE RIMClass = @RIMClass AND AccountNumber = @AccountNumber
 End
 Else
 Begin
	INSERT INTO AccountStatementRequest
	  (
		 RIMClass    ,
		 AccountNumber   ,     
		 No_of_Requests
	   )  
	   VALUES 
	  (  
		@RIMClass,
		@AccountNumber,
		1
	  )
 End
GO
drop_old_proc GetNoOfStatementRequests
GO
CREATE Procedure dbo.GetNoOfStatementRequests
@RIMClass varchar(50),
@AccountNumber varchar(50)
AS
/* Version = '1' , Modification Date = '2018/11/26' */          
/*            
CreationDate : 26-11-2018
OriginalName : dbo.GetNoOfStatementRequests          
Programmer   : Nada Elshafie           
Description  : Return No of requests for RIMClass and AccountNumber
*/    

SET NOCOUNT ON 

  
  SELECT 
  No_of_Requests
  from dbo.AccountStatementRequest 
  Where  RIMClass=@RIMClass and AccountNumber=@AccountNumber
  
  GO
drop_old_proc GetStatementFreeChargeSetup
GO
CREATE Procedure dbo.GetStatementFreeChargeSetup
@OptionNo int,
@RIMClass varchar(50)
AS
/* Version = '1' , Modification Date = '2018/11/26' */          
/*            
CreationDate : 26-11-2018
OriginalName : dbo.GetStatementFreeChargeSetup          
Programmer   : Nada Elshafie           
Description  : Return Record for RIMClass charges setup if exists else return record for RIMClass = 'All' if exists
*/    

SET NOCOUNT ON 

  if EXISTS (SELECT 1 from dbo.StatementReqFreeCharges   Where OptionNo=@OptionNo and RIMClass=@RIMClass)
  Begin
  SELECT 
  MaxCharges,
  FreeRequests 
  from dbo.StatementReqFreeCharges 
  Where OptionNo=@OptionNo and RIMClass=@RIMClass
  End
  Else
  Begin
  SELECT 
  MaxCharges,
  FreeRequests 
  from dbo.StatementReqFreeCharges 
  Where OptionNo=@OptionNo and RIMClass like N'All'
  End
  GO
Drop_old_proc TLR_ActiveLoens
GO
CREATE PROCEDURE dbo.TLR_ActiveLoens 
@DrawerID                 char(25),
@CommitmentNo               VARCHAR(12) = '',
@RimNo                     int =0


 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 1-11-2018
Reason: Get Loens Under Commitment "LBDDrawer" which approved
*/
if(@CommitmentNo<>'')
BEGIN
	 IF EXISTS (SELECT     1

	FROM         DiscCheques INNER JOIN

						  DiscChequesDetail ON DiscCheques.Track_No = DiscChequesDetail.Track_No

	WHERE     (DiscCheques.CommitmentNumber=@CommitmentNo AND DiscChequesDetail.DrawerCode=@DrawerID AND DiscCheques.Rim_No=@RimNo

	AND  (DiscChequesDetail.ChequeStatus =1 OR DiscChequesDetail.ChequeStatus =0)))
		BEGIN
			select 2 AS 'Result'
		END 
	else 
		begin
			select 0 AS 'Result'
		END  
END 
ELSE 
BEGIN 
	IF EXISTS(SELECT 1 FROM DiscChequesDetail WHERE DrawerCode=@DrawerID AND (ChequeStatus=1 OR ChequeStatus=0))
		BEGIN
			select 1 AS 'Result'
		END 
	ELSE
	BEGIN 
		SELECT 0 AS 'Result'
	END 
END 




END

go


 Drop_old_proc IRBulkInsertIntoIR     
  go

CREATE PROCEDURE dbo.IRBulkInsertIntoIR 
    @Table IRBulkTableType READONLY    
    AS    
/*      
CreationDate: 2017-5-31     
OriginalName: dbo.IRBulkInsertIntoIR      
Programmer  : Karim Mahmoud
Description : Bulk Insert rows in IR Table 

Reason: GFSY00717 - Add 2 column FLD_111,FLD_121
Developer: Nada Elshafie
Modification date: 14Aug2018
*/   
BEGIN TRY  
    BEGIN TRANSACTION   
       INSERT INTO IR
        (        
			 FileRefNo,        
			 FilePathName,       
			 MsgRefNo,        
			 StatusID,        
			 ActionId,        
			 PaymentMethodID,        
			 DateTimeStamp,        
			 PreparedBy,        
			 MsgValueDate,        
			 ValueDate,        
			 DrAccountNo,        
			 DrAccountNo_AcctType,      
			 DrAccountNo_ApplType,      
			 DrAccountNo_DepLoan,      
			 DrAccountName,        
			 DrCurrency,        
			 DrAmount,        
			 DrAddress,        
			 SenderBank,        
			 DrExchangeRate,        
			 DrCommission,        
			 CrAccountNo,        
			 CrAccountNo_AcctType,     
			 CrAccountNo_ApplType,      
			 CrAccountNo_DepLoan,      
			 CrAccountName,        
			 CrCurrency,        
			 CrAmount,        
			 CrAddress,        
			 OrderingCustomer,        
			 CrExchangeRate,        
			 CrCommission,        
			 OriginalMsg,        
			 Fld_50K,        
			 Fld_59,        
			 Charge_Det,       
			 Account_With_Ref,    
			 Account_With_Ac,    
			 Account_With_Name,    
			 ValueCurrency,    
			 Order_Cust_Name,    
			 Order_Cust_Add1,    
			 Order_Cust_Add2,    
			 Order_Inst,    
			 Order_Inst_Name,    
			 Order_Inst_Add1,    
			 BeneficiaryAccount,    
			 FLD_70,    
			 FLD_71A,    
			 BeneficiaryName,    
			 BeneficiaryAddress,    
			 Updator,    
			 DrValueDate,    
			 CrValueDate,    
			 DrNarrative,    
			 CrNarrative,    
			 FLD_20,    
			 FLD_23,    
			 FLD_33,    
			 FLD_52,    
			 FLD_53,    
			 MsgType,    
			 ExceptionList,    
			 Is_FLD_20_Duplicate,    
			 DrRealExchangeRate,    
			 CrRealExchangeRate,     
			 TTAmount ,    
			 TTCurrency ,    
			 DrSellExchangeRate,    
			 CrBuyExchangeRate ,  
			 IBAN   ,    
			 Ordering_IBAN,    
			 Sender_BIC,    
			 CrRimNo,  
			 Ben_Inst_BIC,
			 FLD_111,
			 FLD_121 
		)       
		SELECT 
		
			 irbt.FileRefNo,        
			 irbt.FilePathName,        
			 irbt.MsgRefNo,        
			 irbt.StatusID,        
			 irbt.ActionId,        
			 irbt.PaymentMethodID,        
			 irbt.DateTimeStamp,        
			 irbt.PreparedBy,        
			 irbt.MsgValueDate,        
			 irbt.ValueDate,        
			 irbt.DrAccountNo,        
			 irbt.DrAccountNo_AcctType,      
			 irbt.DrAccountNo_ApplType,      
			 irbt.DrAccountNo_DepLoan,      
			 irbt.DrAccountName,        
			 irbt.DrCurrency,       
			 irbt.DrAmount,        
			 irbt.DrAddress,        
			 irbt.SenderBank,        
			 irbt.DrExchangeRate,        
			 irbt.DrCommission,        
			 irbt.CrAccountNo,      
			 irbt.CrAccountNo_AcctType,      
			 irbt.CrAccountNo_ApplType,      
			 irbt.CrAccountNo_DepLoan,       
			 irbt.CrAccountName,        
			 irbt.CrCurrency,     
			 irbt.CrAmount,        
			 irbt.CrAddress,        
			 irbt.OrderingCustomer,        
			 irbt.CrExchangeRate,        
			 irbt.CrCommission,        
			 irbt.OriginalMsg,        
			 irbt.Fld_50K,        
			 irbt.Fld_59,        
			 irbt.Charge_Det,    
			 irbt.Account_With_Ref,    
			 irbt.Account_With_Ac,    
			 irbt.Account_With_Name,    
			 irbt.ValueCurrency,    
			 irbt.Order_Cust_Name,    
			 irbt.Order_Cust_Add1,    
			 irbt.Order_Cust_Add2,    
			 irbt.Order_Inst,    
			 irbt.Order_Inst_Name,    
			 irbt.Order_Inst_Add1,    
			 irbt.BeneficiaryAccount,    
			 irbt.FLD_70,     
			 irbt.FLD_71A,    
			 irbt.BeneficiaryName,    
			 irbt.BeneficiaryAddress,    
			 irbt.Updator,  
			 irbt.DB_DrValueDate,   
			 irbt.DB_CrValueDate,    
			 irbt.DB_DrNarrative,    
			 irbt.DB_CrNarrative,    
			 irbt.DB_FLD_20,    
			 irbt.DB_FLD_23,    
			 irbt.DB_FLD_33,    
			 irbt.DB_FLD_52,    
			 irbt.DB_FLD_53,    
			 irbt.MsgType,    
			 irbt.ExceptionList,    
			 irbt.Is_FLD_20_Duplicate,    
			 irbt.DrRealExchangeRate,        
			 irbt.CrRealExchangeRate,    
			 irbt.TTAmount,    
			 irbt.TTCurrency,    
			 irbt.DrSellExchangeRate,    
			 irbt.CrBuyExchangeRate,  
			 irbt.IBAN,  
			 irbt.Ordering_IBAN,    
			 irbt.Sender_BIC,   
			 '',--CrRimNo varchar(100),  
			 '',--Ben_Inst_BIC varchar(100)
			 irbt.FLD_111,
			 irbt.FLD_121  
		
		FROM @Table irbt
    COMMIT  
END TRY  
BEGIN CATCH  
  
    IF @@TRANCOUNT > 0  
        ROLLBACK  
    return -1;
END CATCH  
  
Go
  
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc TLR_IR_GetNextFileSeq
Go
create procedure dbo.TLR_IR_GetNextFileSeq --'20170524'    
 @FileRefNo varchar(11),    
 @MsgsLimit int = 0    
as        
/*        
CreationDate: 2005-07-06      
OriginalName: dbo.TLR_IR_GetNextFileSeq        
Programmer  : Sayed Hussein      
Description : Returns next valid swift file sequence number per day         
Output:          
Assumption:         
        
ModifiedDate:   2005-08-09      
Modifer     :   Sayed Hussein    
ModifyReason:   change @FileRefNo to be of type char(10)        
    
ModifiedDate:   2017-05-29      
Modifer     :   Karim Mahmoud    
ModifyReason:   Handle Concurrent calls    
    
ModifiedDate:   09-October-2017    
Modifer     :   Mohamed Elabd    
ModifyReason:   Add parameter @MsgsLimit - Issue# GFSX12546    
  
ModifiedDate:   16-01-2018    
Modifer     :   Rokaia Kadry  
ModifyReason:   Update RefNo = IRHOSWIFT Reset every new day & Retrofit this Issue# GFSX12546    

ModifiedDate:   28-11-2018    
Modifer     :   Rokaia Kadry  
ModifyReason:   Update FileRefNo to be 4  Issue# GFSX13417  
*/        
declare @refno varchar(20)    
declare @NextSeq varchar (4)    
IF (@MsgsLimit = 0)    
 BEGIN    

  select @NextSeq=isnull( max(convert(int,right(FileRefNo,  len(FileRefNo)-8))), 0)+1    
  from IR    
  where left(FileRefNo, 8) = @FileRefNo    
  ----------------------------------------  Check RefNo = IRHOSWIFT  
    set  @NextSeq = REPLACE(STR(@NextSeq, 4), SPACE(1), '0')  
    select @refno= RefNo from RefNo where RefNo like 'IRHOSWIFT%'     
     if(@refno is null or @refno='')    
     begin    
      insert into RefNo (RefNo) values ('IRHOSWIFT'+@FileRefNo+@NextSeq)    
     end    
     else    
     begin    
    update RefNo set RefNo='IRHOSWIFT'+@FileRefNo+@NextSeq where RefNo like 'IRHOSWIFT%'    
     end    
    select  @NextSeq as NextSequence        
 END    
ELSE    
 BEGIN    
    
--declare @refno varchar(20)    
--declare @NextSeq varchar (3)    
    
--Prevent concurrent calls      
declare @y int            
select @y = 0            
while ((select TL.IsInProcess from dbo.TableLock TL Where tl.TableName = 'RefNo') <> 0)            
 begin            
 if(@y = 120)       
  begin      
  raiserror ('Reference Number Generation Has Timed Out',10,1)      
  select @refno = ''      
  return      
  end      
 else      
  set @y = @y + 1            
       
 waitfor delay '00:00:01'            
end       
      
if not exists (select * from TableLock where TableName='RefNo')      
 insert into TableLock (TableName, IsInProcess) values ('RefNo', 1)      
else      
 update TableLock with (rowlock) set IsInProcess = 1 Where TableName = 'RefNo'      
      
-------------------------------------    
select @refno= RefNo from RefNo where RefNo like 'IRHOSWIFT%'    
if(@refno is null or @refno='')    
 begin    
   select @refno= max(convert(int,right(FileRefNo,  len(FileRefNo)-8))) from IR --LastSequence    
   where left(FileRefNo, 8) = @FileRefNo    
  if(@refno is null or @refno='')    
  begin    
   insert into RefNo (RefNo) values ('IRHOSWIFT'+@FileRefNo+'0000')    
  end    
  else    
  begin    
   insert into RefNo (RefNo) values ('IRHOSWIFT'+@FileRefNo+@refno)    
  end    
  select @refno= RefNo from RefNo where RefNo like 'IRHOSWIFT%' --LastRefNo    
 end    
select  @NextSeq=isnull(max(convert(int,right(RefNo,  len(RefNo)-17))), 0)+1 --as NextSequence    
from RefNo    
where  left(RefNo, 17) = 'IRHOSWIFT'+@FileRefNo  
--where left(RefNo, 17) = left(@refno,17)    
  
     
--update RefNo set RefNo=left(RefNo, 17)+REPLACE(STR(@NextSeq, 3), SPACE(1), '0') where RefNo like 'IRHOSWIFT%'   
 set  @NextSeq = REPLACE(STR(@NextSeq, 4), SPACE(1), '0')   
 update RefNo set RefNo='IRHOSWIFT'+@FileRefNo+@NextSeq where RefNo like 'IRHOSWIFT%'    
 update TableLock with (rowlock) set IsInProcess = 0 Where TableName = 'RefNo'      
 select  @NextSeq as NextSequence    
END    
--select isnull(max(right(FileRefNo, 3)), 0)+1 as NextSequence  
--from IR  
--where left(FileRefNo, 8) = @FileRefNo  
Go
--End of Automatic Generation

drop_old_proc 'dbo.Get_DISC_Cheques'
go
  
CREATE procedure dbo.Get_DISC_Cheques        
   @Ref_No     ReferenceNumber ,                                    
   @Cheque_Status   varchar(10),                                    
   @BranchID varchar(12)      ,                                    
   @User_No      varchar(50),                                       
   @RimNo       varchar(10),                                  
   @BussDate  varchar(70) ,            
   @Track_No ReferenceNumber = null                           
as                                              
                                          
/*                                                  
CreationDate : 07-March-2013                                          
OriginalName : dbo.Get_DISC_Cheques                                               
Programmer   : Aya Mahmoud                    
Description  : Retrofit from CBD  
                      
Modifier :   Aya Mahmoud
Date   :     04-April-2013
Reason   :   Select the DCD.DraweeCustName instead if DiscCheques.CustomerName

Modifier :   May Hassan  
Date   :     27-October-2013  
Reason   :   Fixing Issue# GFSX05264 - Handling Empty String values for FirstName, Middle and LastName in Column 'TLR_USER_NAME_ARRAY'

Modifier :   May Hassan    
Date   :     20-April-2015    
Reason   :   Fixing Issue# GFSX08513 - Adding column 'TLR_PDC_REF_NO_ARRAY' for Loan Account RSM 

Modifier :   Nada Elshafie    
Date   :     03-June-2015    
Reason   :	Get DCD.Int_Amt as TLR_BILL_AMOUNT - GFSY00489

Modifier :   Mostafa Sayed
Date   :     [21/10/2018]		 
Reason   :	Get DCD.Int_Amt as TLR_BILL_AMOUNT and '' to set errors list - GFSY00489
*/                                    
                                    
 Set nocount on                                    
                                    
SELECT               
 '...' as A , ' ' as status , ' ' as COR_STATUS_ARRAY,              
 DiscCheques.Rim_No as TLR_RIM_BRANCH_ARR ,              
 DCD.DraweeCustName as TLR_DRAWERS_NAME   ,                    
 DCD.Ref_No as TLR_IR_MsgRefNo_Array,                               
 DCD.ChequeNo as TLR_PDC_CHEQUE_NUMBER,                              
 DCD.ChequeAmount as TLR_PDC_CHEQUE_AMOUNT,                              
 DCD.ChequeApprovedAmount as TLR_IR_CrAmount_GL_Arr,                               
 DiscCheques.ChequeCurrency as TLR_PDC_CHEQUE_CURRENCY,                              
 CASE OP.FirstName WHEN '' THEN '' ELSE OP.FirstName+' ' END + CASE OP.Middle WHEN '' THEN '' ELSE OP.Middle+' ' END + OP.LastName as TLR_USER_NAME_ARRAY,                        
 DiscCheques.BranchID as TLR_PDC_CLEAR_BRANCH_CODE,                               
 DCD.SendDate as TLR_PDC_SEND_DATE ,                              
 DCD.Track_No as TLR_CR_MODE_OF_PAYMENT,                           
 DCD.ReturnReason as TLR_PDC_COR_ID,                    
 DCD.OtherReturnReason as TLR_PDC_COR_DIRECT_OPT_DSC,                          
 --------------- Params. For TPI                            
 DCD.InterestAmount as TLR_IR_DrExchangeRate_GL_Arr ,                                
 DiscCheques.RSM_ID as TLR_PDC_DRAWER_ACCOUNT_NUMBER ,                          
                           
 DiscCheques.LoanAccountType as TLR_PDC_DR_AC_TYPE,                                 
 DiscCheques.AccountType as TLR_PDC_COL_ACCT_TYPE ,                            
 DiscCheques.LoanClassCode  as TLR_CHEQUE_BOOK_ID_ARRAY ,                            
 DiscCheques.TotalApprovedChequeAmount as TLR_PDC_CHEQUE_AMOUNT_VC,                               
 DCD.MATURITYDate as TLR_SC_Cheque_DATE_ARR,                            
 DiscCheques.CommitmentNumber as TLR_PDC_DR_AC_NUMBER,               
 DiscCheques.CommitmentType as TLR_PDC_PDC_ACCT_APPLI_TYPE,                            
 DCD.CommissionAmount as TLR_TOTAL_CHARGES_ARRAY,                        
 DCD.CommissionDescription as TLR_ExpenseType,                             
 DiscCheques.AccountNumber as TLR_PDC_CHG_AC_NUMBER,                            
 DCD.InterestAmount  as TLR_IR_DrAmount_Array,                      
 DCD.ChequeAmount - DCD.ChequeApprovedAmount as TLR_CHEQUE_AMT_ARR  ,                       
 case when DCD.loanaccountnumber is null then '0' when DCD.loanaccountnumber = '' then '0' else DCD.loanaccountnumber end as TLR_IR_DrAccountNo_Array ,                       
 DCD.Instruction ,                    
 OP.EmployeeID as TLR_INSTALLMENT_TYPE_ARRAY,                      
 DCD. ChequeDate as TLR_PDC_CHEQUE_DATE,                      
 DCD. DestBankAccount as TLR_PDC_DEST_BK_ACCT,                    
 DCD. DestBankAddress1 as TLR_PDC_DEST_ADDRESS1,                      
 DCD. DestBankAddress2 as TLR_PDC_DEST_ADDRESS2,                      
 DCD. DestBankCountry as TLR_PDC_DEST_BK_COUNTRY,                      
 DCD. DestBankDetails as TLR_PDC_DEST_DETAILS,                      
 DCD. DestBankInst as TLR_PDC_DEST_INSTRUCTIONS,                      
 DCD. DestBankName as TLR_PDC_DEST_BK_NAME,                      
 DCD. DirectOption as TLR_PDC_COR_DIRECT_OPT,                      
 DCD. CorrespondentCountry as TLR_ConsDet_CorresAdrs_ln3,                      
 DCD. CorrespondentCity as TLR_PDC_COR_CITY,                      
 DCD. IBCNumber as TLR_CORR_BANK_ARRAY,                      
 DCD. CorrespondantBankID as TLR_PDC_COR_NAME,                      
 DCD. DraweeBankID as TLR_PDC_CLEAR_BANK_CODE,                      
 DCD. DraweeBankName as TLR_PDC_CLEAR_BANK_NAME,                      
 DCD. DraweeBranchName as TLR_PDC_CLEAR_BRANCH_NAME,                      
 DCD. DrAccount as TLR_ConsDet_AccountNo,                      
 DCD. DrAccountCur as TLR_PDC_DR_AC_CUR,                      
 DCD. DrAccountType as TLR_OTHER_ACCT_TYPE_ARRAY,                       
 DCD. DraweeCustName as TLR_ConsDet_CorresAdrs_ln2,                      
 DCD. DraweeAcctNo as TLR_ConsDet_CorresAdrs_ln1,                      
 DCD. InterestAmount as Net_CR_AMT_LOCAL_ARRAY,                      
 DCD. LoanAccountNumber as TLR_IR_CrAccountNo_DP_Arr,                      
 DCD. IsExceptionCheque as TLR_SELECTION   ,              
 DiscCheques.AccountBranch as TLR_ConsDet_AccountType,            
 DCD. ChequeStatus,            
 IsCommissionChanged as TLR_SETTLE_ON_CURRENCY_ARRAY,            
 DCD.routingnumber as  TLR_CORR_BANK_COUNT_ARR  ,          
 datediff(day,@BussDate, DCD.maturitydate ) as TLR_PDC_TYPE_STATUS_ID,          
        dcd.IsInterestChanged as TLR_ICL_Overdraft_Arr,          
 dcd.LateFees as TLR_TOTAL_CHARGES_ARRAY2,          
 dcd.LateFees - dcd.InterestAmount as originalFees,
 ' ' as TLR_PDC_REF_NO_ARRAY ,
 DCD.Int_Amt as TLR_BILL_AMOUNT,
 DR.DrawerID as TLR_ACCT_OFFICER_ARRAY, 
 DR.DrawerName as TLR_COLL_BANK_SETT_INST,
 '' as TLR_Description_ARRAY,
 LPM.EnableCommitmentDrawers as TLR_RECEPIT_STATUS_ARRAY
FROM        DiscChequesDetail as DCD           
   INNER JOIN  DiscCheques           
    ON  DCD.Track_No = DiscCheques.Track_No                      
          
   INNER JOIN Operator OP           
    ON  DCD.User_Number = OP.User_Number  
    
    INNER JOIN LoanProductMap LPM
    on LPM.Acct_Type = DiscCheques.LoanAccountType
   
   LEFT JOIN Drawer DR
   ON DR.DrawerID = DCD.DrawerCode
          
WHERE  (ChequeAmount <> 0  )            
   AND  (DCD.ChequeStatus <> 1)           
   AND  (DCD.ChequeStatus <> 2)                
   AND          
     (@BranchID   is  null or DiscCheques.BranchID = @BranchID) and                 
     (@User_No   is  null or DCD.User_Number   = @User_No)  and                
     (@RimNo    is  null or DiscCheques.Rim_No  = @RimNo)  and                 
     (@Ref_No   is  null or DiscCheques.Ref_No  = @Ref_No)  and                
     (@BussDate   is  null or DCD.MATURITYDate  >=@BussDate) and                
     (@Track_No   is  null or DCD.Track_No =@Track_No) and                 
     (                
     (ChequeStatus =@Cheque_Status  and ChequeStatus is not null) or                 
     (@Cheque_Status  is  null  and ChequeStatus  < 5 )                 
     )   
go
drop_old_proc 'dbo.RecalculateDrawersBalances'
go
CREATE PROCEDURE dbo.RecalculateDrawersBalances
@commitmentNo nvarchar(12),
@currentCommitmentBalance decimal(21,6)
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2018-10-21
	Reason		: CBD_ACM15892_LBD Drawer
    */
	DECLARE @DrawerLimitPercentage float
	DECLARE DRAWER_CURSOR CURSOR  
	DYNAMIC  FOR  
	SELECT DrawerLimit FROM CommitmentDrawer WHERE CommitmentNo=@commitmentNo
	
	OPEN DRAWER_CURSOR
	FETCH NEXT FROM DRAWER_CURSOR INTO  @DrawerLimitPercentage
	WHILE @@FETCH_STATUS = 0      
	BEGIN
		UPDATE CommitmentDrawer
		SET DrawerLimitInAmount = (@DrawerLimitPercentage/100) * @currentCommitmentBalance
		WHERE CURRENT OF DRAWER_CURSOR
		
		UPDATE CommitmentDrawer
		SET AvailableLimit=DrawerLimitInAmount-UtilizedLimit
		WHERE CURRENT OF DRAWER_CURSOR
		
	FETCH  FROM DRAWER_CURSOR INTO  @DrawerLimitPercentage
	END
	CLOSE DRAWER_CURSOR
	DEALLOCATE DRAWER_CURSOR
GO
drop_old_proc 'dbo.Update_DiscoutedCheque'
go
    
CREATE Procedure  dbo.Update_DiscoutedCheque      
@ChequeStatus int ,        
@PrevStatus int,        
@Ref_No ReferenceNumber ,      
@Track_No      ReferenceNumber ,      
@CommissionAmount money,          
@InterestRate Decimal(18,6),      
@LateFees  decimal(18,6),      
@LoanAcctType varchar(10),      
@LoanAcctClass int,      
@CMTType varchar(10),      
@CMTNumber varchar(30),      
@updator OperatorID  ,      
@IsCommissionChanged bit,      
@IsInterestChanged bit,      
      
@OldChequeNo Char(20) = null,            
@ChequeNo Char(20) = null,      
@ChequeDT smalldatetime = null,            
@SendDT smalldatetime = null,            
@MaturityDT smalldatetime = null,            
@ApprovedAmt decimal(18, 0) = null,            
@CommissionDescription string_30 = null,        
@ChequeAmount Money = null,      
@ChequeType  int = null,      
      
@ClearBankBranchID varchar(50) = null,            
@DraweeBankID varchar(5) = null,            
@DraweeBankName nvarchar(50) = null,            
@DraweeBranchName nvarchar(50) = null,            
@DraweeAcctNo nvarchar(60) = null,            
@DraweeCustName nvarchar(100) = null,       
@ClearCenter BranchID = null    ,      
@RoutingnNumber varchar(12) = null,      
      
@ShadowAccount varchar(60) = NULL,            
@ShadowAccountCur CurrencyType = NULL,            
@ShadowAccountType char(3) = NULL,            
@ShadowAccountDepLoan char(3) = NULL    ,      
      
@DrAccount varchar(60) = NULL,            
@DrAccountCur CurrencyType = NULL,            
@DrAccountType char(3) = NULL,            
@DrAccountDepLoan char(3) = NULL,
@DiscountType smallint = NULL,
@UnDiscPercent decimal(6,2) = NULL,
@Int_Amt decimal(21,6) = NULL,
@DrawerCode nvarchar(50) = NULL          
------------------------------------            
/*                    
Creator : Aya Mahmoud  
Date : 07-March-2013               
Purpose : Retrofit from CBD - update discounted cheque details        
  
Modifier :  Aya Mahmoud      
Date :      12-May-2013   
Reason :    Update the column DiscountType (0=Fixed, 1=Percent) & the column @UnDiscPercent

Modifier :  Nada Elshafie      
Date :      03-June-2015
Reason :	Update new Column Int_Amt - GFSY00489

Modifier :  Nada Elshafie      
Date :      05-July-2015
Reason :	Check Int_Amt is not null

Modifier :  Mostafa Sayed  
Date :      21-Oct-2018
Reason :	Update DrawerCode column
*/        
      
As      
      
if(@ShadowAccount = '')      
 set  @ShadowAccount = null      
if(@ShadowAccountCur = '')      
 set @ShadowAccountCur = null      
if(@ShadowAccountType = '')      
 set @ShadowAccountType = null      
if(@ShadowAccountDepLoan = '')      
 set @ShadowAccountDepLoan = null      
if(@Int_Amt is null)
	set @Int_Amt =  (Select Int_Amt from DiscChequesDetail where Ref_No=@Ref_No)    
            
update disccheques          
set [CommitmentType] = @CMTType,      
      [CommitmentNumber] = @CMTNumber      
      ,[LoanAccountType] = @LoanAcctType      
      ,[LoanClassCode] = @LoanAcctClass,      
 [updator] = @updator,      
 [LastChanged] = getdate()      
where [Track_No] = @Track_No      
      
if (@ChequeNo is not null)      
begin      
 Update DiscChequesDetail             
 Set  [ChequeNo] = @ChequeNo       
      ,[ChequeType] = @ChequeType      
      ,[ChequeAmount] = @ChequeAmount       
      ,[ChequeStatus] = @ChequeStatus       
      ,[ChequeApprovedAmount] = @ApprovedAmt       
      ,[InterestAmount] = @InterestRate       
      ,[ChequeDate] = @ChequeDT       
      ,[MaturityDate] = @MaturityDT       
      ,[SendDate] = @SendDT       
      ,[ClearCenter] = @ClearCenter      
      ,[ClearBankBranchID] = @ClearBankBranchID       
      ,[DrAccount] = @DrAccount       
      ,[DrAccountCur] = @DrAccountCur       
      ,[DrAccountType] = @DrAccountType       
      ,[DrAccountDepLoan] = @DrAccountDepLoan       
      ,[DraweeAcctNo] = @DraweeAcctNo       
      ,[DraweeCustName] = @DraweeCustName       
      ,[DraweeBankID] = @DraweeBankID       
      ,[DraweeBankName] = @DraweeBankName       
      ,[DraweeBranchName] = @DraweeBranchName       
      ,[ShadowDepLoan] = @ShadowAccountDepLoan       
      ,[ShadowAccount] = @ShadowAccount       
      ,[ShadowAccountCur] = @ShadowAccountCur       
      ,[ShadowAccountType] = @ShadowAccountType       
      ,[routingnumber] = @RoutingnNumber      
      ,[Updator] = @updator       
      ,[LastChanged] = getdate()      
      ,[CommissionAmount] = @CommissionAmount       
      ,[CommissionDescription] = @CommissionDescription      
      ,[IsCommissionChanged] = @IsCommissionChanged      
      ,[IsInterestChanged] = @IsInterestChanged      
      ,[LateFees] = @LateFees    
      ,[DiscountType] = @DiscountType
      ,[UnDiscPercent]  = @UnDiscPercent
	  ,[Int_Amt] = @Int_Amt
	  ,[DrawerCode] = @DrawerCode
Where ChequeNo = @OldChequeNo and Ref_No = @Ref_No            
end      
else      
begin      
 Update DiscChequesDetail             
 Set   [ChequeStatus] = @ChequeStatus       
      ,[InterestAmount] = @InterestRate       
      ,[Updator] = @updator       
      ,[LastChanged] = getdate()      
      ,[CommissionAmount] = @CommissionAmount       
      ,[IsCommissionChanged] = @IsCommissionChanged      
      ,[IsInterestChanged] = @IsInterestChanged      
      ,[LateFees] = @LateFees
	  ,[Int_Amt] = @Int_Amt     
	  ,[DrawerCode] = @DrawerCode 
 Where Ref_No = @Ref_No        
end      
go
drop_old_proc 'dbo.UpdateDrawerBalances'
go
CREATE PROCEDURE dbo.UpdateDrawerBalances
@commitmentNo nvarchar(12),
@drawerID varchar(25),
@chequeApprovedAmount decimal(21,6)
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2018-10-21
	Reason		: CBD_ACM15892_LBD Drawer
    */
	UPDATE CommitmentDrawer
	SET UtilizedLimit = UtilizedLimit + @chequeApprovedAmount,
		AvailableLimit = AvailableLimit - @chequeApprovedAmount
	WHERE CommitmentNo=@commitmentNo AND DrawerID=@drawerID
	
	UPDATE Drawer
	SET UtilizedLimit = UtilizedLimit + @chequeApprovedAmount,
		AvailableLimit = AvailableLimit - @chequeApprovedAmount
	WHERE DrawerID=@drawerID
GO

drop_old_proc 'dbo.ValidateLBDDrawer'
go
CREATE PROCEDURE dbo.ValidateLBDDrawer 
@TranName nvarchar(100),
@RimNumber int, 
@commitmentNo nvarchar(12) = null,  
@drawerID nvarchar(25) = null,  
@chequeAmount decimal(21,6) = null,  
@currentCommitmentBalance decimal(21,6) = null,  
@chequeMaturityDate date = null, 
@currentCommitmentExpiryDate date = null, 
@validateTotalAmount bit = 0 AS 
/* 
Developer: Mostafa Sayed 
Date	 : 2018-10-21 
Reason	 : CBD_ACM15892_LBD Drawer  
  
Error codes:  
-1  if cheque amount is greater than commitment amount  
-2  if cheque maturity date is greater than commitment maturity date  
-3  if cheque amount is greater than available balance in drawer  
-4  if cheque maturity date is greater than drawer expiry date 
-5  if SA Drawer status is not active 
-6  if link between drawer and commitment status is not active 
-7  if SA Drawer is Past Due 
-8  if totalAmount of cheques is greater than drawer available balance  
-9  if totalAmount of cheques is greater than SA drawer available balance  
-10 if totalAmount of cheques is greater than commitment available balance  
-11 if cheque amount is greater than available balance in SA drawer  

Error Types:  
w = warning  
s = stop
 */  
  
CREATE TABLE #Errors  
(ErrorNo int, ErrorType char(1), ErrorDescription nvarchar(max))  

DECLARE @SADrawerAvailableBalance decimal(21,6) 
DECLARE @DrawerAvailableBalance decimal(21,6)  
DECLARE @DrawerExpiryDate date  
DECLARE @SADrawerStatus char(30)  
DECLARE @CommitmentDrawerStatus nvarchar(20)  
DECLARE @SADrawerPastDue bit  
DECLARE @DreawerName nvarchar(100)
  
SELECT @DrawerAvailableBalance = AvailableLimit,  
    @DrawerExpiryDate = ExpiryDate,  
    @CommitmentDrawerStatus = Status  
FROM CommitmentDrawer  
WHERE CommitmentNo = @commitmentNo  
AND DrawerID = @drawerID
  
SELECT @SADrawerStatus = Status,  
    @SADrawerPastDue = PastDue,
    @SADrawerAvailableBalance = AvailableLimit,
    @DreawerName = DrawerName
FROM Drawer  
WHERE DrawerID = @drawerID  
  
IF(@TranName = 'DiscountedChequesApproval')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'w',N'Cheque Maturity Date Is Greater Than Commitment ('+@commitmentNo+') Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL  AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ('+@DreawerName+') ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Drawer ('+@DreawerName+') Expiry Date')  
 END  
   
 IF(LOWER(@SADrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-5,'s',N'SA Drawer ('+@DreawerName+') Not Active')  
 END  
  
 IF(LOWER(@CommitmentDrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-6,'s',N'Drawer ('+@DreawerName+') Linked To Commitment ('+@commitmentNo+') Is Not Active')  
 END  
   
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Drawer ('+@DreawerName+') Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END
 
 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DreawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
 END  
 
 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
 END 
 
 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
 END 
END  
  
IF(@TranName = 'DiscountedChequeBooking')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'s',N'Cheque Maturity Date Is Greater Than Commitment Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Drawer Expiry Date')  
 END  
   
 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-7,'w',N'Drawer is Past Due')  
 END  
   
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Drawer Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END
 
 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
 END   
END  
SELECT * FROM #Errors 
GO
drop_old_proc 'dbo.ValidateLBDDrawer'
go
CREATE PROCEDURE dbo.ValidateLBDDrawer 
@TranName nvarchar(100),
@RimNumber int, 
@commitmentNo nvarchar(12) = null,  
@drawerID nvarchar(25) = null,  
@chequeAmount decimal(21,6) = null,  
@currentCommitmentBalance decimal(21,6) = null,  
@chequeMaturityDate date = null, 
@currentCommitmentExpiryDate date = null, 
@validateTotalAmount bit = 0 AS 
/* 
Developer: Mostafa Sayed 
Date	 : 2018-10-21 
Reason	 : CBD_ACM15892_LBD Drawer  
  
Error codes:  
-1  if cheque amount is greater than commitment amount  
-2  if cheque maturity date is greater than commitment maturity date  
-3  if cheque amount is greater than available balance in drawer  
-4  if cheque maturity date is greater than drawer expiry date 
-5  if SA Drawer status is not active 
-6  if link between drawer and commitment status is not active 
-7  if SA Drawer is Past Due 
-8  if totalAmount of cheques is greater than drawer available balance  
-9  if totalAmount of cheques is greater than SA drawer available balance  
-10 if totalAmount of cheques is greater than commitment available balance  
-11 if cheque amount is greater than available balance in SA drawer  

Error Types:  
w = warning  
s = stop
 */  
  
CREATE TABLE #Errors  
(ErrorNo int, ErrorType char(1), ErrorDescription nvarchar(max))  

DECLARE @SADrawerAvailableBalance decimal(21,6) 
DECLARE @DrawerAvailableBalance decimal(21,6)  
DECLARE @DrawerExpiryDate date  
DECLARE @SADrawerStatus char(30)  
DECLARE @CommitmentDrawerStatus nvarchar(20)  
DECLARE @SADrawerPastDue bit  
DECLARE @DreawerName nvarchar(100)
  
SELECT @DrawerAvailableBalance = AvailableLimit,  
    @DrawerExpiryDate = ExpiryDate,  
    @CommitmentDrawerStatus = Status  
FROM CommitmentDrawer  
WHERE CommitmentNo = @commitmentNo  
AND DrawerID = @drawerID
  
SELECT @SADrawerStatus = Status,  
    @SADrawerPastDue = PastDue,
    @SADrawerAvailableBalance = AvailableLimit,
    @DreawerName = DrawerName
FROM Drawer  
WHERE DrawerID = @drawerID  
  
IF(@TranName = 'DiscountedChequesApproval')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'w',N'Cheque Maturity Date Is Greater Than Commitment ('+@commitmentNo+') Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL  AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ('+@DreawerName+') ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Drawer ('+@DreawerName+') Expiry Date')  
 END  
   
 IF(LOWER(@SADrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-5,'s',N'SA Drawer ('+@DreawerName+') Not Active')  
 END  
  
 IF(LOWER(@CommitmentDrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-6,'s',N'Drawer ('+@DreawerName+') Linked To Commitment ('+@commitmentNo+') Is Not Active')  
 END  
 
 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-7,'w',N'Drawer is Past Due')  
 END  
 
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Drawer ('+@DreawerName+') Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END
 
 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DreawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
 END  
 
 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
 END 
 
 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
 END 
END  
  
IF(@TranName = 'DiscountedChequeBooking')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'s',N'Cheque Maturity Date Is Greater Than Commitment Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Drawer Expiry Date')  
 END  
   
 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-7,'w',N'Drawer is Past Due')  
 END  
   
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Drawer Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END
 
 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DreawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
 END  
 
 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
 END 
 
 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
 END   
END  
SELECT * FROM #Errors 
GO
drop_old_proc 'dbo.ValidateLBDDrawer'
go
CREATE PROCEDURE dbo.ValidateLBDDrawer 
@TranName nvarchar(100),
@RimNumber int, 
@commitmentNo nvarchar(12) = null,  
@drawerID nvarchar(25) = null,  
@chequeAmount decimal(21,6) = null,  
@currentCommitmentBalance decimal(21,6) = null,  
@chequeMaturityDate date = null, 
@currentCommitmentExpiryDate date = null, 
@validateTotalAmount bit = 0 AS 
/* 
Developer: Mostafa Sayed 
Date	 : 2018-10-21 
Reason	 : CBD_ACM15892_LBD Drawer  
  
Error codes:  
-1  if cheque amount is greater than commitment amount  
-2  if cheque maturity date is greater than commitment maturity date  
-3  if cheque amount is greater than available balance in drawer  
-4  if cheque maturity date is greater than commitment drawer expiry date 
-5  if SA Drawer status is not active 
-6  if link between drawer and commitment status is not active 
-7  if SA Drawer is Past Due 
-8  if totalAmount of cheques is greater than drawer available balance  
-9  if totalAmount of cheques is greater than SA drawer available balance  
-10 if totalAmount of cheques is greater than commitment available balance  
-11 if cheque amount is greater than available balance in SA drawer  
-12 if cheque maturity date is greater than SA drawer expiry date

Error Types:  
w = warning  
s = stop
 */  
  
CREATE TABLE #Errors  
(ErrorNo int, ErrorType char(1), ErrorDescription nvarchar(max))  

DECLARE @SADrawerAvailableBalance decimal(21,6) 
DECLARE @DrawerAvailableBalance decimal(21,6)  
DECLARE @DrawerExpiryDate date  
DECLARE @SADrawerStatus char(30)  
DECLARE @CommitmentDrawerStatus nvarchar(20)  
DECLARE @SADrawerPastDue bit  
DECLARE @DreawerName nvarchar(100)
DECLARE @SADrawerExpiryDate date  
  
SELECT @DrawerAvailableBalance = AvailableLimit,  
    @DrawerExpiryDate = ExpiryDate,  
    @CommitmentDrawerStatus = Status  
FROM CommitmentDrawer  
WHERE CommitmentNo = @commitmentNo  
AND DrawerID = @drawerID
  
SELECT @SADrawerStatus = Status,  
    @SADrawerPastDue = PastDue,
    @SADrawerAvailableBalance = AvailableLimit,
    @DreawerName = DrawerName,
    @SADrawerExpiryDate = ExpiryDate
FROM Drawer  
WHERE DrawerID = @drawerID  
  
IF(@TranName = 'DiscountedChequesApproval')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'w',N'Cheque Maturity Date Is Greater Than Commitment ('+@commitmentNo+') Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL  AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ('+@DreawerName+') ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DreawerName+') Expiry Date')  
 END  
   
 IF(LOWER(@SADrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-5,'s',N'SA Drawer ('+@DreawerName+') Not Active')  
 END  
  
 IF(LOWER(@CommitmentDrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-6,'s',N'Drawer ('+@DreawerName+') Linked To Commitment ('+@commitmentNo+') Is Not Active')  
 END  
 
 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-7,'w',N'Drawer is Past Due')  
 END  
 
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Drawer ('+@DreawerName+') Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END
 
 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DreawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
 END  
 
 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
 END 
 
 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
 END 
 
 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DreawerName+') Expiry Date')  
 END  
END  
  
IF(@TranName = 'DiscountedChequeBooking')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'s',N'Cheque Maturity Date Is Greater Than Commitment Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DreawerName+') Expiry Date')  
 END  
   
 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-7,'w',N'Drawer is Past Due')  
 END  
   
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Drawer Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END
 
 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DreawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
 END  
 
 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
 END 
 
 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
 END   
 
 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DreawerName+') Expiry Date')  
 END  
 
END  
SELECT * FROM #Errors 
GO
drop_old_proc 'dbo.ValidateLBDDrawer'
go
CREATE PROCEDURE dbo.ValidateLBDDrawer 
@TranName nvarchar(100),
@RimNumber int, 
@commitmentNo nvarchar(12) = null,  
@drawerID nvarchar(25) = null,  
@chequeAmount decimal(21,6) = null,  
@currentCommitmentBalance decimal(21,6) = null,  
@chequeMaturityDate date = null, 
@currentCommitmentExpiryDate date = null, 
@validateTotalAmount bit = 0 AS 
/* 
Developer: Mostafa Sayed 
Date	 : 2018-10-21 
Reason	 : CBD_ACM15892_LBD Drawer  
  
Error codes:  
-1  if cheque amount is greater than commitment amount  
-2  if cheque maturity date is greater than commitment maturity date  
-3  if cheque amount is greater than available balance in drawer  
-4  if cheque maturity date is greater than commitment drawer expiry date 
-5  if SA Drawer status is not active 
-6  if link between drawer and commitment status is not active 
-7  if SA Drawer is Past Due 
-8  if totalAmount of cheques is greater than drawer available balance  
-9  if totalAmount of cheques is greater than SA drawer available balance  
-10 if totalAmount of cheques is greater than commitment available balance  
-11 if cheque amount is greater than available balance in SA drawer  
-12 if cheque maturity date is greater than SA drawer expiry date

Error Types:  
w = warning  
s = stop
 */  
  
CREATE TABLE #Errors  
(ErrorNo int, ErrorType char(1), ErrorDescription nvarchar(max))  

DECLARE @SADrawerAvailableBalance decimal(21,6) 
DECLARE @DrawerAvailableBalance decimal(21,6)  
DECLARE @DrawerExpiryDate date  
DECLARE @SADrawerStatus char(30)  
DECLARE @CommitmentDrawerStatus nvarchar(20)  
DECLARE @SADrawerPastDue bit  
DECLARE @DreawerName nvarchar(100)
DECLARE @SADrawerExpiryDate date  
  
SELECT @DrawerAvailableBalance = AvailableLimit,  
    @DrawerExpiryDate = ExpiryDate,  
    @CommitmentDrawerStatus = Status  
FROM CommitmentDrawer  
WHERE CommitmentNo = @commitmentNo  
AND DrawerID = @drawerID
  
SELECT @SADrawerStatus = Status,  
    @SADrawerPastDue = PastDue,
    @SADrawerAvailableBalance = AvailableLimit,
    @DreawerName = DrawerName,
    @SADrawerExpiryDate = ExpiryDate
FROM Drawer  
WHERE DrawerID = @drawerID  
  
IF(@TranName = 'DiscountedChequesApproval')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'w',N'Cheque Maturity Date Is Greater Than Commitment ('+@commitmentNo+') Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL  AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ('+@DreawerName+') ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DreawerName+') Expiry Date')  
 END  
   
 IF(LOWER(@SADrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-5,'s',N'SA Drawer ('+@DreawerName+') Not Active')  
 END  
  
 IF(LOWER(@CommitmentDrawerStatus) != 'active' AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-6,'s',N'Drawer ('+@DreawerName+') Linked To Commitment ('+@commitmentNo+') Is Not Active')  
 END  
 
 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-7,'w',N'Drawer is Past Due')  
 END  
 
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Drawer ('+@DreawerName+') Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END
 
 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DreawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
 END  
 
 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
 END 
 
 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
 END 
 
 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DreawerName+') Expiry Date')  
 END  
END  
  
IF(@TranName = 'DiscountedChequeBooking')  
BEGIN  
 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment Amount ' + cast(@currentCommitmentBalance as varchar))  
 END  
  
 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-2,'s',N'Cheque Maturity Date Is Greater Than Commitment Expiry Date')  
 END  
   
 IF(@chequeAmount IS NOT NULL AND @DrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ' + cast(@DrawerAvailableBalance as varchar))  
 END  
   
 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND   
  (@chequeMaturityDate > @DrawerExpiryDate))  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DreawerName+') Expiry Date')  
 END  
   
 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-7,'w',N'Drawer is Past Due')  
 END  
   
 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Drawer Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
 END
 
 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DreawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
 END  
 
 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
 END 
 
 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
 END   
 
 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  
  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  
 BEGIN  
  INSERT INTO #Errors  
  VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DreawerName+') Expiry Date')  
 END  
 
END  
SELECT * FROM #Errors 
GO
drop_old_proc 'HCS_Search_ClearDetails_all'
GO

CREATE PROC [dbo].[HCS_Search_ClearDetails_all]          
--Search_ClearDetails_all 001,'Ba','asd','11/9/2008','11/9/2008',01,'11/9/2008','11/9/2008',123            
        
 @ClearBankBranchID varchar(20),              
 @BankName varchar(50),              
 @BranchName  varchar(35),              
 @DateFrom smalldatetime,               
 @DateTo smalldatetime ,        
 --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
 @DepositBranchID nvarchar(20)  = '',          
 @DepositDateFrom nvarchar(100) = '',          
 @DepositDateTo nvarchar(100)   = '',          
 @ChequeNumber nvarchar(20)     = '',              
 --Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
 @IDs nvarchar(4000)
as              
/*              
 BY : Shimaa Saeed              
 Date : 2005-08-29              
 Reason : select from cleardetails              
              
 BY : alaa zain               
 Date : 2008-04-21              
 Reason : select from cleardetails              
         
 Modification Date:   24/04/2012            
 Modifer:     Asmaa Hafez             
 Modification Reason: Adding parameters '@DepositBranchID, @DepositDateFrom , @DepositDateTo ,@ChequeNumber'         
       - CR # 6772 (Outward Clearing Off Balance) - ADIB Retrofitting
       
 Modification Date:   25/09/2016            
 Modifer:     May Hassan             
 Modification Reason:   Change @ChequeNumber = -1 to @ChequeNumber = convert (varchar,-1) , so that @ChequeNumber will not be casted as integer 
						and throws an error when the ChequeNumber length is greater than 10 - Issue# GFSX10987
 CreationDate		 : 15-12-2016       
 Programmer			 : Mostafa Sayed
 Description		 : CR#GFSY00614 ADIB_CRQ7501_xp Cmdshell Alternative-  Core System Intregration - 
 Modification Reason : Change in selection criteria
 
 Modification Date:   17/12/2018          
 Modifer:     Rokaia Kadry              
 Modification Reason: return ID column issue#GFSX13438 add @IDs to filter by id.  
 
*/              
SET NOCOUNT ON     

-------------------------------  Rokaia Kadry Begin issue#GFSX13438 -------------------------  
	  DECLARE @x XML 
      SELECT @x = CAST('<A>'+ REPLACE(@IDs,',','</A><A>')+ '</A>' AS XML)     
-------------------------------  Rokaia Kadry End issue#GFSX13438 -------------------------
	
declare @NoOfRows int  
select @NoOfRows = 1000   
select @NoOfRows = convert( nvarchar(10),Value)       
from RulesTranFldParam with(nolock)      
Where  TranName = 'OutwardClChequeSettlement' And Param = 'NoOfRows' And Param = 'NoOfRows' And IsNumeric(Value) = 1     
 
 if(@ChequeNumber='')
 set @ChequeNumber = -1
        
if (@ClearBankBranchID <>'')              
Begin              
       
    select Top(@NoOfRows) ID,TxnID,ClearBankBranchID,AccountNumber,ChequeNumber,DrawerAccNumber ,ChequeAmount , PrevStatus ,Status , ValueDate , Branch , User_Number , Narrative ,ChequeTypeStatusID , BusinessDate ,RefNo , ClearingCenter , ClearBillNumber ,BatchReferenceNo , SourceOfCheque , Other , PrevValueDate , AfterCutoffTime ,Routing_No , GLNumber , ProviderID , Charges , ForUtilityPayment , ShadowAccountType , CustomerShadowAcc , ShadowAccApplicationType ,AccountType , AccountApplictopnType , AccountCurrency , ShadowAccountCurrency ,AccountStatus , ChequeDate , Creator , HostTranStatus , HostTranResponse ,Send_Host_RefNo , return_code1 , ClearBankName,CustomerReference , EffectiveDate              
    From   ClearDetail             
    Where Status=4              
          AND ClearBankBranchID=@ClearBankBranchID              
          AND ValueDate BETWEEN cast(@DateFrom as date) AND CAST( @DateTo  as DATE)        
          --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
          AND (@DepositBranchID ='' OR Branch = @DepositBranchID)        
          AND (@DepositDateFrom ='' OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))             
		  AND (@ChequeNumber = convert (varchar, -1) OR ChequeNumber = @ChequeNumber)    
          --Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
        and ID in ( SELECT t.value('.', 'int') AS inVal  FROM @x.nodes('/A') AS x(T)) -- Rokaia Kadry Begin issue#GFSX13438
End              
Else              
Begin  
              
    select Top(@NoOfRows) ID,TxnID,ClearBankBranchID,AccountNumber,ChequeNumber,DrawerAccNumber ,ChequeAmount , PrevStatus ,Status , ValueDate , Branch , User_Number , Narrative ,ChequeTypeStatusID , BusinessDate ,RefNo , ClearingCenter , ClearBillNumber ,BatchReferenceNo , SourceOfCheque , Other , PrevValueDate , AfterCutoffTime ,Routing_No , GLNumber , ProviderID , Charges , ForUtilityPayment , ShadowAccountType , CustomerShadowAcc , ShadowAccApplicationType ,AccountType , AccountApplictopnType , AccountCurrency , ShadowAccountCurrency ,AccountStatus , ChequeDate , Creator , HostTranStatus , HostTranResponse ,Send_Host_RefNo , return_code1 , ClearBankName,CustomerReference , EffectiveDate             
    From ClearDetail              
    Where Status=4              
  AND ValueDate BETWEEN cast(@DateFrom as date) AND CAST( @DateTo  as DATE)  
  --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]        
  AND (@DepositBranchID ='' OR Branch = @DepositBranchID)      
  AND (@DepositDateFrom ='' OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))    
  AND (@ChequeNumber = convert (varchar,-1) OR ChequeNumber = @ChequeNumber)  
    
  --Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)] 
  and ID in ( SELECT t.value('.', 'int') AS inVal  FROM @x.nodes('/A') AS x(T)) -- Rokaia Kadry Begin issue#GFSX13438
            
END 
GO
drop_old_proc 'Search_ClearDetails'
GO
CREATE PROC dbo.Search_ClearDetails  --                
  @ClearBankBranchID varchar(20),                  
  @BankName varchar(50),                  
  @BranchName  varchar(35),                  
  @DateFrom smalldatetime,                   
  @DateTo smalldatetime  ,              
   --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
  @DepositBranchID BranchID = -1,                  
  @DepositDateFrom nvarchar(100) = '',                  
  @DepositDateTo nvarchar(100) = '',                  
  @ChequeNumber decimal(15, 0) = -1               
  --Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]                 
as                  
/*                  
 BY : Shimaa Saeed                  
 Date : 2005-08-29                  
 Reason : select from cleardetails                 
               
 Modification Date:   24/04/2012                  
 Modifer:     Asmaa Hafez                   
 Modification Reason: Adding parameters '@DepositBranchID, @DepositDateFrom , @DepositDateTo ,@ChequeNumber'               
       - CR # 6772 (Outward Clearing Off Balance) - ADIB Retrofitting             
               
 Modification Date:   29/04/2012                  
 Modifer:     Asmaa Hafez                   
 Modification Reason: select effective date         
       - CR # 9014 (Amend Effective date to be next valid Effective Date) - ADIB Retrofitting           
  
 Modification Date:   29/09/2012                  
 Modifer:     Lamiaa Mostafa                  
 Modification Reason: Fixing Issue #GFSX01318 -  return EffectiveDate column with default value and in datetime datatype. 
     
 Modification Date:   21/1/2016                
 Modifer:     Moataz Mahsoub 
 Version #1812                 
 Modification Reason: return EffectiveDate column with value From ClearDetail Table.   
 
 Modification Date:   17/12/2018          
 Modifer:     Rokaia Kadry              
 Modification Reason: return ID column issue#GFSX13438.  
      
*/                  
SET NOCOUNT ON       
         
declare @NoOfRows int        
select @NoOfRows=1000         
select @NoOfRows = convert( nvarchar(10),Value)          
from RulesTranFldParam          
Where  TranName = 'OutwardClChequeSettlement' And Param = 'NoOfRowsProcess'           
          
                  
if (@ClearBankBranchID <>'')                  
Begin                  
                  
    select Top (@NoOfRows)      
            AccountNumber,                  
            AccountType,                  
            AccountCurrency,                  
            ChequeNumber,                  
            DrawerAccNumber,                  
            ValueDate,             
           -- convert(varchar, '1900-08-28 00:00:00', 103) as EffectiveDate,  
            EffectiveDate,                 
            ChequeAmount,                  
            @BankName,                  
            @BranchName,                  
            Branch,                  
            CustomerShadowAcc,                  
            ShadowAccountType,                  
            ShadowAccountCurrency,                  
            AccountApplictopnType,                  
            ShadowAccApplicationType,                  
            AccountStatus ,  
            HostTranResponse,            
            HostTranStatus,
            [ID]
                          
                  
    From   ClearDetail                  
    Where Status=4                  
          AND ClearBankBranchID=@ClearBankBranchID                  
          AND ValueDate BETWEEN @DateFrom AND @DateTo                
          -- Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
          AND (@DepositBranchID = -1 OR Branch = @DepositBranchID)               
          AND ((@DepositDateFrom = '') OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))              
          AND (@ChequeNumber = -1 OR ChequeNumber = @ChequeNumber)              
          -- Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
                         
End                  
                  
                  
Else                  
Begin                  
    select Top (@NoOfRows)       
            AccountNumber,               
            AccountType,                  
            AccountCurrency,                
            ChequeNumber,                  
            DrawerAccNumber,                  
            ValueDate,                
            --convert(varchar, '1900-08-28 00:00:00', 103)  as EffectiveDate, 
            EffectiveDate,                    
            ChequeAmount,                  
            @BankName,                  
            @BranchName,                  
            Branch,                  
            CustomerShadowAcc,                  
            ShadowAccountType,                 
            ShadowAccountCurrency,                  
            AccountApplictopnType,                  
            ShadowAccApplicationType,                  
            AccountStatus   ,            
            HostTranResponse,            
            HostTranStatus,
            [ID]  
                     
               
    From ClearDetail                  
    Where Status=4                  
          AND ValueDate BETWEEN @DateFrom AND  @DateTo                
          -- Asmaa Hafez [BEGIN: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
          AND (@DepositBranchID = -1 OR Branch = @DepositBranchID)               
          AND ((@DepositDateFrom = '') OR (BusinessDate BETWEEN @DepositDateFrom AND @DepositDateTo))              
          AND (@ChequeNumber = -1 OR ChequeNumber = @ChequeNumber)              
          --  Asmaa Hafez [END: ADIB Retrofitting - CR # 6772 (adding more search criteria)]              
END       
 
 Go
Drop_old_proc TLR_ReturnDrawerAmounts
GO
CREATE PROCEDURE dbo.TLR_ReturnDrawerAmounts  
@LoanAcountNo char(12),
@amount   decimal(21,6)

 
AS
BEGIN
	DECLARE @drawercode nvarchar(25)=''
	DECLARE @commitmentNo nvarchar(12)=''


	SELECT @drawercode=cd.DrawerCode,@commitmentNo=c.CommitmentNumber
	FROM DiscChequesDetail cd LEFT JOIN DiscCheques c 
	ON cd.Track_No = c.Track_No 
	WHERE cd.LoanAccountNumber=@LoanAcountNo

	if((@commitmentNo is not null and @commitmentNo <> '') AND  (@drawercode is not NULL AND  @drawercode<>''))
		BEGIN
			UPDATE CommitmentDrawer 
			SET UtilizedLimit=UtilizedLimit-@Amount,AvailableLimit=AvailableLimit+@Amount 
			WHERE DrawerID=@drawercode AND CommitmentNo=@commitmentNo

			UPDATE Drawer 
			SET UtilizedLimit=UtilizedLimit-@Amount,AvailableLimit=AvailableLimit+@Amount
			WHERE DrawerID=@drawercode
		END
	ELSE
		BEGIN
			RETURN -1
		END


END
GO 
drop_old_proc 'CommitmentDrawerStatus'
go
CREATE PROCEDURE [dbo].[CommitmentDrawerStatus]          
@Months INT  ,         
@businessDate  datetime = '2018-12-12'      
AS            
BEGIN            
/*            
Developer: Mohamed Elabd            
Date:      08-November-2018            
Reason:    Update status of LBD Drawer in GFS Nightly - CBD_ACM15892 - CR# GFSY00740           
*/             
       
-- Update Expiry of CommitmentDrawer that dont have DC cheques          
update CommitmentDrawer      
set Status='Expired'     
WHERE Status='Active' AND ExpiryDate < @businessDate      
AND CommitmentDrawer.DrawerID NOT IN       
(SELECT DrawerCode FROM DiscChequesDetail inner join CommitmentDrawer       
ON CommitmentDrawer.DrawerID = DiscChequesDetail.DrawerCode       
WHERE ChequeStatus in(0,1) AND        
      CommitmentDrawer.CommitmentNo NOT IN       
      (SELECT CommitmentNo FROM DiscCheques inner join CommitmentDrawer      
      on DiscCheques.CommitmentNumber = CommitmentDrawer.CommitmentNo      
      inner join DiscChequesDetail on DiscChequesDetail.DrawerCode = CommitmentDrawer.DrawerID      
      WHERE CommitmentDrawer.Status='Active' AND CommitmentDrawer.ExpiryDate < @businessDate)       
GROUP BY DrawerCode)      
      
      
      
--------------------------------------------------        
DECLARE @DrawerCode VARCHAR(50)           
DECLARE @CommitmentNo VARCHAR(50)        
    
DECLARE db_cursor CURSOR DYNAMIC FOR          
SELECT DrawerID ,CommitmentNo FROM CommitmentDrawer         
where         
Status = 'Active'  and        
DATEADD(month, @Months, CommitmentDrawer.LastChanged) < getdate()          
          
OPEN db_cursor            
FETCH NEXT FROM db_cursor INTO @DrawerCode ,  @CommitmentNo         
          
WHILE @@FETCH_STATUS = 0            
BEGIN                        
         
         
 -- check id SA Drawer have cheques in setup period        
   SELECT COUNT(*) FROM DiscCheques        
   join DiscChequesDetail        
   on DiscCheques.Track_No = DiscChequesDetail.Track_No        
   WHERE DrawerCode = @DrawerCode and        
   CommitmentNumber = @CommitmentNo and         
   ChequeStatus not in (0,1) and         
   DATEADD(month, @Months, DiscCheques.LastChanged) > getdate()        
           
   if (@@ROWCOUNT < 1 )        
   begin        
   UPDATE CommitmentDrawer           
   SET Status = 'DeActivated',          
   LastChanged = getdate()    
   end        
           
           
 FETCH NEXT FROM db_cursor INTO @DrawerCode,@CommitmentNo           
END          
          
CLOSE db_cursor            
DEALLOCATE db_cursor          
        
      
        
           
IF @@ERROR = 0             
BEGIN          
 return 1          
END            
ELSE          
BEGIN          
 return -1          
END          
END      
go
drop_old_proc 'DrawerLastStatus'
go
CREATE PROCEDURE dbo.DrawerLastStatus       
@Months INT  ,    
@businessDate  datetime = '2018-12-12'     
AS        
BEGIN        
/*        
Developer: Mohamed Elabd        
Date:      08-November-2018        
Reason:    Update status of LBD Drawer in GFS Nightly - CBD_ACM15892 - CR# GFSY00740       
*/         
    
DECLARE @DrawerCode VARCHAR(50)    
    
-- Update All active drawers which don`t have cheques in "Booked or Approved" status    
    
update Drawer    
set  Status='Expired'    
WHERE Status='Active' AND ExpiryDate < @businessDate     
AND Drawer.DrawerID NOT IN     
(SELECT DrawerCode FROM DiscChequesDetail inner join Drawer     
ON Drawer.DrawerID = DiscChequesDetail.DrawerCode     
WHERE ChequeStatus in(0,1) GROUP BY DrawerCode)    
     
    
    
-- Check activities for each drawer code in tables (DiscChequesDetail, CommitmentDrawer, Drawer)      
DECLARE db_cursor CURSOR FOR       
SELECT DrawerID  FROM Drawer     
where     
Status = 'Active'  and    
DATEADD(month, @Months, Drawer.LastChanged) < getdate()      
      
OPEN db_cursor        
FETCH NEXT FROM db_cursor INTO @DrawerCode        
      
WHILE @@FETCH_STATUS = 0        
BEGIN                    
     
     
 -- check id SA Drawer have cheques in setup period    
   SELECT  count (DrawerCode) FROM DiscChequesDetail    
   WHERE DrawerCode = @DrawerCode and    
    ChequeStatus not in (0,1) and     
   DATEADD(month, @Months, LastChanged) > getdate()    
   if (@@ROWCOUNT < 1 )    
   begin    
    -- check id SA Drawer have Commitment in setup period    
  SELECT count (DrawerID)       
  FROM CommitmentDrawer       
  WHERE DrawerID = @DrawerCode   AND    
  Status = 'Active' and    
  DATEADD(month, @Months, LastChanged) > getdate()    
  if (@@ROWCOUNT < 1 )    
  begin    
      -- if SA Drawer don`t have Commitment or cheques in setup period     
      -- update status of SA Drawer and all its active relation    
   UPDATE Drawer         
   SET Status = 'DeActivated',        
   DateOfDeactivation = getdate(),        
   LastChanged = getdate()      
   WHERE DrawerID = @DrawerCode      
      
   UPDATE CommitmentDrawer       
   SET Status = 'DeActivated',      
   LastChanged = getdate()      
   WHERE DrawerID = @DrawerCode      
   AND Status = 'Active'    
  end     
   end    
       
       
 FETCH NEXT FROM db_cursor INTO @DrawerCode       
END      
      
CLOSE db_cursor        
DEALLOCATE db_cursor      
    
    
    
IF @@ERROR = 0         
BEGIN      
 return 1      
END        
ELSE      
BEGIN      
 return -1      
END      
    
END        
go
drop_old_proc 'GetDistinctCommitmentNo'
go
CREATE PROCEDURE dbo.GetDistinctCommitmentNo
AS
BEGIN  
/*  
Developer: Mohamed Elabd  
Date:      02-December-2018  
Reason:    GFS Nightly for LBD Drawer - CR# GFSY00732  
*/   
SELECT CommitmentNo,
	(SELECT TOP 1 DrawerLimit
		FROM CommitmentDrawer CD2
		WHERE CD.CommitmentNo = CD2.CommitmentNo) AS 'DrawerLimit',
	(SELECT TOP 1 DrawerLimitInAmount
		FROM CommitmentDrawer CD2 
		WHERE CD.CommitmentNo = CD2.CommitmentNo) AS 'DrawerLimitInAmount'
FROM CommitmentDrawer CD
WHERE Status = 'Active' OR Status = 'Blocked'
GROUP BY CommitmentNo
 
END
GO
drop_old_proc 'GetDrawersLoanAccount'
go
CREATE PROCEDURE dbo.GetDrawersLoanAccount  
AS  
BEGIN    
/*    
Developer: Mohamed Elabd    
Date:      02-December-2018    
Reason:    Get Loan Account from table DiscChequesDetail - CBD_ACM15892 - CR# GFSY00740   
*/     
SELECT LoanAccountNumber,   
DrawerCode  
FROM DiscChequesDetail  
where (DrawerCode IS NOT NULL AND DrawerCode <> '')  
AND (LoanAccountNumber <> '0' AND LoanAccountNumber <> '') 
AND ChequeStatus not in (2,5,6,7,8) 
AND IsPaidOff = 0   
END    
go
drop_old_proc 'LBDDrawerStatus'
go
CREATE PROCEDURE dbo.LBDDrawerStatus      
@BankID INT ,  
@businessDate  datetime = '2018-12-12'         
AS      
BEGIN      
/*      
Developer: Mohamed Elabd      
Date:      08-November-2018      
Reason:    Update status of LBD Drawer in GFS Nightly - CBD_ACM15892 - CR# GFSY00740      
*/       
       
DECLARE @Months INT      
DECLARE @return_status INT    
  
SELECT @Months = [Value]       
FROM BankConfig       
WHERE Name = 'LBD_DrawerActivityMonths'      
AND Bank = @BankID      
    
  
exec  @return_status =  DrawerLastStatus @Months ,@businessDate  
if (@return_status = 1)  
begin  
 exec @return_status = CommitmentDrawerStatus @Months,@businessDate  
end  
else   
 return -1   
   
IF @@ERROR = 0       
BEGIN    
 return 0    
END      
ELSE    
BEGIN    
 return -1    
END    
END      
go
drop_old_proc 'dbo.RecalculateDrawersBalances'
go
CREATE PROCEDURE dbo.RecalculateDrawersBalances
@commitmentNo nvarchar(12),
@currentCommitmentBalance decimal(21,6)
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2018-10-21
	Reason		: CBD_ACM15892_LBD Drawer
    */
	DECLARE @DrawerLimitPercentage float
	DECLARE @DrawerID nvarchar(50)
	DECLARE @DrawerLimitInAmount decimal(21,6)
	
	DECLARE DRAWER_CURSOR CURSOR  
	DYNAMIC  FOR  
	SELECT DrawerLimit,DrawerID,DrawerLimitInAmount 
	FROM CommitmentDrawer WHERE CommitmentNo=@commitmentNo
	
	OPEN DRAWER_CURSOR
	FETCH NEXT FROM DRAWER_CURSOR INTO  @DrawerLimitPercentage,@DrawerID,@DrawerLimitInAmount
	WHILE @@FETCH_STATUS = 0      
	BEGIN
		DECLARE @SumOfDrawerLimitInAmount decimal(21,6)
		DECLARE @CurrentDrawerLimitInAmount decimal(21,6)
		
		SET @CurrentDrawerLimitInAmount = (@DrawerLimitPercentage/100) * @currentCommitmentBalance
		-->>Check if DrawerLimitInAmount in CommitmentDrawer is same as calculated or not.
		-->>If they are not equal, start recalculations.
		IF(@CurrentDrawerLimitInAmount != @DrawerLimitInAmount)
		BEGIN
			-->>First, set DrawerLimitInAmount in CommitmentDrawer with new calculate amount .
			UPDATE CommitmentDrawer
			SET DrawerLimitInAmount = @CurrentDrawerLimitInAmount
			WHERE DrawerID=@DrawerID AND CommitmentNo=@commitmentNo
				AND (Status='Active' OR Status='Blocked')
			-->>Then, update this CommitmentDrawer AvailableLimit.
			UPDATE CommitmentDrawer
			SET AvailableLimit=DrawerLimitInAmount-UtilizedLimit
			WHERE DrawerID=@DrawerID AND CommitmentNo=@commitmentNo
				AND (Status='Active' OR Status='Blocked')
			-->>After that, select sum of DrawerLimitInAmount of this drawer in CommitmentDrawer
			-->>To update Drawer TotalAssignedAmount with summation value.
			SELECT @SumOfDrawerLimitInAmount = SUM(DrawerLimitInAmount) 
			FROM CommitmentDrawer 
			WHERE DrawerID=@DrawerID AND (Status='Active' OR Status='Blocked')
			-->>Finally, update Drawer TotalAssignedAmount with summation value.
			UPDATE Drawer
			SET TotalAssignedAmount=@SumOfDrawerLimitInAmount
			WHERE DrawerID=@DrawerID AND (Status='Active' OR Status='Blocked')
		END
	FETCH  FROM DRAWER_CURSOR INTO  @DrawerLimitPercentage,@DrawerID,@DrawerLimitInAmount
	END
	CLOSE DRAWER_CURSOR
	DEALLOCATE DRAWER_CURSOR
GO
USE [Globalfs]
GO
/****** Object:  Trigger [dbo].[TR_auto_CommitmentDrawer_update]    Script Date: 11/08/2018 13:55:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
drop_old_trigger 'TR_auto_CommitmentDrawer_update'
go
CREATE TRIGGER [dbo].[TR_auto_CommitmentDrawer_update]
ON [dbo].[CommitmentDrawer]
AFTER UPDATE NOT FOR REPLICATION  
AS
-- SET LastChanged = getdate(), Updator = system_user - to help audit updates.
-- Copyright 2001, 2003, 2006 GetronicsWang Co., LLC.  All rights reserved
-- DO NOT EDIT!!! THIS TRIGGER IS PRODUCED DYNAMICALLY BY THE BUILD
-- with procedure p_Create_Update_Triggers version of 16Aug07.
if @@ROWCOUNT = 0 return -- If no rows affected, exit immediately.
-- Note: if the WHERE clause is satisfied,
      -- Then @@rowcount will be > 0 even if no column value really changed.
set nocount on
 
declare @Now DateTime
SET @Now = getdate()

declare @Updator OperatorID 
set @Updator = system_user
if (update(Updator)) begin 
    select @Updator = Updator from inserted

    if ((dbo.is_anonymous(@Updator)=0) and (dbo.f_user_number_of_LoginID (@Updator) is null)) begin
        raiserror('You, "%s", must be a known user in the Operator table.',16,1, @Updator)
        if @@TRANCOUNT > 0
        rollback transaction
        return
    end
end
if (system_user <> @updator) and (dbo.is_anonymous(system_user)=0) begin
    declare @msg varchar(500)
    set @msg = 'You may not impersonate another user ('+system_user+' is impersonating '+ @updator +').'
    raiserror(@msg,16,1)
    if @@TRANCOUNT > 0
    rollback transaction
    return
end

if update(Row_ID) 
   if exists (select 1 from deleted d 
              where not exists (select 1 from inserted i 
                                where i.Row_ID = d.Row_ID))
   begin
        raiserror('You may not update the Row_ID column.',16,1) with log
        if @@TRANCOUNT > 0
            rollback transaction
        return
   end  

if (not update(Updator) ) 
    update This_Table set LastChanged = @Now, Updator = @Updator
    from inserted 
    join dbo.CommitmentDrawer as This_Table 
    on This_Table.Row_ID = inserted.Row_ID
    OPTION (FORCE ORDER)
else
    update This_Table set LastChanged = @Now
    from inserted 
    join dbo.CommitmentDrawer as This_Table 
    on This_Table.Row_ID = inserted.Row_ID
    and This_Table.LastChanged < @Now
    OPTION (FORCE ORDER)
GO
USE [Globalfs]
GO
/****** Object:  Trigger [dbo].[TR_auto_Drawer_update]    Script Date: 11/08/2018 13:55:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
DROP_old_trigger 'TR_auto_Drawer_update'
GO
CREATE TRIGGER [dbo].[TR_auto_Drawer_update]
ON [dbo].[Drawer]
AFTER UPDATE NOT FOR REPLICATION  
AS
-- SET LastChanged = getdate(), Updator = system_user - to help audit updates.
-- Copyright 2001, 2003, 2006 GetronicsWang Co., LLC.  All rights reserved
-- DO NOT EDIT!!! THIS TRIGGER IS PRODUCED DYNAMICALLY BY THE BUILD
-- with procedure p_Create_Update_Triggers version of 16Aug07.
if @@ROWCOUNT = 0 return -- If no rows affected, exit immediately.
-- Note: if the WHERE clause is satisfied,
      -- Then @@rowcount will be > 0 even if no column value really changed.
set nocount on
 
declare @Now DateTime
SET @Now = getdate()

declare @Updator OperatorID 
set @Updator = system_user
if (update(Updator)) begin 
    select @Updator = Updator from inserted

    if ((dbo.is_anonymous(@Updator)=0) and (dbo.f_user_number_of_LoginID (@Updator) is null)) begin
        raiserror('You, "%s", must be a known user in the Operator table.',16,1, @Updator)
        if @@TRANCOUNT > 0
        rollback transaction
        return
    end
end
if (system_user <> @updator) and (dbo.is_anonymous(system_user)=0) begin
    declare @msg varchar(500)
    set @msg = 'You may not impersonate another user ('+system_user+' is impersonating '+ @updator +').'
    raiserror(@msg,16,1)
    if @@TRANCOUNT > 0
    rollback transaction
    return
end

if update(Row_ID) 
   if exists (select 1 from deleted d 
              where not exists (select 1 from inserted i 
                                where i.Row_ID = d.Row_ID))
   begin
        raiserror('You may not update the Row_ID column.',16,1) with log
        if @@TRANCOUNT > 0
            rollback transaction
        return
   end  

if (not update(Updator) ) 
    update This_Table set LastChanged = @Now, Updator = @Updator
    from inserted 
    join dbo.Drawer as This_Table 
    on This_Table.Row_ID = inserted.Row_ID
    OPTION (FORCE ORDER)
else
    update This_Table set LastChanged = @Now
    from inserted 
    join dbo.Drawer as This_Table 
    on This_Table.Row_ID = inserted.Row_ID
    and This_Table.LastChanged < @Now
    OPTION (FORCE ORDER)
GO
drop_old_proc 'dbo.UpdateDrawerBalances'
go
CREATE PROCEDURE dbo.UpdateDrawerBalances
@commitmentNo nvarchar(12),
@drawerID varchar(25),
@chequeApprovedAmount decimal(21,6)
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2018-10-21
	Reason		: CBD_ACM15892_LBD Drawer
    */
	UPDATE CommitmentDrawer
	SET UtilizedLimit = UtilizedLimit + @chequeApprovedAmount,
		AvailableLimit = AvailableLimit - @chequeApprovedAmount
	WHERE CommitmentNo=@commitmentNo AND DrawerID=@drawerID
		AND (Status='Active' OR Status='Blocked')
	
	UPDATE Drawer
	SET UtilizedLimit = UtilizedLimit + @chequeApprovedAmount,
		AvailableLimit = AvailableLimit - @chequeApprovedAmount
	WHERE DrawerID=@drawerID AND (Status='Active' OR Status='Blocked')
GO
drop_old_proc 'UpdateDrawerPastDue'
go
CREATE PROCEDURE dbo.UpdateDrawerPastDue
	@DrawerCodeTT [PastDueDrawersCodesTableType] readonly
AS  
BEGIN    
/*    
Developer: Mohamed Elabd    
Date:      02-December-2018    
Reason:    Update PastDue flag in GFS Nightly - CBD_ACM15892 - CR# GFSY00740    
*/     

--UPDATE Drawer SET PastDue = 1 WHERE DrawerID = @DrawerCode

	UPDATE D
	SET D.PastDue = 1
	FROM Drawer D
    INNER JOIN @DrawerCodeTT DTT
    ON DTT.DrawerCode = D.DrawerID
    WHERE D.PastDue != 1
   
END  
GO  
drop_old_proc 'dbo.ValidateLBDDrawer'
go
CREATE PROCEDURE dbo.ValidateLBDDrawer 
@TranName nvarchar(100),
@RimNumber int, 
@commitmentNo nvarchar(12) = null,  
@drawerID nvarchar(25) = null,  
@chequeAmount decimal(21,6) = null,  
@currentCommitmentBalance decimal(21,6) = null,  
@chequeMaturityDate date = null, 
@currentCommitmentExpiryDate date = null, 
@validateTotalAmount bit = 0 AS 
/* 
Developer: Mostafa Sayed 
Date	 : 2018-10-21 
Reason	 : CBD_ACM15892_LBD Drawer  
  
Error codes:  
-1  if cheque amount is greater than commitment amount  
-2  if cheque maturity date is greater than commitment maturity date  
-3  if cheque amount is greater than available balance in drawer  
-4  if cheque maturity date is greater than commitment drawer expiry date 
-5  if SA Drawer status is not active 
-6  if link between drawer and commitment status is not active 
-7  if SA Drawer is Past Due 
-8  if totalAmount of cheques is greater than drawer available balance  
-9  if totalAmount of cheques is greater than SA drawer available balance  
-10 if totalAmount of cheques is greater than commitment available balance  
-11 if cheque amount is greater than available balance in SA drawer  
-12 if cheque maturity date is greater than SA drawer expiry date
-13 if UtilizedLimit is greater than DrawerLimitInAmount in CommitmentDrawer

Error Types:  
w = warning  
s = stop
 */  
  
CREATE TABLE #Errors  
(ErrorNo int, ErrorType char(1), ErrorDescription nvarchar(max))  

DECLARE @SADrawerAvailableBalance decimal(21,6) 
DECLARE @SADrawerExpiryDate date  
DECLARE @SADrawerStatus char(30)  
DECLARE @SADrawerPastDue bit  

DECLARE @DrawerAvailableBalance decimal(21,6)  
DECLARE @DrawerExpiryDate date  
DECLARE @CommitmentDrawerStatus nvarchar(20)  
DECLARE @DrawerName nvarchar(100)
DECLARE @DrawerLimitInAmount decimal(21,6)
DECLARE @UtilizedLimit decimal(21,6)

  
SELECT @DrawerAvailableBalance = AvailableLimit,  
	   @DrawerExpiryDate = ExpiryDate,  
	   @CommitmentDrawerStatus = Status,
	   @DrawerLimitInAmount = DrawerLimitInAmount,
	   @UtilizedLimit = UtilizedLimit
FROM CommitmentDrawer  
WHERE CommitmentNo = @commitmentNo AND DrawerID = @drawerID

SELECT @SADrawerStatus = Status,  
	   @SADrawerPastDue = PastDue,
       @SADrawerAvailableBalance = AvailableLimit,
       @DrawerName = DrawerName,
       @SADrawerExpiryDate = ExpiryDate
FROM Drawer 
WHERE DrawerID = @drawerID  

SET @UtilizedLimit = @UtilizedLimit + @chequeAmount
  
IF(@TranName = 'DiscountedChequesApproval')  
BEGIN  
	 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Amount ' + cast(@currentCommitmentBalance as varchar))  
	 END  

	 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND  
	  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-2,'w',N'Cheque Maturity Date Is Greater Than Commitment ('+@commitmentNo+') Expiry Date')  
	 END  
	   
	 IF(@chequeAmount IS NOT NULL  AND @DrawerAvailableBalance IS NOT NULL AND   
	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ('+@DrawerName+') ' + cast(@DrawerAvailableBalance as varchar))  
	 END  
	   
	 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND  
	  (@chequeMaturityDate > @DrawerExpiryDate))  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DrawerName+') Expiry Date')  
	 END  
	   
	 IF(LOWER(@SADrawerStatus) != 'active' AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-5,'s',N'SA Drawer ('+@DrawerName+') Not Active')  
	 END  
	  
	 IF(LOWER(@CommitmentDrawerStatus) != 'active' AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-6,'s',N'Drawer ('+@DrawerName+') Linked To Commitment ('+@commitmentNo+') Is Not Active')  
	 END  
	 
	 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-7,'w',N'Drawer ('+@DrawerName+') Is Past Due')  
	 END  
	 
	 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Drawer ('+@DrawerName+') Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
	 END
	 
	 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DrawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
	 END  
	 
	 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
	 END 
	 
	 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
	 END 
	 
	 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  
	  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DrawerName+') Expiry Date')  
	 END  
	 
	 IF(@UtilizedLimit > @DrawerLimitInAmount AND @validateTotalAmount != 1)
	 BEGIN
		INSERT INTO #Errors  
		VALUES(-13,'w',N'Utilized Amount Will Be Greater Than Drawer Limit In Drawer ('+@DrawerName+') Commitment ('+@commitmentNo+')') 
	 END
END  
ELSE IF(@TranName = 'DiscountedChequeBooking')  
BEGIN  
	 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment Amount ' + cast(@currentCommitmentBalance as varchar))  
	 END  
	  
	 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND   
	  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-2,'s',N'Cheque Maturity Date Is Greater Than Commitment Expiry Date')  
	 END  
	   
	 IF(@chequeAmount IS NOT NULL AND @DrawerAvailableBalance IS NOT NULL AND   
	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ' + cast(@DrawerAvailableBalance as varchar))  
	 END  
	   
	 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND   
	  (@chequeMaturityDate > @DrawerExpiryDate))  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DrawerName+') Expiry Date')  
	 END  
	   
	 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-7,'w',N'Drawer ('+@DrawerName+') Is Past Due')  
	 END  
	   
	 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Drawer Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
	 END
	 
	 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DrawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
	 END  
	 
	 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
	 END 
	 
	 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
	 END   
	 
	 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  
	  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DrawerName+') Expiry Date')  
	 END  
	 
	 IF(@UtilizedLimit > @DrawerLimitInAmount AND @validateTotalAmount != 1)
	 BEGIN
		INSERT INTO #Errors  
		VALUES(-13,'w',N'Utilized Amount Will Be Greater Than Drawer Limit In Drawer ('+@DrawerName+') Commitment ('+@commitmentNo+')') 
	 END
END  
	SELECT * FROM #Errors 
GO
drop_old_proc 'dbo.RecalculateDrawersBalances'
go
CREATE PROCEDURE dbo.RecalculateDrawersBalances
@commitmentNo nvarchar(12),
@currentCommitmentBalance decimal(21,6)
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2018-10-21
	Reason		: CBD_ACM15892_LBD Drawer
    */
	DECLARE @DrawerLimitPercentage float
	DECLARE @DrawerID nvarchar(50)
	DECLARE @DrawerLimitInAmount decimal(21,6)
	
	DECLARE DRAWER_CURSOR CURSOR  
	DYNAMIC  FOR  
	SELECT DrawerLimit,DrawerID,DrawerLimitInAmount 
	FROM CommitmentDrawer WHERE CommitmentNo=@commitmentNo
	
	OPEN DRAWER_CURSOR
	FETCH NEXT FROM DRAWER_CURSOR INTO  @DrawerLimitPercentage,@DrawerID,@DrawerLimitInAmount
	WHILE @@FETCH_STATUS = 0      
	BEGIN
		DECLARE @SumOfDrawerLimitInAmount decimal(21,6)
		DECLARE @CurrentDrawerLimitInAmount decimal(21,6)
		
		SET @CurrentDrawerLimitInAmount = (@DrawerLimitPercentage/100) * @currentCommitmentBalance
		-->>Check if DrawerLimitInAmount in CommitmentDrawer is same as calculated or not.
		-->>If they are not equal, start recalculations.
		IF(@CurrentDrawerLimitInAmount != @DrawerLimitInAmount)
		BEGIN
			-->>First, set DrawerLimitInAmount in CommitmentDrawer with new calculate amount .
			UPDATE CommitmentDrawer
			SET DrawerLimitInAmount = @CurrentDrawerLimitInAmount
			WHERE DrawerID=@DrawerID AND CommitmentNo=@commitmentNo
				AND (Status='Active' OR Status='Blocked')
			-->>Then, update this CommitmentDrawer AvailableLimit.
			UPDATE CommitmentDrawer
			SET AvailableLimit=DrawerLimitInAmount-UtilizedLimit
			WHERE DrawerID=@DrawerID AND CommitmentNo=@commitmentNo
				AND (Status='Active' OR Status='Blocked')
			-->>After that, select sum of DrawerLimitInAmount of this drawer in CommitmentDrawer
			-->>To update Drawer TotalAssignedAmount with summation value.
			SELECT @SumOfDrawerLimitInAmount = SUM(DrawerLimitInAmount) 
			FROM CommitmentDrawer 
			WHERE DrawerID=@DrawerID AND (Status='Active' OR Status='Blocked')
			-->>Finally, update Drawer TotalAssignedAmount with summation value.
			UPDATE Drawer
			SET TotalAssignedAmount=@SumOfDrawerLimitInAmount
			WHERE DrawerID=@DrawerID AND (Status='Active' OR Status='Blocked')
		END
	FETCH  FROM DRAWER_CURSOR INTO  @DrawerLimitPercentage,@DrawerID,@DrawerLimitInAmount
	END
	CLOSE DRAWER_CURSOR
	DEALLOCATE DRAWER_CURSOR
GO
drop_old_proc 'dbo.UpdateDrawerBalances'
go
CREATE PROCEDURE dbo.UpdateDrawerBalances
@commitmentNo nvarchar(12),
@drawerID varchar(25),
@chequeApprovedAmount decimal(21,6)
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2018-10-21
	Reason		: CBD_ACM15892_LBD Drawer
    */
	UPDATE CommitmentDrawer
	SET UtilizedLimit = UtilizedLimit + @chequeApprovedAmount,
		AvailableLimit = AvailableLimit - @chequeApprovedAmount
	WHERE CommitmentNo=@commitmentNo AND DrawerID=@drawerID
		AND (Status='Active' OR Status='Blocked')
	
	UPDATE Drawer
	SET UtilizedLimit = UtilizedLimit + @chequeApprovedAmount,
		AvailableLimit = AvailableLimit - @chequeApprovedAmount
	WHERE DrawerID=@drawerID AND (Status='Active' OR Status='Blocked')
GO
drop_old_proc 'dbo.ValidateLBDDrawer'
go
CREATE PROCEDURE dbo.ValidateLBDDrawer 
@TranName nvarchar(100),
@RimNumber int, 
@commitmentNo nvarchar(12) = null,  
@drawerID nvarchar(25) = null,  
@chequeAmount decimal(21,6) = null,  
@currentCommitmentBalance decimal(21,6) = null,  
@chequeMaturityDate date = null, 
@currentCommitmentExpiryDate date = null, 
@validateTotalAmount bit = 0 AS 
/* 
Developer: Mostafa Sayed 
Date	 : 2018-10-21 
Reason	 : CBD_ACM15892_LBD Drawer  
  
Error codes:  
-1  if cheque amount is greater than commitment amount  
-2  if cheque maturity date is greater than commitment maturity date  
-3  if cheque amount is greater than available balance in drawer  
-4  if cheque maturity date is greater than commitment drawer expiry date 
-5  if SA Drawer status is not active 
-6  if link between drawer and commitment status is not active 
-7  if SA Drawer is Past Due 
-8  if totalAmount of cheques is greater than drawer available balance  
-9  if totalAmount of cheques is greater than SA drawer available balance  
-10 if totalAmount of cheques is greater than commitment available balance  
-11 if cheque amount is greater than available balance in SA drawer  
-12 if cheque maturity date is greater than SA drawer expiry date
-13 if UtilizedLimit is greater than DrawerLimitInAmount in CommitmentDrawer

Error Types:  
w = warning  
s = stop
 */  
  
CREATE TABLE #Errors  
(ErrorNo int, ErrorType char(1), ErrorDescription nvarchar(max))  

DECLARE @SADrawerAvailableBalance decimal(21,6) 
DECLARE @SADrawerExpiryDate date  
DECLARE @SADrawerStatus char(30)  
DECLARE @SADrawerPastDue bit  

DECLARE @DrawerAvailableBalance decimal(21,6)  
DECLARE @DrawerExpiryDate date  
DECLARE @CommitmentDrawerStatus nvarchar(20)  
DECLARE @DrawerName nvarchar(100)
DECLARE @DrawerLimitInAmount decimal(21,6)
DECLARE @UtilizedLimit decimal(21,6)

  
SELECT @DrawerAvailableBalance = AvailableLimit,  
	   @DrawerExpiryDate = ExpiryDate,  
	   @CommitmentDrawerStatus = Status,
	   @DrawerLimitInAmount = DrawerLimitInAmount,
	   @UtilizedLimit = UtilizedLimit
FROM CommitmentDrawer  
WHERE CommitmentNo = @commitmentNo AND DrawerID = @drawerID

SELECT @SADrawerStatus = Status,  
	   @SADrawerPastDue = PastDue,
       @SADrawerAvailableBalance = AvailableLimit,
       @DrawerName = DrawerName,
       @SADrawerExpiryDate = ExpiryDate
FROM Drawer 
WHERE DrawerID = @drawerID  

SET @UtilizedLimit = @UtilizedLimit + @chequeAmount
  
IF(@TranName = 'DiscountedChequesApproval')  
BEGIN  
	 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Amount ' + cast(@currentCommitmentBalance as varchar))  
	 END  

	 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND  
	  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-2,'w',N'Cheque Maturity Date Is Greater Than Commitment ('+@commitmentNo+') Expiry Date')  
	 END  
	   
	 IF(@chequeAmount IS NOT NULL  AND @DrawerAvailableBalance IS NOT NULL AND   
	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ('+@DrawerName+') ' + cast(@DrawerAvailableBalance as varchar))  
	 END  
	   
	 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND  
	  (@chequeMaturityDate > @DrawerExpiryDate))  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DrawerName+') Expiry Date')  
	 END  
	   
	 IF(LOWER(@SADrawerStatus) != 'active' AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-5,'s',N'SA Drawer ('+@DrawerName+') Not Active')  
	 END  
	  
	 IF(LOWER(@CommitmentDrawerStatus) != 'active' AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-6,'s',N'Drawer ('+@DrawerName+') Linked To Commitment ('+@commitmentNo+') Is Not Active')  
	 END  
	 
	 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-7,'w',N'Drawer ('+@DrawerName+') Is Past Due')  
	 END  
	 
	 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Drawer ('+@DrawerName+') Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
	 END
	 
	 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DrawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
	 END  
	 
	 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
	 END 
	 
	 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
	 END 
	 
	 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  
	  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DrawerName+') Expiry Date')  
	 END  
	 
	 IF(@UtilizedLimit > @DrawerLimitInAmount AND @validateTotalAmount != 1)
	 BEGIN
		INSERT INTO #Errors  
		VALUES(-13,'w',N'Utilized Amount Will Be Greater Than Drawer Limit In Drawer ('+@DrawerName+') Commitment ('+@commitmentNo+')') 
	 END
END  
ELSE IF(@TranName = 'DiscountedChequeBooking')  
BEGIN  
	 IF(@chequeAmount IS NOT NULL AND @currentCommitmentBalance IS NOT NULL AND   
	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-1,'w',N'Cheque Amount Is Greater Than Commitment Amount ' + cast(@currentCommitmentBalance as varchar))  
	 END  
	  
	 IF(@chequeMaturityDate IS NOT NULL AND @currentCommitmentExpiryDate IS NOT NULL AND   
	  (@chequeMaturityDate > @currentCommitmentExpiryDate))  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-2,'s',N'Cheque Maturity Date Is Greater Than Commitment Expiry Date')  
	 END  
	   
	 IF(@chequeAmount IS NOT NULL AND @DrawerAvailableBalance IS NOT NULL AND   
	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-3,'w',N'Cheque Amount Is Greater Than Available Balance In Drawer ' + cast(@DrawerAvailableBalance as varchar))  
	 END  
	   
	 IF(@chequeMaturityDate IS NOT NULL AND @DrawerExpiryDate IS NOT NULL AND   
	  (@chequeMaturityDate > @DrawerExpiryDate))  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-4,'w',N'Cheque Maturity Date Is Greater Than Commitment Drawer ('+@DrawerName+') Expiry Date')  
	 END  
	   
	 IF(@SADrawerPastDue = 1 AND @validateTotalAmount = 0)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-7,'w',N'Drawer ('+@DrawerName+') Is Past Due')  
	 END  
	   
	 IF(@DrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @DrawerAvailableBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-8,'w',N'Total Cheque Amount Is Greater Than Drawer Available Balance ' + cast(@DrawerAvailableBalance as varchar))  
	 END
	 
	 IF(@SADrawerAvailableBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-9,'w',N'Total Cheque Amount Is Greater Than SA Drawer ('+@DrawerName+') Available Balance ' + cast(@SADrawerAvailableBalance as varchar))  
	 END  
	 
	 IF(@currentCommitmentBalance IS NOT NULL AND @chequeAmount IS NOT NULL AND  
	  (@chequeAmount > @currentCommitmentBalance) AND @validateTotalAmount = 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-10,'w',N'Total Cheque Amount Is Greater Than Commitment ('+@commitmentNo+') Available Balance ' + cast(@currentCommitmentBalance as varchar))  
	 END 
	 
	 IF(@chequeAmount IS NOT NULL AND @SADrawerAvailableBalance IS NOT NULL AND   
	  (@chequeAmount > @SADrawerAvailableBalance) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-11,'w',N'Cheque Amount Is Greater Than Available Balance In SA Drawer ' + cast(@SADrawerAvailableBalance as varchar))  
	 END   
	 
	 IF(@chequeMaturityDate IS NOT NULL AND @SADrawerExpiryDate IS NOT NULL AND  
	  (@chequeMaturityDate > @SADrawerExpiryDate) AND @validateTotalAmount != 1)  
	 BEGIN  
		INSERT INTO #Errors  
		VALUES(-12,'w',N'Cheque Maturity Date Is Greater Than SA Drawer ('+@DrawerName+') Expiry Date')  
	 END  
	 
	 IF(@UtilizedLimit > @DrawerLimitInAmount AND @validateTotalAmount != 1)
	 BEGIN
		INSERT INTO #Errors  
		VALUES(-13,'w',N'Utilized Amount Will Be Greater Than Drawer Limit In Drawer ('+@DrawerName+') Commitment ('+@commitmentNo+')') 
	 END
END  
	SELECT * FROM #Errors 
GO
drop_old_proc 'CommitmentDrawerStatus'
go
CREATE PROCEDURE [dbo].[CommitmentDrawerStatus]          
@Months INT  ,         
@businessDate  datetime = '2018-12-12'      
AS            
BEGIN            
/*            
Developer: Mohamed Elabd            
Date:      08-November-2018            
Reason:    Update status of LBD Drawer in GFS Nightly - CBD_ACM15892 - CR# GFSY00740    

Modifier:	Mostafa Sayed
Date	:	[1/01/2019] 
Reason	:	GFSX13472          
*/             
       
-- Update Expiry of CommitmentDrawer that dont have DC cheques          
UPDATE CommitmentDrawer      
SET Status='Expired'     
WHERE Status='Active' AND ExpiryDate < @businessDate      
AND CommitmentDrawer.DrawerID NOT IN       
(SELECT DrawerCode FROM DiscChequesDetail INNER JOIN CommitmentDrawer       
ON CommitmentDrawer.DrawerID = DiscChequesDetail.DrawerCode       
WHERE ChequeStatus IN(0,1) AND        
      CommitmentDrawer.CommitmentNo NOT IN       
      (SELECT CommitmentNo FROM DiscCheques INNER JOIN CommitmentDrawer      
      ON DiscCheques.CommitmentNumber = CommitmentDrawer.CommitmentNo      
      INNER JOIN DiscChequesDetail ON DiscChequesDetail.DrawerCode = CommitmentDrawer.DrawerID      
      WHERE CommitmentDrawer.Status='Active' AND CommitmentDrawer.ExpiryDate < @businessDate)       
GROUP BY DrawerCode)      
      
      
      
--------------------------------------------------        
--DECLARE @DrawerCode VARCHAR(50)           
--DECLARE @CommitmentNo VARCHAR(50)        
    
--DECLARE db_cursor CURSOR DYNAMIC FOR          
--SELECT DrawerID ,CommitmentNo FROM CommitmentDrawer         
--WHERE         
--Status = 'Active'  and        
----DATEADD(month, @Months, CommitmentDrawer.LastChanged) 
--DATEADD(month, @Months, DATEDIFF(dd, 0, CommitmentDrawer.LastChanged)) < @businessDate --getdate()          
          
--OPEN db_cursor            
--FETCH NEXT FROM db_cursor INTO @DrawerCode ,  @CommitmentNo         
          
--WHILE @@FETCH_STATUS = 0            
--BEGIN                        
         
         
-- -- check id SA Drawer have cheques in setup period        
--   SELECT COUNT(*) FROM DiscCheques        
--   JOIN DiscChequesDetail        
--   ON DiscCheques.Track_No = DiscChequesDetail.Track_No        
--   WHERE DrawerCode = @DrawerCode and        
--   CommitmentNumber = @CommitmentNo and         
--   --ChequeStatus not in (0,1) and
--   --DATEADD(month, @Months, DiscCheques.LastChanged) 
--   ChequeStatus IN (0,1) AND 
--   DATEADD(month, @Months, DATEDIFF(dd, 0, DiscCheques.LastChanged)) > @businessDate--getdate()        
           
--   IF (@@ROWCOUNT < 1 )        
--   BEGIN        
--	   UPDATE CommitmentDrawer           
--	   SET Status = 'DeActivated',          
--	   LastChanged = @businessDate--getdate()    
--	   WHERE Status='Active' AND DrawerID=@DrawerCode AND CommitmentNo=@CommitmentNo
--   END        
           
           
-- FETCH NEXT FROM db_cursor INTO @DrawerCode,@CommitmentNo           
--END          
          
--CLOSE db_cursor            
--DEALLOCATE db_cursor          
        
      
UPDATE CommitmentDrawer 
SET Status='DeActivated'
WHERE Status='Active' 
AND DATEADD(MONTH, @Months, DATEDIFF(dd, 0, CommitmentDrawer.LastChanged))< @businessDate
AND CommitmentDrawer.DrawerID NOT IN       
(SELECT DrawerCode FROM DiscChequesDetail 
	INNER JOIN CommitmentDrawer 
	ON CommitmentDrawer.DrawerID = DiscChequesDetail.DrawerCode  
	INNER JOIN DiscCheques
	ON DiscCheques.CommitmentNumber = CommitmentDrawer.CommitmentNo     
	WHERE ChequeStatus IN(0,1))
	
           
IF @@ERROR = 0             
BEGIN          
 return 1          
END            
ELSE          
BEGIN          
 return -1          
END          
END      
go
drop_old_proc 'DrawerLastStatus'
go
CREATE PROCEDURE dbo.DrawerLastStatus       
@Months INT  ,    
@businessDate  datetime = '2018-12-12'     
AS        
BEGIN        
/*        
Developer: Mohamed Elabd        
Date:      08-November-2018        
Reason:    Update status of LBD Drawer in GFS Nightly - CBD_ACM15892 - CR# GFSY00740 

Modifier:	Mostafa Sayed
Date	:	[1/01/2019] 
Reason	:	GFSX13472     
*/         
    
DECLARE @DrawerCode VARCHAR(50)    
CREATE TABLE #DeActivatedDrawerCodes
(DraweCode nvarchar(25))
CREATE TABLE #ExpiredDrawerCodes
(DraweCode nvarchar(25))
    
-- Update All active drawers which don`t have cheques in "Booked or Approved" status    
--UPDATE Drawer    
--SET  Status='Expired'    
--WHERE Status='Active' AND ExpiryDate < @businessDate     
--AND Drawer.DrawerID NOT IN     
--(SELECT DrawerCode FROM DiscChequesDetail inner join Drawer     
--ON Drawer.DrawerID = DiscChequesDetail.DrawerCode     
--WHERE ChequeStatus in(0,1) GROUP BY DrawerCode)    

INSERT INTO #ExpiredDrawerCodes
SELECT DrawerID FROM Drawer    
WHERE Status='Active' AND ExpiryDate < @businessDate     
AND Drawer.DrawerID NOT IN     
(SELECT DrawerCode FROM DiscChequesDetail INNER JOIN Drawer     
ON Drawer.DrawerID = DiscChequesDetail.DrawerCode     
WHERE ChequeStatus IN(0,1) GROUP BY DrawerCode) 

--Update Drawer & CommitmentDrawer status to 'Expired'
UPDATE Drawer         
SET Status = 'Expired'
WHERE DrawerID IN (SELECT DraweCode FROM #ExpiredDrawerCodes) AND Status= 'Active'
	
UPDATE CommitmentDrawer       
SET Status = 'Expired'   
WHERE DrawerID IN (SELECT DraweCode FROM #ExpiredDrawerCodes) AND Status = 'Active' 

-- Check activities for each drawer code in tables (DiscChequesDetail, CommitmentDrawer, Drawer)      
INSERT INTO #DeActivatedDrawerCodes
SELECT Drawer.DrawerID FROM Drawer   
WHERE Status='Active' AND
DATEADD(MONTH, @Months, DATEDIFF(dd, 0, Drawer.LastChanged))< @businessDate
AND Drawer.DrawerID NOT IN     
(SELECT DrawerCode FROM DiscChequesDetail 
	INNER JOIN Drawer     
	ON Drawer.DrawerID = DiscChequesDetail.DrawerCode 
	RIGHT JOIN CommitmentDrawer 
	ON Drawer.DrawerID = CommitmentDrawer.DrawerID    
	WHERE ChequeStatus in(0,1) GROUP BY DrawerCode)
--AND Drawer.DrawerID IN
--(SELECT CommitmentDrawer.DrawerID FROM CommitmentDrawer  
--	 WHERE CommitmentDrawer.Status = 'Active' 
--	 AND DATEADD(MONTH, @Months, DATEDIFF(dd, 0, CommitmentDrawer.LastChanged))< @businessDate)

--Update Drawer & CommitmentDrawer status to 'DeActivated'
UPDATE Drawer         
SET Status = 'DeActivated',        
DateOfDeactivation = @businessDate
WHERE DrawerID IN (SELECT DraweCode FROM #DeActivatedDrawerCodes) AND Status= 'Active'
	
UPDATE CommitmentDrawer       
SET Status = 'DeActivated'   
WHERE DrawerID IN (SELECT DraweCode FROM #DeActivatedDrawerCodes) AND Status = 'Active' 
    
IF @@ERROR = 0         
BEGIN      
 return 1      
END        
ELSE      
BEGIN      
 return -1      
END      
    
END        
go