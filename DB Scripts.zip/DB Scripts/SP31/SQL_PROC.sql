--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Get_Recived_Override_Request
Go


create PROCEDURE dbo.Get_Recived_Override_Request  --dbo.Get_Recived_Override_Request 1,1,1,639,'20111009'      
          
@BankID tinyint,          
@RegionID tinyint,          
@BranchID smallint,          
@UserNumber smallint,          
@BusinessDate   Datetime,
@LCID int           
          
/*          
CreationDate: 27/5/2007          
OriginalName: dbo.Get_Recived_Override_Request          
Programmer: Karim Taha          
Description: get the recived override request for given user          
Output:            
Assumption:           
*/          
        
/*        
Modify Date: 9/12/2007        
Developer: Adel Shaban        
Reasons:To Return Dummy column 'StatusString'        
*/       
      
/*      
Modify Date: 17/08/2009        
Developer: Shimaa Saeed      
Reasons: join with tables  rulestranname,rulesdescriptor to get transaction description not transaction name      
  
  
Modifier: Osama Orabi  
Date : 2010-03-23  
Reason : Performance Tuning  

Modifier: Mostafa Sayed
Date : 2017-12-14 
Reason : Get Local Descriptors of transctions' names

Modifier: MAhmoud Saad
Date : 2018-07-02 
Reason : The pending overrides are not showing (Return Pending Overrides)
*/        
        
as     
  
SET NOCOUNT ON  
       
declare @useloginid nvarchar(50)          
          
select @useloginid = loginid           
from operator          
where user_number = @UserNumber          
        
declare @StatusString varchar(50);        
set @StatusString='';        

select DISTINCT ( O.RequestID), Descriptor as TransactionName,CASE WHEN LD.LocalDescription IS NULL THEN D.Descriptor ELSE LD.LocalDescription END AS TransactionNameLocal,  
  O.status ,  
  convert(varchar(20),O.sendtimestamp,108) as SendTimeStamp ,   
  @StatusString as StatusString
--from overriderequests      
from OverrideRequestReasons AS OvReqRsns (NOLOCK)  
 INNER JOIN overriderequests as O    (NOLOCK)  
   ON O.RequestID = OvReqRsns.RequestID  
       and (supervisoruserid = @useloginid 
	   or  (supervisoruserid is null and (GroupName=@useloginid 
	   or  GroupName in(select RoleName from V_OperatorRoles
	   where  U#=@UserNumber)))) 
	   and o.User_Number <> @UserNumber
 INNER JOIN rulestranname as T (NOLOCK)  
   on O.TransactionName = T.TransactionName      
 INNER JOIN rulesdescriptor as D (NOLOCK)  
   on D.DescriptorID=T.DSC_Description
   LEFT OUTER JOIN dbo.RulesDescriptorLocal LD (NOLOCK)         
 on LD.DescriptorID= D.DescriptorID         
  and LD.LCID = @LCID         
          
-- where Requestid in(select requestid from OverrideRequestReasons where supervisoruserid = @useloginid )           
   AND Bank = @BankID           
   AND Region = @RegionID           
--AND Branch = @BranchID           
   AND convert(datetime,convert(varchar,BusinessDate) ,112     ) = @BusinessDate          
    





Go
--End of Automatic Generation
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Get_TransactionNames
Go

Create PROCEDURE dbo.Get_TransactionNames -- dbo.Get_TransactionNames 1,1,2,466,'12/04/2009'        
@BankID tinyint,      
@RegionID tinyint,      
@BranchID smallint,      
@UserNumber smallint,      
@BusinessDate   SmallDate,
@ShowSent bit=1,
@LCID int
      
/*      
CreationDate: 27/5/2007      
OriginalName: dbo.Get_Recived_Override_Request      
Programmer: Karim Taha      
Description: get the distinct transaction names for given user      
Output:        
Assumption:       
      
*/      
    
/*    
Modify Date: 17/08/2009      
Developer: Shimaa Saeed    
Reasons: join with tables  rulestranname,rulesdescriptor to get transaction description not transaction name    

Modifier: Osama Orabi
Date	: 2010-03-23
Reason	: Performance Tuning

Modifier: Osama Orabi
Date	: 2017-12-14
Reason	: Get Local Descriptors of transctions' names

Modifier: Mostafa Sayed
Date	: 2017-12-14
Reason	: Get Local Descriptors of transctions' names

Modifier: Mahmoud Saad
Date	: 03/07/2018
Reason : The pending overrides are not showing (Return Pending Overrides)
*/     
    
as      
SET NOCOUNT ON

if(@ShowSent=1)
Begin
	--select distinct Descriptor as TransactionName
	select distinct CASE WHEN LD.LocalDescription IS NULL THEN D.Descriptor ELSE LD.LocalDescription END AS TransactionNameLocal     
	--from overriderequests      
	from overriderequests as O  (NOLOCK)   
	inner join rulestranname as T 
		on O.TransactionName = T.TransactionName    
	inner join rulesdescriptor as D 
		on D.DescriptorID=T.DSC_Description
		LEFT OUTER JOIN dbo.RulesDescriptorLocal LD         
	 on LD.DescriptorID= D.DescriptorID         
	  and LD.LCID = @LCID         
	where	Bank = @BankID 
		AND Region = @RegionID 
		AND Branch = @BranchID 
		AND User_Number = @UserNumber 
		AND BusinessDate = @BusinessDate      
End
Else
Begin
	declare @userlogin operatorid

	select @userLogin=Loginid
	from operator
	where user_number=@userNumber

	--select distinct Descriptor as TransactionName     
	select distinct CASE WHEN LD.LocalDescription IS NULL THEN D.Descriptor ELSE LD.LocalDescription END as TransactionNameLocal     
	--from overriderequests      
	from OverrideRequestReasons OvrRqstRsns  (NOLOCK)
	INNER JOIN  overriderequests as O  (NOLOCK)
		ON O.RequestId = OvrRqstRsns.RequestID
		--AND SupervisorUserId= @UserLogin
		and (supervisoruserid = @UserLogin 
	    or  (supervisoruserid is null and (GroupName=@UserLogin 
	    or  GroupName in(select RoleName from V_OperatorRoles
	    where  U#=@UserNumber)))) 
		AND BusinessDate = @BusinessDate 
	inner join rulestranname as T 
		on O.TransactionName = T.TransactionName    
	inner join rulesdescriptor as D 
		on D.DescriptorID=T.DSC_Description 
	LEFT OUTER JOIN dbo.RulesDescriptorLocal LD         
	 on LD.DescriptorID= D.DescriptorID         
	  and LD.LCID = @LCID       
   -- where BusinessDate = @BusinessDate 
		--and o.RequestId in (select RequestId from OverrideRequestReasons where SupervisorUserId= @UserLogin)
End 


Go
--End of Automatic Generation
drop_old_proc 'Update_SDDetail_Status'
GO
CREATE procedure dbo.Update_SDDetail_Status        
(        
@RefNo ReferenceNumber ,--,char(13),        
@BoxID int,        
@NewStatus int,        
@BoxType char(5),        
@TranName TransactionName,        
@OldStatus int,        
@AutoRenewal bit,    
@Remarks nvarchar(255) = '',    
@Updator OperatorID = '',    
@Operation varchar(30) = '',
--[Start - 2013/10/23] Mahmoud Kamel - CR#GFSY00290 - Audit Trail
@Workstation_ID MachineName = Null
--[End - 2013/10/23] Mahmoud Kamel - CR#GFSY00290 - Audit Trail
)        
as        
/*      
ModifiedDate: 2009-1-25      
Modifer: Mohamed Gad       
ModifyReason: Changing @RefNo data type      
    
ModifiedDate: 28/11/2010    
Modifer: Adel Shaban    
ModifyReason: Adding @Remarks parameter to mention Remarks through SDBox Maintenance    
    
ModifiedDate: 10/1/2011    
Modifer: Adel Shaban    
ModifyReason: Add @LogModifiedStatus to decide if insert record in SDLog table or not    


ModifiedDate: 07/11/2011    
Modifer: Souad Ali    
ModifyReason: fixing issue GFSX01728 

ModifiedDate: 11/11/2013    
Modifer: Mahmoud Kamel
ModifyReason: CR#GFSY00290 - Audit Trail

ModifiedDate: 16/7/2018   
Modifer: Mahmoud Saad
ModifyReason: Fixing Issue#GFSX13087 
*/      
    
--[Start - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail
select @Workstation_ID = REPLACE(@Workstation_ID,'\DOMAIN\','\')
--[End - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail
    
update SDDetail         
set     
 BoxStatus=@NewStatus,     
 IsAssigned= Case when(@NewStatus = 1) Then 0 Else isnull(IsAssigned,0) End,     
 Remarks  = @Remarks    
where RefNo = @RefNo and BoxId=@BoxId        
    
Declare @ModeOfPayment int    
    
Select @ModeOfPayment = ModeOfPayment    
from SDDetail    
where RefNo = @RefNo and BoxId=@BoxId        
    
    
    
if @NewStatus =-1  
Begin      
 update SDDetail         
 SET     
  ModeOfPayment   = 0,              
  AcctNo    = '',               
  RecoverMargin   = 0,               
  MarginAcctNo   = '',               
  MarginAmount   = 0,               
  RecoverRent   = 0,               
  RentAmount   = 0,               
  DebitExchangeRate  = 0,              
  RentFrequency   = 0,              
  CustomerName  = '',              
  CustomerAddress  = '',              
  CustomerIDType  = 0,              
  CustomerIDNumber = '',              
  CustomerPhone  = '',              
  Note   = '',              
  IsAssigned  = 0,            
   AutoRenewal = 0,            
  RenewDate = Null,            
  ExpiryDate = Null,            
  JH = '',      
  MarginAccountType = '',           
  RentAccountType   = '',        
  RentAppType    = '',        
  RentDpLoan     = '',      
  AccountCurrency   = '',    
  KeyNumber     = 0,    
  NumberOfKeys    = 0,    
  LastChanged    = getdate(),    
  ChequeNumber    = 0,    
  ChequeDate     = Null,    
  SDLAdditionalFees  = 0,    
  AssignDate   = Null,    
  CustomerRim  = '',    
  TransferId   = Null    
  where RefNo = @RefNo and BoxId=@BoxId        
    
 delete  from sdjh where refno=@refno and boxid=@boxid          
END    
else if @NewStatus =1  --Empty
Begin      
 update SDDetail         
 SET     
  ModeOfPayment   = 0,              
  AcctNo    = '',               
  RecoverMargin   = 0,               
  MarginAcctNo   = '',               
  MarginAmount   = 0,               
  RecoverRent   = 0,               
  RentAmount   = 0,               
  DebitExchangeRate  = 0,              
  RentFrequency   = 0,              
  CustomerName  = '',              
  CustomerAddress  = '',              
  CustomerIDType  = 0,              
  CustomerIDNumber = '',              
  CustomerPhone  = '',              
  Note   = '',              
  IsAssigned  = 0,            
   AutoRenewal = 0,            
  RenewDate = Null,            
  ExpiryDate = Null,            
  JH = '',      
  MarginAccountType = '',           
  RentAccountType   = '',        
  RentAppType    = '',        
  RentDpLoan     = '',      
  AccountCurrency   = '',    
  --KeyNumber     = 0,    
 -- NumberOfKeys    = 0,    
  LastChanged    = getdate(),    
  ChequeNumber    = 0,    
  ChequeDate     = Null,    
  SDLAdditionalFees  = 0,    
  AssignDate   = Null,    
  CustomerRim  = '',    
  TransferId   = Null    
  where RefNo = @RefNo and BoxId=@BoxId        
    
 delete  from sdjh where refno=@refno and boxid=@boxid          
END    

    
Declare @TransferID int    
    
Select @TransferID = TransferID    
from SDDetail    
where RefNo = @RefNo and BoxId=@BoxId        

--[Start - 2013/11/11] Mahmoud Kamel - CR#GFSY00290 - Audit Trail    
insert into sdlog(RefNo          ,BoxID      , BoxType        ,BoxStatus     , TranName       , OldStatus,   AutoRenewal,Remarks, Updator, Creator, LastChanged, Operation, TransferID,ModeOfPayment , Workstation_ID)        
values  (@RefNo     ,@BoxId      ,@BoxType   , @NewStatus     , @TranName    ,@OldStatus     ,@AutoRenewal, @Remarks , @Updator, @Updator,  getdate(), @Operation, @TransferID, @ModeOfPayment, @Workstation_ID)        
--[End - 2013/10/23] Mahmoud Kamel - CR#GFSY00290 - Audit Trail
GO

------------------------------------------------------------------------
 
 Drop_old_proc 'dbo.Get_Acct_Drawer_PMDenomDetail'
 GO
 Create PROCEDURE dbo.Get_Acct_Drawer_PMDenomDetail  --Get_Acct_Drawer_PMDenomDetail '100000009403',1,1,1,9,'XAU' 
 @AccountNumber varchar (20)  ,
 @Bank BankID,  
 @Region RegionID,  
 @Branch BranchID,  
 @CashDrawerNumber CashDrawerNumber,  
 @CurrencyType CurrencyType 
 
AS  
/*  
 CreationDate: 19-10-2017
 OriginalName: dbo.Get_Acct_Drawer_PMDenomDetail  
 Creator	 : Asmaa Gamal 
 Resone      : GFSY00663,GFSY00708
 Description : Select the avaible denomination for specific currency PM   
   the teller cash drawer and account number   
 Output      : denomination ,InDrawerQuantity  ,InAcctQuantity  
    
  
  
*/  
  
set nocount on  
 
 select convert ( int , D.Denomination) as Denomination,convert ( int ,(D.InDrawerAmount/ D.Denomination ))as InDrawerQuantity 
, P.Quantity as InAcctQuantity  from CashDrawerDetail	 D  
inner join PM_AcctDenomination P on  D.Denomination =P.PMDenomination
where p.AccountNumber =@AccountNumber and 
D.CashDrawerNumber =@CashDrawerNumber	and D.CurrencyType=@CurrencyType and Bank=@Bank and Region=@Region and Branch=@Branch



GO





------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------  
GO
drop_old_proc 'Get_Branches_Of_BankRegion'
GO
create PROC dbo.Get_Branches_Of_BankRegion   --  Get_Branches_Of_BankRegion 1,-1,0  
 @BankNo  int,                 
 @RegionNo int  ,              
 @ShowDefaultBranch bit=1              
AS                
/*                
CreationDate: 2005-01-09                 
OriginalName: dbo.Get_Branches_Of_BankRegion                
Programmer: Sayed Hussein                
Description: Get Branches Of Bank and Region                
Output:                  
Assumption:                 
                
ModifiedDate: 2005-12-14                
Modifer: Mahmoud Elkabary                
ModifyReason: check if region criteria used or not                
                
ModifiedDate: 29/4/2008                
Modifer: hany nasr                
ModifyReason: performance issue                
              
ModifiedDate: 17/1/2010              
Modifer: Adel Shaban              
ModifyReason: Add new parameter @ShowDefaultBranch to decide if show branch0 or not              
            
ModifiedDate: 18/08/2010            
Modifer: Aya Mahmoud            
ModifyReason: Check whether the Bank criteria is used            
          
ModifiedDate: 31/10/2011            
Modifer: Mostafa ElBarbary            
ModifyReason: Add New Field to Return The BranchID          
        
ModifiedDate: 06/02/2012           
Modifer: Lamiaa Mostafa           
ModifyReason: Exclude  Region = 0 or branch = 0        
      
ModifiedDate: 15/04/2012           
Modifer: Mohammed El-Masry          
ModifyReason: Return Movement Flags from BranchConfig CR # 9724       
    
ModifiedDate: 06/01/2013           
Modifer: Doaa Nassar          
ModifyReason: Add join condition to avoid duplicate branches appearing in the result   

ModifiedDate: 10/08/2015           
Modifer: Asmaa Gamal          
ModifyReason: Return Status of branch is open or no to used in( CBD_CRQ10428_External Stock Movements ,#GFSY00508    )    

ModifiedDate: 15/10/2017          
Modifer: Sara Badwy         
ModifyReason: Return DealTreasury From BranchConfig  CR[]Gold Account       
*/                
set nocount on                
                
  select distinct B.Branch, cast(B.Branch as varchar) + ' - ' + B.[Name] as name, id as BrID  ,      
  isnull(DealBranches  ,0) as DealBranches,      
  isnull(DealCB  ,0) as DealCB,      
  isnull(DealVendor  ,0) as DealVendor,      
  isnull(IsCashCentre  ,0) as IsCashCentre,      
  isnull(CashCentre  ,0) as CashCentre   ,
  --Asmaa Gamal
  isnull(IsOpenBranch,0) as   IsOpenBranch,
  B.Bank as Bank,
  --Asmaa Gamal      
  isnull(DealTreasury  ,0) as DealTreasury       
  from dbo.Branch as B  left outer join BranchConfig BC on B.Branch = BC.Branch      
  and B.Region = BC.Region             
  where ((@BankNo=-1)   or (B.Bank=@BankNo))            
  and   ((@RegionNo=-1)   or (B.Region=@RegionNo))            
  AND   ((@ShowDefaultBranch=1) or (@ShowDefaultBranch=0 And B.Branch>0))          
  AND B.Region <> 0 AND B.Branch <> 0          
  ORDER BY 1          
  GO  
  


------------------------------------------------------------------------
DROP_OLD_PROC 'dbo.Get_PM_AcctDenomination'
GO
Create proc dbo.Get_PM_AcctDenomination   --'100000009408'                                      
                              
      
 @AccountNumber VARCHAR(20) 
                                     
                              
 As                                        
                              
                                      
                              
/*                                        
 CreationDate: 25-10-2017
 OriginalName: dbo.Get_PM_AcctDenomination  
 Creator	 : Asmaa Gamal 
 Resone      : GFSY00663,GFSY00708
 Description : Select PM_AcctDenomination table
                       
 
*/  

SELECT PMDenomination As Denomination
,'Plates'  as  CashDrawerType
, Quantity as Count
 ,Quantity * PMDenomination as Value
, Quantity * PMDenomination as  InDrawerAmount  
		FROM PM_AcctDenomination WHERE AccountNumber =@AccountNumber

		Go

		 


------------------------------------------------------------------------
  DROP_OLD_PROC 'GetLeadTeller_By_VaultCustodian_ActiveDrawer'
GO

  CREATE PROC dbo.GetLeadTeller_By_VaultCustodian_ActiveDrawer  
       
@cashdrawerID smallint,        
@bank bankid,        
@region regionid,        
@branch branchid        
AS  
    
/*        
creationdate: 2017-12-05        
originalname: dbo.select_allSignedOnTellers_ActiveDrawer        
programmer: Sara Badwy        
description: get  signed on LeadTeller Assigned to this VaultCustodian with active cashdrawer   
*/  
set nocount on  
select distinct CV.leadTeller,Op.LoginID As LeadTellerLoginId ,isnull(t.IsOpenDay ,0) as IsOpenDay,convert(bit,isnull(t.IsSignedOn ,0)) as IsSignedOn   
from cashvault CV  
inner join Operator Op on CV.LeadTeller = Op.user_number  
inner join CashDrawer cd on cd.cashdrawernumber=@cashdrawerID
 left outer join dbo.Operator_Status AS t on t.user_number=OP.user_number     
where vaultnumber = @cashdrawerID  
and  CV.bank =@bank and CV.region =@region        
and  CV.branch=@branch  
and cd.isactive=1
and t.IsSignedOn=1


go


------------------------------------------------------------------------
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc GETVAULTNUMBER_BY_LEADTELLER
Go
CREATE PROC dbo.GETVAULTNUMBER_BY_LEADTELLER        
@Bank BankID,        
@Region RegionID,        
@Branch BranchID,        
@CashDrawerNo CashDrawerNumber      
AS        
      
-- Hany A Hassan ---------------------       
      
/*        
  	ModifiedDate:	2008-05-29
	ModifiedBy	:Hany A Hassan
	ModifyReason:	Get the vault LoginID 
	
	ModifiedDate:	2011-08-25
	ModifiedBy	:Osama Orabi
	ModifyReason:	Porting From UBS3 to G8
	
	2011-Aug-28: Osama Orabi: Self Join CashDrawers table using CD1.cashDrawerNumber = CD2.AttachedToVault  AND CD1.BrID = CD2.BrID
	2011-Dec-01: Osama Orabi: Filter by Passed Bank, Region, And Branch.
	2014-Jan-29: Mohammed El-Masry: Return IsOpenDay,IsSignedOn   
	2014-Apr-8:  May Hassan: Return IsStockCustodian  
        
        ModifiedDate:	2017-18-10
	ModifiedBy	:   asmaa gamal
	ModifyReason:	retrive VaultCustodianID
*/        
select CD1.CashDrawerNumber as 'CashDrawerNumber',      
    O.LoginID as 'VaultCustodian'  ,isnull(t.IsOpenDay ,0)  as IsOpenDay,isnull(t.IsSignedOn ,0) as IsSignedOn ,
    CASE when O.UserClassID = 8 THEN 1 ELSE 0 END as IsStockCustodian,
     O.user_number  	 as 'VaultCustodianID'
from CashDrawerS CD1 inner join CashDrawers CD2       
on CD1.cashDrawerNumber = CD2.AttachedToVault      
 AND CD1.BrID = CD2.BrID    
inner join Operator O on CD1.Assignedtoteller = O.user_number    
AND O.BrID = CD1.BrID    
left outer join dbo.Operator_Status AS t on t.user_number=O.user_number  
OUTER APPLY dbo.GetBankRegionBranchForBrID(O.BrID) BranchDetail    
where BranchDetail.Bank = @Bank    
and BranchDetail.Region= @Region    
and BranchDetail.Branch= @Branch     
and CD2.CashDrawerNumber = @CashDrawerNo      

GO
--End of Automatic Generation


------------------------------------------------------------------------
 
 Drop_old_proc 'dbo.Insert_Acct_PMDenomDetail'
 GO
 Create PROCEDURE dbo.Insert_Acct_PMDenomDetail  --Insert_Acct_PMDenomDetail '100000009402',1,300,3 
    @AccountNumber  varchar (20) ,
	@PMTypeID int ,
	@PMDenomination decimal (21, 6) ,
	@Quantity int 
 
AS  
/*  
 CreationDate: 19-10-2017
 OriginalName: dbo.Insert_Acct_PMDenomDetail  
 Creator	 : Asmaa Gamal 
 Reason     : GFSY00663,GFSY00708
 Description : insert 	 or update in table PM_AcctDenomination
    
  
  
*/  
  
set nocount on  
If Not Exists( select * from PM_AcctDenomination where AccountNumber = @AccountNumber  and PMTypeID =@PMTypeID and PMDenomination= @PMDenomination)
 BEGIN
 INSERT INTO [dbo].[PM_AcctDenomination]
           ([AccountNumber]
           ,[PMTypeID]
           ,[PMDenomination]
           ,[Quantity])
     VALUES
           (@AccountNumber 
           ,@PMTypeID
           ,@PMDenomination 
           ,@Quantity )
 END
 ELSE
 BEGIN 
 update   PM_AcctDenomination 
 set Quantity +=@Quantity
 where AccountNumber = @AccountNumber  and PMTypeID =@PMTypeID and PMDenomination= @PMDenomination
 END

GO





------------------------------------------------------------------------
DROP_OLD_PROC 'dbo.PM_AcctDenomination_Change'
GO
Create proc [dbo].[PM_AcctDenomination_Change]                                        
                              
 @PMDEnom [T_PM_AcctDenomination] readonly,          
 @IsIncreaser VARCHAR(1) --I,D
                                     
                              
 As                                        
                              
                            
/*                                        
 CreationDate: 25-10-2017
 OriginalName: dbo.PM_AcctDenomination_Change  
 Creator	 : Asmaa Gamal 
 Resone      : GFSY00663,GFSY00708 retrofit
 Description : update   or insert PM_AcctDenomination table
                       
 
*/                                        
             

      
                          
Begin Transaction Update_PM_AcctDenomination                                  
  
  select distinct (PMDenomination), sum (Quantity) as Quantity ,AccountNumber,PMTypeID   into #tempx   from @PMDEnom

--where  Quantity > 0
group by PMDenomination  , AccountNumber	,PMTypeID

 
                  
UPDATE PM_AcctDenomination                                  
 SET PM_AcctDenomination.Quantity= 
		(CASE 
			WHEN UPPER(@IsIncreaser)='I' 
				THEN  PM_AcctDenomination.Quantity +   PMDA.Quantity
			ELSE  PM_AcctDenomination.Quantity - PMDA.Quantity
		END 
		)                             
                                
             
                              
FROM PM_AcctDenomination                                                       
INNER JOIN #tempx PMDA
ON 
PM_AcctDenomination.AccountNumber   = PMDA.AccountNumber  AND 
PM_AcctDenomination.PMDenomination  = PMDA.PMDenomination AND 
PM_AcctDenomination.PMTypeID        = PMDA.PMTypeID  
 
INSERT INTO PM_AcctDenomination 	 
SELECT #tempx.AccountNumber ,#tempx.PMTypeID,#tempx.PMDenomination,#tempx.Quantity FROM #tempx	 
WHERE 
  1 not in (select 1 from PM_AcctDenomination 
  where 
  AccountNumber  = #tempx.AccountNumber and 
  PMTypeID = #tempx.PMTypeID and 
  PMDenomination = #tempx.PMDenomination)                                     
                              
                                  
delete from  PM_AcctDenomination where Quantity <=0                    
             
IF @@error <> 0 BEGIN                                  
                              
ROLLBACK TRANSACTION Update_PM                                  
                              
PRINT N'An Error Occured While Update_PM_AcctDenomination'                                  
                              
RETURN -1                            
                              
END ELSE                            
BEGIN                            
COMMIT TRANSACTION Update_PM_AcctDenomination                          
RETURN 0                            
END 
 Go


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_Add_PM_Plates'
GO
CREATE PROC [dbo].[PM_Add_PM_Plates] (@PM [T_PM_Add_Plates] READONLY,          
         --@RefNo ReferenceNumber,          
         --@PMType_ID int,          
         @Amount NUMERIC,          
         @From_Type INT,          
         @From_Partner VARCHAR,          
         @From_CashDrawer CashDrawerNumber=NULL,          
         @To_Type INT,          
         @To_Partner VARCHAR,          
         @To_CashDrawer CashDrawerNumber=NULL,          
         @TransactionName TransactionName,          
         @MovementType INT,          
         @CustomerAccount AccountNumber,          
         @BusinessDate BusinessDate,          
         @Operator OperatorID--,        
         --@Locations T_RequiredLocations READONLY
         )          
AS          
/*            
 Creator : Mohamed  Barakat          
 Created : 01/12/2013            
 Reason  : Insert  PM Plates into Tables (PM,PM_Movement,PM_MovementDetails) with Status After each movement        
         
 Updator : Motaz Atiya        
 Date  : 27 May, 2015        
 Reason  : Allow receiving PMs which are reversed form treasury or sent to vendor  
 
 Updator : Mostafa Sayed
 Date    : [1/10/2017]
 Reason  : -CR#GFSY00663 - KFH_CRQ14056_Gold Account
		   -Removing Location, PrevLocation, DepartmentID and Movement
 Updator : Nehal Ramadan
 Date    : [6/25/2018]
 Reason  : -CR#GFSY00708 - KFH_CRQ14056_Gold Account_RetroFit
		   -Removing Location, PrevLocation, DepartmentID and Movement
		   
*/          
          
BEGIN TRANSACTION Insert_PM        
-- Receiving      
-- Receive new PM        
INSERT INTO PM (SerialNo    
, PMTypeID    
, VendorID    
, Denom    
--, Location    
, Status    
, Branch    
--, DeptartmentID    
, USER_ID    
, CashDrawer    
, CustomerAccount    
, RIM    
, Creator    
, Updator)    
    
 SELECT    
  TPM.[SerialNo],    
  TPM.[PMTypeID],    
  TPM.[VendorID],    
  TPM.[Denom],    
  --TPM.[Location],    
  TPM.[Status],    
  TPM.[Branch],    
  --TPM.[DeptartmentID],    
  TPM.[User_ID],    
  TPM.[CashDrawer],    
  TPM.[CustomerAccount],    
  TPM.[RIM],    
  @Operator,    
  @Operator    
 FROM @PM TPM    
 LEFT JOIN PM    
  ON TPM.SerialNo = pm.SerialNo    
  AND TPM.PMTypeID = pm.PMTypeID    
  AND TPM.VendorID = pm.VendorID    
  AND TPM.Denom = pm.Denom    
 WHERE PM.SerialNo IS NULL    
 AND PM.PMTypeID IS NULL    
 AND PM.VendorID IS NULL    
 AND PM.Denom IS NULL;    
        
-- Receive reversed form treasury or sent to vendor PMs        
UPDATE PM    
SET SerialNo = TPMP.[SerialNo],    
 PMTypeID = TPMP.[PMTypeID],    
 VendorID = TPMP.[VendorID],    
 Denom = TPMP.[Denom],    
 --Location = TPMP.[Location],    
 --PrevLocation = PM.Location,    
 Status = TPMP.[Status],    
 Branch = TPMP.[Branch],    
 --DeptartmentID = TPMP.[DeptartmentID],    
 USER_ID = TPMP.[User_ID],    
 CashDrawer = TPMP.[CashDrawer],    
 CustomerAccount = TPMP.[CustomerAccount],    
 RIM = TPMP.[RIM],    
 Creator = @Operator,    
 Updator = @Operator    
FROM @PM TPMP    
INNER JOIN PM    
 ON TPMP.SerialNo = PM.SerialNo    
 AND TPMP.PMTypeID = PM.PMTypeID    
 AND TPMP.VendorID = PM.VendorID    
 AND TPMP.Denom = PM.Denom    
 --AND PM.Location IN (SELECT    
 -- *    
 --FROM @Locations);    
        
-------------------------------------------------------------------        
-- Get next movement ID        
/*DECLARE @MovementID INT;        
        
EXEC [dbo].[Get_Next_TableID] 'PM_Movement',        
        'ID',        
        1,        
        @MovementID OUTPUT,        
        0;        
        
-- Insert Into PM Movements          
EXEC dbo.PM_Add_PM_MOV @MovementID,        
      '',        
      @Amount,        
      @From_Type,        
      @From_Partner,        
      @From_CashDrawer,        
      @To_Type,        
      @To_Partner,        
      @To_CashDrawer,        
      @TransactionName,        
      @MovementType,        
      @CustomerAccount,        
      @BusinessDate,        
      @Operator;        
        
--------------------------------------------------------------------        
-- Insert movement details        
        
EXEC dbo.PM_Add_PM_Details @PM,        
       @MovementID,        
       @Operator;        
 */       
--------------------------------------------------------------------        
        
IF @@ERROR <> 0 BEGIN        
ROLLBACK TRANSACTION Insert_PM        
PRINT N'An Error Occured While Insert_PM';        
RETURN -1  
END ELSE  
BEGIN  
COMMIT TRANSACTION Insert_PM  
RETURN 0  
END  


GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_Check_RefNo'
GO
CREATE PROCEDURE dbo.PM_Check_RefNo  --exec PM_Check_RefNo '001PM00014715'    
@RefNo ReferenceNumber    
AS    
/*    
 Creator: Mohamed Elabd    
 Date: 20-August-2015    
 Reason: Check if the reference number has been reversed Or Not    
   -1 Already Reversed  
   0 Not Reversed  
*/    
IF EXISTS(SELECT TOP 1 RefNo     
    FROM dbo.PM_Movement      
    WHERE RefNo = @RefNo    
    AND MovementType = 7)    
 return -1 --Already Reversed   
ELSE    
 return 0 --Not Reversed
 GO


------------------------------------------------------------------------
DROP_old_proc 'dbo.PM_Check_SerialAndStatus'
GO 
CREATE proc dbo.PM_Check_SerialAndStatus
@Serial varchar(100),
@Status int,
@Denom decimal
AS
 /*  
 CreationDate: 04-Oct-2017
 OriginalName: dbo.PM_Check_SerialAndStatus  
 Creator: Ahmed Osman  
 Description: CR GFSY00663 ,GFSY00701, Check Precious Metal Serial Exists or not And it's status matched or not
	output : 
			0 -- Serial not Exists
			1 -- Serial Exists and same status
			2 -- Serial Exists and same status But Not Same Denomination
			3 -- Serial Exists but Not the same status
*/
IF Exists (SELECT * FROM PM WHERE PM.SerialNo = @Serial)
BEGIN
	IF Exists (SELECT * FROM PM WHERE PM.SerialNo = @Serial AND PM.Status = @Status)
	BEGIN
		IF Exists ( SELECT * FROM PM WHERE PM.SerialNo = @Serial AND PM.Status = @Status AND Denom = @Denom)
		BEGIN
			select 1
		END
		ELSE
		BEGIN
			SELECT 2
		END
	END
	ELSE
	BEGIN
		select 3
	END
END
ELSE
	BEGIN
		select 0
	END
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_CheckRef'

GO
create PROC dbo.PM_CheckRef 
 @RefNo  ReferenceNumber  
AS                
/*                
CreationDate: 2017-10-31                  
Creator: Sara Badwy
*/
Begin
if exists(select * from dbo.PM_PendingMovement where RefNo=@RefNo)
select 1 as result
else
select 0 as result
End
GO



------------------------------------------------------------------------
DROP_OLD_PROC 'PM_DELETE_MOVEMENT'
GO
CREATE   PROCEDURE dbo.PM_DELETE_MOVEMENT --'ASMAA'        
     
	@RefNo ReferenceNumber 
	
     
           
AS                        
/*   
 CreationDate: 17-10-2017
 OriginalName: dbo.PM_DELETE_MOVEMENT 
 Creator	 : Asmaa Gamal 
 Resone      : GFSY00663,GFSY00708
 Description : delete from  table  pm_pendingmovementDetails and   pm_pendingmovement
 
      
*/                        
  
set nocount on  
DECLARE @ID INT 	, @PendingMovementID INT   
 SELECT @PendingMovementID =  ID FROM PM_PendingMovement WHERE RefNo=@RefNo

 	

		DELETE  FROM pm_pendingmovementDetails WHERE PendingMovementID=@PendingMovementID

		DELETE 	FROM PM_PendingMovement WHERE 	RefNo=@RefNo
	
	



			
	


GO







------------------------------------------------------------------------
DROP_OLD_PROC 'PM_EntitiesBalance_Lock'
GO
CREATE   PROCEDURE dbo.PM_EntitiesBalance_Lock  --0               
			@Mode  int
            
AS                        
/*   
 CreationDate: 19-9-2017
 OriginalName: dbo.PM_EntitiesBalance_Lock  
 Creator	 : Asmaa Gamal 
 Resone      : GFSY00663, GFSY00708
 Description :  lock and unlock and check in table 	PM_EntitiesBalance
 0  unlock
 1  lock
 2  check
 
      
*/                        
  
set nocount on  

	if (@Mode=0)
	begin
	 update TableLock set IsInProcess=0 where TableName='PM_EntitiesBalance'
	 select 0
	end
	else if (@Mode=1)
	begin
	 update TableLock set IsInProcess=1 where TableName='PM_EntitiesBalance'
	 select 1
	end
	else
	begin
		select IsInProcess from TableLock where TableName='PM_EntitiesBalance'  
	end
	
		   
GO    

			
	
 




------------------------------------------------------------------------
DROP_OLD_PROC 'PM_ExecuteReconcelation'
GO
CREATE   PROCEDURE [dbo].[PM_ExecuteReconcelation]  
	@PMBalance T_PM_Balance READONLY
AS                                  
/* 
 Programmer   : Mostafa Sayed
 Creation Date: [20/9/2017] 
 Reason       : CR#GFSY00677 - KFH_CRQ14056_Gold Account_Part6
 Notes		  : To Execute Reconcelation Transaction which update PM_EntitiesBalance
*/
BEGIN TRANSACTION EXECUTE_RECONCELATION

	UPDATE PM_EntitiesBalance    
	SET	   PM_EntitiesBalance.BankBalance= TPMB.BankBalance,    
		   PM_EntitiesBalance.CustomerBalance = TPMB.CustomerBalance      
	FROM   @PMBalance TPMB   
	INNER JOIN PM_EntitiesBalance   
	ON	   TPMB.PMType = PM_EntitiesBalance.PMType
	AND    TPMB.OwnerDescription = PM_EntitiesBalance.OwnerDescription 
	AND    TPMB.Bank = PM_EntitiesBalance.Bank
	AND    TPMB.Region = PM_EntitiesBalance.Region
	AND    TPMB.Branch = PM_EntitiesBalance.Branch
	AND    TPMB.CashDrawer = PM_EntitiesBalance.CashDrawer
	
IF @@ERROR <> 0 BEGIN        
	ROLLBACK TRANSACTION EXECUTE_RECONCELATION        
	PRINT N'An Error Occured While Executing Reconcelation';        
	RETURN -1	
END ELSE  
	BEGIN  
	COMMIT TRANSACTION EXECUTE_RECONCELATION  
	RETURN 0  
END  
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_Get_Data'
GO
CREATE PROC [dbo].[PM_Get_Data]  
  
as  
  
/*  
Creator : Motaz Atiya  
Date : 26 May, 2015  
Reason : Get PM table  
*/  
  
SELECT  
 *  
FROM pm;  


GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_GetAllCustomersInventory'
GO

CREATE   PROCEDURE [dbo].[PM_GetAllCustomersInventory]     

 @PMType int         
AS                                    
/*   
 Programmer   : Mostafa Sayed  
 Creation Date: [22/02/2018]   
 Reason       : CR#GFSY00694 - KFH_ACM15999_Gold Account Enhancement  
 Notes    : Retrive All customers inventory and their count  
*/  
BEGIN  
 SELECT PMDenomination,SUM(Quantity) as'COUNT'   
 FROM PM_AcctDenomination  
 WHERE PMTypeID=@PMType  
 GROUP BY PMDenomination  
END  

GO
------------------------------------------------------------------------
DROP_OLD_PROC 'PM_GetAllEntitiesBalance'
GO
CREATE   PROCEDURE [dbo].[PM_GetAllEntitiesBalance]  
	@PMType INT      
AS                                  
/* 
 Programmer   : Mostafa Sayed
 Creation Date: [20/9/2017] 
 Reason       : CR#GFSY00663 - KFH_CRQ14056_Gold Account
 Notes		  : To get PM Entities Balance except Users entities
*/
BEGIN
	SELECT PM_EntitiesBalance.OwnerDescription,PM_EntitiesBalance.BankBalance,PM_EntitiesBalance.CustomerBalance 
	FROM PM_EntitiesBalance
	WHERE PMType=@PMType AND OwnerDescription <> 'USER'
END
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_GetAllUsersEntitiesBalance'
GO
CREATE   PROCEDURE [dbo].[PM_GetAllUsersEntitiesBalance]  
	@PMType INT      
AS                                  
/* 
 Programmer   : Mostafa Sayed
 Creation Date: [20/9/2017] 
 Reason       : CR#GFSY00663 - KFH_CRQ14056_Gold Account
 Notes		  : To get PM Entities Balance for all Users
*/
BEGIN
	SELECT PM_EntitiesBalance.Bank,PM_EntitiesBalance.Region,PM_EntitiesBalance.Branch,PM_EntitiesBalance.CashDrawer,Operator.LoginID,PM_EntitiesBalance.BankBalance,PM_EntitiesBalance.CustomerBalance
	FROM PM_EntitiesBalance 
	INNER JOIN CashDrawers
	ON PM_EntitiesBalance.CashDrawer=CashDrawers.CashDrawerNumber
	INNER JOIN Operator
	ON CashDrawers.AssignedToTeller=Operator.user_number
	WHERE PM_EntitiesBalance.OwnerDescription='USER' AND PM_EntitiesBalance.PMType=@PMType
	ORDER BY id
END
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_GetEntitiesBalance'
GO
CREATE   PROCEDURE [dbo].[PM_GetEntitiesBalance]  
	@PMType INT,
	@OwnerDescription VARCHAR(50),
	@BankOrCustomer VARCHAR(1),--B,C
	@cashDrawer INT =-1,
	@Bank INT =-1,
	@Region INT =-1,
	@Branch INT =-1        
AS                                  
/* 
 Programmer   : Mostafa Sayed
 Creation Date: [25/6/2018] 
 Reason       : CR#GFSY00708 - Retrofit
 Notes		  : To get PM Entities Balance
*/
BEGIN
	SELECT CASE WHEN UPPER(@BankOrCustomer) = 'C' THEN CustomerBalance ELSE BankBalance END AS 'Balance'
	FROM PM_EntitiesBalance
	WHERE PMType=@PMType AND OwnerDescription=@OwnerDescription AND CashDrawer=@cashDrawer AND Bank=@Bank AND Region=@Region AND Branch=@Branch
END
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_GetRefNoDetails'
GO
CREATE   PROCEDURE [dbo].[PM_GetRefNoDetails] --'001PM00018315'                                               
        
     @RefNo        ReferenceNumber                               
        
AS                                    
/*                                    
 Creation Date     : 01 Dec 2013                                    
 Original Name     : dbo.PM_GetRefNoDetails                                                       
 Description     : gets movement details using Reference#    
     
 Updator : Motaz Atiya    
 Date  : 27 May, 2015    
 Reason  : Extend PM search criteria to include (Denomination, PM Type and Vendor)    
*/                                    
set nocount on                                  
        
select               
        
PM.Denom,              
        
PM.SerialNo,              
        
Mov.Amount,  
  
PM.VendorID,  
  
PMV.Vendor,        
        
PM.PMTypeID,            
        
mov.From_type,        
        
Op.user_number,            
        
Op.LoginID             
        
            
        
from PM_Movement Mov              
        
inner join PM_MovementDetails Det              
        
on Mov.ID = Det.MovementID              
        
inner join PM              
        
on PM.SerialNo = Det.SerialNo      
and PM.PMTypeID = Det.PMTypeID      
and PM.VendorID = Det.VendorID      
and PM.Denom = Det.Denom      
        
left JOIN Operator Op            
        
on Op.user_number = Mov.From_Partner            
  
LEFT JOIN PM_Vendor PMV  
on PM.VendorID = PMV.VendorID  
  
where Mov.RefNo = @RefNo  


GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_GetTotalEveryEntitiesBalance'
go
CREATE   PROCEDURE dbo.PM_GetTotalEveryEntitiesBalance  --PM_GetTotalEveryEntitiesBalance 'XAU' 
	@PMCurrency char (3)      
AS                                  
/* 
 CreationDate: 19-10-2017
 OriginalName: dbo.PM_GetTotalEveryEntitiesBalance  
 Creator	 : Asmaa Gamal 
 Resone      : GFSY00663,GFSY00708
 Description : Select BankBalance, CustomerBalance from all entity in PM_EntitiesBalance 
   
*/
BEGIN
	SELECT  SUM (BankBalance) as BankBalance,SUM(CustomerBalance)	 as CustomerBalance
	FROM PM_EntitiesBalance
	where PMType  = (select PMTypeID from PM_Type where ISO_Code =@PMCurrency )
	
END
go



------------------------------------------------------------------------
DROP_OLD_PROC 'PM_INS_LOGHISTORY'
GO
CREATE   PROCEDURE dbo.PM_INS_LOGHISTORY  --'ETHIXBRANCH',1000,'12-10-2017','ITSOFT\ASMAA.GAMAL','ASMAAGAMAL_NB','10.10.12.4',1,'232334344'                    
			@Interface  nvarchar(50)
           ,@Amount  money
           ,@Created  datetime
           ,@Creator  [dbo].[OperatorID]
           ,@MachineName  nvarchar(50)
           ,@MachineIP  nvarchar(50)
           ,@PMTypeID  int
		   ,@TranType  nvarchar(50)
           ,@EntityType  nvarchar(50)
           ,@CoreReferenceNumber  nvarchar(250)	=''
           ,@EthixRelatedReference  nvarchar(250) =''
           
	
	
	
     
           
AS                        
/*   
 CreationDate: 16-10-2017
 OriginalName: dbo.PM_INS_LOGHISTORY  
 Creator	 : Asmaa Gamal 
 Resone      : GFSY00663,GFSY00708
 Description :  insert  in  PM_logHistory 
 
      
*/                        
  
set nocount on  

		INSERT INTO [dbo].[PM_logHistory]
           ([Interface]
           ,[Amount]
           ,[Created]
           ,[Creator]
           ,[MachineName]
           ,[MachineIP]
           ,[PMTypeID]
           ,[CoreReferenceNumber]
           ,[EthixRelatedReference]
           ,[TranType]
           ,[EntityType]
		   ,[IsReversed])
     VALUES
           (@Interface
           ,@Amount
           ,@Created
           ,@Creator
           ,@MachineName 
           ,@MachineIP 
           ,@PMTypeID 
           ,@CoreReferenceNumber 
           ,@EthixRelatedReference 
           ,@TranType 
           ,@EntityType
		   ,0 )
		   
GO    

			
	
 




------------------------------------------------------------------------
Drop_Old_Proc PM_InsUserEntitiesBalance
GO  
create Proc dbo.PM_InsUserEntitiesBalance
 @PMType INT,  
 @cashDrawer INT ,  
 @Bank INT ,  
 @Region INT ,  
 @Branch INT   
AS          
/*          
 Developer : Nehal Ramadan         
 Created  : 6 Dec 2017          
 Reason  : Insert record PM_EntityBalance for the user in the first use 
*/          
  
set nocount on          

declare @result table (column_Name varchar(2), next_id int)
insert into @result
exec p_next_id 'PM_EntitiesBalance', 1
declare @ID int
select @ID =next_id from @result

If Not Exists(Select * From PM_EntitiesBalance Where CashDrawer= @cashDrawer)
Begin
 Insert Into PM_EntitiesBalance(id,PMType,OwnerDescription,Bank,Region,Branch,CashDrawer,BankBalance,CustomerBalance,Creator,Updator)
 Values (@ID,@PMType,N'USER',@Bank,@Region,@Branch,@cashDrawer,0.000000,0.000000,N'ITSOFT\GFSMTSuser',N'ITSOFT\GFSMTSuser')
End

GO



------------------------------------------------------------------------
DROP_OLD_PROC 'PM_IsReconciliationExecuted'
GO
CREATE   PROCEDURE [dbo].[PM_IsReconciliationExecuted]          
AS                                  
/* 
 Programmer   : Mostafa Sayed
 Creation Date: [6/25/2018] 
 Reason       : CR#GFSY00663 - KFH_CRQ14056_Gold Account
 Notes		  : To check if Reconciliation transaction is executed or not
*/
BEGIN
	DECLARE @TotalBankBalance DECIMAL 
	DECLARE @TotalCustomerBalance DECIMAL
	
	SELECT @TotalBankBalance=SUM(BankBalance),@TotalCustomerBalance=SUM(CustomerBalance) 
	FROM PM_EntitiesBalance
	WHERE OwnerDescription='CENTER CONTROL'
	
	IF @TotalBankBalance=0 AND @TotalCustomerBalance=0
	SELECT 1 AS 'IsReconciliationExec'
	ELSE
	SELECT 0 AS 'IsReconciliationExec'
END
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'pm_ListAvilableVendors'
GO
create proc [dbo].[pm_ListAvilableVendors]    
@PMTypeID int =0    
-- Reason : List Avilable Vendors per Precious Metal    
-- and get vendor Info also    
as    
SELECT PMV.[VendorID]    
      ,[Vendor]    
      ,[NostroAccount]    
      ,[acct_type]    
      ,[appl_type]    
      ,[dep_loan]    
      ,[acct_curr]    
FROM [Globalfs].[dbo].[PM_VendorToType] PMVT    
inner join [Globalfs].[dbo].[PM_Vendor] PMV on PMV.VendorID =PMVT.VendorID and PMVT.PMTypeID=@PMTypeID  


GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_Reverse_Receive'
GO
CREATE PROC [dbo].[PM_Reverse_Receive]                                
                                
 (	@PM [T_PM_Add_Plates] readonly,
	@MovementType INT = -1                                                   
                                
 --,@Amount NUMERIC = -1                                
                                  
 --,@From_Type INT = -1                               
                                  
 --,@From_Partner NVARCHAR(50) = NULL                               
                                  
 --,@From_CashDrawer CashDrawerNumber = -1                                
                                  
 --,@To_Type INT = -1                               
                                  
 --,@To_Partner NVARCHAR(50) = NULL                               
                                  
 --,@To_CashDrawer CashDrawerNumber = -1                                
                                  
 --,@TransactionName TransactionName = NULL                               
                                  
 --,@MovementType INT = -1                               
                                  
 --,@CustomerAccount AccountNumber = NULL                               
                                  
 --,@BusinessDate BusinessDate = NULL                               
                                  
 --,@Operator OperatorID = NULL                    
                     
 --,@Locations T_RequiredLocations READONLY                  
                   
 --,@CheckForReverse BIT = 0)
 )                                
                                
AS                              
                              
/*                                          
                                
 Creator : Motaz Atiya                              
                                
 Created : 25 May, 2015                              
                                
 Reason  : Check for reverse availability and Reverse Gold Account transactions that has no reference number generated  
                             
 Output  : In case of checking for reverse                            
    --If reverse operation is allowed                          
       Returns 0                            
    --If reverse operation is not allowed                          
       Returns -2                            
                                  
    In Case of reversing                            
    --Updates PM table                              
    --Inserts new movement into (PM_Movement) table                              
    --Inserts movement details into (PM_MovementDetails) table  
    --Check on User_ID and CashDrawer value before update      
            -1: PM Currently not assigned to a certain cash drawer or user      
   -2: don't update current cash drawer or user (for PreciousMetalRequestWithdrawal transaction)  
   
    Updator : Mostafa Sayed
	Date    : [1/10/2017]
	Reason  : -CR#GFSY00663 - KFH_CRQ14056_Gold Account
			  -Removing Location, PrevLocation, DepartmentID and Movement
*/                              
                    
--Checking for reverse                            
                                
/*IF (@CheckForReverse = 1)                              
BEGIN                                
                    
IF EXISTS (SELECT                    
 *                    
FROM @PM PMT                    
INNER JOIN PM ON PMT.SerialNo = pm.SerialNo                    
  AND PMT.PMTypeID = pm.PMTypeID                    
  AND PMT.VendorID = pm.VendorID                    
  AND PMT.Denom = pm.Denom                    
WHERE PM.Location NOT IN (SELECT * FROM @Locations)) BEGIN RETURN -2 END-- PM's location has changed                       
ELSE BEGIN RETURN 0 END                    
                                
END                      
              
IF EXISTS (SELECT                    
 *                    
FROM @PM PMT                    
INNER JOIN PM ON PMT.SerialNo = pm.SerialNo                    
  AND PMT.PMTypeID = pm.PMTypeID                    
  AND PMT.VendorID = pm.VendorID                    
  AND PMT.Denom = pm.Denom                    
WHERE PM.Location NOT IN (SELECT * FROM @Locations)) BEGIN RETURN -2 END-- PM's location has changed                
                    
ELSE 
*/                      
BEGIN TRAN Reverse_Receive                    
                    
--Reversing                            
---------------------------------------------------                            
--Update PM table                                
--UPDATE [Globalfs].[dbo].[PM]                                
                                
--SET /*PM.[Location] = CASE          
--      WHEN PMT.Location = -1 THEN PrevLocation           
--      ELSE PMT.Location           
--     END,                               
                                
-- PM.[PrevLocation] = PM.Location,*/                                
                                
-- PM.[Status] = PMT.Status,                                
                                
-- PM.[Branch] = PMT.Branch,                                
                                
-- --PM.[DeptartmentID] = PMT.DeptartmentID,                            
           
-- PM.[User_ID] =          
--     CASE          
--      WHEN PMT.User_ID = -2 THEN PM.[User_ID]          
--      ELSE PMT.User_ID          
--     END,          
-- PM.[CashDrawer] =          
--     CASE          
--      WHEN PMT.CashDrawer = -2 THEN PM.[CashDrawer]          
--      ELSE PMT.CashDrawer          
--     END,          
                                
-- PM.[CustomerAccount] = PMT.CustomerAccount,                                
                                
-- PM.[RIM] = PMT.RIM,                                
                                
-- PM.[LastChanged] = GETDATE(),                             
                                
-- PM.[Updator] = PMT.Operator                                
                                
--FROM PM                                
                                
--INNER JOIN @PM PMT                                
                                
-- ON PM.SerialNo = PMT.SerialNo                                
                      
-- AND PM.PMTypeID = PMT.PMTypeID                                
                                
-- AND PM.VendorID = PMT.VendorID                                
                                
-- AND PM.Denom = PMT.Denom;                                
                                
---------------------------------------------------                                
--Get next movement ID                                
/*DECLARE @MovementID INT;                                
                                
EXEC [dbo].[Get_Next_TableID] 'PM_Movement',                                
        'ID',                                
        1,                                
        @MovementID OUTPUT,                          0;                                
                            
--Insert new movement                                
EXEC dbo.PM_Add_PM_MOV @MovementID,                                
                                
      '',                                
                                
      @Amount,                                
                                
      @From_Type,                              
                                
      @From_Partner,                                
                                
      @From_CashDrawer,                                
                                
      @To_Type,                                
                                
      @To_Partner,                                
                                
      @To_CashDrawer,                                
                                
      @TransactionName,                                
                                
      @MovementType,                               
                                
      @CustomerAccount,                                
                                
      @BusinessDate,                                
                                
      @Operator;                                
                                
---------------------------------------------------                                
--Insert movement details                                
EXEC dbo.PM_Add_PM_Details @PM,                                
                                
       @MovementID,                                
                                
  @Operator;                                
*/                                
---------------------------------------------------  
IF(@MovementType = 1)--Reverse Receive
BEGIN
	DELETE PMTable
	FROM PM PMTable
	INNER JOIN @PM PMT
	ON PMTable.SerialNo=PMT.SerialNo
	AND PMTable.PMTypeID = PMT.PMTypeID  
	AND PMTable.VendorID = PMT.VendorID
	AND PMTable.Denom = PMT.Denom
	AND PMTable.User_ID = PMT.User_ID
	WHERE PMTable.Status = 1 --ReceivedByTR
END
--ELSE IF(@MovementType = 0)--Reverse Send
--BEGIN
--END
                           
                    
IF @@error <> 0                                
BEGIN                                            
 ROLLBACK TRAN Reverse_Receive                                
 PRINT N'An Error Occured While Reverse_Receive'                                   
END                                
ELSE                    
BEGIN                    
 COMMIT TRAN Reverse_Receive                
END 
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_SEARCH_WITHDRAWAL'
GO
CREATE PROCEDURE dbo.PM_SEARCH_WITHDRAWAL
	@PMTypeID int = -1,
	@BranchID int = -1,
	@AvailBusinessDay datetime = -1,
	@CusAcct nvarchar(36) = '',
	@RimNum nvarchar(30) = '',
	@location T_RequiredLocations readonly
AS

/*
 Creation Date   : 05-July-2015
 Creator         : Mohamed Elabd
 Description     : Search for the requested PM plates for withdrawal
*/

WITH outputTable AS(
SELECT PM_MovementDetails.Denom,
	   PM_MovementDetails.SerialNo,
	   PM_Movement.BusinessDate,
	   PM_Vendor.Vendor,
	   PM.VendorID,
	   PM.CashDrawer,
	   row_number() OVER (PARTITION BY PM_MovementDetails.Denom,
									   PM_MovementDetails.SerialNo,
									   PM_Vendor.Vendor,
									   PM.VendorID 
									   ORDER BY PM_Movement.BusinessDate DESC) AS RowNumber
FROM   PM_MovementDetails JOIN  PM_Movement
ON	   PM_MovementDetails.MovementID = PM_Movement.ID
JOIN   PM
ON	   PM_MovementDetails.SerialNo = PM.SerialNo
AND	   PM_MovementDetails.Denom = PM.Denom
AND    PM_MovementDetails.VendorID = PM.VendorID
AND    PM_MovementDetails.PMTypeID = PM.PMTypeID
JOIN   PM_Vendor   
ON     PM.VendorID = PM_Vendor.VendorID 
WHERE  PM_Movement.TransactionName = 'PreciousMetalRequestWithdrawal'
AND	   PM.PMTypeID = @PMTypeID
AND	   PM_Movement.BusinessDate <= @AvailBusinessDay
AND	   PM.CustomerAccount = @CusAcct
AND    PM.RIM = @RimNum
AND	   PM.Location IN(SELECT * FROM @Location) 
AND	   PM.Branch = @BranchID
)
SELECT * FROM outputTable WHERE RowNumber = 1
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_SearchAvailablePlat'
GO
CREATE   PROCEDURE [dbo].[PM_SearchAvailablePlat]          
     @PMType int = -1,              
     @VendorID int = -1,                 
     @Denom int = -1,                
     @Quantity int = -1,            
     @SerialNo varchar(100) = '', 
     @SerialTo varchar(100) = '',  
     @Prefix varchar(100) = '',       
     @CusAcct AccountNumber = '0',            
     @CashDrawerNumber as CashDrawerNumber  = -1,             
     @UserBranch as BranchID = -1,             
     --@Location T_RequiredLocations readonly,      
	 --@Status int = -1
	 @Status T_PM_Status readonly
AS                                  
      
/* 
 Creation Date     : 01 Dec 2013                                  
 Original Name     : dbo.PM_SearchAvailablePlat                                                       
 Description     : Search available plates using specific criteria                            
      
 Updator : Motaz Atiya                
 Date  : 26 May, 2015                
 Reason  :  - Search by Location instead of Status              
    - Change int 'Status' parameter to 'T_RequiredLocation' table type 'Location' parameter to allow multiple Locations search    
    
 Updator : Mohamed Elabd               
 Date  : 18 August 2015      
 Reason  : - Select PM.CustomerAccount , PM.RIM
		   - Change default value of @CusAcct to be '0'
		   
 Updator : Mostafa Sayed             
 Date    : [20/9/2017] 
 Reason  : -CR#GFSY00663 - KFH_CRQ14056_Gold Account
		   - Adding Prefix to search criteria  
		   - Adding FromSerial-ToSerial to search criteria   
		   - Removing location    
		   - Excluding CashDrawer , CustomerAccount ,RIM from search  criteria
 
*/                                 

IF @Quantity <> -1 SET ROWCOUNT @Quantity;    
      
SELECT      
 0 AS 'Select',     
 PM.Denom,
 '' AS 'Prefix',      
 PM.SerialNo,      
 --PMV.Vendor,      
 PM.VendorID  
 --PM.CustomerAccount,  
 --PM.RIM  
 
FROM PM      
LEFT JOIN PM_Vendor PMV     
ON pm.VendorID = PMV.VendorID     
WHERE (PM.PMTypeID = @PMType      
OR @PMType = -1)      
AND (PM.VendorID = @VendorID      
OR @VendorID = -1)      
AND (PM.Denom = @Denom      
OR @Denom = -1)      
--AND (PM.SerialNo like '%' + @SerialNo + '%'       
--OR @SerialNo = '')      
AND (PM.SerialNo like '%' + @Prefix + '%'    
OR @Prefix = '')  
AND (CONVERT(INT,substring(SerialNo, PatIndex('%[0-9]%', SerialNo),len(SerialNo))) between CONVERT(INT,@SerialNo) AND CONVERT(INT,@SerialTo)
OR @SerialTo='')
--AND (PM.CustomerAccount = @CusAcct      
--OR @CusAcct = '0')      
--AND (PM.CashDrawer = @CashDrawerNumber      
--OR @CashDrawerNumber = -1)      
AND (PM.Branch = @UserBranch      
OR @UserBranch = -1)      
/*AND PM.Location IN (SELECT            
FROM @Location)      
AND (PM.Status = @Status    
OR @Status = -1)*/
AND PM.Status IN(SELECT * FROM @Status)       
ORDER BY CONVERT(INT,substring(SerialNo, PatIndex('%[0-9]%', SerialNo),len(SerialNo)));
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_SEL_DENOM'
GO
CREATE proc [dbo].[PM_SEL_DENOM]      
@PreciousMetalID int = 1           
as          
        
/*          
 Creator : Asmaa Hafez        
 Created : 08/12/2013            
 Reason  : List of precious metal denomenations          
*/          
        
SELECT        
floor(Denomination) As 'Denom'     
FROM CashDenomination C           
inner join PM_Type P        
on C.CurrencyType = P.ISO_Code         
and P.PMTypeID = @PreciousMetalID        
      
select convert(varchar(100), cast(floor(12345.68) as int), 1)  


GO


------------------------------------------------------------------------
DROP_OLD_PROC 'dbo.PM_Sel_EntityDirection'
GO
CREATE   PROCEDURE [dbo].[PM_Sel_EntityDirection] --741,2                     
    @TranID int ,
    @Partner1 nvarchar (20)
         
AS                        
/* 
 Creator Name      : Nehal Ramadan                      
 Creation Date     : 05 OCT 2017                        
 Original Name     : dbo.PM_SEL_EntityDirectionOfPartner                                             
 Description       : gets all Tran Setup of the partner  

*/                        
  
set nocount on  

 
select * from PM_EntityDirection   where  TranID=@TranID and Partner1=@Partner1
 

GO




------------------------------------------------------------------------
DROP_OLD_PROC 'PM_SEL_INS_MOVEMENT'
GO
CREATE  PROCEDURE [dbo].[PM_SEL_INS_MOVEMENT]  --0 ,1,1030,1,'bank','nEHAL'                      
 @Mode int ,  
 @ToCode int ,  
 @ToID int ,  
 @PMTypeID int, 
 @TransactionName  [T_TransName] readonly, 
 @GetLogin bit,
 @EntityType varchar (20)='' ,
 @FromCode int   =NULL,  
 @FromID int  =NULL,  
 @RefNo ReferenceNumber =NULL
     
AS                          
/*     
 CreationDate: 26-6-2018  
 OriginalName: dbo.PM_SEL_INS_MOVEMENT    
 Creator  : Asmaa Gamal   
 Resone      : GFSY00663  ,GFSY00708
 Description : gets  or insert  in  PM_SEL_INS_MOVEMENT   
 Mode        : 0-> select, 1-> Insert  
 GetLogin    : 0-> select without loginid  ,1-> get login id
 
 
 UpdateDate: 30-10-2017   
 Modifier  : Sara Badwy  
 Reson      : GFSY00673, GFSY00674
 Description : gets LogINID of the fromID plus adding transactionName.   
 
*/      
set nocount on    
DECLARE @ID INT  , @PendingMovementID INT ,@TransactionNameIns [varchar](30)    
IF @Mode=0   
 BEGIN 
 IF @GetLogin=0
  SELECT  pm.* FROM pm_pendingmovement  pm   
  WHERE   
  pm.ToCode = @ToCode and  
  pm.ToID = @ToID   and  
  pm.PMTypeID = @PMTypeID  and 
  pm.TransactionName in(select * from @TransactionName) and 
  (pm.EntityType=@EntityType or @EntityType='') 
 Else
 SELECT  pm.*,O.LoginID FROM pm_pendingmovement  pm 
 inner join Operator O  ON pm.FromID=O.user_number
  WHERE   
  pm.ToCode = @ToCode and  
  pm.ToID = @ToID   and  
  pm.PMTypeID = @PMTypeID  and 
  pm.TransactionName in(select * from @TransactionName) and 
  (pm.EntityType=@EntityType or @EntityType='') 
 END  
  
ELSE  
  
BEGIN  
select @ID = MAX(ID)+1 from PM_PendingMovement 
IF @ID IS NULL
BEGIN
	select @ID=1
END
select @TransactionNameIns= [TranName] from  @TransactionName                 
INSERT INTO [dbo].[PM_PendingMovement]  
           ([ID]  
           ,[RefNo]  
           ,[ToCode]  
           ,[ToID]  
           ,[PMTypeID]  
           ,[EntityType]  
     ,[FromCode]   
     ,[FromID]  
     ,[TransactionName])  
     VALUES  
           (@ID   
           ,@RefNo   
           ,@ToCode   
           ,@ToID  
           ,@PMTypeID  
           ,@EntityType  
     ,@FromCode  
     ,@FromID  
     ,@TransactionNameIns)   
      
   SELECT 1   
      
  END  

GO





------------------------------------------------------------------------
DROP_OLD_PROC 'PM_SEL_INS_MOVEMENTDETAILS'
GO
create  PROCEDURE dbo.PM_SEL_INS_MOVEMENTDETAILS --1,'Sara2',1000,'bill',3000,1,1000             
 @Mode int ,  
 @RefNo ReferenceNumber ,  
 @Denomination T_PM_Denomination readonly     
             
AS                          
/*     
 CreationDate: 19-9-2017  
 OriginalName: dbo.PM_SEL_INS_MOVEMENTDETAILS    
 Creator  : Asmaa Gamal   
 Resone      : GFSY00663 , GFSY00708 Retrofit
 Description : gets  or insert  in  pm_pendingmovementDetails   
 Mode        : 0-> select, 1-> Insert   
 
 ModificationDate: 19-9-2017  
 Modifier  : Sara Badwy  
 Reason      : GFSY00673,GFSY00674
*/                          
    
set nocount on    
DECLARE @ID INT  , @PendingMovementID INT     
SELECT @PendingMovementID =  ID FROM PM_PendingMovement WHERE RefNo=@RefNo  
IF @Mode=0   
 BEGIN  
 SELECT  [ID]
			   ,[PendingMovementID]
			   ,[Denomination]
			   ,[DenomType]  AS CashDrawerType
			   ,[Count]
			   ,[Value]
			   , 1.0           AS InDrawerAmount    
		FROM pm_pendingmovementDetails WHERE PendingMovementID=@PendingMovementID
 END  
ELSE  
BEGIN 
declare @MaxID  INT;
SELECT @MaxID=MAX(ID) FROM [PM_PendingMovementDetails]
IF @MaxID IS NULL
BEGIN
	SELECT @MaxID = 1
END

INSERT INTO [dbo].[PM_PendingMovementDetails]  
           ([ID]  
           ,[PendingMovementID]  
           ,[Denomination]  
           ,[DenomType]  
           ,[Count]  
            ,[value]  
   )  
   SELECT @MaxID+[RowNumber],@PendingMovementID ,Denom,DenomType,[Count],Value
   FROM @Denomination 
   IF @@ERROR = 0 
   return 1
   else  
   return 0
END


GO

------------------------------------------------------------------------
DROP_OLD_PROC 'PM_SEL_PM'
GO
CREATE proc [dbo].[PM_SEL_PM]       
as      
      
/*      
 Creator : Mohamed  Barakat      
 Created : 04/12/2013        
 Reason  : lIST OF PRECIOUS METAL \    
     
 Asma Hafez      
*/      
SELECT  PMTypeID,PM,ISO_Code FROM PM_Type  


GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_SelectRefNo'
GO
CREATE   PROCEDURE [dbo].[PM_SelectRefNo]                      
    @ToPartnertble T_PM_SelectRefNo_ToPartnertble readonly,  
    @From_Type int = -1,  
    @From_Partner varchar(50) = null  
           
AS                        
/*                        
 Creation Date     : 01 Dec 2013                        
 Original Name     : dbo.PM_SelectRefNo                                             
 Description     : gets RefNo of all sent PM                       
*/                        
  
set nocount on  
  
SELECT pmov.RefNo,       
    pmov.Amount,                       
    pmov.From_Type,                       
    pmov.From_Partner,   
    pmov.From_CashDrawer,  
 pmov.To_Type,          
    pmov.To_Partner,         
    pmov.To_CashDrawer    
          
FROM PM_Movement pmov  
INNER JOIN @ToPartnertble toPartner  
on toPartner.ToTypeID = pmov.To_Type AND toPartner.ToID = pmov.To_Partner AND toPartner.ToCashDrawer = pmov.To_CashDrawer  
WHERE pmov.ID in(SELECT max(pmov2.ID) from PM_Movement pmov2   
WHERE pmov.RefNo = pmov2.RefNo   
group by pmov2.RefNo  
)  
AND pmov.MovementType = 0  
AND ( pmov.From_Type = @From_Type or @From_Type = -1)  
AND ( pmov.From_Partner = @From_Partner or @From_Partner is null)  


GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_Update_LOGHISTORY'
GO
CREATE   PROCEDURE dbo.PM_Update_LOGHISTORY  --'00000610000000021557'                    
	@EthixRelatedReference   nvarchar(250) ,
	@ReverseReferenceNumber  nvarchar(250)
	   
AS                        
/*   
 CreationDate: 23-10-2017
 OriginalName: dbo.PM_Update_LOGHISTORY  
 Creator	 : Asmaa Gamal 
 Reason      : GFSY00663,GFSY00708 Retrofit
 Description :  UPDATE  in  PM_logHistory 
 
      
*/                        
  
set nocount on  

		update 	PM_logHistory 
		set 
		IsReversed=1 ,
		ReverseReferenceNumber = @ReverseReferenceNumber
		where
		
	    EthixRelatedReference = @EthixRelatedReference 
		   
GO    

			
	
 




------------------------------------------------------------------------
DROP_OLD_PROC 'PM_Update_Plates'
GO
Create proc [dbo].[PM_Update_Plates]                                        
                              
 @PM [T_PM] readonly,          
 @PMTypeID  int  ,
 @Status	int                                       
                              
 As                                        
/*                                        
 CreationDate: 24-10-2017
 OriginalName: dbo.PM_Update_Plates  
 Creator	 : Asmaa Gamal 
 Resone      : GFSY00663,GFSY00708
 Description : update  pm table
                       
 
*/                                        
             
                       
Begin Transaction Update_PM                                  
                    
UPDATE PM                                  
                              
SET PM.Status=@Status                                
             
                              
FROM PM                                                       
INNER JOIN @PM PMT
ON 
PM.SerialNo = UPPER(PMT.SerialNo) AND PM.Denom = PMT.Denom                                  
                              
                                  
                    
             
IF @@error <> 0 BEGIN                                  
                              
ROLLBACK TRANSACTION Update_PM                                  
                              
PRINT N'An Error Occured While Update_PM'                                  
                              
RETURN -1                            
                              
END ELSE                            
BEGIN                            
COMMIT TRANSACTION Update_PM                            
RETURN 0                            
END 
Go



------------------------------------------------------------------------
DROP_OLD_PROC 'PM_Update_PM_Plates'
GO
Create proc [dbo].[PM_Update_PM_Plates]                                        
                              
 (@PM [T_PM_Add_Plates] readonly                                      
                              
 ,@RefNo ReferenceNumber                                     
                              
 ,@Amount numeric                                      
                              
 ,@From_Type int                                      
                              
 ,@From_Partner nvarchar(50)                                      
                              
 ,@From_CashDrawer CashDrawerNumber=null                                      
                              
 ,@To_Type int                                      
                              
 ,@To_Partner nvarchar(50)                                      
                              
 ,@To_CashDrawer CashDrawerNumber=null                                      
                              
 ,@TransactionName TransactionName                                      
                              
 ,@MovementType int                                      
                              
 ,@CustomerAccount AccountNumber                                      
                              
 ,@BusinessDate BusinessDate                                      
                              
 ,@Operator OperatorID)                                       
                              
 As                                        
                              
                                      
                              
/*                                        
                              
 Creator : Hatim AlSum                                         
                              
 Created : 01/12/2013                                        
                              
 Reason  : Update PM Plates with Status After each movement                                        
                              
                                      
                              
 Updator : Mohamed Barakat                                      
                              
 Date  : 01/12/2013                                      
                              
 Reason  :   Insert Into Insert  PM Plates into Tables (PM_Movement,PM_MovementDetails) with Status After each movement                           
                           
                           
 Updator : Doaa Nassar                           
                                  
 Date  : 30/07/2015                                   
                           
 Reason  :  Check on User_ID and CashDrawer value before update                          
            -1: PM Currently not assigned to a certain cash drawer or user                          
   -2: don't update current cash drawer or user (for PreciousMetalRequestWithdrawal transaction)                        
                           
                           
 Updator : Motaz Atiya                        
                                  
 Date  : 17 August, 2015                        
                           
 Reason  :  *Check on CustomerAccount, RIM and Status value before update                          
            empty string: PM Currently not assigned to a certain Customer              
            Value: PM is currently assigned to a certain customer                        
   -2: don't update current CustomerAccount, RIM or Status (for gold movement transactions)    
       
       
 Updator : Mohamed ElAbd  
     
 Date : 23 August, 2015  
     
 Reason : Calling PM_Check_Location procedure to Handle double posting    
    Return -2 if transaction has been already posted 
 
 Updator : Mostafa Sayed
 Date    : [1/10/2017]
 Reason  : -CR#GFSY00663 - KFH_CRQ14056_Gold Account
		   -Removing Location, PrevLocation , DepartmentID and Movement  
       
*/                                        
             
/*DECLARE @UpdateLocation INT = (SELECT TOP 1 PMT.Location FROM @PM AS PMT)      
DECLARE @Return_Check_Location INT       
EXEC @Return_Check_Location = dbo.PM_Check_Location @PM , @UpdateLocation      
      
IF(@Return_Check_Location = -2)      
 return -2*/     
       
DECLARE @CustAcc AccountNumber;            
                          
Begin Transaction Update_PM                                  
                              
UPDATE [Globalfs].[dbo].[PM]                                  
                              
SET /*PM.[Location] = PMT.Location,                                  
                              
 PM.[PrevLocation] = PM.Location,*/                                  
                              
 PM.[Status] =                      
 case when PMT.Status = -2                          
      then PM.[Status]                           
   else PMT.Status end,                      
                              
 PM.[Branch] = PMT.Branch,                                  
                              
 --PM.[DeptartmentID] = PMT.DeptartmentID,                                  
                              
 PM.[User_ID] =                           
 case when PMT.User_ID = -2                          
      then PM.[User_ID]                           
   else PMT.User_ID end,                                
                          
 PM.[CashDrawer] =                            
 case when  PMT.CashDrawer = -2                          
      then  PM.[CashDrawer]                          
   else  PMT.CashDrawer end,                                      
                         
 PM.[CustomerAccount] =                            
 case when  PMT.CustomerAccount = '-2'                          
      then  PM.[CustomerAccount]                          
   else  PMT.CustomerAccount end,                                
                              
 PM.[RIM] =                        
 case when  PMT.RIM = '-2'                          
      then  PM.[RIM]                 else  PMT.RIM end,                        
                              
 PM.[LastChanged] = GETDATE(),                                  
                              
 PM.[Updator] = PMT.Operator,              
               
 @CustAcc =               
 case when  PMT.CustomerAccount = '-2'                          
      then  PM.[CustomerAccount]                          
   else  PMT.CustomerAccount end              
                              
FROM PM                          
                              
INNER JOIN @PM PMT                                  
                              
 ON PM.SerialNo = PMT.SerialNo                                  
                              
 AND PM.PMTypeID = PMT.PMTypeID                                  
                              
 AND PM.VendorID = PMT.VendorID                                  
                              
 AND PM.Denom = PMT.Denom                                  
                    
                    
---------------------------------------------------              
                    
                              
/*DECLARE @MovementID INT                                  
                              
EXEC [dbo].[Get_Next_TableID] 'PM_Movement',                                  
                              
        'ID',                                  
                              
        1,                                  
                              
        @MovementID OUTPUT,                                  
                              
        0*/                                  
                              
                                  
                              
---------------------------------------------------                                      
                              
                                  
                              
/*EXEC dbo.PM_Add_PM_MOV @MovementID,                            
                              
      @RefNo,                                  
                              
      @Amount,                                  
                              
      @From_Type,                                  
                              
      @From_Partner,                                  
                              
      @From_CashDrawer,                                  
                              
      @To_Type,                                  
                              
      @To_Partner,                                  
                              
      @To_CashDrawer,                                  
                              
      @TransactionName,     
                              
      @MovementType,                                  
                              
      @CustAcc,                                  
                              
      @BusinessDate,                                  
                              
      @Operator*/                                  
                              
                                  
                              
---------------------------------------------------                                      
/*EXEC dbo.PM_Add_PM_Details @PM,                                  
                
       @MovementID,                                  
                              
       @Operator */                                 
                              
IF @@error <> 0 BEGIN                                  
                              
ROLLBACK TRANSACTION Update_PM                                  
                              
PRINT N'An Error Occured While Update_PM'                                  
                              
RETURN -1                            
                              
END ELSE                            
BEGIN                            
COMMIT TRANSACTION Update_PM                            
RETURN 0                            
END 
GO


------------------------------------------------------------------------
DROP_OLD_PROC 'PM_UpdateEntitiesBalance'
GO
CREATE   PROCEDURE [dbo].[PM_UpdateEntitiesBalance]          
	@PMType INT,
	@OwnerDescription VARCHAR(50),
	@IsIncreaser VARCHAR(1),--I,D
	@BankOrCustomer VARCHAR(1),--B,C
	@BalanceAmount DECIMAL,
	@cashDrawer INT =-1,
	@Bank INT =-1,
	@Region INT =-1,
	@Branch INT =-1
AS                                  
      
/* 
 Programmer   : Mostafa Sayed
 Creation Date: [06/25/2018] 
 Reason       : CR#GFSY00663 - KFH_ Gold Retrofit
 Notes		  :This procedure created to update PM_EntitiesBalance table
			   1-To increaser bank balance ->@IsIncreaser='I',@BankOrCustomer='B'
			   2-To decrease bank balance ->@IsIncreaser='D',@BankOrCustomer='B'
			   3-To increase customer balance ->@IsIncreaser='I',@BankOrCustomer='C'
			   4-To decrease customer balance ->@IsIncreaser='D',@BankOrCustomer='C'
*/

BEGIN TRANSACTION UpdatePMEntities
--Insert record for USER for first time of transaction execution if not exists
IF @OwnerDescription='USER'
BEGIN
	IF NOT EXISTS(SELECT * FROM PM_EntitiesBalance WHERE PMType=@PMType AND OwnerDescription='USER' AND @Bank=Bank AND Region=@Region AND Branch=@Branch AND CashDrawer=@cashDrawer)
	BEGIN
		DECLARE @ID INT
		SELECT @ID=MAX(PM_EntitiesBalance.id)+1 FROM PM_EntitiesBalance
		INSERT INTO PM_EntitiesBalance(id,PMType,OwnerDescription,Bank,Region,Branch,CashDrawer,BankBalance,CustomerBalance)
		SELECT @ID,@PMType,'USER',@Bank,@Region,@Branch,@cashDrawer,0,0
	END
END

IF EXISTS(SELECT * FROM PM_EntitiesBalance WHERE PMType=@PMType AND OwnerDescription=UPPER(@OwnerDescription) AND @Bank=Bank AND Region=@Region AND Branch=@Branch AND CashDrawer=@cashDrawer)
BEGIN
	IF UPPER(@BankOrCustomer)='B'  --bank balance  
	BEGIN
		UPDATE PM_EntitiesBalance
		SET BankBalance= 
		(CASE 
			WHEN UPPER(@IsIncreaser)='I' THEN  BankBalance+@BalanceAmount
			ELSE  BankBalance-@BalanceAmount
		END 
		)  
		WHERE  PMType=@PMType AND OwnerDescription=UPPER(@OwnerDescription) AND @Bank=Bank AND Region=@Region AND Branch=@Branch AND CashDrawer=@cashDrawer
	END
	ELSE						--customer balance
	BEGIN
	UPDATE PM_EntitiesBalance
		SET CustomerBalance= 
		(CASE 
			WHEN UPPER(@IsIncreaser)='I' THEN  CustomerBalance+@BalanceAmount
			ELSE  CustomerBalance-@BalanceAmount
		END 
		)  
		WHERE  PMType=@PMType AND OwnerDescription=UPPER(@OwnerDescription) AND @Bank=Bank AND Region=@Region AND Branch=@Branch AND CashDrawer=@cashDrawer
	
	END
END
IF @@error <> 0 BEGIN                                                       
	ROLLBACK TRANSACTION UpdatePMEntities                                                              
	PRINT N'An Error Occured While Updating PMEntities'                                                             
	RETURN -1                                                     
END 
ELSE                            
	BEGIN                            
	COMMIT TRANSACTION UpdatePMEntities                            
	RETURN 0                            
END 
GO



------------------------------------------------------------------------
DROP_OLD_PROC 'select_allSignedOnTellers_ActiveDrawer'
GO
CREATE procedure [dbo].[select_allSignedOnTellers_ActiveDrawer]        
   @UserNumber int,        
   @BranchID BranchID,      
   @CashDrawerNo CashDrawerNumber,      
   @UserClassID int = null,    
   @CurrencyCode currencytype = null      
as      
/*        
creationdate: 2017-12-05        
originalname: dbo.select_allSignedOnTellers_ActiveDrawer        
programmer: Sara Badwy        
description: get all signed on users with active cashdrawer   
*/     
set nocount on    
SELECT DISTINCT        
 V_O_S.LoginID,         
 V_O_S.User_Number        
FROM  V_Operator V_O_S      
 INNER JOIN  CashDrawer cd        
 ON cd.AssignedToTeller = V_O_S.user_number    
 LEFT JOIN dbo.CashDrawerStart CDS    
 ON cd.CashDrawerNumber = CDS.CashDrawerNumber    
WHERE (V_O_S.SignedOnAt  <> ''  AND V_O_S.SignedOnAt IS NOT NULL)   
 AND V_O_S.Branch  = @BranchID        
 AND V_O_S.user_number <> @UserNumber        
 AND cd.AttachedToVault = @CashDrawerNo      
 AND (V_O_S.UserClassID = @UserClassID OR @UserClassID IS NULL)    
 AND ((CDS.CurrencyType = @CurrencyCode) OR (@CurrencyCode IS NULL))      
 AND  cd.IsActive=1 
  
 GO


------------------------------------------------------------------------
 
 Drop_old_proc 'dbo.Select_CashDrawerDetail_PM'
 GO
 Create PROCEDURE dbo.Select_CashDrawerDetail_PM   --Select_CashDrawerDetail_PM -1,1,1,1,9,'XAU'
 @FromPM int  =-1 ,
 @Bank BankID = -1,  
 @Region RegionID =-1,  
 @Branch BranchID =-1,  
 @CashDrawerNumber CashDrawerNumber =-1,  
 @CurrencyType CurrencyType  =''   
 
AS  
/*  
 CreationDate: 26-6-2018
 OriginalName: dbo.Select_CashDrawerDetail_PM  
 Creator	 : Asmaa Gamal 
 Resone      : GFSY00663-GFSY00708 Retrofit
 Description : Select the avaible denomination for specific currency PM   
   the teller cash drawer  
 Output      : FieldName,IsCashIn,denomination   
    
  
  
*/  
  
set nocount on  
IF @FromPM=-1
Begin  
declare @t table (  
 CurrencyType varchar(4),  
 Denomination decimal(12,4) not null,  
 CashDrawerType varchar(30) COLLATE SQL_Latin1_General_CP1_CS_AS,  
 InDrawerAmount money default 0,  
 DisplayOrder int,
 DisplayOrderCashInCashOut int)  
  
  

 insert into @t (  
  CurrencyType,  
  Denomination,  
  CashDrawerType,  
  DisplayOrder,
  DisplayOrderCashInCashOut)  
 select CurrencyType,  
  Denomination,  
  CashDrawerType,  
  DisplayOrder ,
  DisplayOrderCashInCashOut 
 from dbo.CashDenomination  
 where CurrencyType = @CurrencyType  
  
 
  
update t  
set t.InDrawerAmount = cdd.InDrawerAmount  
from dbo.CashDrawerDetail as cdd  
inner join @t as t  
on cdd.CurrencyType = t.CurrencyType  
where cdd.Bank = @Bank  
and cdd.Region = @Region  
and cdd.Branch = @Branch  
and cdd.Denomination = t.Denomination  
and cdd.CashDrawerNumber = @CashDrawerNumber  
and cdd.CashDrawerType = t.CashDrawerType  
  
select Denomination,  
 CashDrawerType,  
 InDrawerAmount  
from @t  
order by DisplayOrder,  
DisplayOrderCashInCashOut,
 CashDrawerType,  
 Denomination 
 End
 Else
 Begin
  select     
   convert (DECIMAL(12,4),Denom) as Denomination ,
   'Plates'  as  CashDrawerType,
   count (Denom) as Count,
   convert (DECIMAL(12,6),Denom) *count (Denom)  as Value ,
   convert (DECIMAL(12,6),Denom) *count (Denom) as InDrawerAmount  
  --convert (money, (count (Denom))) as InDrawerAmount 
   from PM	 where   Status =3 group By	  Denom
 End 
 GO


drop_old_proc 'GetTellerConfigByID'
go
Create procedure dbo.GetTellerConfigByID 
@LoginID as OperatorID
as
/*  
Creator : Ahmed Helmy  
Date    : 13/05/2012 
Reason  : GetTellerConfigByID

 Updator	:	Hatim AlSum
 Date		:	22/12/2013
 Reason		:   add IsTreasury Column

*/
SELECT T.*,D.IsTreasury FROM [dbo].[TellerConfig] T
inner join dbo.Department D on T.DepartmentID=D.Id
WHERE [User_ID] = (select user_number from operator where LoginID = @LoginID)

go
DROP_OLD_PROC 'ThresholdAmountsDelete'
GO
CREATE Procedure ThresholdAmountsDelete 
@ID int
AS  
/*  
 Developer     : Mohamed Elabd
 Creation Date : 26-July-2018
 Purpose       : CBD_ACM16085_Cash Deposit Thresh Hold Charges - CR# GFSY00714
*/  
  
DELETE FROM ThresholdAmounts WHERE ID = @ID

GO
DROP_OLD_PROC 'ThresholdAmountsGetSetup'
GO
CREATE Procedure ThresholdAmountsGetSetup
@AccountNumber nvarchar(50),
@RimClass nvarchar(50)
AS  
/*  
 Developer     : Mohamed Elabd
 Creation Date : 26-July-2018
 Purpose       : CBD_ACM16085_Cash Deposit Thresh Hold Charges - CR# GFSY00714
*/  
  
Declare @count int = 0
  
SELECT @count = Count(AccountNumber) 
FROM ThresholdAmounts
WHERE AccountNumber = @AccountNumber
AND RimClass = @RimClass

IF @count > 0
begin
-- Select Account setup
SELECT 'AccountNumber' AS [Setup],
MinThresholdAmount,
MinThresholdCharge,
MaxThresholdAmount,
MaxThresholdCharge 
FROM ThresholdAmounts
WHERE AccountNumber = @AccountNumber
AND RimClass = @RimClass
end
ELSE
BEGIN
-- Select rim class setup
SELECT 'RimClass' AS [Setup],
MinThresholdAmount,
MinThresholdCharge,
MaxThresholdAmount,
MaxThresholdCharge 
FROM ThresholdAmounts
WHERE RimClass = @RimClass
AND (AccountNumber = '' OR AccountNumber IS NULL)
END

GO
DROP_OLD_PROC 'ThresholdAmountsInsert'
GO
CREATE Procedure ThresholdAmountsInsert
@RimClass nvarchar(50),  
@AccountNumber nvarchar(50) = '',  
@MinThresholdAmount money = 0,  
@MinThresholdCharge money = 0,  
@MaxThresholdAmount money = 0,  
@MaxThresholdCharge money = 0,
@Updator nvarchar(50)
AS  
/*  
 Developer     : Mohamed Elabd
 Creation Date : 26-July-2018
 Purpose       : CBD_ACM16085_Cash Deposit Thresh Hold Charges - CR# GFSY00714
*/  
  
INSERT INTO ThresholdAmounts(RimClass, AccountNumber, MinThresholdAmount, MinThresholdCharge, MaxThresholdAmount, MaxThresholdCharge,Creator,Updator)
VALUES(@RimClass, @AccountNumber, @MinThresholdAmount, @MinThresholdCharge, @MaxThresholdAmount, @MaxThresholdCharge,@Updator,@Updator)

GO
DROP_OLD_PROC 'ThresholdAmountsSelectAll'
GO
CREATE Procedure ThresholdAmountsSelectAll
AS  
/*  
 Developer     : Mohamed Elabd
 Creation Date : 26-July-2018
 Purpose       : CBD_ACM16085_Cash Deposit Thresh Hold Charges - CR# GFSY00714
*/  
  
SELECT ID,
RimClass,
AccountNumber,
MinThresholdAmount,
MinThresholdCharge,
MaxThresholdAmount,
MaxThresholdCharge 
FROM ThresholdAmounts

GO
DROP_OLD_PROC 'ThresholdAmountsUpdate'
GO
CREATE Procedure ThresholdAmountsUpdate
@ID int,
@MinThresholdAmount money = 0,  
@MinThresholdCharge money = 0,  
@MaxThresholdAmount money = 0,  
@MaxThresholdCharge money = 0,
@Updator nvarchar(50)
AS  
/*  
 Developer     : Mohamed Elabd
 Creation Date : 26-July-2018
 Purpose       : CBD_ACM16085_Cash Deposit Thresh Hold Charges - CR# GFSY00714
*/  
  
UPDATE ThresholdAmounts
SET MinThresholdAmount = @MinThresholdAmount,  
MinThresholdCharge = @MinThresholdCharge,  
MaxThresholdAmount = @MaxThresholdAmount,  
MaxThresholdCharge = @MaxThresholdCharge, 
Updator = @Updator
WHERE ID = @ID

GO
DROP_OLD_PROC 'select_allSignedOnTellers_ActiveDrawer'
GO
CREATE procedure [dbo].[select_allSignedOnTellers_ActiveDrawer]        
   @UserNumber int,        
   @BranchID BranchID,      
   @CashDrawerNo CashDrawerNumber,      
   @UserClassID int = null,    
   @CurrencyCode currencytype = null ,
   @IsTellerMovement int = 0          
as      
/*        
creationdate: 2017-12-05        
originalname: dbo.select_allSignedOnTellers_ActiveDrawer        
programmer: Sara Badwy        
description: get all signed on users with active cashdrawer   
   
Modifier:Nehal Ramadan      
Date:2-9-2018
description: attachtovault for teller movement is handled  
*/     
set nocount on   
if(@IsTellerMovement = 1 )
begin
set @CashDrawerNo = (select CashDrawer.AttachedToVault from  CashDrawer       
     where  CashDrawerNumber = @CashDrawerNo        
       and Branch = @BranchID            
    ) 
end 
 
SELECT DISTINCT        
 V_O_S.LoginID,         
 V_O_S.User_Number        
FROM  V_Operator V_O_S      
 INNER JOIN  CashDrawer cd        
 ON cd.AssignedToTeller = V_O_S.user_number    
 LEFT JOIN dbo.CashDrawerStart CDS    
 ON cd.CashDrawerNumber = CDS.CashDrawerNumber    
WHERE (V_O_S.SignedOnAt  <> ''  AND V_O_S.SignedOnAt IS NOT NULL)   
 AND V_O_S.Branch  = @BranchID        
 AND V_O_S.user_number <> @UserNumber        
 AND cd.AttachedToVault = @CashDrawerNo      
 AND (V_O_S.UserClassID = @UserClassID OR @UserClassID IS NULL)    
 AND ((CDS.CurrencyType = @CurrencyCode) OR (@CurrencyCode IS NULL))      
 AND  cd.IsActive=1 
  
 GO
 Drop_old_proc IRBulkInsertIntoIR     
  go

CREATE PROCEDURE dbo.IRBulkInsertIntoIR 
    @Table IRBulkTableType READONLY    
    AS    
/*      
CreationDate: 2017-5-31     
OriginalName: dbo.IRBulkInsertIntoIR      
Programmer  : Karim Mahmoud
Description : Bulk Insert rows in IR Table

Reason: GFSY00717 - Add 2 column FLD_111,FLD_121
Developer: Nada Elshafie
Modification date: 14Aug2018
*/   
BEGIN TRY  
    BEGIN TRANSACTION   
       INSERT INTO IR
        (        
			 FileRefNo,        
			 FilePathName,       
			 MsgRefNo,        
			 StatusID,        
			 ActionId,        
			 PaymentMethodID,        
			 DateTimeStamp,        
			 PreparedBy,        
			 MsgValueDate,        
			 ValueDate,        
			 DrAccountNo,        
			 DrAccountNo_AcctType,      
			 DrAccountNo_ApplType,      
			 DrAccountNo_DepLoan,      
			 DrAccountName,        
			 DrCurrency,        
			 DrAmount,        
			 DrAddress,        
			 SenderBank,        
			 DrExchangeRate,        
			 DrCommission,        
			 CrAccountNo,        
			 CrAccountNo_AcctType,     
			 CrAccountNo_ApplType,      
			 CrAccountNo_DepLoan,      
			 CrAccountName,        
			 CrCurrency,        
			 CrAmount,        
			 CrAddress,        
			 OrderingCustomer,        
			 CrExchangeRate,        
			 CrCommission,        
			 OriginalMsg,        
			 Fld_50K,        
			 Fld_59,        
			 Charge_Det,       
			 Account_With_Ref,    
			 Account_With_Ac,    
			 Account_With_Name,    
			 ValueCurrency,    
			 Order_Cust_Name,    
			 Order_Cust_Add1,    
			 Order_Cust_Add2,    
			 Order_Inst,    
			 Order_Inst_Name,    
			 Order_Inst_Add1,    
			 BeneficiaryAccount,    
			 FLD_70,    
			 FLD_71A,    
			 BeneficiaryName,    
			 BeneficiaryAddress,    
			 Updator,    
			 DrValueDate,    
			 CrValueDate,    
			 DrNarrative,    
			 CrNarrative,    
			 FLD_20,    
			 FLD_23,    
			 FLD_33,    
			 FLD_52,    
			 FLD_53,    
			 MsgType,    
			 ExceptionList,    
			 Is_FLD_20_Duplicate,    
			 DrRealExchangeRate,    
			 CrRealExchangeRate,     
			 TTAmount ,    
			 TTCurrency ,    
			 DrSellExchangeRate,    
			 CrBuyExchangeRate ,  
			 IBAN   ,    
			 Ordering_IBAN,    
			 Sender_BIC,    
			 CrRimNo,  
			 Ben_Inst_BIC,
			 FLD_111,
			 FLD_121 
		)       
		SELECT 
		
			 irbt.FileRefNo,        
			 irbt.FilePathName,        
			 irbt.MsgRefNo,        
			 irbt.StatusID,        
			 irbt.ActionId,        
			 irbt.PaymentMethodID,        
			 irbt.DateTimeStamp,        
			 irbt.PreparedBy,        
			 irbt.MsgValueDate,        
			 irbt.ValueDate,        
			 irbt.DrAccountNo,        
			 irbt.DrAccountNo_AcctType,      
			 irbt.DrAccountNo_ApplType,      
			 irbt.DrAccountNo_DepLoan,      
			 irbt.DrAccountName,        
			 irbt.DrCurrency,       
			 irbt.DrAmount,        
			 irbt.DrAddress,        
			 irbt.SenderBank,        
			 irbt.DrExchangeRate,        
			 irbt.DrCommission,        
			 irbt.CrAccountNo,      
			 irbt.CrAccountNo_AcctType,      
			 irbt.CrAccountNo_ApplType,      
			 irbt.CrAccountNo_DepLoan,       
			 irbt.CrAccountName,        
			 irbt.CrCurrency,     
			 irbt.CrAmount,        
			 irbt.CrAddress,        
			 irbt.OrderingCustomer,        
			 irbt.CrExchangeRate,        
			 irbt.CrCommission,        
			 irbt.OriginalMsg,        
			 irbt.Fld_50K,        
			 irbt.Fld_59,        
			 irbt.Charge_Det,    
			 irbt.Account_With_Ref,    
			 irbt.Account_With_Ac,    
			 irbt.Account_With_Name,    
			 irbt.ValueCurrency,    
			 irbt.Order_Cust_Name,    
			 irbt.Order_Cust_Add1,    
			 irbt.Order_Cust_Add2,    
			 irbt.Order_Inst,    
			 irbt.Order_Inst_Name,    
			 irbt.Order_Inst_Add1,    
			 irbt.BeneficiaryAccount,    
			 irbt.FLD_70,     
			 irbt.FLD_71A,    
			 irbt.BeneficiaryName,    
			 irbt.BeneficiaryAddress,    
			 irbt.Updator,  
			 irbt.DB_DrValueDate,   
			 irbt.DB_CrValueDate,    
			 irbt.DB_DrNarrative,    
			 irbt.DB_CrNarrative,    
			 irbt.DB_FLD_20,    
			 irbt.DB_FLD_23,    
			 irbt.DB_FLD_33,    
			 irbt.DB_FLD_52,    
			 irbt.DB_FLD_53,    
			 irbt.MsgType,    
			 irbt.ExceptionList,    
			 irbt.Is_FLD_20_Duplicate,    
			 irbt.DrRealExchangeRate,        
			 irbt.CrRealExchangeRate,    
			 irbt.TTAmount,    
			 irbt.TTCurrency,    
			 irbt.DrSellExchangeRate,    
			 irbt.CrBuyExchangeRate,  
			 irbt.IBAN,  
			 irbt.Ordering_IBAN,    
			 irbt.Sender_BIC,   
			 '',--CrRimNo varchar(100),  
			 '',--Ben_Inst_BIC varchar(100)
			 irbt.FLD_111,
			 irbt.FLD_121  
		
		FROM @Table irbt
    COMMIT  
END TRY  
BEGIN CATCH  
  
    IF @@TRANCOUNT > 0  
        ROLLBACK  
    return -1;
END CATCH  
  
  
GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc TLR_IR_LockupMsgs
Go
create  procedure dbo.TLR_IR_LockupMsgs --'ITSOFT\karim.mahmoud','2017/04/29'
 @OperatorID     OperatorID,    
 @business_date  smalldatetime,
 @FileRefNo     ReferenceNumber  = null,
 @StatusId       int  = null,      
 @PaymentMethodId  int  = null       ,
 @CorresBank  varchar(100) = null,
 @DrCurrency  char(3) = null,
 @CrCurrency  char(3) = null,
 @MsgDate  varchar(10) = null,
 @CrAccountNo  varchar(12) = null,
 @OredringCustomer varchar(100) = null,
 @SenderReference varchar(50) = null ,
 @DrAmount  decimal(21,6) = 0 ,
 @CrAmount  decimal(21,6) = 0 ,
 @MsgRefNo     ReferenceNumber   = null
as      
/*      
CreationDate: 2005-7-20      
OriginalName: dbo.TLR_IR_LockupMsgsByFileRef      
Programmer  : Sayed Hussein      
Description : Select Messages filter by one (or all) of the following criteria       
              {FileRefNo,StatusId,PaymentMethodId}   
         And operator id for visibility   
Output:        
Assumption:       
      
ModifiedDate: 2005-7-21      
Modifer:      Sayed Hussein        
ModifyReason: Group by file ref     

ModifiedDate: 29/4/2008     
Modifer:      hany nasr        
ModifyReason: performance issue


ModifiedDate: 23/6/2008     
Modifer:      Mohamed Gad        
ModifyReason: Adding Branch,MsgType,DrAccountNo_DepLoan and IR.* to the return result

ModifiedDate: 26 January 2009
Modifer:   Hany A Hassan	   
ModifyReason:   Change the Data Type of @FileRefNo,@MsgRefNo to ReferenceNumber 

ModifiedDate:	2011-04-06
Modifer:		Osama Orabi	   
ModifyReason:   add two columns two return recordset

ModifiedDate: 2012-10-29  
Modifer:  Hatim ALSum      
ModifyReason:   add Missing Columns to return RecordSet 

ModifiedDate: 2015-05-27 
Modifer:  Asmaa Gamal       
ModifyReason:   Fix issue # GFSX08949 remove dublicate retrive columns (ValueDate,MsgValueDate)

ModifiedDate: 2018-08-28 
Modifer:  Nada Elshafie      
ModifyReason:  GFSY00717 - retrieve FLD_111 and FLD_121

*/      
      
declare @IS_IR_SuperVisor as int    
select @IS_IR_SuperVisor = T.IR_SuperVisor 
from  dbo.TellerConfig T 
inner  join 
 dbo.Operator O 
on  O.user_number = T.[User_Id] 
where  O.LoginID = @OperatorID    
 
declare @sql varchar(8000)
 
set  @sql = 
'select MsgRefNo,
 FLD_20 as SenderRefNo,
 S1.ShortDescription as Status, 
 DrAmount as DebitAmount,
 ValueDate ,
 SenderBank,
 FileRefNo,
 FilePathName,
 S2.ShortDescription as PaymentMethod ,
 isnull(S3.ShortDescription, '''') as Action,
 isnull(S4.ShortDescription, '''') as SendTo,
 StatusID,
 PaymentMethodID,
 ActionID,
 SendToID,
 AccountOfficerID,
 DateTimeStamp,
 PreparedBy,
 SpecialRateNeeded,
 MsgValueDate,
 VoucherOK,
 AuthorizedBy,
 ApprovedBy,
 DrAccountNo,
 DrAccountName,
 DrCurrency,
 DrAmount,
 DrAddress,
 DrExchangeRate,
 DrCommission,
 CrAccountNo,
 CrAccountName,
 CrCurrency,
 CrAmount,
 CrAddress,
 OrderingCustomer,
 CrExchangeRate,
 CrCommission,
 GTDTicket,
 OriginalMsg,
 Fld_50K,
 Fld_59,
 Charge_Det,
 BeneficiaryAmount,
 BeneficiaryCurrency,
 BeneficiarySellRate,
 BeneficiaryBuyRate,
 BeneficiaryGTDTicket,
 BeneficiaryName,
 BeneficiaryIDType,
 BeneficiaryIDNumber,
 BeneficiaryPhone,
 BeneficiaryAddress,
 BeneficiaryNarrative,
 Row_Version,
 LockedByID,
 IR.Updator,
 IR.LastChanged,
 Branch,
 MsgType,
 DrAccountNo_DepLoan,
 MsgValueDate, 
 IR.DrAccountNo_AcctType,
 IR.DrAccountNo_ApplType,
 IR.CrAccountNo_AcctType,  
 IR.CrAccountNo_ApplType,  
 IR.CrAccountNo_DepLoan,
 IR.MT103Generated,
 IR.MT202Generated,
 IR.Account_With_Ref,
 IR.Account_With_Ac,
 IR.Account_With_Name,
 IR.ValueCurrency,
 IR.Order_Cust_Name,
 IR.Order_Cust_Add1,
 IR.Order_Cust_Add2,
 IR.Order_Inst,
 IR.Order_Inst_Name,
 IR.Order_Inst_Add1,
 IR.BeneficiaryAccount,
 IR.FLD_70,
 IR.FLD_71A,
 IR.DrValueDate,
 IR.CrValueDate,
 IR.CrNarrative,
 IR.DrNarrative,
 IR.FLD_20,
 IR.FLD_23,
 IR.FLD_33,
 IR.FLD_52,
 IR.FLD_53,
 IR.Is_FLD_20_Duplicate,
 IR.ExceptionList,
 IR.OldStatusID,
 IR.OldDrAccountNo,
 IR.OldDrAccountNo_AcctType,
 IR.OldDrAccountNo_ApplType,
 IR.OldDrAccountNo_DepLoan,
 IR.OldDrAccountName,
 IR.OldDrCurrency,
 IR.OldDrAmount,
 IR.OldDrExchangeRate,
 IR.OldDrCommission,
 IR.OldCrAccountNo,
 IR.OldCrAccountNo_AcctType,
 IR.OldCrAccountNo_ApplType,
 IR.OldCrAccountNo_DepLoan,
 IR.OldCrAccountName,
 IR.OldCrCurrency,
 IR.OldCrAmount,
 IR.OldCrExchangeRate,
 IR.OldCrCommission,
 IR.OldDrValueDate,
 IR.OldCrValueDate,
 IR.OldCrNarrative,
 IR.OldDrNarrative,
 IR.DrRealExchangeRate,
 IR.CrRealExchangeRate,
 IR.TTAmount,
 IR.TTCurrency,
 IR.DrSellExchangeRate,
 IR.CrBuyExchangeRate,
 IR.IBAN,
 IR.Ordering_IBAN,
 IR.CrRimNo,
 IR.Sender_BIC,
 IR.FLD_72,
 IR.Ben_Inst_BIC,
 0 as CrExchangeGain,   
 0 as DrExchangeGain,
 IR.FLD_111,
 IR.FLD_121   
from    IR
inner  join 
 Status S1  
on   IR.StatusID = S1.[Id]
And S1.StatusTypeID = 12  
inner  join 
 Status S2  
on   IR.PaymentMethodID = S2.[Id] 
And S2.StatusTypeID = 13
LEFT  join 
 Status S3  
on   IR.ActionID = S3.[Id]
And S3.StatusTypeID = 14
Left  join 
 Status S4
on   IR.SendToID = S4.[Id]
And S4.StatusTypeID = 15
where     
(
 (SendToID = 5 /*SendToTeller*/OR SendToID = 6 /*SendAllToTeller*/)    
    OR 
 (    
     (SendToID = 1 /*SendToAccountOfficer*/OR SendToID = 2 /*SendAllToAccountOfficer*/)
  And AccountOfficerID = '''+@OperatorID+'''    
 )    
 OR
 (
  (SendToID = 3 /*SendToSupervisor*/OR SendToID = 4 /*SendAllToSupervisor*/)
  And '+convert(varchar(10),@IS_IR_SuperVisor)+' = 1
 )    
)
 
AND ValueDate <= ''' + convert(varchar, @business_date,111) + ''''
 
if (@FileRefNo is not null)       
 set @sql = @sql + ' AND (FileRefNo      = '''+@FileRefNo+''')'
 
if (@MsgRefNo is not null)       
 set @sql = @sql + ' AND (MsgRefNo       = '''+@MsgRefNo+''')'
 
if (@PaymentMethodId is not null)       
 set @sql = @sql + ' AND (PaymentMethodId   = '+convert(varchar(10),@PaymentMethodId)+')'
 
if (@StatusId is not null)       
 set @sql = @sql + ' AND  (StatusId     = '+convert(varchar(10),@StatusId) +' )'
 
if ((@CorresBank is not null) and (@CorresBank <> ''))
 set @sql = @sql + ' AND DrAccountName = '''+@CorresBank+''''
 
if ((@DrCurrency is not null) and (@DrCurrency <> ''))
 set @sql = @sql + ' AND DrCurrency = '''+@DrCurrency+''''
 
if ((@CrCurrency is not null) and (@CrCurrency <> ''))
 set @sql = @sql + ' AND CrCurrency = '''+@CrCurrency+''''
 
if ((@MsgDate is not null) and (@MsgDate <> ''))
 set @sql = @sql + ' AND MsgValueDate = '''+@MsgDate+''''
 
if ((@CrAccountNo is not null) and (@CrAccountNo <> ''))
 set @sql = @sql + ' AND ( CrAccountNo = '''+@CrAccountNo+''')'
 
if ((@OredringCustomer is not null) and (@OredringCustomer <> ''))
 set @sql = @sql + ' AND ( Fld_50K like ''%'+@OredringCustomer+'%'')'
 
if ((@SenderReference is not null) and (@SenderReference <> ''))
 set @sql = @sql + ' AND ( Fld_20 LIKE ''%'+@SenderReference+'%'')'
 
if ((@DrAmount is not null) and (@DrAmount <> 0))
 set @sql = @sql + ' AND ( DrAmount = '+convert(varchar(50),@DrAmount)+')'
 
if ((@CrAmount is not null) and (@CrAmount <> 0))
 set @sql = @sql + ' AND ( CrAmount = '+convert(varchar(50),@CrAmount)+')'
 
 set @sql= @sql + ' And (LockedByID is NULL or LockedByID ='''' or LockedByID <> ''' + @OperatorID+ ''')'
--print @sql
EXEC (@sql)
go
--End of Automatic Generation


DROP_OLD_PROC 'PM_Add_PM_Plates'
GO
CREATE PROC [dbo].[PM_Add_PM_Plates] (@PM [T_PM_Add_Plates] READONLY,          
         --@RefNo ReferenceNumber,          
         --@PMType_ID int,          
         @Amount NUMERIC,          
         @From_Type INT,          
         @From_Partner VARCHAR,          
         @From_CashDrawer CashDrawerNumber=NULL,          
         @To_Type INT,          
         @To_Partner VARCHAR,          
         @To_CashDrawer CashDrawerNumber=NULL,          
         @TransactionName TransactionName,          
         @MovementType INT,          
         @CustomerAccount AccountNumber,          
         @BusinessDate BusinessDate,          
         @Operator OperatorID--,        
         --@Locations T_RequiredLocations READONLY
         )          
AS          
/*            
 Creator : Mohamed  Barakat          
 Created : 01/12/2013            
 Reason  : Insert  PM Plates into Tables (PM,PM_Movement,PM_MovementDetails) with Status After each movement        
         
 Updator : Motaz Atiya        
 Date  : 27 May, 2015        
 Reason  : Allow receiving PMs which are reversed form treasury or sent to vendor  
 
 Updator : Mostafa Sayed
 Date    : [1/10/2017]
 Reason  : -CR#GFSY00663 - KFH_CRQ14056_Gold Account
		   -Removing Location, PrevLocation, DepartmentID and Movement
 Updator : Nehal Ramadan
 Date    : [6/25/2018]
 Reason  : -CR#GFSY00708 - KFH_CRQ14056_Gold Account_RetroFit
		   -Removing Location, PrevLocation, DepartmentID and Movement
  Updator : Nehal Ramadan  
 Date    : [9/6/2018]  
 Reason  : -CR#GFSY00708 - KFH_CRQ14056_Gold Account_RetroFit  
     
		   
*/          
if exists(select * from PM as p inner join @PM as temp on p.SerialNo=temp.SerialNo and p.VendorID=temp.VendorID and p.PMTypeID = temp.PMTypeID)
begin
return 1
end
      
BEGIN TRANSACTION Insert_PM        
-- Receiving      
-- Receive new PM        
INSERT INTO PM (SerialNo    
, PMTypeID    
, VendorID    
, Denom    
--, Location    
, Status    
, Branch    
--, DeptartmentID    
, USER_ID    
, CashDrawer    
, CustomerAccount    
, RIM    
, Creator    
, Updator)    
    
 SELECT    
  TPM.[SerialNo],    
  TPM.[PMTypeID],    
  TPM.[VendorID],    
  TPM.[Denom],    
  --TPM.[Location],    
  TPM.[Status],    
  TPM.[Branch],    
  --TPM.[DeptartmentID],    
  TPM.[User_ID],    
  TPM.[CashDrawer],    
  TPM.[CustomerAccount],    
  TPM.[RIM],    
  @Operator,    
  @Operator    
 FROM @PM TPM    
 LEFT JOIN PM    
  ON TPM.SerialNo = pm.SerialNo    
  AND TPM.PMTypeID = pm.PMTypeID    
  AND TPM.VendorID = pm.VendorID    
  AND TPM.Denom = pm.Denom    
 WHERE PM.SerialNo IS NULL    
 AND PM.PMTypeID IS NULL    
 AND PM.VendorID IS NULL    
 AND PM.Denom IS NULL;    
        
-- Receive reversed form treasury or sent to vendor PMs        
UPDATE PM    
SET SerialNo = TPMP.[SerialNo],    
 PMTypeID = TPMP.[PMTypeID],    
 VendorID = TPMP.[VendorID],    
 Denom = TPMP.[Denom],    
 --Location = TPMP.[Location],    
 --PrevLocation = PM.Location,    
 Status = TPMP.[Status],    
 Branch = TPMP.[Branch],    
 --DeptartmentID = TPMP.[DeptartmentID],    
 USER_ID = TPMP.[User_ID],    
 CashDrawer = TPMP.[CashDrawer],    
 CustomerAccount = TPMP.[CustomerAccount],    
 RIM = TPMP.[RIM],    
 Creator = @Operator,    
 Updator = @Operator    
FROM @PM TPMP    
INNER JOIN PM    
 ON TPMP.SerialNo = PM.SerialNo    
 AND TPMP.PMTypeID = PM.PMTypeID    
 AND TPMP.VendorID = PM.VendorID    
 AND TPMP.Denom = PM.Denom    
 --AND PM.Location IN (SELECT    
 -- *    
 --FROM @Locations);    
        
-------------------------------------------------------------------        
-- Get next movement ID        
/*DECLARE @MovementID INT;        
        
EXEC [dbo].[Get_Next_TableID] 'PM_Movement',        
        'ID',        
        1,        
        @MovementID OUTPUT,        
        0;        
        
-- Insert Into PM Movements          
EXEC dbo.PM_Add_PM_MOV @MovementID,        
      '',        
      @Amount,        
      @From_Type,        
      @From_Partner,        
      @From_CashDrawer,        
      @To_Type,        
      @To_Partner,        
      @To_CashDrawer,        
      @TransactionName,        
      @MovementType,        
      @CustomerAccount,        
      @BusinessDate,        
      @Operator;        
        
--------------------------------------------------------------------        
-- Insert movement details        
        
EXEC dbo.PM_Add_PM_Details @PM,        
       @MovementID,        
       @Operator;        
 */       
--------------------------------------------------------------------        
        
IF @@ERROR <> 0 BEGIN        
ROLLBACK TRANSACTION Insert_PM        
PRINT N'An Error Occured While Insert_PM';        
RETURN -1  
END ELSE  
BEGIN  
COMMIT TRANSACTION Insert_PM  
RETURN 0  
END  


GO

--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Select_IR_By_MsgRefNo
Go

create proc dbo.Select_IR_By_MsgRefNo  
 @MsgRefNo ReferenceNumber,  
 @user_number OperatorID  
as  
/*  
 BY : Ahmed Fahim  
 Date : 2005-07-10  
 Reason : Used To select the details for a specific IR  
  
ModifiedDate:   25 January 2009  
Modifer  : Hany A Hassan      
ModifyReason:   Change the Data Type of @MsgRefNo to ReferenceNumber   

ModifiedDate:   2009 - 12 - 16  
Modifer  : Amira Kamel    
ModifyReason:   select from ir if locked = null or by the current user
  
  ModifiedDate:  28/8/2018
Modifer  : mahmoud.saad    
ModifyReason:   Fix Issue GFSX13180 add condition on updating LockedByIDId coloum on IR table that StatusID must be 4 OR 6 (Not Posted Message).
  
  
*/  
if exists  
 ( Select s.LongDescription  ,   
   i.FileRefNo ,  
   i.MsgRefNo ,  
   i.DrCurrency ,  
   i.DrAmount ,  
   i.DrExchangeRate ,  
   i.CrCurrency ,  
   i.CrAmount ,  
   i.CrExchangeRate ,  
   i.Fld_50K ,  
   i.Fld_59 
    
  From  IR i  
  inner join  
   status s  
  on s.id = i.StatusID  
  inner join  
   StatusType st  
  on s.StatusTypeID = st.id  
  and st.id = 12  
  and i.StatusID in (4,6)
  WHERE  MsgRefNo = @MsgRefNo  
  and  (i.LockedByID is null Or i.LockedByID=@user_number )
 )  
begin  
 update IR  
 set LockedByID  = @user_number  
 where MsgRefNo = @MsgRefNo  
  
 if (@@rowcount = 1)  
 begin  
  Select  s.LongDescription  ,   
   i.FileRefNo ,  
   i.MsgRefNo ,  
   i.DrCurrency ,  
   i.DrAmount ,  
   i.DrExchangeRate ,  
   i.CrCurrency ,  
   i.CrAmount ,  
   i.CrExchangeRate ,  
   i.Fld_50K ,  
   i.Fld_59    
    
  From  IR i  
  inner join  
   status s  
  on s.id = i.StatusID  
  inner join  
   StatusType st  
  on s.StatusTypeID = st.id  
  and st.id = 12  
  WHERE  MsgRefNo = @MsgRefNo  
 end  
 else  
 begin  
  Select  '' as LongDescription  ,   
  '' as FileRefNo ,  
  '' as MsgRefNo ,  
  '' as DrCurrency ,  
  '' as DrAmount ,  
  '' as DrExchangeRate ,  
  '' as CrCurrency ,  
  '' as CrAmount ,  
  '' as CrExchangeRate ,  
  '' as Fld_50K ,  
  '' as Fld_59    
 end  
end  
else  
begin  
 Select  '' as LongDescription  ,   
  '' as FileRefNo ,  
  '' as MsgRefNo ,  
  '' as DrCurrency ,  
  '' as DrAmount ,  
  '' as DrExchangeRate ,  
  '' as CrCurrency ,  
  '' as CrAmount ,  
  '' as CrExchangeRate ,  
  '' as Fld_50K ,  
  '' as Fld_59   
end 


Go
--End of Automatic Generation
Drop_old_proc TLR_STOCK_CHECK_MOVE_RECEIVE
Go

create proc dbo.TLR_STOCK_CHECK_MOVE_RECEIVE	--TLR_STOCK_CHECK_MOVE_RECEIVE	'001CO00004118'
 @RefNo nvarchar(max)
as  
/*  
 BY		: Ahmed Osman  
 Date	: 13/09/2018
 Reason : Used TO Check if this movement has been Recieved before or not 
*/  

if exists (SELECT * FROM StockMovement WHERE RefNo = @RefNo AND MovementTypeID = 2)	-- Recieved
Begin
	SELECT 1;
End
ELSE
BEGIN
	SELECT 0;
END
GO
DROP_OLD_PROC 'PM_SEL_INS_MOVEMENT'
GO
CREATE  PROCEDURE [dbo].[PM_SEL_INS_MOVEMENT]  --0 ,1,1030,1,'bank','nEHAL'                      
 @Mode int ,  
 @ToCode int ,  
 @ToID int ,  
 @PMTypeID int, 
 @TransactionName  [T_TransName] readonly, 
 @GetLogin bit,
 @EntityType varchar (20)='' ,
 @FromCode int   =NULL,  
 @FromID int  =NULL,  
 @RefNo ReferenceNumber =NULL
     
AS                          
/*     
 CreationDate: 26-6-2018  
 OriginalName: dbo.PM_SEL_INS_MOVEMENT    
 Creator  : Asmaa Gamal   
 Resone      : GFSY00663  ,GFSY00708
 Description : gets  or insert  in  PM_SEL_INS_MOVEMENT   
 Mode        : 0-> select, 1-> Insert  
 GetLogin    : 0-> select without loginid  ,1-> get login id
 
 
 UpdateDate: 30-10-2017   
 Modifier  : Sara Badwy  
 Reson      : GFSY00673, GFSY00674
 Description : gets LogINID of the fromID plus adding transactionName.  
 
  
 UpdateDate: 16-09-2018   
 Modifier  : Sara Badwy  
 Reson      : GFSX13193
 Description :Check if refNo exists
 
*/      
set nocount on    
DECLARE @ID INT  , @PendingMovementID INT ,@TransactionNameIns [varchar](30) ,@RefExist int   
IF @Mode=0   
 BEGIN 
 IF @GetLogin=0
  SELECT  pm.* FROM pm_pendingmovement  pm   
  WHERE   
  pm.ToCode = @ToCode and  
  pm.ToID = @ToID   and  
  pm.PMTypeID = @PMTypeID  and 
  pm.TransactionName in(select * from @TransactionName) and 
  (pm.EntityType=@EntityType or @EntityType='') 
 Else
 SELECT  pm.*,O.LoginID FROM pm_pendingmovement  pm 
 inner join Operator O  ON pm.FromID=O.user_number
  WHERE   
  pm.ToCode = @ToCode and  
  pm.ToID = @ToID   and  
  pm.PMTypeID = @PMTypeID  and 
  pm.TransactionName in(select * from @TransactionName) and 
  (pm.EntityType=@EntityType or @EntityType='') 
 END  
  
ELSE  
  
BEGIN  
select @ID = MAX(ID)+1 from PM_PendingMovement 
IF @ID IS NULL
BEGIN
	select @ID=1
END
select @RefExist=ID  from [PM_PendingMovement] where RefNo=@RefNo
IF(@RefExist IS NULL)
Begin
select @TransactionNameIns= [TranName] from  @TransactionName                 
INSERT INTO [dbo].[PM_PendingMovement]  
           ([ID]  
           ,[RefNo]  
           ,[ToCode]  
           ,[ToID]  
           ,[PMTypeID]  
           ,[EntityType]  
     ,[FromCode]   
     ,[FromID]  
     ,[TransactionName])  
     VALUES  
           (@ID   
           ,@RefNo   
           ,@ToCode   
           ,@ToID  
           ,@PMTypeID  
           ,@EntityType  
     ,@FromCode  
     ,@FromID  
     ,@TransactionNameIns)   
      
   SELECT 1   
      
      END
      ELSE
      SELECT 3 --Duplicate Ref No
  END  

GO


