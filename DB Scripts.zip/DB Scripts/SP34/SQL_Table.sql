USE Globalfs
GO
IF NOT EXISTS (SELECT * FROM SYS.objects WHERE name =  'TCR_LOG' AND TYPE = 'U')
	BEGIN
		CREATE TABLE [dbo].[TCR_LOG]  
		(
			user_number internal_user_ID,
			Bank BankID,
			Region RegionID,
			Branch BranchID,
			JNLSequance int,
			BusinessDate date,
			InsertTime datetime default GETDATE(),
			TranName TransactionName,
			TCR_JNL_ID int,
			XML xml,
			XML_Type nvarchar(20),
			Session_GUID nvarchar(max)
		)
	END
GO

IF NOT EXISTS (SELECT * FROM SYS.objects WHERE name =  'TCRDevices' AND TYPE = 'U')
	BEGIN
		CREATE TABLE [dbo].[TCRDevices]  
		(
			ID int primary key IDENTITY(1,1),
			DeviceName nvarchar(250),
			Creator	OperatorID	NOT NULL,
			Created	datetime NOT NULL,
			Updator	OperatorID NOT NULL,
			LastChanged datetime NOT NULL,
		)
		ALTER TABLE TCRDevices ADD CONSTRAINT DF_TCRDevices_Creator DEFAULT (suser_sname()) FOR Creator                            
		ALTER TABLE TCRDevices ADD CONSTRAINT DF_TCRDevices_Created DEFAULT (getdate()) FOR Created                         
		ALTER TABLE TCRDevices ADD CONSTRAINT DF_TCRDevices_Updator DEFAULT (suser_sname()) FOR Updator                        
		ALTER TABLE TCRDevices ADD CONSTRAINT DF_TCRDevices_LastChanged DEFAULT (getdate()) FOR LastChanged
	END
GO

IF NOT EXISTS (SELECT * FROM SYS.objects WHERE name =  'TCR_Totals' AND TYPE = 'U')
	BEGIN
		CREATE TABLE [dbo].[TCR_Totals](
			[Branch_unit] [dbo].[hierarchy_node#] NOT NULL,
			[BusinessDate] [dbo].[SmallDate] NOT NULL,
			[user_number] [dbo].[internal_user_ID] NOT NULL,
			[TCRDeviceID] [int] NOT NULL,
			[BucketID] [dbo].[Bucket_ID] NOT NULL,
			[CurrencyType] [dbo].[CurrencyType] NOT NULL,
			[Batch] [int] NOT NULL,
			[Counter] [int] NOT NULL,
			[Amount] [money] NOT NULL,
			[created] [datetime] NOT NULL,
			[TransactionTime] [datetime] NOT NULL,
		 CONSTRAINT [PK_TCR_Totals] PRIMARY KEY NONCLUSTERED 
		(
			[Branch_unit] ASC,
			[BusinessDate] ASC,
			[user_number] ASC,
			[BucketID] ASC,
			[CurrencyType] ASC,
			[Batch] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [IndexGroup]
		) ON [DynamicData]


		SET ANSI_PADDING ON
		

		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Business Date, with Zero for Hours, Minutes and Seconds' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TCR_Totals', @level2type=N'COLUMN',@level2name=N'BusinessDate'
		

		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'User Number from Operator Table' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TCR_Totals', @level2type=N'COLUMN',@level2name=N'user_number'
		

		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Currency Type - USD, EUR, CAD, etc' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TCR_Totals', @level2type=N'COLUMN',@level2name=N'CurrencyType'
		

		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Batch Number' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TCR_Totals', @level2type=N'COLUMN',@level2name=N'Batch'
		

		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'count of transactions' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TCR_Totals', @level2type=N'COLUMN',@level2name=N'Counter'
		

		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Total Amount from Transactions' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TCR_Totals', @level2type=N'COLUMN',@level2name=N'Amount'
		

		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Date and Time Row was Created' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TCR_Totals', @level2type=N'COLUMN',@level2name=N'created'
		

		EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Transaction Date and Time, especially for Starting Cash' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'TCR_Totals', @level2type=N'COLUMN',@level2name=N'TransactionTime'
		

		ALTER TABLE [dbo].[TCR_Totals] ADD  DEFAULT ('USD') FOR [CurrencyType]
		

		ALTER TABLE [dbo].[TCR_Totals] ADD  DEFAULT (getdate()) FOR [created]
		
	END
GO

IF NOT EXISTS(SELECT 1 FROM sys.columns 
          WHERE Name = N'UseTCR'
          AND Object_ID = Object_ID(N'RulesTranConfig'))
BEGIN
    ALTER TABLE RulesTranConfig
	ADD UseTCR BIT DEFAULT 0 WITH VALUES
END
GO

IF NOT EXISTS(SELECT 1 FROM sys.columns 
          WHERE Name = N'TCRLoginID'
          AND Object_ID = Object_ID(N'Operator'))
BEGIN
    ALTER TABLE Operator
	ADD TCRLoginID nvarchar(50) NULL
END
GO

IF NOT EXISTS(SELECT 1 FROM sys.columns 
          WHERE Name = N'TCRDeviceID'
          AND Object_ID = Object_ID(N'Operator'))
BEGIN
    ALTER TABLE Operator
	ADD TCRDeviceID int null foreign key references TCRDevices(ID)
END
GO
--Programmer : Mostafa Sayed
--Date       : [27/06/2019]
--Reason     : Issus#GFSX13693
------------------------------
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_TYPE = 'PRIMARY KEY' AND CONSTRAINT_NAME = 'PK_TCR_Totals' AND TABLE_NAME = 'TCR_Totals' AND TABLE_SCHEMA ='dbo')
BEGIN
	ALTER TABLE TCR_Totals
	DROP CONSTRAINT PK_TCR_Totals
	ALTER TABLE TCR_Totals
	ADD CONSTRAINT PK_TCR_Totals PRIMARY KEY (Branch_unit,BusinessDate,user_number,TCRDeviceID,BucketID,CurrencyType,Batch)
END
GO
/*
CreationDate: 2018-12-02                                             
Programmer: Ahmed Osman                              
Description:  Enh GFSY00739 - KFH_ACM16035_Special Needs Customer 
*/
---------------------------------------------------------------------------------------------------------------------------------------------------------
/*
CreationDate: 2018-12-02                                             
Programmer: Ahmed Osman                              
Description: CREATE TABLE CustomExceptionChargesConditions || CR#GFSY00739 - Add Custom Exception Charges 
*/

IF not exists (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'CustomExceptionChargesConditions')
BEGIN
CREATE TABLE CustomExceptionChargesConditions (
	[ID]				[bigint] IDENTITY (1, 1) NOT NULL,
	[ConditionId]		[int] NOT NULL,
	[Seq]				[int] NULL,
	[OperandsDataType]	[varchar](max)	COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Operand1]			[varchar](max)	COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Operator]			[varchar](max)	COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Operand2]			[varchar](max)	COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[LogicalOperator]	[char](10)		COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ArrayIndex1]		[int] NULL,
	[ArrayIndex2]		[int] NULL,
	[Creator]			[dbo].[OperatorID] NOT NULL				CONSTRAINT [DF_CustomExceptionChargesConditions_Creator]		DEFAULT (suser_sname()),
	[Created]			[datetime] NOT NULL						CONSTRAINT [DF_CustomExceptionChargesConditions_Created]		DEFAULT (getdate()),
	[Updator]			[dbo].[OperatorID] NOT NULL				CONSTRAINT [DF_CustomExceptionChargesConditions_Updator]		DEFAULT (suser_sname()),
	[LastChanged]		[datetime] NOT NULL						CONSTRAINT [DF_CustomExceptionChargesConditions_LastChanged]	DEFAULT (getdate()),
	[Row_ID]			[uniqueidentifier] ROWGUIDCOL  NOT NULL CONSTRAINT [DF_CustomExceptionChargesConditions_Row_ID]			DEFAULT (newid())
)
END
GO
---------------------------------------------------------------------------------------------------------------------------------------------------------
/*
CreationDate: 2018-12-02                                             
Programmer: Ahmed Osman                              
Description: ALTER TABLE ExceptionCharges || CR#GFSY00739 - Add Custom Exception Charges 
*/

IF NOT EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'ExceptionCharges' AND Column_Name = 'CustomException')
BEGIN
	ALTER TABLE ExceptionCharges
	ADD CustomException int NULL 
END
GO
--/************Mostafa Helmy Defect #GFSX13741*****************************/

Use Globalfs
GO

if not exists ( select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='CertifiedCheques' and COLUMN_NAME='isLCN')
begin
	ALTER TABLE CertifiedCheques  
	ADD isLCN int Default 0 Not Null     
end

Go
--/************Mostafa Helmy Defect #GFSX13741*****************************/


