﻿USE [Globalfs]
GO
       
If Not Exists(Select * From ServicePacks Where BasePackageName = 'ETHIX-Branch_2.00.46' And SP_Number = 43)
Begin
Insert Into ServicePacks(BasePackageName,SP_Number,SP_Name, LastPackageName, BriefDescription, DetailedDescription,IncludeWholeFilesOnly,DontRemoveTmpFldrWhenFinished,OptionalSourceList,Comments,PatchNumber)
Values('ETHIX-Branch_2.00.46', 43,'SP43_ETHIX-Branch_2.0.46.0','SP42_ETHIX-Branch_2.0.46.0','SP43_ETHIX-Branch_2.0.46.0','', 1, 0, '', '',0)
End
GO

PRINT 'Start. Script for CR# GFSY00901 DML Script'
------------------------------------------------------------------------------------------------------------------

	If Not Exists(select * From SQLstrings Where AccessID = 1100196)
	Begin
		Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
		Values (1,1100196,'GetErrorCodeDetails','p',1,'Globalfs','dbo.GetErrorCodeDetails',0,'','','ITSOFT\shaimaa.nasser','ITSOFT\shaimaa.nasser','Oct 07 2021 10:39AM',' Get Error details by code',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','May 20 2019 12:02PM',' ','',0,0,0,NULL,NULL,0,0,0,0)
	End
	go
		If Not Exists(select * From SQLstrings Where AccessID = 1100197)
	Begin
		Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
		Values (1,1100197,'GetErrorSetupEnabled','p',0,'Globalfs','dbo.GetErrorSetupEnabled',0,'','','ITSOFT\shaimaa.nasser','ITSOFT\shaimaa.nasser','Oct 07 2021 10:39AM','  Get result from param to fire setup for locaul fund reversal conditions',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','May 20 2019 12:02PM',' ','',0,0,0,NULL,NULL,0,0,0,0)
	End 
	go
----------------------------------------------------- RulesParam ---------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------
	If Not Exists(Select *  From RulesTranField Where TranID = 794 And FieldID = 179) --TLR_CARD_HOLDER_NAME
	Begin
	 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern ,isDupable,MaxArray,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH)
	 Values (794,179,1, 0,0,  NULL,'','',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0)
	End
	GO
	If Not Exists(Select *  From RulesTranField Where TranID = 794 And FieldID = 378) --TLR_ID2_EXP
	Begin
	 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern ,isDupable,MaxArray,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH)
	 Values (794,378,1, 0,0,  NULL,'','',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0)
	End
	GO
----------------------------------------------------- RulesParam ---------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------
	declare @paramid int
	select @paramid=MAX(paramid)+1 from RulesParam

	 If Not Exists(Select * From RulesParam Where ParamName = 'Enable_ErrorCode_Setup')
	Begin
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@paramid,'Enable_ErrorCode_Setup','determine if new setup for Error Code Reversal is applied or not ',NULL,0,0,0,'','Static    ','','Sep  22 2021 8:22AM',N'ITSOFT\shaimaa.nasser','Sep  22 1900 12:00AM','Dec 31 9999 12:00AM',1)
	End
	 If Not Exists(Select * From RulesTranFldParam Where TranName = 'LocalFundTransferByAccount' And Param = 'Enable_ErrorCode_Setup')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,DataType,LastChanged,Description)
	 Values ('LocalFundTransferByAccount','Transaction','Enable_ErrorCode_Setup','N' ,'nvarchar','Sep  22 2021 8:22AM','determine if new setup for Error Code Reversal is applied or not')
	End
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'EFTSBillsPayment' And Param = 'Enable_ErrorCode_Setup')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,DataType,LastChanged,Description)
	 Values ('EFTSBillsPayment','Transaction','Enable_ErrorCode_Setup','N' ,'nvarchar','Sep  22 2021 8:22AM','determine if new setup for Error Code Reversal is applied or not')
	End
	GO


	PRINT 'End. Script for CR# GFSY00901 DML Script'
--Devolper	 :	Aya Tarek 
--Date       :	[8/4/2022]		
--Reason     :	CR#GFSY00903 ACM19499-BLOM-Certified Cheques Changes
------------------------------------------------------------------------------------------------
--------------------------------

----------------------------------SQLstrings-----------------------
IF Not Exists(select * from SQLstrings where AccessID = 1100198)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile , Developer , Updator , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100198 , 'SELECT_PREFIX_FOR_BRANCH' , 'p' , 1, 'Globalfs' , 'dbo.Select_Prefix_For_BranchBank' , 0 , '' , '' , 'ITSOFT\aya.tarek' , 'ITSOFT\aya.tarek' , 'Retrieves prefix from table BranchConfig by Bank,region and branch' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO

--=============================================================
--Devolper	:	Ahmed Atef
--Date		:	[20/03/2022]
--Reason	:	Enh ACM19258 - KFHB - Local Fund Transfer By GL
--=============================================================
-----------------------------------
-- RulesParam & RulesTranFldParam -
-----------------------------------
IF NOT EXISTS(Select * From RulesParam Where ParamName='LocalFundChargeAmount')
BEGIN
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'LocalFundChargeAmount','charge amount for local fund transfer in case GL','',0,1,0,'','Static','')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'LocalFundTransferByAccount' AND FieldName = 'LocalFundChargeAmount' AND Param = 'LocalFundChargeAmount' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'LocalFundTransferByAccount' , 'LocalFundChargeAmount' , 'LocalFundChargeAmount' , '0' ,'ITSOFT\ahmed.atef' , 'int')
END
GO
-------------------
-- RulesTranField -
-------------------
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 793 AND FieldID = 1480)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(793, 1480, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2022-03-20 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2022-03-20 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2022-03-20 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'PaymentMode', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 793 AND FieldID = 1575)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(793, 1575, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', CONVERT(DATETIME, '2022-03-20 00:00:00', 102), 1, NULL, '', CONVERT(DATETIME, '2022-03-20 00:00:00', 102), N'ITSOFT\\ahmed.atef', 1, 
			CONVERT(DATETIME,'2022-03-20 00:00:00', 102), CONVERT(DATETIME, '9998-12-31 00:00:00', 102), 0, NULL, 0, 0, 'TLR_GL', 1, - 1, NULL, NULL, NULL)
END
GO
----------------------
-- RulesTranField_ex -
----------------------
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 793 And FieldID Is Null And FieldIDInPage = '_grpPaymentMode')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (793,NULL,'Teller','_grpPaymentMode',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',0,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 793 And FieldID Is Null And FieldIDInPage = '_optPaymentMode')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (793,NULL,'Teller','_optPaymentMode',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 793 And FieldID Is Null And FieldIDInPage = '_GLNumber')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (793,NULL,'Teller','_GLNumber',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',0,NULL,NULL,NULL,NULL)
END
GO
--Field50_SenderIBAN
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 793 And FieldIDInPage = '_txt_Order_Customer_IBAN')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (793,NULL,'Teller','_txt_Order_Customer_IBAN',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
--Field50_SenderName
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 793 And FieldIDInPage = '_txt_Order_Customer_Title_1')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (793,NULL,'Teller','_txt_Order_Customer_Title_1',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
--Field50_SenderAddress
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 793 And FieldIDInPage = '_txt_Order_customer_Addr1')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (793,NULL,'Teller','_txt_Order_customer_Addr1',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1,NULL,NULL,NULL,NULL)
END
GO
--==================================================================
--Devolper	:	Ahmed Atef
--Date		:	[20/04/2022]
--Reason	:	Enh ACM19688 - BIsB_Merchant ID For Non-Personal RIM
--==================================================================
-------------------------
-- RulesTranDescriptors -
-------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_MERCHANT_ID')
Begin
 Insert Into RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
 Values (565, 'TLR_MERCHANT_ID', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
End
GO
If Not Exists(Select * From RulesTranDescriptors Where TranID = 578 And DSC_Name = 'TLR_MERCHANT_ID')
Begin
 Insert Into RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
 Values (578, 'TLR_MERCHANT_ID', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
End
GO
-------------------
-- RulesTranField -
-------------------
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 565 AND FieldID = 442)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(565, 442, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', 'Apr 20 2022  3:50PM', 1, NULL, '', 'Apr 20 2022  3:50PM', N'ITSOFT\\ahmed.atef', 1, 
			'Apr 20 2022  3:50PM', 'Apr 20 9999  3:50PM', 0, NULL, 0, 0, 'MerchantID', 1, - 1, NULL, NULL, NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 578 AND FieldID = 442)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, ToHost, FromHost, DSC_Pattern, Developer, LastChanged, isDupable, MaxArray, Notes, Created, Updator, RowStatus, EffectiveDate, ExpirationDate, IsReadOnly, jTarget, 
                         BindValue, isReadOnlyImaging, FieldAlias, ShowInDWH, IndexInDWH, IsPrimaryKey, PrimaryKeyAlias, PrimaryKeySeq)
	VALUES(578, 442, 1, 0, 0, NULL, 'ITSOFT\\ahmed.atef', 'Apr 20 2022  3:50PM', 1, NULL, '', 'Apr 20 2022  3:50PM', N'ITSOFT\\ahmed.atef', 1, 
			'Apr 20 2022  3:50PM', 'Apr 20 9999  3:50PM', 0, NULL, 0, 0, 'MerchantID', 1, - 1, NULL, NULL, NULL)
END
GO
----------------------
-- RulesTranField_ex -
----------------------
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 565 And FieldID Is Null And FieldIDInPage = '_txt_MerchantId')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (565,NULL,'Teller','_txt_MerchantId',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',0,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 578 And FieldID Is Null And FieldIDInPage = '_txt_MerchantId')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (578,NULL,'Teller','_txt_MerchantId',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',0,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 565 And FieldID Is Null And FieldIDInPage = '_lbl_MerchantId')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (565,NULL,'Teller','_lbl_MerchantId',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',0,NULL,NULL,NULL,NULL)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 578 And FieldID Is Null And FieldIDInPage = '_lbl_MerchantId')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 VALUES (578,NULL,'Teller','_lbl_MerchantId',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',0,NULL,NULL,NULL,NULL)
END
GO

----------------------------
--BankTPIInterface table----
----------------------------
If Not Exists(Select * From BankTPIInterface Where BankID = 1 And FieldCode = 'CUS')
Begin
 Insert Into BankTPIInterface(BankID,FieldCode,NoOfParameters,RequiredSequence)
 Values (1,'CUS',240,'N')
End
Else
Begin
	Update BankTPIInterface set NoOfParameters = 240 Where BankID = 1 And FieldCode = 'CUS'
End
go
---------------------------------------
--HostCoreService----------------------
---------------------------------------
---------------------------------------
--GetNonPersonalRimInfo----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetNonPersonalRimInfo') AND FieldName='MerchantID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetNonPersonalRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'MerchantID','nvarchar',0,0,N'0','O')
END 
GO


--===============================================================================
--Devolper	:	Ibrahim Harby
--Date		:	[30/Jan/2022]
--Reason	:	GFSY00894
--================================================================================
--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
exec p_next_id 'RulesDescriptor' ,1

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106123 and Name = 'RegPayToThrdPrtyPOThroughEFTS')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106123	,'RegPayToThrdPrtyPOThroughEFTS',0,'Labels','Regular Payment To 3rd Party Purchase Orders Through EFTS')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106123 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106123 , 1025, N'السداد المنتظم لأوامر شراء الطرف الثالث من خلال EFTS'	)
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106149 and Name = 'SELECT_ONLY_ONE')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106149	,'SELECT_ONLY_ONE',0,'Labels','You can select only one record , Do you want to change old selection ?')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106149 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106149 , 1036, N'Vous ne pouvez sélectionner que un seul enregistrement. Voulez-vous modifier le ancienne sélection ?'	)
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106149 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106149 , 1025, N'يمكن اختيار سطر واحد فقط . هل تريد تغيير الاختيار القديم ؟'	)
End
GO


----------------------------------
-- Menu_Action & Menu_Definition -
----------------------------------
IF NOT EXISTS (SELECT * FROM Menu_Action WHERE MenuActionID = 905)
BEGIN
    INSERT INTO Menu_Action (MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Enabled) 
    VALUES(905,1,1106123,'Regular Payment To 3rd Party Purchase Orders Through EFTS',2,'RegPayToThrdPrtyPOThroughEFTS',1)
END
GO

IF NOT EXISTS (SELECT * FROM Menu_Definition WHERE MenuActionID = 905)
BEGIN
INSERT INTO Menu_Definition (MenuID,MenuKey,Parent,MenuActionID) 
    VALUES(2513,'17334','1733',905)
END
GO

------------------
-- RulesTranName -
------------------
IF NOT EXISTS (SELECT * FROM RulesTranName WHERE TranID = 886)
BEGIN
INSERT INTO RulesTranName(TransactionName,TranID,Description,DSC_Description,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,RowStatus,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
	VALUES('RegPayToThrdPrtyPOThroughEFTS', 886, 'Regular Payment To 3rd Party Purchase Orders Through EFTS',1106123,10,'Teller',113,1,'',1,0,1,1,0,0,0,1,0,0,0,0,1,0,0,0,1,0,0,NULL,NULL,NULL,0,NULL,0,0,0,0,NULL,null,1)
END
GO

--------------
-- Component -
--------------
If Not Exists(Select * From Component Where ComponentID = 324)
Begin
 Insert Into Component(ComponentID,AppID,ComponentName,ComponentType,Description,ProjectDirectory,ProjectFile,ProjectType,ProjectTarget,ProductionGroup,isSourceShipped,TargetDirectory,TypeLibrary,TypeLibVersion,GUID,VersionInfoFile,FileVersion,ComponentSize,InstallDirectory,ProductionGroup2,InstallDirectory2,RowStatus,WiseProject,BuildChangesOnly,SymbolsFile,ProjectGUID)
 Values (324,1,N'RegPayToThrdPrtyPOThroughEFTS','DLL','',N'IBS.Net\Source\BP\Custom\RegPayToThrdPrtyPOThroughEFTS',N'RegPayToThrdPrtyPOThroughEFTS.csproj','C#2010',N'Debug','Client_NonRegistered',0,N'..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\',NULL,NULL,NULL,NULL,'2.0.46.0',106496,N'shared.net\Source\bin\Common\Teller',NULL,NULL,1,N'GFSTellerdotNetClient.wsm',1,N'RegPayToThrdPrtyPOThroughEFTS.pdb',NULL)
End
go


------------------------
-- RulesContainerTrans -
------------------------
If Not Exists(Select * From RulesContainerTrans WHERE TranName = 'RegPayToThrdPrtyPOThroughEFTS')
Begin
 Insert Into RulesContainerTrans(container_name,TranName)
 Values ('Teller','RegPayToThrdPrtyPOThroughEFTS')
End
go


--------------------
-- RulesTranConfig -
--------------------

If Not Exists(SELECT * FROM RulesTranConfig WHERE TranID =  886)
Begin
 Insert Into RulesTranConfig(TranID,DenomRequired,AccountingEntries,DrAccountCategoryID ,CrAccountCategoryID,AllowEmptyAccountingEntries,FeesCategoryID,ReadAllAccountingEntries,PrintOption,ForcePositioning,EnableCharges,SalesMessageActive,FutureStaleChequeDays,BackDatedStaleChequeDays,ValidateStaleCheque,StaleChequeAction,StaleChequeDefaultDate,EscWarningEnabled,Blacklisted,BlacklistedAction,BenPmtStrict,BenPmtWarning,HasCheckList,CheckListCategoryID,ShowAvlBal,AutoPrintPassBook,DaysAllowedForReversal,CashFollowAcctCurr,useFX,CheckDrawerTypeRestrictions,use_XPath_app,SameRIMForCharge,SameCurrencyForCharge,PrimaryIDExpiryAction,PrimaryIDExpiryVal,RecoveryReversal,CustomerInquiry,ReviewVouchersBeforePrinting,UpdDateReqired,UpdDateValue,UpdDateAction,IsFinancialTran,CHK_AccumilativeInfoMessage,CHK_IncludeAccumilative,OpenSessionRequired,SupportResend,CheckBillPastDueDT,PastDueDTAction,UseExpressions,WorkOnNightlyModeAllowed)
 Values (886,0,0,11,11,1,8,0,1,0,0,0,0,0,0,'Warning',0,0,1,'STOP', 0,0,0,0,1,0,10,1,1,0,0,0,0,'Warning',0,1,0,1,0,1,0,0,0,0,1,0,0,'Warning',1,0)   
End
go

IF NOT EXISTS (SELECT * FROM dbo.RulesTranFldParam Where TranName = 'RegPayToThrdPrtyPOThroughEFTS' AND FieldName = 'AmountCurrType' AND Param = 'CurrencyCategoryID' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,DataType)
Values( 'RegPayToThrdPrtyPOThroughEFTS' , 'AmountCurrType' , 'CurrencyCategoryID' , 2 , 'nvarchar')
END
GO

--------------------
-- Transaction Steps -
--------------------
If Not Exists(Select * From RulesTranSteps Where TranID = 886 and StepSequence = 10)
Begin
Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,EffectiveDate,ExpirationDate,RowStatus)
Values (886,10,305,0,0,'JournalInsert','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)
End
go    
	If Not Exists(Select * From RulesStepAction Where Action = 'SendToPhoenixWithCallRegPayToThrdPrtyPO_EFTSService' And StepType = 413)
	Begin
	 Insert Into RulesStepAction(Action,StepType,AppID,WritesJournal)
	 Values ('SendToPhoenixWithCallRegPayToThrdPrtyPO_EFTSService',413,1,0)
	End
	go  
	If Not Exists(Select * From RulesTranSteps Where TranID = 886 And Action='SendToPhoenixWithCallRegPayToThrdPrtyPO_EFTSService' And StepSequence = 20)
	Begin
		Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,RowStatus)
		Values (886,20,413,0,0,'SendToPhoenixWithCallRegPayToThrdPrtyPO_EFTSService',1)
	End
	go  
If Not Exists(Select * From RulesTranSteps Where TranID = 886 and StepSequence = 40)
Begin
Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,EffectiveDate,ExpirationDate,RowStatus)
Values (886,40,305,0,1,'JournalUpdate','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)
End
go
----------------------
-- TransactionScopes -
----------------------
If Not Exists(Select * From TransactionScopes Where  TranID = 886)
Begin
 Insert Into TransactionScopes(Scope,TranID)
 Values (1001,886)
End
GO

-------------------
-- RulesTranField -
-------------------
-- node1 , 2 ,3 
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = -1099994)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, -1099994 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = -1099995)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, -1099995 ,1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = -1099996)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, -1099996 ,1)
END
---
---TLR_CO_CHEQUE_NUMBER 
select * from RulesDBField where FieldID = 467
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 379)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional ,  FieldAlias)
	VALUES(886, 379,1, 'InvoiceDate')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 467)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 467,1, 'InvoiceNo')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1730)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 1730, 1,'InvoiceAmount')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1740)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID,Optional,  FieldAlias)
	VALUES(886, 1740,1, 'InvoicePayAmt')
END

----------------------

IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 9)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 9 ,1, 'Amount')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = -1099990)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID,Optional,  FieldAlias)
	VALUES(886, -1099990 ,1, 'TotalCreditAmount')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 186)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional, FieldAlias)
	VALUES(886, 186,1, 'GTD_Ticket')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 147)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 147,1, 'Narrative')
END
-------------------------------------


IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1783)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID,Optional,  FieldAlias)
	VALUES(886, 1783 ,1, 'PaymentAmount')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1784)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 1784,1, 'PaymentCurrency')
END
-----------------------------
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1151)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 1151, 1,'ServiceType')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 389)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 389,1, 'MessageType')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1583)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 1583, 1, 'RequestDate')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 205)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional,  FieldAlias)
	VALUES(886, 205,1, 'OrderingTime')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 375)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID,  Optional, FieldAlias)
	VALUES(886, 375,1, 'TransactionType')
END
----------------------
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1493)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 1493,1, 'Sender')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1496)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 1496,1, 'Receiver')
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 434)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID, Optional, FieldAlias)
	VALUES(886, 434,1, 'Channel')
END

IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = -1099978)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, -1099978 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 179)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 179 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 191)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 191 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 209)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 209 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 223)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 223 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 232)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 232 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 262)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 262 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 339)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 339 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 343)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 343 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 377)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 377 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 378)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 378 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 446)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 446 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 468)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 468 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1131)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1131 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1188)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1188 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1202)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1202 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1203)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1203 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1204)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1204 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1204)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1204 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1205)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1205 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1207)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1207 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1208)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1208 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1212)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1212 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1213)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1213 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1218)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1218 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1219)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1219 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1228)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1228 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1229)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1229 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1241)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1241 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1242)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1242 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1243)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1243 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1244)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1244 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1304)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1304 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1315)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1315 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1397)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1397 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1398)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1398 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1399)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1399 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1412)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1412 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1413)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1413 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1420)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1420 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1424)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1424 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1425)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1425 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1426)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1426 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1427)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1427 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 277)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 277 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 316)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 316 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 361)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 361 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 362)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 362 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 363)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 363 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 371)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 371 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 396)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 396 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 417)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 417 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 465)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 465 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 589)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 589 , 1)
END

IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1069)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1069 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1107)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1107 , 1)
END


IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1652)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1652 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1466)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1466 , 1)
END

IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1725)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1725 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1749)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1749 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1778)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1778 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1782)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1782 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1787)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1787 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1788)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1788 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1790)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1790 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1791)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1791 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1793)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1793 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1794)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1794 , 1)
END

IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1883)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1883 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1896)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1896 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 2011)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 2011 , 1)
END
IF NOT EXISTS (SELECT * FROM RulesTranField WHERE TranID = 886 AND FieldID = 1000141)
BEGIN
INSERT INTO	RulesTranField(TranID, FieldID ,Optional)
	VALUES(886, 1000141 , 1)
END


If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_dealInformation')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_dealInformation',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txtTLR_BRANCHES_NO')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txtTLR_BRANCHES_NO',0,1,'',1)
End

If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_TLR_3RDPARTY_SERIAL_NO')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_TLR_3RDPARTY_SERIAL_NO',0,1,'',1)
End

If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'txt_Sender')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','txt_Sender',0,1,'Default Sender',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'txt_Receiver')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','txt_Receiver',0,1,'Default Reciever',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'txt_Channel')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','txt_Channel',0,1,'Default Channel',1)
End


If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_curPaid_Amount')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_curPaid_Amount',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_curTLR_ADV_AMT')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_curTLR_ADV_AMT',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txtTLR_DUE_DATE')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txtTLR_DUE_DATE',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txtTLR_BILL_ID')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txtTLR_BILL_ID',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TotalPaid')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TotalPaid',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lblTLR_DUE_DATE')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lblTLR_DUE_DATE',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lblTLR_ADV_AMT')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lblTLR_ADV_AMT',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lblTLR_BILL_ID')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lblTLR_BILL_ID',0,0,'',1)
End

--53 A
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Sender_Corres')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Sender_Corres',0,1,'Dummy Data',1)
End
--update  RulesTranField_ex set DefaultValue = 'Dummy Data' Where TranID = 886 and FieldIDInPage = '_txt_Sender_Corres'
--50 K
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Order_Customer_IBAN')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Order_Customer_IBAN',0,1,'IBANForAccNo100000009316',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Order_Customer_Title_1')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Order_Customer_Title_1',0,1,'title1',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Order_customer_Addr1')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Order_customer_Addr1',0,1,'address1',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Order_customer_Addr2')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Order_customer_Addr2',0,1,'address2',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Order_customer_Addr3')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Order_customer_Addr3',0,1,'address3',1)
End

--71 A
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_TLR_Details_Of_Charges')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_TLR_Details_Of_Charges',0,1,'OUR',1)
End

If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Remittance_Info3')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Remittance_Info3',0,0,'Deal No',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Remittance_Info2')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Remittance_Info2',0,0,'PO No',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Remittance_Info1')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Remittance_Info1',0,0,'Invoice No',1)
End

If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lblTLR_GTD_TKT')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lblTLR_GTD_TKT',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txtGTD_DEAL_TICKET')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txtGTD_DEAL_TICKET',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_datTLR_SO_VALUE_DATE')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_datTLR_SO_VALUE_DATE',0,0,'',1)
End

If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'txt_OrderingTime')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','txt_OrderingTime',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'lbl_OrderingTime')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','lbl_OrderingTime',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lblTLR_PAYMENT_VALUE_DATE')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lblTLR_PAYMENT_VALUE_DATE',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_datTLR_SO_VALUE_DATE')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_datTLR_SO_VALUE_DATE',0,0,'',1)
End



If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_curAmount')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_curAmount',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lblTLR_Transfer_AMOUNT')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lblTLR_Transfer_AMOUNT',0,0,'',1)
End

If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'lbl_requestDate')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','lbl_requestDate',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'dat_RequestDate')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','dat_RequestDate',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'lbl_TransactionType')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','lbl_TransactionType',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'cbo_TransactionType')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','cbo_TransactionType',0,0,'',1)
End

If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'lbl_MessageType')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','lbl_MessageType',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'txt_MessageType')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','txt_MessageType',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'lbl_ServiceType')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','lbl_ServiceType',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'cbo_ServiceType')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','cbo_ServiceType',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'lbl_Sender')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','lbl_Sender',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'lbl_Receiver')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','lbl_Receiver',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = 'lbl_Channel')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','lbl_Channel',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_nrvDr_Narrative')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_nrvDr_Narrative',0,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_Narrative')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_Narrative',0,0,'',1)
End

---popup
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_grp_MT103Fields')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_grp_MT103Fields',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRBankComments')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRBankComments',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_TLRBankComments')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_TLRBankComments',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_Regulatory_Info')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_Regulatory_Info',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_TLRSend_Receive_Info3')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_TLRSend_Receive_Info3',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_TLRSend_Receive_Info4')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_TLRSend_Receive_Info4',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_TLRSend_Receive_Info5')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_TLRSend_Receive_Info5',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Order_Inst_acct')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Order_Inst_acct',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Benef_Cust_Addr1')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Benef_Cust_Addr1',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Benef_Cust_Addr2')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Benef_Cust_Addr2',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Benef_Cust_Addr3')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Benef_Cust_Addr3',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Receiver_corres_acct')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Receiver_corres_acct',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Order_Inst_BIC')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Order_Inst_BIC',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Acct_with_Inst')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Acct_with_Inst',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Remittance_Info4')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Remittance_Info4',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_TLRSend_Receive_Info1')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_TLRSend_Receive_Info1',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Regulatory_Info1')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Regulatory_Info1',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Regulatory_Info2')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Regulatory_Info2',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Regulatory_Info3')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Regulatory_Info3',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_Order_Customer')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_Order_Customer',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_Order_Inst')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_Order_Inst',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRSender_Corres')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRSender_Corres',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRBenef_Customer')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRBenef_Customer',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRRemittanceInfo')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRRemittanceInfo',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRSend_Receive_Info')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRSend_Receive_Info',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Receiver_corres_BIC')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Receiver_corres_BIC',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRReceiver_Corres')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRReceiver_Corres',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRDetails_Of_Charges')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRDetails_Of_Charges',1,0,'',1)
End

If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRAcct_With_Inst')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRAcct_With_Inst',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_TLRSend_Receive_Info2')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_TLRSend_Receive_Info2',1,0,'',1)
End


If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRBenef_Customer_Name')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRBenef_Customer_Name',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_Benef_Cust_Name')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_Benef_Cust_Name',1,0,'',1)
End

If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_lbl_TLRBank_Name')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_lbl_TLRBank_Name',1,0,'',1)
End
If Not Exists(Select * From RulesTranField_ex Where TranID = 886 and FieldIDInPage = '_txt_TLR_Bank_Name')
Begin
	Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,Optional,IsReadOnly,DefaultValue,IsVisible)
	Values (886,'Teller','_txt_TLR_Bank_Name',1,0,'',1)
End

-------------------------------------------
--****** Rules param && RulesTranParam ****
-------------------------------------------
declare @paramid int
	select @paramid=MAX(paramid)+1 from RulesParam

	 If Not Exists(Select * From RulesParam Where ParamName = 'Enable_ErrorCode_Setup')
	Begin
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@paramid,'Enable_ErrorCode_Setup','determine if new setup for Error Code Reversal is applied or not ',NULL,0,0,0,'','Static    ','','Sep  22 2021 8:22AM',N'ITSOFT\shaimaa.nasser','Sep  22 1900 12:00AM','Dec 31 9999 12:00AM',1)
	End
	 If Not Exists(Select * From RulesTranFldParam Where TranName = 'RegPayToThrdPrtyPOThroughEFTS' And Param = 'Enable_ErrorCode_Setup')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,DataType,LastChanged,Description)
	 Values ('RegPayToThrdPrtyPOThroughEFTS','Transaction','Enable_ErrorCode_Setup','N' ,'nvarchar','Sep  22 2021 8:22AM','determine if new setup for Error Code Reversal is applied or not')
	End
GO





declare @paramid int
	select @paramid=MAX(paramid)+1 from RulesParam

	 If Not Exists(Select * From RulesParam Where ParamName = 'RegPay_PO_EFTS_ThresholdAmount')
	Begin
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
	 Values (@paramid,'RegPay_PO_EFTS_ThresholdAmount','Threshold Amount',NULL,0,0,0,'','Static    ','')
	End
	 If Not Exists(Select * From RulesTranFldParam Where TranName = 'RegPayToThrdPrtyPOThroughEFTS' And Param = 'RegPay_PO_EFTS_ThresholdAmount')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,DataType,LastChanged,Description)
	 Values ('RegPayToThrdPrtyPOThroughEFTS','ThresholdAmount','RegPay_PO_EFTS_ThresholdAmount','0.00' ,'money','Sep  22 2021 8:22AM','determine if new setup for Error Code Reversal is applied or not')
	End
GO

declare @paramid int
	select @paramid=MAX(paramid)+1 from RulesParam

	 If Not Exists(Select * From RulesParam Where ParamName = 'RegPay_PO_EFTS_ServiceAccount')
	Begin
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
	 Values (@paramid,'RegPay_PO_EFTS_ServiceAccount','Fawri Account To use in Account Entries',NULL,0,0,0,'','Static    ','')
	End
	 If Not Exists(Select * From RulesTranFldParam Where TranName = 'RegPayToThrdPrtyPOThroughEFTS' And Param = 'RegPay_PO_EFTS_ServiceAccount')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,DataType,LastChanged,Description)
	 Values ('RegPayToThrdPrtyPOThroughEFTS','RegPay_PO_EFTS_ServiceAccount','RegPay_PO_EFTS_ServiceAccount','0.00' ,'nvarchar','Sep  22 2021 8:22AM','Fawri Account To use in Account Entries')
	End
GO

--===========================================
--Devolper	:	Ahmed Atef
--Date		:	[24/05/2022]
--Reason	:	INC000000336010 - SO Payment
--===========================================
-----------------------------------
-- RulesParam & RulesTranFldParam -
-----------------------------------
IF NOT EXISTS(Select * From RulesParam Where ParamName='ProcessOpenSchedule')
BEGIN
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'ProcessOpenSchedule','New Parameter for SO Payment Execution transaction and SO service to retrieve open schedule or both open and closed schedule','',0,1,0,'','Static','')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'SoPaymentExecution' AND FieldName = 'ProcessOpenSchedule' AND Param = 'ProcessOpenSchedule' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'SoPaymentExecution' , 'ProcessOpenSchedule' , 'ProcessOpenSchedule' , '0' ,'ITSOFT\ahmed.atef' , 'bit')
END
GO
IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'SoPaymentExecutionService' AND FieldName = 'ProcessOpenSchedule' AND Param = 'ProcessOpenSchedule' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'SoPaymentExecutionService' , 'ProcessOpenSchedule' , 'ProcessOpenSchedule' , '0' ,'ITSOFT\ahmed.atef' , 'bit')
END
GO

---------------------------------------
--HostCoreServices---------------------
---------------------------------------
---------------------------------------
--ListSODuePayment---------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment') AND FieldName='ProcessOpenSchedule')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePayment'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'ProcessOpenSchedule','int',0,0,N'0','I')
END 
GO
---------------------------------------
--ListSODuePaymentForSoService---------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePaymentForSoService') AND FieldName='ProcessOpenSchedule')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListSODuePaymentForSoService'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'ProcessOpenSchedule','int',0,0,N'0','I')
END 
GO
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=547 AND FieldIDInPage='tab_SourceOfWealth')
BEGIN
update RulesTranField_ex set FieldIDInPage='tab_SourceWealth' WHERE TranID=547 AND FieldIDInPage='tab_SourceOfWealth'
END
ELSE if not exists(select * FROM RulesTranField_ex WHERE TranID=547 AND FieldIDInPage='tab_SourceWealth')
BEGIN
INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
values( 547, NULL , 'Teller' , 'tab_SourceWealth' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\mostafa.helmy' , 0)

END
GO
IF  EXISTS(select * from RulesTranField_ex where TranID =  547 and FieldIDInPage = 'cbo_AMLCahnnels' and FieldID IS Not NULL)
 BEGIN
	DELETE RulesTranField_ex where TranID =  547 and FieldIDInPage = 'cbo_AMLCahnnels' and FieldID IS Not NULL
 END

 IF  EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLCahnnels' and FieldID IS Not NULL)
 BEGIN
	DELETE RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLCahnnels' and FieldID IS Not NULL
 END

  IF  EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLOwnership' and FieldID IS Not NULL)
 BEGIN
	DELETE RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLOwnership' and FieldID IS Not NULL
 END
GO
--==========================================
--Devolper	:	Ahmed Atef
--Date		:	[15/06/2022]
--Reason	:   issue# GFSX15124
--==========================================
--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Exists(select * From RulesDescriptor Where DescriptorID = 1106081 and Name = 'TLR_PROCESS_IN_MORNING')
BEGIN
	UPDATE RulesDescriptor SET Descriptor = 'Process In Morning' Where DescriptorID = 1106081 and Name = 'TLR_PROCESS_IN_MORNING'
END
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106158 and Name = 'TLR_FORCE_ACCOUNT_ENTRIES')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106158	,'TLR_FORCE_ACCOUNT_ENTRIES',1,'Labels','Force Accounting Entries','ITSOFT\ahmed.atef','2022-06-15 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000',	'2022-06-15 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106158 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106158 , 1025, N'إدخالات الحسابات إجبارياً','ITSOFT\ahmed.atef','2022-06-15 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106158 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106158 , 1036, 'Écritures Comptables en Force','ITSOFT\ahmed.atef','2022-06-15 03:27:00')
End
GO
--Devolper	 :	Ibrahim Harby 
--Date       :	[12/06/2022]		
--Reason     :	CR#GFSY00885 [CBD_ACM19919_Virtual Account Narration and Notification - Retrofit]
------------------------------------------------------------------------------------------------


IF NOT EXISTS (SELECT * FROM ExternalWebService WHERE WebServiceName='VAaccountPostingNotification')
BEGIN
	INSERT INTO ExternalWebService(WebServiceName,Description,WebServiceIP,MachineName,URL,UserName,Password,ApplyWSE,WebServiceMapName,Servicetype)
	Values('VAaccountPostingNotification', 'WebService for Send Notification when search by virtual account ','20.24.24.20','EGDEVGFSAPP004','http://egdevgfsapp004:8089/Api','','',0,'VAaccountPostingNotification','REST')
END
GO

IF NOT EXISTS (SELECT * FROM ExternalWebServiceTran WHERE TranID= -1 AND WebServiceName='VAaccountPostingNotification' AND Methods='VAtxnposting' AND MethodsMapName='VAtxnposting')
BEGIN
	declare @maxID int

	select @maxID=max(ID)+1 from ExternalWebServiceTran
	
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,MethodsMapName,ID , HttpMethod , ContentType)
	Values(-1,'VAaccountPostingNotification','VAtxnposting','VAtxnposting',@maxID ,'POST', 'application/json')
	
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='XMLParam')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'XMLParam','XMLString',0,'DUMY_XMLParam',1,'VAtxnposting.xsd')
	END 	
END
GO	 



If Not Exists(Select * From RulesStepAction Where Action = 'VAPostingNotification' And StepType = 100)
Begin
 Insert Into RulesStepAction(Action,StepType,AppID,WritesJournal)
 Values ('VAPostingNotification',100,1,0)
End
GO

-------------
-- RulesTranSteps -
-------------------
-- Update step sequence


If not Exists(Select * From RulesTranSteps Where TranID = 160 AND [Action] = 'VAPostingNotification')
Begin
 UPDATE RulesTranSteps SET StepSequence = StepSequence + 10 WHERE TranID = 160 AND [Action] = 'JournalUpdate'
End
GO

declare @stepSequence int
select @stepSequence =  StepSequence From RulesTranSteps Where TranID = 160 AND [Action] = 'JournalUpdate'

--Cash Deposit
If not Exists(Select * From RulesTranSteps Where TranID = 160 AND [Action] = 'VAPostingNotification')
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action)
 Values (160,@stepSequence - 10,100,1,0,'VAPostingNotification')
End
GO


---*************************
If not Exists(Select * From RulesTranSteps Where TranID = 192 AND [Action] = 'VAPostingNotification')
Begin
 UPDATE RulesTranSteps SET StepSequence = StepSequence + 10 WHERE TranID = 192 AND [Action] = 'JournalUpdate'
End
GO

declare @stepSequence int
select @stepSequence =  StepSequence From RulesTranSteps Where TranID = 192 AND [Action] = 'JournalUpdate'

--Cash Deposit
If not Exists(Select * From RulesTranSteps Where TranID = 192 AND [Action] = 'VAPostingNotification')
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action)
 Values (192,@stepSequence - 10,100,1,0,'VAPostingNotification')
End
GO



If Not Exists(select * From RulesTranField Where TranID = 192 And FieldID = 179 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (192,179,1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 160 And FieldID = 179 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (160,179,1)
End
go



If Not Exists(Select * From  RulesTranSteps_Conditions where Operand1 = 'DUMY_VANotify' AND Operand2 = 1 )
Begin
		DECLARE @newId INT, @newCondID INT 
		SELECT @newId = MAX(Id)+1, @newCondID = MAX(ConditionID)+1 FROM RulesTranSteps_Conditions

		INSERT INTO RulesTranSteps_Conditions(Id, ConditionID, Seq, OperandsDataType, Operand1, Operator, Operand2, LogicalOperator)
		VALUES (@newId, @newCondID, 1, '2', 'DUMY_VANotify', '1',1, null)	
		
	

		If  Exists(Select * From RulesTranSteps Where TranID = 160 And Action = 'VAPostingNotification')
		Begin	
		  update RulesTranSteps set ConditionID = @newCondID where  TranID = 160 And Action = 'VAPostingNotification'
		End

		If  Exists(Select * From RulesTranSteps Where TranID = 192 And Action = 'VAPostingNotification')
		Begin	
		  update RulesTranSteps set ConditionID = @newCondID where  TranID = 192 And Action = 'VAPostingNotification'
		End
End
go



if exists(select * from  ExternalWebServiceTran where MethodsMapName = 'PartyAcctRelInq' )
	begin
		declare @ID int
		select @ID = ID from    ExternalWebServiceTran where  MethodsMapName = 'PartyAcctRelInq'
		IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@ID AND ParamName='RefData')
		BEGIN
			insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
			values(@ID,null,@ID,'RefData','XMLString',5,'DUMY_XMLParam',0,'')
		END 
	End	
Go	

--==========================================
--Devolper	:	Ahmed Atef
--Date		:	[15/06/2022]
--Reason	:	Enh GFSX15126
--==========================================
--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106159 and Name = 'TLR_FxRequestTracker')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106159	,'TLR_FxRequestTracker',1,'Labels','Fx Request Tracker','ITSOFT\ahmed.atef','2022-06-16 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-16 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106159 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106159 , 1025, N'FX طلب تعقب','ITSOFT\ahmed.atef','2022-06-06 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106159 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106159 , 1036, 'FX traqueur de requête','ITSOFT\ahmed.atef','2022-06-06 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1101424 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1101424 , 1036, 'Identité Civile','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Identité Civile' Where DescriptorID = 1101424 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1101844 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1101844 , 1036, 'Date d''expiration de l''identifiant civil','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Date d''expiration de l''identifiant civil' Where DescriptorID = 1101844 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1002225 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1002225 , 1036, 'd''identité nationale','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'd''identité nationale' Where DescriptorID = 1002225 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1002226 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1002226 , 1036, 'Date d''expiration de nationale d''identité','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Date d''expiration de nationale d''identité' Where DescriptorID = 1002226 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = -10142 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (-10142 , 1036, 'Type d''identification','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Type d''identification' Where DescriptorID = -10142 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1261 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1261 , 1036, 'Date d''expiration','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Date d''expiration' Where DescriptorID = 1261 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 475 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (475 , 1036, 'Date d''expiration','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Date d''expiration' Where DescriptorID = 475 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1101513 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1101513 , 1036, 'La religion','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'La religion' Where DescriptorID = 1101513 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = -10197 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (-10197 , 1036, 'le type','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'le type' Where DescriptorID = -10197 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1105091 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1105091 , 1036, 'Type de relation','ITSOFT\ahmed.atef','2022-06-16 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Type de relation' Where DescriptorID = 1105091 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = -269884 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (-269884 , 1036, 'Approuvé','ITSOFT\ahmed.atef','2022-06-19 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Approuvé' Where DescriptorID = -269884 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1268 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values ( 1268, 1036, 'Approuvé','ITSOFT\ahmed.atef','2022-06-19 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Approuvé' Where DescriptorID =1268  And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1000043 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values ( 1000043, 1036, 'Approuvé','ITSOFT\ahmed.atef','2022-06-19 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Approuvé' Where DescriptorID = 1000043 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1000043 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values ( 1000043, 1036, 'Approuvé','ITSOFT\ahmed.atef','2022-06-19 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'Approuvé' Where DescriptorID = 1000043 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1102194 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1102194 , 1036, 'le grade','ITSOFT\ahmed.atef','2022-06-19 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'le grade' Where DescriptorID = 1102194 And LCID = 1036
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106109 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106109 , 1036, 'La date d''expiration est inférieure ou égale à la date système','ITSOFT\ahmed.atef','2022-06-19 03:27:00')
End
Else
Begin
	Update RulesDescriptorLocal set LocalDescription = 'La date d''expiration est inférieure ou égale à la date système' Where DescriptorID = 1106109 And LCID = 1036
End
GO
update RulesDescriptor set Descriptor = 'Accouting Entries' where DescriptorID = 1000177
GO