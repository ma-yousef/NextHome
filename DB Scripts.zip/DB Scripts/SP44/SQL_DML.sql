﻿USE [Globalfs]
GO
       
If Not Exists(Select * From ServicePacks Where BasePackageName = 'ETHIX-Branch_2.00.46' And SP_Number = 44)
Begin
Insert Into ServicePacks(BasePackageName,SP_Number,SP_Name, LastPackageName, BriefDescription, DetailedDescription,IncludeWholeFilesOnly,DontRemoveTmpFldrWhenFinished,OptionalSourceList,Comments,PatchNumber)
Values('ETHIX-Branch_2.00.46', 44,'SP44_ETHIX-Branch_2.0.46.0','SP43_ETHIX-Branch_2.0.46.0','SP44_ETHIX-Branch_2.0.46.0','', 1, 0, '', '',0)
End
GO

--Devolper	 :	Aya Tarek 
--Date       :	[20/7/2022]		
--Reason     :	CR#GFSY00915 [IBAN_spliting]{Retrofit]
------------------------------------------------------------------------------------------------
--RulesParam-----------
--------------------------------
If Not Exists(Select * From RulesParam Where ParamName='LoadRatesFromIR')
Begin
    DECLARE @paramID1 int
    SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
    Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
    Values (@paramID1,'LoadRatesFromIR','LoadRatesFromIR','',0,1,0,'','Static','')
End
GO
--------------------------------
--RulesTranFldParam-----------
--------------------------------
-- LoadRatesFromIR 
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'InwardRemittanceHOSwiftService' AND FieldName ='ExchangeRate' AND Param = 'LoadRatesFromIR' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'InwardRemittanceHOSwiftService' , 'ExchangeRate' , 'LoadRatesFromIR' , 1 ,'ITSOFT\aya.tarek' , 'bit')
 END 
GO
		
	----------------------------------------------------- ---------- --------------------------------------------------------------------------------
	----------------------------------------------------- RulesDescriptor ---------------------------------------------------------------------------
	IF NOT EXISTS (SELECT *  FROM RulesDescriptor WHERE  DescriptorID = 1106172 )
	BEGIN
		INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor )  
		SELECT 1 , 1106172  , 'TLR_ATM_TYPE' , 0 , 'Labels' , 'ATM Type'  
	END
	GO
	If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106172 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription )
	 Values (1106172,1025,N'نوع ماكينة الصراف الالي' )
	End
	go
		If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106172 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription )
	 Values (1106172,1036,N'Type de guichet automatique' )
	End
	go
	IF NOT EXISTS (SELECT *  FROM RulesDescriptor WHERE  DescriptorID = 1106173 )
	BEGIN
		INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor )  
		SELECT 1 , 1106173  , 'TLR_ATMINTERNAL' , 0 , 'Labels' , 'Internal'  
	END
	GO
	If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106173 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription )
	 Values (1106173,1025,N'داخلي' )
	End
	go
		If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106173 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription )
	 Values (1106173,1036,N'interne' )
	End
	go
		IF NOT EXISTS (SELECT *  FROM RulesDescriptor WHERE  DescriptorID = 1106174 )
	BEGIN
		INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor )  
		SELECT 1 , 1106174  , 'TLR_ATMExternal' , 0 , 'Labels' , 'External'  
	END
	GO
	If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106174 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription )
	 Values (1106174,1025,N'خارجي' )
	End
	go
		If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106174 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription )
	 Values (1106174,1036,N'externe' )
	End
	go 
	If Not Exists(Select * From RulesTranDescriptors Where TranID = 375 And DSC_Name = 'TLR_ATM_TYPE')
		Begin
		 Insert Into RulesTranDescriptors(TranID,DSC_Name  )
		 Values (375,'TLR_ATM_TYPE' )
		End
	go
		If Not Exists(Select * From RulesTranDescriptors Where TranID = 178 And DSC_Name = 'TLR_ATM_TYPE')
		Begin
		 Insert Into RulesTranDescriptors(TranID,DSC_Name  )
		 Values (178,'TLR_ATM_TYPE' )
		End
	go
	----------------------------------------------------- ---------- --------------------------------------------------------------------------------
	----------------------------------------------------- Picklists ---------------------------------------------------------------------------
	If Not Exists(Select * From Picklists Where PickListID = 580)
		Begin
		 Insert Into Picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate )
		 Values (1,580,'TLR_ATM_TYPE','Jan  1 1901 12:00AM','Dec 31 9999 12:00AM' )
		End
		go  
		delete  from  Picklist_Entries Where PickListID = 580
		If Not Exists(Select * From Picklist_Entries Where PickListID = 580 And DisplayOrder = 0)
		Begin
		 Insert Into Picklist_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate )
		 Values (580,1,0,'TLR_ATMINTERNAL','Internal','Jan  1 1901 12:00AM','Dec 31 9999 12:00AM' )
		End 
		If Not Exists(Select * From Picklist_Entries Where PickListID = 580 And DisplayOrder = 1)
		Begin
		 Insert Into Picklist_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate )
		 Values (580,1,1,'TLR_ATMExternal','External','Jan  1 1901 12:00AM','Dec 31 9999 12:00AM' )
		End
    ----------------------------------------------------- ---------- --------------------------------------------------------------------------------
	----------------------------------------------------- RulesTranField_ex--------------------------------------------------------------------------------
	 
	If Not Exists(Select * From RulesTranField_ex Where TranID = 178  And FieldIDInPage = '_cbo_ATMType')
	Begin
	 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values (178,NULL,'Teller','_cbo_ATMType',-1,-1,-1,0,0,'','','' ,0)
	End
	go 
	If Not Exists(Select * From RulesTranField_ex Where TranID = 375  And FieldIDInPage = '_cbo_ATMType')
	Begin
	 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values (375,NULL,'Teller','_cbo_ATMType',-1,-1,-1,0,0,'','','' ,0)
	End
	go 
		If Not Exists(Select * From RulesTranField_ex Where TranID = 178  And FieldIDInPage = 'lbl_ATMType')
	Begin
	 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values (178,NULL,'Teller','lbl_ATMType',-1,-1,-1,0,0,'','','' ,0)
	End
	go 
	If Not Exists(Select * From RulesTranField_ex Where TranID = 375  And FieldIDInPage = 'lbl_ATMType')
	Begin
	 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values (375,NULL,'Teller','lbl_ATMType',-1,-1,-1,0,0,'','','' ,0)
	End
	go 
    ----------------------------------------------------- ---------- --------------------------------------------------------------------------------
	----------------------------------------------------- RulesTranField ---------------------------------------------------------------------------

		If Not Exists(Select * From RulesTranField Where TranID = 178 And FieldID = 155)  -- COR_CLASS_CODE
			Begin
			Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
			Values (178,155,1,0,0,NULL ,1,NULL,'' ,1,0,NULL,0,0,NULL,0,-1)
			End

	    If Not Exists(Select * From RulesTranField Where TranID = 375 And FieldID = 155) -- COR_CLASS_CODE   1000048  1000049
			Begin
			Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
			Values (375,155,1,0,0,NULL ,1,NULL,'' ,1,0,NULL,0,0,NULL,0,-1)
			End  
GO
 
 --Devolper :	Aya Tarek
--Date       :	[23/5/2022]		
--Reason     :	CR#GFSY00908 - ACM000000020088 - AML Integration
--=============================================================
PRINT 'Start. Script for CR# GFSY00908 DML Script part 1'
GO

---------------------------
-- RulesErrorDescription --
---------------------------

--MSG01
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1826)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1826,'DEPOSITORNAME_NOT_ACCEPT','Depositor name Accept English only with AML.','Depositor name Accept English only with AML.',4,'ErrDesc.hlp',1,'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1826)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1826,N'AML اسم المودع لايقبل الا اللغة الانجليزية معِ',N'AML اسم المودع لايقبل الا اللغة الانجليزية معِ','','ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1036 And DescriptionNumber = 1826)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1036,1826,'Nom du déposant Accepter l’anglais uniquement avec AML','Nom du déposant Accepter l’anglais uniquement avec AML','','ITSOFT\aya.tarek')
End
Go



--MSG02
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1830)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1830,'AML_INVALIDRIM','unable Processed with transaction ,Third Party has Invalid RIM Number.','unable Processed with transaction , Third Party has Invalid RIM Number.',4,'ErrDesc.hlp',1,'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1830)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1830,N'لا يمكن المتابعة فى هذة المعاملة رقم العميل غير صالح ',N'لا يمكن المتابعة فى هذة المعاملة رقم العميل غير صالح ','','ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1036 And DescriptionNumber = 1830)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1036,1830,'impossible Traité avec transaction','Un tiers n’a pas de numéro RIM valide.','','ITSOFT\aya.tarek')
End
Go

--MSG03
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1833)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1833,'ERR_NO_RESULTTOFOUND','No result Found with selected Criteria.','No result Found with selected Criteria .',4,'ErrDesc.hlp',1,'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1833)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1833,N' لم يتم العثور على نتيجة مع المعايير المختارة',N' لم يتم العثور على نتيجة مع المعايير المختارة','','ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1036 And DescriptionNumber = 1833)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1036,1833,'Aucun résultat trouvé avec les critères sélectionnés.','Aucun résultat trouvé avec les critères sélectionnés.','','ITSOFT\aya.tarek')
End
Go

--MSG04
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1834)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1834,'ERR_NO_AMLIDTYPE','there is no ID type identified for AML.','there is no ID type identified for AML.',4,'ErrDesc.hlp',1,'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1834)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1834,N'محدد لمكافحة غسيل الأموال IDType لا يوجد',N' محدد لمكافحة غسيل الأموال IDType لا يوجد','','ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1036 And DescriptionNumber = 1834)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1036,1834,'il nay a pas de type daidentification identifié pour la AML.','Aucun résultat trouvé avec les critères sélectionnés.','','ITSOFT\aya.tarek')
End
Go

--------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal --
--------------------------------------------
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106178 and Name = 'TLR_AMLCheck')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106178	,'TLR_AMLCheck',1,'Labels','Transaction Check (AML System)','ITSOFT\ahmed.atef','2022-08-02 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-08-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106178 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106178 , 1025, N'(AML) فحص العمليات','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106178 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106178 , 1036, 'AML chéque de transaction','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106179 and Name = 'TLR_AMLSearch')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106179	,'TLR_AMLSearch',1,'Labels','AML Search','ITSOFT\ahmed.atef','2022-08-02 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-08-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106179 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106179 , 1025, N'(AML) بحث','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106179 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106179 , 1036, 'AML chercher','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106180 and Name = 'TLR_AMLFinalStatus')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106180	,'TLR_AMLFinalStatus',1,'Labels','AML Final Status Is','ITSOFT\ahmed.atef','2022-08-02 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-08-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106180 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106180 , 1025, N'AML الحالة النهائية تكون','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106180 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106180 , 1036, 'le statut final AML est','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106181 and Name = 'TLR_AMLFinalStatRS')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106181	,'TLR_AMLFinalStatRS',1,'Labels','Final Status','ITSOFT\ahmed.atef','2022-08-02 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-08-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106181 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106181 , 1025, N'الحالة النهائية','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106181 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106181 , 1036, 'le statut final','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO

If not Exists(select * From RulesDescriptor Where DescriptorID = 1106150 and Name = 'CaseID')
Begin
Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106150	,'CaseID',0,'Labels','Case ID')
End
GO
If not Exists(select * From RulesDescriptor Where DescriptorID = 1106151 and Name = 'AML_CaseID')
Begin
Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106151	,'AML_CaseID',0,'Labels','AML Case ID')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106150 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106150 , 1025, N'رقم الحالة','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106150 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106150 , 1036, N'ID de case','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106151 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106151 , 1025, N'AML رقم الحالة','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106151 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106151 , 1036, N'AML ID de case','ITSOFT\ahmed.atef','2022-08-02 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1104332 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,LastChanged)
 Values (1104332 , 1025, N'طباعة التقرير','2022-08-02 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106087 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,LastChanged)
 Values (1106087 , 1025, N'العلاقة','2022-08-02 03:27:00')
End
GO
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1106190 and Name = 'TLR_OWNER_RIM_NUMBER')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1106190,'TLR_OWNER_RIM_NUMBER',0,'Labels','Owner Rim Number','ITSOFT\ahmed.amohamed','Mar  4 2012 10:41AM',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','Dec 30 2004 12:09PM',N'ITSOFT\ahmed.amohamed')
End
go
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106190 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,LastChanged)
 Values (1106190 , 1025, N'رقم العميل المالك','2022-08-17 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106190 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,LastChanged)
 Values (1106190 , 1036, N'Numéro de client du propriétaire','2022-08-17 03:27:00')
End
GO
--------------------------------
-- RulesTranErrorDescriptions --
--------------------------------
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'CashDeposit' And Error_Name = 'DEPOSITORNAME_NOT_ACCEPT')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('CashDeposit','DEPOSITORNAME_NOT_ACCEPT','ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'CashDeposit' And Error_Name = 'ERR_NO_AMLIDTYPE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('CashDeposit','ERR_NO_AMLIDTYPE','ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'RegPayToThrdPrtyInvAcc' And Error_Name = 'AML_INVALIDRIM')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('RegPayToThrdPrtyInvAcc','AML_INVALIDRIM','ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'RegPayToThrdPrtyInvAcc' And Error_Name = 'ERR_NO_RESULTTOFOUND')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('RegPayToThrdPrtyInvAcc','ERR_NO_RESULTTOFOUND','ITSOFT\aya.tarek',1)
End
GO


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'RegPayToThrdPrtyInvGL' And Error_Name = 'AML_INVALIDRIM')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('RegPayToThrdPrtyInvGL','AML_INVALIDRIM','ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'RegPayToThrdPrtyInvGL' And Error_Name = 'ERR_NO_RESULTTOFOUND')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('RegPayToThrdPrtyInvGL','ERR_NO_RESULTTOFOUND','ITSOFT\aya.tarek',1)
End
GO



If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'GLToGLTransfer' And Error_Name = 'AML_INVALIDRIM')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('GLToGLTransfer','AML_INVALIDRIM','ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'GLToGLTransfer' And Error_Name = 'ERR_NO_RESULTTOFOUND')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('GLToGLTransfer','ERR_NO_RESULTTOFOUND','ITSOFT\aya.tarek',1)
End
GO


---------------------------------
-- RulesParam -------------------
---------------------------------
DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'CheckAMLInfo')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'CheckAMLInfo','Apply Checking AML Or Not For On boarding Scan Service and inquiry Service',NULL,0,1,0,'','Static','',N'ITSOFT\aya.tarek',1)
END
GO

DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'IDTypeAMLRequest')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'IDTypeAMLRequest','The value of the IDType For use in AML service ',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.atef',1)
END
GO

DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'AMLSourceOfRequest')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'AMLSourceOfRequest','the value of SourceOfRequest that used as input parameter in AML service ',NULL,0,1,0,'','Static','',N'ITSOFT\aya.tarek',1)
END
GO

DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'AMLThirdPartyTypes')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'AMLThirdPartyTypes','define the Third-party Types (Comma Separated) that will be Configured to allow Calling AML WS',NULL,0,1,0,'','Static','',N'ITSOFT\aya.tarek',1)
END
GO

DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'AMLRIMrelationships')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'AMLRIMrelationships','define the RIMrelationships (Comma Separated) that will be Configured to allow Calling AML WS',NULL,0,1,0,'','Static','',N'ITSOFT\aya.tarek',1)
END
GO

---------------------------------
-- RulesTranFldParam ------------
---------------------------------
---------------------
-- CashDeposit 160
---------------------
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CashDeposit' AND FieldName = 'AMLScanningServiceParam' AND Param = 'CheckAMLInfo')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('CashDeposit','AMLScanningServiceParam','CheckAMLInfo','false',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CashDeposit' AND FieldName = 'AMLScanningServiceParam' AND Param = 'IDTypeAMLRequest')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('CashDeposit','AMLScanningServiceParam','IDTypeAMLRequest','',N'ITSOFT\ahmed.atef','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CashDeposit' AND FieldName = 'AMLScanningServiceParam' AND Param = 'AMLSourceOfRequest')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('CashDeposit','AMLScanningServiceParam','AMLSourceOfRequest','',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO
---------------------
-- RegPayToThrdPrtyInvAcc 322
---------------------
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvAcc' AND FieldName = 'AMLScanningServiceParam' AND Param = 'CheckAMLInfo')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvAcc','AMLScanningServiceParam','CheckAMLInfo','false',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvAcc' AND FieldName = 'AMLScanningServiceParam' AND Param = 'AMLThirdPartyTypes')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvAcc','AMLScanningServiceParam','AMLThirdPartyTypes','',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvAcc' AND FieldName = 'AMLScanningServiceParam' AND Param = 'AMLRIMrelationships')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvAcc','AMLScanningServiceParam','AMLRIMrelationships','',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvAcc' AND FieldName = 'AMLScanningServiceParam' AND Param = 'AMLSourceOfRequest')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvAcc','AMLScanningServiceParam','AMLSourceOfRequest','',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvAcc' AND FieldName = 'AMLScanningServiceParam' AND Param = 'IDTypeAMLRequest')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvAcc','AMLScanningServiceParam','IDTypeAMLRequest','','nvarchar',NULL)
END
GO
---------------------
-- RegPayToThrdPrtyInvGL 336
---------------------
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvGL' AND FieldName = 'AMLScanningServiceParam' AND Param = 'CheckAMLInfo')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvGL','AMLScanningServiceParam','CheckAMLInfo','false',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvGL' AND FieldName = 'AMLScanningServiceParam' AND Param = 'AMLThirdPartyTypes')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvGL','AMLScanningServiceParam','AMLThirdPartyTypes','',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvGL' AND FieldName = 'AMLScanningServiceParam' AND Param = 'AMLRIMrelationships')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvGL','AMLScanningServiceParam','AMLRIMrelationships','',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvGL' AND FieldName = 'AMLScanningServiceParam' AND Param = 'AMLSourceOfRequest')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvGL','AMLScanningServiceParam','AMLSourceOfRequest','',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'RegPayToThrdPrtyInvGL' AND FieldName = 'AMLScanningServiceParam' AND Param = 'IDTypeAMLRequest')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,DataType,Description)
 VALUES ('RegPayToThrdPrtyInvGL','AMLScanningServiceParam','IDTypeAMLRequest','','nvarchar',NULL)
END
GO
---------------------
-- GLToGLTransfer 443
---------------------
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'GLToGLTransfer' AND FieldName = 'AMLScanningServiceParam' AND Param = 'CheckAMLInfo')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('GLToGLTransfer','AMLScanningServiceParam','CheckAMLInfo','false',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'GLToGLTransfer' AND FieldName = 'AMLScanningServiceParam' AND Param = 'AMLRIMrelationships')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('GLToGLTransfer','AMLScanningServiceParam','AMLRIMrelationships','',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'GLToGLTransfer' AND FieldName = 'AMLScanningServiceParam' AND Param = 'AMLSourceOfRequest')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('GLToGLTransfer','AMLScanningServiceParam','AMLSourceOfRequest','',N'ITSOFT\aya.tarek','nvarchar',NULL)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'GLToGLTransfer' AND FieldName = 'AMLScanningServiceParam' AND Param = 'IDTypeAMLRequest')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,DataType,Description)
 VALUES ('GLToGLTransfer','AMLScanningServiceParam','IDTypeAMLRequest','','nvarchar',NULL)
END
GO

---------------------------------------------
-- RulesExpression & RulesExpressionDetail --
---------------------------------------------
DECLARE @ExpressionId int
SELECT @ExpressionId = MAX(ExpressionId) +1 from RulesExpression
IF NOT EXISTS(SELECT * FROM RulesExpression WHERE ExpressionName = 'AMLRequestID')
BEGIN
 INSERT INTO RulesExpression(ExpressionId,ExpressionName,SerialNumberLength,PaddingCharacter,IsLeftPadded,ExpressionCategroyId)
 VALUES (@ExpressionId,'AMLRequestID',11,'0',1,1)

 DECLARE @Id int
 SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 1)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,1,1,'DUMY_SourcerOfRequest',1,1,'0',1)
 END
END
GO


IF NOT EXISTS ( Select * From  dbo.PickLists Where  AppID   = 1  AND  PickListID   =  581  AND  PickList_Name   = 'AMLintegrationTranNames'  ) 
BEGIN 
 INSERT INTO dbo.PickLists ( AppID  , PickListID  , PickList_Name     )  
 Values( 1   ,   581   ,  'AMLintegrationTranNames'  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 581  AND  DisplayOrder   =  0   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value    )  
 Values( 581   ,   1   ,   0  ,  'RegPayTo3rdPartyInvByAccount'  ,  'RegPayToThrdPrtyInvAcc'    )
END 
GO

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 581  AND  DisplayOrder   =  1   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value    )  
 Values( 581   ,   1   ,   1  ,  'RegPayTo3rdPartyInvByGL'  ,  'RegPayToThrdPrtyInvGL'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 581  AND  DisplayOrder   =  2   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value    )  
 Values( 581   ,   1   ,   2  ,  'TLR_CASH_DEPOSIT'  ,  'CashDeposit'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 581  AND  DisplayOrder   =  3   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value    )  
 Values( 581   ,   1   ,   3  ,  'TLR_GL_TO_GL_TRANSFER'  ,  'GLToGLTransfer'   )
END 
GO

IF Not Exists(select * from SQLstrings where AccessID = 1100202)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile  , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100202 , 'SELECT_FORM_AML_Info' , 'p' , 1, 'Globalfs' , 'dbo.SELECT_FORM_AML_Info' , 0 , '' , '', 'Retrieves the AML INFO From search Popup' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO



IF Not Exists(select * from SQLstrings where AccessID = 1100203)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile  , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100203 , 'GetAMLPreviousRequests' , 'p' , 1, 'Globalfs' , 'dbo.GetAMLPreviousRequests' , 0 , '' , '', 'get the AML Previous Requests ' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO

IF Not Exists(select * from SQLstrings where AccessID = 1100204)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile  , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100204 , 'AMLInfo_UpdateInqury' , 'p' , 0, 'Globalfs' , 'dbo.AMLInfo_UpdateInqury' , 0 , '' , '', 'Update AML inquiry Data ' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO



PRINT 'End. Script for CR# GFSY00908 DML Script part 1'
GO
	
--===============================================================
--Devolper	:	Ahmed Atef
--Date		:	[05/06/2022]
--Reason	:	Enh GFSY00914 - ACM000000020191 - MOI Integration
--===============================================================
--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106152 and Name = 'TLR_MOI_CHECKING_PER_CUS')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106152	,'TLR_MOI_CHECKING_PER_CUS',1,'Labels','MOI Checking For Personal Customers','ITSOFT\ahmed.atef','2022-06-06 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106152 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106152 , 1025, N'(MOI) التحقق من العملاء الشخصيين','ITSOFT\ahmed.atef','2022-06-06 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106152 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106152 , 1036, 'MOI Vérification des clients personnels','ITSOFT\ahmed.atef','2022-06-22 03:27:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106153 and Name = 'TLR_MOI_CHECK_CRITERIA')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106153	,'TLR_MOI_CHECK_CRITERIA',1,'Labels','MOI Checking Criteria','ITSOFT\ahmed.atef','2022-06-06 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106153 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106153 , 1025, N'(MOI) فحص معايير','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106153 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106153 , 1036, 'MOI Critères de vérification','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106154 and Name = 'TLR_MOI_SER_RESPONSE')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106154	,'TLR_MOI_SER_RESPONSE',1,'Labels','MOI Service Response Info','ITSOFT\ahmed.atef','2022-06-06 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106154 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106154 , 1025, N'MOI بيانات خدمة','ITSOFT\ahmed.atef','2022-06-06 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106154 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106154 , 1036, 'MOI infos de réponse du service','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106155 and Name = 'TLR_MOI_RETURN_ERR')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106155	,'TLR_MOI_RETURN_ERR',1,'Labels','Returned Error Info','ITSOFT\ahmed.atef','2022-06-06 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106155 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106155 , 1025, N'معلومات الخطأ','ITSOFT\ahmed.atef','2022-06-06 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106155 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106155 , 1036, 'infos d''erreur renvoyées','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106156 and Name = 'TLR_CHECK_MOI')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106156	,'TLR_CHECK_MOI',1,'Labels','Check MOI','ITSOFT\ahmed.atef','2022-06-06 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106156 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106156 , 1025, N'MOI فحص','ITSOFT\ahmed.atef','2022-06-06 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106156 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106156 , 1036, 'MOI vérification','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106157 and Name = 'TLR_MOI_EXPIRY_DATE')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106157	,'TLR_MOI_EXPIRY_DATE',1,'Labels','Civil ID Expiry Date','ITSOFT\ahmed.atef','2022-06-06 03:27:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-06 03:27:17.173' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106157 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106157 , 1025, N'تاريخ انتهاء البطاقة المدنية','ITSOFT\ahmed.atef','2022-06-06 03:27:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106157 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106157 , 1036, 'Date d''expiration de l''identifiant civil','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106160 and Name = 'TLR_English_FULLNAME')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106160	,'TLR_English_FULLNAME',1,'Labels','English Full Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106160 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106160 , 1025, N'الاسم كامل باللغة الإنجليزية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106160 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106160 , 1036, 'Nom complet anglais','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106161 and Name = 'TLR_Arab_FULLNAME')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106161	,'TLR_Arab_FULLNAME',1,'Labels','Arabic Full Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106161 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106161 , 1025, N'الاسم كامل باللغة العربية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106161 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106161 , 1036, 'Nom complet arabe','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106162 and Name = 'TLR_FIRST_EnglishName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106162	,'TLR_FIRST_EnglishName',1,'Labels','First English Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106162 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106162 , 1025, N'الاسم الاول بالإنجليزية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106162 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106162 , 1036, 'Premier nom anglais','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106163 and Name = 'TLR_SECOND_EnglishName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106163	,'TLR_SECOND_EnglishName',1,'Labels','Second English Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106163 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106163 , 1025, N'الاسم الثاني بالإنجليزية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106163 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106163 , 1036, 'Deuxième nom anglais','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106164 and Name = 'TLR_THIRD_EnglishName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106164	,'TLR_THIRD_EnglishName',1,'Labels','Third English Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106164 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106164 , 1025, N'الاسم الثالث بالإنجليزية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106164 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106164 , 1036, 'Troisième nom anglais','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106165 and Name = 'TLR_FOURTH_EnglishName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106165	,'TLR_FOURTH_EnglishName',1,'Labels','Fourth English Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106165 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106165 , 1025, N'الاسم الرابع بالإنجليزية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106165 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106165 , 1036, 'Quatrième nom anglais','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106166 and Name = 'TLR_FIFTH_EnglishName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106166	,'TLR_FIFTH_EnglishName',1,'Labels','Fifth English Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106166 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106166 , 1025, N'الاسم الخامس بالإنجليزية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106166 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106166 , 1036, 'Cinquième nom anglais','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106167 and Name = 'TLR_FIRST_ArabName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106167	,'TLR_FIRST_ArabName',1,'Labels','First Arabic Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106167 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106167 , 1025, N'الاسم الاول بالعربية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106167 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106167 , 1036, 'Premier nom arabe','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106168 and Name = 'TLR_SECOND_ArabName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106168	,'TLR_SECOND_ArabName',1,'Labels','Second Arabic Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106168 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106168 , 1025, N'الاسم الثاني بالعربية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106168 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106168 , 1036, 'Deuxième nom arabe','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106169 and Name = 'TLR_THIRD_ArabName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106169	,'TLR_THIRD_ArabName',1,'Labels','Third Arabic Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106169 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106169 , 1025, N'الاسم الثالث بالعربية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106169 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106169 , 1036, 'Troisième nom arabe','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106170 and Name = 'TLR_FOURTH_ArabName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106170	,'TLR_FOURTH_ArabName',1,'Labels','Fourth Arabic Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106170 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106170 , 1025, N'الاسم الرابع بالعربية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106170 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106170 , 1036, 'Quatrième nom arabe','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106171 and Name = 'TLR_FIFTH_ArabName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106171	,'TLR_FIFTH_ArabName',1,'Labels','Fifth Arabic Name','ITSOFT\ahmed.atef','2022-06-23 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-23 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106171 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106171 , 1025, N'الاسم الخامس بالعربية','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106171 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106171 , 1036, 'Cinquième nom arabe','ITSOFT\ahmed.atef','2022-06-23 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106175 and Name = 'TLR_RIM_NOT_OPEN')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106175	,'TLR_RIM_NOT_OPEN',1,'Labels','Can''t Open RIM','ITSOFT\ahmed.atef','2022-06-28 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-28 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106175 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106175 , 1025, N'لا يمكن فتح حساب عميل','ITSOFT\ahmed.atef','2022-06-28 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106175 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106175 , 1036, 'Impossible d''ouvrir un compte client','ITSOFT\ahmed.atef','2022-06-28 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106176 and Name = 'TLR_ERROR_NOT_DEFINED')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106176	,'TLR_ERROR_NOT_DEFINED',1,'Labels','Error Code Not Defined','ITSOFT\ahmed.atef','2022-06-28 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-28 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106176 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106176 , 1025, N'رمز الخطأ غير محدد','ITSOFT\ahmed.atef','2022-06-28 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106176 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106176 , 1036, 'Code d''erreur non défini','ITSOFT\ahmed.atef','2022-06-28 09:32:00')
End
GO

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106177 and Name = 'TLR_ERROR_NOT_FOUND')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	,LastChanged	,RowStatus	,EffectiveDate	,ExpirationDate	,Created,	Updator)
 Values (1,	1106177	,'TLR_ERROR_NOT_FOUND',1,'Labels','Error Code Not Found','ITSOFT\ahmed.atef','2022-06-28 09:32:00',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2022-06-28 09:32:00' ,'ITSOFT\ahmed.atef')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106177 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106177 , 1025, N'رمز الخطأ غير موجود','ITSOFT\ahmed.atef','2022-06-28 09:32:00')
End
GO
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106177 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription,Creator,LastChanged)
 Values (1106177 , 1036, 'Code d''erreur introuvable','ITSOFT\ahmed.atef','2022-06-28 09:32:00')
End
GO
	If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1835)
	Begin
	 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID, ExpirationDate)
	 Values (1835,'INVALID_ID_EXPIRYDATE','Invalid ID with the entered Expiry Date.','Invalid ID with the entered Expiry Date.',4,'',1 ,'Dec 31 9998 12:00AM')
	End
	go

	If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1835 and LanguageLCID = 1025)
	Begin
	 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
	 Values (1835,1025 ,'ID غير صالح مع تاريخ انتهاء الصلاحية الذي تم إدخاله.','ID غير صالح مع تاريخ انتهاء الصلاحية الذي تم إدخاله.' )
	End
	go
-------------------------
-- RulesTranDescriptors -
-------------------------

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_MOI_CHECKING_PER_CUS')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_MOI_CHECKING_PER_CUS', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_MOI_CHECK_CRITERIA')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_MOI_CHECK_CRITERIA', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_MOI_SER_RESPONSE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_MOI_SER_RESPONSE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_MOI_RETURN_ERR')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_MOI_RETURN_ERR', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_MOI_EXPIRY_DATE')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_MOI_EXPIRY_DATE', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_CHECK_MOI')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_CHECK_MOI', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_English_FULLNAME')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_English_FULLNAME', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_Arab_FULLNAME')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_Arab_FULLNAME', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_FIRST_EnglishName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_FIRST_EnglishName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_SECOND_EnglishName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_SECOND_EnglishName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_THIRD_EnglishName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_THIRD_EnglishName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_FOURTH_EnglishName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_FOURTH_EnglishName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_FIFTH_EnglishName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_FIFTH_EnglishName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_FIRST_ArabName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_FIRST_ArabName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_SECOND_ArabName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_SECOND_ArabName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_THIRD_ArabName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_THIRD_ArabName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_FOURTH_ArabName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_FOURTH_ArabName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO

IF NOT EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name = 'TLR_FIFTH_ArabName')
BEGIN
INSERT INTO	RulesTranDescriptors(TranID, DSC_Name, Updator, Creator,RowStatus)
	VALUES(547, 'TLR_FIFTH_ArabName', 'ITSOFT\\ahmed.atef', 'ITSOFT\\ahmed.atef',1)
END
GO
----------------------
-- RulesTranField_ex -
----------------------

IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'grp_MOI_Check_Criteria')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','grp_MOI_Check_Criteria',-1,-1,-1,0,0,'TLR_MOI_CHECK_CRITERIA','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'grp_MOIResidency')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','grp_MOIResidency',-1,-1,-1,0,0,'TLR_RESIDENCY','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'opt_MOIResidency')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','opt_MOIResidency',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'Chkbox_MOIJointRim')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','Chkbox_MOIJointRim',-1,-1,-1,0,0,'TLR_JOINT_RIM_LBL','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'grp_MOITINFormat')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','grp_MOITINFormat',-1,-1,-1,0,0,'TLR_TINFormat','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'grp_MOI_Service_Info')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','grp_MOI_Service_Info',-1,-1,-1,0,0,'TLR_MOI_SER_RESPONSE','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'grp_MOIReturnErrInfo')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','grp_MOIReturnErrInfo',-1,-1,-1,0,0,'TLR_MOI_RETURN_ERR','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'btn_CheckMOI')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','btn_CheckMOI',-1,-1,-1,0,0,'TLR_CHECK_MOI','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOICivilID')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOICivilID',-1,-1,-1,0,0,'TLR_CUSTOMER_CIVILID','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIExpiryDate')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIExpiryDate',-1,-1,-1,0,0,'TLR_MOI_EXPIRY_DATE','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIIDNumber')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIIDNumber',-1,-1,-1,0,0,'TLR_ID_NUM','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOINationality')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOINationality',-1,-1,-1,0,0,'TLR_SO_NATIONALITY','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'grp_Gender')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','grp_Gender',-1,-1,-1,0,0,'TLR_GENDER','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIEngFullName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIEngFullName',-1,-1,-1,0,0,'TLR_English_FULLNAME','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIArabFullName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIArabFullName',-1,-1,-1,0,0,'TLR_Arab_FULLNAME','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIFirstEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIFirstEngName',-1,-1,-1,0,0,'TLR_FIRST_EnglishName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOISecondEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOISecondEngName',-1,-1,-1,0,0,'TLR_SECOND_EnglishName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIThirdEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIThirdEngName',-1,-1,-1,0,0,'TLR_THIRD_EnglishName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIFourthEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIFourthEngName',-1,-1,-1,0,0,'TLR_FOURTH_EnglishName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIFifthEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIFifthEngName',-1,-1,-1,0,0,'TLR_FIFTH_EnglishName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIFirstArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIFirstArabName',-1,-1,-1,0,0,'TLR_FIRST_ArabName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOISecondArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOISecondArabName',-1,-1,-1,0,0,'TLR_SECOND_ArabName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIThirdArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIThirdArabName',-1,-1,-1,0,0,'TLR_THIRD_ArabName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIFourthArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIFourthArabName',-1,-1,-1,0,0,'TLR_FOURTH_ArabName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIFifthArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIFifthArabName',-1,-1,-1,0,0,'TLR_FIFTH_ArabName','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIBirthDate')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIBirthDate',-1,-1,-1,0,0,'TLR_DATE_OF_BIRTH','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIErrorCode')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIErrorCode',-1,-1,-1,0,0,'ERROR_CODE','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'lbl_MOIErrorDescription')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','lbl_MOIErrorDescription',-1,-1,-1,0,0,'ERROR_DESCRIPTION','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOICivilID')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOICivilID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'dt_MOIExpiryDate')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','dt_MOIExpiryDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIIDNumber')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIIDNumber',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'cbo_MOINationality')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','cbo_MOINationality',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547   And FieldIDInPage = 'opt_Gender_MOI')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','opt_Gender_MOI',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIEngFullName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIEngFullName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIArabFullName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIArabFullName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIFirstEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIFirstEngName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOISecondEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOISecondEngName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIThirdEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIThirdEngName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIFourthEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIFourthEngName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIFifthEngName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIFifthEngName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIFirstArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIFirstArabName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOISecondArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOISecondArabName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIThirdArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIThirdArabName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIFourthArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIFourthArabName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIFifthArabName')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIFifthArabName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'dt_MOIBirthDate')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','dt_MOIBirthDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIErrorCode')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIErrorCode',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS (SELECT * FROM RulesTranField_ex Where TranID = 547 And FieldID Is Null And FieldIDInPage = 'txt_MOIErrorDescription')
BEGIN
 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 VALUES (547,NULL,'Teller','txt_MOIErrorDescription',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.atef',1)
END
GO

-----------------------------------
-- RulesParam & RulesTranFldParam -
-----------------------------------
IF NOT EXISTS(Select * From RulesParam Where ParamName='CheckMOI')
BEGIN
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'CheckMOI','New Parameter for checking apply "MOI" or not ','',0,1,0,'','Static','')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'OpenPersonalRim' AND FieldName = 'CheckMOI' AND Param = 'CheckMOI' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'OpenPersonalRim' , 'CheckMOI' , 'CheckMOI' , '0' ,'ITSOFT\ahmed.atef' , 'bit')
END
GO
IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'EditPersonalRim' AND FieldName = 'CheckMOI' AND Param = 'CheckMOI' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'EditPersonalRim' , 'CheckMOI' , 'CheckMOI' , '0' ,'ITSOFT\ahmed.atef' , 'bit')
END
GO

--==========================================
--Devolper	:	Ibrahim Harby
--Date		:	[31/08/2022]
--Reason	:   issue# GFSX15194
--==========================================
--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1104101)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus)
 Values (1,1104101,'TLR_TINFormat',0,'Labels','TIN format',1)
End
go

--------------------------------------------
-- PickLists && PickList_Entries -
--------------------------------------------
If Not Exists(Select * From PickLists Where PickListID = 446)
Begin
 Insert Into PickLists(AppID,PickListID,PickList_Name,RowStatus)
 Values (1,446,'TLR_TINFormat',1)
End
go
If Not Exists(Select * From PickList_Entries Where PickListID = 446 And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,RowStatus,CustomValues)
 Values (446,1,0,'TLR_Unformatted','U',1,NULL)
End
go
If Not Exists(Select * From PickList_Entries Where PickListID = 446 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,RowStatus,CustomValues)
 Values (446,1,1,'TLR_TIN','T',1,NULL)
End
go
If Not Exists(Select * From PickList_Entries Where PickListID = 446 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,RowStatus,CustomValues)
 Values (446,1,2,'TLR_SSN','S',1,NULL)
End
go
If Not Exists(Select * From PickList_Entries Where PickListID = 446 And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,RowStatus,CustomValues)
 Values (446,1,3,'TLR_Custom','C',1,NULL)
End
go





 
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	{14/08/2022}	
--Reason	:	Enh GFSY00917 - ACM000000020167 - RIM Override Audit
--====================================================================


IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100206)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100206,'InsertRimAuditTrails','p',0,'Globalfs','dbo.InsertRimAuditTrails',0,NULL,NULL,'Insert Values Into Table RimAuditTrails',1,'','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO
--==================================================================================================================================================================
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100207)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100207,'GetRimAudit','p',1,'Globalfs','dbo.GetRimAudit',0,NULL,NULL,'select from Table RimAuditTrails',1,'','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO
--==================================================================================================================================================================
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100208)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100208,'GetControlSetupFrom_EX','p',1,'Globalfs','dbo.GetControlSetupFrom_EX',0,NULL,NULL,'select from Table RulesTranField_ex',1,'','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO
--==================================================================================================================================================================


DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'Audit_BackColor')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,RowStatus)
		VALUES (@paramID,'Audit_BackColor','Apply changed Backcolor in case useing aduit Rim ',NULL,0,1,0,'','Static','',1)
END
GO
--==================================================================================================================================================================

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'EditPersonalRim' AND FieldName = 'RimAuditBackColor' AND Param = 'Audit_BackColor')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,DataType,Description)
 VALUES ('EditPersonalRim','RimAuditBackColor','Audit_BackColor','Red','Color',NULL)
END
GO

--==================================================================================================================================================================

--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
exec p_next_id 'RulesDescriptor' ,1

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106194 and Name = 'TLR_OldValue')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106194	,'TLR_OldValue',0,'Labels','Old Value')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106194 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106194 , 1025, N'القيمه القديمة'	)
End
GO 
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106194 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106194 , 1036, N'ancienne valeur'	)
End
GO 
--===========================================================================================================
--===========================================================================================================
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106195 and Name = 'TLR_NewValue')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106195	,'TLR_NewValue',0,'Labels','New Value')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106195 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106195 , 1025, N'القيمه الجديدة'	)
End
GO 
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106195 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106195 , 1036, N'nouvelle valeur'	)
End
GO 
--===========================================================================================================
--===========================================================================================================
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106196 and Name = 'TLR_ControlName')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106196	,'TLR_ControlName',0,'Labels','Control Name')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106196 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106196 , 1025, N'اسم التحكم'	)
End
GO 
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106196 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106196 , 1036, N'nom du contrôle'	)
End
GO 
--===========================================================================================================
--===========================================================================================================
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106197 and Name = 'TLR_Label')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106197	,'TLR_Label',0,'Labels','Label')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106197 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106197 , 1025, N'اسم الملصق'	)
End
GO 
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106197 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106197 , 1036, N'Étiquette'	)
End
GO 
--===========================================================================================================
--===========================================================================================================
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106198 and Name = 'TLR_AuditControls')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106198	,'TLR_AuditControls',0,'Labels','Audit Controls')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106198 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106198 , 1025, N' ضوابط التدقيق'	)
End
GO 
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106198 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106198 , 1036, N'contrôles d audit'	)
End
GO 
--Devolper :	Aya Tarek
--Date       :	[7/8/2022]		
--Reason     :	CR#GFSY00918 - ACM000000020364 - Swift ISO20022-XML Format
--=============================================================
PRINT 'Start. Script for CR# GFSY00918 DML  Script'
GO
--RulesDescriptor

IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1106184)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1106184,'TLR_READ_XML_FILE_SD',0,'Labels','Read XML File')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106184 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106184,1025,N' XML قراءة ملف ')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106184 AND LCID=1036)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106184,1036,'Lire le fichier XML')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1106185)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1106185,'TLR_READ_XML_FILE_LD',0,'Labels','This property is used to setup whether System Should Read from MT file Or XML File Or both.\r\n 0 : which is the default value (the system will read from MT file).\r\n 1 : the system will read from XML file.\r\n 2 : where the system can read from both (MT file and XML file).')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106185 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106185,1025,N' أو كليهما MT أو ملف XML تُستخدم هذه الخاصية لإعداد ما إذا كان يجب على النظام القراءة من ملف. \ r \ n 0: وهي القيمة الافتراضية (سيقرأ النظام من ملف MT). \ r \ n 1: سيقرأ النظام من ملف XML. \ r \ n 2: حيث يمكن للنظام القراءة من كل من (ملف MT وملف XML).')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106185 AND LCID=1036)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106185,1036,'Cette propriété est utilisée pour configurer si le système doit lire à partir du fichier MT ou du fichier XML ou les deux.\r\n 0 : qui est la valeur par défaut (le système lira à partir du fichier MT).\r\n 1 : le système lira à partir du fichier XML.\r\n 2 : où le système peut lire à la fois (fichier MT et fichier XML).')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1106186)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1106186,'TLR_INREMITT_READXMLPATH_SD',0,'Labels','Inward Remittance Read XML Path')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106186 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106186,1025,N'لقراءة الحوالات الواردة  XMLمسار')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106186 AND LCID=1036)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106186,1036,'Chemin XML de lecture des versements entrants')
END
GO
--
IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1106187)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1106187,'TLR_INREMITT_READXMLPATH_LD',0,'Labels','This property is used to setup the inward remittance read XML file location, the system will use this path to read new files.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106187 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106187,1025,N'تستخدم هذه الخاصية لتحديد موقع ملف  قراءة التحويلات النقدية الداخلية، سيستخدم النظام هذا المسار لقراءة الملفات الجديدة(XML)')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106187 AND LCID=1036)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106187,1036,'Cette propriété est utilisée pour configurer l’emplacement du fichier de lecture du virement entrant. Le système utilisera ce chemin d’accès pour lire les nouveaux fichiers (XML)')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1106188)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1106188,'TLR_INREMITT_WRITEXMLPATH_SD',0,'Labels','Inward Remittance Write XML Path')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106188 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106188,1025,N'لكتابة الحوالات الواردة  XMLمسار')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106188 AND LCID=1036)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106188,1036,'Chemin Accès Écriture Virement Entrant XML')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1106189)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1106189,'TLR_INREMITT_WRITEXMLPATH_LD',0,'Labels','This property is used to setup the inward remittance write XML file location, the system will use this path to write new files.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106189 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106189,1025,N'تستخدم هذة الخاصية لتحديد موقع كتابة التحويلات النقدية الداخلية، سيستخدم النظام هذا المسار لكتابة الملفات المقروءة بالفعلxml')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1106189 AND LCID=1036)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1106189,1036,'Cette propriété est utilisée pour configurer l’emplacement du fichier d’écriture du virement entrant. Le système utilisera ce chemin d’accès pour écrire les fichiers déjà lus.(XML)')
END
GO
--BankConfig
IF NOT EXISTS(Select * from BankConfig where Name = 'READ_XML_FILE')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'READ_XML_FILE',@Value = '0',@DataType = 'int',@ShortDescr = 'TLR_READ_XML_FILE_SD',@LongDescr = 'TLR_READ_XML_FILE_LD',@MaxVal = '2',@MinVal='0'
END
GO
IF NOT EXISTS(Select * from BankConfig where Name = 'IR_ReadXML_PATH')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'IR_ReadXML_PATH',@Value = 'C:\IR_ReadXML',@DataType = 'Path',@ShortDescr = 'TLR_INREMITT_READXMLPATH_SD',@LongDescr = 'TLR_INREMITT_READXMLPATH_LD',@MaxVal = '',@MinVal='0'
END
GO
IF NOT EXISTS(Select * from BankConfig where Name = 'IR_WriteXML_PATH')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'IR_WriteXML_PATH',@Value = 'C:\IR_WriteXML',@DataType = 'Path',@ShortDescr = 'TLR_INREMITT_WRITEXMLPATH_SD',@LongDescr = 'TLR_INREMITT_WRITEXMLPATH_LD',@MaxVal = '',@MinVal='0'
END
GO

----------------------------------SQLstrings-----------------------
IF Not Exists(select * from SQLstrings where AccessID = 1100209)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile , Developer , Updator , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100209 , 'Get_MXMessageTagList' , 'p' , 1, 'Globalfs' , 'dbo.Get_MXMessageTagList' , 0 , '' , '' , 'ITSOFT\aya.tarek' , 'ITSOFT\aya.tarek' , 'Select all MX Message Tags List  from setup table XMLToIRTableMapping' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO
PRINT 'End. Script for CR# GFSY00918 DML  Script'
GO
--===============================================================
--Devolper	:	Shaimaa Nasser 
--Date		:	[09/08/2022]
--Reason	:	Enh GFSY00919 - ACM000000019738 - MT202 and MT199
--===============================================================
--------------------------------------------
-- RulesErrorDescription && RulesLocalErrorDescription -
	
	If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1837)
	Begin
	 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID, ExpirationDate)
	 Values (1837,'NO_TEMPLETES_AVAILABLE','There is no Templates Defined in setup table.','There is no Templates Defined in setup table.',4,'',1 ,'Dec 31 9998 12:00AM')
	End
	go

	If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1837 and LanguageLCID = 1025)
	Begin
	 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
	 Values (1837,1025 ,N'لا توجد قوالب معرّفة في جدول الإعداد .',N'لا توجد قوالب معرّفة في جدول الإعداد.' )
	End
	else 
	Begin
	UPDATE RulesLocalErrorDescription set DisplayText =  N'لا توجد قوالب معرّفة في جدول الإعداد .' Where DescriptionNumber = 1837 and LanguageLCID = 1025
	End
	go
		If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1837 and LanguageLCID = 1036)
	Begin
	 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
	 Values (1837,1036 ,N'il n''y a pas de modèles définis dans le tableau de configuration.',N'il n''y a pas de modèles définis dans le tableau de configuration.' )
	End
	go  
		If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1838)
	Begin
	 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID, ExpirationDate)
	 Values (1838,'SELECT_TEMPLET','Please, Select template for MT199 first.','please, Select template for MT199 first.',4,'',1 ,'Dec 31 9998 12:00AM')
	End
	go

	If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1838 and LanguageLCID = 1025)
	Begin
	 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
	 Values (1838,1025 ,N'من فضلك ، حدد القوالب لـ MT199 أولاً.',N'من فضلك ، حدد القوالب لـ MT199 أولاً.' )
	End	
	else 
	Begin
	UPDATE RulesLocalErrorDescription set DisplayText = N'من فضلك ، حدد القوالب لـ MT199 أولاً.' Where DescriptionNumber = 1838 and LanguageLCID = 1025
	End
	go
	If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1838 and LanguageLCID = 1036)
	Begin
	 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
	 Values (1838,1036 ,N's''il vous plaît, sélectionnez d''abord le modèle pour MT199.' ,N's''il vous plaît, sélectionnez d''abord le modèle pour MT199.' )
	End
	go  

 


--------------------------------------------------------------------------------- 
-------------------------------------------************ SQLstrings**********
--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 

	If Not Exists(select * From SQLstrings Where AccessID = 1100205)
	Begin
		Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
		Values (1,1100205,'GET_MT199_Templates','p',1,'Globalfs','dbo.GET_MT199_Templates',0,'','','ITSOFT\shaimaa.nasser','ITSOFT\shaimaa.nasser','Oct 07 2021 10:39AM','Get available templates in the setup table.',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','May 20 2019 12:02PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
	End
	go
--------------------------------------------------------------------------------- 
-------------------------------------------************ RulesDescriptor**********
--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 

   If Not Exists(Select * From   RulesDescriptor  Where  DescriptorID = 1106182)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106182,'TLR_SO_MT_199',0,'Labels','MT199 Fields',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End 
	  If Not Exists(Select * From RulesDescriptor  Where  DescriptorID = 1106183)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106183,'TLR_SO_Narrative',0,'Labels','79: Narrative',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	If Not Exists(Select * From RulesDescriptor  Where  DescriptorID = 1106191)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106191,'TLR_PREVIEW',0,'Labels','Preview',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	If Not Exists(Select * From RulesDescriptor  Where  DescriptorID = 1106192)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106192,'TLR_MT199_FIELDS',0,'Labels','MT199 Fields Error',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End 
		If Not Exists(Select * From RulesDescriptor  Where  DescriptorID = 1106193)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106193,'TLR_MT199_ATTACH',0,'Labels','Attach MT199/Template',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End 
	ELSE
	BEGIN
	UPDATE  RulesDescriptor set Descriptor = 'Attach MT199/Template'   Where  DescriptorID = 1106193
	END 
	GO
	If Not Exists(Select * From RulesDescriptor  Where  DescriptorID = 1106202)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106202,'TLR_MT199_WILLBEGENERATED',0,'Labels','MT199 Message Will be generated!',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End  
	GO
	--TLR_MT199_INFO 1106203 
	If Not Exists(Select * From RulesDescriptor  Where  DescriptorID = 1106203)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106203,'TLR_MT199_INFO',0,'Labels','MT199 Info',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End  
	GO
	 	--TLR_MT199_Field_CHANGED 1106204 
	If Not Exists(Select * From RulesDescriptor  Where  DescriptorID = 1106204)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106204,'TLR_MT199_Field_CHANGED',0,'Labels','Field tag was changed ',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End  
	GO
		If Not Exists(Select * From RulesDescriptor  Where  DescriptorID = 1106205)
	Begin
	 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,RowStatus,EffectiveDate,ExpirationDate)
	 Values (1,1106205,'TLR_MT199_MSGPREVIEW',0,'Labels','Message Preview',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End  
	GO
--------------------------------------------------------------------------------- 
-------------------------------------------************ RulesDescriptorLocal**********
--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 

   If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106182 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106182,1025,N'حقول MT199','May 7 2018 09:48AM')
	End
	ELSE
	BEGIN
	UPDATE  RulesDescriptorLocal set LocalDescription = N'حقول MT199'   Where DescriptorID = 1106182 And LCID = 1025
	END 
	go
   If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106183 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106183,1025,N'79: مفصل','May 7 2018 09:48AM')
	End
	ELSE
	BEGIN
	UPDATE  RulesDescriptorLocal set LocalDescription = N'79: مفصل'  Where DescriptorID = 1106183 And LCID = 1025
	END 
	go
   If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106191 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106191,1025,N'معاينة','May 7 2018 09:48AM')
	End
	ELSE
	BEGIN
	UPDATE  RulesDescriptorLocal set LocalDescription =N'معاينة'  Where DescriptorID = 1106191 And LCID = 1025
	END 
	go
   If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106192 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106192,1025,N'MT199 خطأ الحقول','May 7 2018 09:48AM')
	End
	ELSE
	BEGIN
	UPDATE  RulesDescriptorLocal set LocalDescription =N'MT199 خطأ الحقول'  Where DescriptorID = 1106192 And LCID = 1025
	END 
	go

	  If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106182 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106182,1036,N'Champs MT199','May 7 2018 09:48AM')
	End
	go
   If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106183 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106183,1036,N'79: Notes','May 7 2018 09:48AM')
	End
	go
   If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106191 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106191,1036,N'Erreur de champs MT199','May 7 2018 09:48AM')
	End
	go
   If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106192 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106192,1036,N'Aperçu','May 7 2018 09:48AM')
	End
	go
	   If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106193 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106193,1025, N' إرفاق قوالب /MT199 ','May 7 2018 09:48AM')
	End
	ELSE
	BEGIN
	UPDATE  RulesDescriptorLocal set LocalDescription = N' إرفاق قوالب /MT199 '   Where DescriptorID = 1106193 And LCID = 1025
	END 
	go 
	  If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106193 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106193,1036,N'Joindre MT199/Tempête','May 7 2018 09:48AM')
	End
	go
	 If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106202 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106202,1025,N'سيتم إنشاء رسالة MT199','May 7 2018 09:48AM')
	End
	ELSE
	BEGIN
	UPDATE  RulesDescriptorLocal set LocalDescription = N'سيتم إنشاء رسالة MT199'  Where DescriptorID = 1106202 And LCID = 1025
	END 
	go

	  If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106202 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106202,1036,N'Le message MT199 sera généré','May 7 2018 09:48AM')
	End
	go
	--1106203
	 If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106203 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106203,1036,N'MT199 Info','May 7 2018 09:48AM')
	End
	GO  
	 If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106203 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106203,1025,N'تفاصيل  MT199','May 7 2018 09:48AM')
	End
	GO
	
	 	-- 1106205 
   If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106205 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106205,1036,N'aperçu du message','May 7 2018 09:48AM')
	End
	GO  
	 If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106205 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106205,1025,N'معاينة الرسالة','May 7 2018 09:48AM')
	End
	GO
	--1106204

	  If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106204 And LCID = 1036)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106204,1036,N'La balise de champ a été modifiée','May 7 2018 09:48AM')
	End
	GO  
	 If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1106204 And LCID = 1025)
	Begin
	 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
	 Values (1106204,1025,N'تم تغيير علامة الحقل','May 7 2018 09:48AM')
	End 
	GO
--------------------------------------------------------------------------------- 
-------------------------------------------************ RulesTranDescriptors*****
--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 
   If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_SO_MT_199' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_SO_MT_199',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go
   If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_20_REFERENCE_NUMBER' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_20_REFERENCE_NUMBER',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go
	 If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_21_RELATED_REFERENCE_NUM' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_21_RELATED_REFERENCE_NUM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go
    If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_SO_Narrative' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_SO_Narrative',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go
   If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_PREVIEW' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_PREVIEW',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go
   If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'COR_CANCEL' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'COR_CANCEL',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go
   If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'COR_OK' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'COR_OK',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go
	-- TLR_MT199_FIELDS
	  If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_MT199_FIELDS' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_MT199_FIELDS',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
	--TLR_MT199_ATTACH
	  If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_MT199_ATTACH' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_MT199_ATTACH',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
	--TLR_MT199_WILLBEGENERATED
		  If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_MT199_WILLBEGENERATED' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_MT199_WILLBEGENERATED',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
	--TLR_MT199_INFO
	 If Not Exists(Select * From RulesTranDescriptors Where TranID = 277  AND DSC_Name = 'TLR_MT199_INFO'   )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_MT199_INFO',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
	 	--TLR_MT199_Field_CHANGED 1106204 
		 If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_MT199_Field_CHANGED' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_MT199_Field_CHANGED',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
		 If Not Exists(Select * From RulesTranDescriptors Where DSC_Name = 'TLR_MT199_MSGPREVIEW' AND TranID = 277 )
	Begin
	 Insert Into RulesTranDescriptors(TranID,DSC_Name,RowStatus,EffectiveDate,ExpirationDate)
	 Values (277,'TLR_MT199_MSGPREVIEW',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
	End
	go 
--------------------------------------------------------------------------------- 
-------------------------------------------************ RulesTranField_ex********
--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 
	If Not Exists(Select * From RulesTranField_ex Where TranID = 277  And FieldIDInPage = '_cbo_MT199')
	Begin
	 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values (277,NULL,'Teller','_cbo_MT199',-1,-1,-1,0,0,'','','' ,0)
	End
	go 
    If Not Exists(Select * From RulesTranField_ex Where TranID = 277  And FieldIDInPage = 'MT199_chk')
	Begin
	 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values (277,NULL,'Teller','MT199_chk',-1,-1,-1,0,0,'','','' ,0)
	End
	go 
	 If Not Exists(Select * From RulesTranField_ex Where TranID = 277  And FieldIDInPage = 'MT199_button')
	Begin
	 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values (277,NULL,'Teller','MT199_button',-1,-1,-1,0,0,'','','' ,0)
	End
	go 
	 If Not Exists(Select * From RulesTranField_ex Where TranID = 277  And FieldIDInPage = 'MT199_groupBox1')
	Begin
	 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values (277,NULL,'Teller','MT199_groupBox1',-1,-1,-1,0,0,'','','' ,0)
	End
	go  
 --------------------------------------------------------------------------------
-------------------------------------------************ RulesTranField***********
--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 
	If Not Exists(Select * From RulesTranField Where TranID = 277 And FieldID = 295)  -- CSR_VISIT_INFO
		Begin
			Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
			Values (277,295,1,0,0,NULL ,1,NULL,'' ,1,0,NULL,0,0,NULL,0,-1)
		End
GO
	If Not Exists(Select * From RulesTranField Where TranID = 277 And FieldID = 1608)  -- TLR_REGION_HEAD
		Begin
			Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
			Values (277,1608,1,0,0,NULL ,1,NULL,'' ,1,0,NULL,0,0,NULL,0,-1)
		End
GO 
	If Not Exists(Select * From RulesTranField Where TranID = 277 And FieldID = 1087)  -- TLR_ID_TYPE2_3
		Begin
			Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
			Values (277,1087,1,0,0,NULL ,1,NULL,'' ,1,0,NULL,0,0,NULL,0,-1)
		End
GO
	If Not Exists(Select * From RulesTranField Where TranID = 277 And FieldID = 1292)  -- TLR_CHEQUE_DP
		Begin
			Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
			Values (277,1292,1,0,0,NULL ,1,NULL,'' ,1,0,NULL,0,0,NULL,0,-1)
		End
GO
----------------------------------------------------- RulesParam ---------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------
	declare @paramid int
	select @paramid=MAX(paramid)+1 from RulesParam

	 If Not Exists(Select * From RulesParam Where ParamName = 'Static_Fld72Ln1_forMT199')
	Begin
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@paramid,'Static_Fld72Ln1_forMT199','Default value for Fld72Ln1 if MT199 Checked',NULL,0,0,0,'','Static    ','','Sep  22 2021 8:22AM',N'ITSOFT\shaimaa.nasser','Sep  22 1900 12:00AM','Dec 31 9999 12:00AM',1)
	End

  If Not Exists(Select * From RulesTranFldParam Where TranName = 'IssueTTAgainstAccount' And Param = 'Static_Fld72Ln1_forMT199')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,DataType,LastChanged,Description)
	 Values ('IssueTTAgainstAccount','Transaction','Static_Fld72Ln1_forMT199','/REC/:22Y: OCLR' ,'nvarchar','Sep  22 2021 8:22AM','Specify Default value for Fld21 if MT199 Checked')
	End

   If Not Exists(Select * From RulesParam Where ParamName = 'Static_Fld21_forMT199')
	Begin
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@paramid+1,'Static_Fld21_forMT199','Default value for Fld21 if MT199 Checked',NULL,0,0,0,'','Static    ','','Sep  22 2021 8:22AM',N'ITSOFT\shaimaa.nasser','Sep  22 1900 12:00AM','Dec 31 9999 12:00AM',1)
	End

  If Not Exists(Select * From RulesTranFldParam Where TranName = 'IssueTTAgainstAccount' And Param = 'Static_Fld21_forMT199')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,DataType,LastChanged,Description)
	 Values ('IssueTTAgainstAccount','Transaction','Static_Fld21_forMT199','LIABILITY STLMNT' ,'nvarchar','Sep  22 2021 8:22AM','Specify Default value for Fld72Ln1 if MT199 Checked')
	End 

go
--================================================================
--Devolper	:	Ahmed Atef
--Date		:	[30/08/2022]
--Reason	:	Enh GFSY00921 - ACM000000020368 - ECC Denomination
--================================================================

IF Not Exists(select * from SQLstrings where AccessID = 1100211)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile  , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100211 , 'GetCashDrawerAvailableBalance' , 'p' , 1, 'Globalfs' , 'dbo.GetCashDrawerAvailableBalance' , 0 , '' , '', 'calculate the teller cash drawer available balance ' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 

GO
IF Not Exists(select * from SQLstrings where AccessID = 1100213)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile  , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100213 , 'GetSuggestedDenomination' , 'p' , 1, 'Globalfs' , 'dbo.GetSuggestedDenomination' , 0 , '' , '', 'get suggested and available denomination ' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO
--Devolper :	Ibrahim Harby
--Date       :	[15/09/2022]		
--Reason     :	Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2
--=============================================================
PRINT 'Start. Script for CR# GFSY00922 DML  Script'
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100212)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100212,'GET_JOURNAL_SUMMARY_PRINTAUDIT','s',1,'Globalfs',N'exec dbo.Get_Journal_Summary_For_Printing_Audit   @criteria=?, @criteria2=?, @start_date =?, @end_date= ?,  @order_time_ascending=?,@max_rows=?,@page_back=?, @LCID=?, @for_user=?',0,NULL,NULL,'Get summary rows for journal with audit scan for new printing transaction',1,'','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO

IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100214)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100214,'GET_JOURNAL_SUMMARY_AUDIT','s',1,'Globalfs',N'exec dbo.Get_Journal_Summary_Audit   @criteria=?, @start_date =?, @end_date= ?,  @order_time_ascending=?,@max_rows=?,@page_back=?, @LCID=?, @for_user=?',0,NULL,NULL,'Get summary rows for journal with audit scan',1,'','',0,0,1,NULL,NULL,0,0,0,0,0)
END

IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100215)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100215,'LIST_JOURNAL_TRAN_NAMES_AUDIT','p',1,'Globalfs',N'dbo.List_Journal_Transaction_Names_Audit',0,NULL,NULL,'List Names of transactions in Journal with Audit',1,'','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO

--===========================================================================================================
--===========================================================================================================
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106199 and Name = 'TLR_ShowAuditTransactions')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106199	,'TLR_ShowAuditTransactions',0,'Labels','Show Audit Transaction')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106199 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106199 , 1025, N'اظهار معاملات التدقيق'	)
End
GO 
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106199 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106199 , 1036, N'afficher les transactions de audit'	)
End
GO 
--===========================================================================================================
--===========================================================================================================
If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106200 and Name = 'TLR_PrintAuditTranReport')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106200	,'TLR_PrintAuditTranReport',0,'Labels','Print Transaction Audit Report')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106200 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106200 , 1025, N'طباعه تقرير معاملات التدقيق'	)
End
GO 
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106200 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106200 , 1036, N'imprimer le rapport de audit des transactions'	)
End
GO 
--===========================================================================================================
--===========================================================================================================

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1106201 and Name = 'TLR_lblTransactionChangedData')
Begin
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	)
 Values (1,	1106201	,'TLR_lblTransactionChangedData',0,'Labels','Transaction Changed Data')
End
GO

If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106201 And LCID = 1025) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106201 , 1025, N'البيانات المتغيره للمعامله'	)
End
GO 
If Not Exists(select * From RulesDescriptorLocal Where DescriptorID = 1106201 And LCID = 1036) 
Begin
 Insert Into RulesDescriptorLocal(DescriptorID, LCID, LocalDescription)
 Values (1106201 , 1036, N'données modifiées par la transaction'	)
End
GO 

--===========================================================================================================
--===========================================================================================================
If Not Exists(Select * From RulesTranField_ex Where TranID = 861  And FieldIDInPage = '_check_ShowAuditTransactions')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (861,NULL,'Teller','_check_ShowAuditTransactions',-1,-1,-1,1,0,NULL,'False',NULL,'ITSOFT\ibrahim.harby',0,NULL,NULL,NULL,NULL)
End
GO
If Not Exists(Select * From RulesTranField_ex Where TranID = 861  And FieldIDInPage = '_btn_PrintTranAuditReport')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (861,NULL,'Teller','_btn_PrintTranAuditReport',-1,-1,-1,1,0,NULL,'False',NULL,'ITSOFT\ibrahim.harby',0,NULL,NULL,NULL,NULL)
End
GO
--===========================================================================================================
--===========================================================================================================
If Not Exists(Select * From AuthRulesTranField_exMap Where TranID = 861 And FieldIDInPage = '_check_ShowAuditTransactions' And RoleName = 'GFSTellers')
Begin
 Insert Into AuthRulesTranField_exMap(TranID,FieldIDInPage,RoleName)
 Values (861,'_check_ShowAuditTransactions','GFSTellers')
End
go

PRINT 'End. Script for CR# GFSY00922 DML  Script'
GO
--==============================
--Devolper	:	Aya Tarek
--Date		:	[9/10/2022]		
--Reason	:	Issue GFSX14863
--==============================


-----------------------
-- RulesTranField_ex --
-----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_CO_CHEQUE_NUMBER')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_CO_CHEQUE_NUMBER',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblOldCONumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblOldCONumber',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_REMITTER_ID_ADDRESS2')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_REMITTER_ID_ADDRESS2',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_OTHER_PURPOSE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_REMITTER_ID_ADDRESS1')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_REMITTER_ID_ADDRESS1',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_REMITTER_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_REMITTER_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_RIM_PHONE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_RIM_PHONE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_RIM_NATIONALITY')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_RIM_NATIONALITY',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_RIm_PURPOSE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_RIm_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_RIM_ID_NUMBER')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_RIM_ID_NUMBER',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTL_RIM_ID_TYPE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTL_RIM_ID_TYPE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lbl_PhoneNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lbl_PhoneNo',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblCoType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblCoType',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_REQUEST_TYPE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_REQUEST_TYPE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_PAYMENT_VALUE_DATE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_PAYMENT_VALUE_DATE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_GTD_TICKET')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_GTD_TICKET',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_NARRAIVE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_NARRAIVE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_BENEFICIARY_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_BENEFICIARY_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_CO_AMOUNT')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_CO_AMOUNT',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_DEBIT_AMOUNT')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_DEBIT_AMOUNT',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblTLR_DEBIT_AMOUNT_LOCAL')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblTLR_DEBIT_AMOUNT_LOCAL',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 185 And  FieldIDInPage = '_lblDocumentsReceived')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (185,NULL,'Teller','_lblDocumentsReceived',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO
-----------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_CO_AMOUNT')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_CO_AMOUNT',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_DEBIT_AMOUNT')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_DEBIT_AMOUNT',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_CO_CHEQUE_NUMBER')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_CO_CHEQUE_NUMBER',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblCOR_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblCOR_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_PHONE_NUM')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_PHONE_NUM',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_CUSTOMER_ID_TYPE1')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_CUSTOMER_ID_TYPE1',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_CUSTOMER_ID_NUMBER1')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_CUSTOMER_ID_NUMBER1',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_PAYMENT_VALUE_DATE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_PAYMENT_VALUE_DATE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblOldCONumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblOldCONumber',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_REMITTER_ID_ADDRESS2')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_REMITTER_ID_ADDRESS2',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_OTHER_PURPOSE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_REMITTER_ID_ADDRESS1')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_REMITTER_ID_ADDRESS1',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_REMITTER_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_REMITTER_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_RIM_PHONE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_RIM_PHONE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_RIM_NATIONALITY')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_RIM_NATIONALITY',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_RIm_PURPOSE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_RIm_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_RIM_ID_NUMBER')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_RIM_ID_NUMBER',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTL_RIM_ID_TYPE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTL_RIM_ID_TYPE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblCoType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblCoType',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblGTDDealTicket')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblGTDDealTicket',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_CASH_CURRENCY')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_CASH_CURRENCY',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_BENEFICIARY_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_BENEFICIARY_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_ISSUER_NATIONALITY')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_ISSUER_NATIONALITY',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_NARRAIVE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_NARRAIVE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lbl_Nationality')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lbl_Nationality',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_BENEFICIARY_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_BENEFICIARY_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 183 And  FieldIDInPage = '_lblTLR_REQUEST_TYPE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (183,NULL,'Teller','_lblTLR_REQUEST_TYPE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO
-------------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_CO_AMOUNT')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_CO_AMOUNT',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_DEBIT_AMOUNT')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_DEBIT_AMOUNT',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_BENEFICIARY_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_BENEFICIARY_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_CO_CHEQUE_NUMBER')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_CO_CHEQUE_NUMBER',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_DEBIT_AMOUNT_LOCAL')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_DEBIT_AMOUNT_LOCAL',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_NARRAIVE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_NARRAIVE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_PAYMENT_VALUE_DATE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_PAYMENT_VALUE_DATE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_CHEQUE_NO')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_CHEQUE_NO',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_GTD_TKT')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_GTD_TKT',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_CHEQUE_VALUE_DATE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_CHEQUE_VALUE_DATE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_REMITTER_ID_ADDRESS2')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_REMITTER_ID_ADDRESS2',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_OTHER_PURPOSE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_REMITTER_ID_ADDRESS1')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_REMITTER_ID_ADDRESS1',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_REMITTER_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_REMITTER_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_RIM_PHONE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_RIM_PHONE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_RIM_NATIONALITY')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_RIM_NATIONALITY',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_RIm_PURPOSE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_RIm_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_RIM_ID_NUMBER')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_RIM_ID_NUMBER',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTL_RIM_ID_TYPE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTL_RIM_ID_TYPE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lbl_PhoneNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lbl_PhoneNo',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblCoType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblCoType',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 186 And  FieldIDInPage = '_lblTLR_REQUEST_TYPE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (186,NULL,'Teller','_lblTLR_REQUEST_TYPE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO
----------------------------------------------------------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_CO_AMOUNT')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_CO_AMOUNT',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_DEBIT_AMOUNT')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_DEBIT_AMOUNT',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_DEBIT_AMOUNT_LOCAL')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_DEBIT_AMOUNT_LOCAL',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblOldCONumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblOldCONumber',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_REMITTER_ID_ADDRESS2')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_REMITTER_ID_ADDRESS2',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_OTHER_PURPOSE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_OTHER_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_REMITTER_ID_ADDRESS1')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_REMITTER_ID_ADDRESS1',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_REMITTER_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_REMITTER_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_RIM_PHONE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_RIM_PHONE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_RIM_NATIONALITY')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_RIM_NATIONALITY',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_RIm_PURPOSE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_RIm_PURPOSE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_RIM_ID_NUMBER')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_RIM_ID_NUMBER',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTL_RIM_ID_TYPE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTL_RIM_ID_TYPE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblCoType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblCoType',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_CO_CHEQUE_NUMBER')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_CO_CHEQUE_NUMBER',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblMerchant')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblMerchant',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_GTD_TICKET')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_GTD_TICKET',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_NARRAIVE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_NARRAIVE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_BENEFICIARY_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_BENEFICIARY_NAME',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 281 And  FieldIDInPage = '_lblTLR_REQUEST_TYPE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (281,NULL,'Teller','_lblTLR_REQUEST_TYPE',-1,-1,-1,1,0,'','','',N'ITSOFT\aya.tarek',1)
End
GO
