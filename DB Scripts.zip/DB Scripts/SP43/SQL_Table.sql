GO
IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'EFTS_ResponseCode' AND COLUMN_NAME = 'Reversal_Type' AND DATA_TYPE='Nvarchar')                   
BEGIN
	ALTER TABLE [dbo].[EFTS_ResponseCode]
    Add Reversal_Type Nvarchar(40) Null 
END
GO 