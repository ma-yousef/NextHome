--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Update_RulesTranField_ex
Go

create proc dbo.Update_RulesTranField_ex    
@TranID Tran_ID,    
@Fieldid Field_ID,    
@Module char(10) ='Teller',    
@Optional FldOption = 0,    
@isreadonly bit = 0,    
@tranfielddescr DescriptorName,    
@fieldtype varchar(11),     
@firstpage int = -1 ,    
@lastpage int = -1 ,    
@controlpage int = -1,    
@defaultvalue varchar(90),    
@fieldIDInPage varchar(100) = '',    
@IsVisible bit = 1,
@updator OperatorID
AS      
/*      
CreationDate: 2007-11-19      
OriginalName: dbo.Update_RulesTranField_ex      
Programmer: m abdelwahed      
Description: update rulestranfield_ex tables      
Output:        
Assumption:       

modifier : hany nasr
date : 8-5-2008
reason : performance tunning

modifier : Adel Shaban
date : 2/5/2010
reason : Adding parameter @IsVisible

Modifier : Mohamed Elabd
Date :     25-March-2018
Reason :   Add parameter @updator for Audit Trail - Issue# GFSX12935
*/      
set nocount on    
update dbo.RulesTranField_ex    
set FieldID=@Fieldid,    
 Module=@Module,    
 Optional=@Optional,    
 IsReadOnly=@isreadonly,    
 TranFieldDescr=@tranfielddescr,    
 FieldType=@fieldtype,    
 FirstPage=@firstpage,    
 LastPage=@lastpage,    
 ControlPage=@controlpage,    
 DefaultValue=@defaultvalue,
 IsVisible = @IsVisible,    
 Updator = @updator
where TranID=@TranID    
and FieldIDInPage=@fieldIDInPage  
return @@error     
Go
--End of Automatic Generation

drop_old_proc 'HCS_Select_OutRejectedChq'
go
CREATE proc  HCS_Select_OutRejectedChq  
( @fileRefNumber nvarchar(22)  )         
as        
    
/*        
CreationDate: 04/10/2018     
Programmer:  Rokaia Kadry        
Description: Issue#GFSX12976 ASSR#INC000000198306 Select With RefNumber Critirea
Output:                
      
*/    
  
begin        
   
select FileReferenceNumber,
	   ClearBankCode,
	   ClearBranchCode,
	   ClearBankBranchID,
	   ChequeNumber,
	   ChequeAmount,
	   CustomerAccNumber,
	   CustomerShadowAcc,
	   ShadowAccountCurrency,
	   ShadowAccountType,
	   DrawerAccNumber,
	   GLNumber,
	   Status,
	   Processed,
	   UserID,
	   Branch,
	   HostResponse,
	   Host_RefNo
from    OutRejectedCheques
WHERE FileReferenceNumber =@fileRefNumber
end
Go

USE Globalfs
go
drop_old_proc AutoDebit_EG_2
go
CREATE PROC dbo.AutoDebit_EG_2
AS
/*
     Creator : Muhammad Mabrouk
	 Date    : 2/1/2017
     Reason  : CR#GFSY00614 ADIB_CRQ7501_xp Cmdshell Alternative-  Core System Intregration -
			   Scripts were included in SSIS Packages by "Osama Nabil"  
			   Run the AutoDebit Package Globalfs_AutoDebit_Sybase.dtsx  
    
     Developer : Rokaia KAdry
	 Date    : 02/05/2018
     Reason  : Issue#GFSX12993 Missing Column in BulkData LoadFileName
*/

BEGIN
   select  id as "id",
		   UserId ,
		   [Status] as [status],
		   RecordType as recordtype,
		   AccountType as accounttype,
		   DrAmount as amt,
		   DrAccountNo as acct_no,
		   ChequeNo as chk_no,
		   Sender_Bank,
		   Sender_Bank_Name,
		   ValueDays,
		   ChargeAmount as "ChargeAmount",
		   Branch as "Branch",
		   Created as "Created",
		   Rim_Class as "Rim_Class",
		   Rim_No as "Rim_No",
		   Profile_ID as "Profile_ID",
		   Currency as "Currency",
		   Acct_Type as "Acct_Type",
		   FeeCode as "FeeCode",
		   LoadFileName 
	    from AutoDebit
END
go

IF OBJECT_ID('dbo.AutoDebit_EG_2') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.AutoDebit_EG_2 >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.AutoDebit_EG_2 >>>'
go
 
Drop_old_proc 'dbo.ValidateBulkChequesDublication'
go
CREATE procedure dbo.ValidateBulkChequesDublication --'001BC00014917'    
 @ref_no varchar(25)    
/*     
Developer Asmaa Gamal  
Date 05/12/2016  

Modifier : Mohamed Elabd
Date     : 02-May-2018
Reason   : Fix CONVERT(int,ChequeNumber) to be decimal 
		   and change @ChequeNumberTrim from int to decimal - Issue# GFSX12993
*/    
as  

DECLARE @ChequeType int ,
		@ChequeCount int,
		@Processed int,
		@ClearBankBranchID int,
		@ChequeNumberTrim decimal, 
		@FlagNoDublicated int,
		@ChequeNumber nvarchar(20),
		@ProcessError nvarchar(255),
		@DebitAccountNumber nvarchar(36),
		@ClearBankName nvarchar(40),
		@ClearBranchName nvarchar(50),
		@BankCode nchar(10), 
		@BranchCode nchar(10)

set @FlagNoDublicated = 1 
DECLARE ChequeData CURSOR static for  

SELECT chequeType,
	   ChequeNumber,
	   Processed,
	   ProcessError,
	   ClearBankBranchID,
	   DebitAccountNumber,
	   BankCode,
	   BranchCode 
from BulkCheques 
where ref_no=@ref_no 

OPEN ChequeData


IF @@CURSOR_ROWS > 0
BEGIN
 FETCH NEXT FROM ChequeData into @ChequeType ,
								 @ChequeNumber,
								 @Processed,
								 @ProcessError,
								 @ClearBankBranchID,
								 @DebitAccountNumber,
								 @BankCode,
								 @BranchCode
 WHILE @@Fetch_status = 0
 BEGIN
	 IF @ChequeType = 0 or @ChequeType = 3 or @ChequeType = 4 --OnUs ,CPOnUs,CPClearing
		BEGIN
		     --set @ChequeNumberTrim = CONVERT(int, convert(varchar ,@ChequeNumber))
		     set @ChequeNumberTrim = replace(ltrim(replace(@ChequeNumber,'0',' ')),' ','0') --remove 0 in the beginning
		     
			 SELECT @ChequeCount = COUNT(ID) --COUNT(*) 
			 FROM BulkCheques 
			 where ChequeNumber = @ChequeNumber 
			 and ChequeType = @ChequeType 
			 and ref_no!= @ref_no 
			 and ((Processed=0 and ProcessError is NULL) or (Processed=1 and ProcessError=0))
			 
			 if @ChequeCount>=1
				begin
					   set @FlagNoDublicated =0
					   select @ChequeNumberTrim as ChequeNumber
					   break
			    end
			 --else 
				--select  0 as ChequeNumber
		 END
	 Else IF  @ChequeType = 1 --Clearing
		BEGIN
			 --set @ChequeNumberTrim = CONVERT(int, convert(varchar ,@ChequeNumber))
			 set @ChequeNumberTrim = replace(ltrim(replace(@ChequeNumber,'0',' ')),' ','0') --remove 0 in the beginning

			 SELECT @ChequeCount = COUNT(ID) --COUNT(*) 
			 FROM BulkCheques 
			 where ChequeNumber = @ChequeNumber 
			 and ChequeType = @ChequeType 
			 and ref_no!= @ref_no 
			 and ((Processed=0 and ProcessError is NULL) or (Processed=1 and ProcessError=0))
			 and ClearBankBranchID = @ClearBankBranchID
			 and CONVERT(decimal, convert(varchar ,DebitAccountNumber)) = CONVERT(decimal, convert(varchar ,@DebitAccountNumber))
			 --and CONVERT(int, convert(varchar ,ClearBankBranchID)) = CONVERT(int, convert(varchar ,@ClearBankBranchID))
			   				
			 if @ChequeCount>=1  
				begin
					   set @FlagNoDublicated =0
					   select @ChequeNumberTrim as ChequeNumber
					   break
			    end
			 else 
				begin
				 if (@ChequeNumberTrim = (select ChequeNumber 
										  from ClearDetail 										  
										  where ChequeNumber  = CONVERT(decimal, convert(varchar ,@ChequeNumber))
										  and ClearBankBranchID = @ClearBankBranchID
										  and CONVERT(decimal ,DrawerAccNumber)  = CONVERT(decimal, convert(varchar ,@DebitAccountNumber)) 
										  and status not in (7,8,9,12,13)										  
										  --where CONVERT(int,ChequeNumber)  = CONVERT(int, convert(varchar ,@ChequeNumber))
										  --and CONVERT(int,ClearBankBranchID)  = CONVERT(int, convert(varchar ,@ClearBankBranchID))  
										))
					begin
						   set @FlagNoDublicated =0
						   select  @ChequeNumberTrim  as ChequeNumber
						   break
					end
				 --else
					--select 0  as ChequeNumber
				end
		 END
	 Else --PDCOnUs,PDCClearing
		BEGIN
		     --set @ChequeNumberTrim = CONVERT(int, convert(varchar ,@ChequeNumber))
		     set @ChequeNumberTrim = replace(ltrim(replace(@ChequeNumber,'0',' ')),' ','0') --remove 0 in the beginning
		     
			 select @ClearBankName = ClearBankName 
			 from ClearBank 
			 where CONVERT(int,ClearBankCode) = CONVERT(int, convert(varchar ,@BankCode))
			 
			 select @ClearBranchName = ClearBranchCode+' '+ClearBranchName 
			 from ClearBankBranch 
			 where CONVERT(int,ClearBankCode) = CONVERT(int, convert(varchar ,@BankCode))
			 and CONVERT(int,ClearBranchCode)  = CONVERT(int, convert(varchar ,@BranchCode))
		     
			 SELECT @ChequeCount = COUNT(*) 
			 FROM BulkCheques 
			 where ChequeNumber = @ChequeNumber 
			 and ChequeType = @ChequeType 
			 and ref_no!= @ref_no 
			 and ((Processed=0 and ProcessError is NULL) or (Processed=1 and ProcessError=0))
			 and BankCode   = @BankCode
			 and BranchCode = @BranchCode
			 
			 if @ChequeCount>=1
				begin
					   set @FlagNoDublicated =0
					   select @ChequeNumberTrim as ChequeNumber
					   break
			    end
			 else 
			    begin
					if (@ChequeNumberTrim = (select ChequeNumber 
											 from PDCDetail 
											 where ChequeNumber = CONVERT(decimal, convert(varchar ,@ChequeNumber)) 
											 and DraweeBankName = @ClearBankName 
											 and DraweeBranchName = @ClearBranchName 
											 --where CONVERT(int,ChequeNumber) = CONVERT(int, convert(varchar ,@ChequeNumber)) 
											 
											))
					  begin
						   set @FlagNoDublicated =0 
						   select  @ChequeNumberTrim  as ChequeNumber
						   break
					  end
					--else
					--  select 0  as ChequeNumber
				end
				
		 END 

	 FETCH NEXT FROM ChequeData into @ChequeType,
									 @ChequeNumber,
									 @Processed,
									 @ProcessError,
									 @ClearBankBranchID,
									 @DebitAccountNumber,
									 @BankCode,
									 @BranchCode
 END

				
END


CLOSE ChequeData
DEALLOCATE ChequeData
SET NOCOUNT OFF

if  @FlagNoDublicated =1 
select 0 as ChequeNumber
GO

drop_old_proc 'Select_BranchConfig_MoveDet'
GO
CREATE PROCEDURE dbo.Select_BranchConfig_MoveDet -- Select_BranchConfig_MoveDet 1,1,1
@BankID			bankid,  
@RegionID		regionid,  
@BranchID		branchid  
AS  
/*  
ModifiedDate:2018-05-07   
Modifer: Sara Badwy   
ModifyReason: CR[GFSY00700][Cash Company Option]  
*/  
  
set nocount on  
  
select DealBranches , DealCB , DealVendor , isnull(IsCashCentre,0) as IsCashCentre , isnull(CashCentre,0) as CashCentre,isnull(DealCashCompany,0) as DealCashCompany
from BranchConfig 
where Bank=@BankID  
     and  Region=@RegionID  
     and  Branch=@BranchID 
 

GO
drop_old_proc 'dbo.Move_Bulkcheques_data'
GO
Create procedure dbo.Move_Bulkcheques_data --  Move_Bulkcheques_data '001BC00027315','24487679',5,20582,1,'100000084482','BHD','CUR' ,'CK','ITSOFT\asmaa.gamal'                 
@ref_no varchar(25),                    
@ChequeNumber varchar(20),                             
@ChequType int ,                    
@CrRim int = null,                    
@CrRimBranch int = null,                    
@CrAccount nvarchar(36) = null,                    
@CrAccountCur varchar(3) = null,                    
@CrAccountType varchar(5) = null,                    
@CrAppType varchar(5) = null,                    
@Updator nvarchar(40)= null ,    
@BusinessDate datetime,    
@refno nvarchar(20)= null    
                      
as                    
/*                    
                               
 Creator     : Asmaa Gamal        
 Create Date : 26/01/2016                   
 Purpose     : created procedure to move bulk chequs to cleardetail table or PDCDetail   
   
 updator : Asmaa Gamal  
 Date    : 22/11/2016  
 Purpose : insert CustomerReference, ValueDate,AfterCutoffTime,AccountType,AccountCurrency,ClearBankName,Charges,ForUtilityPayment,ForCreditCardPayment,ForStockMarketPayment,FloatWithProfile,ISCertifiedCheque,Routing_No,AccountBranch,GLNumber  in cleardetail table to unable complete cycle . 
 
 updator : Asmaa Gamal  
 Date    : 27/11/2016  
 Purpose : insert CustomerReference,DraweeBankID  ,DraweeBankName ,DraweeBranchName ,DraweeBranchID,SpecialClearing,AmendCount,PrevStatus,Serial,ClearCenter,ShadowDepLoan     in PDCdetail table to unable complete cycle & update value of status in PDCDetail by correct 0 if onus 1 if clearing . 
     
 updator : Mohamed Elabd   
 Date    : 27-May-2018
 Purpose : Get PDCDetailID using procedure Next_Table_MaxID to be compatible with Insert_PDC_Cheque_Data - Issue# GFSX13046
                
 updator : Mohamed Elabd   
 Date    : 03-June-2018
 Purpose : Change ClearCenter from '0' to BulkCheques.ClearingCenter - Issue# GFSX13016
*/                     
       
declare @maxid as bigint                        
exec dbo.Next_Table_MaxID 'PDCDetail','PDCDetailid',@maxid output  
select @maxid
             
IF      (@ChequType = 1)                    
BEGIN                    
 declare @Txn     int   
 declare @BankCode     int   
 declare @ClearBankName  nvarchar(250)                      
                       
 set @Txn = (select LastValue from dbo.TableID with(nolock) where lower(TableName) ='cleardetail' and lower(FieldName)='txnid')                                              
                    
 if(@Txn is null)                                    
 begin                                    
  insert into dbo.TableID with(RowLock) (TableName,FieldName,LastValue) values('cleardetail','txnid',0)                                    
  if(@@error<>0)                                    
  begin                                    
   --Rollback Transaction                                    
   return 0                                    
  end                                    
  set @Txn = 0                                    
 end                                    
                                                   
 set @Txn = @Txn + 1    
                     
        
 INSERT INTO ClearDetail (TxnID,ID,RefNo, AccountNumber,ChequeNumber                    
 ,DrawerAccNumber,ChequeAmount ,Status,ShadowAccountType,CustomerShadowAcc                    
 ,ShadowAccApplicationType,ShadowAccountCurrency,ChequeDate,ClearBankBranchID                    
 ,ClearingCenter,User_Number,Branch,BusinessDate,ChequeTypeStatusID,RIM_No,ValueDate,AfterCutoffTime,AccountType,AccountCurrency,ClearBankName,
 Charges,ForUtilityPayment,ForCreditCardPayment,ForStockMarketPayment,FloatWithProfile,ISCertifiedCheque,Routing_No,AccountBranch,GLNumber,CustomerReference)                     
                    
                    
 SELECT @Txn , (select isnull (max(id),0) + 1 from ClearDetail) ,BulkCheques.ref_no ,BulkCheques.CreditAccountNumber,BulkCheques.ChequeNumber                    
 ,BulkCheques.DebitAccountNumber,BulkCheques.ChequeAmount,1,BulkCheques.ShadowAccountType,BulkCheques.CustomerShadowAcc                    
 ,BulkCheques.ShadowAccApplicationType,BulkCheques.Currency,BulkCheques.ChequeDate,BulkCheques.ClearBankBranchID,BulkCheques.ClearingCenter                    
 ,BulkCheques.UserID,BulkCheques.Branch,BulkCheques.BusinessDate,1,CONVERT(int, BulkCheques.RimNo ) , BulkCheques.ChequeDate,0 ,@CrAccountType,@CrAccountCur   
 ,(select ClearBankName from ClearBank where  CONVERT(int,ClearBankCode)  = CONVERT(int, convert(varchar ,BulkCheques.BankCode)))
 ,0,0,0,0,0,0,
 (select routing_no from ClearBankBranch where  CONVERT(int,ClearBankBranchID)  = CONVERT(int, convert(varchar ,BulkCheques.ClearBankBranchID))),
 @CrRimBranch,
 (select ClearBranchGL from ClearBankBranch where  CONVERT(int,ClearBankBranchID)  = CONVERT(int, convert(varchar ,BulkCheques.ClearBankBranchID))),
 BulkCheques.CustomerReferenceNumber 
 
 from BulkCheques where BulkCheques.chequeType = @ChequType AND BulkCheques.ref_no = @ref_no AND BulkCheques.ChequeNumber = @ChequeNumber --AND BulkCheques.CustomerShadowAcc = @CustomerShadowAcc                     
                    
                    
                    
                    
 update dbo.BulkCheques set Processed = 1 where BulkCheques.chequeType = @ChequType AND BulkCheques.ref_no = @ref_no AND BulkCheques.ChequeNumber = @ChequeNumber --AND BulkCheques.CustomerShadowAcc = @CustomerShadowAcc                     
                       
END                    
ELSE IF (@ChequType = 2)                    
BEGIN 
                 
 INSERT INTO [Globalfs].[dbo].[pdcdetail]                    
           (PDCDetailID,BookingBranch,TrackingNumber,ChequeType,Status      
           ,CreditRim,CreditRimBranch,CreditAccount,CreditAccountCur,CreditAccountType,CreditAppType,CrDepLoan                    
           ,[PDCAccount],[PDCAccountCur],[PDCAccountType],[PDCAppType],[PDCDepLoan]                    
           ,[ChequeNumber],[ChequeCurrency],[ChequeAmount],[ChequeDate],[SendDate]
           ,DrAccount                    
           ,DraweeBankID                             
           ,Developer ,Updator           
           ,ShadowAccount            
           ,ShadowAccountType            
           ,ShadowAccountCur      
           ,BookingUserNumber     
           ,BookingDate     
           ,PDCRef  
           ,AmendCount
           ,PrevStatus 
           ,Serial  
           ,ClearCenter
           ,SpecialClearing 
           ,CustomerReference             
           )                    
                    
 SELECT @maxid, --(select isnull (max(PDCDetailID),0) + 1 from pdcdetail),
   CONVERT(INT,Branch),ref_no,0,0                    
                       
   ,@CrRim,@CrRimBranch,@CrAccount,@CrAccountCur,@CrAccountType,@CrAppType,'DP'                    
   ,BulkCheques.PDCAccount,BulkCheques.PDCAccountCur,BulkCheques.PDCAccountType,'','DP'                     
   ,BulkCheques.ChequeNumber,BulkCheques.Currency,BulkCheques.ChequeAmount,BulkCheques.ChequeDate,BulkCheques.ChequeDate
   ,BulkCheques.DebitAccountNumber--                    
   ,BulkCheques.BankCode                  
   ,@Updator,@Updator,                   
   BulkCheques.PDCShadowAccount,            
   BulkCheques.PDCShadowAccountType,            
   rtrim(ltrim (BulkCheques.PDCShadowAccountCur)),    
   BulkCheques.UserID  ,    
   @BusinessDate  ,    
   @refno,
   0,0,0,
   0,
   0,
   BulkCheques.CustomerReferenceNumber  
               
                       
   from BulkCheques   where BulkCheques.chequeType = @ChequType AND BulkCheques.ref_no = @ref_no AND BulkCheques.ChequeNumber = @ChequeNumber --AND BulkCheques.PDCAccount = @CustomerShadowAcc                     
                     
   update dbo.BulkCheques set Processed = 1 where BulkCheques.chequeType = @ChequType AND BulkCheques.ref_no = @ref_no AND BulkCheques.ChequeNumber = @ChequeNumber --AND BulkCheques.PDCAccount = @CustomerShadowAcc                     
                    
End  
ELSE IF (@ChequType = 5)                    
BEGIN 
                 
 INSERT INTO [Globalfs].[dbo].[pdcdetail]                    
           (PDCDetailID,BookingBranch,TrackingNumber,ChequeType,Status      
           ,CreditRim,CreditRimBranch,CreditAccount,CreditAccountCur,CreditAccountType,CreditAppType,CrDepLoan                    
           ,[PDCAccount],[PDCAccountCur],[PDCAccountType],[PDCAppType],[PDCDepLoan]                    
           ,[ChequeNumber],[ChequeCurrency],[ChequeAmount],[ChequeDate],[SendDate]
           ,DraweeAcctNo                             
           ,Developer ,Updator           
           ,ShadowAccount            
           ,ShadowAccountType            
           ,ShadowAccountCur      
           ,BookingUserNumber     
           ,BookingDate     
           ,PDCRef             
           ,DraweeBankID  
           ,DraweeBankName 
           ,DraweeBranchName 
           ,DraweeBranchID
           ,SpecialClearing 
           ,AmendCount
           ,PrevStatus 
           ,Serial 
           ,ClearCenter  
           ,ShadowDepLoan
           ,CustomerReference      
           )                    
                    
 SELECT @maxid, --(select isnull (max(PDCDetailID),0) + 1 from pdcdetail),
   CONVERT(INT,Branch),ref_no,1,0                    
                       
   ,@CrRim,@CrRimBranch,@CrAccount,@CrAccountCur,@CrAccountType,@CrAppType,'DP'                    
   ,BulkCheques.PDCAccount,BulkCheques.PDCAccountCur,BulkCheques.PDCAccountType,'','DP'                     
   ,BulkCheques.ChequeNumber,BulkCheques.Currency,BulkCheques.ChequeAmount,BulkCheques.ChequeDate,BulkCheques.ChequeDate                                      
   ,BulkCheques.DebitAccountNumber--                                    
   ,@Updator,@Updator,                   
   BulkCheques.PDCShadowAccount,            
   BulkCheques.PDCShadowAccountType,            
   rtrim(ltrim (BulkCheques.PDCShadowAccountCur)),    
   BulkCheques.UserID  ,    
   @BusinessDate  ,    
   @refno ,
   (select ClearBankCode from ClearBank where  CONVERT(int,ClearBankCode)  = CONVERT(int, convert(varchar ,BulkCheques.BankCode)))  ,
   (select ClearBankName from ClearBank where  CONVERT(int,ClearBankCode)  = CONVERT(int, convert(varchar ,BulkCheques.BankCode))),
   (select ClearBranchCode+' '+ClearBranchName from ClearBankBranch where  CONVERT(int,ClearBankCode)  = CONVERT(int, convert(varchar ,BulkCheques.BankCode))and CONVERT(int,ClearBranchCode)  = CONVERT(int, convert(varchar ,BulkCheques.BranchCode))),
   (select ClearBranchCode from ClearBankBranch where  CONVERT(int,ClearBankCode)  = CONVERT(int, convert(varchar ,BulkCheques.BankCode) )and CONVERT(int,ClearBranchCode)  = CONVERT(int, convert(varchar ,BulkCheques.BranchCode))),
   0,0,0,1,
   BulkCheques.ClearingCenter, --0,
   'DP',
   BulkCheques.CustomerReferenceNumber 
               
                       
   from BulkCheques   where BulkCheques.chequeType = @ChequType AND BulkCheques.ref_no = @ref_no AND BulkCheques.ChequeNumber = @ChequeNumber --AND BulkCheques.PDCAccount = @CustomerShadowAcc                     
                     
   update dbo.BulkCheques set Processed = 1 where BulkCheques.chequeType = @ChequType AND BulkCheques.ref_no = @ref_no AND BulkCheques.ChequeNumber = @ChequeNumber --AND BulkCheques.PDCAccount = @CustomerShadowAcc                     
                    
End                  
ELSE IF (@ChequType = 4)                   
BEGIN                     
 update dbo.BulkCheques set Processed = 1   where BulkCheques.chequeType = @ChequType AND BulkCheques.ref_no = @ref_no AND CONVERT(INT, BulkCheques.ChequeNumber) = @ChequeNumber                   
End                    
ELSE IF (@ChequType = 3)                  
BEGIN                     
 update dbo.BulkCheques set Processed = 1 where BulkCheques.chequeType = @ChequType AND BulkCheques.ref_no = @ref_no AND CONVERT(INT, BulkCheques.ChequeNumber) = @ChequeNumber                     
End                                     
ELSE IF (@ChequType = 0)                  
BEGIN                     
 update dbo.BulkCheques set Processed = 1 where BulkCheques.chequeType = @ChequType AND BulkCheques.ref_no = @ref_no AND BulkCheques.ChequeNumber = @ChequeNumber                     
End                   
GO
drop_old_proc Update_bulkcheques_data
go
CREATE procedure dbo.Update_bulkcheques_data --Update_bulkcheques_data 'sddfdf1009999',1056             
              
@ref_no varchar (20) ,  
@Bank int               
              
as              
                
/*                
              
Creator     : Asmaa Gamal      
Create Date : 11/01/2016             
Purpose     : update data which added from PKG .  
  
Updator  : Asmaa Gamal  
Update Date : 22/11/2016  
Purpose  : Fix Issue GFSX11376 .  

Updator  : Rokaia Kadry
Update Date : 07/03/2017  
Purpose  : Fix Issue GFSX11717 for CR#GFSY00614 .  
Change From ISNUMERIC(DraweeRim)=0
	    To ISNUMERIC(DraweeRim)=1
To make the Business Need

Updator  :	  Mohamed Elabd
Update Date : 20-May-2018
Purpose  :	  Remove space in 'bankcode' - Issue# GFSX13016

Updator  :	  Mohamed Elabd
Update Date : 27-May-2018
Purpose  :	  Add DISTINCT to UPDATE BulkCheques - Issue# GFSX13046
*/                
      
declare @BankCode int   
select @BankCode =  id from Banks where Bank=@Bank                
UPDATE                
        BulkCheques                
    SET                
        chequeType =                
        (                
            CASE               
               --Asmaa Gamal               
                WHEN chequeDate > BusinessDate and DraweeRim is not null  AND ISNUMERIC(DraweeRim)=1 /*DraweeRim !='          '*/ 
                and  convert(varchar(5),convert(int,bankcode)) = ( select convert(varchar(5),convert(int,Value)) FROM BankConfig WHERE Name='bankcode' and Bank = @BankCode)--DraweeRim is  not NULL                       
                THEN                
                    3  -- CP On Us Cheque             
                                
                WHEN chequeDate > BusinessDate and DraweeRim is not null  AND ISNUMERIC(DraweeRim)=1 /*DraweeRim !='          '*/ 
                and convert(varchar(5),convert(int,bankcode)) != ( select convert(varchar(5),convert(int,Value)) FROM BankConfig WHERE Name='bankcode' and Bank = @BankCode)--DraweeRim is  not NULL                       
                THEN                
                    4  -- CP Clearing Cheque            
               --Asmaa Gamal              
                            
                WHEN   chequeDate <= BusinessDate and convert(varchar(5),convert(int,bankcode)) = ( select convert(varchar(5),convert(int,Value)) FROM BankConfig WHERE Name='bankcode' and Bank = @BankCode)                 
                THEN                
                    0  --On Us Cheque              
                WHEN  chequeDate <= BusinessDate  and  convert(varchar(5),convert(int,bankcode))!= ( select convert(varchar(5),convert(int,Value)) FROM BankConfig WHERE Name='bankcode' and Bank = @BankCode)                 
                THEN                
                    1 --Clearing Cheque       
                        
                WHEN   chequeDate > BusinessDate and convert(varchar(5),convert(int,bankcode)) = ( select convert(varchar(5),convert(int,Value)) FROM BankConfig WHERE Name='bankcode' and Bank = @BankCode)                 
                THEN                
                    2  --PDC On Us Cheque              
                WHEN  chequeDate > BusinessDate  and  convert(varchar(5),convert(int,bankcode))!= ( select convert(varchar(5),convert(int,Value)) FROM BankConfig WHERE Name='bankcode' and Bank = @BankCode)                 
                THEN                
                    5 --PDC Clearing Cheque             
                          
                 
                                    
            END          
        )                
    WHERE                
        ref_no  = @ref_no                
                        
                  
        /* wait salkawy replay  
        UPDATE BulkCheques SET ChequeCharges = (SELECT dbo.select_charges_fun ('BulkCheques',BulkCheques.ChequeAmount,1,'',''))                
          WHERE                
        ref_no  = @ref_no */               
                        
                        
        UPDATE BulkCheques SET Currency = (SELECT DefaultCurrency  FROM Bank where Bank = @Bank)                
          WHERE                
        ref_no  = @ref_no                
                        
         
  UPDATE BulkCheques SET ClearBankBranchID = (SELECT  ClearBankBranchID                 
  FROM ClearBankBranch                 
  where CONVERT(int,ClearBankCode)  = CONVERT(int, convert(varchar ,BankCode) )               
  and   CONVERT(int,ClearBranchCode)  = CONVERT(int,convert(varchar ,BranchCode)))                
  where      ref_no  = @ref_no and chequetype in(1,2,4,5)                
                 
                 
   UPDATE BulkCheques SET clearingcenter  =                
   (SELECT DISTINCT ClearingConfig.ClearingCenter from ClearingConfig where ClearingConfig.ToClearAreaCode = (select ClearAreaCode from ClearBankBranch where ClearBankBranchID= BulkCheques.ClearBankBranchID  )               
   AND ClearingConfig.Branch =( SELECT Value FROM BankConfig WHERE Name='HeadOffice' and  Bank =@BankCode)                
   and ClearingConfig.ModeOfOperation =(SELECT Value FROM BankConfig WHERE Name='ClearingModeofoperation' and  Bank =@BankCode))                
    where      ref_no  = @ref_no and chequetype in(1,4,5) --chequetype in(1,2,4,5)   
    
    UPDATE BulkCheques SET ClearingCenter = 0
    WHERE ref_no = @ref_no AND chequeType = 2
go  
 drop_old_proc 'Get_ALL_CorporateCOs_REF'
 GO
CREATE  Proc [dbo].Get_ALL_CorporateCOs_REF  
 -- exec Get_ALL_CorporateCOs_REF '001CC00003712'  
 @RefernceNumber nvarchar(50)  
as          
/*          
 Developer:  MOHAMED bARAKAT    
 return  :  Get All Account Number By Refernce Number    
 
 Developer:  Rokaia KAdry   
 return  :  Get All Account Type By Refernce Number    
 Issue:GFSX13022 27-05-2018  
*/        
  
 select DebitAccount ,DebitAccountType 
 from CorporateCOs  
 where ReferenceNumber = @RefernceNumber  

GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc GET_corporateCOs_ANDCHARGES
Go

Create	Proc dbo.GET_corporateCOs_ANDCHARGES 
		
		@ReferenceNumber varchar(20),
		@status int =0,
		@FromCO char(15)= null,
		@ToCO Char(15) =null
		
AS
/*
	Developer : Mostafa Essam
	Created   : 27-07-2010


	ModifiedDate:	
	Modifer:		
	ModifyReason:	
 
  Developer:  Rokaia KAdry   
  return  :  Get All Account Type By Refernce Number  
  Issue:GFSX13022 27-05-2018  
	

*/
set	nocount on

select 
serial			as		TLR_CHEQUE_BOOK_ID_ARRAY ,
DebitAccount	as 		TLR_ACCOUNTS ,
CONumber		as		TLR_CHEQUE_NUMBER_ARRAY2,
ChargeAmount			as		TLR_IR_DrCommission_Array,
COAmount		as		TLR_IR_DrAmount_Array,
BeneficiaryName	as		TLR_CustomerName_ARRAY ,
user1ID , 
CASE user2signature
  WHEN 1 THEN user2ID  ELSE Null  end as user2ID   ,   
DebitAccountType   as   TLR_CHEQUE_BOOK_TYPE_ARRAY   
 from  CorporateCOs  
	where
		 ReferenceNumber=@ReferenceNumber
and status =@status


and ((@FromCO is null or @ToCO is null  ) or cast (conumber as int)  between cast (@FromCO as int) and  cast (@ToCO as int ))


Go
--End of Automatic Generation

drop_old_proc LogonIntranetOperator
go
CREATE PROC LogonIntranetOperator @LoginID OperatorID, -- e.g. DomainA\SomeUser          
  @WorkStation MachineName, -- e.g. DomainA\SomeMachine          
  @Role RoleName, -- e.g. GFSOperators (here, 'role' really implies 'application')          
  @ChannelID int,          
  @SecondaryLogonPassword varchar(50) = NULL, -- encrypted or hashed secondary logon Password          
  @SecondaryLogonPasswordNew varchar(50) = NULL -- new secondary (encrypted or hashed) logon Password          
, @now datetime = NULL          
 AS           
-- Purpose: Performs (database) steps required to log an operator on to a          
--    Globalfs.Net intranet application.          
--          
-- Note: This procedure is invoked with @Role =  'GFSOperators' when           
--       the container application (e.g. Globalfs.Exe) call the           
--       IntranetPrincipalIdentity's LogOn() method.   This occurs just after          
--       startup and before any applications (e.g. Teller) are loaded.            
--          
-- Prevent teller logon if currently being processed as an 'absent teller' by another operator.          
-- Copyright 2003,2004,2005,2006,2007,2008 Getronics USA Inc.  All rights reserved.          
-- May 1, 2003 - Bill Davidson          
-- 12Jul04 Bill D. - Added support for (optional) secondary logon          
-- 01Mar05 John - Allow Workstations to be the computer name or the domain\workstation          
-- 30Mar05 Bodhi - Allow LoginID to be user-number, simple account or domain\account name.          
-- 12OCT06 Bodhi - Forbid sign-on in 'GFSOperators' role if operator is active as teller in another branch.          
--        - Stop relying on XACT_ABORT to rollback.  Optimize for speed.           
--        - Fix bug of allowing log-in when another user is working as this one in absentee mode.          
-- 16Nov06 Bodhi - Use test_as_absentee for the "supervisor working as". Eliminate unused variables.          
-- 19Dec06 Gilberto - Added Update/Insert into OperatorStatus as required           
--     - Modifed the call to test_as_absentee to add BRB values.          
--     - Updated column search to match new design          
--     - Removed check for Open Day, (commented)          
-- 27Mar07 - Fix bug of allowing log-in when already on another workstation.          
-- 03AUG07 Bodhi - Reject logons when the user has an Open-Day in a different branch. This was formerly done in GetAllOperatorInfo.          
-- 25OCT07 Bodhi - Allow customizable error messages for some errors.          
-- 03JAN08 Bodhi - Error 518 is now optional.          
-- 04FEB08 Bodhi - Test for error of active drawer with no totals, here instead of in GetAllTellerInfo.          
-- 15MAY08 Juan Hdz - Changed to use new Workstations table (instead of workstation) CR15845          
--         Bodhi - simplified the workstation lookup for performance.          
--  30Jul08 TimG - Replaced RowStatus check with dbo.isRowActive().          
--  26Jun11 Mfarouk - comment call to func 'verify_active_user_drawers' that checks the case that if cash drawer is active, it should have a row in totals_2 table      
-- 16Aug11 OOrabi - Verify that the Operator branch is the same as the workstation branch    
-- 21oct12 AHelmy - Check TellerBranchOperation property to insert LastBusinessDate and Isopenday with operator status insertion.   
-- 4 Aug.2014 mostafa Essam - change the condition @SecondaryPasswordExpired = 1 and @SecondaryLogonPasswordNew is null and  @SecondaryLogonPassword is not null 
-- 04Jun6 Rokaia Kadry - ISSUE.GFSX12166 - BBK_ASSR_Transaction Posting with XAPI Error Issue   Add Error 52073
-- 03-October-2017 Mohamed Elabd - Add validation "Application is already opened on this workstaion" - Issue# GFSX12523    
--osama nabil 6-6-2018 rollback defect# GFSX12523
set nocount on          
set XACT_ABORT ON          
declare @bank BankID, @region RegionID, @branch BranchID          
 , @other_br internal_branch#   -- for error messages          
declare @WSbank bankID, @WSregion regionID, @WSbranch branchID, @BrID internal_branch#           
declare @bankPrev bankID, @regionPrev regionID, @branchPrev branchID --, @BrIDPrev internal_branch#           
declare @Other_WorkStation MachineName -- For error Message.          
declare @isTellerRole bit, @row_status int, @current varchar(10)          
declare @err int, @rowCount int -- we will count the # of rows the update made, if 0 throw error if first logon time.          
declare @user_number internal_user_ID          
declare @ExistingSecondaryPassword varchar(50)          
declare @SecondaryPasswordExpired bit          
declare @domain as nvarchar(60)          
declare @WScomputer as nvarchar(100)          
declare @branch_name string_30, @start_date datetime, @expired datetime, @now_string varchar(30)          
if @now is null set @now = dbo.now()          
          
if patindex('%\%', @Workstation) > 0 begin          
 set @domain = substring(@Workstation, 1, patindex('%\%', @Workstation)-1)          
 set @WScomputer = substring(@Workstation, patindex('%\%', @Workstation)+1, len(@Workstation))          
end else begin          
 set @WScomputer = @Workstation          
end          
-- Is the workstation is in the Workstation table?          
select @brID = BrID          
from dbo.Workstations           
where (Workstation = @WScomputer)          
  AND ExpirationDate > @now and EffectiveDate < @Now          
if @@rowcount = 0 Begin          
 raiserror(52771, 16, 1,@workstation)          
 return -52771          
End          
          
select @WSbank = Bank, @WSregion = Region, @WSbranch = Branch, @branch_name = Name          
, @start_date = EffectiveDate, @expired = ExpirationDate          
from dbo.Branch_Static          
where BrID = @brID           
if (@@rowcount = 0) or @expired < @now or @start_date > @now Begin          
 set @now_string = convert(varchar(30), @now, 120)          
 raiserror('Branch %s = %d is not active/valid at time %s'          
 , 15, 1, @branch_name, @WSBranch, @now_string)          
 return -15          
End          
           
-- IS the Operator is in the Operators table?          
set @user_number = dbo.f_user_number_of_LoginID(@LoginID)          
if @user_number is null begin          
 raiserror(52071, 16, 1, @LoginID) -- not a valid operator          
 return -52071          
end          
          
-- Check if this is an application-specific logon (e.g. Teller).          
if @Role != 'GFSOperators' begin           
 -- ** CR14357 ** S          
 select @isTellerRole = RequiresTellerRow          
 from dbo.MTSRole           
 where RoleName = @Role          
 if @isTellerRole is null begin          
  RAISERROR('Invalid role name "%s"', 16,1,@Role)          
  RETURN -16          
 end          
 -- Check to make sure container app has already logged on.          
 if not exists (select 1          
             from dbo.OperatorStatus as O           
             JOIN dbo.OperatorSession As S           
               on S.user_number = O.user_number          
       and O.user_number = @user_number          
              and O.SignedOnAt = @WScomputer and S.Role = 'GFSOperators'           
     and S.ChannelID = @ChannelID and S.DeliveryType = 'NET')          
 begin          
  raiserror('Could not perform the requested Globalfs.Net application logon: LoginID: "%s",  Workstation: "%s", Role:  "%s".   REASON:           
Globalfs.Net main container logon has not yet occurred ',           
   16, 1, @LoginID, @Workstation, @Role)          
  return @@error          
 end          
          
 if @isTellerRole = 1 begin           
 -- ** CR14357 ** E          
 -- Perform Teller-specific logon operations.          
  select @row_status = RowStatus from dbo.Operator          
  where User_Number = @User_Number          
  if @row_status is null or @row_status <> 1 begin          
   raiserror('Logon of "%s" for role "%s" failed.  User has expired status.'          
    ,14,1, @LoginID, @Role)          
   return -16          
  end          
  -- Prevent logon if this user is currently being processed as an 'absent teller' by another operator/supervisor               
  exec @err = dbo.test_as_absentee @user_number, @WSBank, @WSRegion, @WSBranch          
  if @err <> 0 return @err          
  declare @msg nvarchar(200)          
  /*set @msg = dbo.verify_active_user_drawers(@brID, @user_number)          
  if @msg > '' begin          
   raiserror(@msg, 16, 1) -- Must be level 16, a developer error. This should never happen.    
   return -16          
  end    */      
  if not exists (select 1 from dbo.RulesEnvironment with (nolock)           
     where value_name = 'Allow concurrent open day in more than one branch'          
       and value = '1')          
  begin          
   -- Do NOT allow teller to log on in different brb when "open day" in another.          
   select @bankPrev = bank, @regionPrev = region, @branchPrev = branch          
   from dbo.CashDrawer           
   where AssignedToTeller = @user_number          
     AND isActive = 1          
     and NOT (Bank = @WSbank and Region = @WSregion and Branch = @WSbranch)          
          
   if @@rowcount > 0 begin          
    exec dbo.raise_logon_brb_msg 52518, @LoginID, @bankPrev, @regionPrev, @branchPrev          
    return -52518          
   end          
  end        
     -- Update Teller's last Bank, last Region, last Branch Info          
  BEGIN TRAN          
  -- We update the record, because he was logged as an Operator, previously          
  Update dbo.OperatorStatus          
  set Last_Branch_Sign_On_Time = @now,          
  SignedOnAt = @WScomputer, LastChanged = @now          
  where BrID = @BrID and User_Number =@user_number          
          
  select @rowCount = @@rowcount, @err= @@error          
          
  if(@rowCount =0 or @err != 0) begin -- throw ERROR          
   raiserror('could not update OperatorStatus table to set Last_Branch_Sign_on_time for %s'           
     ,16, 1, @LoginID)          
    if @@trancount > 0 ROLLBACK TRAN          
    return @err          
  end          
 end          
 else          
  BEGIN TRAN          
end          
else begin          
-- GFSOperators          
-- This is a logon request from the main container application (e.g. Globalfs.Exe)          
 -- IS the Operator current in the Operators table?          
 select @current = convert(varchar(10),ExpirationDate,120)          
 from dbo.Operator           
 where user_number = @user_number           
      -- ** CR17002 ** S          
   and dbo.isRowActive(RowStatus, Created, ExpirationDate, getdate()) <> 1          
      -- ** CR17002 ** E          
 if @@rowcount > 0 begin          
  raiserror(52072, 16, 1, @LoginID, @current)          
  return -52072          
 end          

-- Rokaia Kadry BEGIN- ISSUE.GFSX12166 - BBK_ASSR_Transaction Posting with XAPI Error Issue   
-- --GFSOperators            
-- --This is a logon request from the main container application (e.g. Globalfs.Exe)            
---- -- IS the Employee ID in  ad_gb_rsm is Status Active          
declare @IsActive varchar(25)     
 select   @IsActive=  rsm.status       
 from dbo.Operator   left OUTER JOIN ad_gb_rsm rsm    
    ON rsm.employee_id=Operator.EmployeeID                  
 where user_number = @user_number and Status <> 'Active'          
       
 if @@rowcount > 0 begin            
  raiserror(52073, 16, 1, @LoginID)            
  return -52073            
 end    
 -- Rokaia Kadry END- ISSUE.GFSX12166 - BBK_ASSR_Transaction Posting with XAPI Error Issue   
       
    -- **** BEGIN ITS-SPECIFIC - Allow operator logon on to his/her assigned branch only ******      
      
      -- Check to see if this is operator's bank, region, branch (this should be set as an Operator table constraint)      
  DECLARE @OpBrID internal_branch#       
  SELECT @OpBrID = BrID FROM Operator where User_Number = @user_number      
      IF (@OpBrID is null)       
      -- @bank = bank, @region = region, @branch = branch from Operator where User_Number = @User_Number      
      -- if @bank is null OR @region is null OR @branch is null      
  begin      
      
        --rollback tran      
      
   raiserror('The BrID for user "%s" has not been configured (is null) in the Operator table.  Please contact your system administrator.',       
      
      16, 1, @LoginID)      
      
        return -52776      
      
      end      
      
       
      
      -- Confirm that the operator is attempting to logon to his/her own branch      
      
      declare @wbank bankID, @wregion regionID, @wbranch branchID -- for error messages      
      
      --select @wbank = bank, @wregion = region, @wbranch = branch from WorkStation where WorkStation = @WorkStation      
      
      if (@BrID <> @OpBrID) -- Workstaion branch is not the same as Operator's BrID      
      
      begin      
      
       -- rollback tran      
      
       raiserror(52776, 16, 1,@LoginID,@WSbank, @WSregion, @WSbranch)      
      
        return -52776      
      
      
      end      
     -- Mostafa Barbary -Zenith CR #8628  01/01/2012[Start]      
     --Confirm That The Workstation is attempting to logon by The Assigned [LinkTo] Operator       
  declare  @Temp MachineName  , @Compare MachineName, @error varchar (100)      
        
     select @Compare = workstation  from Operator where user_number = @user_number     
         
    if @Compare is not null    
    begin    
  select @Temp  = OPP.Workstation from Operator OPP inner join Workstations WS on OPP.BrID = WS.BrID and OPP.Workstation = @WScomputer      
  where OPP.user_number = @user_number     
         
  if @Temp is null    
    begin    
     Set @error = 'Login User Not Matched with This Workstation for GFS'      
      RAISERROR(@error, 16,1)      
       return  -52799     
    end    
    end    
    
      
       -- Mostafa Barbary -Zenith CR #8628 01/01/2012[End]      
-- **** END ITS-SPECIFIC ******      
         -- Determine if the user is already logged on; OK if same Workstation,  error otherwise.          
 select @other_br = O.BrID, @bank = O.Bank, @region = O.Region, @branch = O.Branch,          
  @Other_Workstation = O.SignedOnAt          
 from dbo.OperatorStatus as O          
 JOIN dbo.OperatorSession As S -- and has a session already          
 on S.user_number = O.user_number           
  and O.user_number = @user_number           
  and O.SignedOnAt > ''          
  and O.SignedOnAt <> @WScomputer          
        
 if @Other_WorkStation  > '' begin          
  exec dbo.raise_logon_wkstn_brb_msg 52714, @LoginID,          
   @Other_WorkStation, @bank, @region, @branch          
         return -52714          
 end          

--osama nabil rollback defect# GFSX12523

-- Mohamed Elabd [Start: 03-October-2017 - Issue# GFSX12523]     
--DECLARE @num int    
--SELECT @num = count(*)     
--FROM Operator_Status     
--WHERE SignedOnAt = @WScomputer    
--AND user_number <> @user_number
  
--IF (@num > 0)    
--begin    
--    -- XXIERR: 71, Application is already opened on this workstaion. XXIERR_END    
-- raiserror(52777, 12,1)      
--    return -52777       
--end    
-- Mohamed Elabd [End: 03-October-2017 - Issue# GFSX12523]             
--osama nabil rollback defect# GFSX12523

 -- Prepare a new logon session ...           
          
 -- Authenticate against secondary login credentials (if necessary)          
 --   1) Get existing credentials in Operator table           
 select @ExistingSecondaryPassword = SecondaryLogonPwOneWayHash, @SecondaryPasswordExpired = SecondaryLogonPwHasExpired          
 from dbo.Operator where user_number = @user_number          
          
 --   2) Compare to supplied credentials; if mismatch, abort and raise an error          
 if  not (          
  (@ExistingSecondaryPassword is null and @SecondaryLogonPassword is null)           
  OR           
  ( @ExistingSecondaryPassword is not null           
   AND @SecondaryLogonPassword is not null           
   AND @SecondaryLogonPassword = @ExistingSecondaryPassword)          
  )          
 begin          
         raiserror(52774, 12, 1, @LoginID)          
         return -52774          
 end          
 --   3) Has the Password expired?          
else if @SecondaryPasswordExpired = 1 and @SecondaryLogonPasswordNew is null and  @SecondaryLogonPassword is not null                 
 begin          
         raiserror(52775, 12, 1, @LoginID)          
         return -52775          
 end          
 --   4) Raise error if user is being used as an absentee.          
 exec @err = dbo.test_as_absentee @user_number, @WSBank, @WSRegion, @WSBranch          
 if @err <> 0 return @err          
 --   5) Update with the new Password (if provided)          
 BEGIN TRAN          
 if @SecondaryLogonPasswordNew is not null begin          
  update dbo.Operator           
   set SecondaryLogonPwOneWayHash = @SecondaryLogonPasswordNew,          
   SecondaryLogonPwHasExpired = 0 -- reset Password 'expired' Status          
   where user_number = @user_number          
  set @err = @@error           
  if @err <> 0 begin          
   if @@trancount > 0 ROLLBACK TRAN          
   raiserror('Failure on updating the secondary login password in database for user "%s".',           
    16, 1, @LoginID)          
   return @err          
  end          
 end          
 -- Perform a LogOff to handle clean-up.  Clear OperatorSession, SignedOnAt and WorkingAs          
 exec @err = dbo.LogoffIntranetOperator @LoginID, 'GFSOperators', @user_number, @brID          
 if @@error <> 0 or @err <> 0 begin          
     if @@trancount > 0 rollback tran          
  return @err          
 end          
 -- Update the Operator table with value's from the workstation's Bank, Region, Branch.          
 -- Insert the row if it doesnt exists otherwise update values.          
          
 Update dbo.OperatorStatus          
 set Last_Branch_Sign_On_Time = @now, SignedOnAt = @WScomputer, LastChanged = @now          
 where Brid = @brID and User_Number = @user_number          
 if (@@rowcount =0) begin -- no elements where updated, means we need a new Row  
      -- Start Ahmed Helmy GFSX01214- Check TellerBranchOperation property to insert LastBusinessDate and Isopenday with operator status insertion.    
  
   DECLARE @TellerBranchOperation nvarchar(1)     
   exec dbo.Get_BankConfigProperty @wsBank, 'TellerBranchOperation',@TellerBranchOperation out      
   if (@TellerBranchOperation=1)  
   begin  
      insert dbo.OperatorStatus           
      (User_Number, SignedOnAt, Bank, Region, Branch,Last_Branch_Sign_On_Time, LastChanged, brID)          
  values (@User_Number, @WScomputer, @wsBank, @wsRegion, @wsBranch, @now, @now, @brID)          
   END  
   ELSE  
   BEGIN  
     declare @BusinessDate Datetime  
     declare @IsOpenBranch bit  
     select @BusinessDate=CurrentBusinessDate, @IsOpenBranch=IsOpenBranch from BranchConfig   
     where Bank=@wsBank and Region=@wsRegion and Branch=@wsBranch  
       
  insert dbo.OperatorStatus           
      (User_Number, SignedOnAt, Bank, Region, Branch,Last_Branch_Sign_On_Time, LastChanged, brID, LastBusinessDate, IsOpenDay)          
  values (@User_Number, @WScomputer, @wsBank, @wsRegion, @wsBranch, @now, @now, @brID, CONVERT(varchar,@BusinessDate,112),@IsOpenBranch)  
   END   
   -- END ahmed helmy GFSX01214        
 end -- no elements where updated, means we need new Row          
 set @err = @@error           
          
 if @err <> 0 begin          
  raiserror('Cannot update OperatorStatus table for "%s", "%s"',           
   16, 1, @LoginID, @Workstation)          
  if @@trancount > 0 ROLLBACK TRAN          
 return @err          
 end          
end          
          
-- The following code is executed for all valid roles.          
-- Update the OperatorSession with the new information.          
insert dbo.OperatorSession (user_number, Role, DeliveryType, ChannelID, LastChanged)          
       values (@user_number, @Role, 'NET', @ChannelID, @now)          
set @err = @@error           
if @err <> 0 begin          
    raiserror('Cannot insert into dbo.OperatorSession table for "%s", "%s"'          
    , 16, 1, @LoginID, @Role)          
 if @@trancount > 0 ROLLBACK TRAN          
    return @err          
end          
          
-- Everything seems OK, commit transaction.          
COMMIT TRAN          
return 0 
go
grant execute on LogonIntranetOperator to TranProgram
go


DROP_OLD_PROC 'Retrieve_Stock_serial'
GO
CREATE  PROCEDURE dbo.Retrieve_Stock_serial-- 'CO',-1,7,4,666,0        
  @StockCode as varchar(20),              
  @InventoryID as int,            
  @Quantity as int,            
  @UserBranch as BranchID, -- Current Branch            
  @UserNumber as internal_User_id,            
  @isVault as bit        
          
AS            
/*            
CreationDate: 2010-10-7            
OriginalName: dbo.Retrieve_Stock_serial            
Programmer:  Mohamed Barakat      
Description:             
Output:               
Assumption:      
       
	Modifier     : Rokaia Kadry 
	Modified     : 2018-06-14
 	reason	     : Issue#GFSX13069
 	Description	 : Comment Codition  ->  s.InventoryID is null       when inventoryid is -1
 	
*/            
        
            
            
if(@InventoryID = -1) Set @InventoryID = null            
     
set rowcount @Quantity          
begin        
 if( @InventoryID is not null)            
 begin            
  if(@isVault = 0)            
  begin            
           
            
   select s.Serial  from dbo.Stock s  inner join dbo.StockMovement  as sm  on s.lastid  = sm.id            
   where s.StockCode = @StockCode            
   and s.InventoryID = @InventoryID            
   and sm.movementtypeid = 2            
   and sm.isvault  = @isVault            
   and sm.User_Branch = @UserBranch            
   and isVault = 0             
   and  user_number = @UserNumber            
   order by sm.created,  s.serial            
  end            
  else            
  begin            
        
          
   select s.Serial  from dbo.Stock s inner join dbo.StockMovement  as sm  on s.lastid  = sm.id            
   where s.StockCode = @StockCode            
   and s.InventoryID = @InventoryID            
   and sm.movementtypeid = 2            
   AND  isVault = 1            
   AND sm.User_Branch = @UserBranch            
   --AND user_number = @UserNumber            
   order by sm.created,  s.serial            
  end            
 end            
 else            
 begin             
            
        
  select s.Serial  from dbo.Stock s  inner join dbo.StockMovement  as sm  on s.lastid  = sm.id            
  where s.StockCode = @StockCode            
  --and s.InventoryID is null            
  and sm.movementtypeid = 2            
  and sm.isvault  = @isVault            
  and sm.User_Branch = @UserBranch            
  and ( ( @isVault = 0 AND isVault = 0 AND User_number = @UserNumber  ) OR ( @isVault = 1 AND isVault = 1  ) )            
  order by sm.created,  s.serial            
 end            
end 
GO
drop_old_proc 'selSentCashRefNo'
go
CREATE PROCEDURE dbo.selSentCashRefNo		--exec dbo.selSentCashRefNo 1,4,'17',0,11 
     @CurBranch    BranchID, -- Current Branch ID                      
     @ToID        int,  -- 1 Branch(3)     or User(1)                     
     @ToCode    varchar(20), -- 269 CurrentBranchID  or UserNumber                      
     @CB        bit = 0,   --0         
     @CashDrawerNumber  CashDrawerNumber  = null -- cd number    
AS     
/* Version : 2.00.0046.2103 , Date : 2016/09/06 */                 
/*                      
 Creation Date     : 21 Oct 2004                      
 Original Name     : dbo.selSentCashRefNo                      
 Programmer     : Mohammed Mustafa                       
 Description     : gets RefNo of all sent transaction to @CurrentBranch                      
 Output      : All Reference Number of Sent Cash                      
 Assumption     : Run on main Branch Database                      
                 All Operators are stored in main Branch Database                      
                                   
 ModifiedDate : 15 Mar 2005                    
 Modifer      :    Mohammed Mustafa                       
 ModifyReason :    Added UserName Column                    
                    
 ModifiedDate : 14 May 2006                    
 Modifer      :    Mohammed Mustafa                       
 ModifyReason :    Added ToID = 0 (Central Bank) for Central Bank Receive                    
        Change made In Arbift for new transaction Central Cash Movement Receive                    
                
ModifiedDate : 14 January 2008                    
 Modifer      :    Hany A. Hassan                
 ModifyReason :    Added ToID = 9 (Lead Teller) For using New configurations                    
              
Modified date:05/05/2008            
Modifer: Mostafa Elbarbary            
Resaon:To impove Sp code performance                   
            
            
Modified date:19/05/2008            
Modifer: Hany A Hassan            
Resaon:To add cashdrawer number in selection criteria      
    
Modified date:29/05/2008            
Modifer: Hany A Hassan            
Resaon:To get leadteller's vault     
    
Modified date:2010-04-29    
Modifer   : Hassan E. Halim          
Resaon   : in teller to teller movement there will be restriction such that;     
    the sender drawer type = the reciever drawer type.    
    
Modified date: 2010-05-04    
Modifer   : Osama Orabi    
Resaon   : Performance Enhanement    
    
     
 ModifiedDate : 2011-06 - 22     
 Modifer   : Mohammed El-Masry     
 ModifyReason : Change Column LinkedServer from Branch.LinkedServer into BranchConfig.LinkedServer  
   
 ModifiedDate : 2013-04-02  
 Modifer   : Mohammed Farouk  
 ModifyReason : CBD CR  GFSY00210, Cash movement rejection  
   
 ModifiedDate : 2014-07-07  
 Modifer   : Amr Salah El-din  
 ModifyReason : Solve defect #GFSX07416, retirn ToFromCode column  
  
  
 ModifiedDate : 2014-08-03  
 Modifer   : Lamiaa Mostafa  
 ModifyReason : select MovementType to check rejected movements - GFSX07495  
 
 ModifiedDate 	: 2014-09-06  
 Modifer   		: Mahmoud Kamel
 ModifyReason 	: Issue#GFSX11029 - Performance Issue
 
 ModifiedDate 	: 19-December-2016  
 Modifer   		: Mohamed Elabd
 ModifyReason 	: Issue# GFSX11493 - Add where condition AssignedToTeller�=�@ToCode
 
 ModifiedDate 	: 06-06-2018  
 Modifer   		: Osama Nabil
 ModifyReason 	: Issue# GFSX13055 - 
 
*/                      
                    
set nocount on                    

--ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
create table #TempCashMovement
(
[RefNo] nvarchar(20) NOT NULL,
[LastID] [int] NOT NULL
)

insert into #TempCashMovement
select cshMve2.RefNo, max(cshMve2.id)
from CashMovement (NOLOCK) cshMve2    
group by cshMve2.RefNo

--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue

if(@ToID = 0) -- CentralBank                      
begin                      
 select  cm1.RefNo,                      
    cm1.currency,                      
    cm1.amount,                      
    cm1.FromSeal,                      
    cm1.ToSeal,                      
    cm1.CashSealMsgrCode,                      
    cm1.User_Branch, -- Sender Branch                       
    cm1.User_Number,                    
    cm1.isVault,                      
    cm1.date_time,                      
    op.LoginID as UserName,  
 cm1.ToFromCode,    
 cm1.MovementType                    
    from  dbo.CashMovement as cm1                    
    INNER join dbo.Operator op                    
    on   op.user_number = cm1.User_number  
	--ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
	/*
    Where  cm1.id in( select max(cshMve2.id) as LastID     
       from dbo.CashMovement cshMve2    
       WHERE cshMve2.RefNo = cm1.RefNo    
       group by cshMve2.RefNo)
	*/
	Where  cm1.id in (select LastID     
       from #TempCashMovement (NOLOCK) cshMve2    
       WHERE cshMve2.RefNo = cm1.RefNo)    
	--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
    AND   cm1.Movementtype in( 1,10) -- send , rejected                     
    AND   cm1.ToFromID  = 0 -- CentralBank(0)                      
    AND   cm1.User_Branch  = @CurBranch -- Central Bank Receive From the Same Branch                    
end    
Else if(@ToID = 4) -- To Vault                      
begin
	
    select  cm1.RefNo,                      
    cm1.currency,                      
    cm1.amount,                      
    cm1.FromSeal,      
    cm1.ToSeal,                      
    cm1.CashSealMsgrCode,                      
    cm1.User_Branch, -- Sender Branch                       
    cm1.User_Number,                    
    cm1.isVault,                      
    cm1.date_time,                      
    op.LoginID as UserName ,            
    cm1.CashDrawerNumber,  
 cm1.ToFromCode,  
 cm1.MovementType                          
    from  dbo.CashMovement as cm1                    
    inner join  dbo.Operator op                    
    on   op.user_number = cm1.User_number            
    inner join  dbo.CashDrawer cd           
    ON   (cd.AssignedToTeller = cm1.User_Number     
    and   cm1.CashDrawerNumber =  cd.cashdrawerNumber     
    and   cd.Branch = cm1.User_Branch )           
    and   cd.AttachedToVault = @CashDrawerNumber            
    --ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
	/*
    Where  cm1.id in( select max(cshMve2.id) as LastID     
       from CashMovement cshMve2    
       WHERE cshMve2.RefNo = cm1.RefNo    
       group by cshMve2.RefNo)
	*/
	Where  cm1.id in (select LastID     
       from #TempCashMovement (NOLOCK) cshMve2    
       WHERE cshMve2.RefNo = cm1.RefNo)    
	--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
    and   cm1.Movementtype in( 1,10) -- send , rejected  
    and   cm1.ToFromID  = 4 -- Vault(4)                      
    and   cm1.User_Branch  = @CurBranch -- TELLER sent to his BRANCH VAULT            
end                      
else if(@ToID =  3) -- To Branch                    
Begin                    
    if(@CB = 0) -- From Branch / HO                    
    Begin                    
        select  cm1.RefNo,                      
		 cm1.currency,                      
		 cm1.amount,                      
		 cm1.FromSeal,                      
		 cm1.ToSeal,                      
		 cm1.CashSealMsgrCode,                 
		 cm1.User_Branch, -- Sender Branch                       
		 cm1.User_Number,                    
		 cm1.isVault,                      
		 cm1.date_time,                
		 op.LoginID as UserName,  
		 cm1.ToFromCode,  
		 cm1.MovementType                        
		from  dbo.CashMovement as cm1                    
		inner join  dbo.Operator op    
		on   op.user_number = cm1.User_number                    
		--ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
		/*
		Where  cm1.id in( select max(cshMve2.id) as LastID     
		   from CashMovement cshMve2    
		   WHERE cshMve2.RefNo = cm1.RefNo    
		   group by cshMve2.RefNo)
		*/
		Where  cm1.id in (select LastID     
		   from #TempCashMovement (NOLOCK) cshMve2    
		   WHERE cshMve2.RefNo = cm1.RefNo)    
		--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
        and   cm1.Movementtype in( 1,10) -- send , rejected  
        and   cm1.ToFromID    = @ToID -- Teller(1),Branch(3)                      
        and   cm1.ToFromCode  = @ToCode -- CurrentBranchID                      
        and   cm1.User_Branch =@CurBranch    
    end    
    else-- (@CB <> 0)From CentralBank                    
    Begin                    
        select  cm1.RefNo,                      
		 cm1.currency,                      
		 cm1.amount,                      
		 cm1.FromSeal,                      
		 cm1.ToSeal,                      
		 cm1.CashSealMsgrCode,                      
		 cm1.User_Branch, -- Sender Branch                       
		 cm1.User_Number,                    
		 cm1.isVault,                      
		 cm1.date_time,                     
		 op.LoginID as UserName   ,  
		 cm1.ToFromCode,  
		 cm1.MovementType                     
        from  dbo.CashMovement as cm1                    
        inner join  dbo.Operator op                    
        on   op.user_number = cm1.User_number                    
        --ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
		/*
		Where  cm1.id in( select max(cshMve2.id) as LastID     
		   from CashMovement cshMve2    
		   WHERE cshMve2.RefNo = cm1.RefNo    
		   group by cshMve2.RefNo)
		*/
		Where  cm1.id in (select LastID     
		   from #TempCashMovement (NOLOCK) cshMve2    
		   WHERE cshMve2.RefNo = cm1.RefNo)    
		--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
        and   cm1.Movementtype   in( 1,10) -- send , rejected          
		and   cm1.User_Branch    = 0                    
        and   cm1.ToFromID    = @ToID -- Teller(1),Branch(3)                      
        and   cm1.ToFromCode    = @ToCode -- CurrentBranchID                    
    End                    
End                    
Else if(@ToID =  1) -- to Teller    
begin                      
    declare @ReceiverVault int,    
   @ReceiverDrawerType varchar(40)    
    select  @ReceiverVault = AttachedToVault ,    
    @ReceiverDrawerType = DrawerType    
    from  CashDrawer            
    where  CashDrawerNumber = @CashDrawerNumber
       and AssignedToTeller = @ToCode -- Mohamed Elabd[19-December-2016 - Issue# GFSX11493]
        
    select  cm1.RefNo,    
		cm1.currency,    
		cm1.amount,    
		cm1.FromSeal,    
		cm1.ToSeal,    
		cm1.CashSealMsgrCode,                      
		cm1.User_Branch, -- Sender Branch                       
		cm1.User_Number,    
		cm1.isVault,    
		cm1.date_time,     
		op.LoginID as UserName,            
		cm1.CashDrawerNumber  ,  
		cm1.ToFromCode,  
		cm1.MovementType      
	 from  dbo.CashMovement as cm1                    
    inner join  dbo.Operator op    
    on   op.user_number = cm1.User_number            
    inner join  dbo.CashDrawer cd                
	on   (cd.AssignedToTeller = cm1.User_Number and cm1.CashDrawerNumber = cd.cashdrawerNumber and cd.Branch = cm1.User_Branch )    
   --ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
	/*
	Where  cm1.id in( select max(cshMve2.id) as LastID     
	   from CashMovement cshMve2    
	   WHERE cshMve2.RefNo = cm1.RefNo    
	   group by cshMve2.RefNo)
	*/
	Where  cm1.id in (select LastID     
	   from #TempCashMovement (NOLOCK) cshMve2    
	   WHERE cshMve2.RefNo = cm1.RefNo)    
	--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
    and   cm1.Movementtype in( 1,10) -- send , rejected  
    and   cm1.ToFromID  = @ToID -- Teller(1),Branch(3)                      
    and   cm1.ToFromCode   = @ToCode -- CurrentBranchID  or UserNumber                      
    and   cm1.User_Branch = @CurBranch                    
    and   @ToID = 1  -- When sender is User Movement is from Same Branch            
    and   ((cm1.isVault = 1 and cm1.CashDrawerNumber =  @ReceiverVault) or ( cm1.isVault = 0 and @ReceiverVault = cd.AttachedToVault) )    
    and   ( (cd.DrawerType = @ReceiverDrawerType and cm1.isVault = 0) or cm1.isVault= 1)    
end                    
Else if(@ToID = 9) -- To LeadTeller                      
begin        
 declare  @Vault int            
    select  @Vault = AttachedToVault            
    from  CashDrawer            
    where  CashDrawerNumber = @CashDrawerNumber    
	select  cm1.RefNo,                      
		cm1.currency,                      
		cm1.amount,
		cm1.FromSeal,             
		cm1.ToSeal,                      
		cm1.CashSealMsgrCode,                      
		cm1.User_Branch, -- Sender Branch                       
		cm1.User_Number,                    
		cm1.isVault,                      
		cm1.date_time,                      
		op.LoginID as UserName,            
		cm1.CashDrawerNumber   ,  
		cm1.ToFromCode,  
		cm1.MovementType                     
    from  dbo.CashMovement as cm1                    
    inner join dbo.Operator op                    
    on   op.user_number = cm1.User_number               
    inner join dbo.CashDrawer cd                
	on   (cd.AssignedToTeller = cm1.User_Number and   cm1.CashDrawerNumber =  cd.cashdrawerNumber and cd.Branch = cm1.User_Branch )    
    --ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
	/*
	Where  cm1.id in( select max(cshMve2.id) as LastID     
	   from CashMovement cshMve2    
	   WHERE cshMve2.RefNo = cm1.RefNo    
	   group by cshMve2.RefNo)
	*/
	Where  cm1.id in (select LastID     
	   from #TempCashMovement (NOLOCK) cshMve2    
	   WHERE cshMve2.RefNo = cm1.RefNo)    
	--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
     and  cm1.Movementtype in( 1,10) -- send , rejected  
     and  cm1.ToFromID  = 9 -- LeadTeller(4)                      
     and  cm1.User_Branch  = @CurBranch -- TELLER sent to his Lead Teller                      
     and  ((cm1.isVault = 1 and cm1.CashDrawerNumber =  @Vault) or ( cm1.isVault = 0 and @Vault = cd.AttachedToVault) )            
end 

--ITS Code Start [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
DROP Table #TempCashMovement
--ITS Code End [Mahmoud Kamel - 2016/09/06] Issue#GFSX11029 - Performance Issue
go
drop_old_proc'addATMCardRequest'
go
Create  proc dbo.addATMCardRequest                                                  
@ATMCardNumber varchar(50)=null,                                                  
@RimNumber int=null,                                                  
@CardType smallint=0,                                                  
@NameOnCard varchar(30)='',                                                  
@CardStatus smallint=0,                                                  
@DeliveryBranch varchar(30)='',                                                  
@PlasticType varchar(50)='',                                                  
@IssueDate datetime='1900-01-01',                                                  
@Language_display smallint=0,                                                  
@ID_Number varchar(20)='',                                                  
@POSService smallint=0,                                                  
@AccountNumber_1 varchar(12)='',                                                  
@AccountType_1 varchar(3)='',                                                  
@AccountNumber_2 varchar(12)='',                                                  
@AccountType_2 varchar(3)='',                                                  
@AccountNumber_3 varchar(12)='',                                                  
@AccountType_3 varchar(3)='',                                                  
@AccountNumber_4 varchar(12)='',                                                  
@AccountType_4 varchar(3)='',                                                  
@AccountNumber_5 varchar(12)='',                                                  
@AccountType_5 varchar(3)='',                                                  
@AccountNumber_6 varchar(12)='',                                                  
@AccountType_6 varchar(3)='',                                                  
@Telephone_1 varchar(20)='',                                                  
@Telephone_2 varchar(20)='',                                                  
@Telephone_3 varchar(20)='',                                                  
@Telephone_4 varchar(20)='',                                                  
@Telephone_5 varchar(20)='',                                                  
@Electricity_1 varchar(20)='',                                                  
@Electricity_2 varchar(20)='',                                                  
@Electricity_3 varchar(20)='',                                                  
@Electricity_4 varchar(20)='',                                                  
@Electricity_5 varchar(20)='',                                              
@Create_date DateTime = '1900-01-01',                                                  
@User_id varchar(20)='',                        
                               
------ Sherif Samy - BIsB CR# 28 --------                                      
@ChargeWaived Char(1) = '1',                                      
@OriginalChargeAmount varChar(21) = '0.00',                                      
@ChargeAmount varChar(21) = '0.00',                                      
@ChargeAccountType Char(3) = '',                                      
@ChargeAccountNumber Char(12) = '',                                      
@WaivedType Char(10),                                      
------------------------------------                                           
                                      
---- Sherif Samy - BBK CR# 114 -----                                          
@ExpireDate Char(10),                        
 ---- Sally Muhammad - ADIB CR# 8080 -----                                          
@RimName nvarchar(200),                                     
@RimName2 nvarchar(200),                                    
@IssueBranchID Int ,                    
@deliveredFromCMS char(1)  ='N'     ,                       
-------------------------------------------                                     
                
---- Motaz Atiya - ADIB CR# 516                  
@SupplementaryCard bit = 0,                  
@PrimaryCard nvarchar(50) = '',                
@LimitProfile nvarchar(10) = '',                  
@AddressLine1 nvarchar(110) = '',                  
@AddressLine2 nvarchar(110) = '',
@Name2 NVARCHAR(40) ,         ---- CR[CRQ13289][GFSY00702][Debit Card For Business Banking]{23-05-2018}{Sara Badwy}              
@Region Int,          
------------------------------------               
@Bank Int,                   
@Branch Int  ,                       
------------------------------------                                       
@AccountBranch_1 Int        ---- Rokaia Kadry [23-November-2017 - Issue# GFSX12661]   

AS                                       
                                  
/*                                  
modified : Hatem Mohammed Noaman                  
date : 29-05-2008                                  
reason :Use Get_BankConfigProperty instead of Get_BankConfig_Property                                  
               
modified : Hatem Mohammed Noaman                                  
date : 03-06-2008                                  
reason :Return Credit Card Number using @maxid instread of @id                            
                            
modified : Mostafa Elbarbary                                   
date : 25-03-2012                                  
reason :Change Selection from Table ATMCardNoSequenceRange to BranchConfig                        
                      
modified : Sally Muhammad                                 
date : 23-04-2012                                  
Cahnges :Update Last Sequence after generating the new ATM Card ID to the next valid id                       
this column acts as Next Sequence not the last used sequence                      
reason :Procedure use the same id and it should be unique                       
                    
modified : Sally Muhammad                         
date : 9-05-2012                                  
Cahnges :new columns [RimName,RimName2,IssueBranchID ,deliveredFromCMS] have been added to table ATMCardRequest                     
reason :CR-8080_ATM Interface between CMS                   
                  
modified : Motaz Atiya                  
date : 14 september, 2015                  
changes : New columns [SupplementaryCard, PrimaryCard, LimitProfile, Address1, Address2] have been added to table [ATMCardRequest],          
   Select from BranchConfig by Region, Bank and Branch instead of only Branch          
reason : CR-516              
  
modified : Karim Mahmoud       
date : 10-12-2015                
reason :handling barnch number conversion to varChar(3)  
Version : 2.00.46.1810   

Updator : Sara Badwy            
 Date :    2018-05-23               
 Reason : CR[CRQ13289] Add Column Name2   
 
	CreationDate : [23/11/2017]
	Programmer   : Rokaia Kadry 
	Description  : Issue#GFSX12661 Adding new Column for @AccountBranch_1 .....   
*/                                 
                                    
if( rTrim(@WaivedType) = 'NULL' )                                       
  Set @WaivedType = Null                                      
                                      
                                      
declare @ID bigint                                        
Declare @Prefix varChar(20)                                      
                                      
Select @Prefix = PlasticTypePrefix From ATMPlasticTypes Where PlasticTypeCode = @PlasticType                                      
                                      
Set @ATMCardNumber = @Prefix                                      
                                      
Begin Tran                                      
------------------------------------------- Sherif Samy -- BBK CR# 114 -----------------------------------------------                                      
Declare @GenerateCardNoMechanism Int                                      
--Select @GenerateCardNoMechanism = isNull(ATMGenerateCardNoMechanism, 0) From BankConfig Where Bank = @Bank                                       
--Select @GenerateCardNoMechanism = isNull(convert(Int,value),0) FROM Get_BankConfig_Property(@Bank,'ATMGenerateCardNoMechanism')                                      
Exec Get_BankConfigProperty 1,'ATM_ChargeCard',@GenerateCardNoMechanism Output                                      
                                      
If ( @GenerateCardNoMechanism = 1 )                                      
begin                                      
 Declare @NextATMCardNoSerial varChar(50)               Declare @CheckDigit Int                                      
 Declare @rtn Int                                      
                                      
 Exec @rtn = GetNextATMCardNoSequenc @Region, @Bank, @Branch, @NextATMCardNoSerial OutPut                            
                                
 If( @rtn = 0 )                                      
    begin                                      
  Set @ATMCardNumber = rTrim(@ATMCardNumber) + Right('00' + rTrim(Convert(varChar(3), @Branch)), 3) + rTrim(@NextATMCardNoSerial)                                       
                                       
  Exec GetATMCardNoCheckDigit @ATMCardNumber, @CheckDigit OutPut                                      
                                       
  Set @ATMCardNumber = rTrim(@ATMCardNumber) + rTrim(Convert(char(10), @CheckDigit))                                      
                                       
  --Update BranchConfig Set LastSequence = Convert(BigInt, @NextATMCardNoSerial) Where Branch = @Branch             
  Update BranchConfig Set LastSequence = Convert(BigInt, @NextATMCardNoSerial)+1 Where Branch = @Branch and Bank = @Bank and Region = @Region            
 end                                      
 Else                                      
 begin                                       
  Rollback                                      
  SELECT NULL,@rtn,NULL,NULL,NULL,NULL,NULL,NULL,Case When @rtn = -1 Then 'Branch not exist in ATMCardNoSequenceRange Table' Else  'ATM Card Number Sequence Exceeded Branch Range ' End, 'Failed',NULL,NULL,NULL,@ID                                        
  Return @rtn                                      
 end                       
end                                      
Else                                      
begin                                      
 Set @ATMCardNumber = @PlasticType + ' ' + @ATMCardNumber                                      
end                                      
----------------------------------------------------------------------------------------------------------------------                                      
declare @maxid as numeric                                  
exec Next_Table_MaxID 'ATMCardRequest','ID',@maxid output                                  
--select @maxid                                      
                                      
INSERT INTO ATMCardRequest                                      
(                                    
ID,                                    
ATMCardNumber,                                       
RimNumber,                                       
CardType,                                       
NameOnCard,                                       
CardStatus,                                       
DeliveryBranch,                                       
PlasticType,                                       
IssueDate,                                       
Language_display,                                       
ID_Number,                                       
POSService,                                       
AccountNumber_1, AccountType_1,                                       
AccountNumber_2, AccountType_2,                                       
AccountNumber_3, AccountType_3,                                       
AccountNumber_4, AccountType_4,                                       
AccountNumber_5, AccountType_5,                                       
AccountNumber_6, AccountType_6,                                       
Telephone_1, Telephone_2, Telephone_3, Telephone_4, Telephone_5,                                       
Electricity_1, Electricity_2, Electricity_3, Electricity_4, Electricity_5,                                       
Creator, Created, Updator, LastChanged,                                       
ChargeWaived, OriginalChargeAmount, ChargeAmount, ChargeAccountType, ChargeAccountNumber, WaivedType, ExpiryDate, UpdateDate, UpdateFlag                    
,RimName,RimName2,IssueBranchId,Delivered, SupplementaryCard, PrimaryCard, LimitProfile, Address1, Address2,AccountBranch_1,Name2)                                      
values(                                    
 @maxid,                                    
@ATMCardNumber,                                       
@RimNumber,                                       
@CardType,                                                  
@NameOnCard,     
@CardStatus,                                       
CASE WHEN @DeliveryBranch = -1 THEN 'Other' ELSE @DeliveryBranch END,                                                  
@PlasticType,                                       
@IssueDate,                                       
@Language_display,                                                  
@ID_Number,                                      
@POSService,                                       
@AccountNumber_1, @AccountType_1,                                       
@AccountNumber_2, @AccountType_2,                                                  
@AccountNumber_3, @AccountType_3,                                       
@AccountNumber_4, @AccountType_4,                                       
@AccountNumber_5, @AccountType_5,                                                  
@AccountNumber_6, @AccountType_6,                                       
@Telephone_1, @Telephone_2, @Telephone_3, @Telephone_4, @Telephone_5,                                                  
@Electricity_1, @Electricity_2, @Electricity_3, @Electricity_4, @Electricity_5,                                       
@User_id , GETDATE() ,@User_id, GETDATE (),                                      
Convert(Bit, @ChargeWaived), Convert(Decimal(21, 6), @OriginalChargeAmount), Convert(Decimal(21, 6), @ChargeAmount), @ChargeAccountType, @ChargeAccountNumber, @WaivedType,                                       
Convert(DateTime, @ExpireDate), GETDATE (), 'N',@RimName,@RimName2,@IssueBranchID,@deliveredFromCMS,        
CASE WHEN @SupplementaryCard = 0 THEN 'P' ELSE 'A' END,        
@PrimaryCard,        
@LimitProfile,        
@AddressLine1,        
@AddressLine2,                                      
@AccountBranch_1,
@Name2)                                      
                                              
set @ID = @@identity                                           
                                         
if @@error <> 0                                              
begin                                              
 Rollback                                      
 SELECT NULL,@@error,NULL,NULL,NULL,NULL,NULL,NULL,@@error,'Failed',NULL,NULL,NULL,@ID                                           
end                            
else                                              
begin                      
 Commit                                           
 SELECT NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Created',NULL,NULL,@ATMCardNumber,@maxid                                        
end   
Go
DROP_OLD_PROC 'getAllAtmCard'
GO
create proc dbo.getAllAtmCard                  
@RimNumber int                   
as          
/*                
 * Modifier : Mohammed Farouk                
 * Date  : 2011-09-21                
 * Reason : select descriptions for ATMCardType, ATMCardStatus, Plastic Type                
               
 Updator : Motaz Atiya              
 Date : 22 september, 2015              
 Reason : get Card Type description from 'CardType' table instead of a picklist     
   
 Updator : May Hassan              
 Date :    2016-06-22               
 Reason :  Add ATMCardDesc , NameOnCard + CardNumber   
 
 	CreationDate : [23/11/2017]
	Programmer   : Rokaia Kadry 
	Description  : Issue#GFSX12661 Adding new Column for @AccountBranch_1 .....    
	
Updator : Sara Badwy            
 Date :    2018-05-22               
 Reason : CR[CRQ13289] Return Column Name2   
           
*/  
/*Version : 2.00.46.1807, Modification Date : 07/12/2015*/        
SELECT          
 ID, ATMCardNumber, RimNumber, CardType, NameOnCard, CardStatus,    
 CASE    
 WHEN DeliveryBranch = 'Other' THEN '-1'    
 ELSE DeliveryBranch    
 END AS DeliveryBranch,    
 PlasticType, IssueDate, Language_display, ID_Number, POSService,          
 AccountNumber_1, AccountType_1, AccountNumber_2, AccountType_2, AccountNumber_3, AccountType_3, AccountNumber_4, AccountType_4, AccountNumber_5,        
 AccountType_5, AccountNumber_6, AccountType_6, Telephone_1, Telephone_2, Telephone_3, Telephone_4, Telephone_5, Electricity_1, Electricity_2, Electricity_3,        
 Electricity_4, Electricity_5, ATMCR.Creator, ATMCR.Created, ATMCR.Updator, ATMCR.LastChanged, ChargeWaived, OriginalChargeAmount, ChargeAmount,          
 ChargeAccountType, ChargeAccountNumber, WaivedType, ExpiryDate, UpdateDate, UpdateFlag, Delivered, ExportedToCMS, RimName, RimName2, IssueBranchId,          
 CASE          
  WHEN SupplementaryCard = 'P' THEN 0          
  ELSE 1          
 END AS SupplementaryCard,          
 PrimaryCard, LimitProfile, Address1, Address2,          
 PLCardStatusDesc.Descriptor AS CardStatusDesc,          
 PLCardTypeDesc.CardTypeDescription AS CardTypeDesc,          
 ATMPlasticTypes.PlasticTypeDescription ,  
 NameOnCard +' '+  ATMCardNumber As  ATMCardDesc     
 ,AccountBranch_1 
 ,Name2
FROM ATMCardRequest ATMCR          
LEFT JOIN PickList_Entries PLCardStatus          
 ON ATMCR.CardStatus = PLCardStatus.Value          
 AND PLCardStatus.PickListID = 15059          
LEFT JOIN RulesDescriptor PLCardStatusDesc          
 ON PLCardStatusDesc.Name = PLCardStatus.DescriptorName          
LEFT JOIN CardType PLCardTypeDesc          
 ON PLCardTypeDesc.CardTypeCode = ATMCR.CardType          
LEFT JOIN ATMPlasticTypes          
 ON ATMCR.PlasticType = ATMPlasticTypes.PlasticTypeCode          
WHERE RimNumber = CONVERT(INT, @RimNumber); 
GO
DROP_OLD_PROC 'updateATMCardRequest'
GO
CREATE Procedure updateATMCardRequest                 
              
@ID bigint ,                     
@ATMCardNumber varchar(25)=null,                
@RimNumber int=null,                 
@CardType smallint=0,                        
@NameOnCard varchar(40)='',                        
@CardStatus smallint=0,                        
@DeliveryBranch varchar(30)='',                        
@PlasticType varchar(50)='',                        
@IssueDate DATETIME ='1900-01-01',                        
@Language_display smallint=0,                        
@ID_Number varchar(20)='',                        
@POSService smallint=0,                        
@AccountNumber_1 varchar(12)='',                        
@AccountType_1 varchar(3)='',                        
@AccountNumber_2 varchar(12)='',                        
@AccountType_2 varchar(3)='',                        
@AccountNumber_3 varchar(12)='',                        
@AccountType_3 varchar(3)='',                        
@AccountNumber_4 varchar(12)='',                        
@AccountType_4 varchar(3)='',                        
@AccountNumber_5 varchar(12)='',                        
@AccountType_5 varchar(3)='',                        
@AccountNumber_6 varchar(12)='',                        
@AccountType_6 varchar(3)='',                        
@Telephone_1 varchar(20)='',                        
@Telephone_2 varchar(20)='',                        
@Telephone_3 varchar(20)='',                        
@Telephone_4 varchar(20)='',                        
@Telephone_5 varchar(20)='',                        
@Electricity_1 varchar(20)='',                        
@Electricity_2 varchar(20)='',                        
@Electricity_3 varchar(20)='',                        
@Electricity_4 varchar(20)='',                        
@Electricity_5 varchar(20)='',                  
@LastChanged DATETIME = '1900-01-01',                        
@Updator OperatorID,                
------ Sherif Samy - CR# 28 --------                
@ChargeWaived Char(1) = '1',                
@OriginalChargeAmount varChar(21) = '0.00',                
@ChargeAmount varChar(21) = '0.00',                
@ChargeAccountType Char(3) = '',                
@ChargeAccountNumber Char(12) = '',                
@WaivedType Char(10) = '',                
------------------------------------                
---- Sherif Samy - BBK CR# 114 -----                    
@ExpireDate Char(10)    ,            
------------------------------------                
 ---- Sally Muhammad - ADIB CR# 8080 -----                                  
@RimName nvarchar(200),                             
@RimName2 nvarchar(200),                            
@IssueBranchID Int ,            
@deliveredFromCMS char(1)  ='N',            
-------------------------------------------                  
          
---- Motaz Atiya - ADIB CR# 516            
@SupplementaryCard bit = 0,            
@PrimaryCard nvarchar(50) = '',            
@LimitProfile nvarchar(10) = '',            
@AddressLine1 nvarchar(110) = '',            
@AddressLine2 nvarchar(110) = '' ,
@Name2 NVARCHAR(40)=''          ----Defect[GFSX13063]{14-06-2018}{Sara Badwy} 
          
AS                        
 /*modified : Sally Muhammad                         
date : 9-05-2012                          
Cahnges :new columns [RimName,RimName2,IssueBranchID ,deliveredFromCMS] have been added to table ATMCardRequest             
reason :CR-8080_ATM Interface between CMS              
          
modified : Motaz Atiya            
date : 14 september, 2015            
changes : - New columns [SupplementaryCard, PrimaryCard, LimitProfile, Address1, Address2] have been added to table [ATMCardRequest]        
    - If updated card is a primary card that has supplementary cards attached to it, Then update supplementary cards with new values of        
    [Plastic Type, Card Type, Limit Profile, Account Numbers]        
reason : CR-516            


Modified: Mohamed Elabd             
Date:	  28-November-2016             
Changes:  Update ATMCardNumber (Uncommented) - Issue# GFSX11361


Modified: Rokaia Kadry         
Date:	  20-09-2017       
Changes:  Ethix Branch - G12 - ATM Card Request - Issue# GFSX12490-INC000000176522
Add Defensive Action on @ATMCardNumber is Null

Modified: Sara Badwy  
Date:	  14-06-2018      
Changes:  Ethix Branch -Defect[GFSX13063]
Update Name2 


*/            

/*Version : 2.00.46.2017, Modification Date : 28/11/2016*/
            
Declare @rtn Int                
                
Exec @rtn = InsertATMRequestHistory @ID, @Updator, @LastChanged                
                
if( @rtn = 0 )                
  begin                
 if( rTrim(@WaivedType) = 'NULL' )                 
   Set @WaivedType = Null                
                     
 begin          
  UPDATE ATMCardRequest                
  SET ATMCardNumber = @ATMCardNumber,                 
  RimNumber =  @RimNumber,                 
  CardType = @CardType,                 
  NameOnCard = @NameOnCard,                 
  CardStatus = @CardStatus,                 
  DeliveryBranch = CASE WHEN @DeliveryBranch = -1 THEN 'Other' ELSE @DeliveryBranch END,  
  PlasticType = @PlasticType,                 
  IssueDate = @IssueDate,                 
  Language_display = @Language_display,                 
  ID_Number = @ID_Number,                 
  POSService = @POSService,                 
  AccountNumber_1 = @AccountNumber_1,                 
  AccountType_1 = @AccountType_1,                 
  AccountNumber_2 = @AccountNumber_2 ,                 
  AccountType_2 = @AccountType_2,                 
  AccountNumber_3 = @AccountNumber_3,                 
  AccountType_3 = @AccountType_3,                 
  AccountNumber_4 = @AccountNumber_4,                 
  AccountType_4 = @AccountType_4 ,                 
  AccountNumber_5 = @AccountNumber_5 ,                 
  AccountType_5 = @AccountType_5 ,                 
  AccountNumber_6 = @AccountNumber_6 ,                 
  AccountType_6 = @AccountType_6 ,                 
  Telephone_1 = @Telephone_1 ,                 
  Telephone_2 = @Telephone_2 ,                 
  Telephone_3 = @Telephone_3 ,                 
  Telephone_4 = @Telephone_4 ,                 
  Telephone_5 = @Telephone_5 ,                 
  Electricity_1 = @Electricity_1 ,                 
  Electricity_2 = @Electricity_2 ,                 
  Electricity_3 = @Electricity_3 ,                 
  Electricity_4 = @Electricity_4 ,                 
  Electricity_5 = @Electricity_5 ,              
  RimName = @RimName ,                 
  RimName2 = @RimName2 ,            
  Delivered=@deliveredFromCMS,                 
  IssueBranchId = @IssueBranchID ,                 
  Updator = @Updator ,                 
  LastChanged =getdate(),-- @LastChanged,                
  -----------------------------                  
  ChargeWaived = Convert(Bit, @ChargeWaived),                
  OriginalChargeAmount = Convert(Decimal(21, 6), @OriginalChargeAmount),                
  ChargeAmount = Convert(Decimal(21, 6), @ChargeAmount),                
  ChargeAccountType = @ChargeAccountType,                
  ChargeAccountNumber = @ChargeAccountNumber,                
  WaivedType = @WaivedType,                
  ExpiryDate = Convert(DateTime, @ExpireDate),                
  UpdateDate = GetDate(),                 
  UpdateFlag = 'U',                
  -----------------------------                
  SupplementaryCard = CASE WHEN @SupplementaryCard = 0 THEN 'P' ELSE 'A' END,           
  PrimaryCard = @PrimaryCard,          
  LimitProfile = @LimitProfile,          
  Address1 = @AddressLine1,          
  Address2 = @AddressLine2 ,
  Name2=@Name2         
  -----------------------------          
  WHERE (ID = @ID)                     
                   
------------------------------------------------        
--Update supplementary cards    
	IF EXISTS (SELECT * FROM ATMCardRequest where ATMCardNumber = @ATMCardNumber AND SupplementaryCard = 'P' and  @ATMCardNumber is not null and @ATMCardNumber <> '' ) -- Rokaia Kadry  Issue# GFSX12490-INC000000176522  and  @ATMCardNumber is not null and @ATMCardNumber <> ''    PayCard    
	BEGIN        
	UPDATE ATMCardRequest        
	SET PlasticType = @PlasticType,        
	 CardType = @CardType,        
	 LimitProfile =        
		 CASE        
		  WHEN LimitProfile = '' OR @LimitProfile = '' THEN @LimitProfile        
		  ELSE LimitProfile        
		 END,        
	 AccountNumber_1 = @AccountNumber_1,        
	 AccountType_1 = @AccountType_1,        
	 AccountNumber_2 = @AccountNumber_2,        
	 AccountType_2 = @AccountType_2,        
	 AccountNumber_3 = @AccountNumber_3,        
	 AccountType_3 = @AccountType_3,        
	 AccountNumber_4 = @AccountNumber_4,        
	 AccountType_4 = @AccountType_4,        
	 AccountNumber_5 = @AccountNumber_5,        
	 AccountType_5 = @AccountType_5,        
	 AccountNumber_6 = @AccountNumber_6,        
	 AccountType_6 = @AccountType_6        
	WHERE PrimaryCard = @ATMCardNumber  AND SupplementaryCard = 'A' ;        
	END   
     
------------------------------------------------        
        
if @@error <> 0               
 begin                      
    SELECT NULL,@@error,NULL,NULL,NULL,NULL,NULL,NULL,@@error,'Failed',NULL,NULL,NULL,@ID        
 end                      
else                      
 begin                      
    SELECT NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Created',NULL,NULL,NULL,@ID                        
 end                      
end                      
end                
else                
 begin                
  SELECT NULL,@@error,'History',NULL,NULL,NULL,NULL,NULL,@@error,'Failed',NULL,NULL,NULL,@ID                
 end     
 GO
