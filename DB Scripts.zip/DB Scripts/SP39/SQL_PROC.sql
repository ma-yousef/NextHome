drop_old_proc'Get_XTM_Categories'
GO
CREATE procedure dbo.Get_XTM_Categories 
  (    
	  @currencies AS T_XTMCurrencies READONLY
)
as 
Begin 
select DISTINCT cat.id,cat.Name from CurrencyCategory cat
         inner join CurrencyCategoryDetail catdet on cat.id=catdet.CurrencyCategoryID
         where catdet.Currency in (select * from @currencies)
end

GO
drop_old_proc'Get_XTM_Plates'
GO
CREATE procedure dbo.Get_XTM_Plates      
@XTMCode Nvarchar(15)='-1',    
@VendorID INT =-1,    
@Currency CurrencyType='-1',    
@PlateSerial varchar(100)='-1' ,    
@IncludeSold bit =0    
as                                   
/*                                            
  CreationDate: 25/09/2019                                                     
  Programmer: SaraBadwy                                      
  Description: Select XTM plates with it's status filtered by input params .                                      
  Output:  list of XTM Plates                                              
 */    
 begin    
  --Select xtm plates with any status for this xtm machine 
          SELECT distinct XTMMachineName,PM.Status,PV.Vendor as 'PlateVendor',pm.SerialNo as 'PlateSerial',PM.Denom as 'Denomination',case when PM.Status=6 then 1 else 0 end as 'XTMStock' ,    
                          0 as 'RejectedBin',case when PM.Status=7 then 1 else 0 end as 'XTMSold',case when PM.Status=1 then 1 else 0 end as 'ReceivedByTR'    
          INTO #XTMPlates  from PM INNER JOIN PM_Vendor PV on PM.VendorID=PV.VendorID    
                   INNER JOIN PM_Type   PMT  ON PM.PMTypeID= PMT.PMTypeID    
                   INNER JOIN CurrencyCategoryDetail CCD ON PMT.ISO_Code=CCD.Currency    
                   INNER JOIN CurrencyCategory CC ON CC.id=CCD.CurrencyCategoryID    
                   INNER JOIN ATM  ON ATM.CurrencyCategoryID=CC.id      
                   where PV.XTM=1  --AND (ATM.Code=@XTMCode OR @XTMCode='-1')    
                                   AND (PV.VendorID=@VendorID OR @VendorID=-1)     
                                   AND (CCD.Currency=@Currency or @Currency='-1')    
                                   AND (PM.SerialNo=@PlateSerial OR @PlateSerial='-1') 
                                   AND ATM.ATMType='XTM'                                   
          SELECT PlateVendor,PlateSerial,Denomination,XTMStock ,RejectedBin,XTMSold,ReceivedByTR  FROM #XTMPlates WHERE 
                                  ((@IncludeSold=0 AND #XTMPlates.Status<>7) or @IncludeSold=1)--7 stands for XTMSold status                                    
                                   AND (XTMMachineName=@XTMCode)
          UNION 
-- Select all xtm plates with status RecivedByTr regardless machine name     
           SELECT PlateVendor,PlateSerial,Denomination,XTMStock ,RejectedBin,XTMSold,ReceivedByTR from #XTMPlates  WHERE 
                                   #XTMPlates.Status=1--1 stands for RecivedByTR status                                   
                                   AND (#XTMPlates.XTMMachineName='' OR #XTMPlates.XTMMachineName IS NULL  OR @XTMCode='-1')                                      
                                   order by PlateSerial
                                       
 end  
 go
DROP_OLD_PROC 'pm_ListAvilableVendors'
GO
create proc [dbo].[pm_ListAvilableVendors]        
@PMTypeID int =0        
-- Reason : List Avilable Vendors per Precious Metal        
-- and get vendor Info also    
--  
/*     
 Update Date  : 25/09/2019   
 Programmer   : Sara Badwy  
 Description  : KFH_ACMACM16880_Gold Dispense Retrofit
*/       
as        
SELECT PMV.[VendorID]        
      ,[Vendor]        
      ,[NostroAccount]        
      ,[acct_type]        
      ,[appl_type]        
      ,[dep_loan]        
      ,[acct_curr]  
      ,PMV.[XTM]        
FROM [Globalfs].[dbo].[PM_VendorToType] PMVT        
inner join [Globalfs].[dbo].[PM_Vendor] PMV on PMV.VendorID =PMVT.VendorID and PMVT.PMTypeID=@PMTypeID      

GO
drop_old_proc 'Update_XTM_Plates'
GO
CREATE PROCEDURE Update_XTM_Plates    
(    
	  @dt AS UpdateXtmPlates READONLY
)    
AS     
/*   
 CreationDate : 25/09/2019    
 Programmer   : Sara Badwy
 Description  : KFH_ACMACM16880_Gold Dispense Retrofit
*/     
 BEGIN   
 UPDATE PM    
 SET  PM.Status=PMGFS.Status,  
 PM.XTMMachineName=PMGFS.XTMMachineName  
 FROM  PM INNER JOIN @dt AS PMGFS   
 ON PM.SerialNo= PMGFS.PlateSerial
 INNER JOIN PM_Vendor VEN ON VEN.Vendor=PMGFS.VendorName 
 and PM.VendorID=VEN.VendorID 
END  
GO 
drop_old_proc 'dbo.GetLinkedAndUnlinkedRimClass'
go
Create PROCEDURE [dbo].[GetLinkedAndUnlinkedRimClass]
@employeeID int,
@LCID int,
@rimType varchar(100)
AS
		/*
		Developer	: Ahmed Osman
		Date		: [06/19/2019]
		Reason		: KFH_ACM15771_Upgrade/Downgrade Customer Class - Retrofit
		*/
	--Get the picklistID for Class Code picklist for open personal account and open non personal account
	declare @PickListID int ;
	IF(@rimType = 'Personal')
	BEGIN
	select @PickListID = PickListID from PickLists where PickList_Name='DPHX_P_RIM_CLASS'
	end
	else IF(@rimType = 'NPersonal')

	begin
	select @PickListID = PickListID from PickLists where PickList_Name='DPHX_P_NRIM_CLASS'
	end    

	/* we will filter the picklist entries depending on the login user in the system to get Linked and un linked Rim Classes and 
	will get the Id and name of each class Code,so we get the ID value from table picklist entries Column Value and using 
	the inner join we get the name of Class Code taknig into considration the system language*/
	
	
	--English language
	if(@LCID=1033)
	begin
	select Value,Descr.Descriptor as Name ,PE.CustomValues as mandatoryFields  from PickList_Entries PE inner join
	RulesDescriptor Descr on PE.DescriptorName = Descr.Name
		where 
	PickListID=@PickListID and
	Value not in 
	(select class_code from rm_cls_rsm_grp)
	union 
	select Value,Descr.Descriptor as Name ,PE.CustomValues as mandatoryFields  from PickList_Entries PE inner join
	RulesDescriptor Descr on PE.DescriptorName = Descr.Name
		where 
	PickListID=@PickListID and
	Value in
	(select class_code from rm_cls_rsm_grp where
	 grp_id in 
	 (select grp_id from emp_rsm_grp where
	  emp_id=@employeeID))
	end
	--Other language
	else
	begin
	select Value,DescLoc.LocalDescription as Name ,PE.CustomValues as mandatoryFields  from PickList_Entries PE inner join
	 RulesDescriptor Descr on PE.DescriptorName = Descr.Name inner join 
	 RulesDescriptorLocal DescLoc on Descr.DescriptorID = DescLoc.DescriptorID and DescLoc.LCID = @LCID
		where 
	PickListID=@PickListID and
	Value not in 
	(select class_code from rm_cls_rsm_grp)
	union 
	select Value,DescLoc.LocalDescription as Name  ,PE.CustomValues as mandatoryFields from PickList_Entries PE inner join
	RulesDescriptor Descr on PE.DescriptorName = Descr.Name inner join
	RulesDescriptorLocal DescLoc on Descr.DescriptorID = DescLoc.DescriptorID and DescLoc.LCID = @LCID
		where 
	PickListID=@PickListID and
	Value in
	(select class_code from rm_cls_rsm_grp where
	 grp_id in 
	 (select grp_id from emp_rsm_grp where
	  emp_id=@employeeID))
	end

go
drop_old_proc 'dbo.CalculateEffectiveDays'
GO

CREATE proc dbo.CalculateEffectiveDays
@DepositCurrency nvarchar(50),
@AccountCurrency nvarchar(50),
@AccountType nvarchar(10)
as

/*
Creation date:		9 November, 2016
Creator:			Motaz Atiya
Creation reason:	Calculate effective days
*/

DECLARE @CategoriesNames TABLE
(
  Name nvarchar(50)
);

declare @DaysNo int = -1;
declare @InCategory bit = 0;

INSERT INTO @CategoriesNames
		SELECT
			name
		FROM AccountCategory
		WHERE id IN (SELECT
				id
			FROM AccountCategoryDetail
			WHERE AccountType = @AccountType);

IF EXISTS (SELECT
			*
		FROM @CategoriesNames)
BEGIN

SELECT
	@DaysNo = COALESCE(MIN(No_Days), -1)
FROM CurrencyEffectiveDays
WHERE DepositCurrencyCategory = @DepositCurrency
AND AccountCurrencyCategory = @AccountCurrency
AND AccountTypeCategory IN (SELECT
		Name
	FROM @CategoriesNames);

SET @InCategory = 1;

END

if (@DaysNo = -1 or @InCategory = 0)
begin
SELECT
	@DaysNo = COALESCE(MIN(No_Days), -1)
FROM CurrencyEffectiveDays
WHERE DepositCurrencyCategory = @DepositCurrency
AND AccountCurrencyCategory = @AccountCurrency
AND (AccountTypeCategory = ''
OR AccountTypeCategory IS NULL);
END

RETURN @DaysNo;

GO
drop_old_proc 'dbo.CalculateEffectiveDaysWithFutureDays'
GO

CREATE proc dbo.CalculateEffectiveDaysWithFutureDays
@DepositCurrency nvarchar(50),
@AccountCurrency nvarchar(50),
@AccountType nvarchar(10)
as
BEGIN


/*
-- Author:		Ibrahim Harby
-- Create date: 25/11/2020
-- Description:	Alter 'CalculateEffectiveDays'  for adding Futuredays Value
*/

DECLARE @CategoriesNames TABLE
(
  Name nvarchar(50)
);

declare @DaysNo int = -1;
declare @InCategory bit = 0;
declare @FutureDays int =-1;

INSERT INTO @CategoriesNames
		SELECT
			name
		FROM AccountCategory
		WHERE id IN (SELECT
				id
			FROM AccountCategoryDetail
			WHERE AccountType = @AccountType);

IF EXISTS (SELECT
			*
		FROM @CategoriesNames)
BEGIN

SELECT
	@DaysNo = COALESCE(MIN(No_Days), -1),@FutureDays = COALESCE(MIN(FutureDays), -1)
FROM CurrencyEffectiveDays
WHERE DepositCurrencyCategory = @DepositCurrency
AND AccountCurrencyCategory = @AccountCurrency
AND AccountTypeCategory IN (SELECT
		Name
	FROM @CategoriesNames);



SET @InCategory = 1;

END

if (@DaysNo = -1 or @InCategory = 0)
begin
SELECT
	@DaysNo = COALESCE(MIN(No_Days), -1),@FutureDays = COALESCE(MIN(FutureDays), -1)
FROM CurrencyEffectiveDays
WHERE DepositCurrencyCategory = @DepositCurrency
AND AccountCurrencyCategory = @AccountCurrency
AND (AccountTypeCategory = ''
OR AccountTypeCategory IS NULL);

END


Select @DaysNo as 'No_OF_Days',@FutureDays as 'Future_Days';
END
GO
DROP_OLD_PROC 'GetEffectiveDays'
GO
Create Procedure dbo.GetEffectiveDays
as
/*    
Creator : Asmaa Hafez    
Date    : 10-05-2012   
Reason  : Get Effective Days according to the currency category [CR # 7948 "Cash Deopsit"]    

Modifier: Motaz Atiya
Date: 6 Nov, 2016
Reason: Order output dataset columns


Modifer:      Ibrahim Harby
Date: 18-November-2020
Reason: update select statment to select new column "FutureDays" - CR# GfsY00829 - Retrofit - ADIB_ACM000000019147_Cash Deposit Effective Date Future Value

*/

SET NOCOUNT ON

SELECT
	ID
	,DepositCurrencyCategory
	,AccountCurrencyCategory
	,AccountTypeCategory
	,No_Days
	,FutureDays
FROM dbo.CurrencyEffectiveDays;

GO
DROP_OLD_PROC 'InsertEffectiveDays'
GO
Create Procedure dbo.InsertEffectiveDays
@DepositCurrencyCategory varchar(50) = Null,
@AccountCurrencyCategory varchar(50) = Null,
@AccountTypeCategory varchar(50) = Null,
@DaysNo int = Null,
@FutureDays int = Null
as

/*
Creation date:		9 November, 2016
Creator:			Motaz Atiya
Creation reason:	Insert new effective days values

Modifer:      Ibrahim Harby
Date: 18-November-2020
Reason: update insert statment to insert values to  column "FutureDays" - CR# GfsY00829 - Retrofit - ADIB_ACM000000019147_Cash Deposit Effective Date Future Value

*/

IF EXISTS (SELECT
		1
	FROM dbo.CurrencyEffectiveDays
	WHERE DepositCurrencyCategory = @DepositCurrencyCategory
	AND AccountCurrencyCategory = @AccountCurrencyCategory
	AND AccountTypeCategory = @AccountTypeCategory)
BEGIN
RETURN -10    -- Effective Date already exists
END

DECLARE @NewID INT;
SELECT
	@NewID = MAX(ID) + 1
FROM CurrencyEffectiveDays;

IF (@NewID IS NULL)
SET @NewID = 1;

INSERT INTO dbo.CurrencyEffectiveDays (ID, DepositCurrencyCategory, AccountCurrencyCategory, AccountTypeCategory, No_Days , FutureDays)
	VALUES (@NewID, @DepositCurrencyCategory, @AccountCurrencyCategory, @AccountTypeCategory, @DaysNo , @FutureDays);
GO
DROP_OLD_PROC 'UpdateEffectiveDays'
GO

Create Procedure dbo.UpdateEffectiveDays
@Id int = null,
@DepositCurrencyCategory varchar(50) = Null,
@AccountCurrencyCategory varchar(50) = Null,
@AccountTypeCategory varchar(50) = Null,
@DaysNo int = Null,
@FutureDays int = Null
as

/*
Creation date:		9 November, 2016
Creator:			Motaz Atiya
Creation Reason:	Update effective days values


Modifer:      Ibrahim Harby
Date: 18-November-2020
Reason: update  statment to update values to  column "FutureDays" -   CR# GfsY00829 - Retrofit- ADIB_ACM000000019147_Cash Deposit Effective Date Future Value 

*/

UPDATE dbo.CurrencyEffectiveDays
SET	DepositCurrencyCategory = @DepositCurrencyCategory
	,AccountCurrencyCategory = @AccountCurrencyCategory
	,AccountTypeCategory = @AccountTypeCategory
	,No_Days = @DaysNo 
	,FutureDays = @FutureDays 
	WHERE ID = @Id;

GO
DROP_OLD_PROC 'UpdateJournalAndTotals'
GO
CREATE proc [dbo].[UpdateJournalAndTotals]          
  @Bank  BankID        
 ,@Region RegionID        
 ,@Branch BranchID        
 ,@JNLSequence int -- JNLSequence        
 ,@user_number internal_user_ID        
 ,@BusinessDate_Day tinyint        
 ,@year_month smallint        
 ,@BusinessDate SmallDate        
 ,@CashDrawer CashDrawerNumber = NULL        
 ,@Correction bit = 0        
 ,@update_string nvarchar(4000) = NULL-- update T_SQL        
 ,@child_update_string nvarchar(max) ='' -- update T_SQL for child tables.        
    
 ,@Totals_Bucket0 Bucket_ID = NULL        
 ,@Totals_Currency_Type0 CurrencyType = NULL         
 ,@Totals_Batch0 int = NULL -- Batch id number.        
 ,@Totals_BumpBy0 int = NULL        
 ,@Totals_Amount0 money = NULL        
         
 ,@Totals_Bucket1 Bucket_ID = NULL        
 ,@Totals_Currency_Type1 CurrencyType = NULL         
 ,@Totals_Batch1 int = NULL        
 ,@Totals_BumpBy1 int = NULL        
 ,@Totals_Amount1 money =NULL        
         
 ,@Totals_Bucket2 Bucket_ID = NULL        
 ,@Totals_Currency_Type2 CurrencyType = NULL         
 ,@Totals_Batch2 int = NULL        
 ,@Totals_BumpBy2 int = NULL        
 ,@Totals_Amount2 money =NULL        
 ,@Totals_Bucket3 Bucket_ID = NULL        
 ,@Totals_Currency_Type3 CurrencyType = NULL         
 ,@Totals_Batch3 int = NULL        
 ,@Totals_BumpBy3 int = NULL        
 ,@Totals_Amount3 money =NULL        
 ,@Totals_Bucket4 Bucket_ID = NULL        
 ,@Totals_Currency_Type4 CurrencyType = NULL         
 ,@Totals_Batch4 int = NULL        
 ,@Totals_BumpBy4 int = NULL        
 ,@Totals_Amount4 money =NULL        
        
 ,@Totals_Bucket5 Bucket_ID = NULL        
 ,@Totals_Currency_Type5 CurrencyType = NULL         
 ,@Totals_Batch5 int = NULL        
 ,@Totals_BumpBy5 int = NULL        
 ,@Totals_Amount5 money =NULL        
        
 ,@Totals_Bucket6 Bucket_ID = NULL        
 ,@Totals_Currency_Type6 CurrencyType = NULL         
 ,@Totals_Batch6 int = NULL        
 ,@Totals_BumpBy6 int = NULL        
 ,@Totals_Amount6 money =NULL        
        
 ,@Totals_Bucket7 Bucket_ID = NULL        
 ,@Totals_Currency_Type7 CurrencyType = NULL         
 ,@Totals_Batch7 int = NULL        
 ,@Totals_BumpBy7 int = NULL        
 ,@Totals_Amount7 money =NULL        
        
 ,@Totals_Bucket8 Bucket_ID = NULL        
 ,@Totals_Currency_Type8 CurrencyType = NULL         
 ,@Totals_Batch8 int = NULL        
 ,@Totals_BumpBy8 int = NULL        
 ,@Totals_Amount8 money =NULL        
        
 ,@Totals_Bucket9 Bucket_ID = NULL        
 ,@Totals_Currency_Type9 CurrencyType = NULL         
 ,@Totals_Batch9 int = NULL        
 ,@Totals_BumpBy9 int = NULL        
 ,@Totals_Amount9 money =NULL        
        
 ,@Totals_Bucket10 Bucket_ID = NULL        
 ,@Totals_Currency_Type10 CurrencyType = NULL         
 ,@Totals_Batch10 int = NULL        
 ,@Totals_BumpBy10 int = NULL        
 ,@Totals_Amount10 money =NULL        
        
 ,@Totals_Bucket11 Bucket_ID = NULL        
 ,@Totals_Currency_Type11 CurrencyType = NULL         
 ,@Totals_Batch11 int = NULL        
 ,@Totals_BumpBy11 int = NULL        
 ,@Totals_Amount11 money =NULL        
        
 ,@Totals_Bucket12 Bucket_ID = NULL        
 ,@Totals_Currency_Type12 CurrencyType = NULL         
 ,@Totals_Batch12 int = NULL        
 ,@Totals_BumpBy12 int = NULL        
 ,@Totals_Amount12 money =NULL        
        
 ,@Totals_Bucket13 Bucket_ID = NULL        
 ,@Totals_Currency_Type13 CurrencyType = NULL         
 ,@Totals_Batch13 int = NULL        
 ,@Totals_BumpBy13 int = NULL        
 ,@Totals_Amount13 money =NULL        
        
 ,@Totals_Bucket14 Bucket_ID = NULL        
 ,@Totals_Currency_Type14 CurrencyType = NULL         
 ,@Totals_Batch14 int = NULL        
 ,@Totals_BumpBy14 int = NULL        
 ,@Totals_Amount14 money =NULL      
       
 ,@DenomType varchar(4000) =NULL     
 ,@DenomValue varchar(4000) =NULL        
 ,@DenomCurrency varchar(4000) =NULL        
 ,@DenomAmount varchar(4000) =NULL 
 ,@NewUser_number  internal_user_ID = NULL
 ,@NewCashDrawer  CashDrawerNumber = NULL
 ,@debug int = 0        
as        
-- New version of update_totals_array        
-- Update existing totals buckets or insert new ones.        
-- Then set CashDrawer.HasCountedCash OFF.         
-- Then run the Journal update.        
-- All of this is wrapped in a database transaction - All updates are applied or NONE.        
-- Copyright 2008 Getronics USA Inc.  All rights reserved.        
-- 23JUL08 JuanJ - Added @update_children_string to allow updates in Child tables.        
--   in replacement of update_totals_array when VB code elimination completed        
-- 31JUL08 JuanJ - Changed parameters name to match FieldLists names.        
-- 11AUG08 Bodhi - Added tests of @@trancount to avoid updates outside of transactions.         
-- 26AUG08 JuanJ - Only set CashDrawer.HasCountedCash OFF when CashIn /Cash out Bucket.        
-- 04Jul11 mfarouk - Add new parameters (@DenomType,@DenomValue,@DenomCurrency,@DenomAmount) for denomination to be used in calling procedure UpdateCashDrawerDetails      
-- 26Oct11 mfarouk - correct parameteres passed to UpdateCashDrawerDetails    
-- 15Dec12 Asmaa Hafez - change parameteres passed to UpdateCashDrawerDetails from (BrID) to (Bank - Region - Branch)  - CR # 7305    
-- 2014-07-21: Osama Orabi: Issue# GFSX07456: 2.0.46.1319. Enhance the performane by passing the BrID to write to Totals Directly instead of Totlas_2 or V_Old_Totals    
-- 2020-08-12 : Ahmed Osman	: CR GFSY00804 : Replace param @user_number with @NewUser_number and replace @CashDrawer with @NewCashDrawer 
--				in passing params on proc update totals and cash drawers , we send the same data the default behaviour and we change the data in case the supervisor post the transaction from override request
    
set nocount on  
      
IF (@NewUser_number IS NULL)
BEGIN
	SET @NewUser_number = @user_number
END

IF (@NewCashDrawer IS NULL)
BEGIN
	SET @NewCashDrawer = @CashDrawer
END

DECLARE @BrID hierarchy_node#;    
SELECT @BrID = dbo.id_of_branch(@Bank,@Region,@Branch)   ;    
    
declare  @BucketID  Bucket_ID, @Amount money, @ctype CurrencyType        
 , @Batch int, @Count int        
declare @sql nvarchar(4000), @param_defs nvarchar(255)        
declare @where nvarchar(400)        
declare @day tinyint        
declare @table_name sysname, @suffix char(7)        
declare @result int, @err int        
--** CR17385 ** S        
declare @IsCashIN_OUTBucket bit        
set @IsCashIN_OUTBucket=0        
--** CR17385 ** E        
set @param_defs         
  = N'@bk BankID, @r RegionID, @br BranchID, @u internal_user_ID,        
  @Seq int, @day tinyint, @ym smallint'        
set @day = @BusinessDate_Day        
set @sql = N'SET NOCOUNT ON' +CHAR(10)+ @update_string+N'        
where user_number = @u        
and JNLSequence = @Seq        
and year_month = @ym        
and BusinessDate_Day = @day        
and Branch = @br        
and Region = @r        
and Bank = @bk'        
SET XACT_ABORT ON        
BEGIN TRAN GJ        
if @debug > 1        
 SELECT @Totals_Bucket0 b0, @Totals_Bucket1 b1, @Totals_Bucket2 b2, @Totals_Bucket3 b3, @Totals_Bucket4 b4, @Totals_Bucket5 b5, @Totals_Bucket6 b6        
        
set @result = 0        
-- call update cashdrawer details in case tran has denom detail      
if @DenomType is Not Null      
Begin     
      
 --declare @BrID varchar(10)    
 --select @BrID = CONVERT(Varchar,dbo.id_of_branch(@Bank,@Region,@Branch))     
    
 exec @result = dbo.UpdateCashDrawerDetails @Bank,@Region,@Branch,@NewCashDrawer,@DenomCurrency      
            ,@DenomAmount      
            ,@DenomType      
            ,@DenomValue      
                
 set @err = @@error        
 if @result <> 0 or @err <> 0       
 begin        
  rollback tran GJ        
  return @result       
 end      
End      
      
if @Totals_Bucket0 is not null BEGIN        
--** CR17385 ** S        
--Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
  if (@IsCashIN_OUTBucket=0)        
 set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket0)        
--** CR17385 ** E        
  exec @result = dbo.write_totals        
  @Bank        
 ,@Region        
 ,@Branch        
 ,@NewUser_number        
 ,@BusinessDate        
 ,@NewCashDrawer        
 ,@Correction        
 ,@Totals_Bucket0        
 ,@Totals_Amount0        
 ,@Totals_Currency_Type0        
 ,@Totals_Batch0        
 ,@Totals_BumpBy0        
 ,@debug    
 , @BrID    
  set @err = @@error        
  if @result <> 0 or @err <> 0 begin        
 rollback tran GJ        
 return @result        
  end        
        
  if @Totals_Bucket1 is not null begin        
 --** CR17385 ** S        
 --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
 if (@IsCashIN_OUTBucket=0)        
  set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket1)        
 --** CR17385 ** E        
 exec @result = dbo.write_totals        
   @Bank        
  ,@Region        
  ,@Branch        
  ,@NewUser_number        
  ,@BusinessDate        
  ,@NewCashDrawer        
  ,@Correction        
  ,@Totals_Bucket1        
  ,@Totals_Amount1        
  ,@Totals_Currency_Type1        
  ,@Totals_Batch1        
  ,@Totals_BumpBy1        
  ,@debug        
  , @BrID    
 set @err = @@error        
 if @result <> 0 or @err <> 0 begin        
  rollback tran GJ        
  return @result        
 end        
 if @Totals_Bucket2 is not null begin        
  --** CR17385 ** S        
  --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
  if (@IsCashIN_OUTBucket=0)        
   set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket2)        
  --** CR17385 ** E        
  exec @result = dbo.write_totals        
    @Bank        
   ,@Region        
   ,@Branch        
   ,@NewUser_number        
   ,@BusinessDate        
   ,@NewCashDrawer        
   ,@Correction        
   ,@Totals_Bucket2        
   ,@Totals_Amount2        
   ,@Totals_Currency_Type2        
   ,@Totals_Batch2        
   ,@Totals_BumpBy2        
   ,@debug        
   , @BrID    
  set @err = @@error        
  if @result <> 0 or @err <> 0 begin        
   rollback tran GJ        
   return @result        
  end        
  if @Totals_Bucket3 is not null begin        
   --** CR17385 ** S        
   --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
   if (@IsCashIN_OUTBucket=0)        
    set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket3)        
   --** CR17385 ** E        
   exec @result = dbo.write_totals        
     @Bank        
    ,@Region        
    ,@Branch        
    ,@NewUser_number        
    ,@BusinessDate        
    ,@NewCashDrawer        
    ,@Correction        
    ,@Totals_Bucket3        
    ,@Totals_Amount3        
    ,@Totals_Currency_Type3        
    ,@Totals_Batch3        
    ,@Totals_BumpBy3        
    ,@debug        
 , @BrID    
   set @err = @@error        
   if @result <> 0 or @err <> 0 begin        
    rollback tran GJ        
    return @result        
   end        
           
   if @Totals_Bucket4 is not null begin        
    --** CR17385 ** S        
    --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
    if (@IsCashIN_OUTBucket=0)        
     set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket4)        
    --** CR17385 ** E        
    exec @result = dbo.write_totals        
      @Bank        
     ,@Region        
     ,@Branch        
     ,@NewUser_number        
     ,@BusinessDate        
     ,@NewCashDrawer        
     ,@Correction        
     ,@Totals_Bucket4        
     ,@Totals_Amount4        
     ,@Totals_Currency_Type4        
     ,@Totals_Batch4        
     ,@Totals_BumpBy4        
     ,@debug        
  , @BrID    
    set @err = @@error        
    if @result <> 0 or @err <> 0 begin        
     rollback tran GJ        
     return @result        
    end        
    if @Totals_Bucket5 is not null begin        
     --** CR17385 ** S        
     --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
     if (@IsCashIN_OUTBucket=0)        
     set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket5)        
     --** CR17385 ** E        
     exec @result = dbo.write_totals        
       @Bank        
      ,@Region        
      ,@Branch        
      ,@NewUser_number        
      ,@BusinessDate        
      ,@NewCashDrawer        
      ,@Correction        
      ,@Totals_Bucket5        
      ,@Totals_Amount5        
      ,@Totals_Currency_Type5        
      ,@Totals_Batch5        
      ,@Totals_BumpBy5        
      ,@debug        
   , @BrID    
     set @err = @@error        
     if @result <> 0 or @err <> 0 begin        
      rollback tran GJ        
  return @result        
     end        
     if @Totals_Bucket6 is not null begin        
      --** CR17385 ** S        
      --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
      if (@IsCashIN_OUTBucket=0)        
       set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket6)        
      --** CR17385 ** E        
      exec @result = dbo.write_totals        
        @Bank        
       ,@Region        
       ,@Branch        
       ,@NewUser_number        
       ,@BusinessDate        
       ,@NewCashDrawer        
       ,@Correction        
       ,@Totals_Bucket6        
       ,@Totals_Amount6        
       ,@Totals_Currency_Type6        
       ,@Totals_Batch6        
       ,@Totals_BumpBy6        
       ,@debug        
    , @BrID    
      set @err = @@error        
      if @result <> 0 or @err <> 0 begin        
       rollback tran GJ        
       return @result        
      end        
      if @Totals_Bucket7 is not null begin        
       --** CR17385 ** S        
       --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
       if (@IsCashIN_OUTBucket=0)        
        set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket7)        
       --** CR17385 ** E        
       exec @result = dbo.write_totals        
         @Bank        
        ,@Region        
        ,@Branch        
        ,@NewUser_number        
        ,@BusinessDate        
        ,@NewCashDrawer        
        ,@Correction        
        ,@Totals_Bucket7        
        ,@Totals_Amount7        
        ,@Totals_Currency_Type7        
        ,@Totals_Batch7        
        ,@Totals_BumpBy7        
        ,@debug        
  , @BrID    
       set @err = @@error        
       if @result <> 0 or @err <> 0 begin        
        rollback tran GJ        
        return @result        
       end        
       if @Totals_Bucket8 is not null begin        
        --** CR17385 ** S        
        --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
        if (@IsCashIN_OUTBucket=0)        
         set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket8)        
        --** CR17385 ** E        
        exec @result = dbo.write_totals        
          @Bank        
         ,@Region        
         ,@Branch        
         ,@NewUser_number        
         ,@BusinessDate        
         ,@NewCashDrawer        
         ,@Correction        
         ,@Totals_Bucket8        
         ,@Totals_Amount8        
         ,@Totals_Currency_Type8        
         ,@Totals_Batch8        
         ,@Totals_BumpBy8        
         ,@debug        
   , @BrID    
        set @err = @@error        
        if @result <> 0 or @err <> 0 begin        
         rollback tran GJ        
         return @result        
        end        
        if @Totals_Bucket9 is not null begin        
         --** CR17385 ** S        
         --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
         if (@IsCashIN_OUTBucket=0)        
          set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket9)        
        --** CR17385 ** E 
         exec @result = dbo.write_totals        
           @Bank        
          ,@Region        
          ,@Branch        
          ,@NewUser_number        
          ,@BusinessDate        
          ,@NewCashDrawer        
          ,@Correction        
          ,@Totals_Bucket9        
          ,@Totals_Amount9        
          ,@Totals_Currency_Type9        
          ,@Totals_Batch9        
          ,@Totals_BumpBy9        
          ,@debug        
    , @BrID    
         set @err = @@error        
         if @result <> 0 or @err <> 0 begin        
          rollback tran GJ        
          return @result        
         end        
         if @Totals_Bucket10 is not null begin        
          --** CR17385 ** S        
          --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
          if (@IsCashIN_OUTBucket=0)        
           set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket10)        
          --** CR17385 ** E        
          exec @result = dbo.write_totals        
            @Bank        
           ,@Region        
           ,@Branch        
           ,@NewUser_number        
           ,@BusinessDate        
           ,@NewCashDrawer        
           ,@Correction        
           ,@Totals_Bucket10        
           ,@Totals_Amount10        
           ,@Totals_Currency_Type10        
           ,@Totals_Batch10        
           ,@Totals_BumpBy10        
           ,@debug        
     , @BrID    
          set @err = @@error        
          if @result <> 0 or @err <> 0 begin        
           rollback tran GJ        
           return @result        
          end        
          if @Totals_Bucket11 is not null begin        
           --** CR17385 ** S        
           --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
           if (@IsCashIN_OUTBucket=0)        
            set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket11)        
           --** CR17385 ** E        
           exec @result = dbo.write_totals        
             @Bank        
            ,@Region        
            ,@Branch        
            ,@NewUser_number        
            ,@BusinessDate        
            ,@NewCashDrawer        
            ,@Correction        
            ,@Totals_Bucket11        
            ,@Totals_Amount11        
            ,@Totals_Currency_Type11        
            ,@Totals_Batch11        
            ,@Totals_BumpBy11        
            ,@debug        
   , @BrID    
           set @err = @@error        
           if @result <> 0 or @err <> 0 begin        
            rollback tran GJ        
            return @result        
           end        
           if @Totals_Bucket12 is not null begin        
            --** CR17385 ** S        
            --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
            if (@IsCashIN_OUTBucket=0)        
             set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket12)        
            --** CR17385 ** E        
            exec @result = dbo.write_totals        
              @Bank        
             ,@Region        
             ,@Branch        
             ,@NewUser_number        
             ,@BusinessDate        
             ,@NewCashDrawer        
             ,@Correction        
             ,@Totals_Bucket12        
             ,@Totals_Amount12        
             ,@Totals_Currency_Type12        
             ,@Totals_Batch12        
             ,@Totals_BumpBy12        
   ,@debug        
   , @BrID    
            set @err = @@error        
            if @result <> 0 or @err <> 0 begin        
             rollback tran GJ        
             return @result        
            end        
            if @Totals_Bucket13 is not null begin        
             --** CR17385 ** S        
             --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
             if (@IsCashIN_OUTBucket=0)        
              set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket13)        
             --** CR17385 ** E        
             exec @result = dbo.write_totals        
               @Bank        
              ,@Region        
              ,@Branch        
              ,@NewUser_number        
              ,@BusinessDate        
              ,@NewCashDrawer        
              ,@Correction        
              ,@Totals_Bucket13        
              ,@Totals_Amount13        
              ,@Totals_Currency_Type13        
              ,@Totals_Batch13        
              ,@Totals_BumpBy13        
              ,@debug        
     , @BrID    
             set @err = @@error        
             if @result <> 0 or @err <> 0 begin        
              rollback tran GJ        
              return @result        
             end        
             if @Totals_Bucket14 is not null begin        
              --** CR17385 ** S        
              --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
              if (@IsCashIN_OUTBucket=0)        
               set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket14)        
              --** CR17385 ** E        
              exec @result = dbo.write_totals        
                @Bank        
               ,@Region        
               ,@Branch        
               ,@NewUser_number        
               ,@BusinessDate        
               ,@NewCashDrawer        
               ,@Correction        
               ,@Totals_Bucket14        
               ,@Totals_Amount14        
               ,@Totals_Currency_Type14        
               ,@Totals_Batch14        
               ,@Totals_BumpBy14        
               ,@debug        
      , @BrID    
              set @err = @@error        
              if @result <> 0 or @err <> 0 begin        
               rollback tran GJ        
               return @result        
              end        
             end        
            end        
   end        
          end        
         end        
        end        
       end        
      end        
     end        
    end        
   end        
  end        
 end        
  end        
 --** CR17385 ** S        
 IF @@TRANCOUNT > 0 and @IsCashIN_OUTBucket=1 begin          
   UPDATE dbo.CashDrawer WITH (UPDLOCK ROWLOCK)        
   set  HasCountedCash = 0        
   WHERE AssignedToTeller = @NewUser_number         
  and Bank = @Bank        
  and Region = @Region        
  and Branch = @Branch        
  and CashDrawerNumber = @NewCashDrawer         
  -- and IsActive = 1        
  and HasCountedCash <> 0        
 end        
 --** CR17385 ** E        
end        
        
if @debug > 0 begin -- Put out SQL statements for debugging.        
 print 'declare ' + @param_defs + char(10)         
 print 'select @bk = ' + cast(isnull(@bank,0) as varchar)        
 print '    , @r = ' + cast(isnull(@region, 0) as varchar)        
 print '    , @br = ' + cast(isnull(@branch, 0) as varchar)        
 print '    , @u = ' + cast(isnull(@user_number, 0) as varchar)        
 print '--  , @BusinessDate = ''' + cast(@BusinessDate as varchar) + ''''        
 print '    , @day = ' + cast(@day as varchar)        
 print '    , @ym = ' + cast(@year_month as varchar)        
 print '    , @Seq = '+ cast(isnull(@JNLSequence, 0) as varchar)        
 print isnull(@sql, '-NULL-')        
end        
        
IF @@TRANCOUNT > 0 AND @update_string is not null begin        
 exec @result = dbo.sp_executesql @sql, @param_defs        
 , @bank, @region, @branch, @user_number        
 , @JNLSequence, @day, @year_month        
 set @err = @@error        
 if @err <> 0 or @result <> 0 begin        
  rollback tran GJ        
  return @err        
 end        
end        
IF @@TRANCOUNT > 0 AND  @child_update_string<>'' begin        
 exec @result = dbo.sp_executesql @child_update_string, N''        
 set @err = @@error        
 if @err <> 0 or @result <> 0 begin        
  rollback tran GJ        
  return @err        
 end        
end        
IF @@TRANCOUNT > 0        
  COMMIT TRAN GJ        
        
RETURN @result 


--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[07/10/2020]		
--Reason	:	Enh GFSY00825 - BARWA - ACM18642 CRS Changes
--==========================================================

PRINT 'Start. Script for CR# GFSY00825 Proc Script - dbo.Check_IsoCode_In_ad_gb_country'
GO

drop_old_proc 'Check_IsoCode_In_ad_gb_country'
GO
create proc dbo.Check_IsoCode_In_ad_gb_country		--Check_IsoCode_In_ad_gb_country 'EG'
@ISO_CODE char(2)
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[07/10/2020]		
	Reason		:	Enh GFSY00825 - BARWA - ACM18642 CRS Changes
	Description	:	Check that is the sender iso code is one of countries that allow crs participate
*/          

If Exists(Select * From ad_gb_country Where ISO_Code = @ISO_CODE AND crs_participate = 'Y')
	Begin
		SELECT 'Y'
	END
ELSE
	BEGIN
		SELECT 'N'	
	END
GO

PRINT 'End... Script for CR# GFSY00825 Proc Script - dbo.Check_IsoCode_In_ad_gb_country'
GO
Drop_old_proc IRBulkInsertIntoIR     
  go

CREATE PROCEDURE dbo.IRBulkInsertIntoIR 
    @Table IRBulkTableType READONLY    
    AS    
/*      
CreationDate: 2017-5-31     
OriginalName: dbo.IRBulkInsertIntoIR      
Programmer  : Karim Mahmoud
Description : Bulk Insert rows in IR Table 

Reason: GFSY00717 - Add 2 column FLD_111,FLD_121
Developer: Nada Elshafie
Modification date: 14Aug2018

Reason: GFSY00807 - Save Credit Rim Number
Developer: Ahmed Osman
Modification date: 01/08/2020 Enh - BARWA - ACM18595 Inward Transfers
*/   
BEGIN TRY  
    BEGIN TRANSACTION   
       INSERT INTO IR
        (        
			 FileRefNo,        
			 FilePathName,       
			 MsgRefNo,        
			 StatusID,        
			 ActionId,        
			 PaymentMethodID,        
			 DateTimeStamp,        
			 PreparedBy,        
			 MsgValueDate,        
			 ValueDate,        
			 DrAccountNo,        
			 DrAccountNo_AcctType,      
			 DrAccountNo_ApplType,      
			 DrAccountNo_DepLoan,      
			 DrAccountName,        
			 DrCurrency,        
			 DrAmount,        
			 DrAddress,        
			 SenderBank,        
			 DrExchangeRate,        
			 DrCommission,        
			 CrAccountNo,        
			 CrAccountNo_AcctType,     
			 CrAccountNo_ApplType,      
			 CrAccountNo_DepLoan,      
			 CrAccountName,        
			 CrCurrency,        
			 CrAmount,        
			 CrAddress,        
			 OrderingCustomer,        
			 CrExchangeRate,        
			 CrCommission,        
			 OriginalMsg,        
			 Fld_50K,        
			 Fld_59,        
			 Charge_Det,       
			 Account_With_Ref,    
			 Account_With_Ac,    
			 Account_With_Name,    
			 ValueCurrency,    
			 Order_Cust_Name,    
			 Order_Cust_Add1,    
			 Order_Cust_Add2,    
			 Order_Inst,    
			 Order_Inst_Name,    
			 Order_Inst_Add1,    
			 BeneficiaryAccount,    
			 FLD_70,    
			 FLD_71A,    
			 BeneficiaryName,    
			 BeneficiaryAddress,    
			 Updator,    
			 DrValueDate,    
			 CrValueDate,    
			 DrNarrative,    
			 CrNarrative,    
			 FLD_20,    
			 FLD_23,    
			 FLD_33,    
			 FLD_52,    
			 FLD_53,    
			 MsgType,    
			 ExceptionList,    
			 Is_FLD_20_Duplicate,    
			 DrRealExchangeRate,    
			 CrRealExchangeRate,     
			 TTAmount ,    
			 TTCurrency ,    
			 DrSellExchangeRate,    
			 CrBuyExchangeRate ,  
			 IBAN   ,    
			 Ordering_IBAN,    
			 Sender_BIC,    
			 CrRimNo,  
			 Ben_Inst_BIC,
			 FLD_111,
			 FLD_121 
		)       
		SELECT 
		
			 irbt.FileRefNo,        
			 irbt.FilePathName,        
			 irbt.MsgRefNo,        
			 irbt.StatusID,        
			 irbt.ActionId,        
			 irbt.PaymentMethodID,        
			 irbt.DateTimeStamp,        
			 irbt.PreparedBy,        
			 irbt.MsgValueDate,        
			 irbt.ValueDate,        
			 irbt.DrAccountNo,        
			 irbt.DrAccountNo_AcctType,      
			 irbt.DrAccountNo_ApplType,      
			 irbt.DrAccountNo_DepLoan,      
			 irbt.DrAccountName,        
			 irbt.DrCurrency,       
			 irbt.DrAmount,        
			 irbt.DrAddress,        
			 irbt.SenderBank,        
			 irbt.DrExchangeRate,        
			 irbt.DrCommission,        
			 irbt.CrAccountNo,      
			 irbt.CrAccountNo_AcctType,      
			 irbt.CrAccountNo_ApplType,      
			 irbt.CrAccountNo_DepLoan,       
			 irbt.CrAccountName,        
			 irbt.CrCurrency,     
			 irbt.CrAmount,        
			 irbt.CrAddress,        
			 irbt.OrderingCustomer,        
			 irbt.CrExchangeRate,        
			 irbt.CrCommission,        
			 irbt.OriginalMsg,        
			 irbt.Fld_50K,        
			 irbt.Fld_59,        
			 irbt.Charge_Det,    
			 irbt.Account_With_Ref,    
			 irbt.Account_With_Ac,    
			 irbt.Account_With_Name,    
			 irbt.ValueCurrency,    
			 irbt.Order_Cust_Name,    
			 irbt.Order_Cust_Add1,    
			 irbt.Order_Cust_Add2,    
			 irbt.Order_Inst,    
			 irbt.Order_Inst_Name,    
			 irbt.Order_Inst_Add1,    
			 irbt.BeneficiaryAccount,    
			 irbt.FLD_70,     
			 irbt.FLD_71A,    
			 irbt.BeneficiaryName,    
			 irbt.BeneficiaryAddress,    
			 irbt.Updator,  
			 irbt.DB_DrValueDate,   
			 irbt.DB_CrValueDate,    
			 irbt.DB_DrNarrative,    
			 irbt.DB_CrNarrative,    
			 irbt.DB_FLD_20,    
			 irbt.DB_FLD_23,    
			 irbt.DB_FLD_33,    
			 irbt.DB_FLD_52,    
			 irbt.DB_FLD_53,    
			 irbt.MsgType,    
			 irbt.ExceptionList,    
			 irbt.Is_FLD_20_Duplicate,    
			 irbt.DrRealExchangeRate,        
			 irbt.CrRealExchangeRate,    
			 irbt.TTAmount,    
			 irbt.TTCurrency,    
			 irbt.DrSellExchangeRate,    
			 irbt.CrBuyExchangeRate,  
			 irbt.IBAN,  
			 irbt.Ordering_IBAN,    
			 irbt.Sender_BIC,   
			 irbt.CrRimNo, --'',--CrRimNo varchar(100),  
			 '',--Ben_Inst_BIC varchar(100)
			 irbt.FLD_111,
			 irbt.FLD_121  
		
		FROM @Table irbt
    COMMIT  
END TRY  
BEGIN CATCH  
  
    IF @@TRANCOUNT > 0  
        ROLLBACK  
    return -1;
END CATCH  
  
GO

drop_old_proc InsertIntoLocalInwardMessages
GO
CREATE PROC dbo.InsertIntoLocalInwardMessages
@MSGID	varchar(35),
@MSGName	varchar(36),
@CreationDateTime	datetime,
@NumberofTrans	int,
@TotalInterbankSettCCY	char(3),
@TotalInterbankSettAMT	money,
@InterBankSettDate	date,
@SettlementMethod	varchar(35),
@Proprietary	varchar(35),
@InstructionPriority_hdr	varchar(35),
@ClearingChannel_hdr	varchar(35),
@CategoryPurpose_hdr	varchar(35),
@InstructionIdentification	varchar(35),
@EndtoEndIdentification	varchar(35),
@TranIdentification	varchar(35),
@InstructionPriority_tran	varchar(35),
@ClearingChannel_tran	varchar(35),
@CategoryPurpose_tran	varchar(35),
@InterbankSettCCY	char(3),
@InterbankSettAMT	money,
@ChargeBearer	varchar(35),
@Debtor	nvarchar(240),
@DebtorAccount	varchar(60),
@DebtorAgent	varchar(12),
@DebtorAgentAccount	varchar(60),
@CreditorAgent	varchar(12),
@CreditorAgentAccount	varchar(60),
@Creditor	nvarchar(240),
@CreditorAccount	varchar(60),
@Purpose	int,
@RemittanceInformation	varchar(140),
@DebtorAgentBIC	varchar(12),
@CreditorAgentBIC	varchar(12),
@Queue	int,
@Status	int,
@ExceptionReason	int,
@IsHolded           bit,
@NameMatchPercent	varchar(5)


as      

/* Version = '1.61.1524.16702' , Modification Date = '2012/08/23 - 19:67 ' */      

/*  

ModifiedDate: 23-08-2015

Modifer  : Nada Elshafie    

ModifyReason: Adding Local Inward Message  

-----------------------------------------

ModifiedDate: 26-02-2016

Modifer  : Karim Mahmoud    

ModifyReason: Adding Name Matching Percent  

-----------------------------------------
ModifiedDate: 23-12-2019

Modifer  :  Mahmoud  Saad

ModifyReason:Fixing issue GFSX13892 

----------------------------------------
ModifiedDate: 28-09-2020

Modifer  : Mostafa Helmy    

ModifyReason: Adding IsHolded - GFSY00823 

*/  

set nocount on

IF NOT EXISTS(SELECT * FROM Local_Inward_Messages_Header where MSGID=@MSGID)
BEGIN
insert into Local_Inward_Messages_Header
(
MSGID,
MSGName,
CreationDateTime,
NumberofTrans,
TotalInterbankSettCCY,
TotalInterbankSettAMT,
InterBankSettDate,
SettlementMethod,
Proprietary,
InstructionPriority_hdr,
ClearingChannel_hdr,
CategoryPurpose_hdr)
values
(
@MSGID	,
@MSGName	,
@CreationDateTime	,
@NumberofTrans	,
@TotalInterbankSettCCY	,
@TotalInterbankSettAMT	,
@InterBankSettDate	,
@SettlementMethod	,
@Proprietary	,
@InstructionPriority_hdr	,
@ClearingChannel_hdr	,
@CategoryPurpose_hdr
)
END

insert into Local_Inward_Messages_Detail
(
MSGID,
InstructionIdentification,
EndtoEndIdentification,
TranIdentification,
InstructionPriority_tran,
ClearingChannel_tran,
CategoryPurpose_tran,
InterbankSettCCY,
InterbankSettAMT,
ChargeBearer,
Debtor,
DebtorAccount,
DebtorAgent,
DebtorAgentAccount,
CreditorAgent,
CreditorAgentAccount,
Creditor,
CreditorAccount,
Purpose,
RemittanceInformation,
Queue,
Status,
ExceptionReason,
NameMatchPercent,
IsHolded
)
values
(
@MSGID	,
@InstructionIdentification	,
@EndtoEndIdentification	,
@TranIdentification	,
@InstructionPriority_tran	,
@ClearingChannel_tran	,
@CategoryPurpose_tran	,
@InterbankSettCCY	,
@InterbankSettAMT	,
@ChargeBearer	,
@Debtor	,
@DebtorAccount	,
case when @DebtorAgent is  null then @DebtorAgentBIC else  @DebtorAgent end,
@DebtorAgentAccount	,
case when @CreditorAgent is null then @CreditorAgentBIC else @CreditorAgent end,
@CreditorAgentAccount	,
@Creditor	,
@CreditorAccount	,
@Purpose	,
@RemittanceInformation	,
@Queue	,
@Status	,
@ExceptionReason,
@NameMatchPercent,
@IsHolded
)      

GO
drop_old_proc SelectLocalInwardMsgs
GO
CREATE PROC dbo.SelectLocalInwardMsgs
@Queue	int,
@Status	int
AS
/*  

ModifiedDate: 26-08-2015

Modifer  : Nada Elshafie    

ModifyReason: select Local Inward Messages 

------------------------------------------

ModifiedDate: 26-02-2016

Modifer  : Karim Mahmoud    

ModifyReason: select Exception reason and Name Matching Percent also in case exception

-------------------------------------------
ModifiedDate: 04-08-2020

Modifer  : Mostafa Helmy    

ModifyReason: select Exception reason Code,InterBankSettDate - GFSY00806
-------------------------------------------
ModifiedDate: 28-09-2020

Modifer  : Mostafa Helmy    

ModifyReason: select IsHolded - GFSY00823

*/  

if(@Queue=2)--Exception
	begin
		Select
		D.MSGID as TLR_PDC_CHG_AC_NUMBER, 
		TranIdentification as TLR_PDC_DR_AC_NUMBER,
		Creditor as TLR_PDC_COR_NAME, 
		InterbankSettCCY as TLR_PDC_COR_DIRECT_OPT_DSC,
		InterbankSettAMT as TLR_BILL_AMOUNT,
		CreditorAccount as TLR_PDC_DEST_BK_NAME,
		Debtor as TLR_PDC_DEST_BK_ACCT,
		MSGName as TLR_PDC_DEST_BK_COUNTRY, 
		CreationDateTime as TLR_SC_Cheque_DATE_ARR,
		RemittanceInformation as TLR_PDC_DEST_DETAILS,
		Purpose as TLR_PDC_COR_ID,
		D.Status as TLR_PDC_COR_DIRECT_OPT,
		Queue as TLR_PDC_CLEAR_BANK_BRANCH_ID,
		EndtoEndIdentification as EndtoEndId,
		DebtorAgent as DebtorAgent,
		CreditorAgent as CreditorAgent,
		Status.LongDescription as TLR_PDC_DEST_ADDRESS1,
		ISNULL(NameMatchPercent,'') as TLR_PDC_DEST_ADDRESS2,
		ISNULL(RejectionReason,'') as TLR_PDC_DEST_INSTRUCTIONS,
		D.ExceptionReason,
		ISNULL(D.ReferenceNumber,'') as TLR_PDC_TYPR_STATUS_DESC,
		H.InterBankSettDate,
		D.IsHolded as TLR_SELECTION
		from Local_Inward_Messages_Header H
		inner join Local_Inward_Messages_Detail D
		on H.MSGID=D.MSGID
		inner join Status
		on Status.id=D.ExceptionReason
		where Queue=@Queue and D.status=@Status and Status.StatusTypeID=72
	end
else
	begin
		Select
		D.MSGID as TLR_PDC_CHG_AC_NUMBER, 
		TranIdentification as TLR_PDC_DR_AC_NUMBER,
		Creditor as TLR_PDC_COR_NAME, 
		InterbankSettCCY as TLR_PDC_COR_DIRECT_OPT_DSC,
		InterbankSettAMT as TLR_BILL_AMOUNT,
		CreditorAccount as TLR_PDC_DEST_BK_NAME,
		Debtor as TLR_PDC_DEST_BK_ACCT,
		MSGName as TLR_PDC_DEST_BK_COUNTRY, 
		CreationDateTime as TLR_SC_Cheque_DATE_ARR,
		RemittanceInformation as TLR_PDC_DEST_DETAILS,
		Purpose as TLR_PDC_COR_ID,
		Status as TLR_PDC_COR_DIRECT_OPT,
		Queue as TLR_PDC_CLEAR_BANK_BRANCH_ID,
		EndtoEndIdentification as EndtoEndId,
		DebtorAgent as DebtorAgent,
		CreditorAgent as CreditorAgent,
		NULL as TLR_PDC_DEST_ADDRESS1,
		ISNULL(NameMatchPercent,'') as TLR_PDC_DEST_ADDRESS2,
		ISNULL(RejectionReason,'') as TLR_PDC_DEST_INSTRUCTIONS,
		D.ExceptionReason,
		ISNULL(D.ReferenceNumber,'') as TLR_PDC_TYPR_STATUS_DESC,
		H.InterBankSettDate,
		D.IsHolded as TLR_SELECTION
		from Local_Inward_Messages_Header H
		inner join Local_Inward_Messages_Detail D
		on H.MSGID=D.MSGID
		where Queue=@Queue and status=@Status --and  H.InterBankSettDate<=@BusinessDate
	end
GO
drop_old_proc UpdateLocalInwardMsgs
GO
CREATE PROC dbo.UpdateLocalInwardMsgs
@MSGID	varchar(35),
@TranIdentification	varchar(35),
@Purpose	int,
@RemittanceInformation	varchar(140),
@Queue	int,
@Status	int,
@ExceptionReason	int=null,
@RejectionReason  varchar(10)=null,
@ReferenceNumber nvarchar(30)=null,
@IsHolded           bit=0
AS
/*  

ModifiedDate: 31-08-2015

Modifer  : Nada Elshafie    

ModifyReason: Update Local Inward Messages 

------------------------------------------

ModifiedDate: 26-02-2016

Modifer  : Karim Mahmoud  

ModifyReason: Update Rejection reason also 

-------------------------------------------
ModifiedDate: 04-08-2020

Modifer  : Mostafa Helmy    

ModifyReason: Update ReferenceNumber - GFSY00806

-------------------------------------------
ModifiedDate: 27-09-2020

Modifer  : Mostafa Helmy    

ModifyReason: Update IsHolded - GFSY00823

*/  
Declare @OriginalExceptionReason int
select @OriginalExceptionReason=exceptionReason from Local_Inward_Messages_Detail where  MSGID=@MSGID and TranIdentification=@TranIdentification
update Local_Inward_Messages_Detail
set Purpose=@Purpose,
RemittanceInformation=@RemittanceInformation,
Queue=@Queue,
Status=@Status,
ExceptionReason=coalesce(@ExceptionReason,@OriginalExceptionReason),
RejectionReason=@RejectionReason,
ReferenceNumber=@ReferenceNumber,
IsHolded=@IsHolded
where MSGID=@MSGID and TranIdentification=@TranIdentification

GO
--==================================================================================================================================================================
--Devolper	:	Shaimaa AbdelNasser
--Date		:	[13/12/2020]		
--Reason	:	Enh GFSY00831 -  cheque deposit Integration with BCTS
--=====================================================================
  
GO
drop_old_proc 'GetUserInfoByUserName'
go
CREATE  PROCEDURE GetUserInfoByUserName		--exec GetUserInfoByUserName ''
@LoginID nvarchar(40)     
As   
/*   
 Created: 19-11-2020       
 Developer: Shaimaa Abdelnasser
 Description: CR# GFSY00831 - cheque deposit Integration with BCTS
*/
DECLARE @user_Number smallint = null  
DECLARE @brId varchar(10)   = null  
DECLARE @bank smallint    = null  
DECLARE @region smallint    = null  
DECLARE @cashdrawer smallint    = null  
DECLARE @GlNumber varchar(60)   = null  
declare @RequestID int    = null  
Declare @count table(counting INT) 
  
  	 SELECT  @user_Number = Op.User_number,@brId = Cd.Branch ,@bank = Cd.bank, @region= Cd.Region,  
		 @cashdrawer = Cd.CashDrawerNumber,@GlNumber = Gd.GLNumber  
	   FROM
	   Operator  as Op inner join CashDrawer Cd  
	   on  Op.user_number = Cd.AssignedToTeller
	   and Op.BrID		  = Cd.BrID 
	   and cd.IsActive = 1 
	    
	   left join GLDetail Gd   
	   on Cd.CashDrawerNumber  = Gd.OwnerNumber 
	   and  Gd.GLOwnerID = 4
	   
	   WHERE  Op.LoginID =  @LoginID      

		  
INSERT INTO @count EXEC dbo.GetRequestID @user_Number  
SELECT @RequestID =counting FROM @Count As Result

SELECT  @user_Number as User_Number , @brId as Branch , @bank as Bank , @region as Region ,  
    @cashdrawer as CashDrawerNumber  , @GlNumber as GLNumber ,@RequestID as RequestID   

GO
USE Globalfs
go

drop_old_proc EFTS_InsertBiller
GO

create proc EFTS_InsertBiller
@ResponseId int = NULL
,@Code nvarchar(31) = NULL
,@Name nvarchar(max) = NULL
,@Mode nvarchar(10) = NULL
,@Email nvarchar(31) = NULL
,@Phone nvarchar(31) = NULL
,@POBox nvarchar(31) = NULL
,@Address1 nvarchar(31) = NULL
,@Address2 nvarchar(31) = NULL
,@Address3 nvarchar(31) = NULL
,@Id int output

/*
Creator: Motaz Atiya
Date: 27 December, 2016
Reason: Insert EFTS Biller
*/

As

SELECT
	@Id = lastvalue
FROM TableID
WHERE TableName = 'EFTS_Biller';

UPDATE TableID
SET LastValue = @Id + 1
WHERE TableName = 'EFTS_Biller';

INSERT INTO EFTS_Biller (Id
, ResponseId
, Code
, [Name]
, Mode
, Email
, Phone
, POBox
, Address1
, Address2
, Address3)
	VALUES (@Id, @ResponseId, @Code, @Name, @Mode, @Email, @Phone, @POBox, @Address1, @Address2, @Address3);

GO
--Devolper :	Ahmed Osman
--Date       :	[03/10/2019]		
--Reason     :	CR#GFSY00768 - BBK_ACM17813_Enable EFTS Service
--=============================================================
PRINT 'Start. Script for CR# GFSY00768 Proc Script -- EFTS_SELECTALLOWEDAMOUNT'
GO

drop_old_proc 'EFTS_SELECTALLOWEDAMOUNT'
GO
create  Proc dbo.EFTS_SELECTALLOWEDAMOUNT
as                

/*
 CreationDate	:	[03/10/2019]       
 Programmer		:	Ahmed Osman
 Description	:	Insert Into Table EFTS_Participants - CR#GFSY00768
*/   

SELECT * FROM EFTS_ServiceDenomAllowedAmt

GO

PRINT 'End... Script for CR# GFSY00768 Proc Script -- EFTS_SELECTALLOWEDAMOUNT'
GO
--Devolper :	Ahmed Osman
--Date       :	[03/10/2019]		
--Reason     :	CR#GFSY00768 - BBK_ACM17813_Enable EFTS Service
--=============================================================
PRINT 'Start. Script for CR# GFSY00768 Proc Script -- EFTSParticipants_Insert'
GO

drop_old_proc 'EFTSParticipants_Insert'
GO
create  Proc dbo.EFTSParticipants_Insert
@SwiftBIC						varchar(max) = NULL,  
@ParticipantName				varchar(max) = NULL,  
@ParticipantShortName			varchar(max) = NULL,  
@ParticipantCountryName			varchar(max) = NULL,  
@ParticipantAddress				varchar(max) = NULL,  
@ParticipantCity				varchar(max) = NULL,  
@ParticipantItCode				varchar(max) = NULL,  
@ParticipantPtCode				varchar(max) = NULL,  
@ParticipantModifDate			varchar(max) = NULL,  
@ParticipantStatus				varchar(max) = NULL,  
@ParticipantType				varchar(max) = NULL,  
@ParticipantInstitutionName		varchar(max) = NULL,  
@AlternativeBICParticipant		varchar(max) = NULL,  
@BICofParticipant				varchar(max) = NULL,  
@ContactPerson1TelephoneNumber	varchar(max) = NULL,  
@ContactPerson2TelephoneNumber	varchar(max) = NULL,  
@DNSAccountNumber				varchar(max) = NULL,  
@NRTAccountNumber				varchar(max) = NULL
as                

/*
 CreationDate	:	[03/10/2019]       
 Programmer		:	Ahmed Osman
 Description	:	Insert Into Table EFTS_Participants - CR#GFSY00768
*/   

Declare @Id int

SELECT  
 @Id = lastvalue  
FROM TableID  
WHERE TableName = 'EFTS_Participants';  
  
UPDATE TableID  
SET LastValue = @Id + 1  
WHERE TableName = 'EFTS_Participants';  
  
INSERT INTO [Globalfs].[dbo].[EFTS_Participants] (
[Id],
[SwiftBIC],
[ParticipantName],
[ParticipantShortName],
[ParticipantCountryName],
[ParticipantAddress],
[ParticipantCity],
[ParticipantItCode],
[ParticipantPtCode],
[ParticipantModifDate],
[ParticipantStatus],
[ParticipantType],
[ParticipantInstitutionName],
[AlternativeBICParticipant],
[BICofParticipant],
[ContactPerson1TelephoneNumber],
[ContactPerson2TelephoneNumber],
[DNSAccountNumber],
[NRTAccountNumber]
)
 VALUES (
 @Id,
 @SwiftBIC,
 @ParticipantName,
 @ParticipantShortName,
 @ParticipantCountryName,
 @ParticipantAddress,
 @ParticipantCity,
 @ParticipantItCode,
 @ParticipantPtCode,
 @ParticipantModifDate,
 @ParticipantStatus,
 @ParticipantType,
 @ParticipantInstitutionName,
 @AlternativeBICParticipant,
 @BICofParticipant,
 @ContactPerson1TelephoneNumber,
 @ContactPerson2TelephoneNumber,
 @DNSAccountNumber,
 @NRTAccountNumber
 );  
   
GO

PRINT 'End... Script for CR# GFSY00768 Proc Script -- EFTSParticipants_Insert'
GO
--Devolper :	Ahmed Osman
--Date       :	[03/10/2019]		
--Reason     :	CR#GFSY00768 - BBK_ACM17813_Enable EFTS Service
--=============================================================
PRINT 'Start. Script for CR# GFSY00768 Proc Script -- EFTSParticipants_Reset'
GO

drop_old_proc 'EFTSParticipants_Reset'
GO
create  Proc dbo.EFTSParticipants_Reset
as                

/*
 CreationDate	:	[03/10/2019]       
 Programmer		:	Ahmed Osman
 Description	:	Delete From Table EFTS_Participants - CR#GFSY00768
*/   

DELETE FROM EFTS_Participants   
  
DELETE FROM TableID WHERE TableName = 'EFTS_Participants'  

INSERT INTO TableID (TableName, FieldName, LastValue) VALUES ('EFTS_Participants', 'ID', 1)   
GO

PRINT 'End... Script for CR# GFSY00768 Proc Script -- EFTSParticipants_Reset'
GO
--Devolper :	Ahmed Osman
--Date       :	[03/10/2019]		
--Reason     :	CR#GFSY00768 - BBK_ACM17813_Enable EFTS Service
--=============================================================
PRINT 'Start. Script for CR# GFSY00768 Proc Script -- EFTSParticipants_Select'
GO

drop_old_proc 'EFTSParticipants_Select'
GO
create  Proc dbo.EFTSParticipants_Select
as                

/*
 CreationDate	:	[03/10/2019]       
 Programmer		:	Ahmed Osman
 Description	:	Select Data From Table EFTS_Participants - CR#GFSY00768
*/   

Select * From EFTS_Participants  
GO

PRINT 'End... Script for CR# GFSY00768 Proc Script -- EFTSParticipants_Select'
GO
drop_old_proc 'dbo.GetPrintTranDocs'
go

CREATE Procedure GetPrintTranDocs   -- GetPrintTranDocs 'CashDeposit',1033,'CashDepositDetail.rpt',0  
  @TranName TransactionName  
 ,@LCID LanguageLCID    
 ,@ReportName DocFormName = null   
 , @PrintOption  tinyint =null  
AS    
-- Copyright 2000-2001 GetronicsWang Co., LLC.  All Rights Reserved.    
-- 21July2003 Kevens -- Added Localization + made the string a stored procedure    
-- 24May2004 BrianW -- Added optional @ReportName parameter so single results can be returned.    
-- 15Feb2006 JohnG -- added Descript column    
-- 29SEP11 Osma Orabi: Returning   CheckCondition, ConditionResult, DisplayPrintMessage,   
--      PostOrPrePrint, MediaOrientation, GridName, PrintDescriptor, PrintOption, ReEvaluateConditionInReprint  
-- 02OCT2011: Osama Orabi:  
-- Adding @PrintOptin
/*
Modifier			: Mostafa Sayed
Modification Date	: [6/11/2019]
Reason				: CR#GFSY00772 - BBK_ACM000000017813 - Print after host rejected
*/  
  
set nocount on    
Select PTD.TranName,   
 PTD.FormSequence,   
 PTD.FormName,   
 PTD.FormLocation,   
 PTD.Copies,   
 isnull(RDL.LocalDescription,isnull(RD.Descriptor,PTD.UIprompt)) as UIPrompt ,   
 PTD.Instances,    
 isnull(RDL1.LocalDescription,isnull(RD1.Descriptor,isnull(PTD.Descript,isnull(RDL2.LocalDescription,isnull(RD2.Descriptor, PD.Descript))))) as Descript     
   
 , PTD.CheckCondition AS CheckCondition  
    , CONVERT(bit,0)  AS ConditionResult  
    ,PTD.DisplayPrintMessage  AS DisplayPrintMessage  
    ,PTD.PostOrPrePrint  AS PostOrPrePrint  
    ,PD.MediaOrientation  AS MediaOrientation  
    ,PTDG.GridName AS GridName  
    ,D.Name AS PrintDescriptor   
    ,PTDO.PrintOption AS PrintOption   
    ,PTD.ReEvaluateConditionInReprint AS ReEvaluateConditionInReprint
    ,PTD.PrintAfterHostRejected AS PrintAfterHostRejected  
    
from dbo.PrintTranDocs PTD     
left outer join dbo.RulesDescriptor RD  on PTD.UIPrompt = RD.Name     
left outer join dbo.RulesDescriptorLocal RDL on RDL.DescriptorID = RD.DescriptorID and RDL.LCID = @LCID    
left outer join dbo.RulesDescriptor RD1 on PTD.Descript = RD1.Name    
left outer join dbo.RulesDescriptorLocal RDL1 on RDL1.DescriptorID = RD1.DescriptorID  and RDL1.LCID = @LCID    
left outer join dbo.PrintDocs PD on PTD.FormName = PD.FormName    
left outer join dbo.RulesDescriptor RD2 on PD.Descript = RD2.Name    
left outer join dbo.RulesDescriptorLocal RDL2 on RDL2.DescriptorID = RD2.DescriptorID  and RDL2.LCID = @LCID    
  
left outer join dbo.PrinTranDocs_Options as PTDO on PTD.TranName = PTDO.TranName and PTD.FormSequence = PTDO.FormSequence  
left outer join dbo.PrintTranDocsGrids PTDG  on  PTD.TranName   = PTDG.TranName  and PTD.FormSequence = PTDG.FormSequence    
left outer join RulesDescriptor D on D.DescriptorID = PTD.PrintDescriptor  
     
where PTD.TranName = @TranName     
  and (@ReportName is null or PTD.FormName = @ReportName)    
  and (@PrintOption is null OR PTDO.PrintOption = @PrintOption or PTDO.PrintOption is null)   
order by FormSequence    
  
--Devolper :	Ahmed Osman
--Date       :	[03/10/2019]		
--Reason     :	CR#GFSY00768 - BBK_ACM17813_Enable EFTS Service
--=============================================================
PRINT 'Start. Script for CR# GFSY00768 Proc Script -- EFTS_SELECTRESPONSECODE'
GO

drop_old_proc 'EFTS_SELECTRESPONSECODE'
GO
create  Proc dbo.EFTS_SELECTRESPONSECODE
as                

/*
 CreationDate	:	[03/10/2019]       
 Programmer		:	Ahmed Osman
 Description	:	Insert Into Table EFTS_Participants - CR#GFSY00768
*/   

SELECT * FROM EFTS_ResponseCode
   
GO

PRINT 'End... Script for CR# GFSY00768 Proc Script -- EFTS_SELECTRESPONSECODE'
GO