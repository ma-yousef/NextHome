:setvar path "D:\ITS\GFS\GFS_SP\Consolidated_SP_30_44\DB Scripts" 
/*=====================================================================================*/ 
:r $(path)"\SP30\SQL_Table.sql" 
GO 
:r $(path)"\SP30\SQL_PROC.sql" 
GO 
:r $(path)"\SP30\SQL_DML.SQL" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP31\SQL_Table.sql" 
GO 
:r $(path)"\SP31\SQL_PROC.sql" 
GO 
:r $(path)"\SP31\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP32\SQL_Table.sql" 
GO 
:r $(path)"\SP32\SQL_PROC.sql" 
GO 
:r $(path)"\SP32\SQL_DML.SQL" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP33\SQL_Table.sql" 
GO 
:r $(path)"\SP33\SQL_PROC_Archive.sql" 
GO 
:r $(path)"\SP33\SQL_PROC.sql" 
GO 
:r $(path)"\SP33\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP34\SQL_Table.sql" 
GO 
:r $(path)"\SP34\SQL_PROC.sql" 
GO 
:r $(path)"\SP34\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP35\SQL_Table.sql" 
GO 
:r $(path)"\SP35\SQL_PROC.sql" 
GO 
:r $(path)"\SP35\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP36\SQL_PROC.sql" 
GO 
:r $(path)"\SP36\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP37\SQL_Table.sql" 
GO 
:r $(path)"\SP37\SQL_PROC.sql" 
GO 
:r $(path)"\SP37\SQL_JOB.sql" 
GO 
:r $(path)"\SP37\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP38\SQL_Table.sql" 
GO 
:r $(path)"\SP38\SQL_PROC.sql" 
GO 
:r $(path)"\SP38\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP39\SQL_Table.sql" 
GO 
:r $(path)"\SP39\SQL_PROC.sql" 
GO 
:r $(path)"\SP39\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP40\SQL_Table.sql" 
GO 
:r $(path)"\SP40\SQL_PROC.sql" 
GO 
:r $(path)"\SP40\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP41\SQL_Table.sql" 
GO 
:r $(path)"\SP41\SQL_PROC.sql" 
GO 
:r $(path)"\SP41\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP42\SQL_Table.sql" 
GO 
:r $(path)"\SP42\SQL_PROC.sql" 
GO 
:r $(path)"\SP42\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP43\SQL_Table.sql" 
GO 
:r $(path)"\SP43\SQL_PROC.sql" 
GO 
:r $(path)"\SP43\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
:r $(path)"\SP44\SQL_Table.sql" 
GO 
:r $(path)"\SP44\SQL_PROC.sql" 
GO 
:r $(path)"\SP44\SQL_DML.sql" 
GO 
/*=====================================================================================*/ 
