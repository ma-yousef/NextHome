-- =============================================
-- Author:		Aya Tarek
-- Create date: 20/5/2020
-- Description:	Setup Table  For IssueTT
-- =============================================
drop_old_proc 'Get_DEFAULTCorres_Banks'
GO

CREATE PROCEDURE Get_DEFAULTCorres_Banks 
	
	@Local_crn_id int = Null, 
	@Tran_Name Varchar(100) = Null
AS
BEGIN

declare @tran_id int  
begin 
 select @tran_id  = R.TranID from dbo.RulesTranName as R where R.TransactionName = @Tran_Name
end 
               
begin
         
  if exists(select * from ad_gb_default_corres_bks_crncy where local_crn_id = @Local_crn_id   ANd  Tran_id  =@Tran_id  )
begin 
    Select * From ad_gb_default_corres_bks_crncy  Where local_crn_id = @Local_crn_id   ANd  Tran_id  =@Tran_id           
end              
             
 else
 begin
  Select  * FROM ad_gb_default_corres_bks_crncy WHERE local_crn_id =	@Local_crn_id   ANd  Tran_id  is Null   
 end            
            
end 
End 

GO
Drop_old_proc 'ICSR_ENL_EMPLOYER_NAMES_LIST_INS'
go
CREATE PROCEDURE dbo.ICSR_ENL_EMPLOYER_NAMES_LIST_INS      
@EMPLOYER_CODE varchar (5) ,      
@EMPLOYER_NAME NVARCHAR (40) ,      
@GRADE VARCHAR (2),       
@INDUSTRY_CODE VARCHAR(3),       
@SECTOR_TYPE NVARCHAR (40 ),      
@APPROVAL_DATE datetime ,      
@EXPIRY_DATE datetime,      
@OFFICER_CODE NVARCHAR (20),      
@ACCOUNT_NUMBER VARCHAR (20) ,      
@SALARY_PAYMENT_DATE datetime ,      
@SALARY_FREQUENCY VARCHAR (15),      
@STATUS VARCHAR (10) ,      
@REMARKS NVARCHAR (200),      
@Emp_Account_Type varchar(3),  
@Fee_CategoryID VARCHAR(10), 
@Certification VARCHAR(50)     
 AS   
 /*  
ModifiedDate: 4-09-2012          
Modifer:      Amr Salah El-din    
ModifyReason: Insert FeeCategoryID       
  
Modified by: Ahmed Helmy MOhamed  
Modified Date: 22-10-2013  
Reason: fixing issue#GFSX04796 that change the @REMARKS parameter width from 30 to 200  


ModifiedDate: 07-10-2014          
Modifer:      Amr Salah El-din    
ModifyReason: Use Nvarchar instead of varchar with (Employeename, sector,officer, remarks) to solve arabic data problems  
  
ModifiedDate: 30-06-2020          
Modifer:      Shaimaa Abdelnasser   
ModifyReason: Add new parameter "Certification" for CR GFSY00802  
 
Modified by:  
Modified Date:  
Reason:  
*/                 
INSERT INTO  ICSR_ENL_EMPLOYER_NAMES_LIST      
(Employer_Code,      
Employer_Name,      
Emp_Grade,      
Emp_Industry_Code,      
Emp_Sector_Type,      
Emp_Approval_Date,      
Emp_Expiry_Date,      
Emp_Officer_Code,      
Emp_Account_Number,      
Emp_Salary_Payment_Date,      
Emp_Salary_Frequency,      
Emp_Status,      
Emp_Remarks,      
Emp_Account_Type,  
FeeCategoryID,
Certification)      
Values  (@EMPLOYER_CODE,       
    @EMPLOYER_NAME ,      
    @GRADE ,      
    @INDUSTRY_CODE ,      
    @SECTOR_TYPE ,      
    @APPROVAL_DATE ,      
    @EXPIRY_DATE ,      
    @OFFICER_CODE ,      
    @ACCOUNT_NUMBER ,      
    @SALARY_PAYMENT_DATE ,       
      @SALARY_FREQUENCY ,      
    @STATUS ,      
    @REMARKS,      
@Emp_Account_Type,  
@Fee_CategoryID,
@Certification) 
go
drop_old_proc 'UpdateEmployerNamesList'
GO  
Create Procedure dbo.UpdateEmployerNamesList    
@Employer_Name nvarchar (40),    
@Emp_Grade char (2),    
@Emp_Industry_Code int,    
@Emp_Sector_Type nvarchar (40),    
@Emp_Approval_Date datetime,    
@Emp_Expiry_Date datetime,    
@Emp_Officer_Code nvarchar (20),    
@Emp_Account_Number varchar (20),    
@Emp_Salary_Payment_Date datetime,    
@Emp_Salary_Frequency varchar (15),    
@Emp_Status varchar (10),    
@Emp_Remarks nvarchar (200),    
@Emp_Account_Type varchar (3),    
@Employer_Code varchar (5),
@FeeCategoryID int    ,
@Certification varchar (50)

As    

/*
ModifiedDate: 4-09-2012        
Modifer:      Amr Salah El-din  
ModifyReason: Insert FeeCategoryID     

ModifiedDate: 28-01-2015        
Modifer:      Mohamed Elabd  
ModifyReason: Fix Arabic language garbage value   

ModifiedDate: 30-06-2020        
Modifer:      Shaimaa AbdElnasser  
ModifyReason: Add new parameter "Certification"

*/      
    
UPDATE ICSR_ENL_EMPLOYER_NAMES_LIST     
SET      
 Employer_Name = @Employer_Name,     
 Emp_Grade = @Emp_Grade,     
 Emp_Industry_Code = @Emp_Industry_Code,     
 Emp_Sector_Type = @Emp_Sector_Type,     
 Emp_Approval_Date = @Emp_Approval_Date,     
 Emp_Expiry_Date = @Emp_Expiry_Date,     
 Emp_Officer_Code= @Emp_Officer_Code,     
 Emp_Account_Number = @Emp_Account_Number,     
 Emp_Salary_Payment_Date = @Emp_Salary_Payment_Date ,     
 Emp_Salary_Frequency = @Emp_Salary_Frequency,     
 Emp_Status = @Emp_Status,     
 Emp_Remarks = @Emp_Remarks,     
 Emp_Account_Type = @Emp_Account_Type,
 FeeCategoryID = @FeeCategoryID  ,
 Certification = @Certification  
Where  Employer_Code = @Employer_Code    


GO
drop_old_proc 'InsertCustomeExcepCharges'
GO
create  Proc dbo.InsertCustomeExcepCharges 
@Custome_Excep_DataTable  CustomeExcepCharges readonly,
@TranID int,
@FeeChargeCode int,
@ConditionID int
as                
/*
 CreationDate	:	29-11-2018       
 Programmer		:	Ahmed Osman
 Description	:	Insert data into table CustomExceptionChargesConditions || CR#GFSY00739 - Add Custom Exception Charges

 CreationDate	:	29-11-2018       
 Programmer		:	Ahmed Osman
 Description	:	Allow saving multiple conditions on same tran and same charge code || CR#GFSY00803
*/   
declare  @Id int
declare @DataTypeID int , @Operator int

--If Exists(SELECT CustomException FROM ExceptionCharges WHERE TranID = @TranID AND ChargeCode = @FeeChargeCode)
--BEGIN
--	SELECT @ConditionID = CustomException FROM ExceptionCharges WHERE TranID = @TranID AND ChargeCode = @FeeChargeCode AND CustomException IS NOT NULL
--END

IF(@ConditionID = -1)	-- New
begin
	If Exists(SELECT * FROM CustomExceptionChargesConditions)	-- in case CustomExceptionChargesConditions table hasn't any rows
		SELECT @ConditionID = max(ConditionId) + 1 FROM  CustomExceptionChargesConditions
	ELSE
		SELECT @ConditionID = 1
End
ELSE	-- Update
	DELETE FROM CustomExceptionChargesConditions WHERE [ConditionId] = @ConditionID
	
SELECT * INTO #CustomeExcepTemp from @Custome_Excep_DataTable

While (Select Count(*) From #CustomeExcepTemp) > 0
Begin

	SET @DataTypeID = null 
	SET @Operator = null
	
    Select Top 1 @Id = Seq From #CustomeExcepTemp

	SELECT @DataTypeID = id FROM OperandDataType WHERE id IN (Select Top 1 DataType From #CustomeExcepTemp)
	SELECT @Operator = id FROM ConditionalOperator WHERE id IN (Select Top 1 Operator From #CustomeExcepTemp)
	
    INSERT INTO CustomExceptionChargesConditions ([ConditionId],[Seq],[OperandsDataType],[Operand1],[Operator],[Operand2],[LogicalOperator])
	SELECT TOP(1)@ConditionID,Seq,@DataTypeID,Operand1,@Operator,Operand2,LogicalOperator FROM #CustomeExcepTemp

    Delete #CustomeExcepTemp Where Seq = @Id
END

SELECT @ConditionID

IF OBJECT_ID('tempdb..#CustomeExcepTemp') IS NOT NULL DROP TABLE #CustomeExcepTemp
GO

Drop_old_proc 'TLR_OV_CheckFinishedReasons'
GO
create proc dbo.TLR_OV_CheckFinishedReasons  
@RequestID int,  
@status int,
@OverrideRepairFields nvarchar(max) = null  
--,@UpdateAll bit=0   
  
/*  
Modifier: Osama Orabi  
Date : 2010-03-23  
Reason : Performance Tuning  

Modified By	: Osama Nabil
Date		: 2015-02-18
Reason		: update OverrideRequests Status to 8 if @status = 8 and ( @UpdateAll=0 or (@UpdateAll=1 and last reason))

Modified By	: Rokaia Kadry
Date		: 2018-18-10
Reason		: RollBacck UpdateAll which it is not used in case of rejection
Issue		: GFSX13315

Modified By : Mostafa Sayed
Date       : [01/06/2020]
Reason     : CR#GFSY00798 - BARWA_ACM18599_General Enhancement - update OverrideRepairFields with marked controls from supervisor side
*/  
as  
  
SET NOCOUNT ON  
  
declare   
  @approvedReq int,  
  @totalReq int,  
  @CurrentDateTime datetime  
  
 select @CurrentDateTime = getdate()  
  
 if @status = 8 -- rejected reason  
 Begin  
  
 --  IF(@UpdateAll=0)
	--Begin
	  update OverrideRequests WITH (ROWLOCK)  
	  set Status = 8,OverrideRepairFields = @OverrideRepairFields  
	  where RequestID = @RequestID    
	  and Status in (5,6)
	--END
	--ELSE
	--BEGIN
	--	 select @approvedReq = count(distinct(ReasonId))  
	--	 from OverrideRequestReasons (NOLOCK)  
	--	 where RequestID = @RequestID   
	--	  and Status IN(7, 8) 
	--  -- count all requests  
	--  select @totalReq = count(distinct(ReasonId))  
	--  from OverrideRequestReasons (NOLOCK)  
	--  where RequestID = @RequestID   
	
	--  update OverrideRequests WITH (ROWLOCK)  
	--  set Status = 8  
	--  where RequestID = @RequestID   
	--  and @approvedReq = @totalReq  
	--		and Status in (5,6)  
		
	-- END
 End  
  
 Else  
  
 if @status = 7 -- partially approved  
 Begin  
  -- count all approved requests  
  select @approvedReq = count(distinct(ReasonId))  
  from OverrideRequestReasons (NOLOCK)  
  where RequestID = @RequestID   
   and Status = 7 -- approved  
  -- count all requests  
  select @totalReq = count(distinct(ReasonId))  
  from OverrideRequestReasons (NOLOCK)  
  where RequestID = @RequestID   
  -- update all request as partially approced  
  update OverrideRequests WITH (ROWLOCK)  
  set Status = 7  
  where RequestID = @RequestID   
  and @approvedReq = @totalReq  
        and Status in (5,6)  
        
  update OverrideRequests WITH (ROWLOCK)  
  set SendTimeStamp=@CurrentDateTime  
  where RequestID=@RequestID  
 End  
  
 Else  
  
  if(@Status=6) -- Forward  
 Begin  
  update OverrideRequests WITH (ROWLOCK)  
  set SendTimeStamp=@CurrentDateTime   
  where RequestID=@RequestID  
  and Status in (5,6)  
 End  
  
  exec TLR_OV_UpdateIsProcessing @RequestID  

GO
Drop_old_proc 'TLR_OV_GetRepairFields'
GO
CREATE PROC dbo.TLR_OV_GetRepairFields  
@RequestID int
/*  
--Programmer : Mostafa Sayed
--Date       : [01/06/2020]
--Reason     : CR#GFSY00798 - BARWA_ACM18599_General Enhancement - get OverrideRepairFields to hilight controls marked by supervisor in case resend
*/  
AS
	select OverrideRepairFields from OverrideRequests
	where RequestID=@RequestID
GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc TLR_OV_UpdateReasonStatus
Go

CREATE PROCEDURE dbo.TLR_OV_UpdateReasonStatus      
 @UserNum int  ,      
 @ReqID  int  ,      
 @ReasonID int  ,      
 @GrpName RoleName ,      
 @SupID  OperatorID ,      
 @Status  int  ,      
 @SupComment nvarchar(500) ,      
 @CurrFwdGrp RoleName ,      
 @ReasonLevel int,
 @UpdateAll bit=0,
 @OverrideRepairFields nvarchar(max)= null         
AS      
/*      
CreationDate: 21/6/2007      
OriginalName: dbo.TLR_OV_UpdateReasonStatus      
Programmer: Ahmed Rafat      
Description: update override reason status in HO DB      
Output:        
Assumption:       
      
ModifiedDate: 21/08/2008       
Programmer:  Osama Orabi      
Reason:  Adding ReasonLevel to Primary Key of OverrideRequestReasons      
   Retrieving Date from OverrideRequestReasons by ReqID,ReasonID,GrpName,ReasonLevel      
    
Modification Date: 6/4/2009    
Developer: Adel Shaban    
Reason: Enhancing Performance for logon Operation by preventing inserting all roles    
  
Modifier: Osama Orabi  
Date : 2010-03-23  
Reason : Performance Tuning   

Modifier: Adel Shaban
Date:     20/12/2010
Reason:   Ignoring All levels where no Supervisor online 

Modified By	: Osama Orabi
Date		: 2011-07-18
Reason		: Migrate from UBS3 to G8  

Modified By	: Osama Nabil
Date		: 2013-04-07
Reason		: change @SupComment datatype to be nvarchar 

Modified By	: Osama Nabil
Date		: 2015-02-18
Reason		: Adding parameter @UpdateAll CR#GFSY00461

Modified By	: Rokaia Kadry
Date		: 2018-18-10
Reason		: update all reasons when @UpdateAll=1
Issue		: GFSX13315

Modified By : Mostafa Sayed
Date       : [01/06/2020]
Reason     : CR#GFSY00798 - BARWA_ACM18599_General Enhancement - pass @OverrideRepairFields to TLR_OV_CheckFinishedReasons proc
*/      
      
--Notes      
-------      
/*      
if status has not been updated yet ( status value < forward status value)      
 this means it's the first update and  so update table without conditions      
else if its status is forward this means that it may be a new update or a not cancelled old request      
 so check if user is in the new forward group (he has permissions to update as a member of new group)      
 -in case he received new request or not as it'll be sent for him in the forward group-      
 so update the request      
else this means it's already accepted or rejected and no way to reUpdate the reason      
or the supervisor tries to update after the request is forwarded by another supervisor.      
*/      
      
-- Declarations      
---------------      
declare       
 @Forward int  ,      
 @CurStatus int ,      
 @ActionID int  ,  
 @AffectedRows int    
      
-- status select * from Status where StatusTypeID = 28      
set @Forward = 6       
      
-- reset action id - if new status is forward      
-- select * from Status where StatusTypeID = 27 "AcceptRejectForward"      
set @ActionID = 2      
      
select @CurStatus = Status   
 from OverrideRequestReasons    (NOLOCK)  
 where RequestID = @ReqID    
  and ReasonID = @ReasonID   
  and GroupName = @GrpName   
  and ReasonLevel =  @ReasonLevel      
  
IF(@CurStatus < @Forward )      
BEGIN   
 SET NOCOUNT OFF  
     
 UPDATE OverrideRequestReasons  WITH (ROWLOCK)    
 SET SupervisorUserID = @SupID   ,      
  Status   = @Status   ,      
  SupervisorComments = @SupComment  ,      
  ActionID  = case @CurrFwdGrp when '' then ActionID else @ActionID end ,      
  CurrentForwardGroup = case @CurrFwdGrp when '' then Null else @CurrFwdGrp end       
 WHERE RequestID  = @ReqID    
 AND ReasonID  = @ReasonID   
 AND GroupName  = @GrpName   
 AND Status   < @Forward   
 AND  
   -- check that the request not sent to teller (rejected or timed out)      
   -- in these cases some reasons may be still valid but all request cycle finished      
   Exists( SELECT 1 -- *  
   FROM OverrideRequests as OVR  (NOLOCK)    
   WHERE OVR.RequestID = @ReqID      
    AND OVR.Status < @Forward )   
 AND ReasonLevel  = @ReasonLevel      
  
 SELECT @AffectedRows = @@RowCount      

-- Start Adel Shaban [Ignoring All levels where no Supervisor online]
if(@Status = @Forward and @AffectedRows > 0)
Begin

Declare @Level int
Declare @NoOfLevelRowsEmpty int
Declare @NoOfLevelRows int

Set @Level = @ReasonLevel

	Select @Level = min(ReasonLevel)
	from OverrideRequestReasons (NOLock)
	where RequestID = @ReqID and ReasonID = @ReasonID and @Level < ReasonLevel

	while(@Level is not NULL)
	Begin
	
		if(exists(select 1 from OverrideRequestReasons (NoLock)
							where	RequestID = @ReqID 
								and ReasonID = @ReasonID 
								and ReasonLevel = @Level
								AND WaitLoggedOffUsers = 0))						
		Begin


			Select @NoOfLevelRowsEmpty = count(ReasonID)
			From OverrideRequestReasons  res (NoLock)
			Inner join OverrideRequests req (NoLock)
			on Req.RequestID = Res.RequestID
			Where res.RequestID = @ReqID and ReasonID = @ReasonID and ReasonLevel = @Level							
							AND	
							(	
								(
									IsUser = 1 AND NOT EXISTS (SELECT 1 FROM V_Operator op
															 INNER JOIN TellerConfig
																	ON op.user_number = TellerConfig.[User_ID]
 															WHERE op.LoginID = res.GroupName 												
																AND SignedOnAt <> ''
																AND (op.Branch	= res.TargetBranch	OR	res.TargetBranch = 0)
																AND ((	IsFilterByDepartment = 0)
																		OR (
																			IsFilterByDepartment = 1 
																			AND (res.UserDepartmentID =  TellerConfig.DepartmentID or res.UserDepartmentID is null)
																			)
																	)
																AND op.user_number <> req.user_number
																AND InLockWhenClose = 0
															)
								)		-- the supervisor is logged-off
							
								OR 
								(
									IsUser = 0 AND NOT EXISTS (SELECT 1 FROM V_OperatorRoles opR
																INNER JOIN V_Operator op
																	ON opR.u# = op.user_number
																	AND SignedOnAt <> ''
																INNER JOIN TellerConfig
																	ON op.user_number = TellerConfig.[User_ID]
																WHERE opR.[RoleName] = res.GroupName
																	AND (op.Branch	= res.TargetBranch	OR	res.TargetBranch = 0)
																	AND ((	IsFilterByDepartment = 0)
																		OR (
																			IsFilterByDepartment = 1 
																			AND (res.UserDepartmentID =  TellerConfig.DepartmentID or res.UserDepartmentID is null)
																			)
																		)
																	AND op.user_number <> req.user_number
																	AND InLockWhenClose = 0
																)-- and all users are LoggedOff
								)
							)

			Select @NoOfLevelRows = Count(ReasonID)
			From OverrideRequestReasons (NoLock)
			Where RequestID = @ReqID and ReasonID = @ReasonID and ReasonLevel = @Level             

			if(@NoOfLevelRows = @NoOfLevelRowsEmpty and @NoOfLevelRows > 0)
			Begin

				Update OverrideRequestReasons with (RowLock)
				set Status = @Forward
				Where RequestID = @ReqID and ReasonID = @ReasonID and ReasonLevel = @Level

				Select @Level = min(ReasonLevel)
				from OverrideRequestReasons (NOLock)
				where RequestID = @ReqID and ReasonID = @ReasonID and @Level < ReasonLevel			
				
			End 
			Else
			Begin
				set @Level = NULL -- To exist loop
			End
		
		End -- End of checking that this level Not Wait for Logged Off supervisors
		Else
		Begin
				set @Level = NULL -- To exist loop
		End
		
	End -- End of  while(@Level is not NULL)

End 
-- End Adel Shaban [Ignoring All levels where no Supervisor online]
  
 EXEC dbo.TLR_OV_CheckFinishedReasons @ReqID, @Status, @OverrideRepairFields --,@UpdateAll 
 
 SET NOCOUNT ON  
  
 END      
/*  
else if exists(      
  select * from OperatorSession  os    
  inner join OperatorRoles ORoles    
  on os.User_Number=ORoles.User_Number and lower(os.role)='gfsoperators'    
  where os.User_Number = @UserNum and      
   oRoles.Role in      
   (select CurrentForwardGroup from OverrideRequestReasons       
    where RequestID = @ReqID  and      
    ReasonID = @ReasonID and      
    GroupName = @GrpName and      
    ReasonLevel = @ReasonLevel)      
  )      
 Begin      
  update OverrideRequestReasons      
  set      
   SupervisorUserID = @SupID  ,      
   Status   = @Status  ,      
   SupervisorComments = @SupComment ,      
   CurrentForwardGroup = case @CurrFwdGrp when '' then Null      
       else @CurrFwdGrp end       
  where      
  RequestID  = @ReqID  and      
   ReasonID  = @ReasonID and      
   GroupName  = @GrpName and      
   status   = @Forward and      
   -- check that the request not sent to teller (rejected or timed out)      
   -- in these cases some reasons may be still valid but all request cycle finished      
   Exists( select * from OverrideRequests as OVR      
    where OVR.RequestID = @ReqID      
    and OVR.Status < @Forward ) and      
   ReasonLevel  = @ReasonLevel      
 END          
*/  
return @AffectedRows  

Go
--End of Automatic Generation
USE [Globalfs]
GO
/*
 CreationDate : 06-21-2020     
 Programmer   :Sara Badwy
 Description  :Defect : GFSX14069                         
*/ 
drop_old_proc 'dbo.IR_SELECT_PAID_MSG'
GO
CREATE PROCEDURE dbo.IR_SELECT_PAID_MSG
(
 @RefTable T_MsgRefNo READONLY    
)
as
Begin
SELECT 1 FROM IR ir
inner join @RefTable rt on ir.MsgRefNo=rt.MsgRefNo 
where  StatusID=8; --Paid
End
GO
use [Globalfs]
GO
 
EXEC [dbo].[drop_old_proc] 'DeleteLockAccountRoll'
Go 

Create proc dbo.DeleteLockAccountRoll 
 @account_number  nvarchar(50)
 
as
  
/*  
CreationDate: 2020-07-26  
OriginalName: dbo.DeleteLockAccountRoll   
Programmer: ahmed eliwa
Description: to Delete Lock Account Roll
*/
declare @acct_number nvarchar(50) 

set @acct_number = @account_number

IF EXISTS (select RimNumber from LockAccountStatus where AccountNumber = @account_number)
BEGIN
	Delete from LockAccountStatus where AccountNumber = @acct_number
END
Go
use [Globalfs]
GO
 
EXEC [dbo].[drop_old_proc] 'GetLockAccountStatus'
Go 

Create proc dbo.GetLockAccountStatus 
 @account_number  nvarchar(50) 
as
  
/*  
CreationDate: 2020-07-26  
OriginalName: dbo.SelectLockRolls   
Programmer: ahmed eliwa
Description: to select lock rolls   
*/

select RimNumber, AccountNumber, UserId, LockRoll, ToStatus 
from LockAccountStatus 
where AccountNumber = @account_number
Go
use [Globalfs]
GO
 
EXEC [dbo].[drop_old_proc] 'GetLockRolls'
Go 

Create proc dbo.GetLockRolls 
as
  
/*  
CreationDate: 2020-07-26  
OriginalName: dbo.GetLockRolls  
Programmer: ahmed eliwa
Description: to select lock rolls   
*/

select LockRoll, ToStatus from LockRolls     
Go
use [Globalfs]
GO
 
EXEC [dbo].[drop_old_proc] 'InsertOrUpdateLockAccountRoll'
Go 

Create proc dbo.InsertOrUpdateLockAccountRoll 
 @rim_number  nvarchar(50), 
 @account_number  nvarchar(50),
 @user_id  nvarchar(50), 
 @lock_roll  nvarchar(200) ,
 @to_status  nvarchar(200) 
as
  
/*  
CreationDate: 2020-07-26  
OriginalName: dbo.InsertOrUpdateLockAccountRoll   
Programmer: ahmed eliwa
Description: to update or insert lock account status  
*/
declare @acct_number nvarchar(50) 

set @acct_number = @account_number

IF EXISTS (select RimNumber from LockAccountStatus where AccountNumber = @acct_number)
BEGIN
	Update LockAccountStatus 
	set 
		RimNumber = @rim_number,
		AccountNumber = @acct_number, 
		UserID = @user_id, 
		LockRoll = @lock_roll, 
		ToStatus = @to_status,
		LastChanged = GetDate(),
		updator = suser_sname()
	where 
		AccountNumber = @acct_number
END

ELSE
BEGIN
	Insert Into LockAccountStatus (RimNumber   ,AccountNumber   ,UserID   ,LockRoll   ,ToStatus)
						   Values (@rim_number ,@acct_number   ,@user_id  ,@lock_roll ,@to_status)
END
Go
Drop_old_proc 'ICSR_ENL_EMPLOYER_NAMES_LIST_SEL'
GO
/****** Object:  StoredProcedure [dbo].[ICSR_ENL_EMPLOYER_NAMES_LIST_SEL]    Script Date: 06/30/2020 4:18:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create  PROCEDURE [dbo].[ICSR_ENL_EMPLOYER_NAMES_LIST_SEL]        
 @EMPLOYER_CODE varchar (5)        
AS        
SELECT		Employer_Code,
			Employer_Name,
			Emp_Grade,
			Emp_Industry_Code,
			Emp_Sector_Type,
			Emp_Officer_Code,
			Emp_Account_Number,
			Emp_Expiry_Date,
			Emp_Approval_Date,        
			Emp_Salary_Payment_Date,
			Emp_Salary_Frequency,
			Emp_Status,Emp_Remarks ,
			Certification       
FROM		ICSR_ENL_EMPLOYER_NAMES_LIST        
WHERE		EMPLOYER_CODE = @EMPLOYER_CODE     

GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00804 Proc Script - dbo.SelectOverrideRequestReasons'
GO
 
drop_old_proc 'SelectOverrideRequestReasons'
GO
create proc dbo.SelectOverrideRequestReasons		--SelectOverrideRequestReasons 6367
@RequestID varchar(max)
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
	Description	:	Select Override Request Reasons
*/          

SELECT OverrideRequestReasons.ReasonID , OverrideRequestReasons.Status 
FROM OverrideRequests INNER JOIN OverrideRequestReasons 
	ON OverrideRequests.RequestID = OverrideRequestReasons.RequestID
	WHERE OverrideRequests.RequestID = @RequestID

GO

PRINT 'End... Script for CR# GFSY00804 Proc Script - dbo.SelectOverrideRequestReasons'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00804 Proc Script - dbo.SelectTellerConfig'
GO 
 
drop_old_proc 'SelectTellerConfig'
GO
create proc dbo.SelectTellerConfig		--SelectTellerConfig 1526
@UserNumber int
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
	Description	:	Select Teller Config
*/          

SELECT * FROM TellerConfig WHERE User_ID = @UserNumber

GO

PRINT 'End... Script for CR# GFSY00804 Proc Script - dbo.SelectTellerConfig'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00804 Proc Script - dbo.SelectTranConfig'
GO
 
drop_old_proc 'SelectTranConfig'
GO
create proc dbo.SelectTranConfig		--SelectTranConfig 'CashDeposit'	
@TranName nvarchar(max)
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
	Description	:	Select Tran Config 
*/          

SELECT TranConfig.* 
	FROM RulesTranConfig TranConfig INNER JOIN RulesTranName TranName
	ON TranConfig.TranID = TranName.TranID
	WHERE TranName.TransactionName = @TranName 

GO

PRINT 'End... Script for CR# GFSY00804 Proc Script - dbo.SelectTranConfig'
GO
DROP_OLD_PROC 'UpdateJournalAndTotals'
GO
CREATE proc [dbo].[UpdateJournalAndTotals]          
  @Bank  BankID        
 ,@Region RegionID        
 ,@Branch BranchID        
 ,@JNLSequence int -- JNLSequence        
 ,@user_number internal_user_ID        
 ,@BusinessDate_Day tinyint        
 ,@year_month smallint        
 ,@BusinessDate SmallDate        
 ,@CashDrawer CashDrawerNumber = NULL        
 ,@Correction bit = 0        
 ,@update_string nvarchar(4000) = NULL-- update T_SQL        
 ,@child_update_string nvarchar(max) ='' -- update T_SQL for child tables.        
    
 ,@Totals_Bucket0 Bucket_ID = NULL        
 ,@Totals_Currency_Type0 CurrencyType = NULL         
 ,@Totals_Batch0 int = NULL -- Batch id number.        
 ,@Totals_BumpBy0 int = NULL        
 ,@Totals_Amount0 money = NULL        
         
 ,@Totals_Bucket1 Bucket_ID = NULL        
 ,@Totals_Currency_Type1 CurrencyType = NULL         
 ,@Totals_Batch1 int = NULL        
 ,@Totals_BumpBy1 int = NULL        
 ,@Totals_Amount1 money =NULL        
         
 ,@Totals_Bucket2 Bucket_ID = NULL        
 ,@Totals_Currency_Type2 CurrencyType = NULL         
 ,@Totals_Batch2 int = NULL        
 ,@Totals_BumpBy2 int = NULL        
 ,@Totals_Amount2 money =NULL        
 ,@Totals_Bucket3 Bucket_ID = NULL        
 ,@Totals_Currency_Type3 CurrencyType = NULL         
 ,@Totals_Batch3 int = NULL        
 ,@Totals_BumpBy3 int = NULL        
 ,@Totals_Amount3 money =NULL        
 ,@Totals_Bucket4 Bucket_ID = NULL        
 ,@Totals_Currency_Type4 CurrencyType = NULL         
 ,@Totals_Batch4 int = NULL        
 ,@Totals_BumpBy4 int = NULL        
 ,@Totals_Amount4 money =NULL        
        
 ,@Totals_Bucket5 Bucket_ID = NULL        
 ,@Totals_Currency_Type5 CurrencyType = NULL         
 ,@Totals_Batch5 int = NULL        
 ,@Totals_BumpBy5 int = NULL        
 ,@Totals_Amount5 money =NULL        
        
 ,@Totals_Bucket6 Bucket_ID = NULL        
 ,@Totals_Currency_Type6 CurrencyType = NULL         
 ,@Totals_Batch6 int = NULL        
 ,@Totals_BumpBy6 int = NULL        
 ,@Totals_Amount6 money =NULL        
        
 ,@Totals_Bucket7 Bucket_ID = NULL        
 ,@Totals_Currency_Type7 CurrencyType = NULL         
 ,@Totals_Batch7 int = NULL        
 ,@Totals_BumpBy7 int = NULL        
 ,@Totals_Amount7 money =NULL        
        
 ,@Totals_Bucket8 Bucket_ID = NULL        
 ,@Totals_Currency_Type8 CurrencyType = NULL         
 ,@Totals_Batch8 int = NULL        
 ,@Totals_BumpBy8 int = NULL        
 ,@Totals_Amount8 money =NULL        
        
 ,@Totals_Bucket9 Bucket_ID = NULL        
 ,@Totals_Currency_Type9 CurrencyType = NULL         
 ,@Totals_Batch9 int = NULL        
 ,@Totals_BumpBy9 int = NULL        
 ,@Totals_Amount9 money =NULL        
        
 ,@Totals_Bucket10 Bucket_ID = NULL        
 ,@Totals_Currency_Type10 CurrencyType = NULL         
 ,@Totals_Batch10 int = NULL        
 ,@Totals_BumpBy10 int = NULL        
 ,@Totals_Amount10 money =NULL        
        
 ,@Totals_Bucket11 Bucket_ID = NULL        
 ,@Totals_Currency_Type11 CurrencyType = NULL         
 ,@Totals_Batch11 int = NULL        
 ,@Totals_BumpBy11 int = NULL        
 ,@Totals_Amount11 money =NULL        
        
 ,@Totals_Bucket12 Bucket_ID = NULL        
 ,@Totals_Currency_Type12 CurrencyType = NULL         
 ,@Totals_Batch12 int = NULL        
 ,@Totals_BumpBy12 int = NULL        
 ,@Totals_Amount12 money =NULL        
        
 ,@Totals_Bucket13 Bucket_ID = NULL        
 ,@Totals_Currency_Type13 CurrencyType = NULL         
 ,@Totals_Batch13 int = NULL        
 ,@Totals_BumpBy13 int = NULL        
 ,@Totals_Amount13 money =NULL        
        
 ,@Totals_Bucket14 Bucket_ID = NULL        
 ,@Totals_Currency_Type14 CurrencyType = NULL         
 ,@Totals_Batch14 int = NULL        
 ,@Totals_BumpBy14 int = NULL        
 ,@Totals_Amount14 money =NULL      
       
 ,@DenomType varchar(4000) =NULL     
 ,@DenomValue varchar(4000) =NULL        
 ,@DenomCurrency varchar(4000) =NULL        
 ,@DenomAmount varchar(4000) =NULL 
 ,@NewUser_number  internal_user_ID = NULL
 ,@NewCashDrawer  CashDrawerNumber = NULL
 ,@debug int = 0        
as        
-- New version of update_totals_array        
-- Update existing totals buckets or insert new ones.        
-- Then set CashDrawer.HasCountedCash OFF.         
-- Then run the Journal update.        
-- All of this is wrapped in a database transaction - All updates are applied or NONE.        
-- Copyright 2008 Getronics USA Inc.  All rights reserved.        
-- 23JUL08 JuanJ - Added @update_children_string to allow updates in Child tables.        
--   in replacement of update_totals_array when VB code elimination completed        
-- 31JUL08 JuanJ - Changed parameters name to match FieldLists names.        
-- 11AUG08 Bodhi - Added tests of @@trancount to avoid updates outside of transactions.         
-- 26AUG08 JuanJ - Only set CashDrawer.HasCountedCash OFF when CashIn /Cash out Bucket.        
-- 04Jul11 mfarouk - Add new parameters (@DenomType,@DenomValue,@DenomCurrency,@DenomAmount) for denomination to be used in calling procedure UpdateCashDrawerDetails      
-- 26Oct11 mfarouk - correct parameteres passed to UpdateCashDrawerDetails    
-- 15Dec12 Asmaa Hafez - change parameteres passed to UpdateCashDrawerDetails from (BrID) to (Bank - Region - Branch)  - CR # 7305    
-- 2014-07-21: Osama Orabi: Issue# GFSX07456: 2.0.46.1319. Enhance the performane by passing the BrID to write to Totals Directly instead of Totlas_2 or V_Old_Totals    
-- 2020-08-12 : Ahmed Osman	: CR GFSY00804 : Replace param @user_number with @NewUser_number and replace @CashDrawer with @NewCashDrawer 
--				in passing params on proc update totals and cash drawers , we send the same data the default behaviour and we change the data in case the supervisor post the transaction from override request
    
set nocount on        
DECLARE @BrID hierarchy_node#;    
SELECT @BrID = dbo.id_of_branch(@Bank,@Region,@Branch)   ;    
    
declare  @BucketID  Bucket_ID, @Amount money, @ctype CurrencyType        
 , @Batch int, @Count int        
declare @sql nvarchar(4000), @param_defs nvarchar(255)        
declare @where nvarchar(400)        
declare @day tinyint        
declare @table_name sysname, @suffix char(7)        
declare @result int, @err int        
--** CR17385 ** S        
declare @IsCashIN_OUTBucket bit        
set @IsCashIN_OUTBucket=0        
--** CR17385 ** E        
set @param_defs         
  = N'@bk BankID, @r RegionID, @br BranchID, @u internal_user_ID,        
  @Seq int, @day tinyint, @ym smallint'        
set @day = @BusinessDate_Day        
set @sql = N'SET NOCOUNT ON' +CHAR(10)+ @update_string+N'        
where user_number = @u        
and JNLSequence = @Seq        
and year_month = @ym        
and BusinessDate_Day = @day        
and Branch = @br        
and Region = @r        
and Bank = @bk'        
SET XACT_ABORT ON        
BEGIN TRAN GJ        
if @debug > 1        
 SELECT @Totals_Bucket0 b0, @Totals_Bucket1 b1, @Totals_Bucket2 b2, @Totals_Bucket3 b3, @Totals_Bucket4 b4, @Totals_Bucket5 b5, @Totals_Bucket6 b6        
        
set @result = 0        
-- call update cashdrawer details in case tran has denom detail      
if @DenomType is Not Null      
Begin     
      
 --declare @BrID varchar(10)    
 --select @BrID = CONVERT(Varchar,dbo.id_of_branch(@Bank,@Region,@Branch))     
    
 exec @result = dbo.UpdateCashDrawerDetails @Bank,@Region,@Branch,@NewCashDrawer,@DenomCurrency      
            ,@DenomAmount      
            ,@DenomType      
            ,@DenomValue      
                
 set @err = @@error        
 if @result <> 0 or @err <> 0       
 begin        
  rollback tran GJ        
  return @result       
 end      
End      
      
if @Totals_Bucket0 is not null BEGIN        
--** CR17385 ** S        
--Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
  if (@IsCashIN_OUTBucket=0)        
 set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket0)        
--** CR17385 ** E        
  exec @result = dbo.write_totals        
  @Bank        
 ,@Region        
 ,@Branch        
 ,@NewUser_number        
 ,@BusinessDate        
 ,@NewCashDrawer        
 ,@Correction        
 ,@Totals_Bucket0        
 ,@Totals_Amount0        
 ,@Totals_Currency_Type0        
 ,@Totals_Batch0        
 ,@Totals_BumpBy0        
 ,@debug    
 , @BrID    
  set @err = @@error        
  if @result <> 0 or @err <> 0 begin        
 rollback tran GJ        
 return @result        
  end        
        
  if @Totals_Bucket1 is not null begin        
 --** CR17385 ** S        
 --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
 if (@IsCashIN_OUTBucket=0)        
  set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket1)        
 --** CR17385 ** E        
 exec @result = dbo.write_totals        
   @Bank        
  ,@Region        
  ,@Branch        
  ,@NewUser_number        
  ,@BusinessDate        
  ,@NewCashDrawer        
  ,@Correction        
  ,@Totals_Bucket1        
  ,@Totals_Amount1        
  ,@Totals_Currency_Type1        
  ,@Totals_Batch1        
  ,@Totals_BumpBy1        
  ,@debug        
  , @BrID    
 set @err = @@error        
 if @result <> 0 or @err <> 0 begin        
  rollback tran GJ        
  return @result        
 end        
 if @Totals_Bucket2 is not null begin        
  --** CR17385 ** S        
  --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
  if (@IsCashIN_OUTBucket=0)        
   set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket2)        
  --** CR17385 ** E        
  exec @result = dbo.write_totals        
    @Bank        
   ,@Region        
   ,@Branch        
   ,@NewUser_number        
   ,@BusinessDate        
   ,@NewCashDrawer        
   ,@Correction        
   ,@Totals_Bucket2        
   ,@Totals_Amount2        
   ,@Totals_Currency_Type2        
   ,@Totals_Batch2        
   ,@Totals_BumpBy2        
   ,@debug        
   , @BrID    
  set @err = @@error        
  if @result <> 0 or @err <> 0 begin        
   rollback tran GJ        
   return @result        
  end        
  if @Totals_Bucket3 is not null begin        
   --** CR17385 ** S        
   --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
   if (@IsCashIN_OUTBucket=0)        
    set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket3)        
   --** CR17385 ** E        
   exec @result = dbo.write_totals        
     @Bank        
    ,@Region        
    ,@Branch        
    ,@NewUser_number        
    ,@BusinessDate        
    ,@NewCashDrawer        
    ,@Correction        
    ,@Totals_Bucket3        
    ,@Totals_Amount3        
    ,@Totals_Currency_Type3        
    ,@Totals_Batch3        
    ,@Totals_BumpBy3        
    ,@debug        
 , @BrID    
   set @err = @@error        
   if @result <> 0 or @err <> 0 begin        
    rollback tran GJ        
    return @result        
   end        
           
   if @Totals_Bucket4 is not null begin        
    --** CR17385 ** S        
    --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
    if (@IsCashIN_OUTBucket=0)        
     set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket4)        
    --** CR17385 ** E        
    exec @result = dbo.write_totals        
      @Bank        
     ,@Region        
     ,@Branch        
     ,@NewUser_number        
     ,@BusinessDate        
     ,@NewCashDrawer        
     ,@Correction        
     ,@Totals_Bucket4        
     ,@Totals_Amount4        
     ,@Totals_Currency_Type4        
     ,@Totals_Batch4        
     ,@Totals_BumpBy4        
     ,@debug        
  , @BrID    
    set @err = @@error        
    if @result <> 0 or @err <> 0 begin        
     rollback tran GJ        
     return @result        
    end        
    if @Totals_Bucket5 is not null begin        
     --** CR17385 ** S        
     --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
     if (@IsCashIN_OUTBucket=0)        
     set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket5)        
     --** CR17385 ** E        
     exec @result = dbo.write_totals        
       @Bank        
      ,@Region        
      ,@Branch        
      ,@NewUser_number        
      ,@BusinessDate        
      ,@NewCashDrawer        
      ,@Correction        
      ,@Totals_Bucket5        
      ,@Totals_Amount5        
      ,@Totals_Currency_Type5        
      ,@Totals_Batch5        
      ,@Totals_BumpBy5        
      ,@debug        
   , @BrID    
     set @err = @@error        
     if @result <> 0 or @err <> 0 begin        
      rollback tran GJ        
  return @result        
     end        
     if @Totals_Bucket6 is not null begin        
      --** CR17385 ** S        
      --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
      if (@IsCashIN_OUTBucket=0)        
       set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket6)        
      --** CR17385 ** E        
      exec @result = dbo.write_totals        
        @Bank        
       ,@Region        
       ,@Branch        
       ,@NewUser_number        
       ,@BusinessDate        
       ,@NewCashDrawer        
       ,@Correction        
       ,@Totals_Bucket6        
       ,@Totals_Amount6        
       ,@Totals_Currency_Type6        
       ,@Totals_Batch6        
       ,@Totals_BumpBy6        
       ,@debug        
    , @BrID    
      set @err = @@error        
      if @result <> 0 or @err <> 0 begin        
       rollback tran GJ        
       return @result        
      end        
      if @Totals_Bucket7 is not null begin        
       --** CR17385 ** S        
       --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
       if (@IsCashIN_OUTBucket=0)        
        set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket7)        
       --** CR17385 ** E        
       exec @result = dbo.write_totals        
         @Bank        
        ,@Region        
        ,@Branch        
        ,@NewUser_number        
        ,@BusinessDate        
        ,@NewCashDrawer        
        ,@Correction        
        ,@Totals_Bucket7        
        ,@Totals_Amount7        
        ,@Totals_Currency_Type7        
        ,@Totals_Batch7        
        ,@Totals_BumpBy7        
        ,@debug        
  , @BrID    
       set @err = @@error        
       if @result <> 0 or @err <> 0 begin        
        rollback tran GJ        
        return @result        
       end        
       if @Totals_Bucket8 is not null begin        
        --** CR17385 ** S        
        --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
        if (@IsCashIN_OUTBucket=0)        
         set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket8)        
        --** CR17385 ** E        
        exec @result = dbo.write_totals        
          @Bank        
         ,@Region        
         ,@Branch        
         ,@NewUser_number        
         ,@BusinessDate        
         ,@NewCashDrawer        
         ,@Correction        
         ,@Totals_Bucket8        
         ,@Totals_Amount8        
         ,@Totals_Currency_Type8        
         ,@Totals_Batch8        
         ,@Totals_BumpBy8        
         ,@debug        
   , @BrID    
        set @err = @@error        
        if @result <> 0 or @err <> 0 begin        
         rollback tran GJ        
         return @result        
        end        
        if @Totals_Bucket9 is not null begin        
         --** CR17385 ** S        
         --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
         if (@IsCashIN_OUTBucket=0)        
          set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket9)        
        --** CR17385 ** E 
         exec @result = dbo.write_totals        
           @Bank        
          ,@Region        
          ,@Branch        
          ,@NewUser_number        
          ,@BusinessDate        
          ,@NewCashDrawer        
          ,@Correction        
          ,@Totals_Bucket9        
          ,@Totals_Amount9        
          ,@Totals_Currency_Type9        
          ,@Totals_Batch9        
          ,@Totals_BumpBy9        
          ,@debug        
    , @BrID    
         set @err = @@error        
         if @result <> 0 or @err <> 0 begin        
          rollback tran GJ        
          return @result        
         end        
         if @Totals_Bucket10 is not null begin        
          --** CR17385 ** S        
          --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
          if (@IsCashIN_OUTBucket=0)        
           set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket10)        
          --** CR17385 ** E        
          exec @result = dbo.write_totals        
            @Bank        
           ,@Region        
           ,@Branch        
           ,@NewUser_number        
           ,@BusinessDate        
           ,@NewCashDrawer        
           ,@Correction        
           ,@Totals_Bucket10        
           ,@Totals_Amount10        
           ,@Totals_Currency_Type10        
           ,@Totals_Batch10        
           ,@Totals_BumpBy10        
           ,@debug        
     , @BrID    
          set @err = @@error        
          if @result <> 0 or @err <> 0 begin        
           rollback tran GJ        
           return @result        
          end        
          if @Totals_Bucket11 is not null begin        
           --** CR17385 ** S        
           --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
           if (@IsCashIN_OUTBucket=0)        
            set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket11)        
           --** CR17385 ** E        
           exec @result = dbo.write_totals        
             @Bank        
            ,@Region        
            ,@Branch        
            ,@NewUser_number        
            ,@BusinessDate        
            ,@NewCashDrawer        
            ,@Correction        
            ,@Totals_Bucket11        
            ,@Totals_Amount11        
            ,@Totals_Currency_Type11        
            ,@Totals_Batch11        
            ,@Totals_BumpBy11        
            ,@debug        
   , @BrID    
           set @err = @@error        
           if @result <> 0 or @err <> 0 begin        
            rollback tran GJ        
            return @result        
           end        
           if @Totals_Bucket12 is not null begin        
            --** CR17385 ** S        
            --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
            if (@IsCashIN_OUTBucket=0)        
             set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket12)        
            --** CR17385 ** E        
            exec @result = dbo.write_totals        
              @Bank        
             ,@Region        
             ,@Branch        
             ,@NewUser_number        
             ,@BusinessDate        
             ,@NewCashDrawer        
             ,@Correction        
             ,@Totals_Bucket12        
             ,@Totals_Amount12        
             ,@Totals_Currency_Type12        
             ,@Totals_Batch12        
             ,@Totals_BumpBy12        
   ,@debug        
   , @BrID    
            set @err = @@error        
            if @result <> 0 or @err <> 0 begin        
             rollback tran GJ        
             return @result        
            end        
            if @Totals_Bucket13 is not null begin        
             --** CR17385 ** S        
             --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
             if (@IsCashIN_OUTBucket=0)        
              set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket13)        
             --** CR17385 ** E        
             exec @result = dbo.write_totals        
               @Bank        
              ,@Region        
              ,@Branch        
              ,@NewUser_number        
              ,@BusinessDate        
              ,@NewCashDrawer        
              ,@Correction        
              ,@Totals_Bucket13        
              ,@Totals_Amount13        
              ,@Totals_Currency_Type13        
              ,@Totals_Batch13        
              ,@Totals_BumpBy13        
              ,@debug        
     , @BrID    
             set @err = @@error        
             if @result <> 0 or @err <> 0 begin        
              rollback tran GJ        
              return @result        
             end        
             if @Totals_Bucket14 is not null begin        
              --** CR17385 ** S        
              --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
              if (@IsCashIN_OUTBucket=0)        
               set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket14)        
              --** CR17385 ** E        
              exec @result = dbo.write_totals        
                @Bank        
               ,@Region        
               ,@Branch        
               ,@NewUser_number        
               ,@BusinessDate        
               ,@NewCashDrawer        
               ,@Correction        
               ,@Totals_Bucket14        
               ,@Totals_Amount14        
               ,@Totals_Currency_Type14        
               ,@Totals_Batch14        
               ,@Totals_BumpBy14        
               ,@debug        
      , @BrID    
              set @err = @@error        
              if @result <> 0 or @err <> 0 begin        
               rollback tran GJ        
               return @result        
              end        
             end        
            end        
   end        
          end        
         end        
        end        
       end        
      end        
     end        
    end        
   end        
  end        
 end        
  end        
 --** CR17385 ** S        
 IF @@TRANCOUNT > 0 and @IsCashIN_OUTBucket=1 begin          
   UPDATE dbo.CashDrawer WITH (UPDLOCK ROWLOCK)        
   set  HasCountedCash = 0        
   WHERE AssignedToTeller = @NewUser_number         
  and Bank = @Bank        
  and Region = @Region        
  and Branch = @Branch        
  and CashDrawerNumber = @NewCashDrawer         
  -- and IsActive = 1        
  and HasCountedCash <> 0        
 end        
 --** CR17385 ** E        
end        
        
if @debug > 0 begin -- Put out SQL statements for debugging.        
 print 'declare ' + @param_defs + char(10)         
 print 'select @bk = ' + cast(isnull(@bank,0) as varchar)        
 print '    , @r = ' + cast(isnull(@region, 0) as varchar)        
 print '    , @br = ' + cast(isnull(@branch, 0) as varchar)        
 print '    , @u = ' + cast(isnull(@user_number, 0) as varchar)        
 print '--  , @BusinessDate = ''' + cast(@BusinessDate as varchar) + ''''        
 print '    , @day = ' + cast(@day as varchar)        
 print '    , @ym = ' + cast(@year_month as varchar)        
 print '    , @Seq = '+ cast(isnull(@JNLSequence, 0) as varchar)        
 print isnull(@sql, '-NULL-')        
end        
        
IF @@TRANCOUNT > 0 AND @update_string is not null begin        
 exec @result = dbo.sp_executesql @sql, @param_defs        
 , @bank, @region, @branch, @user_number        
 , @JNLSequence, @day, @year_month        
 set @err = @@error        
 if @err <> 0 or @result <> 0 begin        
  rollback tran GJ        
  return @err        
 end        
end        
IF @@TRANCOUNT > 0 AND  @child_update_string<>'' begin        
 exec @result = dbo.sp_executesql @child_update_string, N''        
 set @err = @@error        
 if @err <> 0 or @result <> 0 begin        
  rollback tran GJ        
  return @err        
 end        
end        
IF @@TRANCOUNT > 0        
  COMMIT TRAN GJ        
        
RETURN @result 


GO
use [Globalfs]
GO
 
EXEC [dbo].[drop_old_proc] 'GetLockRolls'
Go 

Create proc dbo.GetLockRolls 
as
  
/*  
CreationDate: 2020-07-26  
OriginalName: dbo.GetLockRolls  
Programmer: ahmed eliwa
Description: to select lock rolls   


OriginalName: dbo.GetLockRolls  
Programmer: ahmed eliwa
Description: order by lastchanged
*/

select LockRoll, ToStatus, LastChanged from LockRolls  order by  LastChanged
Go
Drop_old_proc 'ICSR_ENL_EMPLOYER_NAMES_LIST_INS'
go
CREATE PROCEDURE dbo.ICSR_ENL_EMPLOYER_NAMES_LIST_INS      
@EMPLOYER_CODE varchar (5) ,      
@EMPLOYER_NAME NVARCHAR (40) ,      
@GRADE VARCHAR (2),       
@INDUSTRY_CODE VARCHAR(100), 
@SECTOR_TYPE NVARCHAR (40 ),      
@APPROVAL_DATE datetime ,      
@EXPIRY_DATE datetime,      
@OFFICER_CODE NVARCHAR (20),      
@ACCOUNT_NUMBER VARCHAR (20) ,      
@SALARY_PAYMENT_DATE datetime ,      
@SALARY_FREQUENCY VARCHAR (15),      
@STATUS VARCHAR (10) ,      
@REMARKS NVARCHAR (200),      
@Emp_Account_Type varchar(3),  
@Fee_CategoryID VARCHAR(10), 
@Certification VARCHAR(50)     
 AS   
 /*  
ModifiedDate: 4-09-2012          
Modifer:      Amr Salah El-din    
ModifyReason: Insert FeeCategoryID       
  
Modified by: Ahmed Helmy MOhamed  
Modified Date: 22-10-2013  
Reason: fixing issue#GFSX04796 that change the @REMARKS parameter width from 30 to 200  


ModifiedDate: 07-10-2014          
Modifer:      Amr Salah El-din    
ModifyReason: Use Nvarchar instead of varchar with (Employeename, sector,officer, remarks) to solve arabic data problems  
  
ModifiedDate: 30-06-2020          
Modifer:      Shaimaa Abdelnasser   
ModifyReason: Add new parameter "Certification" for CR GFSY00802  
 
Modified by:  
Modified Date:  
Reason:  
*/                 
INSERT INTO  ICSR_ENL_EMPLOYER_NAMES_LIST      
(Employer_Code,      
Employer_Name,      
Emp_Grade,      
Emp_Industry_Code,      
Emp_Sector_Type,      
Emp_Approval_Date,      
Emp_Expiry_Date,      
Emp_Officer_Code,      
Emp_Account_Number,      
Emp_Salary_Payment_Date,      
Emp_Salary_Frequency,      
Emp_Status,      
Emp_Remarks,      
Emp_Account_Type,  
FeeCategoryID,
Certification)      
Values  (@EMPLOYER_CODE,       
    @EMPLOYER_NAME ,      
    @GRADE ,      
    @INDUSTRY_CODE ,      
    @SECTOR_TYPE ,      
    @APPROVAL_DATE ,      
    @EXPIRY_DATE ,      
    @OFFICER_CODE ,      
    @ACCOUNT_NUMBER ,      
    @SALARY_PAYMENT_DATE ,       
      @SALARY_FREQUENCY ,      
    @STATUS ,      
    @REMARKS,      
@Emp_Account_Type,  
@Fee_CategoryID,
@Certification) 
go
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Get_Recived_Override_Request
Go


create PROCEDURE dbo.Get_Recived_Override_Request  --dbo.Get_Recived_Override_Request 1,1,1,639,'20111009'      
          
@BankID tinyint,          
@RegionID tinyint,          
@BranchID smallint,          
@UserNumber smallint,          
@BusinessDate   Datetime,
@LCID int           
          
/*          
CreationDate: 27/5/2007          
OriginalName: dbo.Get_Recived_Override_Request          
Programmer: Karim Taha          
Description: get the recived override request for given user          
Output:            
Assumption:           
*/          
        
/*        
Modify Date: 9/12/2007        
Developer: Adel Shaban        
Reasons:To Return Dummy column 'StatusString'        
*/       
      
/*      
Modify Date: 17/08/2009        
Developer: Shimaa Saeed      
Reasons: join with tables  rulestranname,rulesdescriptor to get transaction description not transaction name      
  
  
Modifier: Osama Orabi  
Date : 2010-03-23  
Reason : Performance Tuning  

Modifier: Mostafa Sayed
Date : 2017-12-14 
Reason : Get Local Descriptors of transctions' names

Modifier: MAhmoud Saad
Date : 2018-07-02 
Reason : The pending overrides are not showing (Return Pending Overrides)
*/        
        
as     
  
SET NOCOUNT ON  
       
declare @useloginid nvarchar(50)          
          
select @useloginid = loginid           
from operator          
where user_number = @UserNumber          
        
declare @StatusString varchar(50);        
set @StatusString='';        

select DISTINCT ( O.RequestID),JNL.Amount,JNL.AmountCurrType, Descriptor as TransactionName,CASE WHEN LD.LocalDescription IS NULL THEN D.Descriptor ELSE LD.LocalDescription END AS TransactionNameLocal,  
  O.status ,  
  convert(varchar(20),O.sendtimestamp,108) as SendTimeStamp ,   
  @StatusString as StatusString
--from overriderequests      
from OverrideRequestReasons AS OvReqRsns (NOLOCK)  
 INNER JOIN overriderequests as O    (NOLOCK)  
   ON O.RequestID = OvReqRsns.RequestID  
       and (supervisoruserid = @useloginid 
	   or  (supervisoruserid is null and (GroupName=@useloginid 
	   or  GroupName in(select RoleName from V_OperatorRoles
	   where  U#=@UserNumber)))) 
	   and o.User_Number <> @UserNumber
 INNER JOIN rulestranname as T (NOLOCK)  
   on O.TransactionName = T.TransactionName      
 INNER JOIN rulesdescriptor as D (NOLOCK)  
   on D.DescriptorID=T.DSC_Description
   LEFT OUTER JOIN dbo.RulesDescriptorLocal LD (NOLOCK)         
 on LD.DescriptorID= D.DescriptorID         
  and LD.LCID = @LCID         
 INNER JOIN Journal JNL
	on O.Bank=JNL.Bank and O.Region=JNL.Region and O.Branch=JNL.Branch
	and O.User_Number=JNL.user_number and O.BusinessDate=JNL.BusinessDate
	and O.TransactionName=jnl.TranName and O.JNL_Seq=JNL.JNLSequence    
-- where Requestid in(select requestid from OverrideRequestReasons where supervisoruserid = @useloginid )           
   AND O.Bank = @BankID           
   AND O.Region = @RegionID           
--AND Branch = @BranchID           
   AND convert(datetime,convert(varchar,O.BusinessDate) ,112     ) = @BusinessDate          
    





Go
--End of Automatic Generation

--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Get_sent_override_reguest
Go

CREATE PROCEDURE dbo.Get_sent_override_reguest    --dbo.Get_sent_override_reguest 1,1,1,466,'12/04/2009'  
       
 @BankID  tinyint ,      
 @RegionID  tinyint ,      
 @BranchID  smallint,      
 @UserNumber  int ,      
 @BusinessDate   SmallDate,      
 @LCID int
AS      
/*      
CreationDate: 27/5/2007      
OriginalName: dbo.Get_sent_override_reguest      
Programmer: Karim Taha      
Description: get the sent override request for given user      
Output:        
Assumption:       
*/      
    
/*    
Modify Date: 9/12/2007    
Developer: Adel Shaban    
Reasons:To Return Dummy column 'StatusString'    
*/    
/*  
Modify Date: 17/08/2009    
Developer: Shimaa Saeed  
Reasons: join with tables  rulestranname,rulesdescriptor to get transaction description not transaction name  

Modifier: Osama Orabi
Date	: 2010-03-23
Reason	: Performance Tuning

Modifier: Osama Orabi
Date	: 2011-07-31
Reason	: Changing the @BusinessDate type to be SmallDate

Modifier: Mostafa Sayed
Date	: 2017-12-14
Reason	: Get Local Descriptors of transctions' names

Modifier : Mostafa Sayed
Date       : [01/06/2020]
Reason     : CR#GFSY00798 - BARWA_ACM18599_General Enhancement .....
			 Return Amount field from Journal.
*/   
    
declare @StatusString varchar(50);    
set @StatusString='';    
    
select RequestID,JNL.Amount,JNL.AmountCurrType, Descriptor as TransactionName,CASE WHEN LD.LocalDescription IS NULL THEN D.Descriptor ELSE LD.LocalDescription END as TransactionNameLocal,  
		status ,convert(varchar(20),sendtimestamp,108) as SendTimeStamp ,
		@StatusString as StatusString
--from overriderequests    
  
from overriderequests as O  (NOLOCK)
inner join rulestranname as T 
	on O.TransactionName = T.TransactionName  
inner join rulesdescriptor as D 
	on D.DescriptorID=T.DSC_Description
LEFT OUTER JOIN dbo.RulesDescriptorLocal LD         
 on LD.DescriptorID= D.DescriptorID         
  and LD.LCID = @LCID
inner join Journal JNL
	on O.Bank=JNL.Bank and O.Region=JNL.Region and O.Branch=JNL.Branch
	and O.User_Number=JNL.user_number and O.BusinessDate=JNL.BusinessDate
	and O.TransactionName=jnl.TranName and O.JNL_Seq=JNL.JNLSequence      
where O.Bank = @BankID 
	AND O.Region = @RegionID 
	AND O.Branch = @BranchID 
	AND O.User_Number = @UserNumber  
	AND O.BusinessDate = @BusinessDate      
  

Go
--End of Automatic Generation
Drop_old_proc 'TLR_OV_CheckFinishedReasons'
GO
create proc dbo.TLR_OV_CheckFinishedReasons  
@RequestID int,  
@status int,
@OverrideRepairFields nvarchar(max) = null  
--,@UpdateAll bit=0   
  
/*  
Modifier: Osama Orabi  
Date : 2010-03-23  
Reason : Performance Tuning  

Modified By	: Osama Nabil
Date		: 2015-02-18
Reason		: update OverrideRequests Status to 8 if @status = 8 and ( @UpdateAll=0 or (@UpdateAll=1 and last reason))

Modified By	: Rokaia Kadry
Date		: 2018-18-10
Reason		: RollBacck UpdateAll which it is not used in case of rejection
Issue		: GFSX13315

Modified By : Mostafa Sayed
Date       : [01/06/2020]
Reason     : CR#GFSY00798 - BARWA_ACM18599_General Enhancement - update OverrideRepairFields with marked controls from supervisor side
*/  
as  
  
SET NOCOUNT ON  
  
declare   
  @approvedReq int,  
  @totalReq int,  
  @CurrentDateTime datetime  
  
 select @CurrentDateTime = getdate()  
  
 if @status = 8 -- rejected reason  
 Begin  
  
 --  IF(@UpdateAll=0)
	--Begin
	  update OverrideRequests WITH (ROWLOCK)  
	  set Status = 8,OverrideRepairFields = @OverrideRepairFields  
	  where RequestID = @RequestID    
	  and Status in (5,6)
	--END
	--ELSE
	--BEGIN
	--	 select @approvedReq = count(distinct(ReasonId))  
	--	 from OverrideRequestReasons (NOLOCK)  
	--	 where RequestID = @RequestID   
	--	  and Status IN(7, 8) 
	--  -- count all requests  
	--  select @totalReq = count(distinct(ReasonId))  
	--  from OverrideRequestReasons (NOLOCK)  
	--  where RequestID = @RequestID   
	
	--  update OverrideRequests WITH (ROWLOCK)  
	--  set Status = 8  
	--  where RequestID = @RequestID   
	--  and @approvedReq = @totalReq  
	--		and Status in (5,6)  
		
	-- END
 End  
  
 Else  
  
 if @status = 7 -- partially approved  
 Begin  
  -- count all approved requests  
  select @approvedReq = count(distinct(ReasonId))  
  from OverrideRequestReasons (NOLOCK)  
  where RequestID = @RequestID   
   and Status = 7 -- approved  
  -- count all requests  
  select @totalReq = count(distinct(ReasonId))  
  from OverrideRequestReasons (NOLOCK)  
  where RequestID = @RequestID   
  -- update all request as partially approced  
  update OverrideRequests WITH (ROWLOCK)  
  set Status = 7  
  where RequestID = @RequestID   
  and @approvedReq = @totalReq  
        and Status in (5,6)  
        
  update OverrideRequests WITH (ROWLOCK)  
  set SendTimeStamp=@CurrentDateTime  
  where RequestID=@RequestID  
 End  
  
 Else  
  
  if(@Status=6) -- Forward  
 Begin  
  update OverrideRequests WITH (ROWLOCK)  
  set SendTimeStamp=@CurrentDateTime   
  where RequestID=@RequestID  
  and Status in (5,6)  
 End  
  
  exec TLR_OV_UpdateIsProcessing @RequestID  

GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc TLR_OV_GetPendingRequests
Go
CREATE Proc dbo.TLR_OV_GetPendingRequests --666  
@UserNumber internal_user_ID,  
@Flag int=2  
as  
/*  
Flag = 0 : Check Responses ONLY  
Flag = 1 : Check Requests ONLY  
Flag = 2 : Check Both  
*/  
  
/*  
Creator : Adel Shaban  
Date : 25/2/2010  
Description: This procedure is called from teller thread as an alternative method of override service  
  
Modifier: Osama Orabi  
Date : 2010-03-23  
Reason : Performance Tuning    
  
  
Modifier: Adel Shaban  
Date : 2010-03-30  
Reason : Solving issue of filtering by Target Branch and Department  
  
  
Modifier: Osama Orabi  
Date : 2010-03-31  
Reason : Performance Enhancement  

Modified By	: Osama Orabi
Date		: 2011-07-18
Reason		: Migrate from UBS3 to G8
			Filter by current logged on branch
			
			
Modifier : Mostafa essam
Date :1-6-2014
reason  :   fix issue UID#GFSX07244  to use unified full name from procedure and comming from MSMQ
  
Modifier: Osama Nabil
Date : 2015-02-18
Reason : add Override_Descriptor to result set 

Modifier : Mostafa Sayed
Date	 : [01/06/2020]
Reason	 : CR#GFSY00798 - BARWA_ACM18599_General Enhancement .....
			 Return Amount field from Journal.
*/  
  
SET NOCOUNT ON  
  
Declare @LogInID OperatorID,  
  @SupervisorBranch int,  
  @SupervisorDepartment int  
  
Select @LogInID = lower(LoginID), @SupervisorBranch = Branch  
From V_Operator  
where User_Number=@UserNumber
AND V_Operator.SignedOnAt <> ''  
  
  
Select @SupervisorDepartment = DepartmentID   
from TellerConfig tc1   
where tc1.User_ID= @UserNumber and DepartmentID <> -1  
-- set @LogInID = lower(@LogInID)  
  
  
-- Reminders     
------------    
  
  select  
   Req.RequestID   ,                    
   Req.Bank  ,                    
   Req.Region  ,                    
   Req.Branch  ,                    
   Req.User_Number  ,                    
   Req.BusinessDate ,                         
   Req.TransactionName ,                    
   '' as TranFieldListBlob ,                    
   Req.JNL_Seq  ,                    
   OVR.ActionID  ,                    
   OP.LoginID  ,                    
   OP.LoginID as FullName, --OP.FirstName + ' ' + OP.LastName as FullName,                 
   OVR.SendTimeStamp as SendDate,  
   Des.Descriptor,  
   OVR.ReasonID,  
   OVR.GroupName,  
   OVR.ReasonLevel,  
            'Request'  as Status ,
   CASE
	   WHEN OD.Override_Descriptor IS NULL OR OD.Override_Descriptor='' THEN 'TLR_OverrideCorrection' 
	   else OD.Override_Descriptor 
   END as Override_Descriptor
   ,JNL.Amount
   ,JNL.AmountCurrType             
 from OverrideRequestReasons as OVR   (NOLOCK)   
  inner join  OverrideRequests as Req  (NOLOCK)   
     on Req.RequestID = OVR.RequestID   
    and Req.User_Number <> @UserNumber -- No Override Request is sent to user who fired override  
    and OVR.IsProcessing=1                  
    and ( @Flag = 1 or @Flag = 2)  
    and ( (IsUser = 1 and lower(GroupName) = @LogInID) -- Override Sent to Specific User  
      OR  
      (IsUser=0         -- Override Sent to A Group  
       and Exists -- The Supervisor is member in this Group  
           (   
          select 1   
          from V_OperatorRoles OpR (NOLOCK)  
          where OpR.u# = @UserNumber   
            and lower(OpR.RoleName) = lower(OVR.GroupName)   
         )  
          -- Fitler By Target Branch Is Required  
       and ( isnull(OVR.TargetBranch,0) = 0 OR OVR.TargetBranch = @SupervisorBranch)  
            /*(  
             (Select Branch from Operator op1 where op1.User_Number = OpR.User_Number)  
             =  
             OVR.TargetBranch  
            )  
           )  
           */  
          -- Filter By Department  
       and ( isnull(OVR.IsFilterByDepartment,0) = 0 OR  
         (@SupervisorDepartment =  
           (Select DepartmentID from TellerConfig  tc2 (NOLOCK) where tc2.User_ID= Req.User_Number)  
         )  
        )  
      )  
     )   
         
  inner join Operator as OP      (NOLOCK)              
  on OP.User_Number = Req.User_Number  
  inner join rulestranname as T (NOLOCK)  
        on Req.TransactionName = T.TransactionName              
  inner join rulesdescriptor as Des (NOLOCK)  
        on Des.DescriptorID=T.DSC_Description   
  left outer join Override OV on OV.id=OVR.ReasonID
  left outer join OverrideDescriptor OD ON OD.Id=OV.override_description_Id                  
  inner join Journal JNL
	on Req.Bank=JNL.Bank and Req.Region=JNL.Region and Req.Branch=JNL.Branch
	and Req.User_Number=JNL.user_number and Req.BusinessDate=JNL.BusinessDate
	and Req.TransactionName=JNL.TranName and Req.JNL_Seq=JNL.JNLSequence
     
union         
-- Accepted, Rejected, timedout Reasons      
-------------------        
  select    
   Req.RequestID   ,                    
   Req.Bank  ,                    
   Req.Region  ,                    
   Req.Branch  ,                    
Req.User_Number  ,                    
   Req.BusinessDate ,                         
   Req.TransactionName ,                    
   '' as TranFieldListBlob ,                    
   Req.JNL_Seq  ,                    
   Null as ActionID  ,                    
   OP.LoginID  ,                    
  OP.LoginID as FullName, --OP.FirstName + ' ' + OP.LastName as FullName,                  
   Req.SendTimeStamp as SendDate,  
   Des.Descriptor,  
   Null as ReasonID,  
   Null as GroupName,  
   Null as ReasonLevel,  
   CASE STATUS WHEN 7 THEN 'Accepted'  
     WHEN 8 THEN 'Rejected'  
     WHEN 14 THEN 'TimedOut' END as Status   ,
     '' as Override_Descriptor
  ,JNL.Amount
  ,JNL.AmountCurrType                 
  From OverrideRequests as Req (NOLOCK)    
  inner join Operator as OP    (NOLOCK)            
        on OP.User_Number = Req.User_Number  
   -- and Req.Status = 7 -- @PartialAccepted        
   and Req.Status IN (7,  
        8, -- rejected  
        14) -- timed out        
   and Req.User_Number = @UserNumber  
   and (@Flag = 0 or @Flag = 2)   
  inner join rulestranname as T   
        on Req.TransactionName = T.TransactionName              
  inner join rulesdescriptor as Des   
        on Des.DescriptorID=T.DSC_Description     
    inner join Journal JNL
	on Req.Bank=JNL.Bank and Req.Region=JNL.Region and Req.Branch=Req.Branch
	and Req.User_Number=JNL.user_number and Req.BusinessDate=JNL.BusinessDate
	and Req.TransactionName=jnl.TranName and Req.JNL_Seq=JNL.JNLSequence
/*                    
          
Union      
  
-- Rejected Requests       
---------------------         
  select    
   Req.RequestID   ,                    
   Req.Bank  ,                    
   Req.Region  ,                    
   Req.Branch  ,                    
   Req.User_Number  ,                    
   Req.BusinessDate ,                         
   Req.TransactionName ,                    
   '' as TranFieldListBlob ,                    
   Req.JNL_Seq  ,                    
   Null as ActionID  ,                    
   OP.LoginID  ,                    
   OP.FirstName + ' ' + OP.LastName as FullName,              
   Req.SendTimeStamp as SendDate,  
   Des.Descriptor,  
   Null as ReasonID,  
   Null as GroupName,  
   Null as ReasonLevel,  
   'Rejected' as Status                           
  From OverrideRequests as Req (NOLOCK)    
  inner join Operator as OP                    
        on OP.User_Number = Req.User_Number  
  and Req.Status = 8 -- REJECTED        
   and Req.User_Number = @UserNumber  
   and (@Flag = 0 or @Flag = 2)   
  inner join rulestranname as T   
        on Req.TransactionName = T.TransactionName              
  inner join rulesdescriptor as Des   
        on Des.DescriptorID=T.DSC_Description  
                  
          
Union      
-- TimedOut Requests      
--------------------      
  select    
   Req.RequestID   ,                    
   Req.Bank  ,                    
   Req.Region  ,                    
   Req.Branch  ,                    
   Req.User_Number  ,                    
   Req.BusinessDate ,                         
   Req.TransactionName ,                    
   '' as TranFieldListBlob ,                    
   Req.JNL_Seq  ,                    
   Null as ActionID  ,                    
   OP.LoginID  ,                    
   OP.FirstName + ' ' + OP.LastName as FullName,              
   Req.SendTimeStamp as SendDate,  
   Des.Descriptor,  
   Null as ReasonID,  
   Null as GroupName,  
   Null as ReasonLevel,  
   'TimedOut' as Status                           
  
  From OverrideRequests as Req  (NOLOCK)    
  inner join Operator as OP                    
        on OP.User_Number = Req.User_Number  
  and Req.Status = 14 -- TIMED OUT        
   and Req.User_Number = @UserNumber  
   and (@Flag = 0 or @Flag = 2)   
  inner join rulestranname as T   
        on Req.TransactionName = T.TransactionName              
  inner join rulesdescriptor as Des   
        on Des.DescriptorID=T.DSC_Description                      
*/  

Go
--End of Automatic Generation
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc TLR_OV_UpdateReasonStatus
Go

CREATE PROCEDURE dbo.TLR_OV_UpdateReasonStatus      
 @UserNum int  ,      
 @ReqID  int  ,      
 @ReasonID int  ,      
 @GrpName RoleName ,      
 @SupID  OperatorID ,      
 @Status  int  ,      
 @SupComment nvarchar(500) ,      
 @CurrFwdGrp RoleName ,      
 @ReasonLevel int,
 @UpdateAll bit=0,
 @OverrideRepairFields nvarchar(max)= null         
AS      
/*      
CreationDate: 21/6/2007      
OriginalName: dbo.TLR_OV_UpdateReasonStatus      
Programmer: Ahmed Rafat      
Description: update override reason status in HO DB      
Output:        
Assumption:       
      
ModifiedDate: 21/08/2008       
Programmer:  Osama Orabi      
Reason:  Adding ReasonLevel to Primary Key of OverrideRequestReasons      
   Retrieving Date from OverrideRequestReasons by ReqID,ReasonID,GrpName,ReasonLevel      
    
Modification Date: 6/4/2009    
Developer: Adel Shaban    
Reason: Enhancing Performance for logon Operation by preventing inserting all roles    
  
Modifier: Osama Orabi  
Date : 2010-03-23  
Reason : Performance Tuning   

Modifier: Adel Shaban
Date:     20/12/2010
Reason:   Ignoring All levels where no Supervisor online 

Modified By	: Osama Orabi
Date		: 2011-07-18
Reason		: Migrate from UBS3 to G8  

Modified By	: Osama Nabil
Date		: 2013-04-07
Reason		: change @SupComment datatype to be nvarchar 

Modified By	: Osama Nabil
Date		: 2015-02-18
Reason		: Adding parameter @UpdateAll CR#GFSY00461

Modified By	: Rokaia Kadry
Date		: 2018-18-10
Reason		: update all reasons when @UpdateAll=1
Issue		: GFSX13315

Modified By : Mostafa Sayed
Date       : [01/06/2020]
Reason     : CR#GFSY00798 - BARWA_ACM18599_General Enhancement - pass @OverrideRepairFields to TLR_OV_CheckFinishedReasons proc
*/      
      
--Notes      
-------      
/*      
if status has not been updated yet ( status value < forward status value)      
 this means it's the first update and  so update table without conditions      
else if its status is forward this means that it may be a new update or a not cancelled old request      
 so check if user is in the new forward group (he has permissions to update as a member of new group)      
 -in case he received new request or not as it'll be sent for him in the forward group-      
 so update the request      
else this means it's already accepted or rejected and no way to reUpdate the reason      
or the supervisor tries to update after the request is forwarded by another supervisor.      
*/      
      
-- Declarations      
---------------      
declare       
 @Forward int  ,      
 @CurStatus int ,      
 @ActionID int  ,  
 @AffectedRows int    
      
-- status select * from Status where StatusTypeID = 28      
set @Forward = 6       
      
-- reset action id - if new status is forward      
-- select * from Status where StatusTypeID = 27 "AcceptRejectForward"      
set @ActionID = 2      
      
select @CurStatus = Status   
 from OverrideRequestReasons    (NOLOCK)  
 where RequestID = @ReqID    
  and ReasonID = @ReasonID   
  and GroupName = @GrpName   
  and ReasonLevel =  @ReasonLevel      
  
IF(@CurStatus < @Forward )      
BEGIN   
 SET NOCOUNT OFF  
     
 UPDATE OverrideRequestReasons  WITH (ROWLOCK)    
 SET SupervisorUserID = @SupID   ,      
  Status   = @Status   ,      
  SupervisorComments = @SupComment  ,      
  ActionID  = case @CurrFwdGrp when '' then ActionID else @ActionID end ,      
  CurrentForwardGroup = case @CurrFwdGrp when '' then Null else @CurrFwdGrp end       
 WHERE RequestID  = @ReqID    
 AND ReasonID  = @ReasonID   
 AND GroupName  = @GrpName   
 AND Status   < @Forward   
 AND  
   -- check that the request not sent to teller (rejected or timed out)      
   -- in these cases some reasons may be still valid but all request cycle finished      
   Exists( SELECT 1 -- *  
   FROM OverrideRequests as OVR  (NOLOCK)    
   WHERE OVR.RequestID = @ReqID      
    AND OVR.Status < @Forward )   
 AND ReasonLevel  = @ReasonLevel      
  
 SELECT @AffectedRows = @@RowCount      

-- Start Adel Shaban [Ignoring All levels where no Supervisor online]
if(@Status = @Forward and @AffectedRows > 0)
Begin

Declare @Level int
Declare @NoOfLevelRowsEmpty int
Declare @NoOfLevelRows int

Set @Level = @ReasonLevel

	Select @Level = min(ReasonLevel)
	from OverrideRequestReasons (NOLock)
	where RequestID = @ReqID and ReasonID = @ReasonID and @Level < ReasonLevel

	while(@Level is not NULL)
	Begin
	
		if(exists(select 1 from OverrideRequestReasons (NoLock)
							where	RequestID = @ReqID 
								and ReasonID = @ReasonID 
								and ReasonLevel = @Level
								AND WaitLoggedOffUsers = 0))						
		Begin


			Select @NoOfLevelRowsEmpty = count(ReasonID)
			From OverrideRequestReasons  res (NoLock)
			Inner join OverrideRequests req (NoLock)
			on Req.RequestID = Res.RequestID
			Where res.RequestID = @ReqID and ReasonID = @ReasonID and ReasonLevel = @Level							
							AND	
							(	
								(
									IsUser = 1 AND NOT EXISTS (SELECT 1 FROM V_Operator op
															 INNER JOIN TellerConfig
																	ON op.user_number = TellerConfig.[User_ID]
 															WHERE op.LoginID = res.GroupName 												
																AND SignedOnAt <> ''
																AND (op.Branch	= res.TargetBranch	OR	res.TargetBranch = 0)
																AND ((	IsFilterByDepartment = 0)
																		OR (
																			IsFilterByDepartment = 1 
																			AND (res.UserDepartmentID =  TellerConfig.DepartmentID or res.UserDepartmentID is null)
																			)
																	)
																AND op.user_number <> req.user_number
																AND InLockWhenClose = 0
															)
								)		-- the supervisor is logged-off
							
								OR 
								(
									IsUser = 0 AND NOT EXISTS (SELECT 1 FROM V_OperatorRoles opR
																INNER JOIN V_Operator op
																	ON opR.u# = op.user_number
																	AND SignedOnAt <> ''
																INNER JOIN TellerConfig
																	ON op.user_number = TellerConfig.[User_ID]
																WHERE opR.[RoleName] = res.GroupName
																	AND (op.Branch	= res.TargetBranch	OR	res.TargetBranch = 0)
																	AND ((	IsFilterByDepartment = 0)
																		OR (
																			IsFilterByDepartment = 1 
																			AND (res.UserDepartmentID =  TellerConfig.DepartmentID or res.UserDepartmentID is null)
																			)
																		)
																	AND op.user_number <> req.user_number
																	AND InLockWhenClose = 0
																)-- and all users are LoggedOff
								)
							)

			Select @NoOfLevelRows = Count(ReasonID)
			From OverrideRequestReasons (NoLock)
			Where RequestID = @ReqID and ReasonID = @ReasonID and ReasonLevel = @Level             

			if(@NoOfLevelRows = @NoOfLevelRowsEmpty and @NoOfLevelRows > 0)
			Begin

				Update OverrideRequestReasons with (RowLock)
				set Status = @Forward
				Where RequestID = @ReqID and ReasonID = @ReasonID and ReasonLevel = @Level

				Select @Level = min(ReasonLevel)
				from OverrideRequestReasons (NOLock)
				where RequestID = @ReqID and ReasonID = @ReasonID and @Level < ReasonLevel			
				
			End 
			Else
			Begin
				set @Level = NULL -- To exist loop
			End
		
		End -- End of checking that this level Not Wait for Logged Off supervisors
		Else
		Begin
				set @Level = NULL -- To exist loop
		End
		
	End -- End of  while(@Level is not NULL)

End 
-- End Adel Shaban [Ignoring All levels where no Supervisor online]
  
 EXEC dbo.TLR_OV_CheckFinishedReasons @ReqID, @Status, @OverrideRepairFields --,@UpdateAll 
 
 SET NOCOUNT ON  
  
 END      
/*  
else if exists(      
  select * from OperatorSession  os    
  inner join OperatorRoles ORoles    
  on os.User_Number=ORoles.User_Number and lower(os.role)='gfsoperators'    
  where os.User_Number = @UserNum and      
   oRoles.Role in      
   (select CurrentForwardGroup from OverrideRequestReasons       
    where RequestID = @ReqID  and      
    ReasonID = @ReasonID and      
    GroupName = @GrpName and      
    ReasonLevel = @ReasonLevel)      
  )      
 Begin      
  update OverrideRequestReasons      
  set      
   SupervisorUserID = @SupID  ,      
   Status   = @Status  ,      
   SupervisorComments = @SupComment ,      
   CurrentForwardGroup = case @CurrFwdGrp when '' then Null      
       else @CurrFwdGrp end       
  where      
  RequestID  = @ReqID  and      
   ReasonID  = @ReasonID and      
   GroupName  = @GrpName and      
   status   = @Forward and      
   -- check that the request not sent to teller (rejected or timed out)      
   -- in these cases some reasons may be still valid but all request cycle finished      
   Exists( select * from OverrideRequests as OVR      
    where OVR.RequestID = @ReqID      
    and OVR.Status < @Forward ) and      
   ReasonLevel  = @ReasonLevel      
 END          
*/  
return @AffectedRows  

Go
--End of Automatic Generation
-- =============================================
-- Author:		Shimaa nasser
-- Create date: 26/7/2020
-- Description:	Return  PurposeCode and PurposeDescription
-- =============================================

drop_old_proc 'Get_PurposeDescription'
GO
Create Proc Get_PurposeDescription
		@transactionType varchar(50),      ----------(Credit,Debit,Transfer)
		@currencyType char(1)              ----------(Local, Foreign, Both)
As
BEGIN
		IF(@transactionType = 'Credit')
		BEGIN 
			SELECT PurposeCode,PurposeDescription
			FROM [PurposeCodeMapping]
			WHERE CashCredit =1 and (Currency = 'B' or Currency = @currencyType)
		End
		ELSE IF(@transactionType = 'Debit')
		BEGIN 
			SELECT PurposeCode,PurposeDescription
			FROM [PurposeCodeMapping]
			WHERE CashDebit =1 and (Currency = 'B' or Currency = @currencyType)
		END
		ELSE IF(@transactionType = 'Transfer')
		BEGIN 
			SELECT PurposeCode,PurposeDescription
			FROM [PurposeCodeMapping]
			WHERE CashTransfer =1 and (Currency = 'B' or Currency = @currencyType)
		END
END
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00804 Proc Script - dbo.Select_ResendControlsEvents'
GO
 
drop_old_proc 'Select_ResendControlsEvents'
GO
create proc dbo.Select_ResendControlsEvents
@TranName TransactionName
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
	Description	:	SELECT data FROM ResendControlsEvents table 
*/          

SELECT * FROM ResendControlsEvents WHERE TransactionName = @TranName

GO

PRINT 'End... Script for CR# GFSY00804 Proc Script - dbo.Select_ResendControlsEvents'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00804 Proc Script - dbo.Select_ResendAutoFillFields'
GO
 
drop_old_proc 'Select_ResendAutoFillFields'
GO
create proc dbo.Select_ResendAutoFillFields
@TranName TransactionName
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
	Description	:	SELECT data FROM ResendControlsEvents table 
*/          

SELECT FieldName FROM ResendAutoFillFields WHERE TransactionName = @TranName

GO

PRINT 'End... Script for CR# GFSY00804 Proc Script - dbo.Select_ResendAutoFillFields'
GO
DROP_OLD_PROC 'UpdateJournalAndTotals'
GO
CREATE proc [dbo].[UpdateJournalAndTotals]          
  @Bank  BankID        
 ,@Region RegionID        
 ,@Branch BranchID        
 ,@JNLSequence int -- JNLSequence        
 ,@user_number internal_user_ID        
 ,@BusinessDate_Day tinyint        
 ,@year_month smallint        
 ,@BusinessDate SmallDate        
 ,@CashDrawer CashDrawerNumber = NULL        
 ,@Correction bit = 0        
 ,@update_string nvarchar(4000) = NULL-- update T_SQL        
 ,@child_update_string nvarchar(max) ='' -- update T_SQL for child tables.        
    
 ,@Totals_Bucket0 Bucket_ID = NULL        
 ,@Totals_Currency_Type0 CurrencyType = NULL         
 ,@Totals_Batch0 int = NULL -- Batch id number.        
 ,@Totals_BumpBy0 int = NULL        
 ,@Totals_Amount0 money = NULL        
         
 ,@Totals_Bucket1 Bucket_ID = NULL        
 ,@Totals_Currency_Type1 CurrencyType = NULL         
 ,@Totals_Batch1 int = NULL        
 ,@Totals_BumpBy1 int = NULL        
 ,@Totals_Amount1 money =NULL        
         
 ,@Totals_Bucket2 Bucket_ID = NULL        
 ,@Totals_Currency_Type2 CurrencyType = NULL         
 ,@Totals_Batch2 int = NULL        
 ,@Totals_BumpBy2 int = NULL        
 ,@Totals_Amount2 money =NULL        
 ,@Totals_Bucket3 Bucket_ID = NULL        
 ,@Totals_Currency_Type3 CurrencyType = NULL         
 ,@Totals_Batch3 int = NULL        
 ,@Totals_BumpBy3 int = NULL        
 ,@Totals_Amount3 money =NULL        
 ,@Totals_Bucket4 Bucket_ID = NULL        
 ,@Totals_Currency_Type4 CurrencyType = NULL         
 ,@Totals_Batch4 int = NULL        
 ,@Totals_BumpBy4 int = NULL        
 ,@Totals_Amount4 money =NULL        
        
 ,@Totals_Bucket5 Bucket_ID = NULL        
 ,@Totals_Currency_Type5 CurrencyType = NULL         
 ,@Totals_Batch5 int = NULL        
 ,@Totals_BumpBy5 int = NULL        
 ,@Totals_Amount5 money =NULL        
        
 ,@Totals_Bucket6 Bucket_ID = NULL        
 ,@Totals_Currency_Type6 CurrencyType = NULL         
 ,@Totals_Batch6 int = NULL        
 ,@Totals_BumpBy6 int = NULL        
 ,@Totals_Amount6 money =NULL        
        
 ,@Totals_Bucket7 Bucket_ID = NULL        
 ,@Totals_Currency_Type7 CurrencyType = NULL         
 ,@Totals_Batch7 int = NULL        
 ,@Totals_BumpBy7 int = NULL        
 ,@Totals_Amount7 money =NULL        
        
 ,@Totals_Bucket8 Bucket_ID = NULL        
 ,@Totals_Currency_Type8 CurrencyType = NULL         
 ,@Totals_Batch8 int = NULL        
 ,@Totals_BumpBy8 int = NULL        
 ,@Totals_Amount8 money =NULL        
        
 ,@Totals_Bucket9 Bucket_ID = NULL        
 ,@Totals_Currency_Type9 CurrencyType = NULL         
 ,@Totals_Batch9 int = NULL        
 ,@Totals_BumpBy9 int = NULL        
 ,@Totals_Amount9 money =NULL        
        
 ,@Totals_Bucket10 Bucket_ID = NULL        
 ,@Totals_Currency_Type10 CurrencyType = NULL         
 ,@Totals_Batch10 int = NULL        
 ,@Totals_BumpBy10 int = NULL        
 ,@Totals_Amount10 money =NULL        
        
 ,@Totals_Bucket11 Bucket_ID = NULL        
 ,@Totals_Currency_Type11 CurrencyType = NULL         
 ,@Totals_Batch11 int = NULL        
 ,@Totals_BumpBy11 int = NULL        
 ,@Totals_Amount11 money =NULL        
        
 ,@Totals_Bucket12 Bucket_ID = NULL        
 ,@Totals_Currency_Type12 CurrencyType = NULL         
 ,@Totals_Batch12 int = NULL        
 ,@Totals_BumpBy12 int = NULL        
 ,@Totals_Amount12 money =NULL        
        
 ,@Totals_Bucket13 Bucket_ID = NULL        
 ,@Totals_Currency_Type13 CurrencyType = NULL         
 ,@Totals_Batch13 int = NULL        
 ,@Totals_BumpBy13 int = NULL        
 ,@Totals_Amount13 money =NULL        
        
 ,@Totals_Bucket14 Bucket_ID = NULL        
 ,@Totals_Currency_Type14 CurrencyType = NULL         
 ,@Totals_Batch14 int = NULL        
 ,@Totals_BumpBy14 int = NULL        
 ,@Totals_Amount14 money =NULL      
       
 ,@DenomType varchar(4000) =NULL     
 ,@DenomValue varchar(4000) =NULL        
 ,@DenomCurrency varchar(4000) =NULL        
 ,@DenomAmount varchar(4000) =NULL 
 ,@NewUser_number  internal_user_ID = NULL
 ,@NewCashDrawer  CashDrawerNumber = NULL
 ,@debug int = 0        
as        
-- New version of update_totals_array        
-- Update existing totals buckets or insert new ones.        
-- Then set CashDrawer.HasCountedCash OFF.         
-- Then run the Journal update.        
-- All of this is wrapped in a database transaction - All updates are applied or NONE.        
-- Copyright 2008 Getronics USA Inc.  All rights reserved.        
-- 23JUL08 JuanJ - Added @update_children_string to allow updates in Child tables.        
--   in replacement of update_totals_array when VB code elimination completed        
-- 31JUL08 JuanJ - Changed parameters name to match FieldLists names.        
-- 11AUG08 Bodhi - Added tests of @@trancount to avoid updates outside of transactions.         
-- 26AUG08 JuanJ - Only set CashDrawer.HasCountedCash OFF when CashIn /Cash out Bucket.        
-- 04Jul11 mfarouk - Add new parameters (@DenomType,@DenomValue,@DenomCurrency,@DenomAmount) for denomination to be used in calling procedure UpdateCashDrawerDetails      
-- 26Oct11 mfarouk - correct parameteres passed to UpdateCashDrawerDetails    
-- 15Dec12 Asmaa Hafez - change parameteres passed to UpdateCashDrawerDetails from (BrID) to (Bank - Region - Branch)  - CR # 7305    
-- 2014-07-21: Osama Orabi: Issue# GFSX07456: 2.0.46.1319. Enhance the performane by passing the BrID to write to Totals Directly instead of Totlas_2 or V_Old_Totals    
-- 2020-08-12 : Ahmed Osman	: CR GFSY00804 : Replace param @user_number with @NewUser_number and replace @CashDrawer with @NewCashDrawer 
--				in passing params on proc update totals and cash drawers , we send the same data the default behaviour and we change the data in case the supervisor post the transaction from override request
    
set nocount on        
DECLARE @BrID hierarchy_node#;    
SELECT @BrID = dbo.id_of_branch(@Bank,@Region,@Branch)   ;    
    
declare  @BucketID  Bucket_ID, @Amount money, @ctype CurrencyType        
 , @Batch int, @Count int        
declare @sql nvarchar(4000), @param_defs nvarchar(255)        
declare @where nvarchar(400)        
declare @day tinyint        
declare @table_name sysname, @suffix char(7)        
declare @result int, @err int        
--** CR17385 ** S        
declare @IsCashIN_OUTBucket bit        
set @IsCashIN_OUTBucket=0        
--** CR17385 ** E        
set @param_defs         
  = N'@bk BankID, @r RegionID, @br BranchID, @u internal_user_ID,        
  @Seq int, @day tinyint, @ym smallint'        
set @day = @BusinessDate_Day        
set @sql = N'SET NOCOUNT ON' +CHAR(10)+ @update_string+N'        
where user_number = @u        
and JNLSequence = @Seq        
and year_month = @ym        
and BusinessDate_Day = @day        
and Branch = @br        
and Region = @r        
and Bank = @bk'        
SET XACT_ABORT ON        
BEGIN TRAN GJ        
if @debug > 1        
 SELECT @Totals_Bucket0 b0, @Totals_Bucket1 b1, @Totals_Bucket2 b2, @Totals_Bucket3 b3, @Totals_Bucket4 b4, @Totals_Bucket5 b5, @Totals_Bucket6 b6        
        
set @result = 0        
-- call update cashdrawer details in case tran has denom detail      
if @DenomType is Not Null      
Begin     
      
 --declare @BrID varchar(10)    
 --select @BrID = CONVERT(Varchar,dbo.id_of_branch(@Bank,@Region,@Branch))     
    
 exec @result = dbo.UpdateCashDrawerDetails @Bank,@Region,@Branch,@NewCashDrawer,@DenomCurrency      
            ,@DenomAmount      
            ,@DenomType      
            ,@DenomValue      
                
 set @err = @@error        
 if @result <> 0 or @err <> 0       
 begin        
  rollback tran GJ        
  return @result       
 end      
End      
      
if @Totals_Bucket0 is not null BEGIN        
--** CR17385 ** S        
--Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
  if (@IsCashIN_OUTBucket=0)        
 set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket0)        
--** CR17385 ** E        
  exec @result = dbo.write_totals        
  @Bank        
 ,@Region        
 ,@Branch        
 ,@NewUser_number        
 ,@BusinessDate        
 ,@NewCashDrawer        
 ,@Correction        
 ,@Totals_Bucket0        
 ,@Totals_Amount0        
 ,@Totals_Currency_Type0        
 ,@Totals_Batch0        
 ,@Totals_BumpBy0        
 ,@debug    
 , @BrID    
  set @err = @@error        
  if @result <> 0 or @err <> 0 begin        
 rollback tran GJ        
 return @result        
  end        
        
  if @Totals_Bucket1 is not null begin        
 --** CR17385 ** S        
 --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
 if (@IsCashIN_OUTBucket=0)        
  set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket1)        
 --** CR17385 ** E        
 exec @result = dbo.write_totals        
   @Bank        
  ,@Region        
  ,@Branch        
  ,@NewUser_number        
  ,@BusinessDate        
  ,@NewCashDrawer        
  ,@Correction        
  ,@Totals_Bucket1        
  ,@Totals_Amount1        
  ,@Totals_Currency_Type1        
  ,@Totals_Batch1        
  ,@Totals_BumpBy1        
  ,@debug        
  , @BrID    
 set @err = @@error        
 if @result <> 0 or @err <> 0 begin        
  rollback tran GJ        
  return @result        
 end        
 if @Totals_Bucket2 is not null begin        
  --** CR17385 ** S        
  --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
  if (@IsCashIN_OUTBucket=0)        
   set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket2)        
  --** CR17385 ** E        
  exec @result = dbo.write_totals        
    @Bank        
   ,@Region        
   ,@Branch        
   ,@NewUser_number        
   ,@BusinessDate        
   ,@NewCashDrawer        
   ,@Correction        
   ,@Totals_Bucket2        
   ,@Totals_Amount2        
   ,@Totals_Currency_Type2        
   ,@Totals_Batch2        
   ,@Totals_BumpBy2        
   ,@debug        
   , @BrID    
  set @err = @@error        
  if @result <> 0 or @err <> 0 begin        
   rollback tran GJ        
   return @result        
  end        
  if @Totals_Bucket3 is not null begin        
   --** CR17385 ** S        
   --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
   if (@IsCashIN_OUTBucket=0)        
    set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket3)        
   --** CR17385 ** E        
   exec @result = dbo.write_totals        
     @Bank        
    ,@Region        
    ,@Branch        
    ,@NewUser_number        
    ,@BusinessDate        
    ,@NewCashDrawer        
    ,@Correction        
    ,@Totals_Bucket3        
    ,@Totals_Amount3        
    ,@Totals_Currency_Type3        
    ,@Totals_Batch3        
    ,@Totals_BumpBy3        
    ,@debug        
 , @BrID    
   set @err = @@error        
   if @result <> 0 or @err <> 0 begin        
    rollback tran GJ        
    return @result        
   end        
           
   if @Totals_Bucket4 is not null begin        
    --** CR17385 ** S        
    --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
    if (@IsCashIN_OUTBucket=0)        
     set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket4)        
    --** CR17385 ** E        
    exec @result = dbo.write_totals        
      @Bank        
     ,@Region        
     ,@Branch        
     ,@NewUser_number        
     ,@BusinessDate        
     ,@NewCashDrawer        
     ,@Correction        
     ,@Totals_Bucket4        
     ,@Totals_Amount4        
     ,@Totals_Currency_Type4        
     ,@Totals_Batch4        
     ,@Totals_BumpBy4        
     ,@debug        
  , @BrID    
    set @err = @@error        
    if @result <> 0 or @err <> 0 begin        
     rollback tran GJ        
     return @result        
    end        
    if @Totals_Bucket5 is not null begin        
     --** CR17385 ** S        
     --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
     if (@IsCashIN_OUTBucket=0)        
     set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket5)        
     --** CR17385 ** E        
     exec @result = dbo.write_totals        
       @Bank        
      ,@Region        
      ,@Branch        
      ,@NewUser_number        
      ,@BusinessDate        
      ,@NewCashDrawer        
      ,@Correction        
      ,@Totals_Bucket5        
      ,@Totals_Amount5        
      ,@Totals_Currency_Type5        
      ,@Totals_Batch5        
      ,@Totals_BumpBy5        
      ,@debug        
   , @BrID    
     set @err = @@error        
     if @result <> 0 or @err <> 0 begin        
      rollback tran GJ        
  return @result        
     end        
     if @Totals_Bucket6 is not null begin        
      --** CR17385 ** S        
      --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
      if (@IsCashIN_OUTBucket=0)        
       set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket6)        
      --** CR17385 ** E        
      exec @result = dbo.write_totals        
        @Bank        
       ,@Region        
       ,@Branch        
       ,@NewUser_number        
       ,@BusinessDate        
       ,@NewCashDrawer        
       ,@Correction        
       ,@Totals_Bucket6        
       ,@Totals_Amount6        
       ,@Totals_Currency_Type6        
       ,@Totals_Batch6        
       ,@Totals_BumpBy6        
       ,@debug        
    , @BrID    
      set @err = @@error        
      if @result <> 0 or @err <> 0 begin        
       rollback tran GJ        
       return @result        
      end        
      if @Totals_Bucket7 is not null begin        
       --** CR17385 ** S        
       --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
       if (@IsCashIN_OUTBucket=0)        
        set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket7)        
       --** CR17385 ** E        
       exec @result = dbo.write_totals        
         @Bank        
        ,@Region        
        ,@Branch        
        ,@NewUser_number        
        ,@BusinessDate        
        ,@NewCashDrawer        
        ,@Correction        
        ,@Totals_Bucket7        
        ,@Totals_Amount7        
        ,@Totals_Currency_Type7        
        ,@Totals_Batch7        
        ,@Totals_BumpBy7        
        ,@debug        
  , @BrID    
       set @err = @@error        
       if @result <> 0 or @err <> 0 begin        
        rollback tran GJ        
        return @result        
       end        
       if @Totals_Bucket8 is not null begin        
        --** CR17385 ** S        
        --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
        if (@IsCashIN_OUTBucket=0)        
         set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket8)        
        --** CR17385 ** E        
        exec @result = dbo.write_totals        
          @Bank        
         ,@Region        
         ,@Branch        
         ,@NewUser_number        
         ,@BusinessDate        
         ,@NewCashDrawer        
         ,@Correction        
         ,@Totals_Bucket8        
         ,@Totals_Amount8        
         ,@Totals_Currency_Type8        
         ,@Totals_Batch8        
         ,@Totals_BumpBy8        
         ,@debug        
   , @BrID    
        set @err = @@error        
        if @result <> 0 or @err <> 0 begin        
         rollback tran GJ        
         return @result        
        end        
        if @Totals_Bucket9 is not null begin        
         --** CR17385 ** S        
         --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
         if (@IsCashIN_OUTBucket=0)        
          set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket9)        
        --** CR17385 ** E 
         exec @result = dbo.write_totals        
           @Bank        
          ,@Region        
          ,@Branch        
          ,@NewUser_number        
          ,@BusinessDate        
          ,@NewCashDrawer        
          ,@Correction        
          ,@Totals_Bucket9        
          ,@Totals_Amount9        
          ,@Totals_Currency_Type9        
          ,@Totals_Batch9        
          ,@Totals_BumpBy9        
          ,@debug        
    , @BrID    
         set @err = @@error        
         if @result <> 0 or @err <> 0 begin        
          rollback tran GJ        
          return @result        
         end        
         if @Totals_Bucket10 is not null begin        
          --** CR17385 ** S        
          --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
          if (@IsCashIN_OUTBucket=0)        
           set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket10)        
          --** CR17385 ** E        
          exec @result = dbo.write_totals        
            @Bank        
           ,@Region        
           ,@Branch        
           ,@NewUser_number        
           ,@BusinessDate        
           ,@NewCashDrawer        
           ,@Correction        
           ,@Totals_Bucket10        
           ,@Totals_Amount10        
           ,@Totals_Currency_Type10        
           ,@Totals_Batch10        
           ,@Totals_BumpBy10        
           ,@debug        
     , @BrID    
          set @err = @@error        
          if @result <> 0 or @err <> 0 begin        
           rollback tran GJ        
           return @result        
          end        
          if @Totals_Bucket11 is not null begin        
           --** CR17385 ** S        
           --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
           if (@IsCashIN_OUTBucket=0)        
            set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket11)        
           --** CR17385 ** E        
           exec @result = dbo.write_totals        
             @Bank        
            ,@Region        
            ,@Branch        
            ,@NewUser_number        
            ,@BusinessDate        
            ,@NewCashDrawer        
            ,@Correction        
            ,@Totals_Bucket11        
            ,@Totals_Amount11        
            ,@Totals_Currency_Type11        
            ,@Totals_Batch11        
            ,@Totals_BumpBy11        
            ,@debug        
   , @BrID    
           set @err = @@error        
           if @result <> 0 or @err <> 0 begin        
            rollback tran GJ        
            return @result        
           end        
           if @Totals_Bucket12 is not null begin        
            --** CR17385 ** S        
            --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
            if (@IsCashIN_OUTBucket=0)        
             set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket12)        
            --** CR17385 ** E        
            exec @result = dbo.write_totals        
              @Bank        
             ,@Region        
             ,@Branch        
             ,@NewUser_number        
             ,@BusinessDate        
             ,@NewCashDrawer        
             ,@Correction        
             ,@Totals_Bucket12        
             ,@Totals_Amount12        
             ,@Totals_Currency_Type12        
             ,@Totals_Batch12        
             ,@Totals_BumpBy12        
   ,@debug        
   , @BrID    
            set @err = @@error        
            if @result <> 0 or @err <> 0 begin        
             rollback tran GJ        
             return @result        
            end        
            if @Totals_Bucket13 is not null begin        
             --** CR17385 ** S        
             --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
             if (@IsCashIN_OUTBucket=0)        
              set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket13)        
             --** CR17385 ** E        
             exec @result = dbo.write_totals        
               @Bank        
              ,@Region        
              ,@Branch        
              ,@NewUser_number        
              ,@BusinessDate        
              ,@NewCashDrawer        
              ,@Correction        
              ,@Totals_Bucket13        
              ,@Totals_Amount13        
              ,@Totals_Currency_Type13        
              ,@Totals_Batch13        
              ,@Totals_BumpBy13        
              ,@debug        
     , @BrID    
             set @err = @@error        
             if @result <> 0 or @err <> 0 begin        
              rollback tran GJ        
              return @result        
             end        
             if @Totals_Bucket14 is not null begin        
              --** CR17385 ** S        
              --Check if we have a Cash in  / Cash out bucket for  later cashdrawer update        
              if (@IsCashIN_OUTBucket=0)        
               set @IsCashIN_OUTBucket = dbo.Is_CashInCashOutBucket(@Totals_Bucket14)        
              --** CR17385 ** E        
              exec @result = dbo.write_totals        
                @Bank        
               ,@Region        
               ,@Branch        
               ,@NewUser_number        
               ,@BusinessDate        
               ,@NewCashDrawer        
               ,@Correction        
               ,@Totals_Bucket14        
               ,@Totals_Amount14        
               ,@Totals_Currency_Type14        
               ,@Totals_Batch14        
               ,@Totals_BumpBy14        
               ,@debug        
      , @BrID    
              set @err = @@error        
              if @result <> 0 or @err <> 0 begin        
               rollback tran GJ        
               return @result        
              end        
             end        
            end        
   end        
          end        
         end        
        end        
       end        
      end        
     end        
    end        
   end        
  end        
 end        
  end        
 --** CR17385 ** S        
 IF @@TRANCOUNT > 0 and @IsCashIN_OUTBucket=1 begin          
   UPDATE dbo.CashDrawer WITH (UPDLOCK ROWLOCK)        
   set  HasCountedCash = 0        
   WHERE AssignedToTeller = @NewUser_number         
  and Bank = @Bank        
  and Region = @Region        
  and Branch = @Branch        
  and CashDrawerNumber = @NewCashDrawer         
  -- and IsActive = 1        
  and HasCountedCash <> 0        
 end        
 --** CR17385 ** E        
end        
        
if @debug > 0 begin -- Put out SQL statements for debugging.        
 print 'declare ' + @param_defs + char(10)         
 print 'select @bk = ' + cast(isnull(@bank,0) as varchar)        
 print '    , @r = ' + cast(isnull(@region, 0) as varchar)        
 print '    , @br = ' + cast(isnull(@branch, 0) as varchar)        
 print '    , @u = ' + cast(isnull(@user_number, 0) as varchar)        
 print '--  , @BusinessDate = ''' + cast(@BusinessDate as varchar) + ''''        
 print '    , @day = ' + cast(@day as varchar)        
 print '    , @ym = ' + cast(@year_month as varchar)        
 print '    , @Seq = '+ cast(isnull(@JNLSequence, 0) as varchar)        
 print isnull(@sql, '-NULL-')        
end        
        
IF @@TRANCOUNT > 0 AND @update_string is not null begin        
 exec @result = dbo.sp_executesql @sql, @param_defs        
 , @bank, @region, @branch, @user_number        
 , @JNLSequence, @day, @year_month        
 set @err = @@error        
 if @err <> 0 or @result <> 0 begin        
  rollback tran GJ        
  return @err        
 end        
end        
IF @@TRANCOUNT > 0 AND  @child_update_string<>'' begin        
 exec @result = dbo.sp_executesql @child_update_string, N''        
 set @err = @@error        
 if @err <> 0 or @result <> 0 begin        
  rollback tran GJ        
  return @err        
 end        
end        
IF @@TRANCOUNT > 0        
  COMMIT TRAN GJ        
        
RETURN @result 


GO
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Select_EndOfDay_Movements
Go

CREATE PROC dbo.Select_EndOfDay_Movements         
 @Bank BankID,              
 @Region RegionID ,              
 @Branch BranchID ,        
 @CheckPendingStock bit = 1,        
 @CurrentBusinessDate smalldatetime  = null,
 @CloseForNightly int = 0
AS              
SET NOCOUNT ON              
/*              
CreationDate: 2005-03-03              
OriginalName: dbo.Select_EndOfDay_Movements            
Programmer : Ahmed Fahim              
Description : Return all movement was sent to current branch during the day without recieve              
Output  :                
Assumption :               
              
ModifiedDate: 14/1/2010              
Modifer:      Adel Shaban          
ModifyReason: in case of having cash or stock movement pending to vault: select vault name + branch number              
        
ModifiedDate: 21/1/2010              
Modifer:      Ahmed Helmi        
ModifyReason: Addding new parameter "@CheckPendingStock" to enable or disable Cash and Stock Movement validations        
  
  
ModifiedDate: 26/05/2010              
Modifer:      Mohamed Kamel        
ModifyReason: Enable or Disable Cash and Stock Movement validations according to @CheckPendingStock parameter  

ModifiedDate: 2011-06-28
Modifer:      MOhammed Farouk
ModifyReason: Use of memory temp table instead of the UNION select as the columns are nvarchar, which not supported in UNION

   
ModifiedDate: 2011-07-13
Modifer:      Osama Orabi
ModifyReason: CR# 7513, if @CheckCashSent = 0, Any Pending CashMovenemt between branches or headoffice is allowed
						if @CheckCashSent = 1, Make sure there is no pending cash movement period (between branches)exceeded 
						the @PendingCashDays
						
ModifiedDate: 2011-07-27
Modifer:      Osama Orabi
ModifyReason: CR# 7513, Rework

ModifiedDate: 2017-03-02
Modifer:      Nada Elshafie
ModifyReason: If closing for Nightly Mode return only pending cash send movement - GFSY00630 - CBD_CRQ13504


ModifiedDate: 2019-02-12
Modifer:      osama nabil
ModifyReason: Defect#GFSX13519 Optimize Stored Procedure

ModifiedDate: 2020-06-23
Modifer:      osama nabil
ModifyReason: Defect#GFSX14099 
*/              
 
 if(@CurrentBusinessDate is null)
	set @CurrentBusinessDate = dbo.now()
declare @CheckCashSent bit,
		@PendingCashDays int
		
SET @CheckCashSent = 1
SET @PendingCashDays = 0

SELECT @CheckCashSent = convert(bit,ISNULL(Value,'True'))
FROM RulesTranFldParam
WHERE TranName = 'EndOfDay'
	AND FieldName = 'CheckPendingCash'
	And Param = 'CheckCashSent'
   
SELECT @PendingCashDays = convert(int,ISNULL(Value,'0'))
FROM RulesTranFldParam
WHERE TranName = 'EndOfDay'
	AND FieldName = 'CheckPendingCash'
	And Param = 'PendingCashDays'
   
 ---
 declare @ListofTCMovementIDs table(    
    ID int not null)
    
INSERT INTO @ListofTCMovementIDs
select max(id) as id              
from tcmovement WITH (NOLOCK)             
group by RefNo

declare @ListofCashMovementIDs table(    
    ID int not null)    
    
INSERT INTO @ListofCashMovementIDs
select max(id) as id              
from cashmovement WITH (NOLOCK)            
group by RefNo

 
 ---
 
    
declare @ListofIDs table(    
    ToFromID int not null)    
  
insert into @ListofIDs values (1)    
insert into @ListofIDs values (4)    
if (@CheckPendingStock = 1)    
begin    
 -- do not insert from branch to branch   
 insert into @ListofIDs values (3)    
 insert into @ListofIDs values (8)    
end    
--=========================================
declare @ListOfIDsForCash table(ToFromID int not null)
insert into @ListOfIDsForCash values (1)    
insert into @ListOfIDsForCash values (4)    
if (@CheckCashSent = 1)    
begin    
 -- do not insert from branch to branch   
 insert into @ListOfIDsForCash values (3)    
 insert into @ListOfIDsForCash values (8)    
end  
--=========================================
declare @result table
(
	[TO]		nvarchar(200),
	Movement	varchar(50),
	Total		int
)
if(@CloseForNightly=0)
Begin
Insert Into @result ([TO],Movement,Total)	           
select 'TO' =              
 case  m.ToFromID              
 /*Teller*/ when '1' then               
 (              
  SELECT     'Teller : ' + FirstName + ' ' + LastName               
  FROM         Operator   WITH (NOLOCK)           
  WHERE     (user_number = m.ToFromCode)              
 )              
              
 /*Branch*/ when '3' then               
 (              
  SELECT     'Branch : ' + Name              
  FROM         Branch              
  WHERE     (Bank = @Bank) and (Region = @Region) and (Branch = ToFromCode)              
 )              
              
 /*Vault*/ when '4' then               
 (          
            
  SELECT     'Vault : ' + Name          
  FROM         Branch     WITH (NOLOCK)       
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
  --SELECT     'Vault : ' +  m.ToFromCode              
 )              
              
 /*HeadOffice*/ when '8' then               
 (              
  SELECT     'Head Office : ' + Name              
  FROM         Branch WITH (NOLOCK)             
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
               
 end,              
 'TC' as 'Movement',              
 count(m.id) as Total              
from tcmovement as m  WITH (NOLOCK)            
--inner join ( select max(id) as id              
--  from tcmovement              
--  group by RefNo) as r              
inner join @ListofTCMovementIDs as r  
on m.id = r.id              
inner join tofrom as f              
on  m.tofromid = f.id              
where m.TCMovementTypeID = 1 -- send              
and m.user_branch = @Branch              
AND m.ToFromID IN (select * from @ListofIDs)--(1,3,4,8)              
group BY m.ToFromID , m.ToFromCode               


  
 ;WITH StockMov as(
 select * 
 from StockMovement WITH (NOLOCK)
 where MovementTypeID = 1 -- send          
 and user_branch = @Branch          
 and ToFromID IN (select * from @ListofIDs)  
 )
          
--UNION    
          
Insert Into @result ([TO],Movement,Total)              
select  'TO' =              
 case  m.ToFromID              
 /*Teller*/ when '1' then               
 (              
  SELECT     'Teller : ' + FirstName + ' ' + LastName               
  FROM         Operator   WITH (NOLOCK)  
  WHERE     (user_number = m.ToFromCode)              
 )              
              
 /*Branch*/ when '3' then               
 (              
  SELECT     'Branch : ' + Name              
  FROM         Branch   WITH (NOLOCK)           
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
              
 /*Vault*/ when '4' then               
 (              
/*  SELECT     'Vault : ' + Name              
  FROM         Branch              
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
*/        
 SELECT   'Vault : ' + op.FirstName+' '+op.LastName+' at Branch#: '+ cast(op.Branch as varchar(10))          
  FROM      v_operator op          
  Where (op.Bank = @Bank) AND (op.Region = @Region)         
 AND op.user_number =(          
      select top 1 AssignedToTeller          
      from CashDrawer   WITH (NOLOCK)        
      where CashDrawerNumber= ToFromCode AND CashDrawer.Branch=m.User_Branch )        
              
  --SELECT     'Vault : ' +  m.ToFromCode              
 )              
      
 /*HeadOffice*/ when '8' then               
 (              
  SELECT     'Head Office : ' + Name              
  FROM         Branch  WITH (NOLOCK)            
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
               
 end              
 ,              
 s.StockCode AS Movement ,              
 count(m.id) AS Total              
FROM StockMov AS m            
INNER join Stock AS s  WITH (NOLOCK)                    
ON s.lastid = m.id  and m.stockid=s.id      
--WHERE m.MovementTypeID = 1 -- Send              
--AND m.User_Branch = @Branch           
--AND (m.ToFromID IN (select * from @ListofIDs)) --(1,3,4,8)    
GROUP  BY               
 m.ToFromID , m.ToFromCode , s.StockCode,m.User_Branch                
End              
--UNION              

 ;WITH CashMov as(
 select * 
 from CashMovement WITH (NOLOCK)
 where movementtype = 1           
 and user_branch = @Branch          
 and ToFromID IN (select * from @ListOfIDsForCash)  
 AND (
		 ToFromID in (1,4)
		OR (@CheckCashSent = 1 AND ToFromID in (3,8) AND  dateadd(day,@PendingCashDays,date_time)<= @CurrentBusinessDate)
	)
 )              
-- any cash movement              
Insert Into @result ([TO],Movement,Total)
select  'TO' =              
 case  m.ToFromID              
 /*Teller*/ when '1' then               
 (              
  SELECT     'Teller : ' + FirstName + ' ' + LastName               
  FROM         Operator  WITH (NOLOCK)            
  WHERE     (user_number = m.ToFromCode)              
 )              
              
 /*Branch*/ when '3' then               
 (            
  SELECT     'Branch : ' + Name              
  FROM         Branch  WITH (NOLOCK)            
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
              
 /*Vault*/ when '4' then               
(          
              
  SELECT   'Vault : ' + op.FirstName+' '+op.LastName+' at Branch#: '+ cast(op.Branch as varchar(10))          
  FROM      v_operator op          
  Where (op.Bank = @Bank) AND (op.Region = @Region)         
 AND op.user_number =(          
      select top 1 AssignedToTeller          
      from CashDrawer  WITH (NOLOCK)         
      where CashDrawerNumber= ToFromCode        
      )          
          
  --SELECT     'Vault : ' +  m.ToFromCode              
 )              
              
 /*HeadOffice*/ when '8' then               
 (              
  SELECT     'Head Office : ' + Name              
  FROM         Branch  WITH (NOLOCK)            
  WHERE     (Bank = @Bank) AND (Region = @Region) AND (Branch = ToFromCode)              
 )              
              
 end              
 , 'Cash' as Movement , count(m.id) as Total              
from CashMov as m              
--inner join ( select max(id) as id              
--  from cashmovement              
--  group by RefNo) as r              
inner join @ListofCashMovementIDs as r
on m.id = r.id              
inner join tofrom as f              
on  m.tofromid = f.id              
--where m.movementtype = 1 -- send              
--and m.user_branch = @Branch              
--AND m.ToFromID IN (select * from @ListOfIDsForCash)--(1,3,4,8) 
--AND (--@CheckCashSent = 0 --(1,4) only will be retrieved
--		--OR
--		 m.ToFromID in (1,4)
--		OR (@CheckCashSent = 1 AND m.ToFromID in (3,8) AND  dateadd(day,@PendingCashDays,m.date_time)<= @CurrentBusinessDate)
--	)
	
group BY m.ToFromID , m.ToFromCode               

Select * From @result

Go
--End of Automatic Generation
drop_old_proc TLR_OV_GetReqData
GO
CREATE PROCEDURE dbo.TLR_OV_GetReqData     
 @ReqID  int   ,                
 @isResponse bit  = 1 ,                
 @ReasonID int  = 0 ,				     
 @GrpName RoleName = '' ,                
 @UserNum int  = 0     ,            
 @ReasonLevel int = 0            
AS                
/*                
CreationDate: 11/6/2007                
OriginalName: dbo.TLR_OV_GetReqData                
Programmer: Ahmed Rafat                
Description: get override Request Data and TranFLdList from HO                
Output:                  
Assumption:                 
                
ModifiedDate: 11/6/2007                
Programmer: Adel Shaban              
Reason:               
            
ModifiedDate: 21/08/2008             
Programmer:  Osama Orabi            
Reason:  Adding ReasonLevel to Primary Key of OverrideRequestReasons            
   Retrieving Date from OverrideRequestReasons by ReqID,ReasonID,GrpName,ReasonLevel            
          
ModifiedDate: 5/8/2009          
Programmer:  Adel Shaban           
Reason:  return column OVRR.SendTimeStamp as SendDate          
        
ModifiedDate: 13/10/2009          
Programmer:  Ahmed Hashem         
Reason:  join with tables  rulestranname,rulesdescriptor to get transaction description        
    
ModifiedDate: 18/10/2009          
Programmer:  Amira Kamel    
Reason:  Change the order of selection to Descriptor    

Modifier: Osama Orabi
Date	: 2010-03-23
Reason	: Performance Tuning

  
Modifier: Osama Nabil
Date : 2015-02-18
Reason : add Override_Descriptor to result set 

Modifier: Mostafa Sayed
Date : 2020-09-09
Reason : Issue#GFSX14194 - Return Amount & Currency fields from Journal.
*/  
          
              
                
SET NOCOUNT ON
--Declarations                
--------------                
declare @Forward int                
-- status -- select * from Status where StatusTypeID = 28                
set @Forward = 6                 
                
-- if data requested from teller - override response - don't check status                 
if(@isResponse =  1)                
Begin                
	select  OVR.RequestID  ,                
			OVR.Bank  ,                
			OVR.Region  ,                
			OVR.Branch  ,                
			OVR.User_Number  ,                
			OVR.BusinessDate ,                      
			OVR.TransactionName ,              
			'' as TranFieldListBlob ,                
			OVR.JNL_Seq  ,                
			NULL as ActionID ,                
			OP.LoginID  ,                
			OP.FirstName + ' ' + OP.LastName as FullName,          
			Null as SendDate,
			Descriptor           
	from OverrideRequests as OVR    (NOLOCK)        
		inner join Operator as OP                
			on OP.User_Number = OVR.User_Number                
			and  OVR.RequestID = @ReqID                
		inner join rulestranname as T 
			on OVR.TransactionName = T.TransactionName          
		inner join rulesdescriptor as D 
			on D.DescriptorID=T.DSC_Description            
		
                
 -- and OVR.Status < @Forward                
End                
                
-- if data requested from supervisor check if request already updated by another supervisor.                
Else                
               
Begin                 
	select  OVR.RequestID   ,                
			OVR.Bank  ,                
			OVR.Region  ,                
			OVR.Branch  ,                
			OVR.User_Number  ,                
			OVR.BusinessDate ,                     
			OVR.TransactionName ,                
			'' as TranFieldListBlob ,                
			OVR.JNL_Seq  ,                
			OVRR.ActionID  ,                
			OP.LoginID  ,                
			OP.FirstName + ' ' + OP.LastName as FullName,          
			OVRR.SendTimeStamp as SendDate,
			d.Descriptor  ,
			CASE
				WHEN OD.Override_Descriptor IS NULL OR OD.Override_Descriptor='' THEN 'TLR_OverrideCorrection' 
			    ELSE OD.Override_Descriptor 
			END as Override_Descriptor
			,JNL.Amount  
			,JNL.AmountCurrType      
	from OverrideRequestReasons as OVRR (NOLOCK)
		inner join OverrideRequests as OVR  (NOLOCK)
			on OVR.RequestID = OVRR.RequestID                
			and OVRR.ReasonID = @ReasonID                
			and OVRR.GroupName = @GrpName                
			and  OVR.RequestID = @ReqID   
			-- check that the whole request not accepted or rejected                 
			and OVR.Status  < @Forward               
			and OVRR.ReasonLevel = @ReasonLevel             
		inner join Operator as OP                
			on OP.User_Number = OVR.User_Number                
			and OP.User_Number <> @UserNum            
		inner join rulestranname as T 
			on OVR.TransactionName = T.TransactionName          
		inner join rulesdescriptor as D 
			on D.DescriptorID=T.DSC_Description
		LEFT OUTER JOIN Override OV on OV.id=OVRR.ReasonID
		LEFT OUTER JOIN OverrideDescriptor OD ON OD.Id=OV.override_description_Id
		inner join Journal JNL  
		on OVR.Bank=JNL.Bank and OVR.Region=JNL.Region and OVR.Branch=JNL.Branch  
		and OVR.User_Number=JNL.user_number and OVR.BusinessDate=JNL.BusinessDate  
		and OVR.TransactionName=JNL.TranName and OVR.JNL_Seq=JNL.JNLSequence  
End     



Go

drop_old_proc SelectLocalInwardMsgs
GO
CREATE PROC dbo.SelectLocalInwardMsgs
@Queue	int,
@Status	int
AS
/*  

ModifiedDate: 26-08-2015

Modifer  : Nada Elshafie    

ModifyReason: select Local Inward Messages 

------------------------------------------

ModifiedDate: 26-02-2016

Modifer  : Karim Mahmoud    

ModifyReason: select Exception reason and Name Matching Percent also in case exception

-------------------------------------------
ModifiedDate: 04-08-2020

Modifer  : Mostafa Helmy    

ModifyReason: select Exception reason Code - GFSY00806

*/  

if(@Queue=2)--Exception
	begin
		Select
		D.MSGID as TLR_PDC_CHG_AC_NUMBER, 
		TranIdentification as TLR_PDC_DR_AC_NUMBER,
		Creditor as TLR_PDC_COR_NAME, 
		InterbankSettCCY as TLR_PDC_COR_DIRECT_OPT_DSC,
		InterbankSettAMT as TLR_BILL_AMOUNT,
		CreditorAccount as TLR_PDC_DEST_BK_NAME,
		Debtor as TLR_PDC_DEST_BK_ACCT,
		MSGName as TLR_PDC_DEST_BK_COUNTRY, 
		CreationDateTime as TLR_SC_Cheque_DATE_ARR,
		RemittanceInformation as TLR_PDC_DEST_DETAILS,
		Purpose as TLR_PDC_COR_ID,
		D.Status as TLR_PDC_COR_DIRECT_OPT,
		Queue as TLR_PDC_CLEAR_BANK_BRANCH_ID,
		EndtoEndIdentification as EndtoEndId,
		DebtorAgent as DebtorAgent,
		CreditorAgent as CreditorAgent,
		Status.LongDescription as TLR_PDC_DEST_ADDRESS1,
		ISNULL(NameMatchPercent,'') as TLR_PDC_DEST_ADDRESS2,
		ISNULL(RejectionReason,'') as TLR_PDC_DEST_INSTRUCTIONS,
		D.ExceptionReason,
		ISNULL(D.ReferenceNumber,'') as TLR_PDC_TYPR_STATUS_DESC
		from Local_Inward_Messages_Header H
		inner join Local_Inward_Messages_Detail D
		on H.MSGID=D.MSGID
		inner join Status
		on Status.id=D.ExceptionReason
		where Queue=@Queue and D.status=@Status and Status.StatusTypeID=72
	end
else
	begin
		Select
		D.MSGID as TLR_PDC_CHG_AC_NUMBER, 
		TranIdentification as TLR_PDC_DR_AC_NUMBER,
		Creditor as TLR_PDC_COR_NAME, 
		InterbankSettCCY as TLR_PDC_COR_DIRECT_OPT_DSC,
		InterbankSettAMT as TLR_BILL_AMOUNT,
		CreditorAccount as TLR_PDC_DEST_BK_NAME,
		Debtor as TLR_PDC_DEST_BK_ACCT,
		MSGName as TLR_PDC_DEST_BK_COUNTRY, 
		CreationDateTime as TLR_SC_Cheque_DATE_ARR,
		RemittanceInformation as TLR_PDC_DEST_DETAILS,
		Purpose as TLR_PDC_COR_ID,
		Status as TLR_PDC_COR_DIRECT_OPT,
		Queue as TLR_PDC_CLEAR_BANK_BRANCH_ID,
		EndtoEndIdentification as EndtoEndId,
		DebtorAgent as DebtorAgent,
		CreditorAgent as CreditorAgent,
		NULL as TLR_PDC_DEST_ADDRESS1,
		ISNULL(NameMatchPercent,'') as TLR_PDC_DEST_ADDRESS2,
		ISNULL(RejectionReason,'') as TLR_PDC_DEST_INSTRUCTIONS,
		D.ExceptionReason,
		ISNULL(D.ReferenceNumber,'') as TLR_PDC_TYPR_STATUS_DESC
		from Local_Inward_Messages_Header H
		inner join Local_Inward_Messages_Detail D
		on H.MSGID=D.MSGID
		where Queue=@Queue and status=@Status
	end
GO
drop_old_proc UpdateLocalInwardMsgs
GO
CREATE PROC dbo.UpdateLocalInwardMsgs
@MSGID	varchar(35),
@TranIdentification	varchar(35),
@Purpose	int,
@RemittanceInformation	varchar(140),
@Queue	int,
@Status	int,
@ExceptionReason	int=null,
@RejectionReason  varchar(10)=null,
@ReferenceNumber nvarchar(30)=null
AS
/*  

ModifiedDate: 31-08-2015

Modifer  : Nada Elshafie    

ModifyReason: Update Local Inward Messages 

------------------------------------------

ModifiedDate: 26-02-2016

Modifer  : Karim Mahmoud  

ModifyReason: Update Rejection reason also 

-------------------------------------------
ModifiedDate: 04-08-2020

Modifer  : Mostafa Helmy    

ModifyReason: Update ReferenceNumber - GFSY00806

*/  
Declare @OriginalExceptionReason int
select @OriginalExceptionReason=exceptionReason from Local_Inward_Messages_Detail where  MSGID=@MSGID and TranIdentification=@TranIdentification
update Local_Inward_Messages_Detail
set Purpose=@Purpose,
RemittanceInformation=@RemittanceInformation,
Queue=@Queue,
Status=@Status,
ExceptionReason=coalesce(@ExceptionReason,@OriginalExceptionReason),
RejectionReason=@RejectionReason,
ReferenceNumber=@ReferenceNumber
where MSGID=@MSGID and TranIdentification=@TranIdentification

GO
drop_old_proc SelectLocalInwardMsgs
GO
CREATE PROC dbo.SelectLocalInwardMsgs
@Queue	int,
@Status	int
AS
/*  

ModifiedDate: 26-08-2015

Modifer  : Nada Elshafie    

ModifyReason: select Local Inward Messages 

------------------------------------------

ModifiedDate: 26-02-2016

Modifer  : Karim Mahmoud    

ModifyReason: select Exception reason and Name Matching Percent also in case exception

-------------------------------------------
ModifiedDate: 04-08-2020

Modifer  : Mostafa Helmy    

ModifyReason: select Exception reason Code,InterBankSettDate - GFSY00806

*/  

if(@Queue=2)--Exception
	begin
		Select
		D.MSGID as TLR_PDC_CHG_AC_NUMBER, 
		TranIdentification as TLR_PDC_DR_AC_NUMBER,
		Creditor as TLR_PDC_COR_NAME, 
		InterbankSettCCY as TLR_PDC_COR_DIRECT_OPT_DSC,
		InterbankSettAMT as TLR_BILL_AMOUNT,
		CreditorAccount as TLR_PDC_DEST_BK_NAME,
		Debtor as TLR_PDC_DEST_BK_ACCT,
		MSGName as TLR_PDC_DEST_BK_COUNTRY, 
		CreationDateTime as TLR_SC_Cheque_DATE_ARR,
		RemittanceInformation as TLR_PDC_DEST_DETAILS,
		Purpose as TLR_PDC_COR_ID,
		D.Status as TLR_PDC_COR_DIRECT_OPT,
		Queue as TLR_PDC_CLEAR_BANK_BRANCH_ID,
		EndtoEndIdentification as EndtoEndId,
		DebtorAgent as DebtorAgent,
		CreditorAgent as CreditorAgent,
		Status.LongDescription as TLR_PDC_DEST_ADDRESS1,
		ISNULL(NameMatchPercent,'') as TLR_PDC_DEST_ADDRESS2,
		ISNULL(RejectionReason,'') as TLR_PDC_DEST_INSTRUCTIONS,
		D.ExceptionReason,
		ISNULL(D.ReferenceNumber,'') as TLR_PDC_TYPR_STATUS_DESC,
		H.InterBankSettDate
		from Local_Inward_Messages_Header H
		inner join Local_Inward_Messages_Detail D
		on H.MSGID=D.MSGID
		inner join Status
		on Status.id=D.ExceptionReason
		where Queue=@Queue and D.status=@Status and Status.StatusTypeID=72
	end
else
	begin
		Select
		D.MSGID as TLR_PDC_CHG_AC_NUMBER, 
		TranIdentification as TLR_PDC_DR_AC_NUMBER,
		Creditor as TLR_PDC_COR_NAME, 
		InterbankSettCCY as TLR_PDC_COR_DIRECT_OPT_DSC,
		InterbankSettAMT as TLR_BILL_AMOUNT,
		CreditorAccount as TLR_PDC_DEST_BK_NAME,
		Debtor as TLR_PDC_DEST_BK_ACCT,
		MSGName as TLR_PDC_DEST_BK_COUNTRY, 
		CreationDateTime as TLR_SC_Cheque_DATE_ARR,
		RemittanceInformation as TLR_PDC_DEST_DETAILS,
		Purpose as TLR_PDC_COR_ID,
		Status as TLR_PDC_COR_DIRECT_OPT,
		Queue as TLR_PDC_CLEAR_BANK_BRANCH_ID,
		EndtoEndIdentification as EndtoEndId,
		DebtorAgent as DebtorAgent,
		CreditorAgent as CreditorAgent,
		NULL as TLR_PDC_DEST_ADDRESS1,
		ISNULL(NameMatchPercent,'') as TLR_PDC_DEST_ADDRESS2,
		ISNULL(RejectionReason,'') as TLR_PDC_DEST_INSTRUCTIONS,
		D.ExceptionReason,
		ISNULL(D.ReferenceNumber,'') as TLR_PDC_TYPR_STATUS_DESC,
		H.InterBankSettDate
		from Local_Inward_Messages_Header H
		inner join Local_Inward_Messages_Detail D
		on H.MSGID=D.MSGID
		where Queue=@Queue and status=@Status --and  H.InterBankSettDate<=@BusinessDate
	end
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/08/2020]		
--Reason	:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
--===============================================================

PRINT 'Start. Script for CR# GFSY00807 Proc Script - dbo.GetIRTotalMessagesAndAmount'
GO

drop_old_proc 'GetIRTotalMessagesAndAmount'
GO
create proc dbo.GetIRTotalMessagesAndAmount		--GetIRTotalMessagesAndAmount 'PostedQueue',1
@QueueType nvarchar(max),
@LoadRatesFromIR int
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
	Description	:	Select Total Messages And Total Amount from table IR based on specify status 
*/          

IF @LoadRatesFromIR = 0
	BEGIN
		SELECT COUNT(*) AS 'MessagesCount' , 0 AS 'SumOfAmount'
			FROM IR INNER JOIN IR_QueueOptionsMapping 
				ON IR.StatusID = IR_QueueOptionsMapping.IRStatusID
				WHERE IR_QueueOptionsMapping.QueueType = @QueueType
				AND ((@QueueType = 'ApprovedQueue'	AND IR.PaymentMethodID IN (1,2,3)) 
		         OR (@QueueType = 'ExceptionQueue' AND IR.StatusID = 1 AND IR.PaymentMethodID NOT IN (1,2,3))
		         OR (@QueueType = 'ExceptionQueue' AND IR.StatusID <> 1 AND IR.PaymentMethodID IN (1,2,3,4))
		         OR (@QueueType = 'PostedQueue')
		         OR (@QueueType = 'OtherQueue'))
	END
ELSE 
	BEGIN
		DECLARE @MessagesCount int
		DECLARE @SumOfAmount decimal

		SELECT @MessagesCount = COUNT(*)
			FROM IR INNER JOIN IR_QueueOptionsMapping 
				ON IR.StatusID = IR_QueueOptionsMapping.IRStatusID
				WHERE IR_QueueOptionsMapping.QueueType = @QueueType
				AND ((@QueueType = 'ApprovedQueue'	AND IR.PaymentMethodID IN (1,2,3)) 
		         OR (@QueueType = 'ExceptionQueue' AND IR.StatusID = 1 AND IR.PaymentMethodID NOT IN (1,2,3))
		         OR (@QueueType = 'ExceptionQueue' AND IR.StatusID <> 1 AND IR.PaymentMethodID IN (1,2,3,4))
		         OR (@QueueType = 'PostedQueue')
		         OR (@QueueType = 'OtherQueue'))

		SELECT @SumOfAmount = SUM(TTAmount * CrBuyExchangeRate / CrExchangeRate) 
			FROM IR INNER JOIN IR_QueueOptionsMapping 
				ON IR.StatusID = IR_QueueOptionsMapping.IRStatusID
				WHERE IR_QueueOptionsMapping.QueueType = @QueueType and CrExchangeRate > 0
				AND ((@QueueType = 'ApprovedQueue'	AND IR.PaymentMethodID IN (1,2,3)) 
		         OR (@QueueType = 'ExceptionQueue' AND IR.StatusID = 1 AND IR.PaymentMethodID NOT IN (1,2,3))
		         OR (@QueueType = 'ExceptionQueue' AND IR.StatusID <> 1 AND IR.PaymentMethodID IN (1,2,3,4))
		         OR (@QueueType = 'PostedQueue')
		         OR (@QueueType = 'OtherQueue'))

		SELECT @MessagesCount AS 'MessagesCount' , @SumOfAmount AS 'SumOfAmount'
	END

GO

PRINT 'End... Script for CR# GFSY00807 Proc Script - dbo.GetIRTotalMessagesAndAmount'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/08/2020]		
--Reason	:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
--===============================================================

PRINT 'Start. Script for CR# GFSY00807 Proc Script - dbo.Select_IR_DynamicException'
GO

drop_old_proc 'Select_IR_DynamicException'
GO
create proc dbo.Select_IR_DynamicException
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
	Description	:	SELECT data FROM IR_DynamicException table 
*/          

SELECT * FROM IR_DynamicException

GO

PRINT 'End... Script for CR# GFSY00807 Proc Script - dbo.Select_IR_DynamicException'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/08/2020]		
--Reason	:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
--===============================================================

PRINT 'Start. Script for CR# GFSY00807 Proc Script - dbo.Select_IR_DynamicExceptionCondition'
GO

drop_old_proc 'Select_IR_DynamicExceptionCondition'
GO
create proc dbo.Select_IR_DynamicExceptionCondition
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
	Description	:	SELECT data FROM IR_DynamicExceptionCondition table 
*/          

SELECT * FROM IR_DynamicExceptionCondition 

GO

PRINT 'End... Script for CR# GFSY00807 Proc Script - dbo.Select_IR_DynamicExceptionCondition'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/08/2020]		
--Reason	:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
--===============================================================

PRINT 'Start. Script for CR# GFSY00807 Proc Script - dbo.Select_IR_QueueMessages'
GO

drop_old_proc 'Select_IR_QueueMessages'		
GO
create proc dbo.Select_IR_QueueMessages		
@QueueType			nvarchar(max),
@ValueDate			nvarchar(max)	= NULL,
@FileRefNo			nvarchar(max)	= NULL,
@DrAccountNo		nvarchar(max)	= NULL,
@CrAccountNo		nvarchar(max)	= NULL,
@DrAccountName		nvarchar(max)	= NULL,
@MsgRefNo			nvarchar(max)	= NULL,
@DrCurrency			nvarchar(max)	= NULL,
@CrCurrency			nvarchar(max)	= NULL,
@MsgValueDateFrom	nvarchar(max)	= NULL,
@MsgValueDateTo		nvarchar(max)	= NULL,
@Fld_50K			nvarchar(max)	= NULL,
@Fld_20				nvarchar(max)	= NULL,
@StatusID			int				= NULL,
@PaymentMethodID	int				= NULL,
@SendToID			int				= NULL,
@ActionID			int				= NULL,
@DrAmount			money			= NULL,
@CrAmount			money			= NULL,
@NumberOfMessages	int				= NULL
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
	Description	:	Select all messages from table IR based on specify status 
*/          

SELECT TOP(@NumberOfMessages) 'false' AS 'Selection' , IR.* FROM 
	IR INNER JOIN IR_QueueOptionsMapping 
		ON IR.StatusID = IR_QueueOptionsMapping.IRStatusID
		WHERE IR_QueueOptionsMapping.QueueType = @QueueType
		AND ValueDate <= @ValueDate
		AND FileRefNo			= CASE WHEN @FileRefNo			IS NULL THEN FileRefNo			ELSE @FileRefNo			END
		AND StatusID			= CASE WHEN @StatusID			IS NULL THEN StatusID			ELSE @StatusID			END
		AND PaymentMethodID		= CASE WHEN @PaymentMethodID	IS NULL THEN PaymentMethodID	ELSE @PaymentMethodID	END
		AND DrAccountName		= CASE WHEN @DrAccountName		IS NULL THEN DrAccountName		ELSE @DrAccountName		END
		AND MsgRefNo			= CASE WHEN @MsgRefNo			IS NULL THEN MsgRefNo			ELSE @MsgRefNo			END
		AND DrCurrency			= CASE WHEN @DrCurrency			IS NULL THEN DrCurrency			ELSE @DrCurrency		END
		AND CrCurrency			= CASE WHEN @CrCurrency			IS NULL THEN CrCurrency			ELSE @CrCurrency		END
		AND MsgValueDate	   >= CASE WHEN @MsgValueDateFrom	IS NULL THEN MsgValueDate		ELSE @MsgValueDateFrom	END
		AND MsgValueDate	   <= CASE WHEN @MsgValueDateTo		IS NULL THEN MsgValueDate		ELSE @MsgValueDateTo	END
		AND Fld_50K				= CASE WHEN @Fld_50K			IS NULL THEN Fld_50K			ELSE @Fld_50K			END
		AND Fld_20				= CASE WHEN @Fld_20				IS NULL THEN Fld_20				ELSE @Fld_20			END
		AND DrAmount			= CASE WHEN @DrAmount			IS NULL THEN DrAmount			ELSE @DrAmount			END
		AND CrAmount			= CASE WHEN @CrAmount			IS NULL THEN CrAmount			ELSE @CrAmount			END
		AND SendToID			= CASE WHEN @SendToID			IS NULL THEN SendToID			ELSE @SendToID			END
		AND ActionID			= CASE WHEN @ActionID			IS NULL THEN ActionID			ELSE @ActionID			END
		AND DrAccountNo			= CASE WHEN @DrAccountNo		IS NULL THEN DrAccountNo		ELSE @DrAccountNo		END
		AND CrAccountNo			= CASE WHEN @CrAccountNo		IS NULL THEN CrAccountNo		ELSE @CrAccountNo		END
		AND ((@QueueType = 'ApprovedQueue'	AND IR.PaymentMethodID IN (1,2,3)) 
		  OR (@QueueType = 'ExceptionQueue' AND IR.StatusID = 1 AND IR.PaymentMethodID NOT IN (1,2,3))
		  OR (@QueueType = 'ExceptionQueue' AND IR.StatusID <> 1 AND IR.PaymentMethodID IN (1,2,3,4))
		  OR (@QueueType = 'PostedQueue')
		  OR (@QueueType = 'OtherQueue'))

GO

PRINT 'End... Script for CR# GFSY00807 Proc Script - dbo.Select_IR_QueueMessages'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/08/2020]		
--Reason	:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
--===============================================================

PRINT 'Start. Script for CR# GFSY00807 Proc Script - dbo.Select_IR_QueueOptionsMapping'
GO

drop_old_proc 'Select_IR_QueueOptionsMapping'
GO
create proc dbo.Select_IR_QueueOptionsMapping
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
	Description	:	SELECT data FROM IR_QueueOptionsMapping table 
*/          

SELECT * FROM IR_QueueOptionsMapping

GO

PRINT 'End... Script for CR# GFSY00807 Proc Script - dbo.Select_IR_QueueOptionsMapping'
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/08/2020]		
--Reason	:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
--===============================================================

PRINT 'Start. Script for CR# GFSY00807 Proc Script - dbo.UpdateIRMessages'
GO

drop_old_proc 'UpdateIRMessages'
GO
create proc dbo.UpdateIRMessages		
@Messages IRMessages READONLY
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[01/07/2020]		
	Reason		:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
	Description	:	Update IR Messages 
*/          

BEGIN TRY
    BEGIN TRANSACTION 
        UPDATE IR WITH (ROWLOCK)
			SET DrAccountNo					= MSG.DrAccountNo,
				DrAccountNo_AcctType		= MSG.DrAccountNo_AcctType,
				DrAccountNo_ApplType		= MSG.DrAccountNo_ApplType,
				DrAccountName				= MSG.DrAccountName,
				Ordering_IBAN				= MSG.Ordering_IBAN,
				DrAccountNo_DepLoan			= MSG.DrAccountNo_DepLoan,
				DrCurrency					= MSG.DrCurrency,
				DrAmount					= MSG.DrAmount,
				DrCommission				= MSG.DrCommission,
				DrExchangeRate				= MSG.DrExchangeRate,
				DrSellExchangeRate			= MSG.DrSellExchangeRate,
				DrValueDate					= MSG.DrValueDate,
				DrNarrative					= MSG.DrNarrative,
				GTDTicket					= MSG.GTDTicket,
				CrAccountNo					= MSG.CrAccountNo,
				CrAccountNo_AcctType		= MSG.CrAccountNo_AcctType,
				CrAccountNo_ApplType		= MSG.CrAccountNo_ApplType,
				CrAccountName				= MSG.CrAccountName,
				IBAN						= MSG.IBAN,
				CrRimNo						= MSG.CrRimNo,
				CrAccountNo_DepLoan			= MSG.CrAccountNo_DepLoan,
				CrCurrency					= MSG.CrCurrency,
				CrAmount					= MSG.CrAmount,
				CrCommission				= MSG.CrCommission,
				CrBuyExchangeRate			= MSG.CrBuyExchangeRate,
				CrExchangeRate				= MSG.CrExchangeRate,
				CrValueDate					= MSG.CrValueDate,
				CrNarrative					= MSG.CrNarrative,
				BeneficiaryGTDTicket		= MSG.BeneficiaryGTDTicket,
				OldDrAccountNo				= MSG.OldDrAccountNo,
				OldDrAccountNo_AcctType		= MSG.OldDrAccountNo_AcctType,
				OldDrAccountNo_ApplType		= MSG.OldDrAccountNo_ApplType,
				OldDrAccountName			= MSG.OldDrAccountName,
				OldDrAccountNo_DepLoan		= MSG.OldDrAccountNo_DepLoan,
				OldDrCurrency				= MSG.OldDrCurrency,
				OldDrAmount					= MSG.OldDrAmount,
				OldDrCommission				= MSG.OldDrCommission,
				OldDrExchangeRate			= MSG.OldDrExchangeRate,
				OldDrValueDate				= MSG.OldDrValueDate,
				OldDrNarrative				= MSG.OldDrNarrative,
				OldCrAccountNo				= MSG.OldCrAccountNo,
				OldCrAccountNo_AcctType		= MSG.OldCrAccountNo_AcctType,
				OldCrAccountNo_ApplType		= MSG.OldCrAccountNo_ApplType,
				OldCrAccountName			= MSG.OldCrAccountName,
				OldCrAccountNo_DepLoan		= MSG.OldCrAccountNo_DepLoan,
				OldCrCurrency				= MSG.OldCrCurrency,
				OldCrAmount					= MSG.OldCrAmount,
				OldCrCommission				= MSG.OldCrCommission,
				OldCrExchangeRate			= MSG.OldCrExchangeRate,
				OldCrValueDate				= MSG.OldCrValueDate,
				OldCrNarrative				= MSG.OldCrNarrative,
				OldStatusID					= MSG.OldStatusID,
				ActionID					= MSG.ActionID,
				StatusID					= MSG.StatusID,
				PaymentMethodID				= MSG.PaymentMethodID,
				ExceptionList				= MSG.ExceptionList,
				Updator						= MSG.Updator,
				ApprovedBy					= MSG.Updator,
				AuthorizedBy				= MSG.Updator,
				ReverseReaason				= MSG.ReverseReason,
				OtherReason					= MSG.OtherReason,
				HostRefNo					= CASE WHEN MSG.HostRefNo IS NULL THEN IR.HostRefNo ELSE MSG.HostRefNo END
			FROM IR JOIN @Messages MSG
				ON IR.MsgRefNo = MSG.MsgRefNo
				WHERE IR.MsgRefNo = MSG.MsgRefNo 
    COMMIT
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK
END CATCH

GO

PRINT 'End... Script for CR# GFSY00807 Proc Script - dbo.UpdateIRMessages'
GO