If Not Exists(Select * from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME = 'ATM' And COLUMN_NAME = 'ATMType_2')
Begin
	Alter Table ATM ADD ATMType_2 nvarchar(50)   NULL
End
GO
 --Devolper :	Aya Tarek
--Date       :	[23/5/2022]		
--Reason     :	CR#GFSY00908 - ACM000000020088 - AML Integration
--=============================================================
PRINT 'Start. Script for CR# GFSY00908 Table  Script'
GO
--------------------------
-- Alter Table AML_Info --
--------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'RimName')
BEGIN
	ALTER TABLE AML_Info
	ADD RimName nvarchar(max) NULL
END
GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'ParentRequestID')
BEGIN
	ALTER TABLE AML_Info
	ADD ParentRequestID nvarchar(20) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'RelatedRimNumber')
BEGIN
	ALTER TABLE AML_Info
	ADD RelatedRimNumber nvarchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'RelatedRimName')
BEGIN
	ALTER TABLE AML_Info
	ADD RelatedRimName nvarchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'RelatedRimType')
BEGIN
	ALTER TABLE AML_Info
	ADD RelatedRimType nvarchar(max) NULL
END
GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'PassportNumber')
BEGIN
	ALTER TABLE AML_Info
	ADD PassportNumber varchar(25) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'RelationshipType')
BEGIN
	ALTER TABLE AML_Info
	ADD RelationshipType varchar(50)  NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'SharePercentage')
BEGIN
	ALTER TABLE AML_Info
	ADD SharePercentage decimal(13,8) NULL
END
GO



IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'AMLUserID')
BEGIN
	ALTER TABLE AML_Info
	ADD AMLUserID nvarchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'AMLUsername')
BEGIN
	ALTER TABLE AML_Info
	ADD AMLUsername nvarchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'DescriptionORReason')
BEGIN
	ALTER TABLE AML_Info
	ADD DescriptionORReason nvarchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'AMLResponsDate')
BEGIN
	ALTER TABLE AML_Info
	ADD AMLResponsDate datetime NULL
END
GO

PRINT 'End... Script for CR# GFSY00908 Table Script'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	{14/08/2022}	
--Reason	:	Enh GFSY00917 - ACM000000020167 - RIM Override Audit
--====================================================================
PRINT 'Start. Script for CR# GFSY00917 Table  Script'
GO


--------------------------------
-- Alter Table RulesTranConfig -
--------------------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'RulesTranConfig' AND COLUMN_NAME = 'ApplyOverrideAudit')
	BEGIN
		ALTER TABLE RulesTranConfig
		ADD ApplyOverrideAudit bit DEFAULT 0 WITH VALUES
	END
GO
--====================================================================
--====================================================================
--------------------------------
-- create Table RimAuditTrails -
--------------------------------
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'RimAuditTrails')
	BEGIN
		CREATE TABLE RimAuditTrails
		(
			ID						int IDENTITY(1,1)	NOT NULL,
			ReferenceNumber		    uniqueidentifier	NOT NULL,
			TID					    nvarchar(100)		 NULL,
			UserNumber				internal_user_ID	 NULL,
			Bank					BankID				 NULL,
			Region					RegionID			 NULL,
			Branch					BranchID			 NULL,
			JNLSequance				int					 NULL,
			BusinessDate			SmallDate			 NULL,
			TransactionName			TransactionName		 NULL,
			ChangedControlsData		XML                  NULL,
			MachineName				nvarchar(100)		 NULL
		)
	END
GO

PRINT 'End... Script for CR# GFSY00917 Table Script'
GO 



--Devolper :	Aya Tarek
--Date       :	[7/8/2022]		
--Reason     :	CR#GFSY00918 - ACM000000020364 - Swift ISO20022-XML Format
--=============================================================
PRINT 'Start. Script for CR# GFSY00918 Table  Script'
GO
--------------------------
-- Create Table XMLToIRTableMapping --
--------------------------
USE Globalfs
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Drop_old_proc IRBulkInsertIntoIR     
  go

IF EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
	drop TYPE IRBulkTableType
end
go

IF not EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
CREATE TYPE IRBulkTableType AS TABLE   
(FileRefNo     varchar(20),        
 FilePathName   varchar(255),        
 MsgRefNo    char(13),        
 StatusID    int,        
 ActionId    int,        
 PaymentMethodID  int,        
 DateTimeStamp   smalldatetime,        
 PreparedBy    varchar(60),--OperatorID,        
 MsgValueDate   DATETIME2,        
 ValueDate    DATETIME2,        
 DrAccountNo    varchar(60),        
 DrAccountNo_AcctType varchar(5),      
 DrAccountNo_ApplType varchar(5),      
 DrAccountNo_DepLoan varchar(5),      
 DrAccountName   nvarchar(255),        
 DrCurrency    varchar(4),--CurrencyType,        
 DrAmount    decimal(21,6),        
 DrAddress    nvarchar(255),        
 SenderBank    nvarchar(255),        
 DrExchangeRate   decimal(21,6),        
 DrCommission   decimal(21,6),        
 CrAccountNo    varchar(60),      
 CrAccountNo_AcctType varchar(5),      
 CrAccountNo_ApplType varchar(5),      
 CrAccountNo_DepLoan varchar(5),       
 CrAccountName   nvarchar(255),        
 CrCurrency    varchar(4),--CurrencyType,        
 CrAmount    decimal(21,6),        
 CrAddress    nvarchar(255),        
 OrderingCustomer  varchar(255),        
 CrExchangeRate   decimal(21,6),        
 CrCommission   decimal(21,6),        
 OriginalMsg    varchar(max),        
 Fld_50K    varchar(255),        
 Fld_59     varchar(255),        
 Charge_Det    char(3),    
 Account_With_Ref varchar(100),    --50
 Account_With_Ac varchar(100),    --50
 Account_With_Name nvarchar(100),    --50
 ValueCurrency varchar(5),    
 Order_Cust_Name nvarchar(100),    --50
 Order_Cust_Add1 varchar(150),    --50
 Order_Cust_Add2 varchar(150),   --50 
 Order_Inst varchar(100),    --50
 Order_Inst_Name varchar(100),    --50
 Order_Inst_Add1 varchar(150),    --50
 BeneficiaryAccount varchar(100),   --60 
 FLD_70 varchar(150),    --50
 FLD_71A varchar(150),    --50
 BeneficiaryName nvarchar(140),  --40  
 BeneficiaryAddress varchar(255) ,    
 Updator    varchar(60),--OperatorID  ,    
 DB_DrValueDate DATETIME2,    
 DB_CrValueDate DATETIME2,    
 DB_DrNarrative varchar(150),    --100
 DB_CrNarrative varchar(150),    --100
 DB_FLD_20 varchar(100),    --50
 DB_FLD_23 varchar(100),    --50
 DB_FLD_33 varchar(100),    --50
 DB_FLD_52 varchar(200),  --150),    --100
 DB_FLD_53 varchar(150),    --100
 MsgType varchar(10),    
 ExceptionList varchar(8000),    
 Is_FLD_20_Duplicate bit,    
 DrRealExchangeRate decimal(21,6),        
 CrRealExchangeRate decimal(21,6),    
 TTAmount decimal(21,6),    
 TTCurrency varchar(4),    
 DrSellExchangeRate decimal(21,6),    
 CrBuyExchangeRate decimal(21,6)  ,  
 IBAN varchar(100),  --60
 Ordering_IBAN  varchar(100), --60   
 Sender_BIC nvarchar(150),--,  --100  
 --CrRimNo varchar(100),  
 --Ben_Inst_BIC varchar(100) 
 FLD_111 nvarchar(3),
 FLD_121 nvarchar(36),
 CrRimNo varchar(100),
 IsMX bit,
 FLD_72 varchar(250),
 Ben_Inst_BIC nvarchar(100), 
 Ben_Inst_Name  nvarchar(100),
 Ben_Inst_AddLn1  nvarchar(100),
 Ben_Inst_AddLn2 nvarchar(100),
 Ben_Inst_AddLn3 nvarchar(100)
);  
end
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME  = 'XMLToIRTableMapping')
	BEGIN
		CREATE TABLE dbo.XMLToIRTableMapping
		(
	        [MsgType] [varchar](10) Not NULL ,
	        [FieldName] [varchar](25)  NULL ,
	        [FieldPathInXML] [nvarchar](1000) Not NULL ,
			[FieldColumninIRtable] [nvarchar](100) Not NULL ,
			[IsMandatory][bit] Not NULL Default '0' ,
			[IsAttribute][bit] Not NULL Default '0' ,
			CONSTRAINT  PK_FilePathInIR Primary key (FieldPathInXML,FieldColumninIRtable),
		    CONSTRAINT�CHK_MsgType�CHECK�(MsgType in ('103'�,'202'))
       )
	END
GO   

IF Not EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'IsMX')
BEGIN

	ALTER TABLE IR
	ADD IsMX bit NOT NULL  Default '0' 
END
GO 

IF EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'OriginalMsg')
BEGIN

	ALTER TABLE IR
	Alter column OriginalMsg varchar(max) NULL 
END
GO 
	

PRINT 'End... Script for CR# GFSY00918 Table Script'
GO
 Drop_old_proc IRBulkInsertIntoIR     
  go
  
IF EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
	drop TYPE IRBulkTableType
end
go

IF not EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
CREATE TYPE IRBulkTableType AS TABLE   
(FileRefNo     varchar(20),        
 FilePathName   varchar(255),        
 MsgRefNo    char(13),        
 StatusID    int,        
 ActionId    int,        
 PaymentMethodID  int,        
 DateTimeStamp   smalldatetime,        
 PreparedBy    varchar(60),--OperatorID,        
 MsgValueDate   DATETIME2,        
 ValueDate    DATETIME2,        
 DrAccountNo    varchar(60),        
 DrAccountNo_AcctType varchar(5),      
 DrAccountNo_ApplType varchar(5),      
 DrAccountNo_DepLoan varchar(5),      
 DrAccountName   nvarchar(255),        
 DrCurrency    varchar(4),--CurrencyType,        
 DrAmount    decimal(21,6),        
 DrAddress    nvarchar(255),        
 SenderBank    nvarchar(255),        
 DrExchangeRate   decimal(21,6),        
 DrCommission   decimal(21,6),        
 CrAccountNo    varchar(60),      
 CrAccountNo_AcctType varchar(5),      
 CrAccountNo_ApplType varchar(5),      
 CrAccountNo_DepLoan varchar(5),       
 CrAccountName   nvarchar(255),        
 CrCurrency    varchar(4),--CurrencyType,        
 CrAmount    decimal(21,6),        
 CrAddress    nvarchar(255),        
 OrderingCustomer  varchar(255),        
 CrExchangeRate   decimal(21,6),        
 CrCommission   decimal(21,6),        
 OriginalMsg    varchar(max),       
 Fld_50K    varchar(255),        
 Fld_59     varchar(255),        
 Charge_Det    char(3),    
 Account_With_Ref varchar(100),    --50
 Account_With_Ac varchar(100),    --50
 Account_With_Name nvarchar(100),    --50
 ValueCurrency varchar(5),    
 Order_Cust_Name nvarchar(100),    --50
 Order_Cust_Add1 varchar(150),    --50
 Order_Cust_Add2 varchar(150),   --50 
 Order_Inst varchar(100),    --50
 Order_Inst_Name varchar(100),    --50
 Order_Inst_Add1 varchar(150),    --50
 BeneficiaryAccount varchar(100),   --60 
 FLD_70 varchar(150),    --50
 FLD_71A varchar(150),    --50
 BeneficiaryName nvarchar(140),  --40  
 BeneficiaryAddress varchar(255) ,    
 Updator    varchar(60),--OperatorID  ,    
 DB_DrValueDate DATETIME2,    
 DB_CrValueDate DATETIME2,    
 DB_DrNarrative varchar(150),    --100
 DB_CrNarrative varchar(150),    --100
 DB_FLD_20 varchar(100),    --50
 DB_FLD_23 varchar(100),    --50
 DB_FLD_33 varchar(100),    --50
 DB_FLD_52 varchar(200),  --150),    --100
 DB_FLD_53 varchar(150),    --100
 MsgType varchar(10),    
 ExceptionList varchar(8000),    
 Is_FLD_20_Duplicate bit,    
 DrRealExchangeRate decimal(21,6),        
 CrRealExchangeRate decimal(21,6),    
 TTAmount decimal(21,6),    
 TTCurrency varchar(4),    
 DrSellExchangeRate decimal(21,6),    
 CrBuyExchangeRate decimal(21,6)  ,  
 IBAN varchar(100),  --60
 Ordering_IBAN  varchar(100), --60   
 Sender_BIC nvarchar(150),--,  --100  
 --CrRimNo varchar(100),  
 --Ben_Inst_BIC varchar(100) 
 FLD_111 nvarchar(3),
 FLD_121 nvarchar(36),
 CrRimNo varchar(100),
 IsMX bit,
 FLD_72 varchar(250),
 Ben_Inst_BIC nvarchar(100), 
 Ben_Inst_Name  nvarchar(100),
 Ben_Inst_AddLn1  nvarchar(100),
 Ben_Inst_AddLn2 nvarchar(100),
 Ben_Inst_AddLn3 nvarchar(100)
);  
end
GO
--Devolper	 :	Shaimaa Nasser
--Date       :	[09/08/2022]		
--Reason     :  ACM000000019738 - MT202 and MT199
------------------------------------------------------------------------------------------------
PRINT 'Start. Script for CR# GFSY00919 Table Script'
GO

----------------------
-- Table Field79Templates
----------------------
USE Globalfs
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME  = 'Field79Templates')
	BEGIN
		CREATE TABLE dbo.Field79Templates
		(
			[Template_ID][int] Not NULL Primary key IDENTITY(1, 1) ,
	        [Template_Description] [varchar](35) Not NULL,
	        [Field79_Free_Text] [nvarchar](max)  Not NUll    
			 )
	END 
GO 
 PRINT 'END. Script for CR# GFSY00919 Table Script'