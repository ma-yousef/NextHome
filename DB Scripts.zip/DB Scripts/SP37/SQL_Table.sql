--Programmer : Mostafa Sayed
--Date       : [09/03/2020]
--Reason     : CR#GFSY00794 - BIsB_ACM17780_Credit Card Multiple Payment .....
-------------------------------------------------------------------
IF EXISTS(SELECT * FROM sysobjects WHERE name = 'CHK__ExternalWebService_ServiceType')
BEGIN
	ALTER TABLE ExternalWebService
	DROP CONSTRAINT [CHK__ExternalWebService_ServiceType]
	ALTER TABLE [dbo].[ExternalWebService]  WITH CHECK 
	ADD  CONSTRAINT [CHK__ExternalWebService_ServiceType] CHECK  (([ServiceType]='WCF' OR [ServiceType]='XML' OR [ServiceType]='REST'))
	ALTER TABLE [dbo].[ExternalWebService] CHECK CONSTRAINT [CHK__ExternalWebService_ServiceType]
END
GO
USE [Globalfs]
GO
Print 'ITS Code Start [Sara Badwy - 2020/01/20]'
GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'Operator' AND COLUMN_NAME = 'UseMenuCaching')                   
BEGIN
ALTER TABLE Operator
Add UseMenuCaching bit not null
Default (0) 
End
Print 'ITS Code End [Sara Badwy - 2020/01/20]'
go
USE [Globalfs]
GO
/*
 CreationDate : 01-20-2020     
 Programmer   :Sara Badwy
 Description  :Defect : GFSX13894 Retrofit                        
*/ 
IF  NOT EXISTS (SELECT * FROM sys.tables st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'MenuCaching' AND ss.name = N'dbo')
	CREATE table [dbo].[MenuCaching](
	[UserNumber] [dbo].[internal_user_ID] NOT NULL,
	[BrID][VARCHAR](10)NULL,
	[MenuName] [nvarchar](50) NOT NULL,
	[XMLContent] XML
	)	
	GO
Print 'ITS Code Start [Sara Badwy - 2020/2/25] Defect GFSX13894 '
GO
drop_old_trigger 'TR_auto_CacheGenration_update'
GO
USE [Globalfs]
GO
/****** Object:  Trigger [dbo].[TR_auto_CacheGenration_update]    Script Date: 02/25/2020 10:39:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[TR_auto_CacheGenration_update]
ON [dbo].[ScopedOperatorRoles]
AFTER INSERT , UPDATE ,DELETE NOT FOR REPLICATION  
AS
Begin
if @@ROWCOUNT = 0 return -- If no rows affected, exit immediately.
-- Note: if the WHERE clause is satisfied,
      -- Then @@rowcount will be > 0 even if no column value really changed.
set nocount on
declare @UseMenuCache bit ,@user_number int
 IF  EXISTS(SELECT 1 FROM INSERTED)
 select  @user_number= user_number from inserted
 else 
select  @user_number= user_number from deleted
select  @UseMenuCache= usemenucaching from operator where user_number=@user_number
if(@UseMenuCache=1)
 BEGIN 
 EXEC Insert_Menu_Caching @user_number
 END
end
GO
IF  EXISTS(SELECT * FROM sys.objects  WHERE name = 'TR_auto_CacheGenration_update' AND type = 'TR' )                   
BEGIN
ALTER TABLE ScopedOperatorRoles DISABLE TRIGGER TR_auto_CacheGenration_update
End 
Print 'ITS Code End [Sara Badwy - 2020/2/25] Defect GFSX13894 '


GO
/*
	CreationDate : [11/05/2020]
	Programmer   : [Sara Badwy]
	Description  : Issue [GFSX14031] Error File IR
*/
USE [Globalfs]
go
IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'IR' AND COLUMN_NAME = 'OriginalMsg' AND CHARACTER_MAXIMUM_LENGTH=5000 )                   
BEGIN
ALTER TABLE IR 
ALTER COLUMN [OriginalMsg] [varchar](5000) NULL
END
GO
-----------------------------------
-- Drop proc IRBulkInsertIntoIR ---
-----------------------------------
Drop_old_proc IRBulkInsertIntoIR     
  go
  
IF EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
	drop TYPE IRBulkTableType
end
go

IF not EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
CREATE TYPE IRBulkTableType AS TABLE   
(FileRefNo     varchar(20),        
 FilePathName   varchar(255),        
 MsgRefNo    char(13),        
 StatusID    int,        
 ActionId    int,        
 PaymentMethodID  int,        
 DateTimeStamp   smalldatetime,        
 PreparedBy    varchar(60),--OperatorID,        
 MsgValueDate   DATETIME2,        
 ValueDate    DATETIME2,        
 DrAccountNo    varchar(60),        
 DrAccountNo_AcctType varchar(5),      
 DrAccountNo_ApplType varchar(5),      
 DrAccountNo_DepLoan varchar(5),      
 DrAccountName   nvarchar(255),        
 DrCurrency    varchar(4),--CurrencyType,        
 DrAmount    decimal(21,6),        
 DrAddress    nvarchar(255),        
 SenderBank    nvarchar(255),        
 DrExchangeRate   decimal(21,6),        
 DrCommission   decimal(21,6),        
 CrAccountNo    varchar(60),      
 CrAccountNo_AcctType varchar(5),      
 CrAccountNo_ApplType varchar(5),      
 CrAccountNo_DepLoan varchar(5),       
 CrAccountName   nvarchar(255),        
 CrCurrency    varchar(4),--CurrencyType,        
 CrAmount    decimal(21,6),        
 CrAddress    nvarchar(255),        
 OrderingCustomer  varchar(255),        
 CrExchangeRate   decimal(21,6),        
 CrCommission   decimal(21,6),        
 OriginalMsg    varchar(5000),        
 Fld_50K    varchar(255),        
 Fld_59     varchar(255),        
 Charge_Det    char(3),    
 Account_With_Ref varchar(100),    --50
 Account_With_Ac varchar(100),    --50
 Account_With_Name nvarchar(100),    --50
 ValueCurrency varchar(5),    
 Order_Cust_Name nvarchar(100),    --50
 Order_Cust_Add1 varchar(150),    --50
 Order_Cust_Add2 varchar(150),   --50 
 Order_Inst varchar(100),    --50
 Order_Inst_Name varchar(100),    --50
 Order_Inst_Add1 varchar(150),    --50
 BeneficiaryAccount varchar(100),   --60 
 FLD_70 varchar(150),    --50
 FLD_71A varchar(150),    --50
 BeneficiaryName nvarchar(140),  --40  
 BeneficiaryAddress varchar(255) ,    
 Updator    varchar(60),--OperatorID  ,    
 DB_DrValueDate DATETIME2,    
 DB_CrValueDate DATETIME2,    
 DB_DrNarrative varchar(150),    --100
 DB_CrNarrative varchar(150),    --100
 DB_FLD_20 varchar(100),    --50
 DB_FLD_23 varchar(100),    --50
 DB_FLD_33 varchar(100),    --50
 DB_FLD_52 varchar(200),  --150),    --100
 DB_FLD_53 varchar(150),    --100
 MsgType varchar(10),    
 ExceptionList varchar(8000),    
 Is_FLD_20_Duplicate bit,    
 DrRealExchangeRate decimal(21,6),        
 CrRealExchangeRate decimal(21,6),    
 TTAmount decimal(21,6),    
 TTCurrency varchar(4),    
 DrSellExchangeRate decimal(21,6),    
 CrBuyExchangeRate decimal(21,6)  ,  
 IBAN varchar(100),  --60
 Ordering_IBAN  varchar(100), --60   
 Sender_BIC nvarchar(150),--,  --100  
 --CrRimNo varchar(100),  
 --Ben_Inst_BIC varchar(100)  
 FLD_111 nvarchar(3),
 FLD_121 nvarchar(36) 

);  
end
go
-----------------------------------
-- Create proc IRBulkInsertIntoIR -
-----------------------------------      

CREATE PROCEDURE dbo.IRBulkInsertIntoIR 
    @Table IRBulkTableType READONLY    
    AS    
/*      
CreationDate: 2017-5-31     
OriginalName: dbo.IRBulkInsertIntoIR      
Programmer  : Karim Mahmoud
Description : Bulk Insert rows in IR Table

Reason: GFSY00717 - Add 2 column FLD_111,FLD_121
Developer: Nada Elshafie
Modification date: 14Aug2018
*/   
BEGIN TRY  
    BEGIN TRANSACTION   
       INSERT INTO IR
        (        
			 FileRefNo,        
			 FilePathName,       
			 MsgRefNo,        
			 StatusID,        
			 ActionId,        
			 PaymentMethodID,        
			 DateTimeStamp,        
			 PreparedBy,        
			 MsgValueDate,        
			 ValueDate,        
			 DrAccountNo,        
			 DrAccountNo_AcctType,      
			 DrAccountNo_ApplType,      
			 DrAccountNo_DepLoan,      
			 DrAccountName,        
			 DrCurrency,        
			 DrAmount,        
			 DrAddress,        
			 SenderBank,        
			 DrExchangeRate,        
			 DrCommission,        
			 CrAccountNo,        
			 CrAccountNo_AcctType,     
			 CrAccountNo_ApplType,      
			 CrAccountNo_DepLoan,      
			 CrAccountName,        
			 CrCurrency,        
			 CrAmount,        
			 CrAddress,        
			 OrderingCustomer,        
			 CrExchangeRate,        
			 CrCommission,        
			 OriginalMsg,        
			 Fld_50K,        
			 Fld_59,        
			 Charge_Det,       
			 Account_With_Ref,    
			 Account_With_Ac,    
			 Account_With_Name,    
			 ValueCurrency,    
			 Order_Cust_Name,    
			 Order_Cust_Add1,    
			 Order_Cust_Add2,    
			 Order_Inst,    
			 Order_Inst_Name,    
			 Order_Inst_Add1,    
			 BeneficiaryAccount,    
			 FLD_70,    
			 FLD_71A,    
			 BeneficiaryName,    
			 BeneficiaryAddress,    
			 Updator,    
			 DrValueDate,    
			 CrValueDate,    
			 DrNarrative,    
			 CrNarrative,    
			 FLD_20,    
			 FLD_23,    
			 FLD_33,    
			 FLD_52,    
			 FLD_53,    
			 MsgType,    
			 ExceptionList,    
			 Is_FLD_20_Duplicate,    
			 DrRealExchangeRate,    
			 CrRealExchangeRate,     
			 TTAmount ,    
			 TTCurrency ,    
			 DrSellExchangeRate,    
			 CrBuyExchangeRate ,  
			 IBAN   ,    
			 Ordering_IBAN,    
			 Sender_BIC,    
			 CrRimNo,  
			 Ben_Inst_BIC,
			 FLD_111,
			 FLD_121 
		)       
		SELECT 
		
			 irbt.FileRefNo,        
			 irbt.FilePathName,        
			 irbt.MsgRefNo,        
			 irbt.StatusID,        
			 irbt.ActionId,        
			 irbt.PaymentMethodID,        
			 irbt.DateTimeStamp,        
			 irbt.PreparedBy,        
			 irbt.MsgValueDate,        
			 irbt.ValueDate,        
			 irbt.DrAccountNo,        
			 irbt.DrAccountNo_AcctType,      
			 irbt.DrAccountNo_ApplType,      
			 irbt.DrAccountNo_DepLoan,      
			 irbt.DrAccountName,        
			 irbt.DrCurrency,       
			 irbt.DrAmount,        
			 irbt.DrAddress,        
			 irbt.SenderBank,        
			 irbt.DrExchangeRate,        
			 irbt.DrCommission,        
			 irbt.CrAccountNo,      
			 irbt.CrAccountNo_AcctType,      
			 irbt.CrAccountNo_ApplType,      
			 irbt.CrAccountNo_DepLoan,       
			 irbt.CrAccountName,        
			 irbt.CrCurrency,     
			 irbt.CrAmount,        
			 irbt.CrAddress,        
			 irbt.OrderingCustomer,        
			 irbt.CrExchangeRate,        
			 irbt.CrCommission,        
			 irbt.OriginalMsg,        
			 irbt.Fld_50K,        
			 irbt.Fld_59,        
			 irbt.Charge_Det,    
			 irbt.Account_With_Ref,    
			 irbt.Account_With_Ac,    
			 irbt.Account_With_Name,    
			 irbt.ValueCurrency,    
			 irbt.Order_Cust_Name,    
			 irbt.Order_Cust_Add1,    
			 irbt.Order_Cust_Add2,    
			 irbt.Order_Inst,    
			 irbt.Order_Inst_Name,    
			 irbt.Order_Inst_Add1,    
			 irbt.BeneficiaryAccount,    
			 irbt.FLD_70,     
			 irbt.FLD_71A,    
			 irbt.BeneficiaryName,    
			 irbt.BeneficiaryAddress,    
			 irbt.Updator,  
			 irbt.DB_DrValueDate,   
			 irbt.DB_CrValueDate,    
			 irbt.DB_DrNarrative,    
			 irbt.DB_CrNarrative,    
			 irbt.DB_FLD_20,    
			 irbt.DB_FLD_23,    
			 irbt.DB_FLD_33,    
			 irbt.DB_FLD_52,    
			 irbt.DB_FLD_53,    
			 irbt.MsgType,    
			 irbt.ExceptionList,    
			 irbt.Is_FLD_20_Duplicate,    
			 irbt.DrRealExchangeRate,        
			 irbt.CrRealExchangeRate,    
			 irbt.TTAmount,    
			 irbt.TTCurrency,    
			 irbt.DrSellExchangeRate,    
			 irbt.CrBuyExchangeRate,  
			 irbt.IBAN,  
			 irbt.Ordering_IBAN,    
			 irbt.Sender_BIC,   
			 '',--CrRimNo varchar(100),  
			 '',--Ben_Inst_BIC varchar(100)
			 irbt.FLD_111,
			 irbt.FLD_121  
		
		FROM @Table irbt
    COMMIT  
END TRY  
BEGIN CATCH  
  
    IF @@TRANCOUNT > 0  
        ROLLBACK  
    return -1;
END CATCH  
Go
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 Table Script'
GO

-----------------------------------------
-- Create Table AML_NationalityMapping --
-----------------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'AML_NationalityMapping')
	BEGIN
		CREATE TABLE dbo.AML_NationalityMapping
			(
			    NationalityID				int				NOT NULL,
			    NationalityDescription      nvarchar(max)	NOT NULL,
			    CountryCode_Personal		nvarchar(max)	NOT NULL
			)
	END
GO

------------------------------------------
-- Create Table AML_CustomerTypeMapping --
------------------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'AML_CustomerTypeMapping')
	BEGIN
		CREATE TABLE dbo.AML_CustomerTypeMapping
			(
			    RimClass		int NOT NULL,
			    CustomerType	nvarchar(100) NOT NULL,
			)
	END
GO

--------------------------
-- Alter Table AML_Info --
--------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'TransactionType')
BEGIN
	ALTER TABLE AML_Info
	ADD TransactionType TransactionName NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'ResidencyStatus')
BEGIN
	ALTER TABLE AML_Info
	ADD ResidencyStatus varchar(20) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'RimClass')
BEGIN
	ALTER TABLE AML_Info
	ADD RimClass int NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'RimNumber')
BEGIN
	ALTER TABLE AML_Info
	ADD RimNumber varchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'AccountNumber')
BEGIN
	ALTER TABLE AML_Info
	ADD AccountNumber varchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'AccountType')
BEGIN
	ALTER TABLE AML_Info
	ADD AccountType varchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'Occupation')
BEGIN
	ALTER TABLE AML_Info
	ADD Occupation int NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'IsPEP')
BEGIN
	ALTER TABLE AML_Info
	ADD IsPEP bit NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'NationalityCode')
BEGIN
	ALTER TABLE AML_Info
	ADD NationalityCode varchar(100) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'EconomicSector')
BEGIN
	ALTER TABLE AML_Info
	ADD EconomicSector varchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'BusinessDomain')
BEGIN
	ALTER TABLE AML_Info
	ADD BusinessDomain char(1) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'ProductAndSerivce')
BEGIN
	ALTER TABLE AML_Info
	ADD ProductAndSerivce char(4) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'RequestID')
BEGIN
	ALTER TABLE AML_Info
	ADD RequestID varchar(max) NULL
END
GO

PRINT 'End... Script for CR# GFSY00793 Table Script'
GO
--==================================================================================================================================================================
go
--Programmer :	Ahmed Osman
--Date       :	[14/06/2020]		
--Reason     :	Issue#GFSX14058 
--=============================
PRINT 'Start. Script for Issue# GFSX14058 Table Script'
GO

drop_old_proc 'TLR_DeleteBalanceAudit_SpecifyTrans'
GO

-----------------------
-- Add sys.types ------
-----------------------
IF EXISTS(SELECT * FROM sys.types WHERE name = 'ChargesAccountsTable')
BEGIN
	DROP TYPE ChargesAccountsTable
END
GO

IF NOT EXISTS(SELECT * FROM sys.types WHERE name = 'ChargesAccountsTable')
BEGIN
 CREATE TYPE ChargesAccountsTable AS TABLE 
(
    AccountNo nvarchar(max)
)
END
GO

PRINT 'End... Script for CR# GFSX14058 Table Script'
GO
