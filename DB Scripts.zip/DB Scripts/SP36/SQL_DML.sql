USE [Globalfs]
GO
       
If Not Exists(Select * From ServicePacks Where BasePackageName = 'ETHIX-Branch_2.00.46' And SP_Number = 36)
Begin
Insert Into ServicePacks(BasePackageName,SP_Number,SP_Name, LastPackageName, BriefDescription, DetailedDescription,IncludeWholeFilesOnly,DontRemoveTmpFldrWhenFinished,OptionalSourceList,Comments,PatchNumber)
Values('ETHIX-Branch_2.00.46', 36,'SP36_ETHIX-Branch_2.0.46.0','SP35_ETHIX-Branch_2.0.46.0','SP36_ETHIX-Branch_2.0.46.0','', 1, 0, '', '',0)
End
GO
--RulesDescriptor
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE AppID=1 and DescriptorID=1104774 )
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor , Creator , Updator )  
	SELECT 1 , 1104774 , 'TLR_PRT_Screen_SD' , 0 , 'Labels' , 'Disable Print Screen' , 'ITSOFT\mostafa.sayed' , 'ITSOFT\mai.gamal'
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE AppID=1 and DescriptorID=1104775 )
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor , Creator , Updator )  
	SELECT 1 , 1104775 , 'TLR_PRT_Screen_LD' , 0 , 'Labels' , 'this is Paramter used By the Bank to Enable and Disable the Print Screen Function' , 'ITSOFT\mostafa.sayed' , 'ITSOFT\mai.gamal'
END
GO
--BankConfig
IF NOT EXISTS(Select * from BankConfig where Name = 'PRT_Screen')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'PRT_Screen',@Value = '0',@DataType = 'bit',@ShortDescr = 'TLR_PRT_Screen_SD',@LongDescr = 'TLR_PRT_Screen_LD',@MaxVal = '1',@MinVal='0'
END
GO
--************** Begin Mostafa Helmy Defect #GFSX13770*****************
IF EXISTS (SELECT * FROM sys.objects WHERE [name] = N'TR_RulesDescriptor_NO_DELETE' AND [type] = 'TR')
BEGIN
      ALTER TABLE RulesDescriptor DISABLE TRIGGER TR_RulesDescriptor_NO_DELETE  
END;

DELETE FROM RulesDescriptorLocal where DescriptorID IN (SELECT DescriptorID FROM RulesDescriptor WHERE Name='TLR_SpecialNeeds' AND DescriptorID=1200268)
DELETE FROM RulesDescriptorLocal where DescriptorID IN (SELECT DescriptorID FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsInfo' AND DescriptorID=1200269)
DELETE FROM RulesDescriptorLocal where DescriptorID IN (SELECT DescriptorID FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsType' AND DescriptorID=1200270)
DELETE FROM RulesDescriptorLocal where DescriptorID IN (SELECT DescriptorID FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsSeverity' AND DescriptorID=1200271)
DELETE FROM RulesDescriptorLocal where DescriptorID IN (SELECT DescriptorID FROM RulesDescriptor WHERE Name='TLR_PL_1200004_0' AND DescriptorID=1200272)
DELETE FROM RulesDescriptorLocal where DescriptorID IN (SELECT DescriptorID FROM RulesDescriptor WHERE Name='TLR_PL_1200004_1' AND DescriptorID=1200273)
DELETE FROM RulesDescriptorLocal where DescriptorID IN (SELECT DescriptorID FROM RulesDescriptor WHERE Name='SpecialneedsINFO' AND DescriptorID=1200274)



DELETE FROM RulesContainerDescriptors WHERE Descriptor_Name IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_SpecialNeeds' AND DescriptorID=1200268)
DELETE FROM RulesContainerDescriptors WHERE Descriptor_Name IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsInfo' AND DescriptorID=1200269)
DELETE FROM RulesContainerDescriptors WHERE Descriptor_Name IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsType' AND DescriptorID=1200270)
DELETE FROM RulesContainerDescriptors WHERE Descriptor_Name IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsSeverity' AND DescriptorID=1200271)


DELETE FROM RulesTranDescriptors WHERE DSC_Name IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_SpecialNeeds' AND DescriptorID=1200268)
DELETE FROM RulesTranDescriptors WHERE DSC_Name IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsInfo' AND DescriptorID=1200269)
DELETE FROM RulesTranDescriptors WHERE DSC_Name IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsType' AND DescriptorID=1200270)
DELETE FROM RulesTranDescriptors WHERE DSC_Name IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsSeverity' AND DescriptorID=1200271)


DELETE FROM PickList_Entries WHERE DescriptorName IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_PL_1200004_0' AND DescriptorID=1200272)
DELETE FROM PickList_Entries WHERE DescriptorName IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_PL_1200004_1' AND DescriptorID=1200273)


DELETE FROM RulesDescriptor WHERE Name='TLR_SpecialNeeds' AND DescriptorID=1200268
DELETE FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsInfo' AND DescriptorID=1200269
DELETE FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsType' AND DescriptorID=1200270
DELETE FROM RulesDescriptor WHERE Name='TLR_SpecialNeedsSeverity' AND DescriptorID=1200271
DELETE FROM RulesDescriptor WHERE Name='TLR_PL_1200004_0' AND DescriptorID=1200272
DELETE FROM RulesDescriptor WHERE Name='TLR_PL_1200004_1' AND DescriptorID=1200273
DELETE FROM RulesDescriptor WHERE Name='SpecialneedsINFO' AND DescriptorID=1200274



IF EXISTS (SELECT * FROM sys.objects WHERE [name] = N'TR_RulesDescriptor_NO_DELETE' AND [type] = 'TR')
BEGIN
      ALTER TABLE RulesDescriptor ENABLE  TRIGGER TR_RulesDescriptor_NO_DELETE  
END;







/*********************RulesDescriptor**************/



If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105441)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105441,'TLR_SpecialNeeds',0,'Labels','Special Needs','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105442)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105442,'TLR_SpecialNeedsInfo',0,'Labels','Special Needs Info','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105443)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105443,'TLR_SpecialNeedsType',0,'Labels','Special Needs Type','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105444)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105444,'TLR_SpecialNeedsSeverity',0,'Labels','Special Needs Severity','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105445)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105445,'TLR_PL_1200004_0',0,'PickLists','Yes','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105446)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105446,'TLR_PL_1200004_1',0,'PickLists','No','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105447)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105447,'SpecialneedsINFO',0,'Labels','Customer has Special needs {0} with Severity {1}','ITSOFT\abdelrhman.kamal','Dec 30 2018 10:23AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Dec 30 2018 10:22AM',N'ITSOFT\abdelrhman.kamal')
End
go

/*******************************RulesContainerDescriptors**************************/
If Not Exists(Select * From RulesContainerDescriptors Where container_name = 'Teller' And Descriptor_Name = 'TLR_SpecialNeeds')
Begin
 Insert Into RulesContainerDescriptors(container_name,Descriptor_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('Teller','TLR_SpecialNeeds','May 13 2019 10:46AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','May 13 2019 10:46AM')
End
go

If Not Exists(Select * From RulesContainerDescriptors Where container_name = 'Teller' And Descriptor_Name = 'TLR_SpecialNeedsInfo')
Begin
 Insert Into RulesContainerDescriptors(container_name,Descriptor_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('Teller','TLR_SpecialNeedsInfo','May 13 2019 10:46AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','May 13 2019 10:46AM')
End
go

If Not Exists(Select * From RulesContainerDescriptors Where container_name = 'Teller' And Descriptor_Name = 'TLR_SpecialNeedsType')
Begin
 Insert Into RulesContainerDescriptors(container_name,Descriptor_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('Teller','TLR_SpecialNeedsType','May 13 2019 10:46AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','May 13 2019 10:46AM')
End
go

If Not Exists(Select * From RulesContainerDescriptors Where container_name = 'Teller' And Descriptor_Name = 'TLR_SpecialNeedsSeverity')
Begin
 Insert Into RulesContainerDescriptors(container_name,Descriptor_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('Teller','TLR_SpecialNeedsSeverity','May 13 2019 10:46AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','May 13 2019 10:46AM')
End
go


/******************************RulesDescriptorLocal*******************************/

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105441 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105441,1025,N'���������� ������','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105442 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105442,1025,N'������� ���������� ������','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105443 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105443,1025,N'��� ���������� ������','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105444 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105444,1025,N'����� ���������� ������','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105445 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105445,1025,N'���','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105446 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105446,1025,N'��','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go
/**************************RulesTranDescriptors***********************/

If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SpecialNeeds')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SpecialNeeds','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_SpecialNeeds')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_SpecialNeeds','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SpecialNeedsInfo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SpecialNeedsInfo','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_SpecialNeedsInfo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_SpecialNeedsInfo','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SpecialNeedsType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SpecialNeedsType','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_SpecialNeedsType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_SpecialNeedsType','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SpecialNeedsSeverity')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SpecialNeedsSeverity','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_SpecialNeedsSeverity')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_SpecialNeedsSeverity','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
/**************************PickList_Entries****************/

If Not Exists(Select * From PickList_Entries Where PickListID = 1200004 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (1200004,1,1,'TLR_PL_1200004_0','Y','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018  2:41PM','Nov 27 2018  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go


If Not Exists(Select * From PickList_Entries Where PickListID = 1200004 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (1200004,1,2,'TLR_PL_1200004_1','N','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018  2:41PM','Nov 27 2018  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

--************** End Mostafa Helmy Defect #GFSX13770*****************
--************** Begin Mostafa Helmy Defect #GFSX13870*****************


IF EXISTS (SELECT * FROM sys.objects WHERE [name] = N'TR_RulesDescriptor_NO_DELETE' AND [type] = 'TR')
BEGIN
      ALTER TABLE RulesDescriptor DISABLE TRIGGER TR_RulesDescriptor_NO_DELETE  
END;

delete FROM RulesDescriptorLocal where DescriptorID IN (SELECT DescriptorID FROM RulesDescriptor WHERE Name='TLR_RSMGroups' AND DescriptorID=1200276)

DELETE FROM PickList_Entries WHERE DescriptorName IN (SELECT Name FROM RulesDescriptor WHERE Name='TLR_RSMGroups' AND DescriptorID=1200276)
delete FROM RulesDescriptor WHERE Name='TLR_RSMGroups' AND DescriptorID=1200276

IF EXISTS (SELECT * FROM sys.objects WHERE [name] = N'TR_RulesDescriptor_NO_DELETE' AND [type] = 'TR')
BEGIN
      ALTER TABLE RulesDescriptor ENABLE  TRIGGER TR_RulesDescriptor_NO_DELETE  
END;


-------------------------------------------------------------------
----------------------------RulesDescriptor------------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105488)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105488,'TLR_RSMGroups',0,'PickLists','RSMGroups','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go


-------------------------------------------------------------------
----------------------------RulesDescriptorLocal-------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105488 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105488,1025,N'������� ��� ����� ���� ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go


-------------------------------------------------------------------
----------------------------PickList_Entries-----------------------
-------------------------------------------------------------------

If Not Exists(Select * From PickList_Entries Where PickListID = 283 And DisplayOrder = 6)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (283,1,6,'TLR_RSMGroups','RSMGroups','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019  2:41PM','Nov 27 2018  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

--************** End Mostafa Helmy Defect #GFSX13870*****************
--Programmer : Mostafa Sayed
--Date       : [7/10/2019]
--Reason     : CR#GFSY00769 - BLOM_ACM18385_Out Clearing Settlement Bulk .....
------------------------------------------------------------------------------
--RulesTranDescriptors
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=365 AND DSC_Name='NumberOfCheques')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(365,N'NumberOfCheques')
END
GO

--RulesTranField
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 365 AND FieldID = 208)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (365,208,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'NumberOfCheques',0,-1)
END
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=365 AND DSC_Name='TLR_Total_Amount')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(365,N'TLR_Total_Amount')
END
GO
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 365 AND FieldID = 1156)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (365,1156,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'TotalAmount',0,-1)
END
GO

--SQLstrings
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID=1100023)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,AccessString,CommandType,GetsRows,DataSource,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	Values(1,1100023,N'GET_PROCESSED_CLEARDETAILS',N'dbo.Get_Processed_ClearDetails',N'P',1,N'Globalfs',0,N'',N'',N'Get processed checques from clear details for specific IDs',1,N'',N'',0,0,1,NULL,NULL,0,0,0,0)
END
GO

--RulesTranFldParam
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName='InBulckMode')
BEGIN
	INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
	VALUES (@paramID1,'InBulckMode','This param determine if transaction will behave in bulck mode or not',NULL,0,1,0,'','Static    ','')
	
	INSERT INTO RulesParamValue(ParamID,ParamValue)
	VALUES(@paramID1,'True')
	INSERT INTO RulesParamValue(ParamID,ParamValue)
	VALUES(@paramID1,'False')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'OutwardClChequeSettlement' And FieldName = 'InBulckMode' And Param = 'InBulckMode')
BEGIN
	INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value)
	VALUES ('OutwardClChequeSettlement','InBulckMode','InBulckMode','false')
END
GO

--Reports
If Not Exists(Select * From Reports Where ReportName = 'OutwardClChequeSettlement.rpt')
Begin
	Insert Into Reports(ReportName)
	Values (N'OutwardClChequeSettlement.rpt')
End
go

If Not Exists(Select * From PrintDocs Where FormName = 'OutwardClChequeSettlement.rpt')
Begin
 Insert Into PrintDocs(FormName,FormLocation,MediaOrientation,Descript,Maxlines,Instances,PrintEngine,LogicalPrinterName,ServerName,DocumentWidth,DocumentHeight,PaperSizeEnum,LeftMargin,RightMargin,TopMargin,BottomMargin)
 Values ('OutwardClChequeSettlement.rpt','Shared.Net\Source\bin\Common\Reports\','Portrait',NULL,NULL,NULL,'Crystal','JOURNALPRINTER',NULL,0,0,0,0,0,0,0)
End
go

If Not Exists(Select * From PrintTranDocs Where TranName = 'OutwardClChequeSettlement' And FormSequence = 1)
Begin
	Insert Into PrintTranDocs(TranName,FormSequence,FormName,FormLocation,Copies,UIPrompt,IsDupable,Descript,Instances,PostOrPrePrint,DisplayPrintMessage,PrintDescriptor,CheckCondition,ReEvaluateConditionInReprint)
	Values ('OutwardClChequeSettlement',1,'OutwardClChequeSettlement.rpt','',1,NULL,1,NULL,1,0,NULL,NULL,1,0)
End
go

If Not Exists(Select * From PrintTranDocsConditions Where TranName = 'OutwardClChequeSettlement' And FormSequence = 1 And Seq = 1)
Begin
 Insert Into PrintTranDocsConditions(TranName,FormSequence,OperandsDataType,Operand1,Operator,Operand2,Seq,LogicalOperator)
 Values ('OutwardClChequeSettlement',1,'String         ','DUMY_PrintAfterPosting','=','1',1,NULL)
End
go
--Programmer : Mostafa Sayed
--Date       : [21/11/2019]
--Reason     : Issue#GFSX13859 - add currency filed to search criteria .....
------------------------------------------------------------------------------
----RulesTranDescriptors
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=365 AND DSC_Name='TLR_CURRENCY')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(365,N'TLR_CURRENCY')
END
GO
--RulesTranField
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 365 AND FieldID = 951)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (365,951,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'Currency',0,-1)
END
GO
--RulesTranField_ex
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=365 AND FieldIDInPage='_cbo_currency')
BEGIN
	 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values(365,951,'Teller','_cbo_currency',-1,-1,-1,1,0,'TLR_CURRENCY','','',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=365 AND FieldIDInPage='_lbl_currency')
BEGIN
	 INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	 Values(365,NULL,'Teller','_lbl_currency',-1,-1,-1,1,0,'TLR_CURRENCY','','',0)
END
GO
/*
CR        :GFSY00778 - ADIB_ACM000000016164_Export Reports In PDF
Developer :Mostafa Helmy
Date      :10-12-2019
*/

-------------------------------------------------------------------
-----------------------RulesParam----------------------------------
-------------------------------------------------------------------

	
If Not Exists(Select * From RulesParam Where  ParamName='AllowedCrystalExportFormat')
Begin
	DECLARE @ParamID INT
	SELECT @ParamID = MAX(ParamID) +1 FROM RulesParam
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@ParamID,'AllowedCrystalExportFormat','define the allowed export formats for the crystal report viewer',NULL,0,0,0,'','Static    ','','Feb 11 2014  3:22PM',N'ITSOFT\mostafa.helmy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)


	
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'ReportsDisplay' And FieldName = '' And Param = 'AllowedCrystalExportFormat')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('ReportsDisplay','','AllowedCrystalExportFormat','all',N'ITSOFT\mostafa.helmy','nvarchar','Oct 20 2019  9:22AM',NULL)
	End
End
go


/*
CR        :GFSY00778 - ADIB_ACM000000016164_Export Reports In PDF
Developer :Mostafa Helmy
Date      :10-12-2019
*/

-------------------------------------------------------------------
-----------------------RulesParam----------------------------------
-------------------------------------------------------------------

	
If Not Exists(Select * From RulesParam Where  ParamName='AllowedCrystalExportFormat')
Begin
	DECLARE @ParamID INT
	SELECT @ParamID = MAX(ParamID) +1 FROM RulesParam
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@ParamID,'AllowedCrystalExportFormat','define the allowed export formats for the crystal report viewer',NULL,0,0,0,'','Static    ','','Feb 11 2014  3:22PM',N'ITSOFT\mostafa.helmy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)


	
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'ReportsDisplay' And FieldName = 'DrawerType' And Param = 'AllowedCrystalExportFormat')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('ReportsDisplay','DrawerType','AllowedCrystalExportFormat','all',N'ITSOFT\mostafa.helmy','nvarchar','Oct 20 2019  9:22AM',NULL)
	End
End
/*************Begin GFSX13885************************/
ELSE

BEGIN
	If Exists(Select * From RulesTranFldParam Where TranName = 'ReportsDisplay' And FieldName = '' And Param = 'AllowedCrystalExportFormat')
	BEGIN
	 UPDATE RulesTranFldParam SET FieldName='DrawerType' where TranName = 'ReportsDisplay' And FieldName = '' And Param = 'AllowedCrystalExportFormat'
	END
END
/*************End GFSX13885************************/
go
--Programmer : Mostafa Sayed
--Date       : [25/12/2019]
--Reason     : Retrofit:CR#GFSY00779 - Internal_ACM000000018120_Customer Dashboard
--================================================================================

--RulesDescriptor
IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1105406)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1105406,'TLR_CUST_DASHBOARD',0,'Labels','Customer Dashboard')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105406 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105406,1025,N'���� ��� ������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1105510)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1105510,'TLR_DASHBOARD',0,'Labels','Dashboard')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105510 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105510,1025,N'���� �����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105511)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105511,N'TLR_PROFILE_PICTURE',0,N'Labels',N'Profile Picture')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105511 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105511,1025,N'������ �������')
END
GO

--RulesTranDescriptors
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_CUST_DASHBOARD' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_CUST_DASHBOARD')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_DASHBOARD' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_DASHBOARD')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_PROFILE_PICTURE' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_PROFILE_PICTURE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_CUST_NAME' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_CUST_NAME')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_RIM_NUMBER' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_RIM_NUMBER')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_FULL_NAME' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_FULL_NAME')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_ADDRESS' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_ADDRESS')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_DATE_OF_BIRTH' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_DATE_OF_BIRTH')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_GENDER' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_GENDER')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_CRS_NATIONALITY' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_CRS_NATIONALITY')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_Customer_Information' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_Customer_Information')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='TLR_ID_NUM' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'TLR_ID_NUM')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors where DSC_Name='AGE' AND TranID=638)
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES(638,'AGE')
END
GO
/*
	Developer	: Mostafa Sayed
	Date		: [23/12/2019]
	Reason		: CR#GFSX13895 - Get missing operator info after open day
*/
    
--SQLstrings
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID=1100031)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,AccessString,CommandType,GetsRows,DataSource,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	Values(1,1100031,N'GET_MISSING_OPERATOR_INFO',N'dbo.GetMissingOperatorInfo',N'P',1,N'Globalfs',0,N'',N'',N'Get missing operator info after open day',1,N'',N'',0,0,1,NULL,NULL,0,0,0,0)
END
GO
------------------------------------------------------------------------------------------
-----  Developer     : Mostafa Helmy -----------------------------------------------------
-----  Creation Date : 23-December-2019---------------------------------------------------
-----  Purpose       : BARWA_ACM000000014549_Black List Changes - CR# GFSY00781
------------------------------------------------------------------------------------------
PRINT 'Start Script for CR# GFSY00781'
GO
-------------------------------------------------------------------
----------------------------RulesDescriptor------------------------
-------------------------------------------------------------------

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105494)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105494,'TLR_ByCustomername',0,'Labels','By Customer Name Only','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105495)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105495,'TLR_RimType',0,'Labels','Rim Type','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105496)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105496,'TLR_BLPersonal',0,'Labels','Personal','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105497)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105497,'TLR_BLNPersonal',0,'Labels','Non Personal','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105498)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105498,'TLR_BLFirstName',0,'Labels','First Name','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105499)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105499,'TLR_BLMiddleName',0,'Labels','Middle Name','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105500)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105500,'TLR_BLLastName',0,'Labels','Last Name','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105501)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105501,'TLR_BLOtherFirstName',0,'Labels','Other First Name','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105502)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105502,'TLR_BLOtherMiddleName',0,'Labels','Other Middle Name','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105503)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105503,'TLR_BLOtherLastName',0,'Labels','Other Last Name','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105504)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105504,'TLR_BLOtherFullName',0,'Labels','Other Full Name','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105505)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105505,'TLR_BLAction',0,'Labels','Action','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105506)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105506,'TLR_BLID2Type',0,'Labels','ID2 Type','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105507)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105507,'TLR_BLID2Number',0,'Labels','ID2 Number','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go 

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105508)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105508,'TLR_BLRelatedList',0,'Labels','Related Lists','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105509)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105509,'TLR_BLSuspectedRims',0,'Labels','Suspected RIMs','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105512)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105512,'TLR_BLID1Type',0,'Labels','ID1 Type','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105513)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105513,'TLR_BLID1Number',0,'Labels','ID1 Number','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go 

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105517)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105517,'TLR_BLSuspPercent',0,'Labels','Suspect Percenatge','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105518)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105518,'TLR_BLMemberID',0,'Labels','Member ID','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105519)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105519,'TLR_BLListID',0,'Labels','List ID','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105520)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105520,'TLR_BLAction_W',0,'Labels','Warning Message','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105521)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105521,'TLR_BLAction_O',0,'Labels','Override Approval','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105522)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105522,'TLR_BLAction_N',0,'Labels','Never Process','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105524)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105524,'TLR_BLFullName',0,'Labels','Full Customer Name','ITSOFT\mostafa.helmy','Jan 01 2019 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jan 01 2019 11:06AM',N'ITSOFT\mostafa.helmy')
End
go


-------------------------------------------------------------------
----------------------------RulesDescriptorLocal-------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105524 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105524,1025,N'��� ������ �������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105522 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105522,1025,N'��� ����� ����� �������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105521 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105521,1025,N'�������� ������ �������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105520 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105520,1025,N'����� �����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105519 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105519,1025,N'��� �������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105518 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105518,1025,N'��� �����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105517 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105517,1025,N'���� ����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105513 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105513,1025,N'��� ���� ������1','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105512 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105512,1025,N'��� ���� ������1','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105508 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105508,1025,N'����� ��� ���','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105509 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105509,1025,N'�������� ������� ����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105494 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105494,1025,N'�� ���� ��� ������ ���','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105495 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105495,1025,N'��� ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105496 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105496,1025,N'����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105497 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105497,1025,N'����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105498 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105498,1025,N'����� ����� ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105499 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105499,1025,N'����� ������ ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105500 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105500,1025,N'����� ������ ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105501 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105501,1025,N'����� ����� ����� ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105502 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105502,1025,N'����� ������ ����� ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105503 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105503,1025,N'����� ������ ����� ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105504 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105504,1025,N'����� ����� ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105505 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105505,1025,N'�����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105506 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105506,1025,N'��� ���� ������2','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105507 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105507,1025,N'��� ���� ������2','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go
-------------------------------------------------------------------
----------------------------RulesTranDescriptors-------------------
------------------------------------------------------------------- 

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLFullName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLFullName','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLListID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLListID','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLMemberID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLMemberID','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLSuspPercent')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLSuspPercent','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLRelatedList')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLRelatedList','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLSuspectedRims')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLSuspectedRims','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_ByCustomername')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_ByCustomername','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_RimType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_RimType','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLPersonal')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLPersonal','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLNPersonal')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLNPersonal','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLFirstName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLFirstName','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLMiddleName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLMiddleName','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLLastName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLLastName','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLOtherFirstName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLOtherFirstName','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLOtherLastName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLOtherLastName','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLOtherFullName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLOtherFullName','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLAction')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLAction','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLID2Type')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLID2Type','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLID2Number')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLID2Number','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLID1Type')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLID1Type','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 618 And DSC_Name = 'TLR_BLID1Number')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (618,'TLR_BLID1Number','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

-------------------------------------------------------------------
----------------------------RulesTranField-------------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = 1227)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,1227,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = 431)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,431,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = 209)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,209,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = 1476)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,1476,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = 1490)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,1490,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = 1492)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,1492,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = 1493)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,1493,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = 1496)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,1496,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = 1498)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,1498,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = -269961)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,-269961,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = -269975)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,-269975,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 618 And FieldID = -129999)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (618,-129999,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

-------------------------------------------------------------------
----------------------------HostCoreServiceFields------------------
-------------------------------------------------------------------
DECLARE @serviceID INT
IF  EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'GetPhxControlValues')
BEGIN

	SELECT @serviceID =  ServiceId FROM HostCoreService WHERE ServiceName='GetPhxControlValues'		
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetPhxControlValues') And FieldId = 190)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,190,'BlAllowMulreason','char',0,0,N'','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END

	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetPhxControlValues') And FieldId = 200)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,200,'BlAllowNameMatch','char',0,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')
	End

	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetPhxControlValues') And FieldId = 210)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,210,'BlMatchNamePercent','decimal',0,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')
	END
END

IF  EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'LocateBlackListCustomers')
BEGIN
	
	SELECT @serviceID =  ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers'
		
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  and FieldId = 8)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,8,'ListID','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END		
	/******************/
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 9)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,9,'OtherFullName','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 10)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,10,'OtherFirstName','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 11)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,11,'OtherMiddleName','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 12)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,12,'OtherLastName','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 13)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,13,'FirstName','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 14)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,14,'MiddleName','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 15)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,15,'LastName','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 16)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,16,'IDType2','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 17)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,17,'IDNumber2','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 43)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,43,'OtherFullName','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 44)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,44,'OtherFirstName','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 45)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,45,'OtherMiddleName','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 46)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,46,'OtherLastName','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 47)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,47,'FirstName','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 48)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,48,'MiddleName','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 49)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,49,'LastName','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 50)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,50,'FullName','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 51)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,51,'grp_ID','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='LocateBlackListCustomers')  And FieldId = 52)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,52,'Action','varchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END	
	
	
END


IF  EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'CustomerProfile')
BEGIN

	SELECT @serviceID =  ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'		
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') And FieldId = 102)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,102,'IdentificationType2','int',0,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END

	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') And FieldId = 103)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,103,'IdentificationValue2','nvarchar',0,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')
	End	
END

GO
-------------------------------------------------------------------
----------------------------BankTPIInterface-----------------------
-------------------------------------------------------------------
IF  EXISTS(SELECT * FROM BankTPIInterface WHERE FieldCode='blm' AND NoOfParameters!=47)
BEGIN
 UPDATE BankTPIInterface SET NoOfParameters=47 where FieldCode='blm'
END
-------------------------------------------------------------------
----------------------------PickList_Entries-----------------------
-------------------------------------------------------------------
If Not Exists(Select * From PickLists Where PickListID = 553)
Begin
 Insert Into PickLists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,553,'TLR_BLActions','Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','Aug 31 2008  4:25PM','Feb 22 2005 10:19AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1)
End
go
--update PickList_Entries SET [Value]='2' Where PickListID = 553 And DisplayOrder = 2
If Not Exists(Select * From PickList_Entries Where PickListID = 553 And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (553,1,0,'TLR_BLAction_N','0','Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','Feb 22 2005 11:22AM','Feb 22 2005 10:20AM',N'ITSOFT\nada.elshafie',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
If Not Exists(Select * From PickList_Entries Where PickListID = 553 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (553,1,1,'TLR_BLAction_O','1','Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','Feb 22 2005 11:22AM','Feb 22 2005 10:20AM',N'ITSOFT\nada.elshafie',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
If Not Exists(Select * From PickList_Entries Where PickListID = 553 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (553,1,2,'TLR_BLAction_W','2','Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','Feb 22 2005 11:22AM','Feb 22 2005 10:20AM',N'ITSOFT\nada.elshafie',N'ITSOFT\mostafa.helmy',1,NULL)
End
go





-------------------------------------------------------------------
----------------------------SQLstrings-----------------------------
-------------------------------------------------------------------

If Not Exists(Select * From SQLstrings Where AccessID = 1100033)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100033,'HS_LISTSUSPECTEDRIMS','p',1,'GFSOLEDB','dbo.HS_LISTSUSPECTEDRIMS',0,NULL,NULL,'ITSOFT\mostafa.helmy','ITSOFT\mostafa.helmy','Mar 12 2019 11:53AM','selects all suspected rims',1,'Jan  1 1900 12:00AM','Dec 31 9998 12:00AM','Mar 11 2012 12:00AM',' ','',0,0,1,NULL,NULL,0,0,0,0,1)
End
go

If Not Exists(Select * From SQLstrings Where AccessID = 1100034)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100034,'HS_LISTBLACKLISTRELATEDMEMBERS','p',1,'GFSOLEDB','dbo.HS_LISTBLACKLISTRELATEDMEMBERS',0,NULL,NULL,'ITSOFT\mostafa.helmy','ITSOFT\mostafa.helmy','Mar 12 2019 11:53AM','selects all black list related members',1,'Jan  1 1900 12:00AM','Dec 31 9998 12:00AM','Mar 11 2012 12:00AM',' ','',0,0,1,NULL,NULL,0,0,0,0,1)
End
go



-------------------------------------------------------------------
----------------------------HostCoreService------------------------
-------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'ListSuspectedRims')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription,Developer,Created,Updator,LastChanged,HostType)
    Values (@serviceID,'ListSuspectedRims','CustomerInquiry','this service list all suspected rims','ITSOFT\mostafa.helmy','Jan 09 2020  4:42PM',N'ITSOFT\mostafa.helmy','Jan 09 2020  4:42PM',N'PHX')
    
    IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListSuspectedRims') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,1,'MemberID','int',0,0,N'0','I','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListSuspectedRims') And FieldId = 20)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,20,'RimNo','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListSuspectedRims') And FieldId = 30)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,30,'CustomerName','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListSuspectedRims') And FieldId = 40)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,40,'SuspectedPercenatge','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
END	
GO

IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'ListBlackListRelatedMembers')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription,Developer,Created,Updator,LastChanged,HostType)
    Values (@serviceID,'ListBlackListRelatedMembers','CustomerInquiry','this service list all black list related members','ITSOFT\mostafa.helmy','Jan 09 2020  4:42PM',N'ITSOFT\mostafa.helmy','Jan 09 2020  4:42PM',N'PHX')
    
    IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,1,'Grp_ID','int',0,0,N'0','I','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 20)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,20,'RimNo','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 30)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,30,'CustomerName','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 40)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,40,'MemberID','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 50)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,50,'ListID','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 60)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,60,'FirstName','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 70)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,70,'MiddleName','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 80)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,80,'LastName','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 90)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,90,'OtherFirstName','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 100)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,100,'OtherMiddleName','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 110)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,110,'OtherLastName','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListBlackListRelatedMembers') And FieldId = 120)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,120,'OtherCustomerName','nvarchar',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
END	
GO
-------------------------------------------------------------------
----------------------------RulesTranField_ex----------------------
-------------------------------------------------------------------

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'txt_BLCustOtherName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'1498','Teller','txt_BLCustOtherName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'cbo_Action')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'-129999','Teller','cbo_Action',-1,-1,-1,0,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'opt_RimType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'431','Teller','opt_RimType',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'txt_BLFirstName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'209','Teller','txt_BLFirstName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'txt_BLMiddleName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'1476','Teller','txt_BLMiddleName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'txt_BLLastName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'1490','Teller','txt_BLLastName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'txt_BL_OtherFirstName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'1492','Teller','txt_BL_OtherFirstName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'txt_BL_OtherMiddleName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'1493','Teller','txt_BL_OtherMiddleName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'txt_BL_OtherMiddleName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'1493','Teller','txt_BL_OtherMiddleName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'txt_BL_OtherLastName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'1496','Teller','txt_BL_OtherLastName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'txt_ID2Number')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'-269961','Teller','txt_ID2Number',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'cbo_ID2Type')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'-269975','Teller','cbo_ID2Type',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'btn_SusbectedRims')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','btn_SusbectedRims',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'btn_RelatedList')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','btn_RelatedList',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go


If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_BLFirstName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_BLFirstName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_BLLastName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_BLLastName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_BLMiddleName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_BLMiddleName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_BL_OtherFirstName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_BL_OtherFirstName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_BL_OtherLastName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_BL_OtherLastName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_BL_OtherMiddleName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_BL_OtherMiddleName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_BLCustOtherName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_BLCustOtherName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_Action')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_Action',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_IDType2')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_IDType2',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_ID2Number')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_ID2Number',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_BLCusFullName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_BLCusFullName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 618 And FieldIDInPage = 'lbl_BLCustName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (618,'','Teller','lbl_BLCustName',-1,-1,-1,1,0,NULL,NULL,NULL,'Sep  5 2011 12:00AM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
------------------------------------------------------------------
PRINT 'End Script for CR# GFSY00781'
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105526)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105526,N'TLR_TOTAL_LOANS',1,N'Labels',N'Total Loans')
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=638 AND DSC_Name='TLR_TOTAL_LOANS')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(638,N'TLR_TOTAL_LOANS')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105526 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105526,1025,N'������ ������')
END
GO
GO
--Programmer : Mostafa Sayed
--Date       : [29/12/2019]
--Reason     : CR#GFSY00780 - BARWA_ACM14549_Black List Changes .....
---------------------------------------------------------------------
--RulesDescriptor
IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1105514)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1105514,'TLR_ENBL_MULT_REASON_BL_SD',0,'Labels','Enable Multi Reasons Black List')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105514 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105514,1025,N'����� ����� ������� ��������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1105515)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1105515,'TLR_ENBL_MULT_REASON_BL_LD',0,'Labels','Specify if Check for Multiple Black List Reasons  in Phoenix or Not:\r\nTrue: Check for Multiple Black List in Phoenix.\r\nFalse: Do not Check for Multiple Black List in Phoenix, Check For Black List Customer Only.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105515 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105515,1025,N'��� �� ��� ��� ������ �� ���� ��� ����� ����� ����� �� ������ �� ��:\r\n����: ���� �� ���� ����� ����� ������ �� ������.\r\n���: �� ���� �� ���� ����� ����� ������ �� ������ � ���� �� ���� ����� ����� ���.')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1105516)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1105516,'TLR_SUSPECTED_MSG',0,'Labels','This Customer is a suspected customer')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105516 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105516,1025,N'��� ������ �� ���� ����� ��')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor where DescriptorID=1105525)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES(1,1105525,'TLR_BLACKLIST_RELATION_MSG',0,'Labels','This customer has a relationship with a black listed customer.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105525 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105525,1025,N'��� ������ �� ����� �� ���� ���� �� ������� �������.')
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=435 AND DSC_Name='ICSR_BLC_BLACK_LIST_CUST_LIST')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(435,N'ICSR_BLC_BLACK_LIST_CUST_LIST')
END
GO
--HostCoreService
--InquireBlackListCustomer
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
	Values(@serviceID,N'InquireBlackListCustomer',N'CustomerInquiry',N'Call phoenix inquiry to check for black list customer')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='ServicesType')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'ServicesType',N'int',0,0,N'1',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='RimNo')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'RimNo',N'int',0,1,N'0',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='TIN')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'TIN',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='ID1')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'ID1',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='ID2')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'ID2',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='FullName')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'FullName',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='LastName')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'LastName',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='FirstName')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'FirstName',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='MiddleName')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'MiddleName',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='OFullName')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'OFullName',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='OLastName')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'OLastName',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='OFirstName')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'OFirstName',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='OMiddleName')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'OMiddleName',N'varchar',0,1,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='RimType')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'RimType',N'varchar',0,0,N'',N'I')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='Status')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'Status',N'varchar',999,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='BlackListID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'BlackListID',N'int',999,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='Action')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'Action',N'varchar',999,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='ReasonOfHighest')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'ReasonOfHighest',N'varchar',999,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='MemberID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'MemberID',N'int',999,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='Remarks')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'Remarks',N'varchar',999,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='Entity')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'Entity',N'varchar',999,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer') AND FieldName='RimNumber')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='InquireBlackListCustomer'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'RimNumber',N'int',999,0,N'0',N'O')
END
GO

--CustomerProfile
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='BlackListStatus')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'BlackListStatus',N'varchar',0,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='BlackListID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'BlackListID',N'int',0,0,N'-1',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='BlackListAction')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'BlackListAction',N'varchar',0,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='BlackListReasonOfHighest')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'BlackListReasonOfHighest',N'varchar',0,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='BlackListRemarks')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'BlackListRemarks',N'varchar',0,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='BlackListEntity')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'BlackListEntity',N'varchar',0,0,N'',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='BlackListRimNo')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'BlackListRimNo',N'int',0,1,N'0',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='BlackListMemberID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'BlackListMemberID',N'int',0,1,N'0',N'O')
END
GO

--SQLStrings
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID=1100032)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,AccessString,CommandType,GetsRows,DataSource,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	Values(1,1100032,N'HS_BlackListInquiry',N'dbo.HS_BlackListInquiry',N'P',1,N'GFSOLEDB',0,N'',N'',N'Inquirey to check if customer is black listed',1,N'',N'',0,0,1,NULL,NULL,0,0,0,0)
END
GO

--BankConfig
IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'EnableMultiReasonsBlackList')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'EnableMultiReasonsBlackList',@Value = '0',@DataType = 'bit',@ShortDescr = 'TLR_ENBL_MULT_REASON_BL_SD',@LongDescr = 'TLR_ENBL_MULT_REASON_BL_LD',@MaxVal = '1',@MinVal='0'
END
GO
--************** Begin Mostafa Helmy Defect #GFSX13949*****************
DECLARE @serviceID INT
IF  EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'CustomerLocate')
BEGIN

	SELECT @serviceID =  ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate'		
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate') And FieldId = 998)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,998,'Id2Type','int',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END

	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate') And FieldId = 999)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,999,'Id2Number','varchar',0,0,N'NULL','I','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')
	End	
END
--************** End Mostafa Helmy Defect #GFSX13949*****************
GO
--Devolper		:	Ahmed Osman
--Date			:	[01/01/2020]		
--Reason		:	CR#GFSY00782 - CBD_ACM17037_Positive Pay Cheque
--=============================================================
PRINT 'Start. Script for CR# GFSY00782 DML Script'
GO

---------------------------------
---- RulesTranDescriptors -------
---------------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 162 And DSC_Name = 'TLR_Remarks')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (162,'TLR_Remarks',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 162 And DSC_Name = 'TLR_BENEFICIARY_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (162,'TLR_BENEFICIARY_NAME',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

---------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------
---- RulesTranField_ex ----------
---------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 162 And FieldID IS NULL And FieldIDInPage = '_lbl_Remarks')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (162,NULL,'Teller','_lbl_Remarks',-1,-1,-1,1,0,'TLR_Remarks','',NULL,N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 162 And FieldID = '435' And FieldIDInPage = '_txt_Remarks')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (162,'435','Teller','_txt_Remarks',-1,-1,-1,1,1,NULL,'',NULL,N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 162 And FieldID = '2042' And FieldIDInPage = '_lbl_benfName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (162,'2042','Teller','_lbl_benfName',-1,-1,-1,1,0,'TLR_BENEFICIARY_NAME','',NULL,N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 162 And FieldID = '2042' And FieldIDInPage = '_txt_benfName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (162,'2042','Teller','_txt_benfName',-1,-1,-1,1,0,NULL,'',NULL,N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO 

---------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------
---- RulesTranField -------------
---------------------------------
If Not Exists(Select * From RulesTranField Where TranID = 162 And FieldID = 435)	--Reamrks Field
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (162,435,1,1,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'Remarks',1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 162 And FieldID = 2042)	--Benf Field
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (162,2042,1,1,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
End
GO

---------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------
---- HostCoreServiceFields ------
---------------------------------
If Exists(Select * From HostCoreService Where ServiceName = 'ListChequesStatus')
BEGIN
	DECLARE @SerivceID int , @FieldId int
	SELECT @SerivceID = ServiceId FROM HostCoreService Where ServiceName = 'ListChequesStatus'

	If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @SerivceID And FieldName = 'ChequeAmount')
	  BEGIN
		SELECT @FieldId = max(FieldId) + 1 From HostCoreServiceFields Where ServiceId = @SerivceID
		Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
		Values (@SerivceID,@FieldId,'ChequeAmount','decimal',999,0,0,'O',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
	  END
	If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @SerivceID And FieldName = 'ChequeDateTime')
	  BEGIN
		SELECT @FieldId = max(FieldId) + 1 From HostCoreServiceFields Where ServiceId = @SerivceID
		Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
		Values (@SerivceID,@FieldId,'ChequeDateTime','datetime',999,0,'9998-12-31 00:00:00.000','O',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
	  END
	If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @SerivceID And FieldName = 'ChequeDescription')
	  BEGIN
		SELECT @FieldId = max(FieldId) + 1 From HostCoreServiceFields Where ServiceId = @SerivceID
		Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
		Values (@SerivceID,@FieldId,'ChequeDescription','nvarchar',999,0,'','O',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
	  END
	If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @SerivceID And FieldName = 'ChequeRemarks')
	  BEGIN
		SELECT @FieldId = max(FieldId) + 1 From HostCoreServiceFields Where ServiceId = @SerivceID
		Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
		Values (@SerivceID,@FieldId,'ChequeRemarks','nvarchar',999,0,'','O',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
	  END
END
GO

---------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------
---- RulesParam -----------------
---------------------------------
DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'RemarksValue')
 BEGIN
	INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
	VALUES (@paramID,'RemarksValue','To Save Cheque Remarks Code Value',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
 END
GO

---------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------
---- RulesTranFldParam ----------
---------------------------------
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CashWithdrawal' And FieldName = 'ChequeRemarks' And Param = 'RemarksValue')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('CashWithdrawal','ChequeRemarks','RemarksValue','',N'ITSOFT\ahmed.orashed','nvarchar','To Save Cheque Remarks Value')
End
GO

---------------------------------------------------------------------------------------------------------------------------------------------
PRINT 'End... Script for CR# GFSY00782 DML Script'
GO
Print 'Begin:INC000000267577,Barwa - Cash difference in prepaid card transaction,Sara Badwy'
----------------------------------- RulesTranField -----------------------------------------
-- TLR_TOT_ACCRUED
If Not Exists(SELECT * From RulesTranField Where TranID = 842 And FieldID = 1142)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (842,1142,1,0,0,NULL,'ITSOFT\sara.badwy','Sep 19 2018 12:59PM',1,NULL,'','Sep 19 2018 12:59PM',N'ITSOFT\sara.badwy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'AmountForTotals',1,-1,NULL,NULL,NULL)
End
go  
If Not Exists(SELECT * From RulesTranField Where TranID = 841 And FieldID = 1142)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (841,1142,1,0,0,NULL,'ITSOFT\sara.badwy','Sep 19 2018 12:59PM',1,NULL,'','Sep 19 2018 12:59PM',N'ITSOFT\sara.badwy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'AmountForTotals',1,-1,NULL,NULL,NULL)
End
go  
----------------------------------- RulesTranField End-----------------------------------------
----------------------------------- RulesTotals -----------------------------------------------
If  Exists(Select * From RulesTotals Where TotalsID = 263 And Sequence = 1 and TranField=1751)
Begin
update RulesTotals set TranField= 1142  Where TotalsID = 263 And Sequence = 1
End
else If not  Exists(Select * From RulesTotals Where TotalsID = 263 And Sequence = 1)
Begin
 INSERT INTO RulesTotals (TotalsID , Sequence , AppID , TranField , TranFieldIndex , CurrencyFieldID , CurrencyFieldIndex , Bucket , OperationType , BumpBy , PreTotalRoutine , Developer , Updator , Creator , BumpByFieldID , BumpByFieldIndex )  
 SELECT 263 , 1 , 1 , 1142 , -1 , 40 , -1 , 'Cash In' , 0 , 1 , '' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , -1 , -1
 End
go
If  Exists(Select * From RulesTotals Where TotalsID = 262 And Sequence = 1 and TranField=1752)
Begin
update RulesTotals set TranField= 1142  Where TotalsID = 262 And Sequence = 1
End
else  If not  Exists(Select * From RulesTotals Where TotalsID = 262 And Sequence = 1)
Begin
 INSERT INTO RulesTotals (TotalsID , Sequence , AppID , TranField , TranFieldIndex , CurrencyFieldID , CurrencyFieldIndex , Bucket , OperationType , BumpBy , PreTotalRoutine , Developer , Updator , Creator , BumpByFieldID , BumpByFieldIndex )  
 SELECT 262 , 1 , 1 , 1142 , -1 , 40 , -1 , 'Cash Out' , 0 , 1 , '' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , -1 , -1
 End
go

--For Charges 
If  Exists(Select * From RulesTotals Where TotalsID = 262 And Sequence = 2 and TranField=1955)
Begin
update RulesTotals set TranField= 1129  Where TotalsID = 262 And Sequence = 2
End
else  If not  Exists(Select * From RulesTotals Where TotalsID = 262 And Sequence = 2)
Begin
 INSERT INTO RulesTotals (TotalsID , Sequence , AppID , TranField , TranFieldIndex , CurrencyFieldID , CurrencyFieldIndex , Bucket , OperationType , BumpBy , PreTotalRoutine , Developer , Updator , Creator , BumpByFieldID , BumpByFieldIndex )  
 SELECT 262 , 2 , 1 , 1129 , -1 , 1921 , -1 , 'Cash In' , 0 , 1 , '' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , -1 , -1
 End
go
If  Exists(Select * From RulesTotals Where TotalsID = 263 And Sequence = 2 and TranField=1955)
Begin
update RulesTotals set TranField= 1129  Where TotalsID = 263 And Sequence = 2
End
else  If not  Exists(Select * From RulesTotals Where TotalsID = 263 And Sequence = 2)
Begin
 INSERT INTO RulesTotals (TotalsID , Sequence , AppID , TranField , TranFieldIndex , CurrencyFieldID , CurrencyFieldIndex , Bucket , OperationType , BumpBy , PreTotalRoutine , Developer , Updator , Creator , BumpByFieldID , BumpByFieldIndex )  
 SELECT 263 , 2 , 1 , 1129 , -1 , 1921 , -1 , 'Cash In' , 0 , 1 , '' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , -1 , -1
 End
go
If  Exists(Select * From RulesTotals Where TotalsID = 264 And Sequence = 1 and TranField=1955)
Begin
update RulesTotals set TranField= 1129  Where TotalsID = 264 And Sequence = 1
End
else  If not  Exists(Select * From RulesTotals Where TotalsID = 264 And Sequence = 1)
Begin
 INSERT INTO RulesTotals (TotalsID , Sequence , AppID , TranField , TranFieldIndex , CurrencyFieldID , CurrencyFieldIndex , Bucket , OperationType , BumpBy , PreTotalRoutine , Developer , Updator , Creator , BumpByFieldID , BumpByFieldIndex )  
 SELECT 264 , 1 , 1 , 1129 , -1 , 1921 , -1 , 'Cash In' , 0 , 1 , '' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , 'itsoft\sara.badwy' , -1 , -1
 End
go
--Defect #GFSX13931
If Not Exists(Select * From RulesTranDescriptors Where TranID = 842 And DSC_Name = 'SELL_RATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (842,'SELL_RATE','Jan 29 2020  8:47PM',N'ITSOFT\sara.badwy',N'ITSOFT\sara.badwy','Jan 29 2020   8:47PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
Print 'End:INC000000267577,Barwa - Cash difference in prepaid card transaction,Sara Badwy'
GO
--Sara Badwy [Begin: 04-03-2020 - Issue# GFSX13965]
IF NOT EXISTS (SELECT * FROM RulesErrorDescription WHERE  Name='TLR_VALUEDT_EQ_BUSDT' AND DisplayText='Value Date Is Equal Business Date for Clearing mode Float')
BEGIN
update RulesErrorDescription set DetailText='Value Date Is Equal Business Date',DisplayText='Value Date Is Equal Business Date'  where Name='TLR_VALUEDT_EQ_BUSDT'
END
--Sara Badwy [Begin: 04-03-2020 - Issue# GFSX13965]
GO
IF EXISTS (SELECT * FROM RulesDescriptor  WHERE Name='TLR_ENBL_MULT_REASON_BL_SD')
BEGIN
	UPDATE RulesDescriptor
	SET Descriptor='Enable Multi Reasons Blacklist'
	WHERE Name='TLR_ENBL_MULT_REASON_BL_SD'
END
GO
IF EXISTS (SELECT * FROM RulesDescriptor  WHERE Name='TLR_ENBL_MULT_REASON_BL_LD')
BEGIN
	UPDATE RulesDescriptor
	SET Descriptor='Specify if Check for Multiple Blacklist Reasons  in Phoenix or Not:\r\nTrue: Check for Multiple Blacklist in Phoenix.\r\nFalse: Do not Check for Multiple Blacklist in Phoenix, Check For Blacklist Customer Only.'
	WHERE Name='TLR_ENBL_MULT_REASON_BL_LD'
END
GO

IF EXISTS (SELECT * FROM RulesDescriptor  WHERE Name='TLR_BLACKLIST_RELATION_MSG')
BEGIN
	UPDATE RulesDescriptor
	SET Descriptor='This customer has a relationship with a blacklisted customer.'
	WHERE Name='TLR_BLACKLIST_RELATION_MSG'
END
GO
