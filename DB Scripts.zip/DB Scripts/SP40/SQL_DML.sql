﻿USE [Globalfs]
GO
       
If Not Exists(Select * From ServicePacks Where BasePackageName = 'ETHIX-Branch_2.00.46' And SP_Number = 40)
Begin
Insert Into ServicePacks(BasePackageName,SP_Number,SP_Name, LastPackageName, BriefDescription, DetailedDescription,IncludeWholeFilesOnly,DontRemoveTmpFldrWhenFinished,OptionalSourceList,Comments,PatchNumber)
Values('ETHIX-Branch_2.00.46', 40,'SP40_ETHIX-Branch_2.0.46.0','SP39_ETHIX-Branch_2.0.46.0','SP40_ETHIX-Branch_2.0.46.0','', 1, 0, '', '',0)
End
GO
-- =============================================
-- Author:		Ibrahim Harby , Ahmed Atef
-- Create date: 04-Jan-2021
-- Description:	 CR# GfsY00833 Swift Standards for TT amount and charges
-- =============================================
If Not Exists(Select * From RulesParam Where ParamName='Field71G_Required')
Begin
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'Field71G_Required','specify if field “71G” will be sent or not in case of field 71A = OUR ','',0,1,0,'','Static','')
End


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstCash' AND FieldName = 'Field71G' AND Param = 'Field71G_Required' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstCash' , 'Field71G' , 'Field71G_Required' , 'False' ,'ITSOFT\ibrahim.harby' , 'nvarchar')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstCheque' AND FieldName = 'Field71G' AND Param = 'Field71G_Required' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstCheque' , 'Field71G' , 'Field71G_Required' , 'False' ,'ITSOFT\ibrahim.harby' , 'nvarchar')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstAccount' AND FieldName = 'Field71G' AND Param = 'Field71G_Required' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstAccount' , 'Field71G' , 'Field71G_Required' , 'False' ,'ITSOFT\ahmed.atef' , 'nvarchar')
END
GO

 

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstGL' AND FieldName = 'Field71G' AND Param = 'Field71G_Required' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstGL' , 'Field71G' , 'Field71G_Required' , 'False' ,'ITSOFT\ahmed.atef' , 'nvarchar')
END
GO
If Not Exists(Select * From SQLstrings Where AccessID = 2901)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,2901,'GetAccingEntFlagForTeller','p',1,'Globalfs','dbo.GetAccingEntFlagForTeller',0,'','','ITSOFT\aya.tarek','ITSOFT\aya.tarek','Aug  9 2011  9:50AM','Get Accounts Entries Flag from teller config',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Sep 19 2007  4:24PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

--=================================================================RulesDescriptor=======================================================
                ----TLR_SelfCertificate
 If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105058)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105058,'TLR_SelfCertificate',0,'Labels','Self Certificate','ITSOFT\shaimaa.nasser','Jan  14 2021  12:57PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','May  24 2018  3:57PM',N'ITSOFT\shaimaa.nasser')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105058 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105058,1025,N'ًSelf وثيقة','ITSOFT\shaimaa.nasser','May  24 2018  12:57PM',N'ITSOFT\shaimaa.nasser')
End
go
                ----TLR_FatcaFailure
If Not Exists (SELECT * FROM RulesDescriptor WHERE DescriptorID = 1104520)
BEGIN
INSERT INTO RulesDescriptor (AppID, DescriptorID, Name, forVB, TypeName, Descriptor, RowStatus)
	VALUES (1, 1104520, 'TLR_FatcaFailure', 0, 'Labels', 'FATCA Web Service response was failure', 1)
END
GO
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID =1104520  And LCID=1025  )
Begin
 Insert Into RulesDescriptorLocal(LCID,DescriptorID,LocalDescription)
 Values (1025,1104520,N'FATCA يوجد خطا في الرد الخاص بخدمة')
End
go
                ----DuplicateGIIN
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber =1678  And Name ='DuplicateGIIN'  )
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,AppID)
 Values (1678,'DuplicateGIIN','Cannot add duplicate GIIN ','Please, Enter Unique GIIN ! ',4,1)
End
go
If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber =1678  And LanguageLCID =1025  )
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText)
 Values (1025,1678,N'من فضللك ادخل GIIN غير متكرر',N'من فضللك ادخل GIIN غير متكرر')
End
go
                ----FatcaDown
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber =1601  And Name ='FatcaDown'  )
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,AppID)
 Values (1601,'FatcaDown','Cannot open / edit Account Because FATCA Web Service is down','Cannot open / edit Account Because FATCA Web Service is down',4,1)
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber =1601  And LanguageLCID =1025  )
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText)
 Values (1025,1601,N'متوقفة FATCA لا يمكن فتح او تعديل الحساب لان خدمة',N'متوقفة FATCA لا يمكن فتح او تعديل الحساب لان خدمة')
End
go
--=================================================================HostCoreService=======================================================
If Not Exists(Select * From HostCoreService Where ServiceName = 'CheckFatcaGIIN' )
Begin
declare @maxID5 int
set @maxID5  = (select max(ServiceId) from HostCoreService) +1
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
 Values (@maxID5,'CheckFatcaGIIN','CustomerInquiry','Get Fatca Info By GIIN')

 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @maxID5 and FieldId=1 )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@maxID5,1,'GIIN','varchar',0,0,'','I')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @maxID5 and FieldId=2 )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@maxID5,2,'GIIN','varchar',999,1,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @maxID5 and FieldId=3 )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@maxID5,3,'FatcaStatus','varchar',999,1,'','O')
End

End
go

declare @sID2 int
set @sID2 = (select top 1 ServiceId from HostCoreService  where ServiceName='GetNonPersonalRimInfo')
if @sID2 is null
Begin
	select 'GetNonPersonalRimInfo HostCoreService must be exist';
End
else if @sID2 is not null
Begin
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID2 and FieldName='SelfCertificate' )
Begin
declare @max int
    set @max  = (select max(FieldId) from HostCoreServiceFields where ServiceId=@sID2) +1
          Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
                                    Values (@sID2,@max,'SelfCertificate','char',0,0,'','O')
 End
End
go

declare @sID3 int
set @sID3 = (select top 1 ServiceId from HostCoreService  where ServiceName='GetPersonalRimInfo')
if @sID3 is null
Begin
	select 'GetPersonalRimInfo HostCoreService must be exist';
End
else if @sID3 is not null
Begin
          If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID3 and FieldName='SelfCertificate' )
                     Begin
                     declare @max int
                     set @max  = (select max(FieldId) from HostCoreServiceFields where ServiceId=@sID3) +1
                      Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
                                                Values (@sID3,@max,'SelfCertificate','char',0,0,'','O')
                     End
End
go

--=================================================================SQLstrings=======================================================

If Not Exists(Select * From SQLstrings Where  AccessID = 2898 and AppID=1 )
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,AccessString,CommandType,GetsRows,DataSource,OutputsXML,CacheMinutes,UseNewCacheRules,Purpose)
Values (1,2898,'CheckFatcaGIIN','dbo.CheckFatcaGIIN','p',1,'GFSOLEDB',0,0,1,'Get Fatca Status BY GIIN')
End
go
--=================================================================RulesTranDescriptors=======================================================
--DPAccountOpening
If Not Exists (SELECT * FROM RulesTranDescriptors WHERE TranID = 534 AND DSC_Name = 'TLR_FatcaFailure')
 BEGIN
INSERT INTO RulesTranDescriptors (TranID, DSC_Name, RowStatus)
	VALUES (534, 'TLR_FatcaFailure', 1)
END

--DPAccountEdit
If Not Exists (SELECT * FROM RulesTranDescriptors WHERE TranID = 544 AND DSC_Name = 'TLR_FatcaFailure')
 BEGIN
INSERT INTO RulesTranDescriptors (TranID, DSC_Name, RowStatus)
	VALUES (544, 'TLR_FatcaFailure', 1)
END

--RIMToRIMRelationship
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName ='RIMToRIMRelationship'  And Error_Name ='FatcaDown'  )
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name)
 Values ('RIMToRIMRelationship','FatcaDown')
End
--=================================================================RulesTranDescriptors=======================================================

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_SelfCertificate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_SelfCertificate','Jan  14 2021  1:07PM',N'ITSOFT\shaimaa.nasser',N'ITSOFT\shaimaa.nasser','Jan  14 2021  1:05PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_SelfCertificate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_SelfCertificate','Jan  14 2021  1:07PM',N'ITSOFT\shaimaa.nasser',N'ITSOFT\shaimaa.nasser','Jan  14 2021  1:05PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SelfCertificate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SelfCertificate','Jan  14 2021  1:07PM',N'ITSOFT\shaimaa.nasser',N'ITSOFT\shaimaa.nasser','Jan  14 2021  1:05PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 578 And DSC_Name = 'TLR_SelfCertificate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'TLR_SelfCertificate','Jan  14 2021  1:07PM',N'ITSOFT\shaimaa.nasser',N'ITSOFT\shaimaa.nasser','Jan  14 2021  1:05PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

--=================================================================RulesTranField     SelfCertificate=======================================================
If Not Exists(select * From RulesTranField Where TranID = 578 And FieldID = 1748)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,1748,1,0,0,NULL,'ITSOFT\shaimaa.nasser','Jan 14 2021  2:11PM',1,NULL,'','Jan 14 2021  2:11PM',N'ITSOFT\shaimaa.nasser',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SelfCertificate',0,-1)
End

If Not Exists(select *  From RulesTranField Where TranID = 564 And FieldID = 1748)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1748,1,0,0,NULL,'ITSOFT\shaimaa.nasser','Jan 14 2021  2:11PM',1,NULL,'','Jan 14 2021  2:11PM',N'ITSOFT\shaimaa.nasser',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SelfCertificate',0,-1)
End

If Not Exists(select * From RulesTranField Where TranID = 565 And FieldID = 1748)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (565,1748,1,0,0,NULL,'ITSOFT\shaimaa.nasser','Jan 14 2021  2:11PM',1,NULL,'','Jan 14 2021  2:11PM',N'ITSOFT\shaimaa.nasser',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SelfCertificate',0,-1)
End

If Not Exists(select * From RulesTranField Where TranID = 547 And FieldID = 1748)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1748,1,0,0,NULL,'ITSOFT\shaimaa.nasser','Jan 14 2021  2:11PM',1,NULL,'','Jan 14 2021  2:11PM',N'ITSOFT\shaimaa.nasser',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SelfCertificate',0,-1)
End
go
--=================================================================RulesTranErrorDescriptions=======================================================
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName ='EditNonPersonalRim'  And Error_Name ='DuplicateGIIN'  )
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name)
 Values ('EditNonPersonalRim','DuplicateGIIN')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName ='OpenNonPersonalRim'  And Error_Name ='DuplicateGIIN'  )
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name)
 Values ('OpenNonPersonalRim','DuplicateGIIN')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName ='EditPersonalRim'  And Error_Name ='FvalFieldRequired'  )
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name)
 Values ('EditPersonalRim','FvalFieldRequired')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName ='OpenNonPersonalRim'  And Error_Name ='FvalFieldRequired'  )
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name)
 Values ('OpenNonPersonalRim','FvalFieldRequired')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName ='OpenPersonalRim'  And Error_Name ='FvalFieldRequired'  )
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name)
 Values ('OpenPersonalRim','FvalFieldRequired')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName ='EditNonPersonalRim'  And Error_Name ='FvalFieldRequired'  )
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name)
 Values ('EditNonPersonalRim','FvalFieldRequired')
End
go
----------------------------------Enhancement-GFSY00752-----------nehal-
If Not Exists(Select * From PickLists Where PickListID = 540)
Begin
 Insert Into PickLists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,540,'DPHX_Seller_ID','Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','March 13 2019  4:25PM','March 13 2019 8:18PM',N'G',N'G',1)
End
go
--------------------------------------Fields----------------------------------------------

If Not Exists(select * From RulesTranField Where TranID = 534 And FieldID = 1118)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (534,1118,1,0,0,NULL,'G','Jan 20 2021  1:30PM',1,NULL,'','Jan 20 2021  1:30PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',0,NULL,0,0,'Seller_ID',0,-1)
End
go
If Not Exists(select * From RulesTranField Where TranID = 544 And FieldID = 1118)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (544,1118,1,0,0,NULL,'G','Jan 20 2021  1:30PM',1,NULL,'','Jan 20 2021  1:30PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',0,NULL,0,0,'Seller_ID',0,-1)
End
go

If Not Exists(select * From RulesTranField Where TranID = 534 And FieldID = 1859)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (534,1859,1,0,0,NULL,'G','Jan 20 2021  1:30PM',1,NULL,'','Jan 20 2021  1:30PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',0,NULL,0,0,'Source_Of_Sales',0,-1)
End
go
If Not Exists(select * From RulesTranField Where TranID = 544 And FieldID = 1859)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (544,1859,1,0,0,NULL,'G','Jan 20 2021  1:30PM',1,NULL,'','Jan 20 2021  1:30PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',0,NULL,0,0,'Source_Of_Sales',0,-1)
End
go

----------------------------RuesTranField_ex
If Not Exists(Select * From RulesTranField_ex Where TranID=534 and FieldID=1859)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (534,1859,'Teller    ','txt_source_of_sales',-1,-1,-1,1,0,'Source_Of_Sales','',NULL,'Nov 25 2019 12:37PM',N'sa',1)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID=544 and FieldID=1859)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (544,1859,'Teller    ','txt_source_of_sales',-1,-1,-1,1,0,'Source_Of_Sales','',NULL,'Nov 25 2019 12:37PM',N'sa',1)
End
go
If Not Exists(select * From RulesTranField_ex Where TranID=630 and FieldID=1859)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (630,1859,'Teller    ','txt_source_of_sales',-1,-1,-1,1,0,'Source_Of_Sales','',NULL,'Nov 25 2019 12:37PM',N'sa',1)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID=534 and FieldID=1118)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (534,1118,'Teller    ','cbo_seller_id',-1,-1,-1,1,0,'SellerID','',NULL,'Nov 25 2019 12:37PM',N'sa',1)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID=544 and FieldID=1118)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (544,1118,'Teller    ','cbo_seller_id',-1,-1,-1,1,0,'SellerID','',NULL,'Nov 25 2019 12:37PM',N'sa',1)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID=630 and FieldID=1118)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (630,1118,'Teller    ','cbo_seller_id',-1,-1,-1,1,0,'SellerID','',NULL,'Nov 25 2019 12:37PM',N'sa',1)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID=534 and FieldIDInPage='lbl_seller_id')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (534,NULL,'Teller    ','lbl_seller_id',-1,-1,-1,1,0,'SellerID','',NULL,'March 30 2019  1:38PM',N'ITSOFT\ahmed.almaghraby',1)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID=544 and FieldIDInPage='lbl_seller_id')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (544,NULL,'Teller    ','lbl_seller_id',-1,-1,-1,1,0,'SellerID','',NULL,'March 30 2019  1:38PM',N'ITSOFT\ahmed.almaghraby',1)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID=630 and FieldIDInPage='lbl_seller_id')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (630,NULL,'Teller    ','lbl_seller_id',-1,-1,-1,1,0,'SellerID','',NULL,'March 30 2019  1:38PM',N'ITSOFT\ahmed.almaghraby',1)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID=534 and FieldIDInPage='lbl_source_of_sales')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (534,NULL,'Teller    ','lbl_source_of_sales',-1,-1,-1,1,0,'Source_Of_Sales','',NULL,'March 30 2019  1:38PM',N'ITSOFT\ahmed.almaghraby',1)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID=544 and FieldIDInPage='lbl_source_of_sales')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (544,NULL,'Teller    ','lbl_source_of_sales',-1,-1,-1,1,0,'Source_Of_Sales','',NULL,'March 30 2019  1:38PM',N'ITSOFT\ahmed.almaghraby',1)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID=630 and FieldIDInPage='lbl_source_of_sales')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (630,NULL,'Teller    ','lbl_source_of_sales',-1,-1,-1,1,0,'Source_Of_Sales','',NULL,'March 30 2019  1:38PM',N'ITSOFT\ahmed.almaghraby',1)
End
go
-----------------------------------Descriptors ------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105345)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105345,'SellerID',0,'Labels','Seller ID','G','March 13 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','March 13 2019  1:32PM',N'ITSOFT\ahmed.almaghraby')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105345 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105345,1025,N'معرف البائع','ITSOFT\ahmed.almaghraby','Nov 7 2018  3:47PM',N'ITSOFT\ahmed.almaghraby')
End
go
--
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105346)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105346,'Source_Of_Sales',0,'Labels','Source Of Sales','G','March 13 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','March 13 2019  1:32PM',N'ITSOFT\ahmed.almaghraby')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105346 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105346,1025,N'مصدر المبيعات','ITSOFT\ahmed.almaghraby','Nov 7 2018  3:47PM',N'ITSOFT\ahmed.almaghraby')
End
go
--
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'SellerID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'SellerID','Nov 17 2018  3:47PM',N'G',N'G','Nov 7 2018  3:47PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'Source_Of_Sales')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'Source_Of_Sales','March 13 2019  3:47PM',N'G',N'G','Nov 7 2018  3:47PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---
If Not Exists(Select * From RulesTranDescriptors Where TranID = 544 And DSC_Name = 'SellerID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (544,'SellerID','March 13 2019  3:47PM',N'G',N'G','March 13 2019   3:47PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 544 And DSC_Name = 'Source_Of_Sales')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (544,'Source_Of_Sales','March 13 2019  3:47PM',N'G',N'G','Nov 7 2018  3:47PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--
If Not Exists(Select * From RulesTranDescriptors Where TranID = 630 And DSC_Name = 'SellerID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (630,'SellerID','March 13 2019  3:47PM',N'G',N'G','March 13 2019   3:47PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 630 And DSC_Name = 'Source_Of_Sales')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (630,'Source_Of_Sales','March 13 2019  3:47PM',N'G',N'G','March 13 2019 3:47PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
-----------------------------TPI---------------------------------
If  Exists(Select * From BankTPIInterface Where BankID = 1 And FieldCode = 'DEP')
Begin
 update  BankTPIInterface  set NoOfParameters =165  
 where  FieldCode = 'DEP'
End
go
----------------------------------hostcoreService------------------
declare @sID int
set @sID = (select top 1 ServiceId from HostCoreService  where ServiceName='GetDPAccountBasicInfo')
if @sID is null
Begin
	select 'GetDPAccountBasicInfo HostCoreService must be exist';
End
else if @sID is not null
Begin
declare @maxID int
set @maxID = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  *From HostCoreServiceFields Where ServiceId = @sID and FieldName='SellerID')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'SellerID','int',0,0,0,'O')
End

Set @maxID = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID)
If Not Exists(Select  *From HostCoreServiceFields Where ServiceId = @sID and FieldName='SourceOfSales' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'SourceOfSales','nvarchar',0,0,'','O')
End

End
go

---RulesErrorDescriptor
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1754)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1754,'INVALID_Seller_ID','Invalid seller ID in list of seller ID','Invalid seller ID in list of seller ID',4,'',1,'ITSOFT\ahmed.almaghraby','march 16 2019  1:28PM',1,'Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'DPAccountEdit' And Error_Name = 'INVALID_Seller_ID')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('DPAccountEdit','INVALID_Seller_ID','Mar 25 2019  3:02PM','ITSOFT\ahmed.almaghraby',1,'Dec 31 9998 12:00AM','Mar 25 2019  3:02PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'DPAccountOpening' And Error_Name = 'INVALID_Seller_ID')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('DPAccountOpening','INVALID_Seller_ID','Mar 25 2019  3:02PM','ITSOFT\ahmed.almaghraby',1,'Dec 31 9998 12:00AM','Mar 25 2019  3:02PM')
End
go


If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1754)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1754,N'رقم البائع غير معرف فى قائمه الباعه',N'رقم البائع غير معرف فى قائمه الباعه','','G','Mar 26 2019  2:35PM')
End
go
--Devolper	 :	Aya Tarek
--Date       :	[20/1/2021]		
--Reason     :	CR#GFSY00765 _Retrofit- KFH_ACM17509_Override Upon Customer Age
------------------------------------------------------------------------------------------------

----------------------------------------------
----- HostCoreService && HostCoreServiceFields
----------------------------------------------
--CustomerAge 
IF Exists(Select * From HostCoreService Where ServiceName = 'GetDPAcctInfoWithCustInfo')
	BEGIN
		DECLARE @serviceID int , @fieldId int
		SELECT @serviceID = ServiceId from HostCoreService WHERE ServiceName = 'GetDPAcctInfoWithCustInfo'
		SELECT @fieldId = max(FieldId) + 1  from HostCoreServiceFields  WHERE ServiceId = @serviceID
		BEGIN
			If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @serviceID And FieldName = 'CustomerAge')
				BEGIN
					Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
					Values (@serviceID,@fieldId,'CustomerAge','int',0,0,0,'O','ITSOFT\aya.tarek',N'ITSOFT\aya.tarek')
				END
		END
	END

GO

--customerAge
	IF Exists(Select * From HostCoreService Where ServiceName = 'GetLNAcctInfoWithCustInfo')
	BEGIN
		DECLARE @serviceID int , @fieldId int
		SELECT @serviceID = ServiceId from HostCoreService WHERE ServiceName = 'GetLNAcctInfoWithCustInfo'
		SELECT @fieldId = max(FieldId) + 1  from HostCoreServiceFields  WHERE ServiceId = @serviceID
		BEGIN
			If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @serviceID And FieldName = 'CustomerAge')
				BEGIN
					Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
					Values (@serviceID,@fieldId,'CustomerAge','int',0,0,0,'O','ITSOFT\aya.tarek',N'ITSOFT\aya.tarek')
				END
		END
	END
GO
----------------------
----- SQLstrings -----
----------------------
If Not Exists(Select * From SQLstrings Where AccessID = 1100020)
	Begin
		Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
		Values (1,1100020,'TLR_GET_TRAN_CONDIT_OPERANDS','p',1,'Globalfs','dbo.GetOverrideAndTranValidationOperands',0,NULL,NULL,'ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select All Override Condition Operands and all Transaction Validation Operands that related to specify transaction - CR#GFSY00765',1,' ','',0,0,1,NULL,NULL,0,0,0,0)
	End
GO

--==================================================================================================================================================================
--Devolper	:	Mostafa Helmy
--Date		:	[25/01/2021]		
--Reason	:	Enh GFSY00839 ACM000000018423 - CBD - Commercial Registration Number

--=====================================================================

PRINT 'Start. Script for CR# GFSY00839 DML Script'
GO
--------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal --
--------------------------------------------

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105861)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105861,'TLR_CRNumber_EXISTS',0,'Labels','CR / Commercial Registration Number Exists','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105861 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105861,1025,N'رقم السجل التجاري موجود من قبل','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO
-------------------------------------------------------------------
----------------------------RulesTranDescriptors-------------------
------------------------------------------------------------------- 

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_CRNumber_EXISTS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_CRNumber_EXISTS','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 578 And DSC_Name = 'TLR_CRNumber_EXISTS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'TLR_CRNumber_EXISTS','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--------------------------------------------
-- RulesParam & RulesTranFldParam-----------
--------------------------------------------

If Not Exists(Select * From RulesParam Where  ParamName='Repeat_CRNumber')
Begin
	DECLARE @ParamID INT
	SELECT @ParamID = MAX(ParamID) +1 FROM RulesParam
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@ParamID,'Repeat_CRNumber','allow or deny the repetition of CR number for non personal rim',NULL,0,0,0,'','Static','','Jan 26 2021  3:22PM',N'ITSOFT\mostafa.helmy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)

End
go
	
If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenNonPersonalRim' And FieldName = 'RepeatCRN' And Param = 'Repeat_CRNumber')
Begin
	Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	Values ('OpenNonPersonalRim','RepeatCRN','Repeat_CRNumber','0',N'ITSOFT\mostafa.helmy','nvarchar','Aug 01 2020 9:22AM',NULL)
End
go

If Not Exists(Select * From RulesTranFldParam Where TranName = 'EditNonPersonalRim' And FieldName = 'RepeatCRN' And Param = 'Repeat_CRNumber')
Begin
	Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	Values ('EditNonPersonalRim','RepeatCRN','Repeat_CRNumber','0',N'ITSOFT\mostafa.helmy','nvarchar','Aug 01 2020 9:22AM',NULL)
End
go

PRINT 'End... Script for CR# GFSY00839 DML Script'
GO
-- =============================================
-- Author:		Ibrahim Harby , Ahmed Atef
-- Create date: 27-Jan-2021
-- Description:	 CR# GFSY00836 Swift Standards for TT amount and charges
-- =============================================
If Not Exists(Select * From RulesParam Where ParamName='Field71G_Required')
Begin
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'Field71G_Required','specify if field “71G” will be sent or not in case of field 71A = OUR ','',0,1,0,'','Static','')
End


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'PayInstallmentBySwift' AND FieldName = 'Field71G' AND Param = 'Field71G_Required' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'PayInstallmentBySwift' , 'Field71G' , 'Field71G_Required' , 'False' ,'ITSOFT\ahmed.atef' , 'nvarchar')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTT' AND FieldName = 'Field71G' AND Param = 'Field71G_Required' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTT' , 'Field71G' , 'Field71G_Required' , 'False' ,'ITSOFT\ibrahim.harby' , 'nvarchar')
END
GO
-------------------------------------------------------------------------------------------------------------
If Not Exists(Select * From RulesParam Where ParamName='ValidationRequired')
Begin
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'ValidationRequired','Specify if Control Validation is Required or Not','',0,1,0,'','Static','')
End

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'PayInstallmentBySwift' AND FieldName = 'AccountWithInstitution' AND Param = 'ValidationRequired' )
BEGIN
	DECLARE @AccWithInstitutionVal nvarchar(10)
	SELECT @AccWithInstitutionVal = Value 
	From  dbo.RulesTranFldParam  
	Where TranName  = 'IssueTTAgainstAccount' 
	AND	  FieldName = 'AccountWithInstitution' 
	AND   Param     = 'ValidationRequired'

	INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
	Values( 'PayInstallmentBySwift' , 'AccountWithInstitution' , 'ValidationRequired' , @AccWithInstitutionVal ,'ITSOFT\ahmed.atef' , 'nvarchar')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'PayInstallmentBySwift' AND FieldName = 'PaymentDetails' AND Param = 'ValidationRequired' )
BEGIN
	DECLARE @PaymentDetailsVal nvarchar(10)
	SELECT @PaymentDetailsVal = Value 
	From  dbo.RulesTranFldParam  
	Where TranName  = 'IssueTTAgainstAccount' 
	AND	  FieldName = 'PaymentDetails' 
	AND   Param     = 'ValidationRequired'

	INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
	Values( 'PayInstallmentBySwift' , 'PaymentDetails' , 'ValidationRequired' , @PaymentDetailsVal ,'ITSOFT\ahmed.atef' , 'nvarchar')
END
GO
-----------------------------------------------------------------------------
---Retrofit  :  Hesabi Segment Update ACM000000017033
---Developer :  Shaimaa AbdElnasser Mohamed 
--------------------------------------------------------------

---------------------------- HostCoreServiceFields--------------------------------------------------------------

IF Not Exists(Select * From HostCoreServiceFields Where ServiceId = (SELECT ServiceId FROM HostCoreService Where ServiceName='GetRimClassInfo') And FieldName = 'MinAge')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,DataType,FieldName,Optional,DefaultValue,Direction,Developer,Created,Updator)
 Values ((SELECT ServiceId FROM HostCoreService Where ServiceName='GetRimClassInfo'),(SELECT MAX(FieldId)+1 From HostCoreServiceFields Where ServiceId =(SELECT ServiceId FROM HostCoreService Where ServiceName='GetRimClassInfo'))
,'tinyint','MinAge','1','0','O',N'ITSOFT\shaimaa.nasser','Jan 24 2021',N'ITSOFT\shaimaa.nasser')
End
go
IF Not Exists(Select * From HostCoreServiceFields Where ServiceId = (SELECT ServiceId FROM HostCoreService Where ServiceName='GetRimClassInfo') And FieldName = 'MaxAge')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,DataType,FieldName,Optional,DefaultValue,Direction,Developer,Created,Updator)
 Values ((SELECT ServiceId FROM HostCoreService Where ServiceName='GetRimClassInfo'),(SELECT MAX(FieldId)+1 From HostCoreServiceFields Where ServiceId =(SELECT ServiceId FROM HostCoreService Where ServiceName='GetRimClassInfo'))
,'tinyint','MaxAge','1','0','O',N'ITSOFT\shaimaa.nasser','Jan 24 2021',N'ITSOFT\shaimaa.nasser')
End
go


-------------------------------------------- RulesErrorDescription------------------------------------------------------------

IF Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1782)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,Help,AppID,Developer,RowStatus,ExpirationDate,ErrorNumber)
 Values (1782,'AGE_NOT_MATCHED_CLASS','RIM Class Not Matched with Customer Age','RIM Class Not Matched with Customer Age','',1,N'ITSOFT\shaimaa.nasser',1,'Dec 31 9998 00:00:00.000',2)
End
go
IF Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1782)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1782,N'فئة العميل غير متطابقة مع عمر العميل',N'فئة العميل غير متطابقة مع عمر العميل','',N'ITSOFT\shaimaa.nasser')
End
go
-------------------------------------------- RulesTranErrorDescriptions------------------------------------------------------------

IF Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'AGE_NOT_MATCHED_CLASS')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,Created,RowStatus,ExpirationDate)
 Values ('OpenPersonalRim','AGE_NOT_MATCHED_CLASS','Jan 25 2021  3:08PM',N'ITSOFT\shaimaa.nasser','Jan 25 2021  3:08PM',1,'Dec 31 9998 00:00:00.000')
End
go

IF Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'AGE_NOT_MATCHED_CLASS')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,Created,RowStatus,ExpirationDate)
 Values ('EditPersonalRim','AGE_NOT_MATCHED_CLASS','Jan 25 2021  3:08PM',N'ITSOFT\shaimaa.nasser','Jan 25 2021  3:08PM',1,'Dec 31 9998 00:00:00.000')
 
End
go
--==================================================================================================================================================================
--Devolper	:	Mostafa Helmy
--Date		:	[03/11/2020]		
--Reason	:	Enh GFSY00800 - KFH - ACM000000018096 KYC RIM Fields - Retrofit

--=====================================================================

PRINT 'Start. Script for CR# GFSY00800 DML Script'
GO

--------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal --
--------------------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105642)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105642,'TLR_INVALID_KycExpDt',0,'Labels','KYC Expiration Date Should Be Updated','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105642 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105642,1025,N'تاريخ معرفة عميلك يجب أن يتم تحديثه','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1104592)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1104592,'TLR_KYC_Date',0,'Labels','KYC Date','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1104592 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1104592,1025,N'تاريخ معرفة عميلك','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO



IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105634)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105634,'TLR_Update_KYC_Date',0,'Labels','Update KYC Date','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105634 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105634,1025,N'تحديث تاريخ معرفة عميلك','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO
-------------------------------------------------------------------
----------------------------RulesTranDescriptors-------------------
------------------------------------------------------------------- 

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_Update_KYC_Date') --OpenPersonalRim
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_Update_KYC_Date','Jan 29 2019  3:48PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_Update_KYC_Date') --OpenNonPersonalRim
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_Update_KYC_Date','Jan 29 2019  3:48PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_Update_KYC_Date') --EditPersonalRim
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_Update_KYC_Date','Jan 29 2019  3:48PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 578 And DSC_Name = 'TLR_Update_KYC_Date') --EditNonPersonalRim
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'TLR_Update_KYC_Date','Jan 29 2019  3:48PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
-------------------------------------------------------------------
----------------------------RulesTranField-------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 286) --Update_KYC_DATE
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,286,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 578 And FieldID = 286) --Update_KYC_DATE
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,286,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1)
End
go

-------------------------------------------------------------------
----------------------------RulesTranField_ex-------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------


If Not Exists(Select * From RulesTranField_ex Where TranID = 578 And FieldID Is Null  And FieldIDInPage = 'Chk_UpdatKycDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller','Chk_UpdatKycDate',-1,-1,-1,1,0,'TLR_Update_KYC_Date','',NULL,'Aug  5 2018 12:55PM',N'ITSOFT\mostafa.helmy',0)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 564 And FieldID Is Null  And FieldIDInPage = 'Chk_UpdatKycDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller','Chk_UpdatKycDate',-1,-1,-1,1,0,'TLR_Update_KYC_Date','',NULL,'Aug  5 2018 12:55PM',N'ITSOFT\mostafa.helmy',0)
End
go

-------------------------------------------------------------------
----------------------------HostCoreService-------------------------
-------------------------------------------------------------------
 DECLARE @serviceID INT
 IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'GetKycExpDate')
BEGIN
	
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription,Developer,Created,Updator,LastChanged)
    Values (@serviceID,'GetKycExpDate','CustomerInquiry','get the rim KYC Expiration Date','ITSOFT\mostafa.helmy','Jan 09 2020  4:42PM',N'ITSOFT\mostafa.helmy','Jan 09 2020  4:42PM')
    
    IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetKycExpDate') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,1,'RimNo','int',0,0,N'0','I','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetKycExpDate') And FieldId = 2)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,2,'KYC_Dt','datetime',9999,0,N'NULL','I','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetKycExpDate') And FieldId = 3)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,3,'KYC_Exp_Date','datetime',9999,0,N'NULL','O','ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM',N'ITSOFT\mostafa.helmy','Jan 09 2020 10:36AM')
	END
	
	
End	


IF  EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'CustomerProfile')
BEGIN
     
   
	SELECT @serviceID =  ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'		
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') And FieldId = 106)
	BEGIN	
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
		VALUES (@serviceID,106,'Kyc_Date','datetime',0,0,N'NULL','O','ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM',N'ITSOFT\mostafa.helmy','Dec 25 2019 10:36AM')		
	END
	
END

-------------------------------------------------------------------
----------------------------SQLstrings-----------------------------
-------------------------------------------------------------------

If Not Exists(Select * From SQLstrings Where AccessID = 1100072)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,1100072,'HS_GETKYCEXPDATE','p',1,'GFSOLEDB','dbo.HS_GETKYCEXPDATE',0,NULL,NULL,'ITSOFT\mostafa.helmy','ITSOFT\mostafa.helmy','Mar 12 2019 11:53AM','Get KYC Exp Date',1,'Jan  1 1900 12:00AM','Dec 31 9998 12:00AM','Mar 11 2012 12:00AM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

PRINT 'End... Script for CR# GFSY00800 DML Script'
GO
--==================================================================================================================================================================
--Developer : Mostafa Sayed
--Date		: 13-01-2021
--Reason	: INC000000294667 - GFSX14411
------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105858)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (1,1105858,'TLR_PAYMENT_DISBURSED_BEFORE',1,'Labels','This payment already disbursed to customer before.')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105858 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1105858,1025,N'.تم صرف هذه الدفعة إلى العميل من قبل')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 343 And DSC_Name = 'TLR_PAYMENT_DISBURSED_BEFORE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (343,'TLR_PAYMENT_DISBURSED_BEFORE')
End
go

/*
CreationDate:	2021-01-18  retorfit 3-1-2021
Programmer:	abdelrhman mohamed
*/

IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID=1100099)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,AccessString,CommandType,GetsRows,DataSource,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,developer)
	Values(1,1100099,N'select_PrintTranFields',N'dbo.select_PrintTranFields',N'P',1,N'Globalfs',0,N'',N'',N'get fields in grid',1,N'',N'',0,0,1,NULL,NULL,0,0,0,0,'sqladmin')
END
GO


--TLR_POSTING_TYPE
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_POSTING_TYPE' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_POSTING_TYPE'
           ,0)
end
GO

--TLR_GL_DP
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_GL_DP' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_GL_DP'
           ,1)
end
GO

--TLR_AC_NUM_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_AC_NUM_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_AC_NUM_MULTI_DR_CR'
           ,2)
end
GO

--TLR_AC_CUR_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_AC_CUR_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_AC_CUR_MULTI_DR_CR'
           ,3)
end
GO

--TLR_TRANSFER_AMT_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_TRANSFER_AMT_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_TRANSFER_AMT_MULTI_DR_CR'
           ,4)
end
GO

--TLR_EXCHANGE_RATE_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_EXCHANGE_RATE_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_EXCHANGE_RATE_MULTI_DR_CR'
           ,5)
end
GO

--TLR_TRANS_AMT_LCL_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_TRANS_AMT_LCL_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_TRANS_AMT_LCL_MULTI_DR_CR'
           ,6)
end
GO

--Description
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='Description' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'Description'
           ,7)
end
GO

--TLR_PRINT_OPTION_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PRINT_OPTION_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PRINT_OPTION_MULTI_DR_CR'
           ,8)
end
GO

--TLR_ACCT_TYPE_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_ACCT_TYPE_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_ACCT_TYPE_MULTI_DR_CR'
           ,9)
end
GO

--TLR_APPLI_TYPE_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_APPLI_TYPE_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_APPLI_TYPE_MULTI_DR_CR'
           ,10)
end
GO

--TLR_ACCT_STATUS_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_ACCT_STATUS_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_ACCT_STATUS_MULTI_DR_CR'
           ,11)
end
GO

--TLR_DOCUMENTNUMBER_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_DOCUMENTNUMBER_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_DOCUMENTNUMBER_ARRAY'
           ,12)
end
GO


--TLR_CHEQUE_NUMBER_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_CHEQUE_NUMBER_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_CHEQUE_NUMBER_ARRAY'
           ,13)
end
GO

--TLR_SETTLE_ON_CURRENCY_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_SETTLE_ON_CURRENCY_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_SETTLE_ON_CURRENCY_ARRAY'
           ,14)
end
GO

--TLR_MulTrnsfR_Acct_ValDt
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_MulTrnsfR_Acct_ValDt' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_MulTrnsfR_Acct_ValDt'
           ,15)
end
GO

--TLR_CHQ_VALDT_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_CHQ_VALDT_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_CHQ_VALDT_MULTI_DR_CR'
           ,16)
end
GO

--TLR_RECEPIT_STATUS_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_RECEPIT_STATUS_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_RECEPIT_STATUS_ARRAY'
           ,17)
end
GO

--TLR_BUY_EXCHANGE_RATE_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_BUY_EXCHANGE_RATE_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_BUY_EXCHANGE_RATE_ARRAY'
           ,18)
end
GO


--TLR_DELIVERY_STATUS_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_DELIVERY_STATUS_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_DELIVERY_STATUS_ARRAY'
           ,19)
end
GO

--TLR_IR_MsgRefNo_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_MsgRefNo_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_MsgRefNo_Array'
           ,20)
end
GO

--TLR_IR_SenderRefNo_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_SenderRefNo_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_SenderRefNo_Array'
           ,21)
end
GO

--TLR_MultiTransfer_Acct_Name
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_MultiTransfer_Acct_Name' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_MultiTransfer_Acct_Name'
           ,22)
end
GO

--TLR_NARRATIVE_DR_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_NARRATIVE_DR_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_NARRATIVE_DR_ARRAY'
           ,23)
end
GO

--TLR_BRANCH_ID_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_BRANCH_ID_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_BRANCH_ID_ARRAY'
           ,24)
end
GO


--TLR_IR_CrExchangeRate_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_CrExchangeRate_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_CrExchangeRate_Array'
           ,25)
end
GO

--TLR_IR_CrExchangeRate_DP_Arr
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_CrExchangeRate_DP_Arr' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_CrExchangeRate_DP_Arr'
           ,26)
end
GO

--TLR_IR_CrExchangeRate_GL_Arr
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_CrExchangeRate_GL_Arr' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_CrExchangeRate_GL_Arr'
           ,27)
end
GO


--TLR_IR_DrExchangeRate_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_DrExchangeRate_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_DrExchangeRate_Array'
           ,28)
end
GO

--TLR_IR_DrExchangeRate_DP_Arr
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_DrExchangeRate_DP_Arr' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_DrExchangeRate_DP_Arr'
           ,29)
end
GO

--TLR_IR_DrExchangeRate_GL_Arr
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_DrExchangeRate_GL_Arr' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_DrExchangeRate_GL_Arr'
           ,30)
end
GO

--TLR_IR_DrSellRate_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_DrSellRate_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_DrSellRate_Array'
           ,31)
end
GO

--TLR_IR_CrBuyRate_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_CrBuyRate_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_CrBuyRate_Array'
           ,32)
end
GO

--TLR_IR_DrAccountName_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_DrAccountName_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_DrAccountName_Array'
           ,33)
end
GO

--TLR_IR_CrAccountName_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_CrAccountName_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_CrAccountName_Array'
           ,34)
end
GO

--COR_STATUS_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='COR_STATUS_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'COR_STATUS_ARRAY'
           ,35)
end
GO

--TLR_AMOUNT_IN_WORDS_AR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_AMOUNT_IN_WORDS_AR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_AMOUNT_IN_WORDS_AR'
           ,36)
end
GO

--TLR_AMOUNT_IN_WORDS_EN
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_AMOUNT_IN_WORDS_EN' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_AMOUNT_IN_WORDS_EN'
           ,37)
end
GO

--TLR_SELECTION
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_SELECTION' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_SELECTION'
           ,38)
end
GO

--TLR_DrAcct_OverDraft_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_DrAcct_OverDraft_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_DrAcct_OverDraft_Array'
           ,39)
end
GO

--TLR_DR_TARGET_COUNTRY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_DR_TARGET_COUNTRY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_DR_TARGET_COUNTRY'
           ,40)
end
GO

--TLR_CORR_BANK_COUNT_ARR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_CORR_BANK_COUNT_ARR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_CORR_BANK_COUNT_ARR'
           ,41)
end
GO

--TLR_IR_DrSellRateGL_Array
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_DrSellRateGL_Array' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_DrSellRateGL_Array'
           ,42)
end
GO

--TLR_INWARD_HOST_FLAG_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_INWARD_HOST_FLAG_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_INWARD_HOST_FLAG_ARRAY'
           ,43)
end
GO

--TLR_PDC_COR_ID
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PDC_COR_ID' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PDC_COR_ID'
           ,44)
end
GO

--TLR_PDC_COR_COUNTRY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PDC_COR_COUNTRY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PDC_COR_COUNTRY'
           ,45)
end
GO


--TLR_PDC_COR_CITY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PDC_COR_CITY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PDC_COR_CITY'
           ,46)
end
GO

--TLR_PDC_COR_DIRECT_OPT
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PDC_COR_DIRECT_OPT' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PDC_COR_DIRECT_OPT'
           ,47)
end
GO

--TLR_PDC_COR_DIRECT_OPT_DSC
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PDC_COR_DIRECT_OPT_DSC' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PDC_COR_DIRECT_OPT_DSC'
           ,48)
end
GO

--TLR_PDC_DEST_DETAILS
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PDC_DEST_DETAILS' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PDC_DEST_DETAILS'
           ,49)
end
GO

--TLR_LANG_PERFERENCE_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_LANG_PERFERENCE_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_LANG_PERFERENCE_ARRAY'
           ,50)
end
GO

--TLR_CLIENT_SEGMENT_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_CLIENT_SEGMENT_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_CLIENT_SEGMENT_ARRAY'
           ,51)
end
GO

--TLR_TRANSFER_DESCRIPTION
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_TRANSFER_DESCRIPTION' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_TRANSFER_DESCRIPTION'
           ,52)
end
GO

--TLR_PAYMENT_DESCRIPTION
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PAYMENT_DESCRIPTION' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PAYMENT_DESCRIPTION'
           ,53)
end
GO

--ACCNT_LOOKUP_RESULT_FIELD_VALUE
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='ACCNT_LOOKUP_RESULT_FIELD_VALUE' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'ACCNT_LOOKUP_RESULT_FIELD_VALUE'
           ,54)
end
GO

--L1Node
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='L1Node' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'L1Node'
           ,55)
end
GO
--L2Node
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='L2Node' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'L2Node'
           ,56)
end
GO
--L3Node
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='L3Node' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'L3Node'
           ,57)
end
--Amount
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='Amount' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'Amount'
           ,58)
end
--TLR_ID_NUMBER
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_ID_NUMBER' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_ID_NUMBER'
           ,59)
end
--TLR_WITHDARWAL_VOUCHER
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_WITHDARWAL_VOUCHER' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_WITHDARWAL_VOUCHER'
           ,60)
end
GO
--TLR_PURCHASER_NAME
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PURCHASER_NAME' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PURCHASER_NAME'
           ,61)
end
GO
--TLR_DATE_TIME
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_DATE_TIME' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_DATE_TIME'
           ,62)
end
GO

--TLR_PURCHASER_MODE
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PURCHASER_MODE' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PURCHASER_MODE'
           ,63)
end
GO

--DEBITAMT
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='DEBITAMT' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'DEBITAMT'
           ,64)
end
GO

--CREDITAMT
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='CREDITAMT' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'CREDITAMT'
           ,65)
end
GO

--TLR_CHEQUE_VALUE_DATE
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_CHEQUE_VALUE_DATE' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_CHEQUE_VALUE_DATE'
           ,66)
end
GO
--TLR_DEST_BANK_NAME
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_DEST_BANK_NAME' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_DEST_BANK_NAME'
           ,67)
end
GO

--TLR_OTHER_REASON_ARRAY
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_OTHER_REASON_ARRAY' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_OTHER_REASON_ARRAY'
           ,68)
end
GO

--TLR_INTC
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_INTC' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_INTC'
           ,69)
end
GO

--TLR_IR_DrCommission
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_DrCommission' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_DrCommission'
           ,70)
end
GO

--TLR_IR_HasPaidStatus
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IR_HasPaidStatus' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IR_HasPaidStatus'
           ,71)
end
GO


--TLR_IS_GL_2
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IS_GL_2' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IS_GL_2'
           ,72)
end
GO

--TLR_IS_GL_3
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_IS_GL_3' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_IS_GL_3'
           ,73)
end
GO
--TLR_DP_GL_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_DP_GL_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_DP_GL_MULTI_DR_CR'
           ,74)
end
GO
--TLR_DESCRIPTION_MULTI_DR_CR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_DESCRIPTION_MULTI_DR_CR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_DESCRIPTION_MULTI_DR_CR'
           ,75)
end
GO
--TLR_SETTLE_ON_CURRENCY_FLAG
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_SETTLE_ON_CURRENCY_FLAG' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_SETTLE_ON_CURRENCY_FLAG'
           ,76)
end
GO
--TLR_MUL_TRNSFR_BAL_FLAG
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_MUL_TRNSFR_BAL_FLAG' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_MUL_TRNSFR_BAL_FLAG'
           ,77)
end
GO

--TLR_STALE_CHEQUE_OVERRIDE
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_STALE_CHEQUE_OVERRIDE' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_STALE_CHEQUE_OVERRIDE'
           ,78)
end
GO
--TLR_RIM_BRANCH_ARR
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_RIM_BRANCH_ARR' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_RIM_BRANCH_ARR'
           ,79)
end
GO
--TLR_PROFIT_AMT
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_PROFIT_AMT' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_PROFIT_AMT'
           ,80)
end
GO

--TLR_DOWN_PMT
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_DOWN_PMT' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_DOWN_PMT'
           ,81)
end
GO

--TLR_ConsDet_CorresAdrs_ln1
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_ConsDet_CorresAdrs_ln1' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_ConsDet_CorresAdrs_ln1'
           ,82)
end
GO
--TLR_ConsDet_CorresAdrs_ln2
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_ConsDet_CorresAdrs_ln2' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_ConsDet_CorresAdrs_ln2'
           ,83)
end
GO
--TLR_ARBIFT_1842
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_ARBIFT_1842' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_ARBIFT_1842'
           ,84)
end
GO

--TLR_ExpensesStatus_Desc
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_ExpensesStatus_Desc' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_ExpensesStatus_Desc'
           ,85)
end
GO
--TLR_OVERDRAWEN_STATUS
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='TLR_OVERDRAWEN_STATUS' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'TLR_OVERDRAWEN_STATUS'
           ,86)
end
GO
GO
--COR_TRAN_ID
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='COR_TRAN_ID' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'COR_TRAN_ID'
           ,87)
end
GO
--COR_TRAN_NAME
if not EXISTs (select * from PrintTranDocsGridsFields where TranName='MultiTransfer' and GridName='_grdTransfers' and fieldName='COR_TRAN_NAME' )
Begin
INSERT INTO [dbo].[PrintTranDocsGridsFields]
           ([TranName]
           ,[GridName]
           ,[FieldName]
           ,[FieldOrder]
           )
     VALUES
           ('MultiTransfer'
           ,'_grdTransfers'
           ,'COR_TRAN_NAME'
           ,88)
end
GO


--Devolper		:	Abdelrhman Mohamed
--Date			:	[04/02/2021]		
--Reason		:	CR#GFSX14434
--=============================================================
---------------------------------
---- RulesTranDescriptors -------
---------------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrAmount')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrAmount',N'ITSOFT\abdelrhman.kamal',N'ITSOFT\abdelrhman.kamal',1)
End
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[04/02/2021]		
--Reason	:	Issue GFSX14431
--=============================
PRINT 'Start. Script for Issue# GFSX14431 DML Script'
GO
 
-----------------------
-- RulesTranField_ex --
-----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 862 And FieldID Is Null  And FieldIDInPage = '_grd_Messages_Column_CrUpdatedExchangeRate_BuyRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrUpdatedExchangeRate_BuyRate',-1,-1,-1,0,0,'','','','Sep 24 2020  2:43PM',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 And FieldID Is Null  And FieldIDInPage = '_grd_Messages_Column_CrUpdatedExchangeRate_SellRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrUpdatedExchangeRate_SellRate',-1,-1,-1,0,0,'','','','Sep 24 2020  2:43PM',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 And FieldID Is Null  And FieldIDInPage = '_grd_Messages_Column_DrUpdatedExchangeRate_BuyRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrUpdatedExchangeRate_BuyRate',-1,-1,-1,0,0,'','','','Sep 24 2020  2:43PM',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 And FieldID Is Null  And FieldIDInPage = '_grd_Messages_Column_DrUpdatedExchangeRate_SellRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrUpdatedExchangeRate_SellRate',-1,-1,-1,0,0,'','','','Sep 24 2020  2:43PM',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

PRINT 'End... Script for Issue# GFSX14431 DML Script'
GO
--==================================================================================================================================================================
GO
-- =============================================
-- Author:		Ibrahim Harby & Ahmed Atef
-- Create date: 07-Mar-2021
-- Description:	 CR# GFSY00840 Swift Modification 2020
-- =============================================

If Not Exists(select * From RulesDescriptor Where DescriptorID = 1105877)
BEGIN
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	)
 Values (1,	1105877	,'TLR_Apply_Swift_Modification21'	,1	,'Labels',	'Apply 2021 Swift Standard'	,'ITSOFT\ibrahim.harby'	)
END
GO


If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105877 And LCID = 1025)
BEGIN
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator)
 Values (1105877,1025,N'تفعيل المعايير الاساسيه لنظام السويفت 2021','ITSOFT\ibrahim.harby')
END
GO

--BankConfig
IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'Apply2021SwiftStandard')
BEGIN
	EXEC dbo.BANK_CONFIG_INSERT @Name= 'Apply2021SwiftStandard',@Value = '0',@DataType = 'bit',@ShortDescr = 'TLR_Apply_Swift_Modification21',@LongDescr = 'TLR_Apply_Swift_Modification21',@MaxVal = '1',@MinVal='0'
END

GO


-- =============================================
-- Author:		Ibrahim Harby 
-- Create date: 28-Mar-2021
-- Description:	 CR# GFSx14487 -  Swift Modification 2020
-- =============================================

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1100232)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1100232,'TRAN_ACCEPT_UNFUND','This transaction accepts unfunded or today renewed fixed deposit accounts.','This transaction accepts unfunded or today renewed fixed deposit accounts.',4,'',1,'GFSDOMAIN\mohibrahim','Jun 15 2008  2:40PM',1,'Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1805)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,AppID)
 Values (1805,'INVALID_ISO_CODE','Invalid ISO Code.','Invalid ISO Code.',4,1)
End
go


--Programmer : Mostafa Sayed
--Date       : [10/03/2021]
--Reason     : Issue#GFSX14456 - INC000000269374
--==============================================
--RulesParam
If Not Exists(Select * From RulesParam Where ParamName='SkipWorkflowIfDown')
Begin
	DECLARE @paramID1 int
	SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
	Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
	Values (@paramID1,'SkipWorkflowIfDown','Try to check pending tasks in workflow, if down skip it and get data from IBS.','',0,1,0,'','Static','')

	Insert Into RulesParamValue(ParamID,ParamValue)
	values(@paramID1, 'False')
	Insert Into RulesParamValue(ParamID,ParamValue)
	values(@paramID1, 'True')
End
go
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'DisburseToCustomerByAccount' And FieldName = 'SkipWorkflowIfDown' And Param = 'SkipWorkflowIfDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,DataType,Description)
 VALUES ('DisburseToCustomerByAccount','SkipWorkflowIfDown','SkipWorkflowIfDown','false', 'bit','Try to check pending tasks in workflow, if down skip it and get data from IBS.')
END
GO
If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1805 and LanguageLCID = 1025)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID ,DescriptionNumber,DetailText,DisplayText)
 Values (1025,1805,N'كود ISO غير صالح',N'كود ISO غير صالح')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1590 and LanguageLCID = 1025)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID ,DescriptionNumber,DetailText,DisplayText)
 Values (1025,1590,N'رقم السطر إلزامي',N'رقم السطر إلزامي')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1588 and LanguageLCID = 1025)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID ,DescriptionNumber,DetailText,DisplayText)
 Values (1025,1588,N'رقم السطر غير صالح',N'رقم السطر غير صالح')
End
go
-- =============================================
-- Author:		Ibrahim Harby 
-- Create date: 29-March-2021
-- Description:	 CR# GFSY00844 
-- =============================================
If Not Exists(Select * From RulesParam Where ParamName='HideStaffAcctBalance')
Begin
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'HideStaffAcctBalance','specify if the Account Balance Hide or Not for Staff users ','',0,1,0,'','Static','')
End


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'AccountClosure' AND FieldName = 'HideStaffAcctBalance' AND Param = 'HideStaffAcctBalance' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,DataType)
Values( 'AccountClosure' , 'HideStaffAcctBalance' , 'HideStaffAcctBalance' , 'False' , 'nvarchar')
END
GO


--Programmer : Ahmed Atef
--Date       : [04/04/2021]
--Reason     : Issue#GFSX13838 - issue in Arabic descriptor .....
-----------------------------------------------------------------
IF EXISTS(SELECT * FROM RulesLanguages WHERE LanguageLCID = 1025)
BEGIN
	UPDATE RulesLanguages
	SET PhoenixLanguageID=7
	WHERE LanguageLCID = 1025
END
GO

IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID=1100022)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,AccessString,CommandType,GetsRows,DataSource,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	Values(1,1100022,N'GET_PHOENIX_LANGUAGE_CODE',N'dbo.GetPhoenixLanguageCode',N'P',1,N'Globalfs',0,N'',N'',N'Return Phoenix language code for specific LCID',1,N'',N'',0,0,1,NULL,NULL,0,0,0,0)
END
GO

IF EXISTS(SELECT * FROM BankTPIInterface WHERE FieldCode='CRE')
BEGIN
	UPDATE BankTPIInterface
	SET NoOfParameters=27
	WHERE FieldCode='CRE'
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 15132 AND FieldID = 998)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (15132,998,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'PTID',0,-1)
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='PTID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'PTID',N'int',999,0,N'0',N'O')
END
GO

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1590 and LanguageLCID = 1025)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID ,DescriptionNumber,DetailText,DisplayText)
 Values (1025,1590,N'السطر رقم 3 إلزامي بعد 2',N'السطر رقم 3 إلزامي بعد 2')
End
go

If  Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1590 and LanguageLCID = 1025)
Begin
 update RulesLocalErrorDescription
 set DetailText = N'السطر رقم 3 إلزامي بعد 2' , DisplayText = N'السطر رقم 3 إلزامي بعد 2'
 where  DescriptionNumber = 1590 and LanguageLCID = 1025
End
go
--Programmer : Mostafa Helmy
--Date       : [12/02/2021]
--Reason     : CR#GFSY00762 - KFH_ACM17057_KYC_Retrofit
----------------------------------------------------

---------------------------------------
--AddressItem--------------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM AddressItem WHERE Description='PACI No')
BEGIN
	INSERT INTO AddressItem(Description)
	VALUES('PACI No')
END
GO
---------------------------------------
--BankTPIInterface---------------------
---------------------------------------
If Not Exists(Select * From BankTPIInterface Where BankID = 1 And FieldCode = 'SIC')
Begin
 Insert Into BankTPIInterface(BankID,FieldCode,NoOfParameters,RequiredSequence)
 Values (1,'SIC',5,'Y')
End
go
If Not Exists(Select * From BankTPIInterface Where BankID = 1 And FieldCode = 'SOW')
Begin
 Insert Into BankTPIInterface(BankID,FieldCode,NoOfParameters,RequiredSequence)
 Values (1,'SOW',6,'Y')
End
go
IF EXISTS(SELECT * FROM BankTPIInterface WHERE FieldCode='ADD')
BEGIN
	UPDATE BankTPIInterface
	SET NoOfParameters=60
	WHERE FieldCode='ADD'
END
GO

---------------------------------------
--RulesDescriptor----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105448)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES (1,1105448,'TLR_PACI_NUMBER',0,'Labels','PACI No.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105448 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	VALUES(1105448,1025,N'رقم المدنية')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105458)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105458,'TLR_OWNERSHIP_RATIO',1,'Labels','Ownership Ratio')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105458 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105458,1025,N'نسبة الملكية')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105459)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105459,'TLR_SHAREHOLDER_INFO',1,'Labels','Share Holder Info')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105459 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105459,1025,N'معلومات حامل الأسهم')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105460)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105460,'TLR_OWNERSHIP_PERCENT',1,'Labels','Ownership %')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105460 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105460,1025,N'نسبة الملكية')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105461)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105461,'TLR_NO_OF_SHARES',1,'Labels','No. Of Shares')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105461 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105461,1025,N'عدد الأسهم')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105462)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105462,'TLR_TOTAL_NO_OF_SHARES',1,'Labels','Total # Of Shares')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105462 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105462,1025,N'إجمالي عدد الأسهم')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105463)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105463,'TLR_SHARE_AMOUNT',1,'Labels','Share Amount')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105463 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105463,1025,N'قيمة السهم')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105464)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105464,'TLR_AMOUNT_OF_SHARE',1,'Labels','Amount Of Share')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105464 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105464,1025,N'القيمة للسهم')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105465)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105465,'TLR_TOTAL_AMOUNT_OF_SHARE',1,'Labels','Total Amount Of Share')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105465 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105465,1025,N'إجمالي قيمة الأسهم')
END
GO
/**************Added By Nehal**********************/
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105432)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105432,'MULTIPLE_SICCODEs',1,'Labels','Multiple SIC Codes','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105432 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105432,1025,N'اكواد SIC عديده','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105433)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105433,'INCLUDE_CLOSED',1,'Labels','Include Closed','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go


If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105433 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105433,1025,N'اشمل المغلق','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105434)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105434,'KYC_PRIORITY',1,'Labels','Priority','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105434 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105434,1025,N'اولويه','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105435)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105435,'KYC_SIC_CODE',1,'Labels','SIC CODE','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105435 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105435,1025,N'كود SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105436)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105436,'KYC_SIC_CODE_DESCRIPTION',1,'Labels','SIC Code Description','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105436 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105436,1025,N'وصف كود SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists (select * From RulesDescriptor Where DescriptorID = 1105437)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105437,'KYC_STATUS',1,'Labels','Status','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105437 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105437,1025,N'الحاله','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists (select * From RulesDescriptor Where DescriptorID = 1105438)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105438,'KYC_SICCodeAndDescription',1,'Labels','SIC Code & Description','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105438 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105438,1025,N'كود SIC ووصفه','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists (select * From RulesDescriptor Where DescriptorID = 1105439)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105439,'KYC_ADD_SICCode',1,'Labels','Add SIC Code ','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105439 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105439,1025,N'كود SIC ووصفه','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists (select * From RulesDescriptor Where DescriptorID = 1105440)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105440,'KYC_EDIT_SICCode',1,'Labels','Edit SIC Code ','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go
If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105440 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105440,1025,N'تعديل ال SIC كود','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105449)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105449,'LISTED_ON_STOCK',1,'Labels','Listed on stock market','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105449 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105449,1025,N'مدرج فى السوق','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105450)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105450,'Stock_Market',1,'Labels','Stock Market','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go
If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105450 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105450,1025,N'سوق المستودع','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105455)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105455,'KYC_SUBSICCODE',1,'Labels','Sub SIC Code','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105455 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105455,1025,N'كود فرعى SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105453)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105453,'KYC_ACTIVE',1,'Labels','Active','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105453 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105453,1025,N'مفعل','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105454)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105454,'KYC_CLOSED',1,'Labels','Closed','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105454 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105454,1025,N'مغلق','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105466)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105466,'SOURCE_OF_WEALTH',1,'Labels','Source Of Wealth','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go


If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105466 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105466,1025,N'مصدر الثروه','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105467)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105467,'SOURCE_CODE',1,'Labels','Source Code','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105467 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105467,1025,N'رقم المصدر','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105468)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105468,'SOURCE_DESCRIPTION',1,'Labels','Source Description','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105468 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105468,1025,N'وصف المصدر','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go


/*******************************************************************************/
/*************************RulesTranDescriptors**********************************/
/*******************************************************************************/

/**************Added By Nehal**********************/

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'SOURCE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'SOURCE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'SOURCE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'SOURCE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'SOURCE_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'SOURCE_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'SOURCE_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'SOURCE_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'SOURCE_OF_WEALTH')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'SOURCE_OF_WEALTH','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'SOURCE_OF_WEALTH')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'SOURCE_OF_WEALTH','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_ACTIVE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_ACTIVE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_ACTIVE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_ACTIVE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_ACTIVE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_ACTIVE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_ACTIVE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_ACTIVE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_SUBSICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_SUBSICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_SUBSICCODE') 
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_SUBSICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_SUBSICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_SUBSICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_SUBSICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_SUBSICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'Stock_Market')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'Stock_Market','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'Stock_Market') 
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'Stock_Market','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'Stock_Market')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'Stock_Market','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'Stock_Market')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'Stock_Market','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'LISTED_ON_STOCK')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'LISTED_ON_STOCK','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'LISTED_ON_STOCK') 
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'LISTED_ON_STOCK','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'LISTED_ON_STOCK')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'LISTED_ON_STOCK','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'LISTED_ON_STOCK')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'LISTED_ON_STOCK','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_EDIT_SICCode')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_EDIT_SICCode','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_EDIT_SICCode')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_EDIT_SICCode','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_EDIT_SICCode')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_EDIT_SICCode','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_EDIT_SICCode')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_EDIT_SICCode','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_ADD_SICCode')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_ADD_SICCode','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_ADD_SICCode')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_ADD_SICCode','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_ADD_SICCode')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_ADD_SICCode','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_ADD_SICCode')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_ADD_SICCode','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_SICCodeAndDescription')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_SICCodeAndDescription','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_SICCodeAndDescription')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_SICCodeAndDescription','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_SICCodeAndDescription')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_SICCodeAndDescription','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_SICCodeAndDescription')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_SICCodeAndDescription','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'COR_ADD')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'COR_ADD','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'COR_ADD')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'COR_ADD','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'COR_ADD')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'COR_ADD','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'COR_ADD')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'COR_ADD','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
----------------------------------------------

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'COR_EDIT')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'COR_EDIT','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'COR_EDIT')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'COR_EDIT','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'COR_EDIT')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'COR_EDIT','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'COR_EDIT')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'COR_EDIT','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
----------------------------------------------------------------------------

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'COR_CANCEL')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'COR_CANCEL','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'COR_CANCEL')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'COR_CANCEL','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'COR_CANCEL')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'COR_CANCEL','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'COR_CANCEL')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'COR_CANCEL','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_STATUS')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_STATUS','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_STATUS')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_STATUS','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_STATUS')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_STATUS','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_STATUS')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_STATUS','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_SIC_CODE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_SIC_CODE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_SIC_CODE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_SIC_CODE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_SIC_CODE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_SIC_CODE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_SIC_CODE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_SIC_CODE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_SIC_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_SIC_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_SIC_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_SIC_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_SIC_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_SIC_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_SIC_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_SIC_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_PRIORITY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_PRIORITY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_PRIORITY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_PRIORITY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'KYC_PRIORITY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'KYC_PRIORITY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'KYC_PRIORITY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'KYC_PRIORITY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'INCLUDE_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'INCLUDE_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'INCLUDE_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'INCLUDE_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'INCLUDE_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'INCLUDE_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'INCLUDE_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'INCLUDE_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'Down')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'Down','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'Down')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'Down','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'Down')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'Down','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'Down')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'Down','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
----------------
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'Up')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'Up','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'Up')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'Up','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'Up')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'Up','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'Up')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'Up','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'MULTIPLE_SICCODEs')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'MULTIPLE_SICCODEs','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'MULTIPLE_SICCODEs') 
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'MULTIPLE_SICCODEs','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'MULTIPLE_SICCODEs')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'MULTIPLE_SICCODEs','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'MULTIPLE_SICCODEs')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'MULTIPLE_SICCODEs','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---------------------------------------
--RIMToRIMRelationship-----------------
---------------------------------------
--*************************************
---------------------------------------
--RulesTranDescriptors-----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=15132 AND DSC_Name='TLR_SHAREHOLDER_INFO')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(15132,N'TLR_SHAREHOLDER_INFO')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=15132 AND DSC_Name='TLR_OWNERSHIP_RATIO')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(15132,N'TLR_OWNERSHIP_RATIO')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=15132 AND DSC_Name='TLR_OWNERSHIP_PERCENT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(15132,N'TLR_OWNERSHIP_PERCENT')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=15132 AND DSC_Name='TLR_NO_OF_SHARES')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(15132,N'TLR_NO_OF_SHARES')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=15132 AND DSC_Name='TLR_PERCENTAGE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(15132,N'TLR_PERCENTAGE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=15132 AND DSC_Name='TLR_AMOUNT_OF_SHARE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(15132,N'TLR_AMOUNT_OF_SHARE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=15132 AND DSC_Name='TLR_TOTAL_NO_OF_SHARES')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(15132,N'TLR_TOTAL_NO_OF_SHARES')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=15132 AND DSC_Name='TLR_SHARE_AMOUNT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(15132,N'TLR_SHARE_AMOUNT')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=15132 AND DSC_Name='TLR_TOTAL_AMOUNT_OF_SHARE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(15132,N'TLR_TOTAL_AMOUNT_OF_SHARE')
END
GO

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'AMOUNT')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'AMOUNT','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'AMOUNT')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AMOUNT','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'CURRENCY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'CURRENCY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'CURRENCY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'CURRENCY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---------------------------------------
--RulesTranField_ex--------------------
---------------------------------------

---------------------------------------
--RulesTranField-----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 15132 AND FieldID = 2028)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (15132,2028,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'OwnershipPercentage',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 15132 AND FieldID = 2029)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (15132,2029,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'ShareAmount',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 15132 AND FieldID = 2030)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (15132,2030,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'TotalAmountOfShare',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 15132 AND FieldID = 1750)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (15132,1750,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'NoOfShares',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 15132 AND FieldID = 1887)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (15132,1887,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'TotalNoOfShares',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 15132 AND FieldID = 2252)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (15132,2252,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'OwnershipRatio',0,-1)
END
GO

If Not Exists(select * From rulestranfield Where TranID = 565 And FieldID = 219)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (565,219,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'INCLUDE_CLOSED',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 565 And FieldID = 1685)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (565,1685,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICCOE_PRIORITY',0,-1)
End
go



If Not Exists(select * From rulestranfield Where TranID = 565 And FieldID = 1758)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (565,1758,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_DESCRIPTION',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 578 And FieldID = 1758)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,1758,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_DESCRIPTION',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1758)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1758,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_DESCRIPTION',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1758)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1758,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_DESCRIPTION',0,-1)
End
go


If Not Exists(select * From rulestranfield Where TranID = 565 And FieldID = 1689)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (565,1689,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_STATUS',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 565 And FieldID = 2024)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (565,2024,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_STOCK_DETAILS',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 565 And FieldID = 231)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (565,231,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_LISTED_ON_STOCK',0,-1)
End
go




IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 565 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (565,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 565 And FieldID = 589)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (565,589,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumberPopup',0,-1)
END
GO




If Not Exists(select * From rulestranfield Where TranID = 578 And FieldID = 1685)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,1685,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICCOE_PRIORITY',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 578 And FieldID = 1887)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,1887,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCOE',0,-1)
End
go


If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1887)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1887,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCOE',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1887)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1887,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCOE',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 578 And FieldID = 219)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,219,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'INCLUDE_CLOSED',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 219)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,219,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'INCLUDE_CLOSED',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 219)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,219,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'INCLUDE_CLOSED',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 578 And FieldID = 1689)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,1689,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_STATUS',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1689)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1689,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_STATUS',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1689)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1689,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_STATUS',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 578 And FieldID = 2024)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,2024,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_STOCK_DETAILS',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 2024)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,2024,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_STOCK_DETAILS',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 2024)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,2024,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_STOCK_DETAILS',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 578 And FieldID = 231)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,231,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_LISTED_ON_STOCK',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 231)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,231,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_LISTED_ON_STOCK',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 231)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,231,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_LISTED_ON_STOCK',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 966)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,966,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_AddOrUpdateSIC',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 578 And FieldID = 966)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (578,966,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_AddOrUpdateSIC',0,-1)
End
go

If Not Exists(select *  From rulestranfield Where TranID = 564 And FieldID = 958)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,958,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'AddOrUpdateWealth',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 285)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,285,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthIncludeClose',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 285)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,285,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthIncludeClose',0,-1)
End
go
-----currencyID-------TLR_DESIGN_TYPE_ARRAY
If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 275)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,275,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'currencyID',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 276)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,276,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatus',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 276)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,276,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatus',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 950)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,950,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDesc',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 950)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,950,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDesc',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 846)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,846,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'CurrencyDesc',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 846)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,846,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'CurrencyDesc',0,-1)
End
go
/************Start Added By MOstafa Helmy*********************/

If Not Exists(select * From rulestranfield Where TranID = 565 And FieldID = 1750) --Added By Mostafa Helmy --1887 -- 1750
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (565,1750,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCOE',0,-1)
End
go

IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 565 And FieldID = 1615) --Added By Mostafa Helmy
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (565,1615,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICStatusDisplay',0,-1)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 578 And FieldID = 1615) --Added By Mostafa Helmy
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (578,1615,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICStatusDisplay',0,-1)
END
GO

If Not Exists(select *  From rulestranfield Where TranID = 564 And FieldID = 367)--367--1685
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,367,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICCOE_PRIORITY',0,-1)
End
go

If Not Exists(select *From rulestranfield Where TranID = 547 And FieldID = 367)--367--1685
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,367,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICCOE_PRIORITY',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 992) --992 --1545
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,992,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthID',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 992)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,992,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthID',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 949) --949 --275
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,949,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'currencyID',0,-1)
End
go

IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 565 And FieldID = 1788) --Added By Mostafa Helmy
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (565,1788,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICDescDisplay',0,-1)
END
GO
/****************************End Added By Mostafa Helmy*************************************************/






/************************************************************/
/**************RulesTranField_ex****************************/
/**********************************************************/


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'tab_MultipleSICCode'  and TranID = 565  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,0,'Teller    ','tab_MultipleSICCode',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'tab_MultipleSICCode'  and TranID = 578  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,0,'Teller    ','tab_MultipleSICCode',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_chk_IncludeClosed'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,219,'Teller    ','_chk_IncludeClosed',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_SICCodeAdd'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','_btn_SICCodeAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_SICCodeAdd'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','_btn_SICCodeAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_SICCodeEdit'  and TranID = 565)
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','_btn_SICCodeEdit',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_SICCodeEdit'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','_btn_SICCodeEdit',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go
--------


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_Up'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','_btn_Up',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_Up'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','_btn_Up',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_Up'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','_btn_Up',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_Up'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','_btn_Up',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go
--------


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_down'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','_btn_down',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_down'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','_btn_down',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go
--------


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_clear'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','btn_clear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_clear'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','btn_clear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCode'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','_drpSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCode'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','_drpSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

------------------------------------


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCode'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','_drpSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCode'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','_drpSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

------------------------------------


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCodeStatus'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','_drpSICCodeStatus',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go



If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCodeStatus'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','_drpSICCodeStatus',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

----------------------cbo_stockMarket---------chk_ListedOnStock-----
If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'cbo_stockMarket'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','cbo_stockMarket',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'cbo_stockMarket'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','cbo_stockMarket',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go
If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'chk_ListedOnStock'  and TranID = 578 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (578,NULL,'Teller    ','chk_ListedOnStock',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'chk_ListedOnStock'  and TranID = 565 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (565,NULL,'Teller    ','chk_ListedOnStock',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go













---------------------------------------
--OpenPersonalRim----------------------
---------------------------------------
--*************************************
---------------------------------------
--RulesTranField-----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 547 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (547,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 547 And FieldID = 589)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (547,589,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumberPopup',0,-1)
END
GO
---------------------------------------
--RulesTranDescriptors-----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (547,'TLR_PACI_NUMBER')
END
GO

---------------------------------------
--OpenNonPersonalRim-------------------
---------------------------------------
--*************************************
---------------------------------------
--RulesTranField-----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 565 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (565,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 565 And FieldID = 589)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (565,589,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumberPopup',0,-1)
END
GO
---------------------------------------
--RulesTranDescriptors-----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 565 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (565,'TLR_PACI_NUMBER')
END
GO
---------------------------------------
--RulesTranField_ex--------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 565 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (565,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 565 AND FieldIDInPage = 'txt_Popup_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (565,589,'Teller    ','txt_Popup_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
---------------------------------------
--EditPersonalRim----------------------
---------------------------------------
--*************************************
---------------------------------------
--RulesTranField-----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 564 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (564,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 564 And FieldID = 589)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (564,589,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumberPopup',0,-1)
END
GO
---------------------------------------
--RulesTranDescriptors-----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 564 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (564,'TLR_PACI_NUMBER')
END
GO

---------------------------------------
--EditNonPersonalRim-------------------
---------------------------------------
--*************************************
---------------------------------------
--RulesTranField-----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 578 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (578,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 578 And FieldID = 589)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (578,589,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumberPopup',0,-1)
END
GO
---------------------------------------
--RulesTranDescriptors-----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 578 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (578,'TLR_PACI_NUMBER')
END
GO
---------------------------------------
--RulesTranField_ex--------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 578 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (578,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 578 AND FieldIDInPage = 'txt_Popup_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (578,589,'Teller    ','txt_Popup_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
---------------------------------------
--SQLstrings---------------------------
---------------------------------------
If Not Exists(Select * From sqlstrings Where AccessID = 2610)
Begin
 Insert Into sqlstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,2610,'ICSR_CHECK_IS_PARENT_SICCODE','p',1,'Globalfs','dbo.Check_Is_Parent_SIC_Code',0,NULL,NULL,'ITSOFT\rokaia.kadry','ITSOFT\osama.nabil','Jan 21 2018 10:44AM','Check Sic Code has parent or not ',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 17 2016  9:28AM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100013)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	VALUES (1,1100013,'HS_ListAllRelationships','p',1,'GFSOLEDB','dbo.HS_ListAllRelationships',0,NULL,NULL,'Get All Relationships',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr  8 2012  2:29PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100014)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	VALUES (1,1100014,'HS_ListAllReciprocalRelations','p',1,'GFSOLEDB','dbo.HS_ListAllReciprocalRelations',0,NULL,NULL,'Get All Reciprocal Relationships',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr  8 2012  2:29PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100015)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	VALUES (1,1100015,'HS_ListLegalNatureRelations','p',1,'GFSOLEDB','dbo.HS_ListLegalNatureRelations',0,NULL,NULL,'Get All legal nature Relationships',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr  8 2012  2:29PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
END
GO

If Not Exists(Select * From sqlstrings Where AccessID = 1100016)
Begin
 Insert Into sqlstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,1100016,'HS_GETNONPERSONALRIMSICINFO','p',1,'GFSOLEDB','dbo.HS_GETNONPERSONALRIMSICINFO',0,NULL,NULL,'G','ITSOFT\nehal.ramadan','Aug  6 2019  9:31AM','Get non personal rim SIC information',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  6 2019  9:31AM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100017)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	VALUES (1,1100017,'HS_GetRimControlValues','p',1,'GFSOLEDB','dbo.HS_GetRimControlValues',0,NULL,NULL,'Get Rim Control Values from phoenix',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr  8 2012  2:29PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
END
GO

If Not Exists(select * From sqlstrings Where AccessID = 1100019)
Begin
 Insert Into sqlstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,1100019,'HS_GETRIMSOWINFO','p',1,'GFSOLEDB','dbo.HS_GETRIMSOWINFO',0,NULL,NULL,'G','ITSOFT\nehal.ramadan','Aug  6 2019  9:31AM','Get non personal rim SIC information',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  6 2019  9:31AM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go
---------------------------------------
--HostCoreService----------------------
---------------------------------------
--*************************************
---------------------------------------
--ListRimToRimInfo---------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='OwnershipRatio')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'OwnershipRatio','nvarchar',999,0,N'0','O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='NoOfShares')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'NoOfShares','int',999,0,N'0','O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='TotalNoOfShares')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'TotalNoOfShares','int',999,0,N'0','O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='OwnershipPercentage')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'OwnershipPercentage','decimal',999,0,N'0','O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='ShareAmount')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'ShareAmount','decimal',999,0,N'0','O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='TotalAmountOfShare')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'TotalAmountOfShare','decimal',999,0,N'0','O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='RimType')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'RimType','nvarchar',999,0,N'0','O')
END
GO
---------------------------------------
--CustomerProfile----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='PEP')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PEP','nvarchar',0,0,N'0','O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='LegalNatID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'LegalNatID','int',0,0,N'0','O')
END
GO
---------------------------------------
--CustomerLocate-----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate') AND FieldName='PEP')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PEP','nvarchar',999,0,N'0','O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate') AND FieldName='LegalNatureID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'LegalNatureID','int',999,0,N'0','O')
END
GO
---------------------------------------
--GetPersonalRimInfo-------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetPersonalRimInfo') AND FieldName='PACI_NO')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetPersonalRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PACI_NO','nvarchar',0,0,N'0','O')
END
GO
---------------------------------------
--ListCustomerAddresses----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListCustomerAddresses') AND FieldName='PACI_NO')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListCustomerAddresses'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PACI_NO','nvarchar',999,0,N'0','O')
END 
GO
---------------------------------------
--GetNonPersonalRimInfo----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetNonPersonalRimInfo') AND FieldName='PACI_NO')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetNonPersonalRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PACI_NO','nvarchar',0,0,N'0','O')
END 
GO
---------------------------------------
--ListAllRelationships-----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'ListAllRelationships')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
	VALUES (@serviceID,'ListAllRelationships','RelationshipsInquiry','List all relationships in phoenix')
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,1,'RelationshipID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 2)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,2,'Relationship','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 3)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,3,'ConcentRelation','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 4)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,4,'OwnershipRatio','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 5)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,5,'PloticalExposed','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 6)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,6,'AllowLegalNature','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 7)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,7,'AllowReciprocal','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 8)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,8,'ApplyToRIM','nvarchar',999,0,N'0','O')
	END
END
GO
---------------------------------------
--ListAllReciprocalRelationships-------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'ListAllReciprocalRelationships')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
	VALUES (@serviceID,'ListAllReciprocalRelationships','RelationshipsInquiry','List all reciprocal relationships in phoenix')
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,1,'ReciprocalRelationID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 2)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,2,'RelationshipID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 3)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,3,'Relationship','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 4)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,4,'ConcentRelation','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 5)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,5,'OwnershipRatio','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 6)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,6,'PloticalExposed','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 7)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,7,'AllowLegalNature','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 8)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,8,'AllowReciprocal','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 9)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,9,'ApplyToRIM','nvarchar',999,0,N'0','O')
	END
END
GO
---------------------------------------
--ListLegalNatureRelationships---------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'ListLegalNatureRelationships')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
	VALUES (@serviceID,'ListLegalNatureRelationships','RelationshipsInquiry','List all legal nature relationships in phoenix')
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,1,'LegalNatureID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 2)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,2,'RelationshipID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 3)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,3,'Relationship','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 4)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,4,'ConcentRelation','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 5)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,5,'OwnershipRatio','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 6)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,6,'PloticalExposed','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 7)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,7,'AllowLegalNature','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 8)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,8,'AllowReciprocal','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 9)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,9,'ApplyToRIM','nvarchar',999,0,N'0','O')
	END
END
GO
------------------------------------------------------

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') AND FieldName='LangID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'LangID',N'int',0,0,N'-1',N'I')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') AND FieldName='LangID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'LangID',N'int',0,0,N'-1',N'I')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimRelationship') AND FieldName='LangID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListRimRelationship'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'LangID',N'int',0,0,N'-1',N'I')
END
GO
---------------------------------------
--GetRIMControlValues------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'GetRIMControlValues')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
	VALUES (@serviceID,'GetRIMControlValues','MiscellaneousInquiry','Get RIM control values from phoenix')
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetRIMControlValues') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,1,'AllowMultipleRelation','nvarchar',0,0,N'0','O')
	END
END
GO
----------------------------------------------------------
------------------ListSICInfo-----------------------------
----------------------------------------------------------
declare @sID int
set @sID = (select MAX(ServiceId)+1 from HostCoreService )
If Not Exists(Select * From HostCoreService Where ServiceName = 'ListSICInfo')
Begin
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription,Developer,Created,Updator,LastChanged)
 Values (@sID,'ListSICInfo','CustomerInquiry','To list SIC Information','ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM',N'ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM')
End
else
begin
set @sID = (select ServiceId from HostCoreService Where ServiceName = 'ListSICInfo')
end

if @sID is not null
Begin

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='RimNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,1,'RimNo','int',0,0,'','I')
End
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Priority' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,2,'SICCODE_Priority','int',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Description' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,3,'SICCODE_Description','nvarchar',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Code' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,4,'SICCODE_Code','int',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Status' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,5,'SICCODE_Status','nvarchar',999,0,'','O')
End
End
go
----------------------------------------------------------
------------------GetNonPersonalRimInfo-----------------------------
----------------------------------------------------------
declare @sID int
set @sID = (select ServiceId from HostCoreService Where ServiceName = 'GetNonPersonalRimInfo')
if @sID is not null
Begin

declare @maxID int
set @maxID = (select max(FieldId)+1 from HostCoreServiceFields Where ServiceId = @sID)
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='ListStockMarket')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'ListStockMarket','char',0,0,'','O')
End
set @maxID = (select max(FieldId)+1 from HostCoreServiceFields Where ServiceId = @sID)
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='Stock_exch_id' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'Stock_exch_id','int',0,0,'','O')
End

End
go
---------------------------------------------------------------------
------------------ListSOWInfo------------------------------
---------------------------------------------------------------------
declare @sID int
set @sID = (select MAX(ServiceId)+1 from HostCoreService )
If Not Exists(Select * From HostCoreService Where ServiceName = 'ListSOWInfo')
Begin
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription,Developer,Created,Updator,LastChanged)
 Values (@sID,'ListSOWInfo','CustomerInquiry','To list SOW Information','ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM',N'ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM')
End
else
begin
set @sID = (select ServiceId from HostCoreService Where ServiceName = 'ListSOWInfo')
end

if @sID is not null
Begin

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='RimNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,1,'RimNo','int',0,0,'','I')
End
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='WealthID' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,2,'WealthID','int',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='CurrencyID' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,3,'CurrencyID','nvarchar',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='Amount' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,4,'Amount','decimal',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='WealthStatus' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,5,'WealthStatus','nvarchar',999,0,'','O')
End
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='Currency' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,6,'Currency','nvarchar',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='WealtfDesc' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,7,'WealtfDesc','nvarchar',999,0,'','O')
End
End
go
---------------------------------------------------------------------
------------------ListRimRelationship--------------------------------
---------------------------------------------------------------------
declare @sID int
set @sID = (select ServiceId from HostCoreService where ServiceName = 'ListRimRelationship' )
If @sID is not null
Begin
declare @maxID int
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='RimType')
Begin
set @maxID = (select max(FieldId)+1 from HostCoreServiceFields where ServiceId = @sID)
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'RimType','char',0,0,'','I')
 End
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='PEP')
Begin
set @maxID = (select max(FieldId)+1 from HostCoreServiceFields where ServiceId = @sID)
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'PEP','char',0,0,'','I')
 End
End
Go


/*******************picklists*********************/
/*************************************************/
/*****Added By Nehal********/

If Not Exists(Select * From picklists Where PickListID = 548)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,548,'DPHX_STOCK_EXCHANGE','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  07 2019  6:23PM','Aug 7 2019  2:14PM',N'ITSOFT\nehal.ramadan',N'G',1)
End
go


If Not Exists(Select * From picklists Where PickListID = 549)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,549,'DPHX_WEALTH_SOURCE','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  07 2019  6:23PM','Aug 7 2019  2:14PM',N'ITSOFT\nehal.ramadan',N'G',1)
End
go

If Not Exists(Select * From picklists Where PickListID = 550)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,550,'KYC_Status','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  07 2019  6:23PM','Aug 7 2019  2:14PM',N'ITSOFT\nehal.ramadan',N'G',1)
End
go

If Not Exists(select * From PickList_Entries Where PickListID = 550 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (550,1,1,'KYC_ACTIVE','Active','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 18 2019 1:37PM','Jan  4 2001  9:44AM',N'G',N'G',1,NULL)
End
go
If Not Exists(select * From PickList_Entries Where PickListID = 550 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (550,1,2,'KYC_CLOSED','Closed','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 18 2019  1:37PM','Jan  4 2001  9:44AM',N'G',N'G',1,NULL)
End
go
-----------------------------------RulesErrorDescription--------------------------
----------------------------------------------------------------------------------
----------------------------------------------------------------------------------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1783)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1783,'WEALTH_ADDED','Wealth has been already Added!','Wealth has been already Added!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1783)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1783,N'هذه الثروه مضاف بالفعل',N'هذه الثروه مضاف بالفعل','','G','Aug 21 2019  4:13PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'WEALTH_ADDED')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','WEALTH_ADDED','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'WEALTH_ADDED')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','WEALTH_ADDED','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go


-----------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1779)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1779,'SICCODE_ADEDD','SICCOde has been already Added!','SICCOde has been already Added!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1779)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1779,N'هذا مضاف بالفعل siccode',N'هذا مضاف بالفعل siccode','','G','Aug 21 2019  4:13PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenNonPersonalRim' And Error_Name = 'SICCODE_ADEDD')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenNonPersonalRim','SICCODE_ADEDD','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'SICCODE_ADEDD')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','SICCODE_ADEDD','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'SICCODE_ADEDD')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','SICCODE_ADEDD','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editNonPersonalRim' And Error_Name = 'SICCODE_ADEDD')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editNonPersonalRim','SICCODE_ADEDD','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go
--------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1780)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1780,'SICCODE_PARENT_ADDITION','Please Select Parent SIC Code in Bank Tab First!','Please Select Parent SIC Code in Bank Tab First!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1780)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1780,N'من فضلك اختر SIC كود فى البنك تاب',N'من فضلك اختر SIC كود فى البنك تاب','','G','Aug 21 2019  4:13PM')
End
go



If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenNonPersonalRim' And Error_Name = 'SICCODE_PARENT_ADDITION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenNonPersonalRim','SICCODE_PARENT_ADDITION','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'SICCODE_PARENT_ADDITION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','SICCODE_PARENT_ADDITION','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'SICCODE_PARENT_ADDITION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','SICCODE_PARENT_ADDITION','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editNonPersonalRim' And Error_Name = 'SICCODE_PARENT_ADDITION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editNonPersonalRim','SICCODE_PARENT_ADDITION','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go
--------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1781)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1781,'SICCODE_MOVE','This SICCode can not be moved!','This SICCode can not be moved!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1781)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1781,N'لا يمكن تحريك هذا الصف',N'من فضلك اختر SIC كود فى البنك تاب','','G','Aug 21 2019  4:13PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenNonPersonalRim' And Error_Name = 'SICCODE_MOVE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenNonPersonalRim','SICCODE_MOVE','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'SICCODE_MOVE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','SICCODE_MOVE','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'SICCODE_MOVE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','SICCODE_MOVE','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editNonPersonalRim' And Error_Name = 'SICCODE_MOVE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editNonPersonalRim','SICCODE_MOVE','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

/***GFSX13835****/

If  Exists(Select * From RulesDescriptor Where DescriptorID = 1105093)
Begin
 update RulesDescriptor set Descriptor='PEP Closed Association '  Where DescriptorID = 1105093
 End
go

If  Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105093 And LCID = 1025)
Begin
 update RulesDescriptorlOCAL set LocalDescription= N'PEP  مُغلق '  Where DescriptorID = 1105093 And LCID = 1025
 
End
go

If  Exists(Select * From RulesDescriptor Where DescriptorID = 1105088)
Begin
 update RulesDescriptor set Descriptor='PEP Closed Association Category'  Where DescriptorID = 1105088
 End
go

If  Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105088 And LCID = 1025)
Begin
 update RulesDescriptorlOCAL set LocalDescription= N'PEP  مًغلق فئة'  Where DescriptorID = 1105088 And LCID = 1025 
End
go
/*****GFSX13832****************/

if exists ( select * from RulesErrorDescription where name='SICCODE_PARENT_ADDITION')
begin
 update RulesErrorDescription set DetailText ='Please Select  SIC Code in Bank Tab First!' , DisplayText= 'Please Select SIC Code in Bank Tab First!'  where name='SICCODE_PARENT_ADDITION'
end
go
/*****GFSX13840****************/
declare @sID int
Select  @sID=ServiceId From HostCoreService Where ServiceName = 'ExecAutomaticDownloadSIC'
If Exists(Select  @sID)
Begin
 
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldId=2 )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,2,'LCID','int',0,0,'','I')
End
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldId=3)
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,3,'description','nvarchar',999,0,'','O')
End
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldId=4 )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,4,'DescriptorName','nvarchar',999,0,'','O')
End
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldId=5 )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,5,'TempValue','nvarchar',999,0,'','O')
End

End
go

if exists (select * from ruleslocalerrordescription where DescriptionNumber=1781 and LanguageLCID=1025)
begin
 update ruleslocalerrordescription set  displaytext=N'لايمكن تغيير هذا الصنف' where DescriptionNumber=1781 and LanguageLCID=1025
end
go

if exists (select * from ruleserrordescription where name = 'SICCODE_ADEDD' )
begin
 update ruleserrordescription set  displaytext='SIC Code has been already Added!'  where name = 'SICCODE_ADEDD'
end
go




if exists (select * from rulesdescriptor where name = 'TLR_SIC_CODE' )
begin
 update rulesdescriptor set  Descriptor='SIC Code'  where name = 'TLR_SIC_CODE'
end
go




If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1104574 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1104574,1025,N'كود متفرع  SIC ','G','Aug  6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go
/************GFSX13813***************************/
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105472)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105472,'AddEdit_SICCODE',1,'Labels','Add / Edit SIC Code','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105472 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105472,1025,N'أضف \ عدل كود SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'AddEdit_SICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'AddEdit_SICCODE') 
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'AddEdit_SICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'AddEdit_SICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---------------------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105473)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105473,'AddEdit_WeathSource',1,'Labels','Add/Edit Weath Source','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go


If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105473 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105473,1025,N' مصدر الثروة أضف \ عدل ','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'AddEdit_WeathSource')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'AddEdit_WeathSource','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'AddEdit_WeathSource')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AddEdit_WeathSource','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--Developer  : Ahmed Atef
--Date       : 24/03/2021
--Reason     : CR#GFSY00762 - KFH_ACM17057_KYC_Retrofit
-------------------------------------------------------

If Not Exists(Select * From picklists Where PickListID = 548)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,548,'DPHX_STOCK_EXCHANGE','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  07 2019  6:23PM','Aug 7 2019  2:14PM',N'ITSOFT\ahmed.atef',N'G',1)
End
go


If Not Exists(Select * From picklists Where PickListID = 549)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,549,'DPHX_WEALTH_SOURCE','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  07 2019  6:23PM','Aug 7 2019  2:14PM',N'ITSOFT\ahmed.atef',N'G',1)
End
go

IF NOT EXISTS(SELECT * FROM AddressItem WHERE Description='PACI No')
BEGIN
	INSERT INTO AddressItem(Description)
	VALUES('PACI No')
END
GO

---------------------------------------
--RulesDescriptor----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105448)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES (1,1105448,'TLR_PACI_NUMBER',0,'Labels','PACI No.')
END
GO
---------------------------------------
--RulesTranField-----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 547 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (547,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 565 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (565,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 564 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (564,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 578 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (578,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 15132 AND FieldID = 998)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (15132,998,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'PTID',0,-1)
END
GO
---------------------------------------
--RulesTranDescriptors-----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (547,'TLR_PACI_NUMBER')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 565 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (565,'TLR_PACI_NUMBER')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 564 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (564,'TLR_PACI_NUMBER')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 578 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (578,'TLR_PACI_NUMBER')
END
GO
---------------------------------------
--RulesTranField_ex--------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 547 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (547,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 565 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (565,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 564 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (564,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\ahmed.atef',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 578 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (578,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\ahmed.atef',1)
END
GO

---------------------------------------
--SQLstrings---------------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100013)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	VALUES (1,1100013,'HS_ListAllRelationships','p',1,'GFSOLEDB','dbo.HS_ListAllRelationships',0,NULL,NULL,'Get All Relationships',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr  8 2012  2:29PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100014)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	VALUES (1,1100014,'HS_ListAllReciprocalRelations','p',1,'GFSOLEDB','dbo.HS_ListAllReciprocalRelations',0,NULL,NULL,'Get All Reciprocal Relationships',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr  8 2012  2:29PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100015)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	VALUES (1,1100015,'HS_ListLegalNatureRelations','p',1,'GFSOLEDB','dbo.HS_ListLegalNatureRelations',0,NULL,NULL,'Get All legal nature Relationships',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr  8 2012  2:29PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100017)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	VALUES (1,1100017,'HS_GetRimControlValues','p',1,'GFSOLEDB','dbo.HS_GetRimControlValues',0,NULL,NULL,'Get Rim Control Values from phoenix',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr  8 2012  2:29PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
END
GO
---------------------------------------
--HostCoreService----------------------
---------------------------------------
--*************************************
---------------------------------------
--ListRimToRimInfo---------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='OwnershipRatio')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'OwnershipRatio','nvarchar',999,0,N'0','O')
END
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo') AND FieldName='PTID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='ListRimToRimInfo'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'PTID',N'int',999,0,N'0',N'O')
END
GO
---------------------------------------
--CustomerLocate-----------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate') AND FieldName='PEP')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PEP','nvarchar',999,0,N'0','O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate') AND FieldName='LegalNatureID')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerLocate'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'LegalNatureID','int',999,0,N'0','O')
END
GO
---------------------------------------
--GetPersonalRimInfo-------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetPersonalRimInfo') AND FieldName='PACI_NO')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetPersonalRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PACI_NO','nvarchar',0,0,N'0','O')
END
GO
---------------------------------------
--ListCustomerAddresses----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListCustomerAddresses') AND FieldName='PACI_NO')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='ListCustomerAddresses'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PACI_NO','nvarchar',999,0,N'0','O')
END 
GO
---------------------------------------
--GetNonPersonalRimInfo----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceID=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetNonPersonalRimInfo') AND FieldName='PACI_NO')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID=HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='GetNonPersonalRimInfo'
	DECLARE @maxFieldID INT
	SET @maxFieldID  = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	VALUES(@serviceID,@maxFieldID,'PACI_NO','nvarchar',0,0,N'0','O')
END 
GO
---------------------------------------
--ListAllRelationships-----------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'ListAllRelationships')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
	VALUES (@serviceID,'ListAllRelationships','RelationshipsInquiry','List all relationships in phoenix')
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,1,'RelationshipID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 2)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,2,'Relationship','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 3)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,3,'ConcentRelation','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 4)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,4,'OwnershipRatio','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 5)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,5,'PloticalExposed','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 6)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,6,'AllowLegalNature','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 7)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,7,'AllowReciprocal','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllRelationships') And FieldId = 8)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,8,'ApplyToRIM','nvarchar',999,0,N'0','O')
	END
END
GO
---------------------------------------
--ListAllReciprocalRelationships-------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'ListAllReciprocalRelationships')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
	VALUES (@serviceID,'ListAllReciprocalRelationships','RelationshipsInquiry','List all reciprocal relationships in phoenix')
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,1,'ReciprocalRelationID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 2)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,2,'RelationshipID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 3)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,3,'Relationship','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 4)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,4,'ConcentRelation','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 5)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,5,'OwnershipRatio','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 6)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,6,'PloticalExposed','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 7)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,7,'AllowLegalNature','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 8)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,8,'AllowReciprocal','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListAllReciprocalRelationships') And FieldId = 9)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,9,'ApplyToRIM','nvarchar',999,0,N'0','O')
	END
END
GO
---------------------------------------
--ListLegalNatureRelationships---------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'ListLegalNatureRelationships')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService

	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
	VALUES (@serviceID,'ListLegalNatureRelationships','RelationshipsInquiry','List all legal nature relationships in phoenix')
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,1,'LegalNatureID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 2)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,2,'RelationshipID','int',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 3)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,3,'Relationship','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 4)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,4,'ConcentRelation','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 5)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,5,'OwnershipRatio','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 6)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,6,'PloticalExposed','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 7)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,7,'AllowLegalNature','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 8)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,8,'AllowReciprocal','nvarchar',999,0,N'0','O')
	END
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListLegalNatureRelationships') And FieldId = 9)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,9,'ApplyToRIM','nvarchar',999,0,N'0','O')
	END
END
GO
---------------------------------------
--GetRIMControlValues------------------
---------------------------------------
IF NOT EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'GetRIMControlValues')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = MAX(ServiceId) +1 FROM HostCoreService
	
	INSERT INTO HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
	VALUES (@serviceID,'GetRIMControlValues','MiscellaneousInquiry','Get RIM control values from phoenix')
	
	IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetRIMControlValues') And FieldId = 1)
	BEGIN
		INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		VALUES (@serviceID,1,'AllowMultipleRelation','nvarchar',0,0,N'0','O')
	END
END
GO
--Devolper	 :	Aya Tarek
--Date       :	[14/2/2021]		
--Reason     :	CR#GFSY00762 KFH ACM17057 KYC_Part1 Requirements_Retrofit
------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
----------------------RulesDescriptor------------------------------------------------------
-------------------------------------------------------------------------------------------

--------------------------OpenPersonal and EditPersonal ---------------------------
-------------------------------------wealth Tab --------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105473)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105473,'AddEdit_WeathSource',1,'Labels','Add/Edit Weath Source','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go


If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105473 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105473,1025,N' مصدر الثروه اضف \ عدل ','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'AddEdit_WeathSource')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AddEdit_WeathSource','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'AddEdit_WeathSource')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'AddEdit_WeathSource','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--SOURCE_OF_WEALTH

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105466)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105466,'SOURCE_OF_WEALTH',1,'Labels','Source Of Wealth',N'ITSOFT\aya.tarek','feb  14 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','feb  14 2021 6:13PM',N'ITSOFT\aya.tarek')
End
go


If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105466 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105466,1025,N'مصدر الثروه',N'ITSOFT\aya.tarek','feb  14 2021  1:32PM',N'ITSOFT\aya.tarek')
End
go


If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'SOURCE_OF_WEALTH')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'SOURCE_OF_WEALTH','feb  14 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb  14 2021 1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'SOURCE_OF_WEALTH')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'SOURCE_OF_WEALTH','feb  14 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb  14 2021 1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists (select * From RulesDescriptor Where DescriptorID = 1105437)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105437,'KYC_STATUS',1,'Labels','Status','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105437 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105437,1025,N'الحاله','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_STATUS')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_STATUS','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'COR_CANCEL')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'COR_CANCEL','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_STATUS')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_STATUS','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'COR_CANCEL')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'COR_CANCEL','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105453)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105453,'KYC_ACTIVE',1,'Labels','Active','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105453 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105453,1025,N'مفعل','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_ACTIVE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_ACTIVE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_ACTIVE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_ACTIVE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105454)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105454,'KYC_CLOSED',1,'Labels','Closed','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105454 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105454,1025,N'مغلق','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--------------------------------------sic cod tab------------------------------------------------------------------

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105472)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105472,'AddEdit_SICCODE',1,'Labels','Add / Edit SIC Code','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105472 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105472,1025,N'اضف \ عدل كود SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'AddEdit_SICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'AddEdit_SICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'AddEdit_SICCODE') 
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'AddEdit_SICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105432)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105432,'MULTIPLE_SICCODEs',1,'Labels','Multiple SIC Codes','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105432 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105432,1025,N'اكواد SIC عديده','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'MULTIPLE_SICCODEs')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'MULTIPLE_SICCODEs','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'UPROUND')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'UPROUND','feb 15 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb 15 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'DOWNROUND')--DOWNROUND
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'DOWNROUND','feb 15 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb 15 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'MULTIPLE_SICCODEs')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'MULTIPLE_SICCODEs','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'UPROUND')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'UPROUND','feb 15 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb 15 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'DOWNROUND')--DOWNROUND
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'DOWNROUND','feb 15 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb 15 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105434)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105434,'KYC_PRIORITY',1,'Labels','Priority','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105434 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105434,1025,N'اولويه','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_PRIORITY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_PRIORITY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_PRIORITY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_PRIORITY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105435)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105435,'KYC_SIC_CODE',1,'Labels','SIC CODE','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105435 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105435,1025,N'كود SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_SIC_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_SIC_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_SIC_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_SIC_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

----------------------------------

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105436)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105436,'KYC_SIC_CODE_DESCRIPTION',1,'Labels','SIC Code Description','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105436 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105436,1025,N'وصف كود SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go


If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_SIC_CODE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_SIC_CODE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_SIC_CODE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_SIC_CODE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
------------------PACI_NO-------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105448)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES (1,1105448,'TLR_PACI_NUMBER',0,'Labels','PACI No.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105448 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	VALUES(1105448,1025,N'رقم المدنية')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (547,'TLR_PACI_NUMBER')
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 564 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (564,'TLR_PACI_NUMBER')
END
GO
---------Update siccode and subsiccode Descriptor-------------
If  Exists(select * from rulesdescriptor where Name='TLR_SUB_SIC_CODE')
Begin
update rulesdescriptor set Descriptor='Child SIC Code' where  Name='TLR_SUB_SIC_CODE'
end
go

If  Exists(select * from rulesdescriptor where Name='TLR_SIC_CODE')
Begin
update rulesdescriptor set Descriptor='Parent SIC Code' where  Name='TLR_SIC_CODE'
end
go

-------------------------------------------------------------------------
------------------------picklists----------------------------------------
------------------------------------------------------------------------
If Not Exists(Select * From PickLists Where PickListID = 550)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,550,'KYC_Status','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  07 2019  6:23PM','Aug 7 2019  2:14PM',N'ITSOFT\nehal.ramadan',N'G',1)
End
go


If Not Exists(select * From PickList_Entries Where PickListID = 550 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (550,1,1,'KYC_ACTIVE','Active','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 18 2019 1:37PM','Jan  4 2001  9:44AM',N'G',N'G',1,NULL)
End
go
If Not Exists(select * From PickList_Entries Where PickListID = 550 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (550,1,2,'KYC_CLOSED','Closed','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 18 2019  1:37PM','Jan  4 2001  9:44AM',N'G',N'G',1,NULL)
End
go
-------

--------------------------------------------------------------------------
--------------------Rulestranfield--------------------------------------------------
------------------------------------------------------------------------------------

------------------OpenPersonal & EditPersonal--------------------------------------------------------------
---------------------------------------------wealth source tab----------------------------------------------
--wealthID in gridview 
-----WealthID-------TLR_IR_DrAccountName_DP_Arr

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1545)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1545,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthID',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1545)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1545,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthID',0,-1)
End
go
-----WealthDescription-------TLR_HOST_RESPONSE_ARRAY
If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 950)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,950,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDesc',0,-1)
 End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 950)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,950,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDesc',0,-1)
 End
go
-----WealthAmount-------
If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 2039)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,2039,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthAmount',0,-1)
 End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 2039)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,2039,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthAmount',0,-1)
 End
go
-----WealthDescDisplay -----TLR_PDC_ISSUE_BRANCH_NAME
If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 1754)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1754,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDescDisplay',0,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1754)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1754,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDescDisplay',0,-1)
End
go
-----currencyID-------TLR_HOST_TRAN_STATUS_ARRAY

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 949)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,949,1,0,0,NULL,N'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'currencyID',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 275)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,275,1,0,0,NULL,N'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'currencyID',0,-1)
End
go
----

-----CurrencyDescription-------TLR_CORR_BANK_COUNT_ARR

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 846)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,846,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'CurrencyDesc',0,-1)
End
go
----
If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 846)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,846,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'CurrencyDesc',0,-1)
End
go

-----WealthStatusDisplay-------TLR_CLINR_BRNCH_NAME_ARR

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1612)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1612,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatusDisplay',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1612)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1612,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatusDisplay',0,-1)
End
go
----
-----WealthStatus-------TLR_NARRATIVE_FUNDS_ARRAY

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 276)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,276,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatus',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 276)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,276,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatus',0,-1)
End
go
-----------------------------------------------------sic code tab----------------------------------------------------
----SICCOE_PRIORITY ----TLR_USE_SIMPLE_CHARGES_ARR
If Not Exists(select *  From rulestranfield Where TranID = 564 And FieldID = 367)--367--1685
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,367,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICCOE_PRIORITY',0,-1)
End
go
If Not Exists(select *  From rulestranfield Where TranID = 547 And FieldID = 367)--367--1685
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,367,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICCOE_PRIORITY',0,-1)
End
go
----KYC_SICCOE ---TLR_BILL_ID_NO_ARRAY
If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1887) 
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1887,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCOE',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1887) 
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1887,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCOE',0,-1)
End
go
--KYC_SICCODE_DESCRIPTION----TLR_PDC_HOST_TRAN_RESPONSE
If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1758)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1758,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_DESCRIPTION',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1758)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1758,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_DESCRIPTION',0,-1)
End
go
---KYC_SICCODE_STATUS----TLR_PDC_DEST_BK_COUNTRY
If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1689)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1689,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_STATUS',0,-1)
End
go
If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1689)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1689,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_STATUS',0,-1)
End
go
--SICDescDisplay -- TLR_INVOICE_NO_ARR
If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 1788)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1788,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICDescDisplay',0,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1788)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1788,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICDescDisplay',0,-1)
End
go
--SICStatusDisplay-------------TLR_BRANCH_NAME_ARRAY
If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1615)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1615,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICStatusDisplay',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1615)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1615,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICStatusDisplay',0,-1)
End
go
----------------------------PAci_NO-------------------
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 547 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (547,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 547 And FieldID = 589)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (547,589,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumberPopup',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 564 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (564,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 564 And FieldID = 589)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (564,589,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumberPopup',0,-1)
END
GO

------------------------------------------------------------------------------------------------
-------------------------------Rulestranfield_ex------------------------------------------------
------------------------------------------------------------------------------------------------

-----------------------------OpenPersonal & EditPersonal--------------------------------------
----------------------------------------wealt source Tab--------------------------------------
If Not Exists(select * From rulestranfield_ex Where FieldIDInPage like 'tab_SourceOfWealth'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','tab_SourceOfWealth',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'grd_SourceOfWealth'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','grd_SourceOfWealth',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthAdd'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','btn_WealthAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthEdit'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','btn_WealthEdit',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthClear'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','btn_WealthClear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'txt_Amount'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','txt_Amount',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Status'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','_cbo_Wealth_Status',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Source'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','_cbo_Wealth_Source',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Currency'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','_cbo_Wealth_Currency',-1,-1,-1,0,0,'','','','Jan 29 2019 3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(select * From rulestranfield_ex Where FieldIDInPage like 'tab_SourceOfWealth'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','tab_SourceOfWealth',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'grd_SourceOfWealth'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','grd_SourceOfWealth',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthAdd'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','btn_WealthAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthEdit'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','btn_WealthEdit',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthClear'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','btn_WealthClear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'txt_Amount'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','txt_Amount',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Status'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','_cbo_Wealth_Status',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Source'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','_cbo_Wealth_Source',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Currency'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','_cbo_Wealth_Currency',-1,-1,-1,0,0,'','','','Jan 29 2019 3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

------------------------------sic tab-----------------------------------------
If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'tab_MultipleSICCode'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller ','tab_MultipleSICCode',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_Grd_Multiple_SIC_Codes'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller ','_Grd_Multiple_SIC_Codes',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_SICCodeAdd'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_btn_SICCodeAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_clear'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','btn_clear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_down'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_btn_down',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_Up'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_btn_Up',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCode'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_drpSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCodeStatus'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_drpSICCodeStatus',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSubSICCode'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,1617,'Teller    ','_drpSubSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\aya.tarek',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'tab_MultipleSICCode'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller ','tab_MultipleSICCode',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_Grd_Multiple_SIC_Codes'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller ','_Grd_Multiple_SIC_Codes',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_SICCodeAdd'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_btn_SICCodeAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_clear'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','btn_clear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_down'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_btn_down',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_Up'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_btn_Up',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCode'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_drpSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCodeStatus'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_drpSICCodeStatus',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSubSICCode'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,1617,'Teller    ','_drpSubSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\aya.tarek',1)
End
go
-----------------------------PACI_NO--------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 547 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (547,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 547 AND FieldIDInPage = 'txt_Popup_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (547,589,'Teller    ','txt_Popup_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 564 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (564,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 564 AND FieldIDInPage = 'txt_Popup_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (564,589,'Teller    ','txt_Popup_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------RulesErrorDescription------------------------------------------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1780)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1780,'SICCODE_PARENT_ADDITION','Please Select Parent SIC Code in Bank Tab First!','Please Select Parent SIC Code in Bank Tab First!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1780)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1780,N'من فضلك اختر SIC كود فى البنك تاب',N'من فضلك اختر SIC كود فى البنك تاب','','G','Aug 21 2019  4:13PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'SICCODE_PARENT_ADDITION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','SICCODE_PARENT_ADDITION','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'SICCODE_PARENT_ADDITION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','SICCODE_PARENT_ADDITION','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1783)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1783,'WEALTH_ADDED','Wealth has been already Added!','Wealth has been already Added!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1783)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1783,N'هذه الثروه مضاف بالفعل',N'هذه الثروه مضاف بالفعل','','G','Aug 21 2019  4:13PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'WEALTH_ADDED')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','WEALTH_ADDED','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'WEALTH_ADDED')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','WEALTH_ADDED','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1779)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1779,'SICCODE_ADEDD','SICCOde has been already Added!','SICCOde has been already Added!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1779)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1779,N'هذا مضاف بالفعل siccode',N'هذا مضاف بالفعل siccode','','G','Aug 21 2019  4:13PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'SICCODE_ADEDD')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','SICCODE_ADEDD','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'SICCODE_ADEDD')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','SICCODE_ADEDD','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go


If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1781)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1781,'SICCODE_MOVE','This SICCode can not be moved!','This SICCode can not be moved!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1781)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1781,N'لا يمكن تحريك هذا الصف',N'من فضلك اختر SIC كود فى البنك تاب','','G','Aug 21 2019  4:13PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'SICCODE_MOVE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','SICCODE_MOVE','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'SICCODE_MOVE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','SICCODE_MOVE','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

---------------------------------------------------------------------------
---------------------HostCoreService---------------------------------------
---------------------------------------------------------------------------
--ListRimRelationship
declare @sID int
set @sID = (select ServiceId from HostCoreService where ServiceName = 'ListRimRelationship' )
If @sID is not null
Begin
declare @maxID int
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='RimType')
Begin
set @maxID = (select max(FieldId)+1 from HostCoreServiceFields where ServiceId = @sID)
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'RimType','char',0,0,'','I')
 End
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='PEP')
Begin
set @maxID = (select max(FieldId)+1 from HostCoreServiceFields where ServiceId = @sID)
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'PEP','char',0,0,'','I')
 End
End
Go

--New Hostoreervice For Sic and SoW
If Not Exists(Select * From sqlstrings Where AccessID = 1100016)
Begin
 Insert Into sqlstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,1100016,'HS_GETNONPERSONALRIMSICINFO','p',1,'GFSOLEDB','dbo.HS_GETNONPERSONALRIMSICINFO',0,NULL,NULL,'G','ITSOFT\nehal.ramadan','Aug  6 2019  9:31AM','Get non personal rim SIC information',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  6 2019  9:31AM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

declare @sID int
set @sID = (select MAX(ServiceId)+1 from HostCoreService )
If Not Exists(Select * From HostCoreService Where ServiceName = 'ListSICInfo')
Begin
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription,Developer,Created,Updator,LastChanged)
 Values (@sID,'ListSICInfo','CustomerInquiry','To list SIC Information','ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM',N'ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM')
End
else
begin
set @sID = (select ServiceId from HostCoreService Where ServiceName = 'ListSICInfo')
end

if @sID is not null
Begin

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='RimNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,1,'RimNo','int',0,0,'','I')
End
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Priority' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,2,'SICCODE_Priority','int',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Description' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,3,'SICCODE_Description','nvarchar',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Code' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,4,'SICCODE_Code','int',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Status' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,5,'SICCODE_Status','nvarchar',999,0,'','O')
End
End
go

--sow
If Not Exists(select * From sqlstrings Where AccessID = 1100019)
Begin
 Insert Into sqlstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,1100019,'HS_GETRIMSOWINFO','p',1,'GFSOLEDB','dbo.HS_GETRIMSOWINFO',0,NULL,NULL,'G','ITSOFT\nehal.ramadan','Aug  6 2019  9:31AM','Get non personal rim SIC information',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  6 2019  9:31AM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

declare @sID int
set @sID = (select MAX(ServiceId)+1 from HostCoreService )
If Not Exists(Select * From HostCoreService Where ServiceName = 'ListSOWInfo')
Begin
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription,Developer,Created,Updator,LastChanged)
 Values (@sID,'ListSOWInfo','CustomerInquiry','To list SOW Information','ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM',N'ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM')
End
else
begin
set @sID = (select ServiceId from HostCoreService Where ServiceName = 'ListSOWInfo')
end

if @sID is not null
Begin

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='RimNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,1,'RimNo','int',0,0,'','I')
End
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='WealthID' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,2,'WealthID','int',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='CurrencyID' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,3,'CurrencyID','nvarchar',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='Amount' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,4,'Amount','decimal',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='WealthStatus' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,5,'WealthStatus','nvarchar',999,0,'','O')
End
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='Currency' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,6,'Currency','nvarchar',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='WealtfDesc' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,7,'WealtfDesc','nvarchar',999,0,'','O')
End
End
go
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_grb_ownershipRatio')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,NULL,N'Teller',N'_grb_ownershipRatio',-1,-1,-1,1,0,N'TLR_OWNERSHIP_RATIO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_rb_NoOfShares')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,NULL,N'Teller',N'_rb_NoOfShares',-1,-1,-1,1,0,N'TLR_NO_OF_SHARES',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_rb_percentage')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,NULL,N'Teller',N'_rb_percentage',-1,-1,-1,1,0,N'TLR_PERCENTAGE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_rb_amountOfShares')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,NULL,N'Teller',N'_rb_amountOfShares',-1,-1,-1,1,0,N'TLR_AMOUNT_OF_SHARE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_lbl_noOfShares')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,NULL,N'Teller',N'_lbl_noOfShares',-1,-1,-1,1,0,N'TLR_NO_OF_SHARES',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_txt_NoOfShares')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,1750,N'Teller',N'_txt_NoOfShares',-1,-1,-1,1,0,N'TLR_NO_OF_SHARES',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_lbl_totalNoOfShares')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,NULL,N'Teller',N'_lbl_totalNoOfShares',-1,-1,-1,1,0,N'TLR_TOTAL_NO_OF_SHARES',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_txt_totalNoOfShares')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,1887,N'Teller',N'_txt_totalNoOfShares',-1,-1,-1,1,0,N'TLR_TOTAL_NO_OF_SHARES',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_lbl_ownership')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,NULL,N'Teller',N'_lbl_ownership',-1,-1,-1,1,0,N'TLR_OWNERSHIP_PERCENT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_txt_ownership')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,2252,N'Teller',N'_txt_ownership',-1,-1,-1,1,0,N'TLR_OWNERSHIP_PERCENT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_lbl_shareAmount')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,NULL,N'Teller',N'_lbl_shareAmount',-1,-1,-1,1,0,N'TLR_SHARE_AMOUNT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_txt_shareAmount')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,2029,N'Teller',N'_txt_shareAmount',-1,-1,-1,1,0,N'TLR_SHARE_AMOUNT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_lbl_totalAmountOfShare')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,NULL,N'Teller',N'_lbl_totalAmountOfShare',-1,-1,-1,1,0,N'TLR_TOTAL_AMOUNT_OF_SHARE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_txt_totalAmountOfShare')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,2030,N'Teller',N'_txt_totalAmountOfShare',-1,-1,-1,1,0,N'TLR_TOTAL_AMOUNT_OF_SHARE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=15132 AND FieldIDInPage='_txt_ownershipPercentage')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(15132,2028,N'Teller',N'_txt_ownershipPercentage',-1,-1,-1,1,0,N'TLR_OWNERSHIP_PERCENT',N'',N'',1)
END
GO
--Devolper	 :	Aya Tarek
--Date       :	[14/2/2021]		
--Reason     :	CR#GFSY00762 KFH ACM17057 KYC_Part1 Requirements_Retrofit
------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------
----------------------RulesDescriptor------------------------------------------------------
-------------------------------------------------------------------------------------------

--------------------------OpenPersonal and EditPersonal ---------------------------
-------------------------------------wealth Tab --------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105473)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105473,'AddEdit_WeathSource',1,'Labels','Add/Edit Weath Source','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go


If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105473 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105473,1025,N' مصدر الثروه اضف \ عدل ','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'AddEdit_WeathSource')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AddEdit_WeathSource','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'AddEdit_WeathSource')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'AddEdit_WeathSource','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--SOURCE_OF_WEALTH

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105466)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105466,'SOURCE_OF_WEALTH',1,'Labels','Source Of Wealth',N'ITSOFT\aya.tarek','feb  14 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','feb  14 2021 6:13PM',N'ITSOFT\aya.tarek')
End
go


If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105466 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105466,1025,N'مصدر الثروه',N'ITSOFT\aya.tarek','feb  14 2021  1:32PM',N'ITSOFT\aya.tarek')
End
go


If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'SOURCE_OF_WEALTH')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'SOURCE_OF_WEALTH','feb  14 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb  14 2021 1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'SOURCE_OF_WEALTH')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'SOURCE_OF_WEALTH','feb  14 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb  14 2021 1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists (select * From RulesDescriptor Where DescriptorID = 1105437)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105437,'KYC_STATUS',1,'Labels','Status','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105437 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105437,1025,N'الحاله','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_STATUS')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_STATUS','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'COR_CANCEL')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'COR_CANCEL','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_STATUS')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_STATUS','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'COR_CANCEL')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'COR_CANCEL','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105453)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105453,'KYC_ACTIVE',1,'Labels','Active','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105453 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105453,1025,N'مفعل','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_ACTIVE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_ACTIVE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_ACTIVE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_ACTIVE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105454)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105454,'KYC_CLOSED',1,'Labels','Closed','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105454 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105454,1025,N'مغلق','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_CLOSED')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_CLOSED','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--------------------------------------sic cod tab------------------------------------------------------------------

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105472)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105472,'AddEdit_SICCODE',1,'Labels','Add / Edit SIC Code','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105472 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105472,1025,N'اضف \ عدل كود SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'AddEdit_SICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'AddEdit_SICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 578 And DSC_Name = 'AddEdit_SICCODE') 
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (578,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 565 And DSC_Name = 'AddEdit_SICCODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'AddEdit_SICCODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105432)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105432,'MULTIPLE_SICCODEs',1,'Labels','Multiple SIC Codes','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105432 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105432,1025,N'اكواد SIC عديده','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'MULTIPLE_SICCODEs')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'MULTIPLE_SICCODEs','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'UPROUND')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'UPROUND','feb 15 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb 15 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'DOWNROUND')--DOWNROUND
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'DOWNROUND','feb 15 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb 15 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'MULTIPLE_SICCODEs')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'MULTIPLE_SICCODEs','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'UPROUND')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'UPROUND','feb 15 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb 15 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'DOWNROUND')--DOWNROUND
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'DOWNROUND','feb 15 2021  1:32PM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek','feb 15 2021  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105434)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105434,'KYC_PRIORITY',1,'Labels','Priority','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105434 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105434,1025,N'اولويه','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_PRIORITY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_PRIORITY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_PRIORITY')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_PRIORITY','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105435)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105435,'KYC_SIC_CODE',1,'Labels','SIC CODE','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105435 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105435,1025,N'كود SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_SIC_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_SIC_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_SIC_CODE')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_SIC_CODE','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

----------------------------------

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105436)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105436,'KYC_SIC_CODE_DESCRIPTION',1,'Labels','SIC Code Description','G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 6 2019 6:13PM',N'ITSOFT\nehal.ramadan')
End
go

If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105436 And LCID = 1025)
Begin
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105436,1025,N'وصف كود SIC','G','Aug 6 2019  1:32PM',N'ITSOFT\nehal.ramadan')
End
go


If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 547 And DSC_Name = 'KYC_SIC_CODE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'KYC_SIC_CODE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTRANDescriptorS Where TranID = 564 And DSC_Name = 'KYC_SIC_CODE_DESCRIPTION')
Begin
 Insert Into RulesTRANDescriptorS(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'KYC_SIC_CODE_DESCRIPTION','Aug 6 2019  1:32PM',N'G',N'G','Aug 6 2019  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
------------------PACI_NO-------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105448)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES (1,1105448,'TLR_PACI_NUMBER',0,'Labels','PACI No.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105448 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	VALUES(1105448,1025,N'رقم المدنية')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 547 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (547,'TLR_PACI_NUMBER')
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 564 AND DSC_Name='TLR_PACI_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (564,'TLR_PACI_NUMBER')
END
GO
---------Update siccode and subsiccode Descriptor-------------
If  Exists(select * from rulesdescriptor where Name='TLR_SUB_SIC_CODE')
Begin
update rulesdescriptor set Descriptor='Child SIC Code' where  Name='TLR_SUB_SIC_CODE'
end
go

If  Exists(select * from rulesdescriptor where Name='TLR_SIC_CODE')
Begin
update rulesdescriptor set Descriptor='Parent SIC Code' where  Name='TLR_SIC_CODE'
end
go

-------------------------------------------------------------------------
------------------------picklists----------------------------------------
------------------------------------------------------------------------
If Not Exists(Select * From PickLists Where PickListID = 550)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,550,'KYC_Status','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  07 2019  6:23PM','Aug 7 2019  2:14PM',N'ITSOFT\nehal.ramadan',N'G',1)
End
go


If Not Exists(select * From PickList_Entries Where PickListID = 550 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (550,1,1,'KYC_ACTIVE','Active','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 18 2019 1:37PM','Jan  4 2001  9:44AM',N'G',N'G',1,NULL)
End
go
If Not Exists(select * From PickList_Entries Where PickListID = 550 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (550,1,2,'KYC_CLOSED','Closed','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug 18 2019  1:37PM','Jan  4 2001  9:44AM',N'G',N'G',1,NULL)
End
go
-------

--------------------------------------------------------------------------
--------------------Rulestranfield--------------------------------------------------
------------------------------------------------------------------------------------

------------------OpenPersonal & EditPersonal--------------------------------------------------------------
---------------------------------------------wealth source tab----------------------------------------------
--wealthID in gridview 
-----WealthID-------TLR_IR_DrAccountName_DP_Arr

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1545)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1545,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthID',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1545)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1545,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthID',0,-1)
End
go
-----WealthDescription-------TLR_HOST_RESPONSE_ARRAY
If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 950)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,950,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDesc',0,-1)
 End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 950)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,950,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDesc',0,-1)
 End
go
-----WealthAmount-------
If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 2039)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,2039,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthAmount',0,-1)
 End
go

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 2039)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,2039,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthAmount',0,-1)
 End
go
-----WealthDescDisplay -----TLR_PDC_ISSUE_BRANCH_NAME
If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 1754)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1754,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDescDisplay',0,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1754)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1754,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthDescDisplay',0,-1)
End
go
-----currencyID-------TLR_HOST_TRAN_STATUS_ARRAY

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 949)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,949,1,0,0,NULL,N'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'currencyID',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 275)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,275,1,0,0,NULL,N'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'currencyID',0,-1)
End
go
----

-----CurrencyDescription-------TLR_CORR_BANK_COUNT_ARR

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 846)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,846,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'CurrencyDesc',0,-1)
End
go
----
If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 846)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,846,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'CurrencyDesc',0,-1)
End
go

-----WealthStatusDisplay-------TLR_CLINR_BRNCH_NAME_ARR

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1612)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1612,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatusDisplay',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1612)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1612,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatusDisplay',0,-1)
End
go
----
-----WealthStatus-------TLR_NARRATIVE_FUNDS_ARRAY

If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 276)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,276,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatus',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 276)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,276,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'WealthStatus',0,-1)
End
go
-----------------------------------------------------sic code tab----------------------------------------------------
----SICCOE_PRIORITY ----TLR_USE_SIMPLE_CHARGES_ARR
If Not Exists(select *  From rulestranfield Where TranID = 564 And FieldID = 367)--367--1685
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,367,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICCOE_PRIORITY',0,-1)
End
go
If Not Exists(select *  From rulestranfield Where TranID = 547 And FieldID = 367)--367--1685
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,367,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICCOE_PRIORITY',0,-1)
End
go
----KYC_SICCOE ---TLR_BILL_ID_NO_ARRAY
If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1887) 
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1887,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCOE',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1887) 
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1887,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCOE',0,-1)
End
go
--KYC_SICCODE_DESCRIPTION----TLR_PDC_HOST_TRAN_RESPONSE
If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1758)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1758,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_DESCRIPTION',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1758)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1758,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_DESCRIPTION',0,-1)
End
go
---KYC_SICCODE_STATUS----TLR_PDC_DEST_BK_COUNTRY
If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1689)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1689,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_STATUS',0,-1)
End
go
If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1689)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1689,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'KYC_SICCODE_STATUS',0,-1)
End
go
--SICDescDisplay -- TLR_INVOICE_NO_ARR
If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 1788)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1788,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICDescDisplay',0,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1788)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1788,1,0,0,NULL,'G','May  7 2019  5:46PM',1,NULL,'','May  7 2019  5:46PM',N'G',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICDescDisplay',0,-1)
End
go
--SICStatusDisplay-------------TLR_BRANCH_NAME_ARRAY
If Not Exists(select * From rulestranfield Where TranID = 547 And FieldID = 1615)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1615,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICStatusDisplay',0,-1)
End
go

If Not Exists(select * From rulestranfield Where TranID = 564 And FieldID = 1615)
Begin
 Insert Into rulestranfield(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1615,1,0,0,NULL,'ITSOFT\aya.tarek','feb  14 2021  5:46PM',1,NULL,'','feb  14 2021   5:46PM',N'ITSOFT\aya.tarek',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'SICStatusDisplay',0,-1)
End
go
----------------------------PAci_NO-------------------
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 547 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (547,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 547 And FieldID = 589)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (547,589,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumberPopup',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 564 And FieldID = 1150)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (564,1150,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 564 And FieldID = 589)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (564,589,1,0,0,NULL,1,NULL,'',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'PACINumberPopup',0,-1)
END
GO

------------------------------------------------------------------------------------------------
-------------------------------Rulestranfield_ex------------------------------------------------
------------------------------------------------------------------------------------------------

-----------------------------OpenPersonal & EditPersonal--------------------------------------
----------------------------------------wealt source Tab--------------------------------------
If Not Exists(select * From rulestranfield_ex Where FieldIDInPage like 'tab_SourceOfWealth'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','tab_SourceOfWealth',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'grd_SourceOfWealth'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','grd_SourceOfWealth',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthAdd'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','btn_WealthAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthEdit'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','btn_WealthEdit',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthClear'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','btn_WealthClear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'txt_Amount'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','txt_Amount',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Status'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','_cbo_Wealth_Status',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Source'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','_cbo_Wealth_Source',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Currency'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller    ','_cbo_Wealth_Currency',-1,-1,-1,0,0,'','','','Jan 29 2019 3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(select * From rulestranfield_ex Where FieldIDInPage like 'tab_SourceOfWealth'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','tab_SourceOfWealth',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'grd_SourceOfWealth'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','grd_SourceOfWealth',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthAdd'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','btn_WealthAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go


If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthEdit'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','btn_WealthEdit',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_WealthClear'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','btn_WealthClear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'txt_Amount'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','txt_Amount',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Status'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','_cbo_Wealth_Status',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Source'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','_cbo_Wealth_Source',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_cbo_Wealth_Currency'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller    ','_cbo_Wealth_Currency',-1,-1,-1,0,0,'','','','Jan 29 2019 3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

------------------------------sic tab-----------------------------------------
If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'tab_MultipleSICCode'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller ','tab_MultipleSICCode',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_Grd_Multiple_SIC_Codes'  and TranID = 547  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,0,'Teller ','_Grd_Multiple_SIC_Codes',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_SICCodeAdd'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_btn_SICCodeAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_clear'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','btn_clear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_down'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_btn_down',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_Up'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_btn_Up',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCode'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_drpSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCodeStatus'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,NULL,'Teller    ','_drpSICCodeStatus',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSubSICCode'  and TranID = 547 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (547,1617,'Teller    ','_drpSubSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\aya.tarek',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'tab_MultipleSICCode'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller ','tab_MultipleSICCode',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',0)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_Grd_Multiple_SIC_Codes'  and TranID = 564  )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,0,'Teller ','_Grd_Multiple_SIC_Codes',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_SICCodeAdd'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_btn_SICCodeAdd',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like 'btn_clear'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','btn_clear',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_down'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_btn_down',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_btn_Up'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_btn_Up',-1,-1,-1,1,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCode'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_drpSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSICCodeStatus'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,NULL,'Teller    ','_drpSICCodeStatus',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From rulestranfield_ex Where FieldIDInPage like '_drpSubSICCode'  and TranID = 564 )
Begin
 Insert Into rulestranfield_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
 Values (564,1617,'Teller    ','_drpSubSICCode',-1,-1,-1,0,0,'','','','Jan 29 2014  3:22PM',N'ITSOFT\aya.tarek',1)
End
go
-----------------------------PACI_NO--------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 547 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (547,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 547 AND FieldIDInPage = 'txt_Popup_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (547,589,'Teller    ','txt_Popup_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 564 AND FieldIDInPage = 'txt_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (564,1150,'Teller    ','txt_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID = 564 AND FieldIDInPage = 'txt_Popup_PACINumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible)
	VALUES (564,589,'Teller    ','txt_Popup_PACINumber',-1,-1,-1,1,0,'TLR_PACI_NUMBER','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0)
END
GO
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------RulesErrorDescription------------------------------------------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1780)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1780,'SICCODE_PARENT_ADDITION','Please Select Parent SIC Code in Bank Tab First!','Please Select Parent SIC Code in Bank Tab First!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1780)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1780,N'من فضلك اختر SIC كود فى البنك تاب',N'من فضلك اختر SIC كود فى البنك تاب','','G','Aug 21 2019  4:13PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'SICCODE_PARENT_ADDITION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','SICCODE_PARENT_ADDITION','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'SICCODE_PARENT_ADDITION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','SICCODE_PARENT_ADDITION','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1783)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1783,'WEALTH_ADDED','Wealth has been already Added!','Wealth has been already Added!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1783)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1783,N'هذه الثروه مضاف بالفعل',N'هذه الثروه مضاف بالفعل','','G','Aug 21 2019  4:13PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'WEALTH_ADDED')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','WEALTH_ADDED','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'WEALTH_ADDED')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','WEALTH_ADDED','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1779)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1779,'SICCODE_ADEDD','SICCOde has been already Added!','SICCOde has been already Added!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1779)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1779,N'هذا مضاف بالفعل siccode',N'هذا مضاف بالفعل siccode','','G','Aug 21 2019  4:13PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'SICCODE_ADEDD')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','SICCODE_ADEDD','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'SICCODE_ADEDD')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','SICCODE_ADEDD','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go


If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1781)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1781,'SICCODE_MOVE','This SICCode can not be moved!','This SICCode can not be moved!',2,'ErrDesc.hlp',1,'G','Aug  21 2019  3:58PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1781)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1781,N'لا يمكن تحريك هذا الصف',N'من فضلك اختر SIC كود فى البنك تاب','','G','Aug 21 2019  4:13PM')
End
go


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'SICCODE_MOVE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','SICCODE_MOVE','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'editPersonalRim' And Error_Name = 'SICCODE_MOVE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('editPersonalRim','SICCODE_MOVE','Aug  21 2019  3:58PM','ITSOFT\nehal.ramadan',1,'Dec 31 9998 12:00AM','Aug  21 2019  3:58PM')
End
go

---------------------------------------------------------------------------
---------------------HostCoreService---------------------------------------
---------------------------------------------------------------------------
--ListRimRelationship
declare @sID int
set @sID = (select ServiceId from HostCoreService where ServiceName = 'ListRimRelationship' )
If @sID is not null
Begin
declare @maxID int
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='RimType')
Begin
set @maxID = (select max(FieldId)+1 from HostCoreServiceFields where ServiceId = @sID)
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'RimType','char',0,0,'','I')
 End
 If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='PEP')
Begin
set @maxID = (select max(FieldId)+1 from HostCoreServiceFields where ServiceId = @sID)
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,@maxID,'PEP','char',0,0,'','I')
 End
End
Go

--New Hostoreervice For Sic and SoW
If Not Exists(Select * From sqlstrings Where AccessID = 1100016)
Begin
 Insert Into sqlstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,1100016,'HS_GETNONPERSONALRIMSICINFO','p',1,'GFSOLEDB','dbo.HS_GETNONPERSONALRIMSICINFO',0,NULL,NULL,'G','ITSOFT\nehal.ramadan','Aug  6 2019  9:31AM','Get non personal rim SIC information',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  6 2019  9:31AM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

declare @sID int
set @sID = (select MAX(ServiceId)+1 from HostCoreService )
If Not Exists(Select * From HostCoreService Where ServiceName = 'ListSICInfo')
Begin
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription,Developer,Created,Updator,LastChanged)
 Values (@sID,'ListSICInfo','CustomerInquiry','To list SIC Information','ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM',N'ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM')
End
else
begin
set @sID = (select ServiceId from HostCoreService Where ServiceName = 'ListSICInfo')
end

if @sID is not null
Begin

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='RimNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,1,'RimNo','int',0,0,'','I')
End
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Priority' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,2,'SICCODE_Priority','int',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Description' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,3,'SICCODE_Description','nvarchar',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Code' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,4,'SICCODE_Code','int',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='SICCODE_Status' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,5,'SICCODE_Status','nvarchar',999,0,'','O')
End
End
go

--sow
If Not Exists(select * From sqlstrings Where AccessID = 1100019)
Begin
 Insert Into sqlstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,1100019,'HS_GETRIMSOWINFO','p',1,'GFSOLEDB','dbo.HS_GETRIMSOWINFO',0,NULL,NULL,'G','ITSOFT\nehal.ramadan','Aug  6 2019  9:31AM','Get non personal rim SIC information',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  6 2019  9:31AM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

declare @sID int
set @sID = (select MAX(ServiceId)+1 from HostCoreService )
If Not Exists(Select * From HostCoreService Where ServiceName = 'ListSOWInfo')
Begin
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription,Developer,Created,Updator,LastChanged)
 Values (@sID,'ListSOWInfo','CustomerInquiry','To list SOW Information','ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM',N'ITSOFT\nehal.ramadan','Aug 13 2019  2:15PM')
End
else
begin
set @sID = (select ServiceId from HostCoreService Where ServiceName = 'ListSOWInfo')
end

if @sID is not null
Begin

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID  and FieldName='RimNo')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,1,'RimNo','int',0,0,'','I')
End
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='WealthID' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,2,'WealthID','int',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='CurrencyID' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,3,'CurrencyID','nvarchar',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='Amount' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,4,'Amount','decimal',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='WealthStatus' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,5,'WealthStatus','nvarchar',999,0,'','O')
End
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='Currency' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,6,'Currency','nvarchar',999,0,'','O')
End

If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @sID and FieldName='WealtfDesc' )
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@sID,7,'WealtfDesc','nvarchar',999,0,'','O')
End
End
go
--Devolper	 :	Ibrahim Harby 
--Date       :	[25/04/2021]		
--Reason     :	CR#GFSY00842 [retrofit]
------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------
--------------------------RulesDescriptor & RulesDesceiptorLocal-------------------------------------------------------
------------------------------------------------------------------------------------------------
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105885 and Name = 'TLR_GOODS_SOLD' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105885,'TLR_GOODS_SOLD',0,'Picklists','GDE - Goods Sold Exports','ITSoft\ibrahim.harby','Mar 10 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Mar 10 2021 10:19AM',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105885 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105885,1025,N'GDE - صادرات البضائع المباعة','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105886 and Name = 'TLR_PROCESSING_REPAIR' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105886,'TLR_PROCESSING_REPAIR',0,'Picklists','GMS - Processing Repair and maintenance Services on goods','ITSoft\ibrahim.harby','Mar 10 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Mar 10 2021 10:19AM',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105886 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105886,1025,N'GMS - خدمات معالجة وإصلاح وصيانة البضائع','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1391 and Name = 'TLR_26T_TRANSACTION' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1391,'TLR_26T_TRANSACTION',0,'Labels','26T : Transaction','ITSoft\ibrahim.harby','Mar 10 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Mar 10 2021 10:19AM',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1391 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1391,1025,N'26T : المعاملة','Mar 10 2021 10:19AM')
End
go



------------------------------------------------------------------------------------------------
--------------------------RulesTranDescriptors-------------------------------------------------------
---------------------------------------------------------------------------------------------

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_26T_TRANSACTION' ,'ITSOFT\ibrahim.harby'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278   ,'TLR_26T_TRANSACTION' ,'ITSOFT\ibrahim.harby'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_26T_TRANSACTION' ,'ITSOFT\ibrahim.harby'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_26T_TRANSACTION' ,'ITSOFT\ibrahim.harby'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_26T_TRANSACTION' ,'ITSOFT\ibrahim.harby'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_26T_TRANSACTION' ,'ITSOFT\ibrahim.harby'  ) 
END
Go


------------------------------------------------------------------------------------------------
--------------------------Picklists-------------------------------------------------------
---------------------------------------------------------------------------------------------

If Not Exists(Select * From PickLists Where PickListID = 569)
Begin
 Insert Into PickLists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,569,'PICK_PURPOSECODE','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Mar 10 2021 10:19AM','Mar 10 2021 10:19AM',N'ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby',1)
End
GO

--------------------------------------------------------------------------------------------------
------------------------------------------- PickList_Entries-------------------------------
-----------------------------------------------------------------------------------------------
--PurposeCode
If Not Exists(Select * From PickList_Entries Where PickListID = 569 And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (569,1,0,'TLR_GOODS_SOLD','GDE','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Mar 10 2021 10:19AM','Mar 10 2021 10:19AM',N'ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby',1,NULL)
End
go
If Not Exists(Select * From PickList_Entries Where PickListID = 569 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (569,1,1,'TLR_PROCESSING_REPAIR','GMS','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Mar 10 2021 10:19AM','Mar 10 2021 10:19AM',N'ITSOFT\ibrahim.harby',N'ibrahim.harby',1,NULL)
End
go

-------------------------------------RulesTRanField-----------------------------
--------------------------------------------------------------------------------
--Purpose Description  TLR_CHEQUE_RETURN_REASON
--IssueTTAgAccount
If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 446 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,446,1)
End
go
--IssuettAgcash
If Not Exists(select * From RulesTranField Where TranID = 278 And FieldID = 446 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (278,446,1)
End
go

--IssueTTAgCheque
If Not Exists(select * From RulesTranField Where TranID = 279 And FieldID = 446 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (279,446,1)
End
go

--IssueTTAgGL
If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 446 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,446,1)
End
go

--Outward Remmitance with swift details
If Not Exists(select * From RulesTranField Where TranID = 262 And FieldID = 446 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (262,446,1)
End
go

-----------Purpose Code 

--IssueTTAgAccount
If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 443 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,443,1)
End
go
--IssuettAgcash
If Not Exists(select * From RulesTranField Where TranID = 278 And FieldID = 443 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (278,443,1)
End
go

--IssueTTAgCheque
If Not Exists(select * From RulesTranField Where TranID = 279 And FieldID = 443 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (279,443,1)
End
go

--IssueTTAgGL
If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 443 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,443,1)
End
go

--Outward Remmitance with swift details
If Not Exists(select * From RulesTranField Where TranID = 262 And FieldID = 443 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (262,443,1)
End
go
-----------------------------RulesTranField_ex-----------
--------------------------------------------------------------
--IssueTTAganistAccount
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 277 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO

--IssueTTAganistCash
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 278 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO

--IssueTTAgaCheque
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 279 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO
--IssueTTAgGL
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 296 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO

--Outward Remmitance with swift details
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=262 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 262 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 0)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=262 AND FieldIDInPage='_txtTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 262 , NULL , 'Teller' , '_txtTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO

--Add NewSo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO
--ModifiySo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO
----------------------Lable For Purpose Description---------------
--IssueTTAgACOOUNT
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 277 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO

--IssueTTAganistCash
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 278 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO

--IssueTTAgaCheque
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 279 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO
--IssueTTAgGL
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 296 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO

--Add NewSo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO
--ModifiySo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ibrahim.harby' , 1)
END
GO
-----------------------------------
-- ModifiySo
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 260 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
END
GO

-- add NewSo
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 257 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
END
GO
--IssueTTAgGL
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 296 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
END
GO
--IssueTTAgaCheque
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 279 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
END
GO
-- IssueTTAganistCash
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 278 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
END
GO
--IssueTTAganistAccount
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 277 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
END
------------------
-- ModifiySo
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 260 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
END
GO

-- add NewSo
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 257 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
END
GO
--IssueTTAgGL
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 296 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
END
GO
--IssueTTAgaCheque
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 279 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
END
GO
-- IssueTTAganistCash
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 278 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
END
GO
--IssueTTAgACOOUNT
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	UPDATE RulesTranField_ex 
	   SET IsVisible = 1
	 WHERE TranID = 277 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
END
GO
-- =============================================
-- Author:		Ibrahim Harby 
-- Create date: 17-May-2021
-- Description:	 CR# GFSY00853
-- =============================================
If Not Exists(Select * From RulesParam Where ParamName='UseNewCorresChargesTable')
Begin
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'UseNewCorresChargesTable','specify To get Correspondet Charges From new table','',0,1,0,'','Static','')
End




IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstCheque' AND FieldName = 'UseNewCorresChargesTable' AND Param = 'UseNewCorresChargesTable' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstCheque' , 'UseNewCorresChargesTable' , 'UseNewCorresChargesTable' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstAccount' AND FieldName = 'UseNewCorresChargesTable' AND Param = 'UseNewCorresChargesTable' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstAccount' , 'UseNewCorresChargesTable' , 'UseNewCorresChargesTable' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO

 

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstGL' AND FieldName = 'UseNewCorresChargesTable' AND Param = 'UseNewCorresChargesTable' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstGL' , 'UseNewCorresChargesTable' , 'UseNewCorresChargesTable' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From  dbo.SQLstrings Where AccessID = 1100106     AND  AccessName   =  'Get_CorrespondentCharges'  )
BEGIN
 INSERT INTO dbo.SQLstrings ( AccessID  , AccessName , CommandType , GetsRows , DataSource ,AccessString , Purpose , AppID ) -- , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )
  Values( 1100106   ,   'Get_CorrespondentCharges', 'P' , 1 , 'Globalfs', 'dbo.Select_corres_charges' , 'Select corres charges from new setup table' , 1) --   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\ibrahim.harby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\ibrahim.harby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL )
END
Go
/*
 Developer : Mostafa Helmy 
 Issue     : GFSX14573
 */

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 300)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (300,'OPEN_REQ',' Open Day Required','Open Day Required',4,'',1,'STCA1\greggy','Jun 22 2001 10:07AM',1,'Dec 31 9998 12:00AM')
End

else
begin
update RulesErrorDescription set DisplayText='Open Day Required' Where DescriptionNumber = 300
End

go
--Devolper	 :	Aya Tarek
--Date       :	[10/3/2021]		
--Reason     :	CR#GFSY00843_Retrofit [PurposeCode For swift Cross Border Payment]
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--------------------------RulesDescriptor & RulesDesceiptorLocal-------------------------------------------------------
------------------------------------------------------------------------------------------------
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105885 and Name = 'TLR_GOODS_SOLD' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105885,'TLR_GOODS_SOLD',0,'Picklists','GDE - Goods Sold Exports','ITSoft\aya.tarek','Mar 10 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Mar 10 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105885 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105885,1025,N'GDE - صادرات البضائع المباعة','Mar 10 2021 10:19AM')
End
go


If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105886 and Name = 'TLR_PROCESSING_REPAIR' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105886,'TLR_PROCESSING_REPAIR',0,'Picklists','GMS - Processing Repair and maintenance Services on goods','ITSoft\aya.tarek','Mar 10 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Mar 10 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105886 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105886,1025,N'GMS - خدمات معالجة وإصلاح وصيانة البضائع','Mar 10 2021 10:19AM')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1391 and Name = 'TLR_26T_TRANSACTION' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1391,'TLR_26T_TRANSACTION',0,'Labels','26T : Transaction','ITSoft\aya.tarek','Mar 10 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Mar 10 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1391 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1391,1025,N'26T : المعاملة','Mar 10 2021 10:19AM')
End
go



------------------------------------------------------------------------------------------------
--------------------------RulesTranDescriptors-------------------------------------------------------
---------------------------------------------------------------------------------------------

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 277 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 277   ,'TLR_26T_TRANSACTION' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 278 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 278   ,'TLR_26T_TRANSACTION' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 279 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 279   ,'TLR_26T_TRANSACTION' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 296 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 296   ,'TLR_26T_TRANSACTION' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 257 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 257   ,'TLR_26T_TRANSACTION' ,'ITSOFT\aya.tarek'  ) 
END
Go
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 260 AND  Dsc_name =  'TLR_26T_TRANSACTION'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 260   ,'TLR_26T_TRANSACTION' ,'ITSOFT\aya.tarek'  ) 
END
Go


------------------------------------------------------------------------------------------------
--------------------------Picklists-------------------------------------------------------
---------------------------------------------------------------------------------------------

If Not Exists(Select * From PickLists Where PickListID = 569)
Begin
 Insert Into PickLists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,569,'PICK_PURPOSECODE','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Mar 10 2021 10:19AM','Mar 10 2021 10:19AM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1)
End
GO

--------------------------------------------------------------------------------------------------
------------------------------------------- PickList_Entries-------------------------------
-----------------------------------------------------------------------------------------------
--PurposeCode
If Not Exists(Select * From PickList_Entries Where PickListID = 569 And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (569,1,0,'TLR_GOODS_SOLD','GDE','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Mar 10 2021 10:19AM','Mar 10 2021 10:19AM',N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1,NULL)
End
go
If Not Exists(Select * From PickList_Entries Where PickListID = 569 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (569,1,1,'TLR_PROCESSING_REPAIR','GMS','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Mar 10 2021 10:19AM','Mar 10 2021 10:19AM',N'ITSOFT\aya.tarek',N'aya.tarek',1,NULL)
End
go

-------------------------------------RulesTRanField-----------------------------
--------------------------------------------------------------------------------
--Purpose Description  TLR_CHEQUE_RETURN_REASON
--IssueTTAgAccount
If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 446 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,446,1)
End
go
--IssuettAgcash
If Not Exists(select * From RulesTranField Where TranID = 278 And FieldID = 446 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (278,446,1)
End
go

--IssueTTAgCheque
If Not Exists(select * From RulesTranField Where TranID = 279 And FieldID = 446 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (279,446,1)
End
go

--IssueTTAgGL
If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 446 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,446,1)
End
go

-----------Purpose Code 

--IssueTTAgAccount
If Not Exists(select * From RulesTranField Where TranID = 277 And FieldID = 443 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (277,443,1)
End
go
--IssuettAgcash
If Not Exists(select * From RulesTranField Where TranID = 278 And FieldID = 443 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (278,443,1)
End
go

--IssueTTAgCheque
If Not Exists(select * From RulesTranField Where TranID = 279 And FieldID = 443 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (279,443,1)
End
go

--IssueTTAgGL
If Not Exists(select * From RulesTranField Where TranID = 296 And FieldID = 443 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (296,443,1)
End
go

-----------------------------RulesTranField_ex-----------
--------------------------------------------------------------
--IssueTTAgACOOUNT
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 277 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

--IssueTTAganistCash
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 278 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

--IssueTTAgaCheque
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 279 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO
--IssueTTAgGL
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 296 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

--Add NewSo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO
--ModifiySo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_cboTLR_26T_TRANSACTION' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO
----------------------Lable For Purpose Description---------------
--IssueTTAgACOOUNT
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 277 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

--IssueTTAganistCash
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 278 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

--IssueTTAgaCheque
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 279 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO
--IssueTTAgGL
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 296 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

--Add NewSo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 257 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO
--ModifiySo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 260 , NULL , 'Teller' , '_lblTLR_26T_TRANSACTION_2' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 0)
END
GO

------------------------Update-----------------------------
-----------------------------------------------------------
--------combo---------
--IssueTTAgACOOUNT
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
 update  RulesTranField_ex set IsVisible=1  WHERE TranID=277 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
	END
GO

--IssueTTAganistCash
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	update  RulesTranField_ex set IsVisible=1 WHERE TranID=278 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
	END
GO

--IssueTTAgaCheque
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	update  RulesTranField_ex set IsVisible=1 WHERE TranID=279 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
	END
GO

--IssueTTAgGL
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	update  RulesTranField_ex set IsVisible=1  WHERE TranID=296 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
	END
GO
--Add NewSo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	update  RulesTranField_ex set IsVisible=1  WHERE TranID=257 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
	END
GO
--ModifiySo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_cboTLR_26T_TRANSACTION')
BEGIN
	update  RulesTranField_ex set IsVisible=1 WHERE TranID=260 AND FieldIDInPage='_cboTLR_26T_TRANSACTION'
	END
GO

--------lable---------
--IssueTTAgACOOUNT
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=277 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
 update  RulesTranField_ex set IsVisible=1  WHERE TranID=277 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
	END
GO

--IssueTTAganistCash
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=278 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	update  RulesTranField_ex set IsVisible=1 WHERE TranID=278 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
	END
GO

--IssueTTAgaCheque
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=279 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	update  RulesTranField_ex set IsVisible=1 WHERE TranID=279 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
	END
GO

--IssueTTAgGL
IF EXISTS(select * FROM RulesTranField_ex WHERE TranID=296 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	update  RulesTranField_ex set IsVisible=1  WHERE TranID=296 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
	END
GO
--Add NewSo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	update  RulesTranField_ex set IsVisible=1  WHERE TranID=257 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
	END
GO
--ModifiySo
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2')
BEGIN
	update  RulesTranField_ex set IsVisible=1 WHERE TranID=260 AND FieldIDInPage='_lblTLR_26T_TRANSACTION_2'
	END
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[13/05/2021]		
--Reason	:	Enh GFSY00850 - BARWA - ACM19129 - General Enhancement II
--=======================================================================
PRINT 'Start. Script for CR# GFSY00850 DML Script'
GO

--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105894)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105894,'TLR_HideOverrideNotification',0,'Labels','Hide Override Notification','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105894 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105894,1025,N'إخفاء إعلام التجاوز','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105897)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105897,'TLR_ShowSupervisorTransactions',0,'Labels','Supervisor Posted Transactions','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105897 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105897,1025,N'المشرف على المعاملات المرسلة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -220057)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (22,-220057,'WEB_SUPERVISOR_ID',0,'Labels','Supervisor ID','lauram','Mar  4 2012 10:41AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jun 26 2002  3:44PM',N'ITSOFT\halsum')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = -220057 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (-220057,1025,N'هوية المشرف','ITSOFT\mafarouk','Oct 13 2011 12:00AM',N'ITSOFT\mafarouk')
End
GO

-------------------------
-- RulesTranDescriptors -
-------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 1000008 And DSC_Name = 'TLR_HideOverrideNotification')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (1000008,'TLR_HideOverrideNotification',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

---------------
-- SQLstrings -
---------------
If Not Exists(Select * From SQLstrings Where AccessID = 1100078)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100078,'SelectTellerConfig','p',1,'Globalfs','dbo.SelectTellerConfig',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select Teller Config',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,0)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100101)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100101,'GET_JOURNAL_SUMMARY_PRINTING','s',1,'Globalfs','exec dbo.Get_Journal_Summary_For_Printing   @criteria=?, @criteria2=?, @start_date =?, @end_date= ?,  @order_time_ascending=?,@max_rows=?,@page_back=?, @LCID=?, @for_user=?',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Get summary rows for journal scan for new printing transaction',1,' ','',1,0,1,NULL,NULL,0,0,0,0,0)
End
GO
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105019)
Begin
Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
Values (1,1105019,'TLR_SECOND_NAME',0,'Labels','Second Name','ITSOFT\mahmoud.saad','Feb 8 2018 1:19PM',1,'Jan 1 1901 12:00AM','Dec 31 9998 12:00AM','Feb 8 2018 1:18PM',N'ITSOFT\mahmoud.saad')
End
go

----------------------
-- RulesTranField_ex -
----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 861 And FieldID Is Null And FieldIDInPage = '_check_ShowSupervisorTransactions')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (861,NULL,'Teller','_check_ShowSupervisorTransactions',-1,-1,-1,1,0,NULL,'True',NULL,'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 861 And FieldID Is Null And FieldIDInPage = '_lbl_Supervisor')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (861,NULL,'Teller','_lbl_Supervisor',-1,-1,-1,1,0,NULL,'',NULL,'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 861 And FieldID Is Null And FieldIDInPage = '_cbo_SupervisorList')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (861,NULL,'Teller','_cbo_SupervisorList',-1,-1,-1,1,0,NULL,'',NULL,'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

PRINT 'End... Script for CR# GFSY00850 DML Script'
GO
--==================================================================================================================================================================
--Devolper	 :	Aya Tarek
--Date       :	[20/5/2021]		
--Reason     :	CR#GFSY00855 [SO 202CoV changes]
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--------------------------RulesParam-------------------------------------------------------
---------------------------------------------------------------------------------------------
If Not Exists(Select * From RulesParam Where ParamName='AttachMT202-202COV')
Begin
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'AttachMT202-202COV',' This parameter will creat MT 202 or MT 202 COV with MT103 ','',0,1,0,'','Static','')
End
Go
------------------------------------RulesTranFldParam----------------------------------------
-----------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--AddNewSO
IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'AddNewSO' AND FieldName = 'GenerateMT202-202COV' AND Param = 'AttachMT202-202COV' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'AddNewSO' , 'GenerateMT202-202COV' , 'AttachMT202-202COV' , '0' ,'ITSOFT\aya.tarek' , 'int')
END
GO

--ModifyExistingSO
IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'ModifyExistingSO' AND FieldName = 'GenerateMT202-202COV' AND Param = 'AttachMT202-202COV' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'ModifyExistingSO' , 'GenerateMT202-202COV' , 'AttachMT202-202COV' , '0' ,'ITSOFT\aya.tarek' , 'int')
END
GO

----- HostCoreService && HostCoreServiceFields
----------------------------------------------
--MT202Cov 
IF Exists(Select * From HostCoreService Where ServiceName = 'GetSoSwiftDetails')
	BEGIN
		DECLARE @serviceID int , @fieldId int
		SELECT @serviceID = ServiceId from HostCoreService WHERE ServiceName = 'GetSoSwiftDetails'
		SELECT @fieldId = max(FieldId) + 1  from HostCoreServiceFields  WHERE ServiceId = @serviceID
		BEGIN
			If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @serviceID And FieldName = 'Mt202Cov')
				BEGIN
					Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
					Values (@serviceID,@fieldId,'Mt202Cov','varchar',999,0,'','O','ITSOFT\aya.tarek',N'ITSOFT\aya.tarek')
				END
		END
	END

GO

-- =============================================
-- Author:		Ahmed Almaghraby
-- Create date: 05/04/2021
-- Description:	GFSX14504
-- =============================================


--- PurposeCode MultCreditTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 193  AND  FieldID   =  1322   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 193   ,   1322   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\ahmed.almaghraby'  ,   1   ,    999    ,  ''  ,  'ITSOFT\ahmed.almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeDescription MultDepitTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 195 AND  FieldID   =  1322   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 195   ,   1322   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\ahmed.almaghraby'  ,   1   ,    9999    ,  ''  ,  'ITSOFT\ahmed.almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
Go



-- PurposeDescription MultCreditTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 193   AND FieldIDInPage   = 'TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 193   ,  1332  ,  'Teller'  ,  'TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label MultCreditTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 193 AND   FieldIDInPage   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 193   ,    NULL    ,  'Teller'  ,  'TLR_TRANSFER_PURPOSE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO

-- PurposeDescription MultdebitTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 195  AND FieldIDInPage   = 'TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 195   ,  1332  ,  'Teller'  ,  'TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label MultdebitTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 195  AND  FieldIDInPage   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 195   ,    NULL    ,  'Teller'  ,  'TLR_TRANSFER_PURPOSE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO
Go
update PickLists set PickList_Name = 'TLR_AML_Personal_Products'   where picklist_name = 'TLR_AML_Products' 
--******************************************************************************************************************************************************************
--*************************PickLists********************************************************************************************************************************
--******************************************************************************************************************************************************************
IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 570)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,570,'TLR_AML_NonPersonal_Products')
	END

IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 571)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,571,'TLR_AML_Personal_Channels')
	END

IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 572)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,572,'TLR_AML_NonPersonal_Channels')
	END		

IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 573)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,573,'TLR_AML_NonPersonal_Ownership')
	END	

--******************************************************************************************************************************************************************
--*************************RulesDescriptor*************************************************************************************************************************
--******************************************************************************************************************************************************************
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105892 and Name = 'lbl_AML_Cahnnels')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105892,'lbl_AML_Cahnnels',0,'Labels','Channels','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105893 and Name = 'lbl_AML_Ownership')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105893,'lbl_AML_Ownership',0,'Labels','Ownership','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105895 and Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105895,'lbl_CustSearch_Branch',0,'Labels','Branch','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105896 and Name = 'AML_PendingRequestWarning')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105896,'AML_PendingRequestWarning',0,'Labels','this customer has pendding request in another branch','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End

--******************************************************************************************************************************************************************
--*************************RulesTranDescriptors*************************************************************************************************************************
--******************************************************************************************************************************************************************
If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'lbl_AML_Cahnnels')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'lbl_AML_Cahnnels','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'lbl_AML_Cahnnels')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'lbl_AML_Cahnnels','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'lbl_AML_Ownership')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'lbl_AML_Ownership','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'lbl_CustSearch_Branch','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'lbl_CustSearch_Branch','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'lbl_CustSearch_Branch','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'AML_PendingRequestWarning')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AML_PendingRequestWarning','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'AML_PendingRequestWarning')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'AML_PendingRequestWarning','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End


If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_SECOND_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_SECOND_NAME','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_TINFormat')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_TINFormat','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

--******************************************************************************************************************************************************************
--*************************RulesTranField_ex*************************************************************************************************************************
--******************************************************************************************************************************************************************
IF NOT EXISTS(select * from RulesTranField_ex where TranID =  547 and FieldIDInPage = 'cbo_AMLCahnnels')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 547 , '' , 'Teller' , 'cbo_AMLCahnnels' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLCahnnels')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 565 , '' , 'Teller' , 'cbo_AMLCahnnels' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLOwnership')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 565 , '' , 'Teller' , 'cbo_AMLOwnership' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_CustSearchBranch')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 565 , '' , 'Teller' , 'cbo_CustSearchBranch' , -1 , -1 , -1 , 1 , 1 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END

 IF NOT EXISTS(select * from RulesTranField_ex where TranID =  547 and FieldIDInPage = 'cbo_CustSearchBranch')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 547 , '' , 'Teller' , 'cbo_CustSearchBranch' , -1 , -1 , -1 , 1 , 1 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  534 and FieldIDInPage = 'cbo_AMLAccountType')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 534 , '' , 'Teller' , 'cbo_AMLAccountType' , -1 , -1 , -1 , 0 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[19/05/2021]		
--Reason	:	Enh GFSY00849 - BARWA - ACM19131- KYC Enhancement
--===============================================================
PRINT 'Start. Script for CR# GFSY00849 DML Script'
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLStrings Where AccessID = 1100107)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100107,'SelectEmployeeName','p',1,'Globalfs','dbo.SelectEmployeeName',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','select employee name from table ad_gb_rsm using employee_id',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105898)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105898,'TLR_CANNOTGETEMPLOYEENAME',0,'Labels','Cannot get current employee name  \r Are you want to continue?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105898 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105898,1025,N'لا يمكن الحصول على اسم الموظف الحالي \ r هل تريد المتابعة؟','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105899)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105899,'Static_PL_555_1',0,'Labels','Cash / Transfers / Cheques / ATM','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105899 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105899,1025,N'النقد / التحويلات / الشيكات / أجهزة الصراف الآلي','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105900)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105900,'Static_PL_555_2',0,'Labels','Private Banking Services','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105900 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105900,1025,N'الخدمات المصرفية الخاصة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105901)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105901,'Static_PL_555_3',0,'Labels','Wealth Management Products','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105901 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105901,1025,N'منتجات إدارة الثروات','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105902)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105902,'Static_PL_555_4',0,'Labels','Salary Transfer','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105902 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105902,1025,N'تحويل الراتب','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105903)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105903,'Static_PL_555_5',0,'Labels','Personal Finance','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105903 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105903,1025,N'تمويل شخصي','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105904)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105904,'Static_PL_555_6',0,'Labels','Saving Account / Time Deposits','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105904 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105904,1025,N'حساب التوفير / الودائع لأجل','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105905)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105905,'Static_PL_555_7',0,'Labels','RIM only (without account)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105905 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105905,1025,N'RIM فقط (بدون حساب)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105906)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105906,'Static_PL_570_1',0,'Labels','Business Activities - Cash/Transfers/Cheques','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105906 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105906,1025,N'الأنشطة التجارية - النقد / التحويلات / الشيكات','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105907)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105907,'Static_PL_570_2',0,'Labels','Trade Finance (LC/LG)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105907 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105907,1025,N'تمويل التجارة (LC / LG)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105908)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105908,'Static_PL_570_3',0,'Labels','Correspondent Banking Services','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105908 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105908,1025,N'خدمات البنوك المراسلة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105909)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105909,'Static_PL_570_4',0,'Labels','Time Deposits','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105909 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105909,1025,N'الوقت دفع','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105910)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105910,'Static_PL_570_5',0,'Labels','RIM only (without account)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105910 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105910,1025,N'RIM فقط (بدون حساب)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105912)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105912,'Static_PL_573_1',0,'Labels','Both','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105912 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105912,1025,N'كلاهما','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105913)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105913,'Static_PL_573_2',0,'Labels','Complex','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105913 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105913,1025,N'معقد','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105914)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105914,'Static_PL_573_3',0,'Labels','Direct','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105914 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105914,1025,N'مباشر','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105915)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105915,'Static_PL_573_4',0,'Labels','Indirect','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105915 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105915,1025,N'غير مباشر','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105916)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105916,'Static_PL_571_1',0,'Labels','Non-Face to Face (E-Banking/Mobile Banking/ATM)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105916 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105916,1025,N'غير وجهًا لوجه (الخدمات المصرفية الإلكترونية / الخدمات المصرفية عبر الهاتف المحمول / ماكينة الصراف الآلي)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105917)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105917,'Static_PL_571_2',0,'Labels','Face to Face (Branch Services)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105917 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105917,1025,N'وجها لوجه (خدمات الفروع)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105918)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105918,'Static_PL_571_3',0,'Labels','Third Party (Including gatekeepers)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105918 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105918,1025,N'الطرف الثالث (بما في ذلك حراس البوابة)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105919)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105919,'Static_PL_572_1',0,'Labels','Non-Face to Face (E-Banking/Mobile Banking/ATM)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105919 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105919,1025,N'غير وجهًا لوجه (الخدمات المصرفية الإلكترونية / الخدمات المصرفية عبر الهاتف المحمول / ماكينة الصراف الآلي)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105920)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105920,'Static_PL_572_2',0,'Labels','Face to Face (Branch Services)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105920 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105920,1025,N'وجها لوجه (خدمات الفروع)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105921)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105921,'Static_PL_572_3',0,'Labels','Third Party (Including gatekeepers)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105921 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105921,1025,N'الطرف الثالث (بما في ذلك حراس البوابة)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
END
GO

----------------------
-- RulesTranField_ex -
----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = '_lbl_AMLSecondName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','_lbl_AMLSecondName',-1,-1,-1,0,0,'TLR_MIDDLE_NAME','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID = '1072' And FieldIDInPage = 'txt_AMLMiddleName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'1072','Teller','txt_AMLMiddleName',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCPRNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','lbl_AMLCPRNumber',-1,-1,-1,0,0,'TLR_CPR_NUMBER','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID = '146' And FieldIDInPage = 'txt_AMLCPRNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'146','Teller','txt_AMLCPRNumber',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'grp_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','grp_AMLTINFormat',-1,-1,-1,0,0,'TLR_TINFormat','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID = '1217' And FieldIDInPage = 'opt_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'1217','Teller','opt_AMLTINFormat',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * FROM RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','lbl_AMLCahnnels',-1,-1,-1,0,0,'lbl_AML_Cahnnels','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'cbo_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','cbo_AMLCahnnels',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'Chkbox_AMLJointRim')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','Chkbox_AMLJointRim',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCommercialRegistrationNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','lbl_AMLCommercialRegistrationNumber',-1,-1,-1,0,0,'TLR_RONP_CR_COMM_NO','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID = '146' And FieldIDInPage = 'txt_AMLCommercialRegistrationNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'146','Teller','txt_AMLCommercialRegistrationNumber',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'grp_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','grp_AMLTINFormat',-1,-1,-1,0,0,'TLR_TINFormat','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID = '1217' And FieldIDInPage = 'opt_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'1217','Teller','opt_AMLTINFormat',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * FROM RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','lbl_AMLCahnnels',-1,-1,-1,0,0,'lbl_AML_Cahnnels','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'cbo_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','cbo_AMLCahnnels',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * FROM RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLOwnership')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','lbl_AMLOwnership',-1,-1,-1,0,0,'lbl_AML_Ownership','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'cbo_AMLOwnership')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','cbo_AMLOwnership',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

---------------------
-- PickList_Entries -
---------------------
If Exists(Select * From PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Products'))
Begin
 DELETE FROM PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Products')
End
GO

If Exists(Select * From PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Products'))
Begin
 DELETE FROM PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Products')
End
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Products'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_555_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_555_2','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_555_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,3,'Static_PL_555_4','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 4)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,4,'Static_PL_555_5','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 5)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,5,'Static_PL_555_6','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 6)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,6,'Static_PL_555_7','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Products'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_570_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_570_2','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_570_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,3,'Static_PL_570_4','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 4)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,4,'Static_PL_570_5','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Ownership'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_573_1','Both',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_573_2','Complex',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_573_3','Direct',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,3,'Static_PL_573_4','Indirect',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Channels'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_571_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_571_2','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_571_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Channels'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_572_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_572_2','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_572_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

PRINT 'End... Script for CR# GFSY00849 DML Script'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[20/01/2021]		
--Reason	:	Issue GFSX14415
--=============================
PRINT 'Start. Script for Issue# GFSX14415 DML Script'
GO
 
---------------------
-- RulesDescriptor --
---------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105859)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105859,'TLR_IR_POSTWITHOUTCHECKPOST',0,'Labels','There are some message are checked without taking action post on them','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105859 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105859,1025,N'هناك بعض الرسائل يتم فحصها دون اتخاذ إجراء بشأنها','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105860)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105860,'TLR_IR_POSTWITHOUTCHECKREVERSE',0,'Labels','There are some message are checked without taking action reverse on them','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105860 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105860,1025,N'هناك بعض الرسائل يتم فحصها دون اتخاذ إجراء عكسي بشأنها','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLstrings Where AccessID = 1100098)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100098,'TLR_OV_UPDATEISPROCESSING','p',0,'Globalfs','dbo.TLR_OV_UpdateIsProcessing',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','It updates the flag of IsProcessing according current state of Override Request',1,' ','',0,0,1,NULL,NULL,0,0,0,0,0)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100100)
BEGIN
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100100,'CheckIRMessagesStatus','p',0,'Globalfs','dbo.CheckIRMessagesStatus',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Check the IR messages status before posting the transaction InwardTransfersHOSwiftProcess',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

PRINT 'End... Script for Issue# GFSX14415 DML Script'
GO
--==================================================================================================================================================================
-- =============================================
-- Author:		Ibrahim Harby 
-- Create date: 17-june-2021
-- Description:	 CR# GFSX14597
-- =============================================
IF  EXISTS(SELECT * FROM sys.tables where name = 'TT_Remitter')
	begin
	ALTER TABLE TT_Remitter
	ALTER COLUMN Remitter_Name nvarchar(200);
	end
go
Go
update PickLists set PickList_Name = 'TLR_AML_Personal_Products'   where picklist_name = 'TLR_AML_Products' 
--******************************************************************************************************************************************************************
--*************************PickLists********************************************************************************************************************************
--******************************************************************************************************************************************************************
IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 570)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,570,'TLR_AML_NonPersonal_Products')
	END

IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 571)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,571,'TLR_AML_Personal_Channels')
	END

IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 572)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,572,'TLR_AML_NonPersonal_Channels')
	END		

IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 573)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,573,'TLR_AML_NonPersonal_Ownership')
	END	

--******************************************************************************************************************************************************************
--*************************RulesDescriptor*************************************************************************************************************************
--******************************************************************************************************************************************************************
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105019)
Begin
Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
Values (1,1105019,'TLR_SECOND_NAME',0,'Labels','Second Name','ITSOFT\mahmoud.saad','Feb 8 2018 1:19PM',1,'Jan 1 1901 12:00AM','Dec 31 9998 12:00AM','Feb 8 2018 1:18PM',N'ITSOFT\mahmoud.saad')
End
go

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105892 and Name = 'lbl_AML_Cahnnels')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105892,'lbl_AML_Cahnnels',0,'Labels','Channels','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105893 and Name = 'lbl_AML_Ownership')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105893,'lbl_AML_Ownership',0,'Labels','Ownership','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105895 and Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105895,'lbl_CustSearch_Branch',0,'Labels','Branch','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105896 and Name = 'AML_PendingRequestWarning')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105896,'AML_PendingRequestWarning',0,'Labels','this customer has pendding request in another branch','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End

--******************************************************************************************************************************************************************
--*************************RulesTranDescriptors*************************************************************************************************************************
--******************************************************************************************************************************************************************
If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'lbl_AML_Cahnnels')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'lbl_AML_Cahnnels','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'lbl_AML_Cahnnels')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'lbl_AML_Cahnnels','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'lbl_AML_Ownership')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'lbl_AML_Ownership','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'lbl_CustSearch_Branch','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'lbl_CustSearch_Branch','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'lbl_CustSearch_Branch','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'AML_PendingRequestWarning')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AML_PendingRequestWarning','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'AML_PendingRequestWarning')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'AML_PendingRequestWarning','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End


If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_SECOND_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_SECOND_NAME','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_TINFormat')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_TINFormat','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

--******************************************************************************************************************************************************************
--*************************RulesTranField_ex*************************************************************************************************************************
--******************************************************************************************************************************************************************
IF NOT EXISTS(select * from RulesTranField_ex where TranID =  547 and FieldIDInPage = 'cbo_AMLCahnnels')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 547 , '' , 'Teller' , 'cbo_AMLCahnnels' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLCahnnels')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 565 , '' , 'Teller' , 'cbo_AMLCahnnels' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLOwnership')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 565 , '' , 'Teller' , 'cbo_AMLOwnership' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_CustSearchBranch')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 565 , '' , 'Teller' , 'cbo_CustSearchBranch' , -1 , -1 , -1 , 1 , 1 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END

 IF NOT EXISTS(select * from RulesTranField_ex where TranID =  547 and FieldIDInPage = 'cbo_CustSearchBranch')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 547 , '' , 'Teller' , 'cbo_CustSearchBranch' , -1 , -1 , -1 , 1 , 1 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  534 and FieldIDInPage = 'cbo_AMLAccountType')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 534 , '' , 'Teller' , 'cbo_AMLAccountType' , -1 , -1 , -1 , 0 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[19/05/2021]		
--Reason	:	Enh GFSY00849 - BARWA - ACM19131- KYC Enhancement
--===============================================================
PRINT 'Start. Script for CR# GFSY00849 DML Script'
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLStrings Where AccessID = 1100107)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100107,'SelectEmployeeName','p',1,'Globalfs','dbo.SelectEmployeeName',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','select employee name from table ad_gb_rsm using employee_id',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105898)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105898,'TLR_CANNOTGETEMPLOYEENAME',0,'Labels','Cannot get current employee name  \r Are you want to continue?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105898 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105898,1025,N'لا يمكن الحصول على اسم الموظف الحالي \ r هل تريد المتابعة؟','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105899)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105899,'Static_PL_555_1',0,'Labels','Cash / Transfers / Cheques / ATM','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105899 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105899,1025,N'النقد / التحويلات / الشيكات / أجهزة الصراف الآلي','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105900)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105900,'Static_PL_555_2',0,'Labels','Private Banking Services','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105900 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105900,1025,N'الخدمات المصرفية الخاصة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105901)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105901,'Static_PL_555_3',0,'Labels','Wealth Management Products','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105901 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105901,1025,N'منتجات إدارة الثروات','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105902)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105902,'Static_PL_555_4',0,'Labels','Salary Transfer','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105902 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105902,1025,N'تحويل الراتب','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105903)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105903,'Static_PL_555_5',0,'Labels','Personal Finance','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105903 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105903,1025,N'تمويل شخصي','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105904)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105904,'Static_PL_555_6',0,'Labels','Saving Account / Time Deposits','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105904 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105904,1025,N'حساب التوفير / الودائع لأجل','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105905)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105905,'Static_PL_555_7',0,'Labels','RIM only (without account)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105905 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105905,1025,N'RIM فقط (بدون حساب)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105906)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105906,'Static_PL_570_1',0,'Labels','Business Activities - Cash/Transfers/Cheques','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105906 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105906,1025,N'الأنشطة التجارية - النقد / التحويلات / الشيكات','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105907)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105907,'Static_PL_570_2',0,'Labels','Trade Finance (LC/LG)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105907 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105907,1025,N'تمويل التجارة (LC / LG)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105908)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105908,'Static_PL_570_3',0,'Labels','Correspondent Banking Services','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105908 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105908,1025,N'خدمات البنوك المراسلة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105909)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105909,'Static_PL_570_4',0,'Labels','Time Deposits','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105909 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105909,1025,N'الوقت دفع','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105910)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105910,'Static_PL_570_5',0,'Labels','RIM only (without account)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105910 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105910,1025,N'RIM فقط (بدون حساب)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105912)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105912,'Static_PL_573_1',0,'Labels','Both','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105912 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105912,1025,N'كلاهما','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105913)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105913,'Static_PL_573_2',0,'Labels','Complex','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105913 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105913,1025,N'معقد','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105914)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105914,'Static_PL_573_3',0,'Labels','Direct','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105914 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105914,1025,N'مباشر','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105915)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105915,'Static_PL_573_4',0,'Labels','Indirect','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105915 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105915,1025,N'غير مباشر','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105916)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105916,'Static_PL_571_1',0,'Labels','Non-Face to Face (E-Banking/Mobile Banking/ATM)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105916 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105916,1025,N'غير وجهًا لوجه (الخدمات المصرفية الإلكترونية / الخدمات المصرفية عبر الهاتف المحمول / ماكينة الصراف الآلي)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105917)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105917,'Static_PL_571_2',0,'Labels','Face to Face (Branch Services)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105917 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105917,1025,N'وجها لوجه (خدمات الفروع)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105918)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105918,'Static_PL_571_3',0,'Labels','Third Party (Including gatekeepers)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105918 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105918,1025,N'الطرف الثالث (بما في ذلك حراس البوابة)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105919)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105919,'Static_PL_572_1',0,'Labels','Non-Face to Face (E-Banking/Mobile Banking/ATM)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105919 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105919,1025,N'غير وجهًا لوجه (الخدمات المصرفية الإلكترونية / الخدمات المصرفية عبر الهاتف المحمول / ماكينة الصراف الآلي)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105920)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105920,'Static_PL_572_2',0,'Labels','Face to Face (Branch Services)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105920 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105920,1025,N'وجها لوجه (خدمات الفروع)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105921)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105921,'Static_PL_572_3',0,'Labels','Third Party (Including gatekeepers)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105921 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105921,1025,N'الطرف الثالث (بما في ذلك حراس البوابة)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
END
GO

----------------------
-- RulesTranField_ex -
----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = '_lbl_AMLSecondName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','_lbl_AMLSecondName',-1,-1,-1,0,0,'TLR_MIDDLE_NAME','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID = '1072' And FieldIDInPage = 'txt_AMLMiddleName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'1072','Teller','txt_AMLMiddleName',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCPRNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','lbl_AMLCPRNumber',-1,-1,-1,0,0,'TLR_CPR_NUMBER','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID = '146' And FieldIDInPage = 'txt_AMLCPRNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'146','Teller','txt_AMLCPRNumber',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'grp_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','grp_AMLTINFormat',-1,-1,-1,0,0,'TLR_TINFormat','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID = '1217' And FieldIDInPage = 'opt_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'1217','Teller','opt_AMLTINFormat',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * FROM RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','lbl_AMLCahnnels',-1,-1,-1,0,0,'lbl_AML_Cahnnels','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'cbo_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','cbo_AMLCahnnels',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'Chkbox_AMLJointRim')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','Chkbox_AMLJointRim',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCommercialRegistrationNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','lbl_AMLCommercialRegistrationNumber',-1,-1,-1,0,0,'TLR_RONP_CR_COMM_NO','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID = '146' And FieldIDInPage = 'txt_AMLCommercialRegistrationNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'146','Teller','txt_AMLCommercialRegistrationNumber',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'grp_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','grp_AMLTINFormat',-1,-1,-1,0,0,'TLR_TINFormat','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID = '1217' And FieldIDInPage = 'opt_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'1217','Teller','opt_AMLTINFormat',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * FROM RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','lbl_AMLCahnnels',-1,-1,-1,0,0,'lbl_AML_Cahnnels','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'cbo_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','cbo_AMLCahnnels',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * FROM RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLOwnership')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','lbl_AMLOwnership',-1,-1,-1,0,0,'lbl_AML_Ownership','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'cbo_AMLOwnership')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','cbo_AMLOwnership',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

---------------------
-- PickList_Entries -
---------------------
If Exists(Select * From PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Products'))
Begin
 DELETE FROM PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Products')
End
GO

If Exists(Select * From PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Products'))
Begin
 DELETE FROM PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Products')
End
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Products'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_555_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_555_2','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_555_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,3,'Static_PL_555_4','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 4)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,4,'Static_PL_555_5','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 5)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,5,'Static_PL_555_6','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 6)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,6,'Static_PL_555_7','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Products'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_570_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_570_2','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_570_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,3,'Static_PL_570_4','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 4)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,4,'Static_PL_570_5','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Ownership'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_573_1','Both',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_573_2','Complex',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_573_3','Direct',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,3,'Static_PL_573_4','Indirect',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Channels'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_571_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_571_2','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_571_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Channels'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_572_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_572_2','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_572_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

PRINT 'End... Script for CR# GFSY00849 DML Script'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/03/2021]		
--Reason	:	Issue GFSX14469
--=============================
PRINT 'Start. Script for Issue# GFSX14469 DML Script'
GO

---------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal --
---------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105867)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105867,'TLR_IR_MSG_MARKED_UPDATE',0,'Labels','Cannot update this message because its marked as used by another teller','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105867 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105867,1025,N'لا يمكن تحديث هذه الرسالة لأنها تم تعليمها على أنها مستخدمة من قبل صراف آخر','ITSOFT\ahmed.orashed','Jan 14 2019 10:23AM',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105868)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105868,'TLR_IR_MSG_MARKED_POST',0,'Labels','You cannot post message with ref no "{0}" because its marked as used by another teller','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105868 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105868,1025,N'لا يمكنك إرسال رسالة بالمرجع no "{0}" لأنه تم تمييزها على أنها مستخدم بواسطة صراف آخر','ITSOFT\ahmed.orashed','Jan 14 2019 10:23AM',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105869)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105869,'TLR_IR_MSG_MARKED_REVERSE',0,'Labels','You cannot reverse the message with ref no "{0}" because it is marked as used by another teller','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105869 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105869,1025,N'لا يمكنك عكس الرسالة ذات المرجع "{0}" لأنه تم تعليمها على أنها مستخدمة من قبل صراف آخر','ITSOFT\ahmed.orashed','Jan 14 2019 10:23AM',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105870)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105870,'TLR_IR_MSG_MARKED_REJECT',0,'Labels','Cannot reject this message because its marked as used by another teller','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105870 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105870,1025,N'لا يمكن رفض هذه الرسالة لأنها تم تعليمها على أنها مستخدمة من قبل صراف آخر','ITSOFT\ahmed.orashed','Jan 14 2019 10:23AM',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105871)
BEGIN
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105871,'TLR_IR_MSG_MARKED_MOVE_AQ',0,'Labels','Cannot move this message to approved queue because its marked as used by another teller','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105871 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105871,1025,N'لا يمكن نقل هذه الرسالة إلى قائمة انتظار معتمدة لأنها تم تعليمها على أنها مستخدمة بواسطة صراف آخر','ITSOFT\ahmed.orashed','Jan 14 2019 10:23AM',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105872)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105872,'TLR_IR_MSG_MARKED_MOVE_EQ',0,'Labels','Cannot move this message to exception queue because its marked as used by another teller','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105872 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105872,1025,N'لا يمكن نقل هذه الرسالة إلى قائمة انتظار الاستثناءات لأنها تم تعليمها على أنها مستخدمة بواسطة صراف آخر','ITSOFT\ahmed.orashed','Jan 14 2019 10:23AM',N'ITSOFT\ahmed.orashed')
End
GO

-----------------------
-- RulesTranField_ex --
-----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 862 And FieldID Is Null  And FieldIDInPage = '_grd_Messages_Column_MarkedAsUsed')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (862,NULL,'Teller','_grd_Messages_Column_MarkedAsUsed',-1,-1,-1,0,0,'','','','Sep 24 2020  2:43PM',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLstrings Where AccessID = 1100102)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100102,'TLR_MARKIRMSGASUSED','p',0,'Globalfs','dbo.MarkIRMessagesAsUsed',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Mark the IR messages as used by teller or not based on sent flag @Mark',1,' ','',0,0,1,NULL,NULL,0,0,0,0,0)
End
GO

PRINT 'End... Script for Issue# GFSX14469 DML Script'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{19/06/2021}	
--Reason	:	Issue GFSX14603
--====================================================

PRINT 'Start. Script for Issue# GFSX14603 DML Script'
GO

---------------
-- SQLstrings -
---------------
If Not Exists(Select * From SQLstrings Where AccessID = 1100105)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100105,'ChangeOverrideStatus','p',0,'Globalfs','dbo.ChangeOverrideRequestAndReasons',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Change Override Request And Reasons',1,' ','',0,0,1,NULL,NULL,0,0,0,0,0)
End
GO

PRINT 'End... Script for Issue# GFSX14603 DML Script'
GO
--==================================================================================================================================================================
If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_CS_TranType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_CS_TranType','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
GO
--------------------------------
-- RulesParam -------------------
---------------------------------
DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'PostSetupChargesXAPI')
    BEGIN
        INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
        VALUES (@paramID,'PostSetupChargesXAPI','To check if setup charges will be sent with TPI or with XAPI if true so charges will be sent by XAPI, if false charges will be sent by TPI',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.eliwa',1)
    END
	Begin
	SELECT @paramID =  MAX(ParamID) FROM RulesParam WHERE ParamName = 'PostSetupChargesXAPI'
        IF NOT EXISTS(Select * From RulesParamValue Where ParamID = @paramID And ParamValue = 'True')
            BEGIN
                INSERT INTO RulesParamValue(ParamID,ParamValue,UPdator)
                VALUES (@paramID,N'True',N'ITSOFT\ahmed.eliwa')
            END
        IF NOT EXISTS(SELECT * FROM RulesParamValue WHERE ParamID = @paramID And ParamValue = 'False')
            BEGIN 
                INSERT INTO RulesParamValue(ParamID,ParamValue,UPdator)
                VALUES (@paramID,N'False',N'ITSOFT\ahmed.eliwa')
            END
	 END
GO

---------------------------------
-- RulesTranFldParam ------------
---------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'AddNewSO' AND FieldName = 'PostSetupCharges' AND Param = 'PostSetupChargesXAPI')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('AddNewSO','PostSetupCharges','PostSetupChargesXAPI','false',N'ITSOFT\ahmed.eliwa','bit',NULL)
END
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[07/10/2020]		
--Reason	:	Enh GFSY00860 - BARWA - ACM19723 - General Enhancement III
--========================================================================
PRINT 'Start. Script for CR# GFSY00860 DML Script'
GO

----------------
-- RulesParam --
----------------
DECLARE @paramID int
SELECT @paramID = MAX(ISNULL(ParamID , 0)) + 1 FROM RulesParam
If Not Exists(Select * From RulesParam Where ParamName = 'Check202CovWithCurrency')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
 Values (@paramID,'Check202CovWithCurrency','in case one of this param values is equal TT currency, by default set Attach 202Cov flag as check, entere values separated by comma',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
End
GO

-----------------------
-- RulesTranFldParam --
-----------------------
If Not Exists(Select * From RulesTranFldParam Where TranName = 'IssueTTAgainstAccount' And FieldName = 'TTCurrency' And Param = 'Check202CovWithCurrency')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('IssueTTAgainstAccount','TTCurrency','Check202CovWithCurrency','',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'IssueTTAgainstGL' And FieldName = 'TTCurrency' And Param = 'Check202CovWithCurrency')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('IssueTTAgainstGL','TTCurrency','Check202CovWithCurrency','',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

-----------------------
-- RulesTranField_ex --
-----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 862 And FieldID Is Null  And FieldIDInPage = '_grd_Messages_Column_LocalEquivalentTTAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (862,NULL,'Teller','_grd_Messages_Column_LocalEquivalentTTAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO


PRINT 'End... Script for CR# GFSY00860 DML Script'
GO
--==================================================================================================================================================================

-- GetDPAcctInfoWithCustInfo
declare @sID int
set @sID = (select top 1 ServiceId from HostCoreService  where ServiceName='GetDPAcctInfoWithCustInfo')
if @sID is null
Begin
	select 'GetDPAcctInfoWithCustInfo HostCoreService must be exist';
End
else if @sID is not null
Begin
declare @maxID int
set @maxID = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  * From HostCoreServiceFields Where ServiceId = @sID and FieldName='PaymentType')
	Begin
		 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		 Values (@sID,@maxID,'PaymentType','varchar',0,0,null,'O')
	End
End
go
--***************************************************************************************
--***************************************************************************************
-- ListDepositAccountClasses
declare @sID int
set @sID = (select top 1 ServiceId from HostCoreService  where ServiceName='ListDepositAccountClasses')
if @sID is null
Begin
	select 'ListDepositAccountClasses HostCoreService must be exist';
End
else if @sID is not null
Begin
declare @maxID int
set @maxID = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  * From HostCoreServiceFields Where ServiceId = @sID and FieldName='PaymentType')
	Begin
		 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		 Values (@sID,@maxID,'PaymentType','varchar',999,0,null,'O')
	End
End
go
--***************************************************************************************
--***************************************************************************************
-- GetAccountClosureInfo
declare @sID int
set @sID = (select top 1 ServiceId from HostCoreService  where ServiceName='GetAccountClosureInfo')
if @sID is null
Begin
	select 'GetAccountClosureInfo HostCoreService must be exist';
End
else if @sID is not null
Begin
declare @maxID int
set @maxID = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  * From HostCoreServiceFields Where ServiceId = @sID and FieldName='OutPrincipleCloseAmt')
	Begin
		 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		 Values (@sID,@maxID,'OutPrincipleCloseAmt','decimal',0,0,null,'O')
	End
End


Begin
declare @maxID2 int
set @maxID2 = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  * From HostCoreServiceFields Where ServiceId = @sID and FieldName='OutDifferanceinRateAmt')
	Begin
		 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		 Values (@sID,@maxID2,'OutDifferanceinRateAmt','decimal',0,0,null,'O')
	End
End



Begin
declare @maxID3 int
set @maxID3 = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  * From HostCoreServiceFields Where ServiceId = @sID and FieldName='OutPenaltyAmt')
	Begin
		 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		 Values (@sID,@maxID3,'OutPenaltyAmt','decimal',0,0,null,'O')
	End
End


Begin
declare @maxID4 int
set @maxID4 = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  * From HostCoreServiceFields Where ServiceId = @sID and FieldName='OutProfitINAdvanceAmt')
	Begin
		 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		 Values (@sID,@maxID4,'OutProfitINAdvanceAmt','decimal',0,0,null,'O')
	End
End


Begin
declare @maxID5 int
set @maxID5 = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  * From HostCoreServiceFields Where ServiceId = @sID and FieldName='OutProfitExpenseInterfaceGL')
	Begin
		 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		 Values (@sID,@maxID5,'OutProfitExpenseInterfaceGL','nvarchar',0,0,null,'O')
	End
End


Begin
declare @maxID6 int
set @maxID6 = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  * From HostCoreServiceFields Where ServiceId = @sID and FieldName='OutPenaltyGL')
	Begin
		 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		 Values (@sID,@maxID6,'OutPenaltyGL','nvarchar',0,0,null,'O')
	End
End


Begin
declare @maxID7 int
set @maxID7 = (select MAX(FieldId)+1 from HostCoreServiceFields where ServiceId= @sID )
If Not Exists(Select  * From HostCoreServiceFields Where ServiceId = @sID and FieldName='OutProfitINAdvanceInterfaceGL')
	Begin
		 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
		 Values (@sID,@maxID7,'OutProfitINAdvanceInterfaceGL','nvarchar',0,0,null,'O')
	End
End
go




--***************************************************************************************
--***************************************************************************************

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1806)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID)
 Values (1806,'INVALID_DATE_FOR_CLASS','Open Date Cannot be Backdated for This Class','Open Date Cannot be Backdated for This Class',4,'ErrDesc.hlp',1)
End
go

--***************************************************************************************
--***************************************************************************************
IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'DPAccountEdit' AND  Error_Name   = 'INVALID_DATE_FOR_CLASS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'DPAccountEdit'  ,  'INVALID_DATE_FOR_CLASS'   )
END 
GO
--***************************************************************************************
--***************************************************************************************
IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'DPAccountOpening' AND  Error_Name   = 'INVALID_DATE_FOR_CLASS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'DPAccountOpening'  ,  'INVALID_DATE_FOR_CLASS'   )
END 
GO


-------------------------------------------------------------------
-------------------RulesTranField For Account Closure--------------
-------------------------------------------------------------------
-------------------------------------------------------------------

If Not Exists(Select * From RulesTranField Where TranID = 360 And FieldID = -1099991) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (360,-1099991,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 360 And FieldID = -1099990) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (360,-1099990,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 360 And FieldID = -19994) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (360,-19994,1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 360 And FieldID = -19976) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (360,-19976,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 360 And FieldID = 452) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (360,452,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 360 And FieldID = 453) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (360,453,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 360 And FieldID = 454) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (360,454,1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 360 And FieldID = 520) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (360,520,1)
End
go

-------------------------------------------------------------------
-----------RulesTranField For Fixed Deposit -----------------------
-------------------------------------------------------------------
-------------------------------------------------------------------


If Not Exists(Select * From RulesTranField Where TranID = 245 And FieldID = -1099991) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (245,-1099991,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 245 And FieldID = -1099990) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (245,-1099990,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 245 And FieldID = -19994) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (245,-19994,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 245 And FieldID = -19976) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (245,-19976,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 245 And FieldID = 452) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (245,452,1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 245 And FieldID = 453) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (245,453,1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 245 And FieldID = 454) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (245,454,1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 245 And FieldID = 520) 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (245,520,1)
End
go



If Not Exists(select * From RulesDescriptor Where DescriptorID = 1105891)
BEGIN
 Insert Into RulesDescriptor(AppID	,DescriptorID	,Name	,forVB	,TypeName	,Descriptor	,Creator	)
 Values (1,	1105891	,'TLR_Advance_Profit_Amt'	,0	,'Labels',	'In Advance Profit Amount'	,'ITSOFT\ibrahim.harby'	)
END
GO


If Not Exists(Select * From RulesDescriptorlOCAL Where DescriptorID = 1105891 And LCID = 1025)
BEGIN
 Insert Into RulesDescriptorlOCAL(DescriptorID,LCID,LocalDescription,Creator)
 Values (1105891,1025,N'مبلغ الربح مقدما','ITSOFT\ibrahim.harby')
END
GO


If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1806 And LanguageLCID = 1025)
BEGIN
 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
 Values (1806,1025,N'تاريخ الفتح لا يمكن ان يكون تاريخ قديم',N'تاريخ الفتح لا يمكن ان يكون تاريخ قديم')
END
GO

Go
update PickLists set PickList_Name = 'TLR_AML_Personal_Products'   where picklist_name = 'TLR_AML_Products' 
--******************************************************************************************************************************************************************
--*************************PickLists********************************************************************************************************************************
--******************************************************************************************************************************************************************
IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 570)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,570,'TLR_AML_NonPersonal_Products')
	END

IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 571)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,571,'TLR_AML_Personal_Channels')
	END

IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 572)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,572,'TLR_AML_NonPersonal_Channels')
	END		

IF NOT EXISTS(SELECT * FROM PickLists WHERE PickListID = 573)
	BEGIN
		INSERT INTO PickLists(AppID,PickListID,PickList_Name)
		VALUES (1,573,'TLR_AML_NonPersonal_Ownership')
	END	

--******************************************************************************************************************************************************************
--*************************RulesDescriptor*************************************************************************************************************************
--******************************************************************************************************************************************************************
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105019)
Begin
Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
Values (1,1105019,'TLR_SECOND_NAME',0,'Labels','Second Name','ITSOFT\mahmoud.saad','Feb 8 2018 1:19PM',1,'Jan 1 1901 12:00AM','Dec 31 9998 12:00AM','Feb 8 2018 1:18PM',N'ITSOFT\mahmoud.saad')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105019 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105019,1025,N'الاسم الثاني','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105892 and Name = 'lbl_AML_Cahnnels')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105892,'lbl_AML_Cahnnels',0,'Labels','Channels','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
END
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105892 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105892,1025,N'القنوات','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105893 and Name = 'lbl_AML_Ownership')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105893,'lbl_AML_Ownership',0,'Labels','Ownership','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
END
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105893 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105893,1025,N'ملكية','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105895 and Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105895,'lbl_CustSearch_Branch',0,'Labels','Branch','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
END
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105895 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105895,1025,N'فرع','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105896 and Name = 'AML_PendingRequestWarning')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105896,'AML_PendingRequestWarning',0,'Labels','This customer has pending request in another branch','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
END
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105896 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105896,1025,N'هذا العميل لديه طلب معلق في فرع آخر','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

--******************************************************************************************************************************************************************
--*************************RulesTranDescriptors*************************************************************************************************************************
--******************************************************************************************************************************************************************
If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'lbl_AML_Cahnnels')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'lbl_AML_Cahnnels','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'lbl_AML_Cahnnels')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'lbl_AML_Cahnnels','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'lbl_AML_Ownership')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'lbl_AML_Ownership','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'lbl_CustSearch_Branch','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'lbl_CustSearch_Branch','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'lbl_CustSearch_Branch')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'lbl_CustSearch_Branch','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'AML_PendingRequestWarning')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'AML_PendingRequestWarning','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'AML_PendingRequestWarning')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'AML_PendingRequestWarning','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End


If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_SECOND_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_SECOND_NAME','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_TINFormat')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_TINFormat','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End

--******************************************************************************************************************************************************************
--*************************RulesTranField_ex*************************************************************************************************************************
--******************************************************************************************************************************************************************
IF NOT EXISTS(select * from RulesTranField_ex where TranID =  547 and FieldIDInPage = 'cbo_AMLCahnnels')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 547 , '' , 'Teller' , 'cbo_AMLCahnnels' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLCahnnels')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 565 , '' , 'Teller' , 'cbo_AMLCahnnels' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_AMLOwnership')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 565 , '' , 'Teller' , 'cbo_AMLOwnership' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  565 and FieldIDInPage = 'cbo_CustSearchBranch')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 565 , '' , 'Teller' , 'cbo_CustSearchBranch' , -1 , -1 , -1 , 1 , 1 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END

 IF NOT EXISTS(select * from RulesTranField_ex where TranID =  547 and FieldIDInPage = 'cbo_CustSearchBranch')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 547 , '' , 'Teller' , 'cbo_CustSearchBranch' , -1 , -1 , -1 , 1 , 1 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  534 and FieldIDInPage = 'cbo_AMLAccountType')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 534 , '' , 'Teller' , 'cbo_AMLAccountType' , -1 , -1 , -1 , 0 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
Go

--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[19/05/2021]		
--Reason	:	Enh GFSY00849 - BARWA - ACM19131- KYC Enhancement
--===============================================================
PRINT 'Start. Script for CR# GFSY00849 DML Script'
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLStrings Where AccessID = 1100107)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100107,'SelectEmployeeName','p',1,'Globalfs','dbo.SelectEmployeeName',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','select employee name from table ad_gb_rsm using employee_id',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105898)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105898,'TLR_CANNOTGETEMPLOYEENAME',0,'Labels','Cannot get current employee name  \r Are you want to continue?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105898 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105898,1025,N'لا يمكن الحصول على اسم الموظف الحالي \ r هل تريد المتابعة؟','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105899)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105899,'Static_PL_555_1',0,'Labels','Cash / Transfers / Cheques / ATM','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105899 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105899,1025,N'النقد / التحويلات / الشيكات / أجهزة الصراف الآلي','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105900)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105900,'Static_PL_555_2',0,'Labels','Private Banking Services','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105900 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105900,1025,N'الخدمات المصرفية الخاصة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105901)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105901,'Static_PL_555_3',0,'Labels','Wealth Management Products','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105901 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105901,1025,N'منتجات إدارة الثروات','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105902)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105902,'Static_PL_555_4',0,'Labels','Salary Transfer','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105902 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105902,1025,N'تحويل الراتب','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105903)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105903,'Static_PL_555_5',0,'Labels','Personal Finance','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105903 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105903,1025,N'تمويل شخصي','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105904)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105904,'Static_PL_555_6',0,'Labels','Saving Account / Time Deposits','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105904 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105904,1025,N'حساب التوفير / الودائع لأجل','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105905)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105905,'Static_PL_555_7',0,'Labels','RIM only (without account)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105905 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105905,1025,N'RIM فقط (بدون حساب)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105906)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105906,'Static_PL_570_1',0,'Labels','Business Activities - Cash/Transfers/Cheques','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105906 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105906,1025,N'الأنشطة التجارية - النقد / التحويلات / الشيكات','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105907)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105907,'Static_PL_570_2',0,'Labels','Trade Finance (LC/LG)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105907 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105907,1025,N'تمويل التجارة (LC / LG)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105908)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105908,'Static_PL_570_3',0,'Labels','Correspondent Banking Services','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105908 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105908,1025,N'خدمات البنوك المراسلة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105909)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105909,'Static_PL_570_4',0,'Labels','Time Deposits','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105909 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105909,1025,N'الوقت دفع','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105910)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105910,'Static_PL_570_5',0,'Labels','RIM only (without account)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105910 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105910,1025,N'RIM فقط (بدون حساب)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105912)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105912,'Static_PL_573_1',0,'Labels','Both','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105912 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105912,1025,N'كلاهما','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105913)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105913,'Static_PL_573_2',0,'Labels','Complex','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105913 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105913,1025,N'معقد','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105914)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105914,'Static_PL_573_3',0,'Labels','Direct','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105914 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105914,1025,N'مباشر','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105915)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105915,'Static_PL_573_4',0,'Labels','Indirect','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105915 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105915,1025,N'غير مباشر','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105916)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105916,'Static_PL_571_1',0,'Labels','Non-Face to Face (E-Banking/Mobile Banking/ATM)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105916 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105916,1025,N'غير وجهًا لوجه (الخدمات المصرفية الإلكترونية / الخدمات المصرفية عبر الهاتف المحمول / ماكينة الصراف الآلي)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105917)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105917,'Static_PL_571_2',0,'Labels','Face to Face (Branch Services)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105917 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105917,1025,N'وجها لوجه (خدمات الفروع)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105918)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105918,'Static_PL_571_3',0,'Labels','Third Party (Including gatekeepers)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105918 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105918,1025,N'الطرف الثالث (بما في ذلك حراس البوابة)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105919)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105919,'Static_PL_572_1',0,'Labels','Non-Face to Face (E-Banking/Mobile Banking/ATM)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105919 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105919,1025,N'غير وجهًا لوجه (الخدمات المصرفية الإلكترونية / الخدمات المصرفية عبر الهاتف المحمول / ماكينة الصراف الآلي)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105920)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105920,'Static_PL_572_2',0,'Labels','Face to Face (Branch Services)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105920 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105920,1025,N'وجها لوجه (خدمات الفروع)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105921)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105921,'Static_PL_572_3',0,'Labels','Third Party (Including gatekeepers)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105921 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105921,1025,N'الطرف الثالث (بما في ذلك حراس البوابة)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
END
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105923)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105923,'TLR_OpeningStatus',0,'Labels','Opening Status','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105923 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105923,1025,N'فتح الحالة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
END
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10142)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,-10142,'TLR_IDTYPE',0,'Labels','ID Type','norml','Mar  4 2012 10:41AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Sep 10 2001  4:20PM',N'ITSOFT\halsum')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = -10142 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (-10142,1025,N'نوع معرف الهوية','ITSOFT\mafarouk','May 27 2013  2:12PM',N'ITSOFT\mafarouk')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 190)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,190,'TLR_ID_NUM',0,'Labels','ID Number','GFSDOMAIN\afahim','Mar  4 2012 10:41AM',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','Aug  8 2004  4:12PM',N'ITSOFT\halsum')
End
GO


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 190 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (190,1025,N'رقم معرف الهوية','GFSDOMAIN\mgaber','May 27 2013  2:12PM',N'ITSOFT\mafarouk')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1103904)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1103904,'TLR_AML_RISK_RATING',0,'Labels','AML Risk Rating','ITSOFT\may.hassan','Sep 16 2014 12:39PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Aug  3 2014  1:05PM',N'ITSOFT\may.hassan')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1103904 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1103904,1025,N'AML نسبة مخاطر','ITSOFT\may.hassan','Sep  7 2014 11:36AM',N'ITSOFT\may.hassan')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10196)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,-10196,'TLR_TRANSACTION_TYPE',0,'Labels','Transaction Type','stevem','Mar  4 2012 10:41AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 31 2001  1:42PM',N'ITSOFT\halsum')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = -10196 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (-10196,1025,N'نوع المعاملة','ITSOFT\mafarouk','Oct 13 2011 12:00AM',N'ITSOFT\mafarouk')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105289)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105289,'TLR_RIM_NUMBER',0,'Labels','Rim Number','ITSoft\sara.badwy','Sep 30 2018  9:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Sep 30 2018  9:48AM',N'ITSOFT\sara.badwy')
End
GO



If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105289 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105289,1025,N'رقم العميل','ITSOFT\sara.badwy','Jan 14 2019  4:13PM',N'ITSOFT\sara.badwy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10019)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,-10019,'TLR_ACCOUNTNUMBER',0,'Labels','Account Number','norml','Mar  4 2012 10:41AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 30 2001  3:11PM',N'ITSOFT\halsum')
End
GO


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = -10019 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (-10019,1025,N'رقم الحساب','ITSOFT\mafarouk','Oct 13 2011 12:00AM',N'ITSOFT\mafarouk')
End
go



If Not Exists(Select * From RulesDescriptor Where DescriptorID = 2995)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,2995,'TLR_ACCOUNT_TYPE',0,'Labels','Account Type','GFSDOMAIN\MohamedElMassry','Mar  4 2012 10:41AM',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','Dec  3 2007  7:55PM',N'ITSOFT\halsum')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 2995 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (2995,1025,N'نوع الحساب','ITSOFT\mafarouk','Oct 13 2011 12:00AM',N'ITSOFT\mafarouk')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = -269868)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (26,-269868,'BRANCH_LABEL',0,'Labels','Branch','smiller','Mar  4 2012 10:41AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jun 23 2003  1:14PM',N'ITSOFT\halsum')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = -269868 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (-269868,1025,N'الفرع','ITSOFT\mafarouk','Oct 13 2011 12:00AM',N'ITSOFT\mafarouk')
End
go




----------------------
-- RulesTranField_ex -
----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = '_lbl_AMLSecondName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','_lbl_AMLSecondName',-1,-1,-1,0,0,'TLR_MIDDLE_NAME','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID = '1072' And FieldIDInPage = 'txt_AMLMiddleName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'1072','Teller','txt_AMLMiddleName',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCPRNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','lbl_AMLCPRNumber',-1,-1,-1,0,0,'TLR_CPR_NUMBER','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID = '146' And FieldIDInPage = 'txt_AMLCPRNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'146','Teller','txt_AMLCPRNumber',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'grp_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','grp_AMLTINFormat',-1,-1,-1,0,0,'TLR_TINFormat','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID = '1217' And FieldIDInPage = 'opt_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'1217','Teller','opt_AMLTINFormat',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * FROM RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','lbl_AMLCahnnels',-1,-1,-1,0,0,'lbl_AML_Cahnnels','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'cbo_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','cbo_AMLCahnnels',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldID IS NULL And FieldIDInPage = 'Chkbox_AMLJointRim')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,NULL,'Teller','Chkbox_AMLJointRim',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCommercialRegistrationNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','lbl_AMLCommercialRegistrationNumber',-1,-1,-1,0,0,'TLR_RONP_CR_COMM_NO','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID = '146' And FieldIDInPage = 'txt_AMLCommercialRegistrationNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'146','Teller','txt_AMLCommercialRegistrationNumber',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'grp_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','grp_AMLTINFormat',-1,-1,-1,0,0,'TLR_TINFormat','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID = '1217' And FieldIDInPage = 'opt_AMLTINFormat')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'1217','Teller','opt_AMLTINFormat',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * FROM RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','lbl_AMLCahnnels',-1,-1,-1,0,0,'lbl_AML_Cahnnels','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'cbo_AMLCahnnels')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','cbo_AMLCahnnels',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * FROM RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'lbl_AMLOwnership')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','lbl_AMLOwnership',-1,-1,-1,0,0,'lbl_AML_Ownership','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = 'cbo_AMLOwnership')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','cbo_AMLOwnership',-1,-1,-1,0,0,'','',NULL,N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

---------------------
-- PickList_Entries -
---------------------
If Exists(Select * From PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Products'))
Begin
 DELETE FROM PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Products')
End
GO

If Exists(Select * From PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Products'))
Begin
 DELETE FROM PickList_Entries Where PickListID IN (SELECT PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Products')
End
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Products'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_555_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_555_2','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_555_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,3,'Static_PL_555_4','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 4)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,4,'Static_PL_555_5','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 5)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,5,'Static_PL_555_6','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 6)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,6,'Static_PL_555_7','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Products'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_570_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_570_2','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_570_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,3,'Static_PL_570_4','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 4)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,4,'Static_PL_570_5','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Ownership'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_573_1','Both',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_573_2','Complex',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_573_3','Direct',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,3,'Static_PL_573_4','Indirect',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_Personal_Channels'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_571_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_571_2','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_571_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

DECLARE @PickListID int 
SELECT @PickListID = PickListID FROM PickLists WHERE PickLists.PickList_Name = 'TLR_AML_NonPersonal_Channels'
If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,0,'Static_PL_572_1','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,1,'Static_PL_572_2','LN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END

If Not Exists(Select * From PickList_Entries Where PickListID = @PickListID And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (@PickListID,0,2,'Static_PL_572_3','DP',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
END
GO

PRINT 'End... Script for CR# GFSY00849 DML Script'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[07/10/2020]		
--Reason	:	Enh GFSY00860 - BARWA - ACM19723 - General Enhancement III
--========================================================================
PRINT 'Start. Script for CR# GFSY00860 DML Script'
GO

----------------
-- RulesParam --
----------------
DECLARE @paramID int
SELECT @paramID = MAX(ISNULL(ParamID , 0)) + 1 FROM RulesParam
If Not Exists(Select * From RulesParam Where ParamName = 'Check202CovWithCurrency')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
 Values (@paramID,'Check202CovWithCurrency','in case one of this param values is equal TT currency, by default set Attach 202Cov flag as check, entere values separated by comma',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
End
GO

-----------------------
-- RulesTranFldParam --
-----------------------
If Not Exists(Select * From RulesTranFldParam Where TranName = 'IssueTTAgainstAccount' And FieldName = 'TTCurrency' And Param = 'Check202CovWithCurrency')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('IssueTTAgainstAccount','TTCurrency','Check202CovWithCurrency','',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'IssueTTAgainstGL' And FieldName = 'TTCurrency' And Param = 'Check202CovWithCurrency')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('IssueTTAgainstGL','TTCurrency','Check202CovWithCurrency','',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

-----------------------
-- RulesTranField_ex --
-----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 862 And FieldID Is Null  And FieldIDInPage = '_grd_Messages_Column_LocalEquivalentTTAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (862,NULL,'Teller','_grd_Messages_Column_LocalEquivalentTTAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO


PRINT 'End... Script for CR# GFSY00860 DML Script'
GO
--==================================================================================================================================================================

--*****************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105873 and Name = 'TLR_BioAuth_SmartCardReader')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105873,'TLR_BioAuth_SmartCardReader',0,'Labels','Authenticate Biometric','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105874 and Name = 'lblFingerName')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105874,'lblFingerName',0,'Labels','Finger Name','ITSoft\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa')
End


--*****************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************
If Not Exists(Select * From RulesTranDescriptors Where TranID = 160 And DSC_Name = 'TLR_BioAuth_SmartCardReader')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (160,'TLR_BioAuth_SmartCardReader','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 160 And DSC_Name = 'lblFingerName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (160,'lblFingerName','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesTranDescriptors Where TranID = 162 And DSC_Name = 'TLR_BioAuth_SmartCardReader')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (162,'TLR_BioAuth_SmartCardReader','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 162 And DSC_Name = 'lblFingerName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (162,'lblFingerName','Aug 2 2018 09:48AM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa','Aug 2 2018 09:48AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--*****************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105873 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105873,1025,N'التحقق من البصمه','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105874 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105874,1025,N'اسم الاصبع','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
go
--*****************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************

Go
	
IF NOT EXISTS(select * from RulesTranField_ex where TranID =  160 and FieldIDInPage = 'btnBiometricReader')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 160 , '' , 'Teller' , 'btnBiometricReader' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END
 
IF NOT EXISTS(select * from RulesTranField_ex where TranID =  160 and FieldIDInPage = 'cboFingerIndex')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 160 , '' , 'Teller' , 'cboFingerIndex' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END

	
IF NOT EXISTS(select * from RulesTranField_ex where TranID =  162 and FieldIDInPage = 'btnBiometricReader')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 162 , '' , 'Teller' , 'btnBiometricReader' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END

IF NOT EXISTS(select * from RulesTranField_ex where TranID =  162 and FieldIDInPage = 'cboFingerIndex')
 BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID   , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible, IsReadOnlyConditionId  )  
	SELECT 162 , '' , 'Teller' , 'cboFingerIndex' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\ahmed.eliwa' , 1 ,NULL
 END


--*****************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************
IF EXISTS(select * from SQLstrings where AccessID =  2885)
 BEGIN
 update SQLstrings set AccessString = 'dbo.InsertOrUpdateIDInfoLog' where AccessID = 2885
 END

--*****************************************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************************************
IF NOT EXISTS (select *  from ReaderDeviceClasses where Name = 'EIDABiometric' and Assembly = 'EIDABiometric' and ClassName = 'EIDABiometric')
BEGIN
Insert into ReaderDeviceClasses (Name, Assembly, ClassName, CommPort, BaudRate, Parity, DataBits, StopBits, OtherProperties, Description)
Values ('EIDABiometric','EIDABiometric','EIDABiometric',5, 9600,'N',8,1,'', 'Emirates Identity Authority with Biometric Authentication')
END
GO
--Developer : Mostafa Sayed
--Date       : [19/06/2021]
--Reason     : CR#GFSY00861 - BARWA_ACM19723_General Enhancement III_Part2
--========================================================================
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105911)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105911,N'TLR_SUP_DAY_REQ_SD',0,N'Labels',N'Supervisor Open Day Required')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105911 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105911,1025,N'مطلوب فتح يوم المشرف')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105922)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105922,N'TLR_SUP_DAY_REQ_LD',0,N'Labels',N'This property is used to allow or restrict posting from supervisor side while supervisor day is closed.\r\nFalse: Supervisor open day not required.\r\nTrue: Supervisor open day required.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105922 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105922,1025,N'تُستخدم هذه الخاصية للسماح بالنشر من جانب المشرف أو تقييده أثناء إغلاق يوم المشرف.\r\nخطأ: اليوم المفتوح للمشرف غير مطلوب.\r\nصحيح: مطلوب فتح يوم المشرف.')
END
GO

IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'SupervisorOpenDayRequired')
BEGIN
	EXEC dbo.BANK_CONFIG_INSERT @Name= 'SupervisorOpenDayRequired',@Value = '0',@DataType = 'bit',@ShortDescr = 'TLR_SUP_DAY_REQ_SD',@LongDescr = 'TLR_SUP_DAY_REQ_LD',@MaxVal = '1',@MinVal='0'
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105924)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105924,N'TLR_INVALID_GL_CURR',0,N'Labels',N'Invalid GL Currency')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105924 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105924,1025,N'عملة أ.ع غير صالحة')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=269 AND DSC_Name='TLR_INVALID_GL_CURR')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(269,N'TLR_INVALID_GL_CURR')
END
GO