--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.GetAllOPSRequestsPerUser'
GO 
 
drop_old_proc 'GetAllOPSRequestsPerUser'
GO
create proc dbo.GetAllOPSRequestsPerUser				--GetAllOPSRequestsPerUser 1,1,1,1526,20210622,1033
@BankID			tinyint ,        
@RegionID		tinyint ,        
@BranchID		smallint,        
@UserNumber		int ,        
@BusinessDate   SmallDate,        
@LCID			int  
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	{04/07/2021}		
	Reason		:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
	Description	:	Select all pending transaction, and all today rejected and posted transaction for specific user
*/          

DECLARE @PendingReview_StatusID int
Select @PendingReview_StatusID = id From Status Where StatusTypeID IN (Select id From StatusType Where Description = 'OPSWorkFlow') And ShortDescription = 'PendingReview'

DECLARE @Posted_StatusID int
Select @Posted_StatusID = id From Status Where StatusTypeID IN (Select id From StatusType Where Description = 'OPSWorkFlow') And ShortDescription = 'Posted'

DECLARE @Rejected_StatusID int
Select @Rejected_StatusID = id From Status Where StatusTypeID IN (Select id From StatusType Where Description = 'OPSWorkFlow') And ShortDescription = 'Rejected'

SELECT	RequestID
	  , CASE WHEN RulesDescriptorLocal.LocalDescription IS NULL THEN RulesDescriptor.Descriptor ELSE RulesDescriptorLocal.LocalDescription END AS TransactionName
	  , Amount
	  , Currency
	  , STATUS
	FROM OPSWorkFlow INNER JOIN RulesTranName
		ON OPSWorkFlow.TranName = RulesTranName.TransactionName    
	INNER JOIN RulesDescriptor 
		ON RulesDescriptor.DescriptorID = RulesTranName.DSC_Description  
	LEFT OUTER JOIN RulesDescriptorLocal        
		ON RulesDescriptor.DescriptorID = RulesDescriptorLocal.DescriptorID 
		AND RulesDescriptorLocal.LCID = @LCID
		WHERE	Bank = @BankID 
			AND Region = @RegionID
			AND Branch = @BranchID
			AND Branch_User = @UserNumber
			AND (STATUS = @PendingReview_StatusID OR (STATUS IN (@Posted_StatusID , @Rejected_StatusID) AND BusinessDate = @BusinessDate))
		ORDER BY BusinessDate DESC , RequestID DESC
GO

PRINT 'End... Script for CR# GFSY00865 Proc Script - dbo.GetAllOPSRequestsPerUser'
GO 

go

--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.GetOPS_TranFieldEX'
GO 
 
drop_old_proc 'GetOPS_TranFieldEX'
GO
create proc dbo.GetOPS_TranFieldEX		--	GetOPS_TranFieldEX 'IssueTTAgainstAccount'
@TranName TransactionName
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	{04/07/2021}		
	Reason		:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
	Description	:	Select all data from table OPS_TranField_ex based on tran name
*/          

SELECT OPS_TranField_ex.* 
FROM OPS_TranField_ex INNER JOIN RulesTranName 
	ON OPS_TranField_ex.TranID = RulesTranName.TranID
	WHERE RulesTranName.TransactionName = @TranName
 
GO

PRINT 'End... Script for CR# GFSY00865 Proc Script - dbo.GetOPS_TranFieldEX'
GO 

go
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.GetOPSWorkFlowTrans'
GO 
 
drop_old_proc 'GetOPSWorkFlowTrans'
GO
create proc dbo.GetOPSWorkFlowTrans		--GetOPSWorkFlowTrans 
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	{04/07/2021}		
	Reason		:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
	Description	:	Select all transaction from table OPSWorkFlow based on specify criteria
*/          

SELECT * FROM OPSWorkFlow 
 
GO

PRINT 'End... Script for CR# GFSY00865 Proc Script - dbo.GetOPSWorkFlowTrans'
GO 
go


 --==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	{14/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.GetOPSWorkFlowTrans_Picklists'
GO 
 
drop_old_proc 'GetOPSWorkFlowTrans_Picklists'
GO
create proc dbo.GetOPSWorkFlowTrans_Picklists		--GetOPSWorkFlowTrans_Picklists 
@lcid Int = 0,
@bankID bankid = 0
as        
    
/*    
	Devolper	:	Ibrahim Harby
	Date		:	{14/07/2021}		
	Reason		:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
	Description	:	Select all Piclistest from table OPSWorkFlow based on specify criteria
	StatusTypeID = 77 = OPS workflow status type

*/          


SELECT  R.Name as Region , B.Name as Branch , Currency , TranName , dbo.GetDescriptorByDSC_Name(S.DSC_Name ,@lcid)  as Status , dbo.simple_name_of_LoginID(O.LoginID) as Submitter ,
 OPS.Bank as bankid, OPS.Branch as branchid ,  OPS.Region as regionid , OPS.Status as statusid , OPS.Branch_User as user_number ,dbo.GetDescriptorByDSC_Name( dbo.getDesName(T.DSC_Description) ,@lcid) as tran_description
	FROM OPSWorkFlow as OPS left outer join 
		       Status as S on S.id = OPS.Status 
			  left outer join Region as R on OPS.Region = R.Region 
							             and OPS.Bank = R.Bank 
			  left outer join Branch as B on OPS.branch = B.branch  
										 and OPS.Bank = B.Bank 
										 and OPS.Region = R.Region 
			  left outer join  Operator as O on O.user_number = OPS.branch_user
			  left outer join RulesTranName as T on OPS.tranname = T.transactionName 
			  
    Where S.StatusTypeID = 77 and OPS.Bank = @bankID
 
GO

PRINT 'End... Script for CR# GFSY00865 Proc Script - dbo.GetOPSWorkFlowTrans_Picklists'
GO 

 go
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.GetTranNameDescriptor'
GO 
 
drop_old_proc 'GetTranNameDescriptor'
GO
create proc dbo.GetTranNameDescriptor		-- GetTranNameDescriptor 'InwardTransfersHOSwiftProcess'
@TranName TransactionName
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	{04/07/2021}		
	Reason		:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
	Description	:	Select transaction name descriptor value 
*/          

SELECT Descriptor AS 'TranNameDescriptor'
	FROM Menu_Action INNER JOIN RulesDescriptor 
		ON Menu_Action.CaptionID = RulesDescriptor.DescriptorID
		WHERE MenuAction = @TranName
GO

PRINT 'End... Script for CR# GFSY00865 Proc Script - dbo.GetOPSWorkFlowTrans'
GO 
go
--==================================================================================================================================================================

--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.InsertAndUpdateIntoOPSWorkFlow'
GO 
 
drop_old_proc 'InsertAndUpdateIntoOPSWorkFlow'
GO
create proc dbo.InsertAndUpdateIntoOPSWorkFlow		
@Mode						int					      ,
@RequestID					nvarchar(max)			  ,
@TranName					TransactionName		= NULL,
@Bank						BankID				= NULL,
@Region						RegionID			= NULL,
@Branch						BranchID			= NULL,
@JNLSequence				int					= NULL,
@BusinessDate				SmallDate			= NULL,
@TransactionTime			datetime			= NULL,
@Branch_User				internal_user_ID	= NULL,
@Branch_Supervisor_LoginID	nvarchar(max)		= NULL,
@TID						uniqueidentifier	= NULL,
@Status						int						  ,
@RimNo						nvarchar(max)		= NULL,
@AccountNumber				nvarchar(max)		= NULL,
@Amount						money				= NULL,
@Currency					CurrencyType		= NULL,
@OPS_User					internal_user_ID	= NULL,
@OPS_Supervisor_LoginID		nvarchar(max)		= NULL
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	{04/07/2021}		
	Reason		:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
	Description	:	Insert And Update Into OPSWorkFlow
*/          


IF @Mode = 0		--Insert Mode
	BEGIN
		DECLARE @Branch_Supervisor_UserNumber internal_user_ID
		SELECT @Branch_Supervisor_UserNumber = user_number FROM Operator WHERE LoginID = @Branch_Supervisor_LoginID
		
		INSERT INTO OPSWorkFlow (RequestID, TranName, Bank, Region, Branch, JNLSequence, BusinessDate, TransactionTime, Branch_User, Branch_Supervisor, TID, Status, RimNo, AccountNumber, Amount, Currency, IsLocked)
			VALUES(@RequestID, @TranName, @Bank, @Region, @Branch, @JNLSequence, @BusinessDate, @TransactionTime, @Branch_User, @Branch_Supervisor_UserNumber, @TID, @Status, @RimNo, @AccountNumber, @Amount, @Currency, 0)

		SELECT 1 AS 'Result'
	END
ELSE IF @Mode = 1	--Update Mode
	BEGIN
		DECLARE @OPS_Supervisor_UserNumber internal_user_ID
		SELECT @OPS_Supervisor_UserNumber = user_number FROM Operator WHERE LoginID = @OPS_Supervisor_LoginID

		UPDATE OPSWorkFlow 
			SET 
				STATUS = @Status,
				OPS_User = @OPS_User,
				OPS_Supervisor = @OPS_Supervisor_UserNumber
			WHERE RequestID = @RequestID

		SELECT 1 AS 'Result'
	END

GO

PRINT 'End... Script for CR# GFSY00865 Proc Script - dbo.InsertAndUpdateIntoOPSWorkFlow'
GO 
go


 --==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	{27/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.List_OPS_Transactions'
GO 
 
drop_old_proc 'List_OPS_Transactions'
GO
Create PROC List_OPS_Transactions   
   @start_date SmallDate = NULL, 
   @end_date SmallDate = NULL ,  
   @tranName nvarchar(100) = null,  
   @statusID int = 0,
   @user_number internal_user_ID = 0,
   @bankID BankID = 0, 
   @regionID RegionID  = 0, 
   @branchID BranchID  = 0,    
   @currency CurrencyType = null,
   @requestID nvarchar(100) ,
   @rim_number nvarchar(50),
   @account_number nvarchar(50) ,
   @amount money = null,
   @LCID   int  = 1033
as     


set nocount on
declare @sql nvarchar(4000) = ''
declare @where nvarchar(4000) = ''


-- 1- Begin handle date range param values
if @end_date  is null set @end_date = dbo.smalldate_of(getdate())    
if @start_date is null set @start_date = dbo.SmallDateAdd('d', - (dbo.max_default_date_range()), @end_date)    
if (@start_date > @end_date )
	begin    
	 raiserror('Start_date %d must be <= end_date %d' , 10, 1, @start_date, @end_date) return -2    
	end 
if  (@end_date >= @start_date)
	begin
	set @where = N'WHERE BusinessDate between @start_date and @end_date '
	end 
 -- end  handle date range param values 

-- 2- Begin get tran name 
if(@tranName <> '')
begin
set @where = @where + ' ' + 'and TranName = @tranName' 
--print ( @tranName)
end
-- End get Tran name 

-- 3- Begin get status  && StatusTypeID = 77 = ops status type
if(@statusID <> 0)
begin
set @where = @where + ' ' + 'and status = @StatusID' 
--print ( @StatusID)
end
-- End get status 

-- 4- Begin get submitter 
if(@user_number <> 0)
begin
set @where = @where + ' ' + 'and branch_user = @user_number' 
--print ( @user_number)
end
-- End get submitter

-- 5- Begin get region 
if(@regionID <> 0)
begin
set @where = @where + ' ' + 'and Region = @RegionID' 
--print ( @RegionID)
end
-- End get region 

-- 6- Begin get branch  
if(@branchID <> 0)
begin
set @where = @where + ' ' + 'and Branch = @BranchID' 
--print ( @BranchID)
end
-- End get branch 


-- 7- Begin get currency 
if(@currency <> '')
begin
set @where = @where + ' ' + 'and currency = @currency' 
--print ( @currency)
end
-- End get currency


-- 8- Begin get request ID
if(@requestID <> '')
begin
set @where = @where + ' ' + 'and RequestID = @requestID' 
--print ( @requestID)
end
-- End get request ID

-- 9- Begin get rim number
if(@rim_number <> '')
begin
set @where = @where + ' ' + 'and RimNo = @rim_number' 
--print ( @rim_number)
end
-- End get account number


-- 10- Begin get account number
if(@account_number <> '')
begin
set @where = @where + ' ' + 'and AccountNumber = @account_number' 
--print ( @account_number)
end
-- End get account number

-- 11- Begin get amount
if(@amount <> 0.00)
begin
set @where = @where + ' ' + 'and Amount = @amount' 
--print ( @amount)
end
-- End get amount


 set @sql = 
 N'SELECT OPS.*
		, CASE WHEN TDL.LocalDescription IS NULL THEN TD.Descriptor ELSE TDL.LocalDescription END AS TransactionDescription 
	    , CASE WHEN SDL.LocalDescription IS NULL THEN SD.Descriptor ELSE SDL.LocalDescription END AS StatusDescription 
	FROM OPSWorkFlow OPS INNER JOIN RulesTranName TN
		ON OPS.TranName = TN.TransactionName    
	INNER JOIN RulesDescriptor TD
		ON TN.DSC_Description = TD.DescriptorID 
	LEFT OUTER JOIN RulesDescriptorLocal TDL    
		ON TD.DescriptorID = TDL.DescriptorID AND TDL.LCID = @LCID
	INNER JOIN Status 
		ON OPS.STATUS = Status.id AND Status.StatusTypeID = 77
	INNER JOIN RulesDescriptor SD
		ON Status.DSC_Name = SD.Name
	LEFT OUTER JOIN RulesDescriptorLocal SDL     
		ON SD.DescriptorID = SDL.DescriptorID AND SDL.LCID = @LCID ' 
					+ @where   + ' ' + ' and bank = @bankID' + ' ORDER BY RequestID ASC'

 exec dbo.sp_executesql @sql, N'@start_date SmallDate , 
   @end_date SmallDate ,  
   @tranName nvarchar(100) , 
   @statusID int ,
   @user_number internal_user_ID ,
   @bankID BankID , 
   @regionID RegionID , 
   @branchID BranchID  ,    
   @currency CurrencyType ,
   @requestID nvarchar(100) ,
   @rim_number nvarchar(50),
   @account_number nvarchar(50) ,
   @amount money = null ,
   @LCID   int  = 1033 '
	,@start_date,@end_date,@tranName,@statusID,@user_number,@bankID,@regionID,@branchID,@currency,@requestID,@rim_number,@account_number,@amount,@LCID
return @@error    

GO

--================================================================================================================ 
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.RejectOPSRequest'
GO 
 
drop_old_proc 'RejectOPSRequest'
GO
create proc dbo.RejectOPSRequest		--	RejectOPSRequest 'IssueTTAgainstAccount'
@RequestID					nvarchar(max),
@RejectReason				nvarchar(max)		= NULL,
@OPS_User					internal_user_ID	= NULL,
@OPS_Supervisor_LoginID		nvarchar(max)		= NULL
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	{04/07/2021}		
	Reason		:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
	Description	:	Reject an OPS request based on request id
*/          

DECLARE @StatusID int
Select @StatusID = id From Status Where StatusTypeID IN (Select id From StatusType Where Description = 'OPSWorkFlow') And ShortDescription = 'Rejected'

DECLARE @OPS_Supervisor_UserNumber internal_user_ID
SELECT @OPS_Supervisor_UserNumber = user_number FROM Operator WHERE LoginID = @OPS_Supervisor_LoginID

If Exists(SELECT * FROM OPSWorkFlow WHERE RequestID = @RequestID)
	Begin
		UPDATE OPSWorkFlow 
			SET STATUS = @StatusID
				, RejectionReason = @RejectReason
				, OPS_User = @OPS_User
				, OPS_Supervisor = @OPS_Supervisor_UserNumber
			WHERE RequestID = @RequestID

		RETURN 1;
	END
ELSE
	BEGIN
		RETURN -1;
	END
GO

PRINT 'End... Script for CR# GFSY00865 Proc Script - dbo.RejectOPSRequest'
GO 

go

--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.InsertAndUpdateIntoOPSWorkFlow'
GO 
 
drop_old_proc 'SelectOPSStatus'
GO
create proc dbo.SelectOPSStatus		-- SelectOPSStatus '001_OPS20210829_0000014'
@RequestID	nvarchar(max)
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	{04/07/2021}		
	Reason		:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
	Description	:	Select OPS Request status based on request id
*/          

SELECT STATUS , IsLocked FROM OPSWorkFlow WHERE RequestID = @RequestID

GO

PRINT 'End... Script for CR# GFSY00865 Proc Script - dbo.SelectOPSStatus'
GO 
go

 --==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	{27/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.UpdateLockedOPSTransaction'
GO 
 
drop_old_proc 'UpdateLockedOPSTransaction'
GO
create proc dbo.UpdateLockedOPSTransaction			--UpdateLockedOPSTransaction '',0 ,1554
@ReQuestID nvarchar(max) ='',
@IsLocked bit = 0,
@LockedBy internal_user_ID = null
as        
    
/*    
	Devolper	:	Ibrahim Harby
	Date		:	[01/08/2021]		
	Reason		:	GFSY00865
	Description	:	update Islocked , LockedBy in OPSWorkFlow table 
*/          

IF EXISTS (SELECT * FROM OPSWorkFlow WHERE RequestID = @ReQuestID)
	BEGIN
		UPDATE OPSWorkFlow SET IsLocked = @IsLocked ,LockedBy = @LockedBy WHERE RequestID = @ReQuestID
	END

	
PRINT 'End. Script for CR# GFSY00865 Proc Script - dbo.UpdateLockedOPSTransaction'


go

drop_old_proc 'UpdateSwiftMessageInIR'
GO
CREATE procedure dbo.UpdateSwiftMessageInIR
 @MsgRefNo  char(13),
 @Row_Version  int,    
 @MT103Generated bit,      
 @MT202Generated bit,      
 @MT199Generated bit
AS        
/*        
CreationDate: 5/9/2021       
OriginalName: dbo.UpdateSwiftMessageInIR       
Programmer: Aya Tarek    
Description:  Update MT103,MT202,MT109       
*/      
        
        
update dbo.IR         
set             
 MT103Generated = @MT103Generated,      
 MT202Generated = @MT202Generated,    
 MT199Generated =@MT199Generated        
where  MsgRefNo = @MsgRefNo        
And Row_Version = @Row_Version         
    
return @@RowCount      

GO

DROP_OLD_PROC 'TLR_IR_UpdateMsgs'
GO
CREATE procedure dbo.TLR_IR_UpdateMsgs  
 @OperatorId  OperatorID,          
 @MsgRefNo  char(13),             
 @ValueDate  smalldatetime,          
 @SpecialRateNeeded bit,             
 @AccountOfficerID OperatorID,          
 @ActionID  int,          
 @SendToID  int,            
 @DrCommission  decimal(21,6),          
 @DrExchangeRate  decimal(21,6),            
 @CrCommission  decimal(21,6),          
 @CrExchangeRate  decimal(21,6),          
 @CrAmount  decimal(21,6),          
 @GTDTicket  varchar(20),          
 @MT103Generated bit,        
 @MT202Generated bit,        
 @Row_Version  int,      
 @LastChanged  smalldatetime,      
 @Branch int,      
 @ExceptionList  varchar(1000),      
      
@DrSellExchangeRate  decimal(21,6),      
@CrBuyExchangeRate  decimal(21,6),      
      
@DrRealExchangeRate decimal(21,6),          
 @CrRealExchangeRate decimal(21,6),      
@StatusId int = NULL,  
@HostRefNo Nvarchar(20) = null ,
@MT199Generated bit 
AS          
/*          
CreationDate: 2005-7-17          
OriginalName: dbo.TLR_IR_UpdateMsgs          
Programmer: Sayed Hussein          
Description:           
Output:            
Assumption:           
          
ModifiedDate: 2005-7-25          
Modifer: Sayed Hussein          
ModifyReason: If status is Accepted by teller then VoucherOk is true, and don't send VoucherOk as a parameter          
          
ModifiedDate: 2005-08-09          
Modifer: Sayed Hussein          
ModifyReason: Add @CrAmount parameter to update CrAmount Column         
        
ModifiedDate: 2005-08-16         
Modifer: Sayed Hussein          
ModifyReason: 2 Columns {MT103Generated,MT202Generated} added        
         
ModifiedDate: 2005-10-05         
Modifer: Sayed Hussein          
ModifyReason: set Authorized by (if Action  = Authorize)  and set ApprovedBy (if Action = Approve)      
      
ModifiedDate: 2005-10-09      
Modifer: Sayed Hussein          
ModifyReason: set Last Changed with Business date      
      
ModifiedDate: 28/11/2007      
Modifer:  azain       
ModifyReason:   Add ExceptionList      
      
ModifiedDate: 27/12/2007      
Modifer:  azain       
ModifyReason:   Add dr sell and cr buy rates      
      
ModifiedDate: 11/10/2008      
Modifer: Marwa Arafat       
ModifyReason: Performance Tuning       
      
ModifedDate : 2010-01-20      
Modifer  : Mohammed Farouk      
ModifyReason: Add Parameter @StatusId that will be used, will be used when @ActionId = -1 , otherwise the new StatusId will be determined using       
    @ActionId as default      
      
ModifedDate : 2012-02-06      
Modifer  : ahussein  
ModifyReason: fixing issue of update ir in case of @sendtoid = -1 and account officer = '' to keep the old value  

ModifedDate : 2017-04-19      
Modifer  	: Mahmoud Kamel  
ModifyReason: Issue#GFSX11957 - Comment Row_Version since there is no use for it 

ModifedDate : 1/8/2021    
Modifer  : Aya Tarek
ModifyReason: Add column  (MT199Generated)(GFSY00870)
*/          
          
update dbo.IR           WITH (ROWLOCK)
set           
 Updator   = @OperatorID,          
 ValueDate  = @ValueDate,          
 SpecialRateNeeded = @SpecialRateNeeded,          
 AccountOfficerID = case @AccountOfficerID when '' then AccountOfficerID else @AccountOfficerID end,           
 ActionID  = case @ActionID when -1 then ActionID else @ActionID end, --@ActionID,           
 SendToID  = case @SendToID when -1 then SendToID else @SendToID end,           
 DrCommission  = @DrCommission,          
 DrExchangeRate  = @DrExchangeRate,          
 CrCommission  = @CrCommission,          
 CrExchangeRate  = @CrExchangeRate,          
 CrAmount  = @CrAmount,          
 GTDTicket  = @GTDTicket,         
 MT103Generated = @MT103Generated,        
 MT202Generated = @MT202Generated,      
 LastChanged = @LastChanged,      
 Branch = @Branch  ,      
 ExceptionList  = @ExceptionList,--azain 28-11-2007      
      
 DrSellExchangeRate =@DrSellExchangeRate,      
 CrBuyExchangeRate =@CrBuyExchangeRate,      
      
 DrRealExchangeRate =@DrRealExchangeRate ,          
 CrRealExchangeRate =@CrRealExchangeRate ,      
      
      
 StatusID  = case @ActionID        
      
 when 1 --MarkVoucherAsOK           
 then 2 --AcceptedByTeller          
 when  2 --MarkVoucherAsNOTOK          
 then 3 --RejectedByTeller          
 when  3 --MarkAllVouchersAsOK          
 then 2 --AcceptedByTeller    
 when  4 --MarkAllVouchersAsNotOK          
 then 3 --RejectedByTeller          
 when  5 --Authorize          
 then 4 --AcceptedByAccountOfficer          
 when  6 --AuthorizeAll          
 then 4 --AcceptedByAccountOfficer          
 when  7 --Approve          
 then 6 --AcceptedBySupervisor          
 when  8 --ApproveAll          
 then 6 --AcceptedBySupervisor          
 when  9 --DoNotAuthorize          
 then 5 --RejectedByAccountOfficer          
 when  10 --DoNotAuthorizeAll          
 then 5 --RejectedByAccountOfficer          
 when  11 --DoNotApprove          
 then 7 --RejectedBySupervisor          
 when  12 --DoNotApproveAll          
 then 7  --RejectedBySupervisor          
 when  13 --Pay          
 then 8 --Paid          
 when  14 --PayAll          
 then 8 --Paid       
 when  15      
 then 13 -- Rejected      
 when 16      
 then 13 -- Rejected      
 when -1      
 then @StatusID      
 else StatusID          
 end,          
 VoucherOK  = case @ActionID          
 when 1 --MarkVoucherAsOK           
 then 1           
 when  2 --MarkVoucherAsNOTOK          
 then 0           
 when  3 --MarkAllVouchersAsOK          
 then 1           
 when  4 --MarkAllVouchersAsNotOK          
 then 0           
 else VoucherOK          
 end,      
 AuthorizedBy = case @ActionID          
 when 5 --Authorize           
 then @OperatorId      
 when 13  --pay      
 then @OperatorId      
 when 14 --pay all      
 then @OperatorId      
 else null      
 end,      
 ApprovedBy = case @ActionID          
 when 7 --Approve           
 then @OperatorId      
 when 13 --pay      
 then @OperatorId      
 when 14 --pay all      
 then @OperatorId         
 else null      
 end,  
 HostRefNo = @HostRefNo,
 MT199Generated =@MT199Generated             
where  MsgRefNo = @MsgRefNo          
--And Row_Version = @Row_Version           --[Mahmoud Kamel - 2017/04/19] Issue#GFSX11957 - Comment Row_Version since there is no use for it
      
return @@RowCount        
GO

--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc TLR_IR_LockupMsgs
Go
create  procedure dbo.TLR_IR_LockupMsgs --'ITSOFT\karim.mahmoud','2017/04/29'
 @OperatorID     OperatorID,    
 @business_date  smalldatetime,
 @FileRefNo     ReferenceNumber  = null,
 @StatusId       int  = null,      
 @PaymentMethodId  int  = null       ,
 @CorresBank  varchar(100) = null,
 @DrCurrency  char(3) = null,
 @CrCurrency  char(3) = null,
 @MsgDate  varchar(10) = null,
 @CrAccountNo  varchar(12) = null,
 @OredringCustomer varchar(100) = null,
 @SenderReference varchar(50) = null ,
 @DrAmount  decimal(21,6) = 0 ,
 @CrAmount  decimal(21,6) = 0 ,
 @MsgRefNo     ReferenceNumber   = null
as      
/*      
CreationDate: 2005-7-20      
OriginalName: dbo.TLR_IR_LockupMsgsByFileRef      
Programmer  : Sayed Hussein      
Description : Select Messages filter by one (or all) of the following criteria       
              {FileRefNo,StatusId,PaymentMethodId}   
         And operator id for visibility   
Output:        
Assumption:       
      
ModifiedDate: 2005-7-21      
Modifer:      Sayed Hussein        
ModifyReason: Group by file ref     

ModifiedDate: 29/4/2008     
Modifer:      hany nasr        
ModifyReason: performance issue


ModifiedDate: 23/6/2008     
Modifer:      Mohamed Gad        
ModifyReason: Adding Branch,MsgType,DrAccountNo_DepLoan and IR.* to the return result

ModifiedDate: 26 January 2009
Modifer:   Hany A Hassan	   
ModifyReason:   Change the Data Type of @FileRefNo,@MsgRefNo to ReferenceNumber 

ModifiedDate:	2011-04-06
Modifer:		Osama Orabi	   
ModifyReason:   add two columns two return recordset

ModifiedDate: 2012-10-29  
Modifer:  Hatim ALSum      
ModifyReason:   add Missing Columns to return RecordSet 

ModifiedDate: 2015-05-27 
Modifer:  Asmaa Gamal       
ModifyReason:   Fix issue # GFSX08949 remove dublicate retrive columns (ValueDate,MsgValueDate)

ModifiedDate: 2018-08-28 
Modifer:  Nada Elshafie      
ModifyReason:  GFSY00717 - retrieve FLD_111 and FLD_121

ModifiedDate: 2021-08-08 
Modifer:  Ahmed Atef      
ModifyReason:  GFSY00870 - retrieve MT199Generated

*/      
      
declare @IS_IR_SuperVisor as int    
select @IS_IR_SuperVisor = T.IR_SuperVisor 
from  dbo.TellerConfig T 
inner  join 
 dbo.Operator O 
on  O.user_number = T.[User_Id] 
where  O.LoginID = @OperatorID    
 
declare @sql varchar(8000)
 
set  @sql = 
'select MsgRefNo,
 FLD_20 as SenderRefNo,
 S1.ShortDescription as Status, 
 DrAmount as DebitAmount,
 ValueDate ,
 SenderBank,
 FileRefNo,
 FilePathName,
 S2.ShortDescription as PaymentMethod ,
 isnull(S3.ShortDescription, '''') as Action,
 isnull(S4.ShortDescription, '''') as SendTo,
 StatusID,
 PaymentMethodID,
 ActionID,
 SendToID,
 AccountOfficerID,
 DateTimeStamp,
 PreparedBy,
 SpecialRateNeeded,
 MsgValueDate,
 VoucherOK,
 AuthorizedBy,
 ApprovedBy,
 DrAccountNo,
 DrAccountName,
 DrCurrency,
 DrAmount,
 DrAddress,
 DrExchangeRate,
 DrCommission,
 CrAccountNo,
 CrAccountName,
 CrCurrency,
 CrAmount,
 CrAddress,
 OrderingCustomer,
 CrExchangeRate,
 CrCommission,
 GTDTicket,
 OriginalMsg,
 Fld_50K,
 Fld_59,
 Charge_Det,
 BeneficiaryAmount,
 BeneficiaryCurrency,
 BeneficiarySellRate,
 BeneficiaryBuyRate,
 BeneficiaryGTDTicket,
 BeneficiaryName,
 BeneficiaryIDType,
 BeneficiaryIDNumber,
 BeneficiaryPhone,
 BeneficiaryAddress,
 BeneficiaryNarrative,
 Row_Version,
 LockedByID,
 IR.Updator,
 IR.LastChanged,
 Branch,
 MsgType,
 DrAccountNo_DepLoan,
 MsgValueDate, 
 IR.DrAccountNo_AcctType,
 IR.DrAccountNo_ApplType,
 IR.CrAccountNo_AcctType,  
 IR.CrAccountNo_ApplType,  
 IR.CrAccountNo_DepLoan,
 IR.MT103Generated,
 IR.MT202Generated,
 IR.Account_With_Ref,
 IR.Account_With_Ac,
 IR.Account_With_Name,
 IR.ValueCurrency,
 IR.Order_Cust_Name,
 IR.Order_Cust_Add1,
 IR.Order_Cust_Add2,
 IR.Order_Inst,
 IR.Order_Inst_Name,
 IR.Order_Inst_Add1,
 IR.BeneficiaryAccount,
 IR.FLD_70,
 IR.FLD_71A,
 IR.DrValueDate,
 IR.CrValueDate,
 IR.CrNarrative,
 IR.DrNarrative,
 IR.FLD_20,
 IR.FLD_23,
 IR.FLD_33,
 IR.FLD_52,
 IR.FLD_53,
 IR.Is_FLD_20_Duplicate,
 IR.ExceptionList,
 IR.OldStatusID,
 IR.OldDrAccountNo,
 IR.OldDrAccountNo_AcctType,
 IR.OldDrAccountNo_ApplType,
 IR.OldDrAccountNo_DepLoan,
 IR.OldDrAccountName,
 IR.OldDrCurrency,
 IR.OldDrAmount,
 IR.OldDrExchangeRate,
 IR.OldDrCommission,
 IR.OldCrAccountNo,
 IR.OldCrAccountNo_AcctType,
 IR.OldCrAccountNo_ApplType,
 IR.OldCrAccountNo_DepLoan,
 IR.OldCrAccountName,
 IR.OldCrCurrency,
 IR.OldCrAmount,
 IR.OldCrExchangeRate,
 IR.OldCrCommission,
 IR.OldDrValueDate,
 IR.OldCrValueDate,
 IR.OldCrNarrative,
 IR.OldDrNarrative,
 IR.DrRealExchangeRate,
 IR.CrRealExchangeRate,
 IR.TTAmount,
 IR.TTCurrency,
 IR.DrSellExchangeRate,
 IR.CrBuyExchangeRate,
 IR.IBAN,
 IR.Ordering_IBAN,
 IR.CrRimNo,
 IR.Sender_BIC,
 IR.FLD_72,
 IR.Ben_Inst_BIC,
 0 as CrExchangeGain,   
 0 as DrExchangeGain,
 IR.FLD_111,
 IR.FLD_121,
 IR.MT199Generated   
from    IR
inner  join 
 Status S1  
on   IR.StatusID = S1.[Id]
And S1.StatusTypeID = 12  
inner  join 
 Status S2  
on   IR.PaymentMethodID = S2.[Id] 
And S2.StatusTypeID = 13
LEFT  join 
 Status S3  
on   IR.ActionID = S3.[Id]
And S3.StatusTypeID = 14
Left  join 
 Status S4
on   IR.SendToID = S4.[Id]
And S4.StatusTypeID = 15
where     
(
 (SendToID = 5 /*SendToTeller*/OR SendToID = 6 /*SendAllToTeller*/)    
    OR 
 (    
     (SendToID = 1 /*SendToAccountOfficer*/OR SendToID = 2 /*SendAllToAccountOfficer*/)
  And AccountOfficerID = '''+@OperatorID+'''    
 )    
 OR
 (
  (SendToID = 3 /*SendToSupervisor*/OR SendToID = 4 /*SendAllToSupervisor*/)
  And '+convert(varchar(10),@IS_IR_SuperVisor)+' = 1
 )    
)
 
AND ValueDate <= ''' + convert(varchar, @business_date,111) + ''''
 
if (@FileRefNo is not null)       
 set @sql = @sql + ' AND (FileRefNo      = '''+@FileRefNo+''')'
 
if (@MsgRefNo is not null)       
 set @sql = @sql + ' AND (MsgRefNo       = '''+@MsgRefNo+''')'
 
if (@PaymentMethodId is not null)       
 set @sql = @sql + ' AND (PaymentMethodId   = '+convert(varchar(10),@PaymentMethodId)+')'
 
if (@StatusId is not null)       
 set @sql = @sql + ' AND  (StatusId     = '+convert(varchar(10),@StatusId) +' )'
 
if ((@CorresBank is not null) and (@CorresBank <> ''))
 set @sql = @sql + ' AND DrAccountName = '''+@CorresBank+''''
 
if ((@DrCurrency is not null) and (@DrCurrency <> ''))
 set @sql = @sql + ' AND DrCurrency = '''+@DrCurrency+''''
 
if ((@CrCurrency is not null) and (@CrCurrency <> ''))
 set @sql = @sql + ' AND CrCurrency = '''+@CrCurrency+''''
 
if ((@MsgDate is not null) and (@MsgDate <> ''))
 set @sql = @sql + ' AND MsgValueDate = '''+@MsgDate+''''
 
if ((@CrAccountNo is not null) and (@CrAccountNo <> ''))
 set @sql = @sql + ' AND ( CrAccountNo = '''+@CrAccountNo+''')'
 
if ((@OredringCustomer is not null) and (@OredringCustomer <> ''))
 set @sql = @sql + ' AND ( Fld_50K like ''%'+@OredringCustomer+'%'')'
 
if ((@SenderReference is not null) and (@SenderReference <> ''))
 set @sql = @sql + ' AND ( Fld_20 LIKE ''%'+@SenderReference+'%'')'
 
if ((@DrAmount is not null) and (@DrAmount <> 0))
 set @sql = @sql + ' AND ( DrAmount = '+convert(varchar(50),@DrAmount)+')'
 
if ((@CrAmount is not null) and (@CrAmount <> 0))
 set @sql = @sql + ' AND ( CrAmount = '+convert(varchar(50),@CrAmount)+')'
 
 set @sql= @sql + ' And (LockedByID is NULL or LockedByID ='''' or LockedByID <> ''' + @OperatorID+ ''')'
--print @sql
EXEC (@sql)
go
--End of Automatic Generation

--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for CR# GFSY00865 Proc Script - dbo.SelectOPSStatus'
GO 
 
drop_old_proc 'SelectOPSStatus'
GO
create proc dbo.SelectOPSStatus		-- SelectOPSStatus '001_OPS20210829_0000014'
@RequestID	nvarchar(max)
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	{04/07/2021}		
	Reason		:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
	Description	:	Select OPS Request status based on request id

	Devolper	:	Ibrahim Harby
	Date		:	{20/09/2021}		
	Reason		:	GFSX14729
*/          

SELECT STATUS , IsLocked , LockedBy FROM OPSWorkFlow WHERE RequestID = @RequestID

GO

PRINT 'End... Script for CR# GFSY00865 Proc Script - dbo.SelectOPSStatus'
GO 
drop_old_proc 'dbo.select_reports'
go
CREATE procedure dbo.select_reports     
@LCID LanguageLCID = NULL         
as  
  
/*  
CreationDate: 2005-08-29  
OriginalName: dbo.select_reports  
Programmer: Mohammed Monir  
Description: select all reports  
Output:    
Assumption:   
  
Changed by:      Alaa Amer  
Changed Date:    08-05-2008  
Changed Reasons: Performance Enhancement   

Changed by:      Lamiaa Mostafa 
Changed Date:    24/03/2013
Changed Reasons: return DSC_Description instead of Description to could display report name in arabic.

Changed by:      Ahmed Osman
Changed Date:    07/08/2019
Changed Reasons: Return IsAuditable column to check the reports that show account balance - CR#GFSY00761 - BIsB_ACM16832_Customer Balances Audit Trail.

Changed by: : Ibrahim Harby
ChangedDate: 20-september-2021 - retrofit
Changed Reasons: alter table to add new column "ExportFormat" - CR# GFSX14724 retrofit ADIB_ACM16164 Export Reports In PDF
*/  
  
set nocount on  
  
SELECT  
  r.[id],  
  r.[FileName],  
  --r.[Description],  
  ISNull(dbo.GetDescriptorByDSC_Name(r.DSC_Description,@LCID),[Description]) as Description, 
  r.ParentID,  
  r.isActive,  
  r.SqlStringID,
  r.IsAuditable  ,
  r.ExportFormat 
  
FROM     dbo.Reports_2 as r  

GO
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[cmpCashMoveDenom]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[cmpCashMoveDenom]
GO

CREATE Proc  dbo.cmpCashMoveDenom        
 @RefNo char(13),          
 @Grid varchar(8000),      
 @BranchID varchar(50)          
As        
/*        
 OriginalName:  dbo.cmpCashMoveDenom        
 Developer:  Mohamed Mustafa Alogail          
 Created : 2005-05-19         
        
 purpose : Compares Denomination from send CashMovement with this in recieve CashMovement        
 returns :  0 if successful  , -1 doesn't Match         
       
 ModifiedDate: 12th Jan 2009          
 Modifer:  Aya Mahmoud          
 ModifyReason: Execute the procedure directly on the target branch using the linked server feature          
      
      
 ModifiedDate: 2010-05-06      
 Modifer:  Osama Orabi       
 ModifyReason: Validate against the Denomination which have values (Amt)     
    
 ModifiedDate: 17/07/2010     
 Modifer:  Mohamed Kamel Mohamed       
 ModifyReason: Use Linked Server     
     
 ModifiedDate: 04/10/2010     
 Modifer:  Hatim AlSum     
 ModifyReason: Fix row count    
   
    
 ModifiedDate : 2011-06 - 22     
 Modifer   : Mohammed El-Masry     
 ModifyReason : Change Column LinkedServer from Branch.LinkedServer into BranchConfig.LinkedServer
 
 ModifiedDate	: 2012-01-11
 Modifer		: Mohammed Farouk
 ModifyReason	: Select @@servername between square brackts, and this inforces that setup in table Branch.LinkedServer 
				  	should be written with square brachts1  
				  	
 ModifiedDate	: 2021-08-19
 Modifer		: Mostafa Sayed
 ModifyReason	: GFSX14697 - INC000000316457 - 
				  Check that CashMoveDenomination.Amt is greater than 0 in case of LinkedServer
      
*/        
      
        
declare @tGrid table( Denom decimal(12,4),          
   Type varchar(30),          
      Amt int)          
          
declare @RowDelimiter char(1),          
 @ColDelimiter char(1),          
 @RowPos  int,          
 @ColPos  int,          
 @i  int,          
 @j  int,          
 @DataRow varchar(100),          
 @ColCount int          
           
declare @Denom  denominationtype,--decimal(12,4),          
  @Amt   varchar(100),          
  @type   varchar(30)          
          
set @RowDelimiter = '|'          
set @ColDelimiter = ','          
set @i = 1          
set @RowPos = charindex(@RowDelimiter, @Grid, @i)          
set @ColPos = 0          
set @ColCount = 0          
          
While(@RowPos > 0)          
BEGIN          
           
 set @DataRow = substring(@Grid, @i, @RowPos-@i)          
          
 set @j = 1          
 set @ColPos  = charindex(@ColDelimiter, @DataRow, @j)          
 set @Denom  = substring(@DataRow, @j, @ColPos-@j)          
          
 set @j   = @ColPos+1          
 set @ColPos = charindex(@ColDelimiter, @DataRow, @j)          
 set @Type = substring(@DataRow, @j, @ColPos-@j)          
          
 set @j   = @ColPos+1          
 set @Amt    = substring(@DataRow, @j, 100)            
           
 insert into @tGrid select @Denom, @Type, @Amt          
          
 set @i = @RowPos+1          
 set @RowPos = charindex(@RowDelimiter, @Grid, @i+1)          
END          
          
 -- select * from @tGrid          
   ----------------------------------------------------          
   /**************** End Grid Parsing ****************/          
   ----------------------------------------------------          
        
declare @count int,        
  @cnt int,       
  @LinkedServer varchar(100),      
  @LocalServer varchar(100),      
  @sql varchar(8000)      
        
set @LocalServer = (select '['+@@servername+']')            
select @LinkedServer = LinkedServer from BranchConfig where Branch = @BranchID and LinkedServer <> ''      
      
select @count = count(*) from @TGrid        
   Where AMT > 0      
      
if(@LocalServer <> @LinkedServer)      
Begin    
 select * into #T1 from @tGrid    
  set @sql = 'select 1       
  from ' + @LinkedServer + '.Globalfs.dbo.CashMoveDenomination d         
  inner join        
  #T1   g        
  on d.Refno = '''+ @RefNo +'''        
  AND d.Denom = g.Denom        
  AND d.Type = g.Type        
  AND d.Amt = g.AMT
  AND d.Amt > 0'      
    
exec (@sql)    
set @cnt = (select @@RowCount)    
      
 if( @count <>  @cnt)        
 return -1        
End      
      
Else      
Begin      
 if( @count <>          
  (select count(*)          
  from CashMoveDenomination d          
  inner join          
   @TGrid   g          
  on d.Refno = @RefNo          
  AND d.Denom = g.Denom          
  AND d.Type = g.Type          
  AND d.Amt = g.AMT      
  AND d.Amt > 0)          
 )          
 return -1       
End   
         
set nocount off         

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

drop_old_proc 'GET_BRANCH_STATUS'
go
CREATE Proc  [dbo].[GET_BRANCH_STATUS] -- GET_BRANCH_STATUS 1,-1,-1             
(              
 --@pBankTopology bit =1              
 @pBank int =null,              
 @pRegion int,              
 @pBranch int            
)              
              
AS                
set nocount on                
/*                                      
CreationDate : 2008-8-4                                       
OriginalName : dbo.pr_GET_BRANCH_STATUS                                      
Programmer : Amgad Awad                                      
Description : Get The Current Branch Status(open/close).                                      
Assumption :               
            
            
ModifiedDate:  11-11-2009                   
Modifer:    Mohamed Gad              
ModifyReason:   Applying modification set from Osama in order to fix bug in case two transaction posted in the same time            
  (Sub quary should retrun one result only)            
            
ModifiedDate:  26-01-2010                  
Modifer:    Aya Mahmoud          
ModifyReason:   Use the varchar for local variables datatypes instead of varchar to enlarge the @sqlString length            
        
ModifiedDate: 2010-02-03        
Modifer  : Osama Orabi            
ModifyReason:  Fixing a bug of closing a branch in the same time as posting a transaction from another branch        
            
2011Dec12: Osama Orabi: porting From UBS3         
        
ModifiedDate: 2012-07-10        
Modifer  : Osama Orabi            
ModifyReason:  use BrID instead of Branch to join Branch and Journal tables          
*/                  
      
/*      
ModifiedDate: 2012-07-17        
Modifer  : Mohammed Farouk           
ModifyReason:  covert CurrentBusinessDate to small date          
*/                  
/*    
ModifiedDate: 2013-02-27      
Modifer  : Sally Muhammad  & Mohammed Farouk        
ModifyReason:  def GFSX03181  ,Issue 122321
Modifications: 
				-update inner join with journal table to left join to 
				return all branches not only that opened in current month.
				
				-change join between bankconfig and journal to be join between
				bankconfig and branch table to avoid returning multiple records for 
				same branch.
				
				-Update subcriteria to use branch table not journal (ex: B.Bank instead of J.Bank....)
				as branch not necessarily exists in Journal table
				
Modifier : Mostafa Sayed
Date    : [07/07/2021]
Reason  : Defect#GFSX14662 - INC000000311771
		  Select only one row in case two different users in the same branch opened branch at the same time.
*/ 
------------------------------------------------------                  
                
declare @sqlString varchar(8000)                
                
declare @subCriteria varchar(150)                
set @subCriteria=' 1=1 '                
declare @tbl varchar(100)                
set   @tbl = 'ZJournal'+(select dbo.jnl_partition_suffix_of_date(convert(varchar,(select dbo.f_max_journal_business_date( 20081105))))) -- convert(datetime,'2008-11-05')  ))))                
                
if @pBank is not null                
begin                
set @subCriteria=@subCriteria+'                
 and B.Bank='+convert(varchar,@pBank)                
end                
                
if @pRegion>-1                
begin                
set @subCriteria=@subCriteria+'                
 and B.Region='+convert(varchar,@pRegion)                
end                 
if @pBranch>-1                
begin                
set @subCriteria=@subCriteria+'                
 and B.Branch='+Convert(varchar,@pBranch)                
end                
                
                  
set @sqlString = 'SELECT distinct B.Name,            
 ( case when BC.IsOpenBranch=0 then ''Closed'' else ''Opened'' end)  as BranchStatus,            
 ( select top 1 J2.COR_LOGED_USER            
  from dbo.' + @tbl + '  as J2              
  where J2.TransactionTime=            
  (select max(TransactionTime)             
   from dbo.' + @tbl + '              
   where ( (TranName=''StartOfDay'' or TranName=''ReOpenBranch'')  and Branch=J.Branch)) and J2.Branch = J.Branch) AS OpeningUser,              
 ( SELECT top 1 (convert(varchar,DATEPART(m, J2.TransactionTime))+''-''+convert(varchar,DATEPART(d,J2.TransactionTime))+''-''+convert(varchar,DATEPART(yy, J2.TransactionTime)))              
    from dbo.' + @tbl + '  as J2              
  where J2.TransactionTime =            
  ( select max(TransactionTime)            
   from dbo.' + @tbl + '             
   where ( (TranName=''StartOfDay'' or TranName=''ReOpenBranch'') and Branch=J.Branch)) and J2.Branch = J.Branch)  as OpenDay,              
 ( Select top 1 (convert(varchar,DATEPART(hh,J2.TransactionTime))+'':''+convert(varchar,DATEPART(mi,J2.TransactionTime))+'':''+convert(varchar,DATEPART(ss,J2.TransactionTime)))               
 from dbo.' + @tbl + '  as J2              
  where J2.TransactionTime =             
  ( select max(TransactionTime)             
   from dbo.' + @tbl + '              
   where ( (TranName=''StartOfDay'' or TranName=''ReOpenBranch'') and Branch=J.Branch)) and J2.Branch = J.Branch) as OpenTime,              
 case             
 when BC.IsOpenBranch=0--(select max(TransactionTime) from dbo.' + @tbl + '  where ( (TranName=''StartOfDay'' or TranName=''ReOpenBranch'')  and Branch=J.Branch)) < (select max(TransactionTime) from dbo.' + @tbl +             
 '  inner join BranchConfig bc on bc.branch = dbo.' + @tbl + ' .branch where TranName=''EndOfDay'' and dbo.' + @tbl + ' .Branch=J.Branch and BusinessDate = bc.CurrentBusinessDate)            
 then             
 ( select J2.COR_LOGED_USER               
  from dbo.' + @tbl + '  as J2              
  where J2.TransactionTime=            
  (select max(TransactionTime)             
   from dbo.' + @tbl + '              
   inner join BranchConfig bc            
   on bc.branch = dbo.' + @tbl + ' .branch            
   where TranName=''EndOfDay''             
   and dbo.' + @tbl + ' .Branch=J.Branch            
   and BusinessDate = dbo.smalldate_of(bc.CurrentBusinessDate)           
  )        
  and J2.Branch = J.Branch            
 )            
 else null            
 end            
 AS ClosingUser,           
 case             
 when BC.IsOpenBranch=0--(select max(TransactionTime) from dbo.' + @tbl + '  where ( (TranName=''StartOfDay'' or TranName=''ReOpenBranch'')  and Branch=J.Branch)) < (select max(TransactionTime) from dbo.' + @tbl +             
 '  inner join BranchConfig bc on bc.branch = dbo.' + @tbl + ' .branch where TranName=''EndOfDay'' and dbo.' + @tbl + ' .Branch=J.Branch and BusinessDate = bc.CurrentBusinessDate)            
 then             
 ( SELECT (convert(varchar,DATEPART(m, J2.TransactionTime))+''-''+convert(varchar,DATEPART(d,J2.TransactionTime))+''-''+convert(varchar,DATEPART(yy, J2.TransactionTime)))              
  from dbo.' + @tbl + '  as J2              
  where J2.TransactionTime=            
  ( select max(TransactionTime) from dbo.' + @tbl + '             
   where (TranName=''EndOfDay'' and Branch=J.Branch)) and J2.Branch = J.Branch)               
 else null            
 end  as CloseDay,              
 case             
 when BC.IsOpenBranch=0--(select max(TransactionTime) from dbo.' + @tbl + '  where ( (TranName=''StartOfDay'' or TranName=''ReOpenBranch'')  and Branch=J.Branch)) < (select max(TransactionTime) from dbo.' + @tbl +             
 '  inner join BranchConfig bc on bc.branch = dbo.' + @tbl + ' .branch where TranName=''EndOfDay'' and dbo.' + @tbl + ' .Branch=J.Branch and BusinessDate = bc.CurrentBusinessDate)            
 then             
 ( Select(convert(varchar,DATEPART(hh,J2.TransactionTime))+'':''+convert(varchar,DATEPART(mi,J2.TransactionTime))+'':''+convert(varchar,DATEPART(ss,J2.TransactionTime)))               
  from dbo.' + @tbl + '  as J2            
  where J2.TransactionTime=            
  ( select max(TransactionTime)             
   from dbo.' + @tbl + '              
   where (TranName=''EndOfDay'' and Branch=J.Branch)) and J2.Branch = J.Branch)             
 else null            
 end  as CloseTime  
FROM Branch as B    
inner join Branchconfig as BC on  B.branch = BC.Branch and B.Bank = BC.Bank ANd B.Region = BC.Region          
Left join  dbo.' + @tbl + '  as J on J.brid=B.id   
where '+ @subCriteria                     
     
  --PRINT @SQLSTRING                             
exec(@sqlString) 
go


drop_old_proc 'SelSolidRemittanceData'
GO
CREATE   procedure   [dbo].[SelSolidRemittanceData]  -- SelSolidRemittanceData '',2,'Pay','','' ,'' 
@BenefName nvarchar (200) ,  
@TranMode int    = 1 ,  
@TranAction varchar(10)='',  
@ClearBank varchar(5)='' ,  
@ClearBranch varchar(5)='',
@ReferenceNo  varchar(50) = ''

as  
  
/*  
CreationDate: 2008-10-21  
OriginalName: dbo.SelSolidRemittanceData  
Programmer: Shimaa Saeed  
Description: select from SelSolidRemittanceData  
Output:    
Assumption:   

Modify Date	:	2011-10-25  
Modifier	:	Mohammed Farouk
Reason		:	G8 Porting, Add Reference Number,Security Question and Secuirty Answer to result set


Modify Date	:	2016-07-19  
Modifier	:	Ahmed Abd Elhakeem
Reason		:	Update new coulmn (BeneficiaryPhone)

Modify Date	:	26/02/2020
Modifier	:	Ahmed Osman
Reason		:	Issue GFSX13945 | BDL - UAT - Layout Issue [returen '' in case SerialNO = -1 else return SerialNO and change datetime format of IssueDate column]

Modify Date	:	29/08/2021
Modifier	:	Ahmed Eliwa
Reason		:	Issue GFSX14711 |System doesn't retrieve serial no in case serial no=-1

*/  

set nocount on  
if (@TranMode =1) --Local Bank  
BEGIN  
	if (@TranAction='Verify')  
	BEGIN  
		SELECT
		--Ahmed Eliwa  [Begin Issue# GFSX14711]{29/08/2021}
		--CASE
		--	WHEN s.SerialNO = -1 THEN ''
			--ELSE s.SerialNO
		--END AS 'SerialNO'
		 s.SerialNO AS 'SerialNO'
		 --Ahmed Eliwa  [End Issue# GFSX14711]{29/08/2021}
		,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
		,s.IssuerName
		,s.RemittanceAmount
		,s.RemittanceCurrency  
		,s.BeneficiaryName  
		,s.BeneficiaryIDType  
		,s.BeneficiaryIDNumber  
		,s.Notes  
		,s.IssuerBranch  
		,s.PaymentClearBankID  
		,s.PaymentClearBranchID  
		,s.PaymentClearGL
		,s.ReferenceNO
		,s.SecurityQuestion  
		,s.SecurityAnswer
        ,s.BeneficiaryPhone
		from    dbo.SoldRemittance as s   
		where   s.BeneficiaryName like '%'+@BenefName+'%'
		and		s.ReferenceNO like '%'+@ReferenceNo+'%'
		and s.Status='Issued'  
		and s.ToLocalBank=1  
		and s.IsExternalIssued=0  
		and(@ClearBank is null or @ClearBank ='' or PaymentClearBankID=@ClearBank)  
		and(@ClearBranch is null or @ClearBranch ='' or PaymentClearBranchID=@ClearBranch)  
	END  
	ELSE IF (@TranAction='Pay')  
	BEGIN  
		select  
		--Ahmed Eliwa  [Begin Issue# GFSX14711]{29/08/2021}
		--CASE
		--	WHEN s.SerialNO = -1 THEN ''
			--ELSE s.SerialNO
		--END AS 'SerialNO'
		 s.SerialNO AS 'SerialNO'
		 --Ahmed Eliwa  [End Issue# GFSX14711]{29/08/2021}
		,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
		,s.IssuerName
		,s.RemittanceAmount
		,s.RemittanceCurrency  
		,s.BeneficiaryName  
		,s.BeneficiaryIDType  
		,s.BeneficiaryIDNumber  
		,s.Notes  
		,s.IssuerBranch  
		,s.PaymentClearBankID  
		,s.PaymentClearBranchID  
		,s.PaymentClearGL  
		,s.ReferenceNO
		,s.SecurityQuestion  
		,s.SecurityAnswer
		,s.BeneficiaryPhone
		from    dbo.SoldRemittance as s   
		where   s.BeneficiaryName like '%'+@BenefName+'%'
		and		s.ReferenceNO like '%'+@ReferenceNo+'%'  
		and s.Status in ('Issued','Verify')  
		and s.ToLocalBank=1  
		and s.IsExternalIssued=0  
		and(@ClearBank is null or @ClearBank ='' or PaymentClearBankID=@ClearBank)  
		and(@ClearBranch is null or @ClearBranch ='' or PaymentClearBranchID=@ClearBranch)  
	END  
END  
ELSE IF(@TranMode =0) --Our branch  
BEGIN  
	select  
	--Ahmed Eliwa  [Begin Issue# GFSX14711]{29/08/2021}
	 --CASE
	 --	WHEN s.SerialNO = -1 THEN ''
		--ELSE s.SerialNO
	 --END AS 'SerialNO'
	s.SerialNO AS 'SerialNO'
	--Ahmed Eliwa  [End Issue# GFSX14711]{29/08/2021}
	,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
	,s.IssuerName
	,s.RemittanceAmount
	,s.RemittanceCurrency  
	,s.BeneficiaryName  
	,s.BeneficiaryIDType  
	,s.BeneficiaryIDNumber  
	,s.Notes  
	,s.IssuerBranch  
	,s.PaymentClearBankID  
	,s.PaymentClearBranchID  
	,s.PaymentClearGL  
	,s.ReferenceNO
	,s.SecurityQuestion  
	,s.SecurityAnswer
	,s.BeneficiaryPhone	
	from    dbo.SoldRemittance as s   
	where   s.BeneficiaryName like '%'+@BenefName+'%'
	and		s.ReferenceNO like '%'+@ReferenceNo+'%'  
	and s.Status='Issued'  
	and s.ToLocalBank=0 
END  

ELSE IF(@TranMode =2) --External Issuing  
BEGIN  
	if (@TranAction='Settlement')  
	BEGIN  
		select  
		--Ahmed Eliwa  [Begin Issue# GFSX14711]{29/08/2021}
		--CASE
		--	WHEN s.SerialNO = -1 THEN ''
			--ELSE s.SerialNO
		--END AS 'SerialNO'
		 s.SerialNO AS 'SerialNO'
		 --Ahmed Eliwa  [End Issue# GFSX14711]{29/08/2021}
		,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
		,s.IssuerName
		,s.RemittanceAmount
		,s.RemittanceCurrency  
		,s.BeneficiaryName  
		,s.BeneficiaryIDType  
		,s.BeneficiaryIDNumber  
		,s.Notes  
		,s.IssuerBranch  
		,s.PaymentClearBankID  
		,s.PaymentClearBranchID  
		,s.PaymentClearGL
		,s.ReferenceNO
		,s.SecurityQuestion  
		,s.SecurityAnswer  
        ,s.BeneficiaryPhone
		from    dbo.SoldRemittance as s   
		where   s.BeneficiaryName like '%'+@BenefName+'%'
		and		s.ReferenceNO like '%'+@ReferenceNo+'%'  
		and s.Status='Pay'  
		 and s.IsExternalIssued=1  
		and(@ClearBank is null or @ClearBank ='' or PaymentClearBankID=@ClearBank)  
		and(@ClearBranch is null or @ClearBranch ='' or PaymentClearBranchID=@ClearBranch)  
	END  
	ELSE IF(@TranAction='Pay')  
	BEGIN  
		select  
		--Ahmed Eliwa  [Begin Issue# GFSX14711]{29/08/2021}
		--CASE
		--	WHEN s.SerialNO = -1 THEN ''
			--ELSE s.SerialNO
		--END AS 'SerialNO'
		 s.SerialNO AS 'SerialNO'
		 --Ahmed Eliwa  [End Issue# GFSX14711]{29/08/2021}
		,CONVERT(varchar(10), s.IssueDate, 103) as 'IssueDate'
		,s.IssuerName
		,s.RemittanceAmount
		,s.RemittanceCurrency  
		,s.BeneficiaryName  
		,s.BeneficiaryIDType  
		,s.BeneficiaryIDNumber  
		,s.Notes  
		,s.IssuerBranch  
		,s.PaymentClearBankID  
		,s.PaymentClearBranchID  
		,s.PaymentClearGL  
		,s.ReferenceNO
		,s.SecurityQuestion  
		,s.SecurityAnswer
		,s.BeneficiaryPhone
		from    dbo.SoldRemittance as s   
		where   s.BeneficiaryName like '%'+@BenefName+'%'
		and		s.ReferenceNO like '%'+@ReferenceNo+'%'  
		and s.Status='Issued'  
		 and s.IsExternalIssued=1  
		and(@ClearBank is null or @ClearBank ='' or PaymentClearBankID=@ClearBank)  
		and(@ClearBranch is null or @ClearBranch ='' or PaymentClearBranchID=@ClearBranch)  
	END
	
END  
GO
