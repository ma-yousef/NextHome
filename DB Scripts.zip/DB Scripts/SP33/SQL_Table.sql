

USE [Globalfs]
GO
------------------------------------------------------------------------------------------
-----  Developer     : Abdelrhman Mohamed Kamal ------------------------------------------
-----  Creation Date : 31-Dec-2018              ------------------------------------------
-----  Purpose       : CRQ000000016784 - KIB - Transfer Cheque Book From Branch To Branch 
 --------------------------------------------------------------------- CR# GFSY00744 -----
------------------------------------------------------------------------------------------

IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'ChqBookMovementBetweenBranches')
BEGIN
CREATE TABLE [dbo].[ChqBookMovementBetweenBranches](

	
	[SerialNumber] [int] IDENTITY(1,1) NOT NULL,
	[ChequeBookReference] [varchar](15) NOT NULL,
	[AccountNumber] [varchar](15) NOT NULL,
	[RIMNumber] [varchar](5) NOT NULL,
	[PostingBranch] [int] NOT NULL,
	[TellerNumber] [int] NOT NULL,
	[ToBranch] [int] NOT NULL,
	[FromBranch] [int] NOT NULL,
	[PostingDate] [datetime] NOT NULL,
	[MovementType] [int] NOT NULL,
	[Updator] [dbo].[OperatorID] NOT NULL,
	[Creator] [dbo].[OperatorID] NOT NULL,
	[Created] [datetime] NOT NULL,
	[LastChanged] [datetime] NOT NULL
)
ALTER TABLE ChqBookMovementBetweenBranches ADD PRIMARY KEY (SerialNumber)

ALTER TABLE ChqBookMovementBetweenBranches ADD CONSTRAINT DF_ChequeBookMovementBetweenBranches_Creator DEFAULT (suser_sname()) FOR Creator
                                                    
ALTER TABLE ChqBookMovementBetweenBranches ADD CONSTRAINT DF_ChequeBookMovementBetweenBranches_Created DEFAULT (getdate()) FOR Created
                                                    
ALTER TABLE ChqBookMovementBetweenBranches ADD CONSTRAINT DF_ChequeBookMovementBetweenBranches_Updator DEFAULT (suser_sname()) FOR Updator
                                                    
ALTER TABLE ChqBookMovementBetweenBranches ADD CONSTRAINT DF_ChequeBookMovementBetweenBranches_LastChanged DEFAULT (getdate()) FOR LastChanged
END 
GO



If Not Exists(Select * from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME = 'ValidationsConditions' And COLUMN_NAME = 'ArrayIndex1')
Begin
	Alter Table ValidationsConditions Add ArrayIndex1 int NULL
End
GO

If Not Exists(Select * from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME = 'ValidationsConditions' And COLUMN_NAME = 'ArrayIndex2')
Begin
	Alter Table ValidationsConditions Add ArrayIndex2 int NULL
End
GO

Go
USE [Globalfs]
GO
/*
 CreationDate : 01-20-2018      
 Programmer   :Abdelrhman Moahmed
 Description  :CHR of Enhancement: GFSY00721 for Rel: 101FP_M                         
*/ 
IF  NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'AddChqbooks' AND ss.name = N'dbo')

CREATE TYPE [dbo].[AddChqbooks] AS TABLE(
  
	[ChequeBookReference] [varchar](15)  NULL,
	[AccountNumber] [varchar](15)  NULL,
	[RIMNumber] [varchar](5)  NULL,
	[PostingBranch] [int]  NULL,
	[TellerNumber] [int]  NULL,
	[ToBranch] [int]  NULL,
	[FromBranch] [int]  NULL,
	[PostingDate] [datetime]  NULL,
	[MovementType] [int]  NULL
)
GO


--Programmer :	Ahmed Osman
--Date       :	[11/02/2019]		
--Reason     :	CR#GFSY00747 - CBD_ACM16557_Emirates ID Expiry Date
--=================================================================

IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'RulesTranValidations' AND COLUMN_NAME = 'ControlField')                   
BEGIN
	ALTER TABLE [dbo].RulesTranValidations
	ADD  ControlField  nvarchar(max) 
END
GO

IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'RulesTranValidations' AND COLUMN_NAME = 'ResultField')                   
BEGIN
	ALTER TABLE [dbo].RulesTranValidations
	ADD  ResultField  nvarchar(max) 
END
GO

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'ValidationsConditions' AND COLUMN_NAME = 'Operand1')                   
BEGIN
	ALTER TABLE [dbo].ValidationsConditions
	ALTER COLUMN Operand1 varchar(max) 
END
GO

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'ValidationsConditions' AND COLUMN_NAME = 'Operand2')                   
BEGIN
	ALTER TABLE [dbo].ValidationsConditions
	ALTER COLUMN Operand2 varchar(max) 
END
GO

go
IF Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_SICCodeCategoryDetail' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_SICCodeCategoryDetail] AS TABLE(
	[SICCode] [varchar](20) NOT NULL
)
END
GO




go
IF Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_Branches' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_Branches] AS TABLE(
	[BranchID] [int] NOT NULL
)
END
GO

/*
 CreationDate : 14/2/2019      
 Programmer   : Mahmoud Saad
 Description  : ConvertPackage to service Update_ClearDetail_valueDate.dtsx                          
*/ 
IF  NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'ClearDetailValueDateType' AND ss.name = N'dbo')
	CREATE TYPE [dbo].[ClearDetailValueDateType] AS TABLE(
	     ID                    INT ,
         BatchReferenceNo      VARCHAR(30),
         ValueDate             DATE   
	)
GO
USE [Globalfs]
GO

IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[dbo].[CK_RulesTranValidations_TransactionMode]') AND parent_object_id = OBJECT_ID(N'[dbo].[RulesTranValidations]'))
ALTER TABLE [dbo].[RulesTranValidations] DROP CONSTRAINT [CK_RulesTranValidations_TransactionMode]
GO

USE [Globalfs]
GO

ALTER TABLE [dbo].[RulesTranValidations]  WITH CHECK ADD  CONSTRAINT [CK_RulesTranValidations_TransactionMode] CHECK  (([TransactionMode]='B' OR [TransactionMode]='R' OR [TransactionMode]='D' OR [TransactionMode]='C' OR [TransactionMode]='A'))
GO

ALTER TABLE [dbo].[RulesTranValidations] CHECK CONSTRAINT [CK_RulesTranValidations_TransactionMode]
GO


USE Globalfs
GO


-----Developer: Mostafa Helmy-----------------------------------------------------
-----Purpose  : ACM16557-CBD_Emirates ID Expiry Date------------------------------- 
---------CR#  : GFSY00754 --------------------------------------------------------
----------------------------------------------------------------------------------

IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'TransactionValidationCustomField')
BEGIN
CREATE TABLE dbo.TransactionValidationCustomField
(
    CustomFieldID       int    NOT NULL,
    CustomObject  nvarchar(40) NOT NULL,
    Property nvarchar(max)    NOT NULL,
    LastChanged smalldatetime  not null,
    Updator     OperatorID  not null

 CONSTRAINT [PK_TransactionValidationCustomField] PRIMARY KEY CLUSTERED 
(
	[CustomFieldID] ASC
)
)

ALTER TABLE [dbo].[TransactionValidationCustomField] ADD  CONSTRAINT [DF_TransactionValidationCustomField_LastChanged]  DEFAULT (getdate()) FOR [LastChanged]

ALTER TABLE [dbo].[TransactionValidationCustomField] ADD  CONSTRAINT [DF_TransactionValidationCustomField_Updator]  DEFAULT (suser_sname()) FOR [Updator]
end
GO




USE Globalfs
GO

--============================ Inserting DescriptorName in the ValidationActions Table as============================

	IF(NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'ValidationActions' AND COLUMN_NAME = 'DescriptorName'))
		BEGIN			
			ALTER TABLE [dbo].[ValidationActions] 
			add DescriptorName Varchar(30)
		END
	GO
	
--===========================================
--=================		sys.types
--===========================================

If Not Exists(Select * From sys.types Where name = 'TransactionValidationConditionsDT')
Begin
 CREATE TYPE TransactionValidationConditionsDT AS TABLE 
 (
    Id INT, 
    RulesTranValidationId INT, 
    Seq INT, 
    OperandsDataType INT, 
    Operand1 VARCHAR(MAX), 
    Operator VARCHAR(MAX), 
    Operand2 VARCHAR(MAX),
    LogicalOperator VARCHAR(MAX),
    DBAccessID INT,
    WebServiceName VARCHAR(MAX),
    WebServiceMethod VARCHAR(MAX),
    ArrayIndex1 INT,
    ArrayIndex2 INT,
    RecordType VARCHAR(MAX),
    RowId INT
 )
End
go

If Not Exists(Select * From sys.types Where name = 'ValidationsConditionsSQLParamsDT')
Begin
 CREATE TYPE ValidationsConditionsSQLParamsDT AS TABLE 
 (
    DBAccessID INT, 
    ParamSeq INT, 
    ParamName VARCHAR(MAX), 
    ParamValue VARCHAR(MAX), 
    DataType VARCHAR(MAX),
	RecordType VARCHAR(MAX),
    RowId INT
 )
End
go	
