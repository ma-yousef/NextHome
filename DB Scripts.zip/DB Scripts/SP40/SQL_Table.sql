--==================================================================================================================================================================
--Devolper	:	Mostafa Helmy
--Date		:	[13/11/2020]		
--Reason	:	Enh GFSY00800 - KFH - ACM000000018096 KYC Rim Field-Retrofit
--=====================================================================

PRINT 'Start. Script for CR# GFSY00800 Table Script'
GO


---------------------------------
-- Alter Table RulesTranConfig--
---------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'RulesTranConfig' AND Column_Name = 'KYCExpiryVal')
BEGIN
	ALTER TABLE RulesTranConfig
	ADD KYCExpiryVal bit NULL
	
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'RulesTranConfig' AND Column_Name = 'KYCExpiryValAction')
BEGIN
	ALTER TABLE RulesTranConfig
	ADD KYCExpiryValAction nvarchar(10) NULL
END
GO


PRINT 'End... Script for CR# GFSY00800 Table Script'
GO
--==================================================================================================================================================================

/*
Creator : Abdelrhman Mohamed
Date: 14-01-2021 retorfit 3-1-2021
Reason: Print journal Grid in printing transaction 
*/
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'PrintTranDocsGridsFields')
	BEGIN
CREATE TABLE [dbo].[PrintTranDocsGridsFields](
	[ID] [int] NOT NULL IDENTITY    ,
	[TranName] [dbo].[TransactionName] NOT NULL,
	[GridName] [varchar](100) NOT NULL,
	[FieldName] [varchar](100) NOT NULL,
	[FieldOrder] [INT] NOT NULL,
	[Creator] [dbo].[DeveloperID] NOT NULL CONSTRAINT [DF_PrintTranDocsGridsFields_Creator]  DEFAULT (suser_sname()),
	[Updator] [dbo].[DeveloperID] NOT NULL CONSTRAINT [DF_PrintTranDocsGridsFields_Updator]  DEFAULT (suser_sname()),
	[LastChanged] [datetime] NOT NULL CONSTRAINT [DF__PrintTranFields__LastC__57414C8C]  DEFAULT (getdate()),
 CONSTRAINT [PK_PrintTranDocsGridsFields] PRIMARY KEY  
(
	[ID] ASC
)
)
	END
GO



--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/03/2021]		
--Reason	:	Issue GFSX14469
--=============================

PRINT 'Start. Script for Issue GFSX14469 Table Script'
GO

----------------------------------------------
-- Alter Table Local_Inward_Messages_Detail --
----------------------------------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'MarkedAsUsed')
BEGIN
	ALTER TABLE IR
	ADD MarkedAsUsed bit NULL
END
GO

PRINT 'End... Script for Issue GFSX14469 Table Script'
GO
--==================================================================================================================================================================
IF NOT EXISTS 
(
    SELECT * 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE table_name = 'RulesLanguages' 
    AND column_name = 'PhoenixLanguageID'
)
BEGIN
	ALTER TABLE RulesLanguages
	ADD PhoenixLanguageID INT NULL
END
GO
USE Globalfs
GO
IF(Not exists(Select * FROM INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'ad_gb_sic' AND COLUMN_NAME = 'DescriptorName'))
BEGIN
	ALTER Table ad_gb_sic
	Add DescriptorName  nvarchar(max) Null
END
GO


IF(Not exists(Select * FROM INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'ad_gb_sic' AND COLUMN_NAME = 'TempValue'))
BEGIN
	ALTER Table ad_gb_sic
	Add TempValue nvarchar(max) Null
END
GO
-- =============================================
-- Author:		Ibrahim Harby 
-- Create date: 17-May-2021
-- Description:	 CR# GFSY008
-- =============================================




IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'CorrespondentCharges')
	BEGIN
		CREATE TABLE dbo.CorrespondentCharges
		(
		    bnkname							nvarchar(40)	NOT NULL,
		    currency					nvarchar(3)	NOT NULL,
			charge_type				nvarchar(3)	NOT NULL,
			corres_charges				 money not null DEFAULT 0.00 
		)
	END
GO



IF  EXISTS(SELECT * FROM sys.triggers WHERE name = 'TR_CorrespondentCharges_duplication_check')
	BEGIN
		DROP TRIGGER [dbo].[TR_CorrespondentCharges_duplication_check]
	END
GO

/****** Object:  Trigger [dbo].[TR_CorrespondentCharges_duplication_check]    Script Date: 05/20/2021 9:27:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create TRIGGER [dbo].[TR_CorrespondentCharges_duplication_check]
--ON [dbo].[CorrespondentCharges] 
ON [dbo].[CorrespondentCharges] instead of INSERT  NOT FOR REPLICATION     

AS
begin
if @@ROWCOUNT = 0 return -- If no rows affected, exit immediately
set nocount on  -- Warning: Don't set NOCOUNT on before testing @@ROWCOUNT
declare @bankname nvarchar(40) , 
@currency nvarchar(3) ,
@type nvarchar(3),
@charges money
select  @bankname = bnkname  , @currency = currency  , @type = charge_type , @charges = corres_charges from inserted
if exists (select 1 from inserted i
    inner join dbo.CorrespondentCharges t
    on i.bnkname = t.bnkname and i.currency = t.currency and i.charge_type = t.charge_type)
	  begin
		 raiserror('This Values is already inserted before',18,1)
		 rollback tran
		 return
	  end 
  else
	  begin
		  insert into CorrespondentCharges (bnkname , currency , charge_type , corres_charges )
		  values (@bankname,@currency,@type,@charges)
	  end
end
GO

ALTER TABLE [dbo].[CorrespondentCharges] ENABLE TRIGGER [TR_CorrespondentCharges_duplication_check]
GO


--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[13/05/2021]		
--Reason	:	Enh GFSY00850 - BARWA - ACM19129 - General Enhancement II
--=======================================================================

PRINT 'Start. Script for CR# GFSY00850 Table Script'
GO

-----------------------------
-- Alter Table TellerConfig -
-----------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'TellerConfig' AND Column_Name = 'HideOverrideNotification')
BEGIN
	ALTER TABLE TellerConfig
	ADD HideOverrideNotification bit NOT NULL DEFAULT 0
	
END
GO 

PRINT 'End... Script for CR# GFSY00850 Table Script'
GO
--==================================================================================================================================================================
GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'AML_Info' AND COLUMN_NAME = 'Branch')                   
BEGIN
	ALTER TABLE [dbo].AML_Info
	ADD Branch nvarchar(100) NULL 
END
GO

GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'AML_Info' AND COLUMN_NAME = 'UserName')                   
BEGIN
	ALTER TABLE [dbo].AML_Info
	ADD UserName nvarchar(100) NULL 
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'AML_Info' AND COLUMN_NAME = 'RequestDate')                   
BEGIN
	ALTER TABLE [dbo].AML_Info
	ADD RequestDate DateTime NULL 
END
GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'AML_Info' AND COLUMN_NAME = 'Cahnnel')                   
BEGIN
	ALTER TABLE [dbo].AML_Info
	ADD Cahnnel nvarchar(500) NULL 
END
GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'AML_Info' AND COLUMN_NAME = 'OwnerShip')                   
BEGIN
	ALTER TABLE [dbo].AML_Info
	ADD [OwnerShip] nvarchar(100) NULL 
END
GO


--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[19/05/2021]		
--Reason	:	Enh GFSY00849 - BARWA - ACM19131- KYC Enhancement
--===============================================================

PRINT 'Start. Script for CR# GFSY00849 Table Script'
GO

--------------------
-- Alter Table IR --
--------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'CivilIDFormat')
BEGIN
    ALTER TABLE AML_Info
    ADD CivilIDFormat nvarchar(max) NULL Default 'U'  
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'CivilID')
BEGIN
    ALTER TABLE AML_Info
    ADD CivilID nvarchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'RIMStatus')
BEGIN
    ALTER TABLE AML_Info
    ADD RIMStatus nvarchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'EmployeeID')
BEGIN
    ALTER TABLE AML_Info
    ADD EmployeeID nvarchar(max) NULL
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'EmployeeName')
BEGIN
    ALTER TABLE AML_Info
    ADD EmployeeName nvarchar(max) NULL
END
GO

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'AML_Info' AND Column_Name = 'ProductAndSerivce')
BEGIN
    ALTER TABLE AML_Info
    ALTER COLUMN ProductAndSerivce varchar(100) NULL
END
GO

PRINT 'End... Script for CR# GFSY00849 Table Script'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[20/01/2021]		
--Reason	:	Issue GFSX14415
--=============================

PRINT 'Start. Script for Issue GFSX14415 Table Script'
GO

----------------------------
-- Create TYPE IRMessages --
----------------------------
IF NOT EXISTS(SELECT * FROM sys.types WHERE name = 'IRMessagesRefNo')
BEGIN 
 CREATE TYPE IRMessagesRefNo AS TABLE 
	(
		[MsgRefNo]		nvarchar(max) NULL
	)
END
GO

PRINT 'End... Script for Issue GFSX14415 Table Script'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{19/06/2021}	
--Reason	:	Issue GFSX14603
--====================================================

PRINT 'Start. Script for Issue# GFSX14603 Table Script'
GO

Drop_old_proc ChangeOverrideRequestAndReasons     
GO
 
IF EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'ReasonIDsType')
BEGIN
	DROP TYPE ReasonIDsType
END
GO

IF NOT EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'ReasonIDsType')
	BEGIN
		CREATE TYPE ReasonIDsType AS TABLE   
			(
				ReasonID	int,
				reasonLevel int,
				GrpName		nvarchar(max)
			);
	END
GO


PRINT 'End... Script for Issue# GFSX14603 Table Script'
GO
--==================================================================================================================================================================
GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'ExternalWebServiceTran' AND COLUMN_NAME = 'HttpMethod')                   
BEGIN
	ALTER TABLE [dbo].ExternalWebServiceTran
	ADD HttpMethod nvarchar(10) NULL 
END
GO

GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'ExternalWebServiceTran' AND COLUMN_NAME = 'ContentType')                   
BEGIN
	ALTER TABLE [dbo].ExternalWebServiceTran
	ADD ContentType nvarchar(50) NULL 
END
GO