USE [Globalfs]
GO
       
If Not Exists(Select * From ServicePacks Where BasePackageName = 'ETHIX-Branch_2.00.46' And SP_Number = 34)
Begin
Insert Into ServicePacks(BasePackageName,SP_Number,SP_Name, LastPackageName, BriefDescription, DetailedDescription,IncludeWholeFilesOnly,DontRemoveTmpFldrWhenFinished,OptionalSourceList,Comments,PatchNumber)
Values('ETHIX-Branch_2.00.46', 34,'SP34_ETHIX-Branch_2.0.46.0','SP33_ETHIX-Branch_2.0.46.0','SP34_ETHIX-Branch_2.0.46.0','', 1, 0, '', '',0)
End
GO
--Programmer : Mostafa Sayed
--Date       : [12/02/2019]
--Reason     : CR#GFSY00749 - Assaraya_CRQ12278_TCR
--=================================================
--RulesDescriptor
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105320)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105320,'TLR_TCR_CONNECT',0,'Labels','Connect TCR','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105320 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
	VALUES (1105320,1025,N'����� �������','ITSOFT\mostafa.sayed','Mar 19 2019 11:13AM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105321)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105321,'TLR_TCR_AMOUNT',0,'Labels','TCR Amount','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105321 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
	VALUES (1105321,1025,N'���� ������','ITSOFT\mostafa.sayed','Mar 19 2019 11:13AM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105322)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105322,'TLR_TCR_XML_PATH_SD',0,'Labels','TCR XML Path','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105322 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
	VALUES (1105322,1025,N'���� ����� ������','ITSOFT\mostafa.sayed','Mar 19 2019 11:13AM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105323)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105323,'TLR_TCR_XML_PATH_LD',0,'Labels','TCR XML Path where XML files requests and responses located.','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105323 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
	VALUES (1105323,1025,N'��� ������ ����� ��� ����� ������� � ��������� ������','ITSOFT\mostafa.sayed','Mar 19 2019 11:13AM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105325)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105325,'TLR_USE_TCR',0,'Labels','Use TCR','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105325 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
	VALUES (1105325,1025,N'������� ������','ITSOFT\mostafa.sayed','Mar 19 2019 11:13AM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105341)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105341,'TLR_TCR_TIME_OUT_SD',0,'Labels','TCR Time Out','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105341 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
	VALUES (1105341,1025,N'���� ��� ������','ITSOFT\mostafa.sayed','Mar 19 2019 11:13AM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105342)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105342,'TLR_TCR_TIME_OUT_LD',0,'Labels','The time (in seconds) should wait till response received.','ITSOFT\mostafa.sayed','Mar 11 2019  1:23PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105342 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
	VALUES (1105342,1025,N'����� ��� �������� ��� ��� ���� �� ������ ��������','ITSOFT\mostafa.sayed','Mar 19 2019 11:13AM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105308)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105308,'TLR_TCR_TOTALS',0,'Labels','TCR Totals','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105308 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
	VALUES (1105308,1025,N'������ ������','ITSOFT\mostafa.sayed','Mar 19 2019 11:13AM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105395)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105395,'TLR_TCR_IN',0,'Labels','TCR In','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105396)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105396,'TLR_TCR_OUT',0,'Labels','TCR Out','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105397)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
	VALUES (1,1105397,'TLR_DEVICE_NAME',0,'Labels','Device Name','ITSOFT\mostafa.sayed','Oct 22 2012  5:06PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Oct 22 2012  5:06PM',N'ITSOFT\mostafa.sayed')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105397 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
	VALUES (1105397,1025,N'��� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
END
GO

--RulesHeaderFields
IF NOT EXISTS(SELECT * FROM RulesHeaderFields WHERE HeaderID = 101 And FieldID = 329)
BEGIN
	INSERT INTO rulesheaderfields(HeaderID,FieldID,Optional,ToHost,FromHost,isDupable,DSC_Pattern,DefaultTestValue,Developer,LastChanged,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (101,329,1,0,0,1,NULL,N'','ITSOFT\mostafa.sayed','Dec 27 2011 11:04AM','Dec 27 2011 11:04AM','ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'TCR_IN_AMOUNT',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesHeaderFields  WHERE HeaderID = 101 And FieldID = 2128)
BEGIN
	INSERT INTO rulesheaderfields(HeaderID,FieldID,Optional,ToHost,FromHost,isDupable,DSC_Pattern,DefaultTestValue,Developer,LastChanged,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (101,2128,1,0,0,1,NULL,N'','ITSOFT\mostafa.sayed','Dec 27 2011 11:04AM','Dec 27 2011 11:04AM','ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'TCR_OUT_AMOUNT',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesHeaderFields WHERE HeaderID = 113 And FieldID = 329)
BEGIN
	INSERT INTO rulesheaderfields(HeaderID,FieldID,Optional,ToHost,FromHost,isDupable,DSC_Pattern,DefaultTestValue,Developer,LastChanged,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (113,329,1,0,0,1,NULL,N'','ITSOFT\mostafa.sayed','Dec 27 2011 11:04AM','Dec 27 2011 11:04AM','ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'TCR_IN_AMOUNT',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesHeaderFields  WHERE HeaderID = 113 And FieldID = 2128)
BEGIN
	INSERT INTO rulesheaderfields(HeaderID,FieldID,Optional,ToHost,FromHost,isDupable,DSC_Pattern,DefaultTestValue,Developer,LastChanged,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	VALUES (113,2128,1,0,0,1,NULL,N'','ITSOFT\mostafa.sayed','Dec 27 2011 11:04AM','Dec 27 2011 11:04AM','ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,'TCR_OUT_AMOUNT',0,-1)
END
GO

--RulesTranDescriptors
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 1000007 And DSC_Name = 'TLR_USE_TCR')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (1000007,'TLR_USE_TCR','Jun 16 2014  7:31AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','Jun 16 2014  7:31AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'BUTTON_OK')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (854,'BUTTON_OK','Jun 16 2014  7:31AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','Jun 16 2014  7:31AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'BUTTON_CANCEL')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (854,'BUTTON_CANCEL','Jun 16 2014  7:31AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','Jun 16 2014  7:31AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'TLR_BRANCH')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (854,'TLR_BRANCH','Jun 16 2014  7:31AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','Jun 16 2014  7:31AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'TLR_NAME')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (854,'TLR_NAME','Jun 16 2014  7:31AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','Jun 16 2014  7:31AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'RPTBUSINESSDATE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (854,'RPTBUSINESSDATE','Jun 16 2014  7:31AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','Jun 16 2014  7:31AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'TLR_DEVICE_NAME')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (854,'TLR_DEVICE_NAME','Jun 16 2014  7:31AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','Jun 16 2014  7:31AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'TLR_CURRENCY')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (854,'TLR_CURRENCY','Jun 16 2014  7:31AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','Jun 16 2014  7:31AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'RPTNETCASH')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (854,'RPTNETCASH','Jun 16 2014  7:31AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','Jun 16 2014  7:31AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO

--BankConfig
IF NOT EXISTS(Select * from BankConfig where Name = 'TCR_XML_PATH')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'TCR_XML_PATH',@Value = '',@DataType = 'Path',@ShortDescr = 'TLR_TCR_XML_PATH_SD',@LongDescr = 'TLR_TCR_XML_PATH_LD',@MaxVal = '255',@MinVal='0'
END
GO
IF NOT EXISTS(Select * from BankConfig where Name = 'TCR_TIME_OUT')
BEGIN
	exec dbo.BANK_CONFIG_INSERT @Name= 'TCR_TIME_OUT',@Value = '0',@DataType = 'int',@ShortDescr = 'TLR_TCR_TIME_OUT_SD',@LongDescr = 'TLR_TCR_TIME_OUT_LD',@MaxVal = '255',@MinVal='0'
END
GO

--RulesParam
DECLARE @paramID int
SELECT @paramID = MAX(ParamID) +1 from RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName='TCR_CurrencyCategory')
BEGIN
	INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	VALUES (@paramID,'TCR_CurrencyCategory','Currency category name which contains allowd currencies for TCR',NULL,0,1,0,'','Static    ','','Mar 11 2019  3:39PM',N'ITSOFT\mostafa.sayed','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CashDeposit' And FieldName = 'TCR_CurrencyCategory' And Param = 'TCR_CurrencyCategory')
BEGIN
	INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	VALUES ('CashDeposit','TCR_CurrencyCategory','TCR_CurrencyCategory','',N'ITSOFT\mostafa.sayed','nvarchar','Oct 20 2015 12:56PM',NULL)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CashWithdrawal' And FieldName = 'TCR_CurrencyCategory' And Param = 'TCR_CurrencyCategory')
BEGIN
	INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	VALUES ('CashWithdrawal','TCR_CurrencyCategory','TCR_CurrencyCategory','',N'ITSOFT\mostafa.sayed','nvarchar','Oct 20 2015 12:56PM',NULL)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'BuyFCYAgainstCash' And FieldName = 'TCR_CurrencyCategory' And Param = 'TCR_CurrencyCategory')
BEGIN
	INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	VALUES ('BuyFCYAgainstCash','TCR_CurrencyCategory','TCR_CurrencyCategory','',N'ITSOFT\mostafa.sayed','nvarchar','Oct 20 2015 12:56PM',NULL)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'SellFCYAgainstCash' And FieldName = 'TCR_CurrencyCategory' And Param = 'TCR_CurrencyCategory')
BEGIN
	INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	VALUES ('SellFCYAgainstCash','TCR_CurrencyCategory','TCR_CurrencyCategory','',N'ITSOFT\mostafa.sayed','nvarchar','Oct 20 2015 12:56PM',NULL)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CashExchange' And FieldName = 'TCR_CurrencyCategory' And Param = 'TCR_CurrencyCategory')
BEGIN
	INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	VALUES ('CashExchange','TCR_CurrencyCategory','TCR_CurrencyCategory','',N'ITSOFT\mostafa.sayed','nvarchar','Oct 20 2015 12:56PM',NULL)
END
GO

--Totals
IF NOT EXISTS(SELECT * FROM RulesTotalsCategory WHERE TotalsReportCategory = 16)
BEGIN
	INSERT INTO RulesTotalsCategory(TotalsReportCategory,AppID,TotalsCategoryDescription,TotalsCategoryDescription_DSC,Developer,LastChanged,Created,Updator,RowStatus,EffectiveDate,ExpirationDate)
	VALUES (16,0,N'TCR',NULL,'ITSOFT\mostafa.sayed','May 23 2019 11:01AM','May 23 2019 11:01AM',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
END
GO

IF NOT EXISTS(SELECT * FROM RulesTotalsBuckets WHERE Bucket = 'XPath')
BEGIN
	INSERT INTO RulesTotalsBuckets(Bucket,AppID,BucketType,SortCategory,isDebit,DSC_Bucket,RowStatus,Developer,LastChanged,Created,EffectiveDate,ExpirationDate,Updator,BucketID)
	VALUES ('XPath',12,0,0,0,1101860,1,'G','Apr 26 2012  5:13PM','Apr 26 2012  5:09PM','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',N'G',12058)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTotalsBuckets WHERE Bucket = 'TCR In')
BEGIN
	INSERT INTO RulesTotalsBuckets(Bucket,AppID,BucketType,SortCategory,isDebit,DSC_Bucket,RowStatus,Developer,LastChanged,Created,EffectiveDate,ExpirationDate,Updator,BucketID)
	VALUES ('TCR In',12,0,0,1,1105395,1,'ITSOFT\mostafa.sayed','May 23 2019 12:43PM','May 23 2019 11:07AM','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',N'ITSOFT\mostafa.sayed',12059)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTotalsBuckets WHERE Bucket = 'TCR Out')
BEGIN
	INSERT INTO RulesTotalsBuckets(Bucket,AppID,BucketType,SortCategory,isDebit,DSC_Bucket,RowStatus,Developer,LastChanged,Created,EffectiveDate,ExpirationDate,Updator,BucketID)
	VALUES ('TCR Out',12,0,0,0,1105396,1,'ITSOFT\mostafa.sayed','May 23 2019 12:43PM','May 23 2019 11:09AM','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',N'ITSOFT\mostafa.sayed',12060)
END
GO
--CashDeposit
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 101 And Sequence = 3)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (101,3,1,329,-1,40,-1,'Cash Out',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 101 And Sequence = 4)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (101,4,1,329,-1,40,-1,'TCR In',0,1,'','ITSOFT\mostafa.sayed','May 23 2019 12:35PM','May 23 2019 11:12AM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',-1,-1)
END
GO
--CashWithdrawal
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 103 And Sequence = 4)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (103,4,1,2128,-1,40,-1,'Cash In',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 103 And Sequence = 5)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (103,5,1,2128,-1,40,-1,'TCR Out',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
--SellFCYAgainstCash
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 106 And Sequence = 4)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (106,4,1,329,-1,1000068,-1,'Cash Out',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 106 And Sequence = 5)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (106,5,1,329,-1,1000068,-1,'TCR In',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
--BuyFCYAgainstCash
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 104 And Sequence = 4)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (104,4,1,2128,-1,1000068,-1,'Cash In',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 104 And Sequence = 5)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (104,5,1,2128,-1,1000068,-1,'TCR Out',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
--CashExchange
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 122 And Sequence = 5)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (122,5,1,329,-1,2170,-1,'Cash Out',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 122 And Sequence = 7)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (122,7,1,329,-1,2170,-1,'TCR In',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 122 And Sequence = 6)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (122,6,1,2128,-1,2175,-1,'Cash In',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTotals WHERE TotalsID = 122 And Sequence = 8)
BEGIN
	INSERT INTO RulesTotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,Developer,LastChanged,Created,Updator,Creator,RowStatus,EffectiveDate,ExpirationDate,BumpByFieldID,BumpByFieldIndex)
	VALUES (122,8,1,2128,-1,2175,-1,'TCR Out',0,1,'','ITSOFT\mostafa.sayed','Feb  9 2010 11:25AM','Mar 31 2008  3:03PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',-1,-1)
END
GO
--SQLStrings
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 2994)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,2994,'TLR_LOG_TCR_XML','p',0,'Globalfs','dbo.Log_TCR_XML',0,NULL,NULL,'ITSOFT\mostafa.sayed','ITSOFT\mostafa.sayed','Sep  2 2018  3:40PM','Log TCR requests and responses',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 15 2012  3:15PM',' ','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 2997)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,2997,'TLR_UPDATE_TCR_JNLSeq','p',0,'Globalfs','dbo.Update_TCR_JNLSequance',0,NULL,NULL,'ITSOFT\mostafa.sayed','ITSOFT\mostafa.sayed','Sep  2 2018  3:40PM','Update journal sequance from TCR requests and responses',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 15 2012  3:15PM',' ','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100004)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100004,'TLR_GET_TCR_DEVICES','p',1,'Globalfs','dbo.GetTCRDevices',0,NULL,NULL,'ITSOFT\mostafa.sayed','ITSOFT\mostafa.sayed','Sep  2 2018  3:40PM','Get TCR devices names',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 15 2012  3:15PM',' ','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100005)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100005,'TLR_TCR_TOTALS_BusDate','p',1,'Globalfs','dbo.TCR_Totals_GetBusinessDates',0,NULL,NULL,'ITSOFT\mostafa.sayed','ITSOFT\mostafa.sayed','Sep  2 2018  3:40PM','Get tcr totals business date',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 15 2012  3:15PM',' ','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100006)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100006,'TLR_TCR_TOTALS_CURRENCY','p',1,'Globalfs','dbo.TCR_Totals_GetCurrency',0,NULL,NULL,'ITSOFT\mostafa.sayed','ITSOFT\mostafa.sayed','Sep  2 2018  3:40PM','Get tcr totals currencies',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 15 2012  3:15PM',' ','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID = 1100007)
BEGIN
 INSERT INTO SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 VALUES (1,1100007,'TLR_TCR_TOTALS_INOUT','p',1,'Globalfs','dbo.TCR_Totals_CashInOut',0,NULL,NULL,'ITSOFT\mostafa.sayed','ITSOFT\mostafa.sayed','Sep  2 2018  3:40PM','get TCR In and TCR Out buckets amounts',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 15 2012  3:15PM',' ','',0,0,1,NULL,NULL,0,0,0,0,0)
END
GO
--TCRTotals Transaction
--Component
IF NOT EXISTS ( SELECT * FROM  Component WHERE  ComponentName   = 'TCRTotals'  ) 
BEGIN 
	INSERT INTO dbo.Component ( ComponentID  , AppID  , ComponentName  , ComponentType  , Description  , ProjectDirectory  , ProjectFile  , ProjectType  , ProjectTarget  , ProductionGroup  , isSourceShipped  , TargetDirectory  , TypeLibrary  , TypeLibVersion  , GUID  , VersionInfoFile  , FileVersion  , ComponentSize  , Developer  , InstallDirectory  , Updator  , ProductionGroup2  , InstallDirectory2  , WiseProject  , BuildChangesOnly  , SourceChanged  , LastBuilt  , SymbolsFile  , ProjectGUID  )  
	SELECT dbo.Next_Component_ComponentID_For_App(1)   ,   1   ,  'TCRTotals'  ,  'DLL'  ,  ''  ,  'Teller.Net\Source\BP\Custom\TCRTotals'  ,  'TCRTotals.csproj'  ,  'C#2010'  ,  'Debug'  ,  'Client_NonRegistered'  ,   0   ,  '..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\'  ,    NULL    ,    NULL    ,    NULL    ,    NULL    ,  '2.0.46.0'  ,   53248   ,  'ITSOFT\mostafa.sayed'  ,  'shared.net\Source\bin\Common\Teller'  ,  'ITSOFT\mostafa.sayed'  ,    NULL    ,    NULL    ,  'GFSTellerdotNetClient.wsm'  ,   1   ,  'Oct  7 2012  4:19PM'  ,  'May 29 2012  7:01PM'  ,  'TCRTotals.pdb'  ,    NULL  
END 
GO
--RulesTranName
IF NOT EXISTS ( SELECT * FROM  RulesTranName WHERE  TransactionName   = 'TCRTotals' AND  TranID   =  854   ) 
BEGIN 
	INSERT INTO RulesTranName (TransactionName , TranID , Description , Developer , DSC_Description , TranCategory , HostTranType , HeaderID , AppID , TranMnemonic , isDupable , isCorrectable , isOpenDayRequired , isHostTran , isOnlineOnly , isUITranOnly , isTestable , Updator , TrackForStats , VisitRequired , Minimizable , CanBeSaved , ShowCustomerInTitle , isCTR , isMIEL , Linkable , SignOnRequired , SupervisorRequired , CanRunInLocalMode , SideMenuName , SideMenuAppName , SideMenuXSL , isBPOnly , HostTranCode , isSuperDupable , TotalsType , IsImagingTran , IsExternalTran , CanBeDeferred , Task_DSC , TaskID , ShowInDWH )  
	SELECT 'TCRTotals' , 854 , 'TCR Totals' , 'ITSOFT\mostafa.sayed' , 1105308 , 10 , 'Teller' , 101 , 1 , 'TCR' , 1 , 0 , 1 , 0 , 0 , 0 , 1 , 'ITSOFT\mostafa.sayed' , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 , 0 , '' , '' , '' , 0 , '' , 0 , NULL , 0 , 0 , 0 , '' , NULL , 0
END 
GO
--RulesContainerTrans
IF NOT EXISTS ( Select * From  RulesContainerTrans Where  container_name   = 'Teller' AND  TranName   = 'TCRTotals'  ) 
BEGIN 
	INSERT INTO dbo.RulesContainerTrans ( container_name  , TranName  , Updator  )  
	SELECT 'Teller'  ,  'TCRTotals'  ,  'ITSOFT\mostafa.sayed' 
END 
GO
--TransactionScopes
IF NOT EXISTS(Select * From TransactionScopes Where Scope = 1001 And TranID = 854)
BEGIN
	INSERT INTO TransactionScopes(Scope,TranID,Developer,Updator)
	SELECT 1001,854,'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed'
END
GO
--RulesTranConfig
IF NOT EXISTS ( Select * From  RulesTranConfig Where  TranID = 854   ) 
BEGIN 

	INSERT INTO RulesTranConfig (TranID , DenomRequired , AccountingEntries , DrAccountCategoryID , CrAccountCategoryID , LimitCategoryID , FeesCategoryID , ExchangeType , OffLineAmount , AllowEmptyAccountingEntries , VerifySignatrue , ReadAllAccountingEntries , ShowInAdmin , Updator , OD_DrAccountCategoryID , PrintOption , ForcePositioning , EnableCharges , SalesMessageActive , FutureStaleChequeDays , BackDatedStaleChequeDays , ValidateStaleCheque , StaleChequeAction , StaleChequeDefaultDate , EscWarningEnabled , ChqRngVal , ChqRngAction , Blacklisted , BlacklistedAction , BenPmtStrict , BenPmtWarning , HasCheckList , CheckListCategoryID , ShowAvlBal , AutoPrintPassBook , TranCommissionGroupID , UseSimpleChargeControl , GLCategoryID , DaysAllowedForReversal , TranLimitID , ChequeType , CashFollowAcctCurr , useFX , CheckDrawerTypeRestrictions , use_XPath_app , SameRIMForCharge , SameCurrencyForCharge , PrimaryIDExpiryVal , PrimaryIDExpiryAction , Channel_Id , RecoveryReversal , Pack_ID , CustomerInquiry , TransOptPickListID , ReviewVouchersBeforePrinting , OpenSessionRequired , Charge_AcctCategoryID , UpdDateReqired , UpdDateValue , UpdDateAction , IsFinancialTran , ShortDescription , TranOptionFLD , CHK_IncludeAccumilative , CHK_AccumilativeInfoMessage , WorkOnNightlyModeAllowed )  
	SELECT 854 , 0 , 0 , NULL , NULL , NULL , NULL , '' , 0.00 , 1 , 0 , 0 , 1 , 'ITSOFT\mostafa.sayed' , NULL , 1 , 0 , 0 , 0 , 0 , 0 , 0 , 'Warning' , 0 , 1 , 0 , 'Warning' , 0 , '' , 0 , 0 , 0 , 0 , 0 , 0 , NULL , 0 , NULL , 0 , NULL , 0 , 1 , 1 , 1 , 0 , 1 , 0 , 1 , 'Warning' , NULL , 0 , NULL , 0 , NULL , 1 , 1 , NULL , 0 , 1 , '0' , 0 , 'TCR' , '' , 0 , 0 , 0
END 
GO
--Menu_Action
IF NOT EXISTS(Select * From Menu_Action Where MenuActionID = 852)
BEGIN
	INSERT INTO Menu_Action(MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Image,Enabled,Updator,Creator)
	SELECT 852,1,1105308,'TCR Totals',2,'TCRTotals',NULL,1,N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed'
END
GO
--Menu_Definition
IF NOT EXISTS(Select * From Menu_Definition Where MenuID = 2502 And MenuKey = '24')
BEGIN
	INSERT INTO Menu_Definition(MenuID,MenuKey,Parent,MenuActionID,Updator,Creator)
	SELECT 2502,'24','2',852,N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed'
END
GO
--Programmer : Mostafa Sayed
--Date       : [14/05/2019]
--Reason     : CR#GFSY00755-ACM000000017554 Cash Withdrawal Beneficiary Name .....
----------------------------------------------------------------------------------
If Not Exists(Select * From rulestrandescriptors Where TranID = 162 And DSC_Name = 'TLR_BENEFICIARY_NAME')
Begin
 Insert Into rulestrandescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (162,'TLR_BENEFICIARY_NAME','May  9 2019  1:07PM',N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed','May  9 2019  1:07PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranField Where TranID = 162 And FieldID = 2042)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (162,2042,1,0,0,NULL,'ITSOF\mostafa.sayed','May  9 2019  1:07PM',1,NULL,'','May  9 2019  1:07PM',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 162 And FieldID = '2042' And FieldIDInPage = '_txt_benfName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (162,'2042','Teller    ','_txt_benfName',-1,-1,-1,0,0,'TLR_BENEFICIARY_NAME','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 162 And FieldID = '2042' And FieldIDInPage = '_lbl_benfName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (162,'2042','Teller    ','_lbl_benfName',-1,-1,-1,0,0,'TLR_BENEFICIARY_NAME','','','Jul 25 2011 11:36AM',N'ITSOFT\mostafa.sayed',0,NULL,NULL,NULL,NULL)
End
go

--Programmer : Mostafa Sayed
--Date       : [10/06/2019]
--Reason     : CR#GFSY00759 - Assaraya_CRQ12278_TCR
--=================================================
--RulesDescriptor
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105404)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES (1,1105404,'TLR_TCR_CASHIN',0,'Labels','TCR Cash In')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105404 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	VALUES (1105404,1025,N'����� ������� ������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105405)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES (1,1105405,'TLR_TCR_CASHOUT',0,'Labels','TCR Cash Out')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105405 And LCID = 1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	VALUES (1105405,1025,N'����� ������� ������')
END
GO

--RulesTranDescriptors
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'TLR_TCR_CASHIN')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (854,'TLR_TCR_CASHIN')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 854 And DSC_Name = 'TLR_TCR_CASHOUT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	VALUES (854,'TLR_TCR_CASHOUT')
END
GO

--RulesTranFldParam
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName='UseTCR')
BEGIN
	INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
	VALUES (@paramID1,'UseTCR','This param determine if deomination control will use tcr machine or not',NULL,0,1,0,'','Static    ','')
END
GO
--CashDeposit
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CashDeposit' And FieldName = 'Amount' And Param = 'UseTCR')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value)
 VALUES ('CashDeposit','Amount','UseTCR','0')
END
GO
--CashWithdrawal
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CashWithdrawal' And FieldName = 'Amount' And Param = 'UseTCR')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value)
 VALUES ('CashWithdrawal','Amount','UseTCR','0')
END
GO
--BuyFCYAgainstCash
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'BuyFCYAgainstCash' And FieldName = 'CREDITAMT' And Param = 'UseTCR')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value)
 VALUES ('BuyFCYAgainstCash','CREDITAMT','UseTCR','0')
END
GO
--SellFCYAgainstCash
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'SellFCYAgainstCash' And FieldName = 'DEBITAMT' And Param = 'UseTCR')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value)
 VALUES ('SellFCYAgainstCash','DEBITAMT','UseTCR','0')
END
GO
--Menu_Definition
IF NOT EXISTS(Select * From Menu_Definition Where MenuID = 2503 And MenuKey = '84')
BEGIN
	INSERT INTO Menu_Definition(MenuID,MenuKey,Parent,MenuActionID,Updator,Creator)
	SELECT 2503,'84','8',852,N'ITSOFT\mostafa.sayed',N'ITSOFT\mostafa.sayed'
END
GO
------------------------------------------------------------------------------------------
-----  Developer     : Abdelrhman Moahmed -----------------------------------------------------
-----  Creation Date : 16-06-2019  -----------------------------------------------------
-----  Purpose       : KFH_ACM16035_Special Needs Customer Retrofit - CR# GFSY00738 -----
------------------------------------------------------------------------------------------
PRINT 'Start Script for CR# GFSY00738'
GO
-------------------------------------------------------------------
----------------------------RulesDescriptor------------------------
-------------------------------------------------------------------

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105290)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105290,'TLR_SpecialNeeds_Flag_Error',0,'Labels','Please close all the special needs types for this rim before disable the special needs flag','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105291)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105291,'TLR_Disaple_SpecialNeeds',0,'Labels','Please disable the special needs flag because all the special needs types for this rim are closed','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1200272)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1200272,'TLR_PL_1200004_0',0,'PickLists','Yes','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1200273)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1200273,'TLR_PL_1200004_1',0,'PickLists','No','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go
--------------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1200268)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1200268,'TLR_SpecialNeeds',0,'Labels','Special Needs','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1200269)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1200269,'TLR_SpecialNeedsInfo',0,'Labels','Special Needs Info','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1200270)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1200270,'TLR_SpecialNeedsType',0,'Labels','Special Needs Type','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1200271)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1200271,'TLR_SpecialNeedsSeverity',0,'Labels','Special Needs Severity','ITSOFT\mostafa.helmy','Nov 27 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go
-------------------------------------------------------------------
----------------------------RulesContainerDescriptors--------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesContainerDescriptors Where container_name = 'Teller' and Descriptor_Name='TLR_SpecialNeeds')
Begin
 Insert Into RulesContainerDescriptors(container_name,Descriptor_Name)
 Values ('Teller','TLR_SpecialNeeds')
End
go
If Not Exists(Select * From RulesContainerDescriptors Where container_name = 'Teller' and Descriptor_Name='TLR_SpecialNeedsInfo')
Begin
 Insert Into RulesContainerDescriptors(container_name,Descriptor_Name)
 Values ('Teller','TLR_SpecialNeedsInfo')
End
go
If Not Exists(Select * From RulesContainerDescriptors Where container_name = 'Teller' and Descriptor_Name='TLR_SpecialNeedsType')
Begin
 Insert Into RulesContainerDescriptors(container_name,Descriptor_Name)
 Values ('Teller','TLR_SpecialNeedsType')
End
go
If Not Exists(Select * From RulesContainerDescriptors Where container_name = 'Teller' and Descriptor_Name='TLR_SpecialNeedsSeverity')
Begin
 Insert Into RulesContainerDescriptors(container_name,Descriptor_Name)
 Values ('Teller','TLR_SpecialNeedsSeverity')
End
go
-------------------------------------------------------------------
----------------------------RulesDescriptorLocal-------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105290 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105290,1025,N'����� ����� �� ����� ������� ������ ���� ������ ���� ��� ����� ���� ���������� ������ �� ��� ��� ��','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105291 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105291,1025,N'����� ����� ���� ���������� ������ �� ��� ��� �� ��� �� �������� ������ ���� ������ �� �������','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1200268 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1200268,1025,N'���������� ������','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1200269 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1200269,1025,N'������� ���������� ������','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1200270 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1200270,1025,N'��� ���������� ������','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1200271 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1200271,1025,N'����� ���������� ������','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go
-------------------
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1200272 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1200272,1025,N'���','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1200273 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1200273,1025,N'��','ITSOFT\mostafa.helmy','Nov 28 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go
-------------------------------------------------------------------
----------------------------RulesTranDescriptors-------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SpecialNeeds_Flag_Error')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SpecialNeeds_Flag_Error','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_Disaple_SpecialNeeds')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_Disaple_SpecialNeeds','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'ICSR_Include_Closed')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'ICSR_Include_Closed','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'ICSR_Include_Closed')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'ICSR_Include_Closed','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SpecialNeeds')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SpecialNeeds','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_SpecialNeeds')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_SpecialNeeds','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SpecialNeedsInfo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SpecialNeedsInfo','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_SpecialNeedsInfo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_SpecialNeedsInfo','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SpecialNeedsType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SpecialNeedsType','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_SpecialNeedsType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_SpecialNeedsType','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'TLR_SpecialNeedsSeverity')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'TLR_SpecialNeedsSeverity','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_SpecialNeedsSeverity')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_SpecialNeedsSeverity','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 564 And DSC_Name = 'Cancel')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (564,'Cancel','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'Cancel')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'Cancel','Nov 28 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Nov 28 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
-------------------------------------------------------------------
----------------------------PickLists------------------------------
-------------------------------------------------------------------

delete from PickList_InitialSelect Where PickListID = 1200004
delete from PickList_Entries Where PickListID = 1200004 
delete from PickLists Where PickListID = 1200004

if Not Exists(Select * From PickLists Where PickListID = 1200004 And PickList_Name = 'SpecialNeeds')
begin
     INSERT INTO PickLists([AppID],[PickListID],[PickList_Name],[EffectiveDate],[ExpirationDate],[LastChanged],[Created],[Updator],[Creator])
     VALUES(1,1200004,'SpecialNeeds','1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','2018-11-28 14:41:09.117','2018-11-28 14:41:09.117','ITSOFT\mostafa.helmy','ITSOFT\mostafa.helmy')
end     
go

-------------------------------------------------------------------
----------------------------PickList_Entries-----------------------
-------------------------------------------------------------------
If Not Exists(Select * From PickList_Entries Where PickListID = 1200004 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (1200004,1,1,'TLR_PL_1200004_0','Y','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018  2:41PM','Nov 27 2018  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 1200004 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (1200004,1,2,'TLR_PL_1200004_1','N','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018  2:41PM','Nov 27 2018  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
-------------------------------------------------------------------
----------------------------PickList_InitialSelect-----------------
-------------------------------------------------------------------
If Not Exists(Select * From PickList_InitialSelect Where PickListID = 1200004)
Begin
 Insert Into PickList_InitialSelect(PickListID,InitialSelect,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1200004,1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','May  4 2015 10:32AM','May  4 2015  9:24AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1)
End
go
-------------------------------------------------------------------
----------------------------RulesTranField_ex----------------------
-------------------------------------------------------------------

If Not Exists(Select * From RulesTranField_ex Where TranID = 564 and FieldIDInPage='_tab_SpecialNeeds')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible,TranFieldDescr) 
values (564,'_tab_SpecialNeeds',0,0,0,'TLR_SpecialNeedsInfo')
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 and FieldIDInPage='_tab_SpecialNeeds')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible,TranFieldDescr) 
values (547,'_tab_SpecialNeeds',0,0,0,'TLR_SpecialNeedsInfo')
End
go
------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 564 and FieldIDInPage='cbo_SpecialNeeds')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible,TranFieldDescr) 
values (564,'cbo_SpecialNeeds',0,0,1,'TLR_SpecialNeeds')
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 and FieldIDInPage='cbo_SpecialNeeds')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible,TranFieldDescr) 
values (547,'cbo_SpecialNeeds',0,0,1,'TLR_SpecialNeeds')
End
go
--------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 564 and FieldIDInPage='lbl_SpecialNeeds')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible) 
values (564,'lbl_SpecialNeeds',0,0,1)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 and FieldIDInPage='lbl_SpecialNeeds')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible) 
values (547,'lbl_SpecialNeeds',0,0,1)
End
go
------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 564 and FieldIDInPage='cbo_SpecialNeedsType')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible,TranFieldDescr) 
values (564,'cbo_SpecialNeedsType',0,0,1,'TLR_SpecialNeedsType')
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 and FieldIDInPage='cbo_SpecialNeedsType')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible,TranFieldDescr) 
values (547,'cbo_SpecialNeedsType',0,0,1,'TLR_SpecialNeedsType')
End
go
----------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 564 and FieldIDInPage='lbl_SpecialNeedsType')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible) 
values (564,'lbl_SpecialNeedsType',0,0,1)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 and FieldIDInPage='lbl_SpecialNeedsType')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible) 
values (547,'lbl_SpecialNeedsType',0,0,1)
End
go
------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 564 and FieldIDInPage='cbo_SpecialNeedsSeverity')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible,TranFieldDescr) 
values (564,'cbo_SpecialNeedsSeverity',0,0,1,'TLR_SpecialNeedsSeverity')
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 and FieldIDInPage='cbo_SpecialNeedsSeverity')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible,TranFieldDescr) 
values (547,'cbo_SpecialNeedsSeverity',0,0,1,'TLR_SpecialNeedsSeverity')
End
go
----------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 564 and FieldIDInPage='lbl_SpecialNeedsSeverity')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible) 
values (564,'lbl_SpecialNeedsSeverity',0,0,1)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 and FieldIDInPage='lbl_SpecialNeedsSeverity')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible) 
values (547,'lbl_SpecialNeedsSeverity',0,0,1)
End
go
------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 564 and FieldIDInPage='cbo_SpecialNeedsStatus')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible,TranFieldDescr) 
values (564,'cbo_SpecialNeedsStatus',0,0,1,'TLR_STATUS')
End
go
----------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 564 and FieldIDInPage='lbl_SpecialNeedsStatus')
Begin
insert into RulesTranField_ex (TranID,FieldIDInPage,Optional,IsReadOnly,IsVisible) 
values (564,'lbl_SpecialNeedsStatus',0,0,1)
End
go
-----------------------------------------
-------------------------------------------------------------------
----------------------------RulesTranField-------------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 148) --COR_ACCT_TYPE char Special Need Value
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,148,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 2044) --TLR_IR_Order_Cust_Name nvarchar
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,2044,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1835) --TLR_MultiTransfer_Acct_Name nvarchar
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1835,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1694) --TLR_PDC_DEST_ADDRESS2 nvarchar
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1694,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 1677) -- TLR_PDC_DR_APPLI_TYPE
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (547,1677,1,0,0,NULL,'ITSOFT\mostafa.sayed','Jun 13 2019 11:47AM',1,NULL,'','Jun 13 2019 11:47AM',N'ITSOFT\mostafa.sayed',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1,0,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1554) --TLR_IR_CrAccountName_GL_Arr nvarchar
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1554,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = -269918) --DenomCntIn02 int
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,-269918,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 957) --TLR_OTHER_ACCT_TYPE_ARRAY char
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,957,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1536) --TLR_IR_DrAccountName_GL_Arr, Nvarchar, Actoin, 1536
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (564,1536,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go
-------------------------------------------------
If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 148) --COR_ACCT_TYPE char Special Need Value
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,148,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 2044) --TLR_IR_Order_Cust_Name, nvarchar, SpecialNeedsSeverity Text
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,2044,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 1835) --TLR_MultiTransfer_Acct_Name, nvarchar, SpecialNeedsStatus Text,1835
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1835,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 1694) --TLR_PDC_DEST_ADDRESS2, nvarchar, SpecialNeedsStatus Value, 1694
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1694,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 1554) --TLR_IR_CrAccountName_GL_Arr, nvarchar, SpecialNeedsType Text, 1554 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1554,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = -269918) --DenomCntIn02, int,SpecialNeedsType Value, -269918
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,-269918,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 957) --TLR_OTHER_ACCT_TYPE_ARRAY, char, SpecialNeedsSeverity Value, 957
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,957,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 547 And FieldID = 1536) --TLR_IR_DrAccountName_GL_Arr, Nvarchar, Actoin, 1536
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (547,1536,1,0,0,NULL,'ITSOFT\mostafa.helmy','Dec  05 2018  9:57AM',1,NULL,'','Dec  05 2018  9:57AM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,1,-1)
End
go
-------------------------------------------------------------------
-------------------------------------------------------------------
----------------------------BankTPIInterface-----------------------
-------------------------------------------------------------------
update BankTPIInterface set NoOfParameters = 236 where FieldCode = 'cus'


If Not Exists(Select * From BankTPIInterface Where BankID = 1 And FieldCode = 'RSN')
Begin
 Insert Into BankTPIInterface(BankID,FieldCode,NoOfParameters,RequiredSequence)
 Values (1,'RSN',5,'N')
End
go
-------------------------------------------------------------------
----------------------------RulesErrorDescription------------------
-------------------------------------------------------------------

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1200004)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate) 
 Values (1200004,'TLR_Disaple_SpecialNeeds','Please disable the special needs flag because all the special needs types for this rim are closed','Please disable the special needs flag because all the special needs types for this rim are closed',4,'',1,'ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM',1,'Dec 31 2222 12:00AM')
End

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1200003)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate) 
 Values (1200003,'TLR_SpecialNeeds_Flag_Error','Please close all the special needs types for this rim before disable the special needs flag','Please close all the special needs types for this rim before disable the special needs flag',4,'',1,'ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM',1,'Dec 31 2222 12:00AM')
End

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1200000)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate) 
 Values (1200000,'TLR_SpecialNeeds_Repetition','Special Needs Type Can not be rpeated','Special Needs Type Can not be rpeated',4,'',1,'ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM',1,'Dec 31 2222 12:00AM')
End

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1200001)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate) 
 Values (1200001,'TLR_SpecialNeedsType_Select','Please enter the special needs info because this is a special needs customer','Please enter the special needs info because this is a special needs customer',4,'',1,'ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM',1,'Dec 31 2222 12:00AM')
End
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1200002)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate) 
 Values (1200002,'TLR_SpecialNeedsType_NotSelect','Please enable the special needs flag','Please enable the special needs flag',4,'',1,'ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM',1,'Dec 31 2222 12:00AM')
End
-------------------------------------------------------------------
----------------------------RulesLocalErrorDescription-------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1200004)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1200004,N'����� ����� ���� ���������� ������ �� ��� ��� �� ��� �� �������� ������ ���� ������ �� �������',N'����� ����� ���� ���������� ������ �� ��� ��� �� ��� �� �������� ������ ���� ������ �� �������','','ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM')
End

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1200003)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1200003,N'����� ����� �� ����� ������� ������ ���� ������ ���� ��� ����� ���� ���������� ������ �� ��� ��� ��',N'����� ����� �� ����� ������� ������ ���� ������ ���� ��� ����� ���� ���������� ������ �� ��� ��� ��','','ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM')
End


If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1200000)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1200000,N'��� ���������� ������ �� ���� �������',N'��� ���������� ������ �� ���� �������','','ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM')
End

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1200001)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1200001,N'����� ����� �������� �� ��� ������ ��� ������ �� ��� ���������� ������',N'����� ����� �������� �� ��� ������ ��� ������ �� ��� ���������� ������','','ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM')
End

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1200002)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1200002,N'����� ����� ���������� ������ ������',N'����� ����� ���������� ������ ������','','ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM')
End
-------------------------------------------------------------------
----------------------------RulesTranErrorDescriptions-------------
-------------------------------------------------------------------


If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'TLR_SpecialNeeds_Repetition')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','TLR_SpecialNeeds_Repetition','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'TLR_SpecialNeedsType_Select')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','TLR_SpecialNeedsType_Select','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'TLR_SpecialNeedsType_NotSelect')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','TLR_SpecialNeedsType_NotSelect','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'TLR_SpecialNeeds_Repetition')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('EditPersonalRim','TLR_SpecialNeeds_Repetition','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'TLR_SpecialNeedsType_Select')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('EditPersonalRim','TLR_SpecialNeedsType_Select','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'TLR_SpecialNeedsType_NotSelect')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('EditPersonalRim','TLR_SpecialNeedsType_NotSelect','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'TLR_Disaple_SpecialNeeds')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('EditPersonalRim','TLR_Disaple_SpecialNeeds','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go
------------------------------------------------------------------------------------------
PRINT 'End Script for CR# GFSY00738'
GO
------------------------------------------------------------------------------------------
----------------------------------------------------------------

            --Developer : Abdelrhman Mohamed 
              
            --Date : 16-06-2019
            
            --purpose: KFH_ACM16035_Special Needs Customer
            
 --------------------------------------------------------------- 

If Not Exists(Select * From picklists Where PickListID = 531)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,RowStatus)
 Values (0,531,'DPHX_SpecialNeed_Type',1)
End
go


If Not Exists(Select * From SqlStrings Where AccessID = 1000615)
Begin
 Insert Into SqlStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose)
 Values (0,1000615,'DPHX_SpecialNeed_Type','p',1,'GFSOLEDB','dbo.DPHX_SpecialNeed_Type',0,NULL,NULL,'SEL ALL PICKLISTS')
End
go

----------------------------------------------------------------------------------------------------



If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105260)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1105260,'SP_Severity_S',0,'PickLists','Simple')
End

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105261)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1105261,'SP_Severity_M',0,'PickLists','Medium')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105262)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1105262,'SP_Severity_E',0,'PickLists','Extreme')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1006989)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1006989,'Mentality',0,'PickLists','Mentality')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1006990)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1006990,'Motion',0,'PickLists','Motion')
End
go
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1006991)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1006991,'Hisbody',0,'PickLists','Hisbody')
End
go
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1006992)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1006992,'Optical',0,'PickLists','Optical')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1006993)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1006993,'Audio',0,'PickLists','Audio')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1006994)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1006994,'Evolutionary',0,'PickLists','Evolutionary')
End
go
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1006995)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1006995,'Education',0,'PickLists','Education')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1006996)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (0,1006996,'SpInfo',0,'Labels','Customer has Special needs with')
End
go
-------------------------------------------------------------

If Not Exists(Select * From picklists Where PickListID = 532)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,RowStatus)
 Values (0,532,'SpecialNeed_Severity',1)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 532 And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,RowStatus)
 Values (532,1,0,'SP_Severity_S','S',1)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 532 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,RowStatus)
 Values (532,1,1,'SP_Severity_M','M',1)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 532 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,RowStatus)
 Values (532,1,2,'SP_Severity_E','E',1)
End
go

-------------------------------------------------------------------------

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105260 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1105260,1025,N'����')
End
go


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105261 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1105261,1025,N'�����')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105262 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1105262,1025,N'���')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1006989 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1006989,1025,N'�����')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1006990 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1006990,1025,N'�����')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1006991 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1006991,1025,N'�����')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1006992 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1006992,1025,N'�����')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1006993 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1006993,1025,N'�����')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1006994 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1006994,1025,N'������')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1006995 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
 Values (1006995,1025,N'�������')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1006996 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1006996,1025,N'������ ���� �����','ITSOFT\abdelrhman.kamal','Dec 19 2018  2:01PM',N'ITSOFT\abdelrhman.kamal')
End
go
-------------------- HostCoreService ----------------------

DECLARE @serviceID int
SELECT @serviceID = MAX(ServiceId) +1 from HostCoreService 

If Not Exists(Select * From HostCoreService Where  ServiceName='ListSpecialNeedInfo' )
Begin
 Insert Into HostCoreService(ServiceId,ServiceName,ServiceAssembly,ServiceDescription)
 Values (@serviceID,'ListSpecialNeedInfo','CustomerInquiry','To list Special Need Information')
end
 -------------------- HostCoreServiceFields ----------------------


 If Not Exists( SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListSpecialNeedInfo') AND FieldId=1)
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@serviceID,1,'RimNo','int',0,0,N'0','I')
End

 If Not Exists( SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListSpecialNeedInfo') AND FieldId=2)
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@serviceID,2,'SpecialNeedTypeNames','nvarchar',999,0,N'0','O')
End



 If Not Exists( SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListSpecialNeedInfo') AND FieldId=3)
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@serviceID,3,'SpecialNeedSeverity','nvarchar',999,0,N'0','O')
End


If Not Exists( SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListSpecialNeedInfo') AND FieldId=4)
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@serviceID,4,'SpecialNeedTypeValues','nvarchar',999,0,N'0','O')
End

If Not Exists( SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT ServiceId FROM HostCoreService WHERE ServiceName='ListSpecialNeedInfo') AND FieldId=5)
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@serviceID,5,'status','nvarchar',999,0,N'0','O')
End


------------------------SP------------------------------------------------------

If Not Exists(Select * From SqlStrings Where AccessID = 2957)
Begin
 Insert Into SqlStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (0,2957,'HS_GETSPECIALNEEDINFO','p',1,'GFSOLEDB','dbo.HS_GETSPECIALNEEDINFO',0,NULL,NULL,'ITSOFT\abdelrhman.kamal','ITSOFT\mostafa.helmy','Jan 16 2019  9:19AM','Get special need Info',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018  1:51PM',' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go



------------------------------------------------------

DECLARE @serviceID int
Select @serviceID=ServiceId From HostCoreService Where  ServiceName='GetDPAcctInfoWithCustInfo'
 If Not Exists( SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetDPAcctInfoWithCustInfo') AND FieldId=166)
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@serviceID,166,'SpecialNeed','char',0,0,NULL,'O')
End
---------------------------------------------------------------
-- customer locate right panel handleing 
---------------------------------------------------------------------
DECLARE @serviceID2 int
DECLARE @FieldID2 int


Select @serviceID2=ServiceId From HostCoreService Where   ServiceName='CustomerProfile'
Select @FieldID2 =Max(FieldId)+1 FROM HostCoreServiceFields WHERE ServiceId=(SELECT ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') 
 If Not Exists( SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='SpecialNeed')
Begin
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
 Values (@serviceID2,@FieldID2,'SpecialNeed','char',0,0,NULL,'O')
End


---------------------------------------------------------------
-- POPUP FOR SPECIAL NEEDS 
---------------------------------------------------------------------

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1200274)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
 Values (1,1200274,'SpecialneedsINFO',0,'Labels','Customer has Special needs {0} with Severity {1}')
End
go

/*
CreationDate: 2018-12-02                                             
Programmer: Ahmed Osman                              
Description:  Enh GFSY00739 - KFH_ACM16035_Special Needs Customer 
*/

---------------------------------
------------sys.types------------
---------------------------------
If Not Exists(Select * From sys.types Where name = 'CustomeExcepCharges')
Begin
 CREATE TYPE CustomeExcepCharges AS TABLE 
(
    Seq INT, DataType VARCHAR(MAX), Operand1 VARCHAR(MAX), Operator VARCHAR(MAX), Operand2 VARCHAR(MAX),LogicalOperator CHAR(10)
)
End
go

------------------------------------------------------------------------------------------------------------------------------------------------------
---------RulesDescriptor---------
---------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105271)	--TLR_AddCustomException
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105271,'TLR_AddCustomException',0,'Labels','Add Custom Exception','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105264)	--TLR_SCALER_FIELD
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105264,'TLR_SCALER_FIELD',0,'Labels','Scaler Field','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105265)	--TLR_ARRAY_FIELD
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105265,'TLR_ARRAY_FIELD',0,'Labels','Array Field','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105266)	--TLR_DUMMY_FIELD
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105266,'TLR_DUMMY_FIELD',0,'Labels','Dummy Field','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105267)	--TLR_STATIC_VALUE
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105267,'TLR_STATIC_VALUE',0,'Labels','Static Value','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105268)	--TLR_VALIDATIONS_CONDITIONS
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105268,'TLR_VALIDATIONS_CONDITIONS',0,'Labels','Validations Conditions','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105269)	--TLR_FIELDNAME
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105269,'TLR_FIELDNAME',0,'Labels','Field','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105270)	--TLR_CustomExceptionCharges
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105270,'TLR_CustomExceptionCharges',0,'Labels','Custom Exception Charges','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105272)	--TLR_FieldSearch
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105272,'TLR_FieldSearch',0,'Labels','Field Search','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105273)	--TLR_ConditionID
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105273,'TLR_ConditionID',0,'Labels','Condition ID','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105274)	--TLR_MissingLogicalOperator
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105274,'TLR_MissingLogicalOperator',0,'Labels','Please add Logical Operator to Condition seq : {0}','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105280)	--TLR_CustomCharges
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105280,'TLR_CustomCharges',0,'Labels','Custom Charges','ITSoft\ahmed.orashed',1,N'ITSoft\ahmed.orashed')
End
go

------------------------------------------------------------------------------------------------------------------------------------------------------
------------RulesDescriptorLocal-----------
---------------------------------
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105271 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105271,1025,N'����� ������� ����',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105264 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105264,1025,N'��� ����',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105265 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105265,1025,N'���� ������',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105266 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105266,1025,N'��� ����',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105267 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105267,1025,N'��� ����',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105268 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105268,1025,N'��� ������',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105269 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105269,1025,N'�����',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105270 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105270,1025,N'���� ��������� �������',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105272 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105272,1025,N'����� ��������',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105273 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105273,1025,N'���� �����',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105274 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105274,1025,N'������ ����� ���� ����� ��� ����� �� ������� {0}',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105280 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105280,1025,N'������ ��������',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed')
End
go

------------------------------------------------------------------------------------------------------------------------------------------------------
------------SQLstrings-----------
---------------------------------
If Not Exists(Select * From SQLstrings Where AccessID = 2956)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,2956,'GetTranFields','p',1,'Globalfs','dbo.GetTranFields',0,NULL,NULL,'ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Get Fileds that attached on specify transaction based on datatype',1,' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

If Not Exists(Select * From SQLstrings Where AccessID = 2958)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,2958,'InsertCustomeExcepCharges','p',1,'Globalfs','dbo.InsertCustomeExcepCharges',0,NULL,NULL,'ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Insert data into table CustomExceptionChargesConditions',1,' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

If Not Exists(select * From SQLstrings Where AccessID = 2961)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,2961,'GetCustomExceptionCharges','p',1,'Globalfs','dbo.GetCustomExceptionCharges',0,NULL,NULL,'ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Insert data into table CustomExceptionChargesConditions',1,' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go   


If Not Exists(Select * From SQLstrings Where AccessID = 2964)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,2964,'GetOperandDataType','p',1,'Globalfs','dbo.GetOperandDataType',0,NULL,NULL,'ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Get Operand DataType  ',1,' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

If Not Exists(Select * From SQLstrings Where AccessID = 2965)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,2965,'GetConditionalOperator','p',1,'Globalfs','dbo.GetConditionalOperator',0,NULL,NULL,'ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Insert data into table CustomExceptionChargesConditions',1,' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

If Not Exists(Select * From SQLstrings Where AccessID = 2966)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values (1,2966,'GetEvaluationCustomException','p',1,'Globalfs','dbo.GetEvaluationCustomException',0,NULL,NULL,'ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Insert data into table CustomExceptionChargesConditions',1,' ','',0,0,1,NULL,NULL,0,0,0,0)
End
go

------------------------------------------------------------------------------------------------------------------------------------------------------
------------PickLists------------
---------------------------------
If Not Exists(Select * From PickLists Where PickListID = 533)
Begin
 Insert Into PickLists(AppID,PickListID,PickList_Name,Updator,Creator,RowStatus)
 Values (1,533,'TLR_FieldType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 533 And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (533,1,0,'TLR_SCALER_FIELD','ScalerField',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 533 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (533,1,1,'TLR_ARRAY_FIELD','ArrayField',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 533 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (533,1,2,'TLR_DUMMY_FIELD','DummyField',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 533 And DisplayOrder = 3)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (533,1,3,'TLR_STATIC_VALUE','StaticValue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
End
go

------------------------------------------------------------------------------------------------------------------------------------------------------
------------RulesErrorDescription------------
---------------------------------------------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1749)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1749,'CustomExceptionCharges','Please Enter Custom Exception Charges Conditions','Please Enter Custom Exception Charges Conditions',4,'',1,'ITSOFT\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1750)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1750,'FillAllData','Please Fill All Data','Please Fill All Data',4,'',1,'ITSOFT\ahmed.orashed',1)
End
go

------------------------------------------------------------------------------------------------------------------------------------------------------
------------RulesLocalErrorDescription------------
---------------------------------------------
If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1749)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1749,N'������ ����� ���� ������� ������',N'������ ����� ���� ������� ������','','ITSOFT\ahmed.orashed')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1750)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1750,N'����� ��� ���� ��������',N'����� ��� ���� ��������','','ITSOFT\ahmed.orashed')
End
go

------------------------------------------------------------------------------------------------------------------------------------------------------
------------RulesTranDescriptors------------
--------------------------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_VALIDATIONS_CONDITIONS')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_VALIDATIONS_CONDITIONS',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_FIELDNAME')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_FIELDNAME',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_CustomExceptionCharges')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_CustomExceptionCharges',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'COR_OPERAND1')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'COR_OPERAND1',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'COR_OPERAND2')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'COR_OPERAND2',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'MSG_OPERATOR')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'MSG_OPERATOR',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_AddCustomException')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_AddCustomException',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_Custom')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_Custom',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'FieldType')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'FieldType',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'COR_DATA_TYPE')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'COR_DATA_TYPE',N'ITSoft\nehal.ramadan',N'ITSoft\nehal.ramadan',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_FieldSearch')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_FieldSearch',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_FIELD_ID')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_FIELD_ID',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_Field_Name')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_Field_Name',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'COR_PARAMETER_DESCRIPTOR')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'COR_PARAMETER_DESCRIPTOR',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'RPT_JNL_SEQ_NUM')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'RPT_JNL_SEQ_NUM',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_Logical_Operator')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_Logical_Operator',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'COR_SAVE')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'COR_SAVE',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_ConditionID')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_ConditionID',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_DATATYPE')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_DATATYPE',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'COR_UP')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'COR_UP',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'COR_DOWN')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'COR_DOWN',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_MissingLogicalOperator')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_MissingLogicalOperator',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 546 And DSC_Name = 'TLR_CustomCharges')	
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (546,'TLR_CustomCharges',N'ITSoft\ahmed.orashed',N'ITSoft\ahmed.orashed',1)
End
go

------------------------------------------------------------------------------------------------------------------------------------------------------
------------RulesTranErrorDescriptions------------
--------------------------------------------------
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'ExceptionalCharges' And Error_Name = 'CustomExceptionCharges')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('ExceptionalCharges','CustomExceptionCharges','ITSOFT\ahmed.orashed',1)
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'ExceptionalCharges' And Error_Name = 'FillAllData')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('ExceptionalCharges','FillAllData','ITSOFT\ahmed.orashed',1)
End
go

------------------------------------------------------------------------------------------------------------------------------------------------------
------------RulesTranField------------
--------------------------------------
If Not Exists(Select * From RulesTranField Where TranID = 546 And FieldID = 1419)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (546,1419,1,0,0,NULL,'ITSOFT\ahmed.orashed',1,NULL,'','ITSOFT\ahmed.orashed',1,0,NULL,0,0,'ConditionID',0,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 546 And FieldID = 1519)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (546,1519,1,0,0,NULL,'ITSOFT\nehal.ramadan',1,NULL,'','ITSOFT\nehal.ramadan',1,0,NULL,0,0,'Seq',0,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 546 And FieldID = 1536)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (546,1536,1,0,0,NULL,'ITSOFT\nehal.ramadan',1,NULL,'','ITSOFT\nehal.ramadan',1,0,NULL,0,0,'DataType',0,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 546 And FieldID = 1545)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (546,1545,1,0,0,NULL,'ITSOFT\nehal.ramadan',1,NULL,'','ITSOFT\nehal.ramadan',1,0,NULL,0,0,'Operand1',0,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 546 And FieldID = 1554)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (546,1554,1,0,0,NULL,'ITSOFT\nehal.ramadan',1,NULL,'','ITSOFT\nehal.ramadan',1,0,NULL,0,0,'Operand2',0,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 546 And FieldID = 1563)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (546,1563,1,0,0,NULL,'ITSOFT\nehal.ramadan',1,NULL,'','ITSOFT\nehal.ramadan',1,0,NULL,0,0,'Operator',0,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 546 And FieldID = 1628)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (546,1628,1,0,0,NULL,'ITSOFT\nehal.ramadan',1,NULL,'','ITSOFT\nehal.ramadan',1,0,NULL,0,0,'LogicalOperator',0,-1)
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1777)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1777,'INVALID_Empty_Tran','Please, select transaction name !','Please, select transaction name !',2,'',1,'ITS\nehal.ramadan','Jun  9 2019 3:08PM',1,'Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'ExceptionalCharges' And Error_Name = 'INVALID_Empty_Tran')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('ExceptionalCharges','INVALID_Empty_Tran','Jul  6 2019 12:00AM','ITSOFT\nehal.ramadan',1,'Dec 31 9999 12:00AM','Sep  6 2011 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = -1099999)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1777,'INVALID_Empty_Tran','Please, select transaction name !','Please, select transaction name !',2,'',1,'ITS\nehal.ramadan','Jun  9 2019 3:08PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1777)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1777,N'�� ����, ���� ��� ������ ���� ! ',N'�� ����, ���� ��� ������ ���� ! ','','GFSDOMAIN\nehal.ramadan','Jun 27 2019  4:13PM')
End
go
--==================Mostafa Helmy [Begin:ISSUE#GFSX13276]{9Jul2019}=============================
UPDATE RulesDescriptor SET [Descriptor]='Used to check if the operator in a certain supervisor list or not where the flag value Equal the list name' WHERE Name='TLR_Accumilative_Group_LD'
GO

UPDATE RulesDescriptor SET [Descriptor]='if(flag=false) maturity method can not be changed to "Transfer" or account can not be holded' WHERE Name='AllowHoldInTrasferCD_L'
GO


UPDATE RulesDescriptor SET [Descriptor]='check if there is any restriction on the customer account type to do financial transaction in different branch' WHERE Name='TLR_BRANCH_ACCT_TYPE_REST_L'
GO


UPDATE RulesDescriptor SET [Descriptor]='if the flag is true the teller will not be aple to do Cash Count if there are pending sent movements' WHERE Name='TLR_CASHCOUNTCHKMOVS_LD'
GO


UPDATE RulesDescriptor SET [Descriptor]='in Transaction (Interface File Management), we write the File Name by the same formate that stored in the Flag Value' WHERE Name='TLR_FileNameFomat'
GO


UPDATE RulesDescriptor SET [Descriptor]='RSM pick list will display all RSM with the defined status only' WHERE Name='TLR_RSM_Status'
GO


UPDATE RulesDescriptor SET [Descriptor]='in transaction (Discounted Cheque Booking), calculate (Approved Amount/Total Amount) and compare the result with the flag value' WHERE Name='TLR_DRAWEE_GLOBALLIMIT_L'
GO


UPDATE RulesDescriptor SET [Descriptor]='if the flag true we will retrieve the next passbook number from (Stock)' WHERE Name='TLR_GETPB_FROM_STOCK_LD'
GO


UPDATE RulesDescriptor SET [Descriptor]='Handle including the exchange gain in positioning leg for xapii code' WHERE Name='IncludeGainInPositioning_LD'
GO


UPDATE RulesDescriptor SET [Descriptor]='if this flag is true, "Sent To Branch" pick list will be visible (transaction "Inward Remittance HO Swift")' WHERE Name='TLR_IsGLOverAccountBranch'
GO


UPDATE RulesDescriptor SET [Descriptor]='if flag is true the system will run more than one (file/day) in transaction (InwardClearingMultiple)' WHERE Name='MultiAutoDebit_L'
GO


UPDATE RulesDescriptor SET [Descriptor]='this flag store the value of Late Fee Cahrge Code where we chack the current charge code is equal to it or not,used in transaction(LoanAdvanceAgainstAccount)' WHERE Name='TLR_LATEFEESCHRGECODE_L'
GO


UPDATE RulesDescriptor SET [Descriptor]='used in transaction IssueTT (Cash/Account/GL) to save the PayHub Threshold Amount' WHERE Name='PayHubThresholdAmount_LD'
GO


UPDATE RulesDescriptor SET [Descriptor]='Enable\Disable CTS.CTS is abbreviation for (Cash Transaction Slip) and mean: if the depositor is not the account owner, CTS should be signed by the owner after a defined limit,Used in transation (Cash Deposit)' WHERE Name='TLR_CTS_LD'
GO


UPDATE RulesDescriptor SET [Descriptor]='Early Settlement Charge Setup' WHERE Name='TLR_EarlySettlementChgAmtCalc'
GO


UPDATE RulesDescriptor SET [Descriptor]='if the flag is false,the system will not save (exchange type info) popup if "position type pick list" is empty' WHERE Name='TLR_SystemDefaultPositions_L'
GO


UPDATE RulesDescriptor SET [Descriptor]='the flag value determine the provider charge and determine if the charge in (local currency or provider currency)' WHERE Name='TLR_UTILITYBILLSCHARGES_LD'
GO


UPDATE RulesDescriptor SET [Descriptor]='in over draft validation Compare the Amount with either the (Available Balance) or the (Warehouse Available Balance) according to the bank config: EffectiveDays . If the flag is true :warehouse balance' WHERE Name='EnableWarehouseBalance'
GO


UPDATE RulesDescriptor SET [Descriptor]='if the flag (true) the system will display book rates' WHERE Name='TLR_SHOWBOOKRATES_LD'
GO       


UPDATE RulesDescriptor SET [Descriptor]='validate GTD (Treasury Reference Number) (Yes/No)' WHERE Name='TLR_ValTreasuryRefNO_LD'
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105419)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105419,'TLR_EarlySettlementBC',0,'Labels','if the flag is true the system will add (early settelement charge) for all early settlement transactions','ITSoft\mostafa.helmy','Jul 14 2019  1:28PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 14 2019  1:28PM',N'ITSoft\mostafa.helmy')
 
 update BankConfig SET LongDescription='TLR_EarlySettlementBC' where ShortDescription='TLR_EarlySettlementChgAmtCalc' AND Name='UseEarlySettlmentSetup'
End
go
--==========================Mostafa Helmy [End:ISSUE#GFSX13276]{9Jul2019}==================================

IF EXISTS(SELECT * FROM SQLstrings where AccessName='HS_GETRIMNATIONALITIES')
BEGIN
      UPDATE SQLstrings
      SET UseNewCacheRules=1
      WHERE AccessName='HS_GETRIMNATIONALITIES'
END
GO
------Nehal Ramadan GFSX 13735
If Not Exists(Select * From picklists Where PickListID = 547)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,547,'TLR_FieldType_Charges','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','June 17 2019 11:34AM','June 17 2019 11:34AM',N'ITSOFT\nehal.ramadan',N'ITSOFT\nehal.ramadan',1)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 547 And DisplayOrder = 0)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (547,1,0,'TLR_SCALER_FIELD','ScalerField','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:42AM','Nov 27 2018 11:42AM',N'ITSOFT\nehal.ramadan',N'ITSOFT\nehal.ramadan',1,NULL)
End
go

If Not Exists(Select * From PickList_Entries Where PickListID = 547 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (547,1,1,'TLR_DUMMY_FIELD','DummyField','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:42AM','Nov 27 2018 11:42AM',N'ITSOFT\nehal.ramadan',N'ITSOFT\nehal.ramadan',1,NULL)
End
go
If Not Exists(Select * From PickList_Entries Where PickListID = 547 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (547,1,2,'TLR_STATIC_VALUE','StaticValue','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 27 2018 11:42AM','Nov 27 2018 11:42AM',N'ITSOFT\nehal.ramadan',N'ITSOFT\nehal.ramadan',1,NULL)
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1778)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1778,'INVALID_Logical_Operator','Logical operator must be empty in last condition!','Logical operator must be empty in last condition!',2,'',1,'ITS\nehal.ramadan','Jun  9 2019 3:08PM',1,'Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'ExceptionalCharges' And Error_Name = 'INVALID_Logical_Operator')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('ExceptionalCharges','INVALID_Logical_Operator','Jul  6 2019 12:00AM','ITSOFT\nehal.ramadan',1,'Dec 31 9999 12:00AM','Sep  6 2011 12:00AM')
End
go


If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1778)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1778,N'Logical Operator ���� �� ���� ���� �� ��� ��� ! ',N'Logical Operator ���� �� ���� ���� �� ��� ��� ! ','','GFSDOMAIN\nehal.ramadan','Jun 27 2019  4:13PM')
End
go
