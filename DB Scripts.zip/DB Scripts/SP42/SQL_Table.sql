USE [Globalfs]
GO
SET ANSI_NULLS ON
GO 
SET QUOTED_IDENTIFIER ON
GO 
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'SOPaymentExecServiceLog')
BEGIN 
	CREATE TABLE [dbo].[SOPaymentExecServiceLog](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[SoType] [nvarchar](50) NOT NULL,
		[BusinessDate] [datetime] NOT NULL,
		[TransferIdNumber] [nvarchar](80) NOT NULL,
		[TransferDescription] [nvarchar](Max) NOT NULL,
		[AccountNumber] [nvarchar](50) NOT NULL,
		[AccountType]  [nvarchar](10) NOT NULL,
		[RimNumber] [int] NOT NULL,
		[TransferAmount] [money] NOT NULL,
		[NextTransferDate] [datetime] NOT NULL,
		[TransferCurrency] [nvarchar](50) NOT NULL,
		[ToAccountCurrency] [nvarchar](50) NOT NULL,
		[FromAccountCurrency] [nvarchar](50) NOT NULL,
		[BranchNo] [int] NOT NULL,
		[AttemptNo] [int]  NULL,
		[DepositLoan] [nvarchar](50)  NULL,
		[NumberOfRetries] [int]  NULL,
		[FatcaStatus] [nvarchar](50) NULL,
		[TransferStatus] [nvarchar](50) NULL,
		[CoreReferenceNumber] [nvarchar](100) NULL,
		[ErrorNumber] [nvarchar](50) NULL,
		[ErrorDescription] [nvarchar](Max) NULL,	
		[MorningProcessing] [nvarchar](1) Not NULL,
		[CountryCode] [nvarchar](50) NULL,
		[crs_participate] [nvarchar](50) NULL,
		[Created] [datetime] NOT NULL DEFAULT getdate(),
		[Creator] [dbo].[OperatorID] NOT NULL DEFAULT suser_sname(), 
	PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [DynamicData]
	) ON [DynamicData]
END
GO
--*************************************************************************************************************************************************
--*************************************************************************************************************************************************
--*************************************************************************************************************************************************
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'SOPaymentExecServiceErrorLog')
BEGIN
	CREATE TABLE [dbo].[SOPaymentExecServiceErrorLog](
		[ID] [int] IDENTITY(1,1) NOT NULL,
		[ErrorDescription] [nvarchar](Max) NOT NULL,
		[BusinessDate] [datetime] NOT NULL,
		[CoreRefNumber] [nvarchar](50)  NULL,
		[ErrorReason] [nvarchar](50)  NULL, 
		[Created] [datetime] NOT NULL DEFAULT getdate(),
		[Creator] [dbo].[OperatorID] NOT NULL DEFAULT suser_sname(),
	PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [DynamicData]
	) ON [DynamicData]
END 
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Atef
--Date		:	[21/11/2021]		
--Reason	:	[Retrofit: CR # GFSY00875][21-11-2021]
--==================================================
GO
IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE Name = N'IsWSIssued' AND Object_ID = Object_ID(N'dbo.SoldRemittance'))
BEGIN
	ALTER TABLE SoldRemittance  
	ADD IsWSIssued bit 
	DEFAULT 0 NOT NULL;
END
GO
--Devolper	 :	Aya Tarek 
--Date       :	[20/12/2021]		
--Reason     :	CR#GFSY00886 [AUB_PurposeCode_swiftField]
------------------------------------------------------------------------------------------------
PRINT 'Start. Script for CR# GFSY00886 Table Script'
GO

----------------------
-- Table TT_PurposeCode
----------------------
USE Globalfs
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME  = 'TT_PurposeCode')
	BEGIN
		CREATE TABLE dbo.TT_PurposeCode
		(
	        [Iso_Country_Code] [char](2) Not NULL,
	        [PurposeCode] [varchar](35) Not NULL,
	        [PurposeDescription] [nvarchar](max) NULL,
			[SwiftField] [varchar](10) Not NULL,
			[FieldLine][int] Not NULL,
			[FieldLine_IS_Enable][char](1) Not NULL
			Constraint  PK_IsoPurpose Primary key (Iso_Country_Code,PurposeCode)
       )
	END
	GO    
	
IF  EXISTS(SELECT * FROM sys.triggers WHERE name = 'TR_TT_PurposeCode_unique_SwiftField')
	BEGIN
		DROP TRIGGER [dbo].[TR_TT_PurposeCode_unique_SwiftField]
	END
GO

create TRIGGER [dbo].[TR_TT_PurposeCode_unique_SwiftField]
ON [dbo].[TT_PurposeCode] instead of INSERT  NOT FOR REPLICATION     

AS
begin
if @@ROWCOUNT = 0 return
set nocount on  
declare @Iso_Country_Code char(2) ,
		@SwiftField varchar(10),
		@FieldLine int ,
		@FieldLine_IS_Enable char(1),
		@PurposeCode varchar(35) ,
	    @PurposeDescription nvarchar(max)
select  @Iso_Country_Code = Iso_Country_Code  ,@PurposeCode=PurposeCode,@PurposeDescription=PurposeDescription, @SwiftField = SwiftField  , @FieldLine = FieldLine , @FieldLine_IS_Enable = FieldLine_IS_Enable from inserted
  if exists (select 1 from inserted i
    inner join dbo.TT_PurposeCode t
    on i.Iso_Country_Code = t.Iso_Country_Code and i.SwiftField = t.SwiftField and i.FieldLine = t.FieldLine and i.FieldLine_IS_Enable = t.FieldLine_IS_Enable)
	  begin	 
		   insert into TT_PurposeCode ( Iso_Country_Code   ,PurposeCode,PurposeDescription, SwiftField  , FieldLine , FieldLine_IS_Enable)
		   values (@Iso_Country_Code   ,@PurposeCode,@PurposeDescription, @SwiftField  , @FieldLine , @FieldLine_IS_Enable)
	  end 

	 else if Not exists (select 1 from inserted i
    inner join dbo.TT_PurposeCode t
    on i.Iso_Country_Code = t.Iso_Country_Code )
	  begin	 
		   insert into TT_PurposeCode ( Iso_Country_Code   ,PurposeCode,PurposeDescription, SwiftField  , FieldLine , FieldLine_IS_Enable)
		   values (@Iso_Country_Code   ,@PurposeCode,@PurposeDescription, @SwiftField  , @FieldLine , @FieldLine_IS_Enable)
	  end 
  else
	  begin
	       raiserror('(Swift Field, Field Line and FieldLine Is Enabled) should be the same for One Iso Country Code',18,1)
		   rollback tran
		   return
	  end
--Arabic Puposecode
if(63=(select UNICODE(@PurposeCode)))
	  begin	 
		
	       raiserror('Purpose code must be in English',18,1)
		   rollback tran
		   return
	  end
end
GO

ALTER TABLE [dbo].[TT_PurposeCode] ENABLE TRIGGER [TR_TT_PurposeCode_unique_SwiftField]
GO
--update
IF  EXISTS(SELECT * FROM sys.triggers WHERE name = 'TR_TT_PurposeCode_unique_SwiftField_Update')
	BEGIN
		DROP TRIGGER [dbo].[TR_TT_PurposeCode_unique_SwiftField_Update]
	END
GO

CREATE TRIGGER [dbo].[TR_TT_PurposeCode_unique_SwiftField_Update]  
ON [dbo].[TT_PurposeCode] 
AFTER UPDATE NOT FOR REPLICATION    
AS  
begin
if @@ROWCOUNT = 0 return  
set nocount on  
   
declare @Iso_Country_Code char(2) ,
        @SwiftField varchar(10),
		@FieldLine int ,
		@PurposeCode varchar(35) ,
		@FieldLine_IS_Enable char(1) 
select  @Iso_Country_Code = Iso_Country_Code  ,@PurposeCode = PurposeCode, @SwiftField = SwiftField  , @FieldLine = FieldLine , @FieldLine_IS_Enable = FieldLine_IS_Enable from inserted
if (update(SwiftField))
 begin   
    if exists (select 1 from deleted d   
              where not exists (select 1 from inserted i   
                                where i.SwiftField = d.SwiftField and i.Iso_Country_Code =d.Iso_Country_Code))  
	 begin  
        raiserror('(Swift Field)should be the same for One Iso Country Code',18,1)
        if @@TRANCOUNT > 0  
        rollback transaction  
        return  
    end  
 end  
 

 if (update(FieldLine))
 begin   
        if exists (select 1 from deleted d   
              where not exists (select 1 from inserted i   
                                where i.FieldLine = d.FieldLine and i.Iso_Country_Code =d.Iso_Country_Code))  
	 begin  
        raiserror('(Field Line)should be the same for One Iso Country Code',18,1)
        if @@TRANCOUNT > 0  
        rollback transaction  
        return  
    end  
 end  

 if (update(FieldLine_IS_Enable))
 begin   
        if exists (select 1 from deleted d   
              where not exists (select 1 from inserted i   
                                where i.FieldLine_IS_Enable = d.FieldLine_IS_Enable and i.Iso_Country_Code =d.Iso_Country_Code))  
	 begin  
        raiserror('(FieldLine_IS_Enable)should be the same for One Iso Country Code',18,1)
        if @@TRANCOUNT > 0  
        rollback transaction  
        return  
    end  
 end  
 --Arabic Puposecode
if(63=(select UNICODE(@PurposeCode)))
	  begin	 
		
	       raiserror('Purpose code must be in English',18,1)
		   rollback tran
		   return
	  end
End
GO

ALTER TABLE [dbo].[TT_PurposeCode] ENABLE TRIGGER [TR_TT_PurposeCode_unique_SwiftField_Update]
GO

PRINT 'END. Script for CR# GFSY00886 Table Script'
GO
