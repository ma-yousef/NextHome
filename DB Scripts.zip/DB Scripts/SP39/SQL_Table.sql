--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[30/06/2020]		
--Reason	:	Issue GFSX14119 
--==================================================

PRINT 'Start. Script for CR# GFSX14119 Table Script'
GO

IF EXISTS(SELECT 1 FROM sys.columns WHERE Name = N'Name' AND Object_ID = Object_ID(N'dbo.EFTS_Biller'))
BEGIN
    ALTER TABLE [EFTS_Biller]
	ALTER COLUMN [Name] nvarchar(max) 
END

GO

PRINT 'End... Script for CR# GFSX14119 Table Script'
GO
--==================================================================================================================================================================
--Devolper :	Ahmed Osman
--Date       :	[03/10/2019]		
--Reason     :	CR#GFSY00768 - BBK_ACM17813_Enable EFTS Service
--=============================================================
PRINT 'Start. Script for CR# GFSY00768 Table Script'
GO

-------------------------------
-- Add BalanceAuditTrails Table
-------------------------------
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'EFTS_Participants')
	BEGIN
		CREATE TABLE dbo.EFTS_Participants
		(
			ID									int				NOT NULL,
		    SwiftBIC							nvarchar(MAX)	NULL,
		    ParticipantName						nvarchar(MAX)	NULL,
			ParticipantShortName				nvarchar(MAX)	NULL,
			ParticipantCountryName				nvarchar(MAX)	NULL,
			ParticipantAddress					nvarchar(MAX)	NULL,
			ParticipantCity						nvarchar(MAX)	NULL,
			ParticipantItCode					nvarchar(MAX)	NULL,
		    ParticipantPtCode					nvarchar(MAX)	NULL,
			ParticipantModifDate				nvarchar(MAX)	NULL,
		    ParticipantStatus					nvarchar(MAX)	NULL,
		    ParticipantType						nvarchar(MAX)	NULL,
			ParticipantInstitutionName			nvarchar(MAX)	NULL,
			AlternativeBICParticipant			nvarchar(MAX)	NULL,
			BICofParticipant					nvarchar(MAX)	NULL,
			ContactPerson1TelephoneNumber		nvarchar(MAX)	NULL,
			ContactPerson2TelephoneNumber		nvarchar(MAX)	NULL,
			DNSAccountNumber					nvarchar(MAX)	NULL,
			NRTAccountNumber					nvarchar(MAX)	NULL
		)
	END
GO

-------------------------------
-- Add EFTS_ResponseCode Table
-------------------------------
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'EFTS_ResponseCode')
	BEGIN
		CREATE TABLE dbo.EFTS_ResponseCode
		(
			ID									int				NOT NULL identity(1,1),
		    ErrorCode							nvarchar(50)	NOT NULL Unique,
		    Description							nvarchar(MAX)	NOT NULL
		)
	END
GO

PRINT 'End... Script for CR# GFSY00768 Table Script'
GO
--Modifier			: Mostafa Sayed
--Modification Date	: [06/11/2019]
--Reason			: CR#GFSY00772 - BBK_ACM000000017813 - Print after host rejected
------------------------------------------------------------------------------------
IF NOT EXISTS 
(
    SELECT * 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE table_name = 'PrintTranDocs' 
    AND column_name = 'PrintAfterHostRejected'
)
BEGIN
	ALTER TABLE PrintTranDocs
	ADD PrintAfterHostRejected BIT NOT NULL DEFAULT(0)
END
GO
----------------------------------------------------- PM_Vendor Begin----------------------------------------------------------------------------------------------

IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'PM_Vendor' AND COLUMN_NAME = 'XTM')                   
BEGIN
	ALTER TABLE dbo.PM_Vendor
	ADD  XTM  BIT
    DEFAULT 0 NOT NULL
END
GO
IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'PM' AND COLUMN_NAME = 'XTMMachineName')                   
BEGIN
	ALTER TABLE dbo.PM
	ADD  XTMMachineName  NVarchar(30)
END
GO
----------------------------------------------------- PM_Vendor End -------------------------------------------------------------------------------------
IF  NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_XTMCurrencies' AND ss.name = N'dbo')
CREATE TYPE [dbo].[T_XTMCurrencies] AS TABLE(
  
	[Currency] [varchar](4) NOT NULL
)
GO
GO
/*
 CreationDate : 09-25-2019      
 Programmer   : Sara Badwy
 Description  : KFH_ACMACM16880_Gold Dispense Retrofit                  
*/ 
IF  NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'UpdateXtmPlates' AND ss.name = N'dbo')

CREATE TYPE [dbo].[UpdateXtmPlates] AS TABLE(
  
	[PlateSerial] [varchar](100)  NULL,
	[XTMMachineName] [Nvarchar](100)  NULL,
	[Status] [int]  NULL,
	[VendorName] [Nvarchar](100)  NULL
)
GO

/*    
Creator : Ibrahim Harby
Date: 18-November-2020
Reason: alter table to add new column "FutureDays" - CR# GfsY00829 - Retrofit - ADIB_ACM000000019147_Cash Deposit Effective Date Future Value

*/
IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'CurrencyEffectiveDays' AND COLUMN_NAME = 'FutureDays')                   
BEGIN
	ALTER TABLE [dbo].CurrencyEffectiveDays
	ADD  FutureDays  int  not NULL DEFAULT 0
END
GO


-- =============================================
-- Author:		Aya Tarek
-- Create date: 5/10/2020
-- Description:	Alter ad_gb_country , Add two columns
-- =============================================


IF NOT EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'ad_gb_country' AND Column_Name = 'ISO_Code')
BEGIN
	ALTER TABLE ad_gb_country
	ADD ISO_Code char(2) NULL  
END
GO

IF NOT EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'ad_gb_country' AND Column_Name = 'crs_participate')
BEGIN
	ALTER TABLE ad_gb_country
	ADD crs_participate char(1) NULL Default 'N'  
END
GO
 Drop_old_proc IRBulkInsertIntoIR     
  go
  
IF EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
	drop TYPE IRBulkTableType
end
go

IF not EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
CREATE TYPE IRBulkTableType AS TABLE   
(FileRefNo     varchar(20),        
 FilePathName   varchar(255),        
 MsgRefNo    char(13),        
 StatusID    int,        
 ActionId    int,        
 PaymentMethodID  int,        
 DateTimeStamp   smalldatetime,        
 PreparedBy    varchar(60),--OperatorID,        
 MsgValueDate   DATETIME2,        
 ValueDate    DATETIME2,        
 DrAccountNo    varchar(60),        
 DrAccountNo_AcctType varchar(5),      
 DrAccountNo_ApplType varchar(5),      
 DrAccountNo_DepLoan varchar(5),      
 DrAccountName   nvarchar(255),        
 DrCurrency    varchar(4),--CurrencyType,        
 DrAmount    decimal(21,6),        
 DrAddress    nvarchar(255),        
 SenderBank    nvarchar(255),        
 DrExchangeRate   decimal(21,6),        
 DrCommission   decimal(21,6),        
 CrAccountNo    varchar(60),      
 CrAccountNo_AcctType varchar(5),      
 CrAccountNo_ApplType varchar(5),      
 CrAccountNo_DepLoan varchar(5),       
 CrAccountName   nvarchar(255),        
 CrCurrency    varchar(4),--CurrencyType,        
 CrAmount    decimal(21,6),        
 CrAddress    nvarchar(255),        
 OrderingCustomer  varchar(255),        
 CrExchangeRate   decimal(21,6),        
 CrCommission   decimal(21,6),        
 OriginalMsg    varchar(1000),        
 Fld_50K    varchar(255),        
 Fld_59     varchar(255),        
 Charge_Det    char(3),    
 Account_With_Ref varchar(100),    --50
 Account_With_Ac varchar(100),    --50
 Account_With_Name nvarchar(100),    --50
 ValueCurrency varchar(5),    
 Order_Cust_Name nvarchar(100),    --50
 Order_Cust_Add1 varchar(150),    --50
 Order_Cust_Add2 varchar(150),   --50 
 Order_Inst varchar(100),    --50
 Order_Inst_Name varchar(100),    --50
 Order_Inst_Add1 varchar(150),    --50
 BeneficiaryAccount varchar(100),   --60 
 FLD_70 varchar(150),    --50
 FLD_71A varchar(150),    --50
 BeneficiaryName nvarchar(140),  --40  
 BeneficiaryAddress varchar(255) ,    
 Updator    varchar(60),--OperatorID  ,    
 DB_DrValueDate DATETIME2,    
 DB_CrValueDate DATETIME2,    
 DB_DrNarrative varchar(150),    --100
 DB_CrNarrative varchar(150),    --100
 DB_FLD_20 varchar(100),    --50
 DB_FLD_23 varchar(100),    --50
 DB_FLD_33 varchar(100),    --50
 DB_FLD_52 varchar(200),  --150),    --100
 DB_FLD_53 varchar(150),    --100
 MsgType varchar(10),    
 ExceptionList varchar(8000),    
 Is_FLD_20_Duplicate bit,    
 DrRealExchangeRate decimal(21,6),        
 CrRealExchangeRate decimal(21,6),    
 TTAmount decimal(21,6),    
 TTCurrency varchar(4),    
 DrSellExchangeRate decimal(21,6),    
 CrBuyExchangeRate decimal(21,6)  ,  
 IBAN varchar(100),  --60
 Ordering_IBAN  varchar(100), --60   
 Sender_BIC nvarchar(150),--,  --100  
 --CrRimNo varchar(100),  
 --Ben_Inst_BIC varchar(100) 
 FLD_111 nvarchar(3),
 FLD_121 nvarchar(36),
 CrRimNo varchar(100)
);  
end
GO
--==================================================================================================================================================================
--Devolper	:	Mostafa Helmy
--Date		:	[28/09/2020]		
--Reason	:	Enh GFSY00823 BARWA_ACM18595_Inward Transfers_Part3
--=====================================================================

PRINT 'Start. Script for CR# GFSY00822 Table Script'
GO


---------------------------------------------
-- Alter Table Local_Inward_Messages_Detail--
---------------------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'Local_Inward_Messages_Detail' AND Column_Name = 'IsHolded')
BEGIN
	ALTER TABLE Local_Inward_Messages_Detail
	ADD IsHolded bit NULL
	
END
GO

PRINT 'End... Script for CR# GFSY00823 Table Script'
GO
--==================================================================================================================================================================
-- =============================================
-- Author:		Aya Tarek
-- Create date: 5/10/2020
-- Description:	Alter ad_gb_country , Add two columns
-- =============================================


IF NOT EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'ad_gb_country' AND Column_Name = 'ISO_Code')
BEGIN
	ALTER TABLE ad_gb_country
	ADD ISO_Code char(2) NULL  
END
GO

IF NOT EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'ad_gb_country' AND Column_Name = 'crs_participate')
BEGIN
	ALTER TABLE ad_gb_country
	ADD crs_participate char(1) NULL Default 'N'  
END
GO