-------------------------------------------------------OLD GOLD---------------------------------------------------------------------------
--TABLES: PM_MovementType, PM_MovementDetails, PM_Movement
IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.[REFERENTIAL_CONSTRAINTS] WHERE CONSTRAINT_NAME = 'FK_PM_Movement_PM_MovementType')                   
BEGIN
	ALTER TABLE [dbo].PM_Movement
	
	DROP CONSTRAINT FK_PM_Movement_PM_MovementType
END
GO

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.[REFERENTIAL_CONSTRAINTS] WHERE CONSTRAINT_NAME = 'FK_PM_MovementDetails_PM')                   
BEGIN
	ALTER TABLE [dbo].PM_MovementDetails
	
	DROP CONSTRAINT FK_PM_MovementDetails_PM
END
GO

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.[TABLES] WHERE TABLE_NAME = 'PM_MovementType')                   
BEGIN
	DROP TABLE PM_MovementType
END
GO

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.[TABLES] WHERE TABLE_NAME = 'PM_MovementDetails')                   
BEGIN
	DROP TABLE PM_MovementDetails
END
GO

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.[TABLES] WHERE TABLE_NAME = 'PM_Movement')                   
BEGIN
	DROP TABLE PM_Movement
END
GO
--==================================================================================================================
------------------------------------[PM_PartnerType]-----------------------------------  exist
IF Not Exists (Select *    From INFORMATION_SCHEMA.tables  Where Table_name = 'PM_PartnerType'  )
Begin
CREATE TABLE [dbo].[PM_PartnerType](
	[PartnerTypeID] [int] NOT NULL,
	[PartnerType] [nvarchar](50) NULL,
 CONSTRAINT [PK_PM_PartnerType] PRIMARY KEY CLUSTERED 
(
	[PartnerTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]
End
GO
---------------------------------------PM_Type--------------------------------------------------- exist
IF Not Exists (Select *    From INFORMATION_SCHEMA.tables  Where Table_name = 'PM_Type'  )
Begin
CREATE TABLE [dbo].[PM_Type](
	[PMTypeID] [int] NOT NULL,
	[PM] [nvarchar](50) NOT NULL,
	[ISO_Code] [char](3) NOT NULL,
	[LastChanged] [datetime] NOT NULL,
	[Creator] [dbo].[OperatorID] NOT NULL,
	[Created] [datetime] NOT NULL,
	[Updator] [dbo].[OperatorID] NOT NULL,
	[Row_ID] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
 CONSTRAINT [PK_PM_Type] PRIMARY KEY CLUSTERED 
(
	[PMTypeID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]


ALTER TABLE [dbo].[PM_Type] ADD  CONSTRAINT [DF_PM_Type_LastChanged]  DEFAULT (getdate()) FOR [LastChanged]


ALTER TABLE [dbo].[PM_Type] ADD  CONSTRAINT [DF_PM_Type_Creator]  DEFAULT (suser_sname()) FOR [Creator]


ALTER TABLE [dbo].[PM_Type] ADD  CONSTRAINT [DF_PM_Type_Created]  DEFAULT (getdate()) FOR [Created]


ALTER TABLE [dbo].[PM_Type] ADD  CONSTRAINT [DF_PM_Type_Updator]  DEFAULT (suser_sname()) FOR [Updator]


ALTER TABLE [dbo].[PM_Type] ADD  CONSTRAINT [DF_PM_Type_Row_ID]  DEFAULT (newid()) FOR [Row_ID]
End
GO
----------------------------------------PM_Vendor-------------------------------------------------exist
if not exists (select * from dbo.sysobjects where id = object_id(N'[PM_Vendor]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
Begin
CREATE TABLE [dbo].[PM_Vendor](
	[VendorID] [int] NOT NULL,
	[Vendor] [nvarchar](50) NOT NULL,
	[NostroAccount] [varchar](60) NOT NULL,
	[acct_type] [varchar](50) NOT NULL,
	[appl_type] [varchar](5) NULL,
	[dep_loan] [varchar](50) NOT NULL,
	[acct_curr] [char](3) NOT NULL,
	[LastChanged] [datetime] NOT NULL,
	[Creator] [dbo].[OperatorID] NOT NULL,
	[Created] [datetime] NOT NULL,
	[Updator] [dbo].[OperatorID] NOT NULL,
	[Row_ID] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
 CONSTRAINT [PK_PM_Vendor] PRIMARY KEY CLUSTERED 
(
	[VendorID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]



SET ANSI_PADDING ON


ALTER TABLE [dbo].[PM_Vendor] ADD  CONSTRAINT [DF_PM_Vendor_acct_type]  DEFAULT ('CUR') FOR [acct_type]


ALTER TABLE [dbo].[PM_Vendor] ADD  CONSTRAINT [DF_PM_Vendor_appl_type]  DEFAULT ('') FOR [appl_type]


ALTER TABLE [dbo].[PM_Vendor] ADD  CONSTRAINT [DF_PM_Vendor_dep_loan]  DEFAULT ('DP') FOR [dep_loan]


ALTER TABLE [dbo].[PM_Vendor] ADD  CONSTRAINT [DF_PM_Vendor_acct_curr]  DEFAULT ('BHD') FOR [acct_curr]


ALTER TABLE [dbo].[PM_Vendor] ADD  CONSTRAINT [DF_PM_Vendor_LastChanged]  DEFAULT (getdate()) FOR [LastChanged]


ALTER TABLE [dbo].[PM_Vendor] ADD  CONSTRAINT [DF_PM_Vendor_Creator]  DEFAULT (suser_sname()) FOR [Creator]


ALTER TABLE [dbo].[PM_Vendor] ADD  CONSTRAINT [DF_PM_Vendor_Created]  DEFAULT (getdate()) FOR [Created]


ALTER TABLE [dbo].[PM_Vendor] ADD  CONSTRAINT [DF_PM_Vendor_Updator]  DEFAULT (suser_sname()) FOR [Updator]


ALTER TABLE [dbo].[PM_Vendor] ADD  CONSTRAINT [DF_PM_Vendor_Row_ID]  DEFAULT (newid()) FOR [Row_ID]
End


Go

----------------------------------------PM_VendorToType---------------------------------------------exist----
if not exists (select * from dbo.sysobjects where id = object_id(N'[PM_VendorToType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
Begin
CREATE TABLE [dbo].[PM_VendorToType](
	[PMTypeID] [int] NOT NULL,
	[VendorID] [int] NOT NULL,
	[LastChanged] [datetime] NOT NULL,
	[Creator] [dbo].[OperatorID] NOT NULL,
	[Created] [datetime] NOT NULL,
	[Updator] [dbo].[OperatorID] NOT NULL,
	[Row_ID] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
 CONSTRAINT [PK_PM_VendorToType] PRIMARY KEY CLUSTERED 
(
	[PMTypeID] ASC,
	[VendorID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]



ALTER TABLE [dbo].[PM_VendorToType]  WITH CHECK ADD  CONSTRAINT [FK_PM_VendorToType_PM_Type] FOREIGN KEY([PMTypeID])
REFERENCES [dbo].[PM_Type] ([PMTypeID])


ALTER TABLE [dbo].[PM_VendorToType] CHECK CONSTRAINT [FK_PM_VendorToType_PM_Type]


ALTER TABLE [dbo].[PM_VendorToType]  WITH CHECK ADD  CONSTRAINT [FK_PM_VendorToType_PM_Vendor] FOREIGN KEY([VendorID])
REFERENCES [dbo].[PM_Vendor] ([VendorID])


ALTER TABLE [dbo].[PM_VendorToType] CHECK CONSTRAINT [FK_PM_VendorToType_PM_Vendor]


ALTER TABLE [dbo].[PM_VendorToType] ADD  DEFAULT (getdate()) FOR [LastChanged]


ALTER TABLE [dbo].[PM_VendorToType] ADD  DEFAULT (suser_sname()) FOR [Creator]


ALTER TABLE [dbo].[PM_VendorToType] ADD  DEFAULT (getdate()) FOR [Created]


ALTER TABLE [dbo].[PM_VendorToType] ADD  DEFAULT (suser_sname()) FOR [Updator]


ALTER TABLE [dbo].[PM_VendorToType] ADD  DEFAULT (newid()) FOR [Row_ID]
End
GO
----------------------------------------PM------------------------------------------------- exist 
if not exists (select * from dbo.sysobjects where id = object_id(N'[PM]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
Begin
CREATE TABLE [dbo].[PM](
	[SerialNo] [varchar](100) NOT NULL,
	[PMTypeID] [int] NOT NULL,
	[VendorID] [int] NOT NULL,
	[Denom] [int] NOT NULL,
	[Status] [int] NOT NULL,
	[Branch] [dbo].[hierarchy_node#] NULL,
	[User_ID] [dbo].[internal_user_ID] NULL,
	[CashDrawer] [dbo].[CashDrawerNumber] NULL,
	[CustomerAccount] [dbo].[AccountNumber] NULL,
	[RIM] [dbo].[RIM_Number] NULL,
	[LastChanged] [datetime] NOT NULL,
	[Creator] [dbo].[OperatorID] NOT NULL,
	[Created] [datetime] NOT NULL,
	[Updator] [dbo].[OperatorID] NOT NULL,
	[Row_ID] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
 CONSTRAINT [PK_PM] PRIMARY KEY CLUSTERED 
(
	[SerialNo] ASC,
	[PMTypeID] ASC,
	[VendorID] ASC,
	[Denom] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]



ALTER TABLE [dbo].[PM]  WITH CHECK ADD  CONSTRAINT [FK_PM_PM_VendorToType] FOREIGN KEY([PMTypeID], [VendorID])
REFERENCES [dbo].[PM_VendorToType] ([PMTypeID], [VendorID])


ALTER TABLE [dbo].[PM] CHECK CONSTRAINT [FK_PM_PM_VendorToType]


ALTER TABLE [dbo].[PM] ADD  CONSTRAINT [DF__PM__LastChanged__4479220A]  DEFAULT (getdate()) FOR [LastChanged]

ALTER TABLE [dbo].[PM] ADD  CONSTRAINT [DF__PM__Creator__456D4643]  DEFAULT (suser_sname()) FOR [Creator]


ALTER TABLE [dbo].[PM] ADD  CONSTRAINT [DF__PM__Created__46616A7C]  DEFAULT (getdate()) FOR [Created]


ALTER TABLE [dbo].[PM] ADD  CONSTRAINT [DF__PM__Updator__47558EB5]  DEFAULT (suser_sname()) FOR [Updator]

ALTER TABLE [dbo].[PM] ADD  CONSTRAINT [DF__PM__Row_ID__4849B2EE]  DEFAULT (newid()) FOR [Row_ID]
End
else
Begin
if  exists (select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='PM' and COLUMN_NAME='Location')
Begin
ALTER TABLE PM DROP COLUMN Location;
End


if  exists (select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='PM' and COLUMN_NAME='DeptartmentID')
Begin
ALTER TABLE PM DROP COLUMN DeptartmentID;
End


IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_TYPE = 'PRIMARY KEY' AND TABLE_NAME = 'PM' AND TABLE_SCHEMA ='dbo' And  CONSTRAINT_NAME = 'PK_PM')                   
BEGIN
	ALTER TABLE [dbo].PM DROP CONSTRAINT PK_PM
	
	ALTER TABLE [dbo].[PM] WITH NOCHECK ADD 
   
    CONSTRAINT [PK_PM] PRIMARY KEY CLUSTERED 
	(
	[SerialNo] ASC,
	[PMTypeID] ASC,
	[VendorID] ASC,
	[Denom] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]

 End   
END
GO

------------------------------------------------------------------------------------------------- not exist
if not exists (select * from dbo.sysobjects where id = object_id(N'[PM_PendingMovement]') and OBJECTPROPERTY(id, N'IsUserTable') = 1) 
Begin
CREATE TABLE [dbo].PM_PendingMovement(
	[ID] [int] NOT NULL,
	[RefNo] [nvarchar](20) NOT NULL,
	[FromCode] [int] NOT NULL,
	[FromID] [int] NOT NULL,
	[ToCode] [int] NOT NULL,
	[ToID] [int] NOT NULL,
	[PMTypeID] [int] NOT NULL,
	[EntityType] [varchar](20) NULL,
	[TransactionName] [dbo].[TransactionName] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]
End
Go
---------------------------------------------PM_PendingMovementDetails---------------------------------------------- not exist
if not exists (select * from dbo.sysobjects where id = object_id(N'[PM_PendingMovementDetails]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
     Begin
     CREATE TABLE [dbo].PM_PendingMovementDetails(
	[ID] [int] NOT NULL,
	[PendingMovementID] [int] NOT NULL,
	[Denomination] [decimal](12, 4) NULL,
	[DenomType] [varchar](30) NOT NULL,
	[Count] [int] NOT NULL,
	[Value] [money] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]



SET ANSI_PADDING ON


ALTER TABLE [dbo].[PM_PendingMovementDetails]  WITH CHECK ADD FOREIGN KEY([PendingMovementID])
REFERENCES [dbo].[PM_PendingMovement] ([ID])


ALTER TABLE [dbo].[PM_PendingMovementDetails]  WITH CHECK ADD  CONSTRAINT [CHK_Value] CHECK  (([Value]=[Denomination]*[Count]))

ALTER TABLE [dbo].[PM_PendingMovementDetails] CHECK CONSTRAINT [CHK_Value]


ALTER TABLE [dbo].[PM_PendingMovementDetails] ADD  CONSTRAINT [DF__PM_PendingMovementDetails__Count]  DEFAULT ((0)) FOR [Count]


ALTER TABLE [dbo].[PM_PendingMovementDetails] ADD  CONSTRAINT [DF__PM_PendingMovementDetails__Value]  DEFAULT ((0)) FOR [Value]
End
Go
-----------------------------------------------PM_EntityDirection----------------------------------------- not exist
if not exists (select * from dbo.sysobjects where id = object_id(N'[PM_EntityDirection]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
Begin
CREATE TABLE [dbo].[PM_EntityDirection](
	[TranID] [int] NOT NULL,
	[Partner1] [nvarchar](20) NOT NULL,
	[Partner2] [nvarchar](20) NOT NULL,
	[EnableSend] [int] NOT NULL,
	[EnableReceive] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[TranID] ASC,
	[Partner1] ASC,
	[Partner2] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]



ALTER TABLE [dbo].[PM_EntityDirection]  WITH CHECK ADD FOREIGN KEY([TranID])
REFERENCES [dbo].[RulesTranName] ([TranID])
End
GO
----------------------------------------------TABLE: PMEntitiesBalance------------------------------------not exist----------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[PM_EntitiesBalance]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
Begin
CREATE TABLE [PM_EntitiesBalance](
	[id] [int] NOT NULL,
	[PMType] [int] NOT NULL,
	[OwnerDescription] [nvarchar](50) NULL,
	[Bank] [int] NOT NULL,
	[Region] [int] NOT NULL,
	[Branch] [int] NOT NULL,
	[CashDrawer] [smallint] NOT NULL,
	[BankBalance] [decimal](21, 6) NULL,
	[CustomerBalance] [decimal](21, 6) NULL,
	[Creator] [dbo].[OperatorID] NOT NULL,
	[Updator] [dbo].[OperatorID] NOT NULL,
	[Created] [datetime] NULL,
	[LastChanged] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]

ALTER TABLE [dbo].[PM_EntitiesBalance]  WITH CHECK ADD FOREIGN KEY([PMType])
REFERENCES [dbo].[PM_Type] ([PMTypeID])


ALTER TABLE [dbo].[PM_EntitiesBalance] ADD  CONSTRAINT [DF__PM_EntitiesBalance__Creator]  DEFAULT (suser_sname()) FOR [Creator]


ALTER TABLE [dbo].[PM_EntitiesBalance] ADD  CONSTRAINT [DF__PM_EntitiesBalance__Updator]  DEFAULT (suser_sname()) FOR [Updator]


ALTER TABLE [dbo].[PM_EntitiesBalance] ADD  CONSTRAINT [DF__PM_EntitiesBalance__Created]  DEFAULT (getdate()) FOR [Created]


ALTER TABLE [dbo].[PM_EntitiesBalance] ADD  CONSTRAINT [DF__PM_EntitiesBalance__LastChanged]  DEFAULT (getdate()) FOR [LastChanged]
End
GO
---------------------------------------------GoldAcctDenomination----------------------------------------------------------not exist---------------------------
     if not exists (select * from dbo.sysobjects where id = object_id(N'[PM_AcctDenomination]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
     Begin
     CREATE TABLE [dbo].PM_AcctDenomination(
              [AccountNumber] [varchar] (20) NOT NULL,
			  [PMTypeID] [int] NOT NULL,
              [PMDenomination] [decimal] (21,6) NOT NULL CONSTRAINT [DF__GoldAcctDenomination__PMDenomination] DEFAULT 1,
              [Quantity] [int] NOT NULL CONSTRAINT [DF__PM_AcctDenomination__Quantity] DEFAULT 0,
       PRIMARY KEY CLUSTERED 
       (
              [AccountNumber] ASC,
              [PMTypeID] ASC,
              [PMDenomination] ASC
       ),
	   FOREIGN KEY(PMTypeID) REFERENCES PM_Type (PMTypeID),
);
End
GO


-----------------------------------------TABLE: BranchConfig------------------------------------------------------------------------------------------

If Not Exists (Select COLUMN_NAME
               From INFORMATION_SCHEMA.COLUMNS
               Where Table_Name = 'BranchConfig'
               And Column_Name = 'DealTreasury')
begin

ALTER TABLE BranchConfig
  ADD DealTreasury bit NOT NULL CONSTRAINT [DF__BranchConfig__DealTreasury] DEFAULT 0;

end
go

----------------------------------------PM_logHistory---------------------------------------not exist----------
If  Not Exists (Select name From sys.tables Where name = 'PM_logHistory')
Begin
CREATE TABLE [dbo].[PM_logHistory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Interface] [nvarchar](50) NOT NULL,
	[Amount] [int] NOT NULL,
	[Created] [datetime] NULL,
	[Creator] [dbo].[OperatorID] NOT NULL,
	[MachineName] [nvarchar](50) NOT NULL,
	[MachineIP] [nvarchar](50) NOT NULL,
	[PMTypeID] [int] NOT NULL,
	[CoreReferenceNumber] [nvarchar](250) NULL,
	[EthixRelatedReference] [nvarchar](250) NULL,
	[TranType] [nvarchar](50) NOT NULL,
	[EntityType] [nvarchar](50) NOT NULL,
	[IsReversed] [int] NOT NULL,
	[ReverseReferenceNumber] [nvarchar](250) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]



ALTER TABLE [dbo].[PM_logHistory] ADD  CONSTRAINT [DF__PM_logHistory__Created]  DEFAULT (getdate()) FOR [Created]


ALTER TABLE [dbo].[PM_logHistory] ADD  CONSTRAINT [DF__PM_logHistory__Creator]  DEFAULT (suser_sname()) FOR [Creator]


ALTER TABLE [dbo].[PM_logHistory] ADD  CONSTRAINT [DF__PM_logHistory__IsReversed]  DEFAULT ((0)) FOR [IsReversed]
End
GO
-------------------------------------------[T_PM_Status]------------------------------not exist-------
IF Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_PM_Status' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_PM_Status] AS TABLE(
	[Status] [int] NULL
)
End
GO
-----------------------------------------------T_TransName--------------------------------------not exist
IF   Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_TransName' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_TransName] AS TABLE(
	[TranName] [varchar](30) NULL
)
End
GO
-----------------------------------------------T_RequiredLocations--------------------------------------not exits
IF  Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_RequiredLocations' AND ss.name = N'dbo')
Begin

CREATE TYPE [dbo].[T_RequiredLocations] AS TABLE(
	[Location] [int] NULL
)
End
GO
-----------------------------------------------[T_PM_SelectRefNo_ToPartnertble]--------------------------------------not exits
IF  Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_PM_SelectRefNo_ToPartnertble' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_PM_SelectRefNo_ToPartnertble] AS TABLE(
	[ToTypeID] [int] NULL,
	[ToID] [varchar](50) NULL,
	[ToCashDrawer] [int] NULL
)
End
GO
-----------------------------------------------T_PM_Plates_Details--------------------------------------exist
IF  Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_PM_Plates_Details' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_PM_Plates_Details] AS TABLE(
	[SerialNo] [varchar](100) NOT NULL,
	[MovementID] [int] NOT NULL
)
End
GO
-----------------------------------------------T_PM_Denomination-------------------------------------- not exits
IF Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_PM_Denomination' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_PM_Denomination] AS TABLE(
	[RowNumber] [int] NULL,
	[Denom] [decimal](12, 4) NULL,
	[DenomType] [varchar](30) NULL,
	[Count] [int] NULL,
	[Value] [decimal](12, 4) NULL
)
End
GO
-----------------------------------------------T_PM_Balance--------------------------------------not exist
IF  Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_PM_Balance' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_PM_Balance] AS TABLE(
	[OwnerDescription] [nvarchar](50) NOT NULL,
	[PMType] [int] NOT NULL,
	[Bank] [int] NOT NULL,
	[Region] [int] NOT NULL,
	[Branch] [int] NOT NULL,
	[CashDrawer] [int] NOT NULL,
	[BankBalance] [decimal](21, 6) NOT NULL,
	[CustomerBalance] [decimal](21, 6) NOT NULL
)
End
GO

-----------------------------------------------T_PM_AcctDenomination--------------------------------------not exits
IF Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_PM_AcctDenomination' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_PM_AcctDenomination] AS TABLE(
	[AccountNumber] [varchar](20) NOT NULL,
	[PMTypeID] [int] NOT NULL,
	[PMDenomination] [decimal](21, 6) NOT NULL,
	[Quantity] [int] NULL
)
End
GO
-----------------------------------------------T_PM--------------------------------------not exist
IF  Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_PM' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_PM] AS TABLE(
	[SerialNo] [varchar](100) NOT NULL,
	[Denom] [decimal](21, 6) NOT NULL
)
End
GO
-----------------------------------------------T_PM_Add_Plates--------------------------------------exist with check
IF  Not EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'T_PM_Add_Plates' AND ss.name = N'dbo')
Begin
CREATE TYPE [dbo].[T_PM_Add_Plates] AS TABLE(
	[SerialNo] [varchar](100) NOT NULL,
	[PMTypeID] [int] NOT NULL,
	[VendorID] [int] NOT NULL,
	[Denom] [int] NOT NULL,
	[Status] [int] NOT NULL,
	[Branch] [dbo].[hierarchy_node#] NULL,
	[User_ID] [dbo].[internal_user_ID] NULL,
	[Operator] [nvarchar](80) NULL,
	[CashDrawer] [int] NULL,
	[CustomerAccount] [dbo].[AccountNumber] NULL,
	[RIM] [dbo].[RIM_Number] NULL
)
End
GO
-----------------------------------------------------------------------------------------------
								----------Alter Tables----------
	-----------------------------------------------------------------------------------------------
	-----------------------------------------------------------------------------------------------

if Not exists (select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='Department' and COLUMN_NAME='IsTreasury')
Begin
ALTER TABLE dbo.Department ADD
	IsTreasury bit NOT NULL CONSTRAINT DF_Department_IsTreasury DEFAULT 0
END
GO

USE [Globalfs]
GO
/*  
 Developer     : Mohamed Elabd
 Creation Date : 26-July-2018
 Purpose       : CBD_ACM16085_Cash Deposit Thresh Hold Charges - CR# GFSY00714
*/  
IF Not Exists (select * from dbo.sysobjects where id = object_id(N'[ThresholdAmounts]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[ThresholdAmounts](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RimClass] [nvarchar](50) NULL,
	[AccountNumber] [nvarchar](50) NULL,
	[MinThresholdAmount] [money] NULL,
	[MinThresholdCharge] [money] NULL,
	[MaxThresholdAmount] [money] NULL,
	[MaxThresholdCharge] [money] NULL,
	[Creator] [dbo].[OperatorID] NOT NULL,
	[Created] [datetime] NOT NULL,
	[Updator] [dbo].[OperatorID] NOT NULL,
	[LastChanged] [datetime] NOT NULL,
	[Row_ID] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
 CONSTRAINT [PK_ThresholdAmounts] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [DynamicData]
) ON [DynamicData]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_AccountNumber]  DEFAULT ('') FOR [AccountNumber]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_MinThresholdAmount]  DEFAULT ((0)) FOR [MinThresholdAmount]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_MinThresholdCharge]  DEFAULT ((0)) FOR [MinThresholdCharge]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_MaxThresholdAmount]  DEFAULT ((0)) FOR [MaxThresholdAmount]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_MaxThresholdCharge]  DEFAULT ((0)) FOR [MaxThresholdCharge]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_Creator]  DEFAULT (suser_sname()) FOR [Creator]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_Created]  DEFAULT (getdate()) FOR [Created]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_Updator]  DEFAULT (suser_sname()) FOR [Updator]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_LastChanged]  DEFAULT (getdate()) FOR [LastChanged]

ALTER TABLE [dbo].[ThresholdAmounts] ADD  CONSTRAINT [DF_ThresholdAmounts_Row_ID]  DEFAULT (newid()) FOR [Row_ID]
END
GO

IF NOT EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'FLD_111')
BEGIN
	ALTER TABLE IR
	ADD FLD_111 NVARCHAR(3) NULL
	 
END
GO
IF NOT EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'FLD_121')
BEGIN
	ALTER TABLE IR
	ADD FLD_121 NVARCHAR(36) NULL
	 
END
GO
 Drop_old_proc IRBulkInsertIntoIR     
  go
  
IF EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
	drop TYPE IRBulkTableType
end
go

IF not EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
CREATE TYPE IRBulkTableType AS TABLE   
(FileRefNo     varchar(11),        
 FilePathName   varchar(255),        
 MsgRefNo    char(13),        
 StatusID    int,        
 ActionId    int,        
 PaymentMethodID  int,        
 DateTimeStamp   smalldatetime,        
 PreparedBy    varchar(60),--OperatorID,        
 MsgValueDate   DATETIME2,        
 ValueDate    DATETIME2,        
 DrAccountNo    varchar(60),        
 DrAccountNo_AcctType varchar(5),      
 DrAccountNo_ApplType varchar(5),      
 DrAccountNo_DepLoan varchar(5),      
 DrAccountName   nvarchar(255),        
 DrCurrency    varchar(4),--CurrencyType,        
 DrAmount    decimal(21,6),        
 DrAddress    nvarchar(255),        
 SenderBank    nvarchar(255),        
 DrExchangeRate   decimal(21,6),        
 DrCommission   decimal(21,6),        
 CrAccountNo    varchar(60),      
 CrAccountNo_AcctType varchar(5),      
 CrAccountNo_ApplType varchar(5),      
 CrAccountNo_DepLoan varchar(5),       
 CrAccountName   nvarchar(255),        
 CrCurrency    varchar(4),--CurrencyType,        
 CrAmount    decimal(21,6),        
 CrAddress    nvarchar(255),        
 OrderingCustomer  varchar(255),        
 CrExchangeRate   decimal(21,6),        
 CrCommission   decimal(21,6),        
 OriginalMsg    varchar(1000),        
 Fld_50K    varchar(255),        
 Fld_59     varchar(255),        
 Charge_Det    char(3),    
 Account_With_Ref varchar(100),    --50
 Account_With_Ac varchar(100),    --50
 Account_With_Name nvarchar(100),    --50
 ValueCurrency varchar(5),    
 Order_Cust_Name nvarchar(100),    --50
 Order_Cust_Add1 varchar(150),    --50
 Order_Cust_Add2 varchar(150),   --50 
 Order_Inst varchar(100),    --50
 Order_Inst_Name varchar(100),    --50
 Order_Inst_Add1 varchar(150),    --50
 BeneficiaryAccount varchar(100),   --60 
 FLD_70 varchar(150),    --50
 FLD_71A varchar(150),    --50
 BeneficiaryName nvarchar(140),  --40  
 BeneficiaryAddress varchar(255) ,    
 Updator    varchar(60),--OperatorID  ,    
 DB_DrValueDate DATETIME2,    
 DB_CrValueDate DATETIME2,    
 DB_DrNarrative varchar(150),    --100
 DB_CrNarrative varchar(150),    --100
 DB_FLD_20 varchar(100),    --50
 DB_FLD_23 varchar(100),    --50
 DB_FLD_33 varchar(100),    --50
 DB_FLD_52 varchar(200),  --150),    --100
 DB_FLD_53 varchar(150),    --100
 MsgType varchar(10),    
 ExceptionList varchar(8000),    
 Is_FLD_20_Duplicate bit,    
 DrRealExchangeRate decimal(21,6),        
 CrRealExchangeRate decimal(21,6),    
 TTAmount decimal(21,6),    
 TTCurrency varchar(4),    
 DrSellExchangeRate decimal(21,6),    
 CrBuyExchangeRate decimal(21,6)  ,  
 IBAN varchar(100),  --60
 Ordering_IBAN  varchar(100), --60   
 Sender_BIC nvarchar(150),--,  --100  
 --CrRimNo varchar(100),  
 --Ben_Inst_BIC varchar(100) 
 FLD_111 nvarchar(3),
 FLD_121 nvarchar(36) 
);  
end
go