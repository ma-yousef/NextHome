﻿--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Insert_ATM_Maintainance
Go

CREATE procedure dbo.Insert_ATM_Maintainance  
 @ATMCode  nvarchar(15),  
 @CombinationDate  smalldatetime,  
 @Custodian1 int , 
 @Custodian2 int  ,  
 @Bank       int  ,
 @Region   int  ,
 @Branch     int , 
 @CurrencyCatname nvarchar(50),
 @ATMGLNumber     nvarchar(60),
 @Updator    DeveloperID ,
 @ATMType char (3),
 @ATMStatus tinyint,
 @ATMType_2  char (20) = ''  
AS  
/*  
CreationDate: 2007-11-14  
OriginalName: dbo.Insert_ATM 
Programmer: Osama Abo el Gheit
Description: insert ATM into ATM table  
Output:    
Assumption:   

ModifiedDate:  19 / 11/ 2007  	
Modifer: Osama Ahmed		
ModifyReason: Add New parameters  ATMGLNumber  

ModifiedDate: 2009-03-16        
Modifer: Mariam moneeb       
ModifyReason: insert Machine Type        

ModifiedDate: 2009-12-28        
Modifer: Mohamed Gad       
ModifyReason: insert ATM/CDM Status  

ModifiedDate: 2022-08-01        
Modifer: shaimaa nasser      
ModifyReason: add ATM_Type2  
*/  
set nocount on  

Declare @CurrencyCategoryID int 
  
if exists ( select *  
  from ATM  
  where Code = @ATMCode)  
  return 10  

select @CurrencyCategoryID = id from CurrencyCategory 
where Name = @CurrencyCatname
if(@ATMType_2 = '0') 
BEGIN 
  set  @ATMType_2 = ''
END
insert into ATM (  
 Code,  
 CombinationDate,  
 Custodian1,  
 Custodian2,  
 Bank,
 Region,
 Branch,
 CurrencyCategoryID,
 ATMGLNumber,
 Updator,
 ATMType,
 RowStatus,
 ATMType_2)  
select @ATMCode,  
 @CombinationDate,  
 @Custodian1,  
 @Custodian2,  
 @Bank,
 @Region,
 @Branch,
 @CurrencyCategoryID,
 @ATMGLNumber ,
 @Updator ,
 @ATMType,
 @ATMStatus	,
 @ATMType_2
  
return @@error  




Go
--End of Automatic Generation

--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc select_ATMIdentifiers
Go

CREATE  procedure [dbo].[select_ATMIdentifiers]
as        
        
/*        
CreationDate: 2004-09-29        
OriginalName: dbo.select_ATMIdentifiers        
Programmer:  Mohammed Monir        
Description: select All codes from ATM table        
Output:          
Assumption:         
        
ModifiedDate: 2007-11-14        
Modifer: Osama Abo El Gheit       
ModifyReason: Add Two Mode for Query And Add New Column CurrencyCategoryID   

ModifiedDate: 2009-03-16        
Modifer: Mariam moneeb       
ModifyReason: Select Machine Type        


ModifiedDate: 2009-03-29        
Modifer: Mohamed Gad      
ModifyReason: Removing "," beween first and last name

ModifiedDate: 2009-12-28        
Modifer: Mohamed Gad      
ModifyReason: Select Machine status


ModifiedDate	: Shaimaa Abd Elnasser
Modifer			: 2022-06-28
ModifyReason	: select ATMType_2 for (Internal/External) ATM Replenishment By Cash Processing Company

ModifiedDate	:
Modifer			:
ModifyReason	:
*/        
        
set nocount on        
select	Bank,
		Region, 
		Branch,
		Code,
		CombinationDate,     
		Custodian1 as user_number1,    
		Custodian2 as user_number2,    
		Custodian1_fullname  = (select (Firstname + ' '+Lastname) as Name from operator where user_number = ATM.Custodian1),    
		Custodian2_fullname   = (select (Firstname + ' '+Lastname) as Name from operator where user_number = ATM.Custodian2),     
		CurrencyGroup = (select Name from CurrencyCategory where id = ATM.CurrencyCategoryID),    
		ATMGLNumber ,   
		ATMType,
		ATMType_2,
		RowStatus

from	ATM       


Go
--End of Automatic Generation
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Update_ATM_Maintenance
Go

Create procedure dbo.Update_ATM_Maintenance
@ATMcode nvarchar(15), 
@combinationdate datetime , 
@custodian1 int , 
@custodian2 int,
@CurrencyCatname nvarchar(50),
@ATMGLNumber nvarchar(60),
@Region int,
@Branch int, 
@Updator DeveloperID ,
@ATMType char (3),
@ATMStatus tinyint,
@ATMType_2  char (20) = ''  

AS 
/*
CreationDate: 2007-11-14
OriginalName: dbo.Update_ATM_Maintenance
Programmer: Osama Abo El Gheit Ahmed
Description: Update ATM 

Output: 
Assumption: 
ModifiedDate: 19 / 11/ 2007 
Modifer: Osama Ahmed 
ModifyReason: Add New parameters ATMGLNumber 


ModifiedDate: 2009-03-16        
Modifer: Mariam moneeb       
ModifyReason: Update Machine Type  to be ATM or CDM

ModifiedDate: 2009-12-28        
Modifer: Mohamed Gad       
ModifyReason: Update Machine Status

ModifiedDate: 2022-08-01        
Modifer: shaimaa nasser      
ModifyReason: add ATM_Type2  
*/

set nocount on
if(@ATMType_2 = '0') 
BEGIN 
  set  @ATMType_2 = ''
END
update ATM

set CombinationDate = @combinationdate ,
Custodian1 = @custodian1,
Custodian2 = @custodian2,
Region = @Region,
Branch = @Branch,
CurrencyCategoryID = (select id from CurrencyCategory where Name = @CurrencyCatname),
ATMGLNumber = @ATMGLNumber,
Updator = @Updator ,
ATMType=@ATMType ,
RowStatus = @ATMStatus,
ATMType_2 = @ATMType_2

where Code = @ATMcode
return @@error





Go
--End of Automatic Generation
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 Proc Script - dbo.AMLInfo_InsertAndUpdate'
GO

drop_old_proc 'AMLInfo_InsertAndUpdate'   
GO
create proc dbo.AMLInfo_InsertAndUpdate
@Mode						int, -- 0 for insert , 1 for update AML Data , 2 for update Rim Data
@ReferenceNumber			ReferenceNumber		= NULL,
@IsPersonal					bit					= NULL,
@ClientName					varchar(80)			= NULL,
@TelephoneNumber			varchar(20)			= NULL,
@PlaceOfBirth				char(5)				= NULL,
@DateOfBirth				datetime			= NULL,
@Nationality				int					= NULL,
@CountryOfIncorporation		char(5)				= NULL,
@Country					char(5)				= NULL,
@PostalCode					varchar(10)			= NULL,
@AddressLine1				varchar(40)			= NULL,
@AddressLine2				varchar(40)			= NULL,
@Governorate				int					= NULL,
@IDType						int					= NULL,
@IDNumber					varchar(25)			= NULL,
@IssueDate					datetime			= NULL,
@ExpirationDate				datetime			= NULL,
@CountryOfIssuance			char(5)				= NULL,
@DateOfUpdate				datetime			= NULL,
@AMLReferenceID				varchar(16)			= NULL,
@RiskRating					varchar(20)			= NULL,
@OpeningStatus				varchar(40)			= NULL,
@RimCreated					bit					= NULL,
@CardReaderLogId			int					= NULL,
@TransactionType			TransactionName		= NULL,
@ResidencyStatus			varchar(20)			= NULL,
@RimClass					int					= NULL,
@RimNumber					varchar(max)		= NULL,
@AccountNumber				varchar(max)		= NULL,
@AccountType				varchar(max)		= NULL,
@Occupation					int					= NULL,
@IsPEP						bit					= NULL,
@NationalityCode			varchar(100)		= NULL,
@EconomicSector				varchar(max)		= NULL,
@BusinessDomain				char(1)				= NULL,
@ProductAndSerivce			varchar(100)		= NULL,
@RequestID					varchar(max)		= NULL,
@Branch						varchar(100)		= NULL,
@UserName					varchar(100)		= NULL,
@RequestDate				DateTime			= NULL,
@Cahnnel					varchar(50)			= NULL,
@OwnerShip					varchar(100)		= NULL,
@CivilIDFormat				varchar(max)		= NULL,
@CivilID					varchar(max)		= NULL,
@RIMStatus					varchar(max)		= NULL,
@EmployeeID					varchar(max)		= NULL,
@EmployeeName				varchar(max)		= NULL,
@RimName                    nvarchar(max)       = NUll,
@RelatedRimNumber           nvarchar(max)       = NUll,
@RelatedRimName             nvarchar(max)       = NUll,
@RelatedRimType             nvarchar(max)       = NUll,
@ParentRequestID            nvarchar(20)        = NUll,
@PassportNumber             varchar(25)         = NUll,
@RelationshipType           varchar(25)                = NUll,
@SharePercentage            decimal(13,8)       = NUll,
@AMLUserID                  nvarchar(max)       = NUll,
@AMLUsername                nvarchar(max)       = NUll,
@DescriptionORReason        nvarchar(max)       = NUll,
@AMLResponsDate             datetime            = NUll
as        
    
/*    
	Devolper	:	Ahmed Osman
	Date		:	[11/05/2020]		
	Reason		:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
	Description	:	Insert and Update table AML_Info

	Devolper	:	Ahmed Osman
	Date		:	[19/05/2021]		
	Reason		:	Enh GFSY00849 - BARWA - ACM19131- KYC Enhancement
	Description	:	Add columns [BranchName,UserName,RequestDate,Cahnnel,OwnerShip,CivilIDFormat,CivilID,RIMStatus,EmployeeID,EmployeeName] to insert and update statment

	--Devolper :	Aya Tarek
    --Date       :	[23/5/2022]		
    --Reason     :	CR#GFSY00908 - ACM000000020088 - AML Integration
	--Description :Add columns [RimName,@RelatedRimNumber,@RelatedRimName,@RelatedRimType,@ParentRequestID,@PassportNumber,@RelationshipType,@SharePercentage,@AMLUserID,@AMLUsername,@DescriptionORReason,@AMLResponsDate]o insert and update statment
--=============================================================
*/     

IF @Mode = 0
	BEGIN
	    SELECT @EmployeeName = user_name  FROM ad_gb_rsm WHERE employee_id = @EmployeeID
		IF NOT EXISTS(SELECT * FROM AML_Info WHERE ReferenceNumber = @ReferenceNumber)
			BEGIN
				Insert Into AML_Info(ReferenceNumber,IsPersonal,ClientName,TelephoneNumber,PlaceOfBirth,DateOfBirth,Nationality,CountryOfIncorporation,Country,PostalCode,AddressLine1,AddressLine2,Governorate,IDType,IDNumber,IssueDate,ExpirationDate,CountryOfIssuance,DateOfUpdate,AMLReferenceID,RiskRating,OpeningStatus,RimCreated,CardReaderLogId,TransactionType,ResidencyStatus,RimClass,RimNumber,AccountNumber,AccountType,Occupation,IsPEP,NationalityCode,EconomicSector,BusinessDomain,ProductAndSerivce,RequestID,Branch,UserName,RequestDate,Cahnnel,OwnerShip,CivilIDFormat,CivilID,RIMStatus,EmployeeID,EmployeeName,RimName,RelatedRimNumber,RelatedRimName,RelatedRimType,ParentRequestID,PassportNumber,RelationshipType,SharePercentage,AMLUserID,AMLUsername,DescriptionORReason,AMLResponsDate)
				Values (@ReferenceNumber,@IsPersonal,@ClientName,@TelephoneNumber,@PlaceOfBirth,@DateOfBirth,@Nationality,@CountryOfIncorporation,@Country,@PostalCode,@AddressLine1,@AddressLine2,@Governorate,@IDType,@IDNumber,@IssueDate,@ExpirationDate,@CountryOfIssuance,@DateOfUpdate,@AMLReferenceID,@RiskRating,@OpeningStatus,@RimCreated,@CardReaderLogId,@TransactionType,@ResidencyStatus,@RimClass,@RimNumber,@AccountNumber,@AccountType,@Occupation,@IsPEP,@NationalityCode,@EconomicSector,@BusinessDomain,@ProductAndSerivce,@RequestID,@Branch,@UserName,@RequestDate,@Cahnnel,@OwnerShip,@CivilIDFormat,@CivilID,@RIMStatus,@EmployeeID,@EmployeeName,@RimName,@RelatedRimNumber,@RelatedRimName,@RelatedRimType,@ParentRequestID,@PassportNumber,@RelationshipType,@SharePercentage,@AMLUserID,@AMLUsername,@DescriptionORReason,@AMLResponsDate)
			END		
	END
ELSE IF @Mode = 1
	BEGIN
		UPDATE AML_Info
			SET 
				AMLReferenceID	= CASE WHEN @AMLReferenceID IS NULL THEN AMLReferenceID ELSE @AMLReferenceID END   
				,RiskRating		= CASE WHEN @RiskRating IS NULL THEN RiskRating ELSE @RiskRating END 
				,OpeningStatus	= CASE WHEN @OpeningStatus IS NULL THEN OpeningStatus ELSE @OpeningStatus END 
				,RimCreated		= CASE WHEN @RimCreated IS NULL THEN RimCreated ELSE @RimCreated END 
				,RimNumber		= CASE WHEN @RimNumber IS NULL THEN RimNumber ELSE @RimNumber END  
				,AccountNumber	= CASE WHEN @AccountNumber IS NULL THEN AccountNumber ELSE @AccountNumber END  
				,AccountType	= CASE WHEN @AccountType IS NULL THEN AccountType ELSE @AccountType END 
			    ,AMLUserID	    = CASE WHEN @AMLUserID IS NULL THEN AMLUserID ELSE @AMLUserID END  
				,AMLUsername	= CASE WHEN @AMLUsername IS NULL THEN AMLUsername ELSE @AMLUsername END 
				,DescriptionORReason = CASE WHEN @DescriptionORReason IS NULL THEN DescriptionORReason ELSE @DescriptionORReason END  
				,AMLResponsDate	= CASE WHEN @AMLResponsDate IS NULL THEN AMLResponsDate ELSE @AMLResponsDate END    
				WHERE RequestID	= @RequestID
	END

IF(@@error<>0)            
     BEGIN            
		RETURN -1          
     END  
ELSE          
     BEGIN              
		RETURN 1     
     END            
GO

PRINT 'End... Script for CR# GFSY00793 Proc Script - dbo.AMLInfo_InsertAndUpdate'
GO
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	[04/08/2022]		
--Reason	:	Enh GFSY00908 
--=====================================================================

PRINT 'Start. Script for CR# GFSY00908 Proc Script - AMLInfo_UpdateInqury'
GO

drop_old_proc 'AMLInfo_UpdateInqury'   
GO
CREATE proc dbo.AMLInfo_UpdateInqury    

@RequestID			ReferenceNumber		= NULL,
@AMLReferenceID				varchar(16)			= NULL,
@OpeningStatus				varchar(40)			= NULL,
@DescriptionORReason        nvarchar(max)       = NUll
as        
    
/*    
	
	--Devolper :	Ibrahim Harby
    --Date       :	[09/08/2022]		
    --Reason     :	CR#GFSY00908 - ACM000000020088 - AML Integration
	
--=============================================================
*/     


UPDATE AML_Info
	SET 
		AMLReferenceID	= CASE WHEN @AMLReferenceID IS NULL THEN AMLReferenceID ELSE @AMLReferenceID END   
		,OpeningStatus	= CASE WHEN @OpeningStatus IS NULL THEN OpeningStatus ELSE @OpeningStatus END 
		,DescriptionORReason = CASE WHEN @DescriptionORReason IS NULL THEN DescriptionORReason ELSE @DescriptionORReason END   
		WHERE RequestID	= @RequestID

IF(@@error<>0)            
     BEGIN            
		RETURN -1          
     END  
ELSE          
     BEGIN              
		RETURN 1     
     END            


PRINT 'End... Script for CR# GFSY00908 Proc Script - GetAMLPreviousRequests'
GO
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	[04/08/2022]		
--Reason	:	Enh GFSY00908 
--=====================================================================

PRINT 'Start. Script for CR# GFSY00908 Proc Script - GetAMLPreviousRequests'
GO

drop_old_proc 'GetAMLPreviousRequests'   
GO
CREATE proc dbo.GetAMLPreviousRequests      
@RIMNo    varchar(100)    = NULL,         
@TransactionType TransactionName = NULL,      
@Status    varchar(100) = NULL      
as              
          
/*          
 Devolper : ibrahim harby   Date  : [03/08/2022]    Reason  : Enh GFSY00908    
 Description : Get AML previous Requests      
*/                
 SELECT  A.RequestID AS 'RequestID',  
        A.OpeningStatus
 FROM AML_Info  A inner join  AML_Info B
  on  A.ParentRequestID = B.RequestID
 WHERE A.RimNumber = @RIMNo   
   AND A.TransactionType = @TransactionType    
   AND (A.OpeningStatus = @Status or @Status is null )

   order by RequestID

PRINT 'End... Script for CR# GFSY00908 Proc Script - GetAMLPreviousRequests'
GO

-- =============================================
--CreationDate: 2008-03-03            
--OriginalName: dbo.select_ATMI_dentifiers            
--Programmer:  Kareem Taha            
--Description: select All ATM codes from ATM table    
-- =============================================

drop_old_proc 'dbo.select_ATM_Identifiers '
GO  
CREATE PROCEDURE dbo.select_ATM_Identifiers   
@bank Bankid ,            
@region Regionid,            
@branch Branchid,    
@ATMType  char (3) = 'ATM'  ,  
@ATMType_2  char (20) = ''    
as      
/*      
CreationDate: 2008-03-03            
OriginalName: dbo.select_ATMI_dentifiers            
Programmer:  Kareem Taha            
Description: select All ATM codes from ATM table            
      
Moodified By:Mostafa Elbarbary        
Date:06/05/2008      
Reason: Improve Sp code performance      
    
ModifiedDate: 2009-03-16            
Modifer: Mariam moneeb           
ModifyReason: Select Machine According to machine Type        
  
ModifiedDate: 2009-05-20  
Modifer: Mariam moneeb           
ModifyReason: Select Machine According to machine Type   
  
ModifiedDate: 2009-12-28  
Modifer: Mohamed Gad           
ModifyReason: Select Active Machine only   
  
ModifiedDate: 2022-07-19  
Modifer: Shaimaa Abdelnasser          
ModifyReason: Filter Atm type with internal & External   
*/      
      
Set NOCOUNT ON  
IF (@ATMType_2 =  '')  
BEGIN   
 SELECT  Code  , CombinationDate  ,Custodian1  ,Custodian2  , ATMGLNumber ,CurrencyCategoryID ,ATMType_2  
 from   dbo.ATM           
 where  Bank  = @bank            
 and   Region  = @region            
 and  Branch  = @branch      
 and  ATMType=@ATMType     
 and RowStatus = 1  
END  
ELSE  
BEGIN   
 SELECT  Code  , CombinationDate  ,Custodian1  ,Custodian2  , ATMGLNumber ,CurrencyCategoryID ,ATMType_2  
 from   dbo.ATM           
 where  Bank  = @bank            
 and   Region  = @region            
 and  Branch  = @branch      
 and  ATMType=@ATMType     
 and     ATMType_2 = @ATMType_2  
 and RowStatus = 1  
  
END   

GO
USE [Globalfs]
GO
/****** Object:  StoredProcedure [dbo].[SELECT_FORM_AML_Info]    Script Date: 08/14/2022 1:09:08 PM ******/
PRINT 'Start. Script for CR# GFSY00908 Proc Script - dbo.SELECT_FORM_AML_Info'
GO
drop_old_proc 'SELECT_FORM_AML_Info'   
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE proc [dbo].[SELECT_FORM_AML_Info]      

@CaseNo varchar(16) = null,

@RequestID varchar(16) = null,    

@OwnerRimNumber varchar(max) = null, 

@CustomerName   varchar(80) = null,          
   
@IDNumber   varchar(25) = null,    
      
@PassportNumber varchar(25) =null,

@TransactionType varchar(40)=null,
@LCID LanguageLCID = NULL
AS               
           
SET NOCOUNT ON                   


SELECT AMLReferenceID as 'AMLCaseID', OpeningStatus as 'ALMStatus' ,RimNumber as 'RimNo' , RimName as 'Name' , 
	 CASE WHEN RulesDescriptorLocal.LocalDescription IS NULL THEN RulesDescriptor.Descriptor  ELSE RulesDescriptorLocal.LocalDescription  END AS 'TransactionType' ,ReferenceNumber as 'RequestID'

FROM AML_Info LEFT OUTER JOIN RulesTranName
ON AML_Info.TransactionType = RulesTranName.TransactionName
LEFT JOIN RulesDescriptor
        ON RulesTranName.DSC_Description = RulesDescriptor.DescriptorID
    LEFT OUTER JOIN RulesDescriptorLocal     
        ON RulesDescriptor.DescriptorID = RulesDescriptorLocal.DescriptorID AND RulesDescriptorLocal.LCID = @LCID


  where (@CaseNo = '' or AMLReferenceID = @CaseNo)     

    and (@CustomerName  = '' or ClientName like '%'+@CustomerName+'%' )      

    and (@IDNumber  = '' or IDNumber = @IDNumber)   
   
    and (@TransactionType='' or TransactionType=@TransactionType)     
  
    and (@OwnerRimNumber = '' or RimNumber =@OwnerRimNumber)  

    and (@RequestID = '' or ReferenceNumber = @RequestID)

    and (@PassportNumber = '' or PassportNumber =@PassportNumber)
  
ORDER  BY  ReferenceNumber     

PRINT 'End... Script for CR# GFSY00908 Proc Script - GetAMLPreviousRequests'
GO
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	[04/08/2022]		
--Reason	:	Enh GFSY00908 
--=====================================================================

PRINT 'Start. Script for CR# GFSY00908 Proc Script - GetAMLPreviousRequests'
GO

drop_old_proc 'GetAMLPreviousRequests'   
GO
CREATE proc dbo.GetAMLPreviousRequests      
@RIMNo    varchar(100)    = NULL,         
@TransactionType TransactionName = NULL,      
@Status    varchar(100) = NULL      
as              
          
/*          
 Devolper : ibrahim harby   Date  : [03/08/2022]    Reason  : Enh GFSY00908    
 Description : Get AML previous Requests      
*/                
 SELECT  A.RequestID AS 'RequestID',  
        A.OpeningStatus
 FROM AML_Info  A 
 --inner join  AML_Info B
 -- on  A.ParentRequestID = B.RequestID
 WHERE A.RimNumber = @RIMNo   
   AND A.TransactionType = @TransactionType    
   AND (A.OpeningStatus = @Status or @Status is null )

   order by RequestID

PRINT 'End... Script for CR# GFSY00908 Proc Script - GetAMLPreviousRequests'
GO
USE [Globalfs]
GO
/****** Object:  StoredProcedure [dbo].[SELECT_FORM_AML_Info]    Script Date: 08/14/2022 1:09:08 PM ******/
PRINT 'Start. Script for CR# GFSY00908 Proc Script - dbo.SELECT_FORM_AML_Info'
GO
drop_old_proc 'SELECT_FORM_AML_Info'   
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE proc [dbo].[SELECT_FORM_AML_Info]      

@CaseNo varchar(16) = null,

@RequestID varchar(16) = null,    

@OwnerRimNumber varchar(max) = null, 

@CustomerName   varchar(80) = null,          
   
@IDNumber   varchar(25) = null,    
      
@PassportNumber varchar(25) =null,

@TransactionType varchar(40)=null,
@LCID LanguageLCID = NULL
AS               
           
SET NOCOUNT ON                   


SELECT AMLReferenceID as 'AMLCaseID', OpeningStatus as 'ALMStatus' ,RimNumber as 'RimNo' , RimName as 'Name' , 
	 CASE WHEN RulesDescriptorLocal.LocalDescription IS NULL THEN RulesDescriptor.Descriptor  ELSE RulesDescriptorLocal.LocalDescription  END AS 'TransactionType' ,RequestID as 'RequestID'

FROM AML_Info LEFT OUTER JOIN RulesTranName
ON AML_Info.TransactionType = RulesTranName.TransactionName
LEFT JOIN RulesDescriptor
        ON RulesTranName.DSC_Description = RulesDescriptor.DescriptorID
    LEFT OUTER JOIN RulesDescriptorLocal     
        ON RulesDescriptor.DescriptorID = RulesDescriptorLocal.DescriptorID AND RulesDescriptorLocal.LCID = @LCID


  where (@CaseNo = '' or AMLReferenceID = @CaseNo)     

    and (@CustomerName  = '' or RimName like '%'+@CustomerName+'%' )      

    and (@IDNumber  = '' or IDNumber = @IDNumber)   
   
    and (@TransactionType='' or TransactionType=@TransactionType)     
  
    and (@OwnerRimNumber = '' or RimNumber =@OwnerRimNumber)  

    and (@RequestID = '' or RequestID = @RequestID)

    and (@PassportNumber = '' or PassportNumber =@PassportNumber)
  
ORDER  BY  ReferenceNumber     

PRINT 'End... Script for CR# GFSY00908 Proc Script - GetAMLPreviousRequests'
GO
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	[04/08/2022]		
--Reason	:	Enh GFSY00908 
--=====================================================================

PRINT 'Start. Script for CR# GFSY00908 Proc Script - GetAMLPreviousRequests'
GO

drop_old_proc 'GetAMLPreviousRequests'   
GO
CREATE proc dbo.GetAMLPreviousRequests      
@RIMNo    varchar(100)    = NULL,         
@TransactionType TransactionName = NULL  
as              
          
/*          
 Devolper : ibrahim harby   Date  : [03/08/2022]    Reason  : Enh GFSY00908    
 Description : Get AML previous Requests      
*/                
 SELECT  RequestID AS 'RequestID',  
        OpeningStatus AS 'Status',
		ParentRequestID AS 'ParentRequestID'
 FROM AML_Info   
 WHERE RimNumber = @RIMNo   
   AND TransactionType = @TransactionType    
order by RequestID
PRINT 'End... Script for CR# GFSY00908 Proc Script - GetAMLPreviousRequests'
GO
--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	{14/08/2022}	
--Reason	:	Enh GFSY00917 - ACM000000020167 - RIM Override Audit
--====================================================================

PRINT 'Start. Script for CR# GFSY00917 Proc Script - dbo.GetControlSetupFrom_EX'
GO
 
drop_old_proc 'GetControlSetupFrom_EX'
GO
Create  Proc [dbo].[GetControlSetupFrom_EX]     
@TransactionName		nvarchar(100)		,
@LCID					LanguageLCID = NULL	
as                
/*
--Devolper	:	Ibrahim Harby
--Date		:	{14/08/2022}	
--Reason	:	Enh GFSY00917 - ACM000000020167 - RIM Override Audit
*/   



 SELECT RulesTranField_ex.*   , 
	 CASE WHEN RulesDescriptorLocal.LocalDescription IS NULL THEN RulesDescriptor.Descriptor  ELSE RulesDescriptorLocal.LocalDescription  END AS 'ControlLabelName' 

FROM RulesTranField_ex inner join RulesTranName
ON RulesTranField_ex.TranID = RulesTranName.TranID
LEFT outer JOIN RulesDescriptor
        ON  RulesTranField_ex.TranFieldDescr collate SQL_Latin1_General_CP1_CS_AS = RulesDescriptor.Name 
		LEFT OUTER JOIN RulesDescriptorLocal     
        ON RulesDescriptor.DescriptorID = RulesDescriptorLocal.DescriptorID 
		AND RulesDescriptorLocal.LCID = @LCID
    
WHERE RulesTranName.TransactionName= @TransactionName



GO
PRINT 'End... Script for CR# GFSY00917 Proc Script - dbo.GetControlSetupFrom_EX'
GO


--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	{14/08/2022}	
--Reason	:	Enh GFSY00917 - ACM000000020167 - RIM Override Audit
--====================================================================

PRINT 'Start. Script for CR# GFSY00917 Proc Script - dbo.GetRimAudit'
GO
 
drop_old_proc 'GetRimAudit'
GO
Create  Proc [dbo].[GetRimAudit]     
@ReferenceNumber		uniqueidentifier	,
@Bank					int				,
@Region					int			,
@Branch					int			,
@JNLSequance		    int					,
@TransactionName		nvarchar(100)				
as                
/*
--Devolper	:	Ibrahim Harby
--Date		:	{14/08/2022}	
--Reason	:	Enh GFSY00917 - ACM000000020167 - RIM Override Audit
*/   



SELECT [ID]
	  ,[ReferenceNumber]
      ,[TID]
      ,[UserNumber]
      ,[Bank]
      ,[Region]
      ,[Branch]
      ,[JNLSequance]
      ,[BusinessDate]
      ,[TransactionName]
      ,[ChangedControlsData]
      ,[MachineName]
  FROM [dbo].[RimAuditTrails]

  where bank = @Bank
  and Region = @Region
  and Branch = @Branch
  and TransactionName = @TransactionName
  and ReferenceNumber = @ReferenceNumber
  and JNLSequance = @JNLSequance

GO
PRINT 'End... Script for CR# GFSY00917 Proc Script - dbo.GetRimAudit'
GO
--==================================================================================================================================================================

--==================================================================================================================================================================
--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	{14/08/2022}	
--Reason	:	Enh GFSY00917 - ACM000000020167 - RIM Override Audit
--====================================================================

PRINT 'Start. Script for CR# GFSY00917 Proc Script - dbo.InsertRimAuditTrails'
GO
 
drop_old_proc 'InsertRimAuditTrails'
GO
Create  Proc [dbo].[InsertRimAuditTrails]     
@ReferenceNumber		uniqueidentifier	,
@TID					nvarchar(100)    ,
@UserNumber				internal_user_ID	,
@Bank					int				,
@Region					int			,
@Branch					int			,
@JNLSequance		    int					,
@BusinessDate			SmallDate			,
@TransactionName		nvarchar(100)		,
@Controls_Data			XML                 ,
@MachineName			nvarchar(100)		
as                
/*
--Devolper	:	Ibrahim Harby
--Date		:	{14/08/2022}	
--Reason	:	Enh GFSY00917 - ACM000000020167 - RIM Override Audit
*/   


BEGIN TRY
    BEGIN TRANSACTION

INSERT INTO [dbo].[RimAuditTrails]
           ([ReferenceNumber]
		   ,[TID]
           ,[UserNumber]
           ,[Bank]
           ,[Region]
           ,[Branch]
           ,[JNLSequance]
           ,[BusinessDate]
           ,[TransactionName]
           ,[ChangedControlsData]
           ,[MachineName])
     VALUES
           (@ReferenceNumber ,
		    @TID ,
            @UserNumber	,
			@Bank  ,
			@Region	,
			@Branch	,
			@JNLSequance ,
			@BusinessDate	,
			@TransactionName ,
			@Controls_Data  ,
			@MachineName)

			SELECT '1' AS 'Result' , '' AS 'ErrorMessage'
	COMMIT TRAN
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
		SELECT '0' AS 'Result', ERROR_MESSAGE() AS 'ErrorMessage'
        ROLLBACK TRAN 
END CATCH
GO

PRINT 'End... Script for CR# GFSY00917 Proc Script - dbo.InsertRimAuditTrails'
GO
--Devolper :	Aya Tarek
--Date       :	[7/8/2022]		
--Reason     :	CR#GFSY00918 - ACM000000020364 - Swift ISO20022-XML Format
--=============================================================

PRINT 'Start. Script for CR# GFSY00918 Proc Script - dbo.Get_MXMessageTagList'
GO 
drop_old_proc 'Get_MXMessageTagList'
GO
create proc dbo.Get_MXMessageTagList		-- Get_MXMessageTagList 
@MsgType	varchar(10)
as        
    
/*    
    Devolper :	Aya Tarek
    Date       :	[7/8/2022]			
	Reason		:	Enh GFSY00918 - ACM000000020364 - Swift ISO20022-XML Format
	Description	:	Select all MX Message Tags List  from setup table XMLToIRTableMapping 

*/          
BEGIN  
	select FieldColumninIRtable As 'TagCode',
		   FieldPathInXML As 'TagXMLPath',
		   IsMandatory As 'TagStatus',
		   IsAttribute As 'TagType'  from XMLToIRTableMapping where MsgType=@MsgType
END  


GO

PRINT 'End... Script for CR# GFSY00918 Proc Script - dbo.Get_MXMessageTagList'
GO  
Drop_old_proc IRBulkInsertIntoIR     
  go

CREATE PROCEDURE dbo.IRBulkInsertIntoIR 
    @Table IRBulkTableType READONLY    
    AS    
/*      
CreationDate: 2017-5-31     
OriginalName: dbo.IRBulkInsertIntoIR      
Programmer  : Karim Mahmoud
Description : Bulk Insert rows in IR Table 

Reason: GFSY00717 - Add 2 column FLD_111,FLD_121
Developer: Nada Elshafie
Modification date: 14Aug2018

Reason: GFSY00807 - Save Credit Rim Number
Developer: Ahmed Osman
Modification date: 01/08/2020 Enh - BARWA - ACM18595 Inward Transfers

Reason: GFSY00918 - Save ISMX,FLD_72, Ben_Inst_Name,Ben_Inst_AddLn1,Ben_Inst_AddLn2,Ben_Inst_AddLn3
Developer: Aya Tarek
Modification date: 9/9/2022 Enh -CR#GFSY00918 - ACM000000020364 - Swift ISO20022-XML Format
*/   
BEGIN TRY  
    BEGIN TRANSACTION   
       INSERT INTO IR
        (        
			 FileRefNo,        
			 FilePathName,       
			 MsgRefNo,        
			 StatusID,        
			 ActionId,        
			 PaymentMethodID,        
			 DateTimeStamp,        
			 PreparedBy,        
			 MsgValueDate,        
			 ValueDate,        
			 DrAccountNo,        
			 DrAccountNo_AcctType,      
			 DrAccountNo_ApplType,      
			 DrAccountNo_DepLoan,      
			 DrAccountName,        
			 DrCurrency,        
			 DrAmount,        
			 DrAddress,        
			 SenderBank,        
			 DrExchangeRate,        
			 DrCommission,        
			 CrAccountNo,        
			 CrAccountNo_AcctType,     
			 CrAccountNo_ApplType,      
			 CrAccountNo_DepLoan,      
			 CrAccountName,        
			 CrCurrency,        
			 CrAmount,        
			 CrAddress,        
			 OrderingCustomer,        
			 CrExchangeRate,        
			 CrCommission,        
			 OriginalMsg,        
			 Fld_50K,        
			 Fld_59,        
			 Charge_Det,       
			 Account_With_Ref,    
			 Account_With_Ac,    
			 Account_With_Name,    
			 ValueCurrency,    
			 Order_Cust_Name,    
			 Order_Cust_Add1,    
			 Order_Cust_Add2,    
			 Order_Inst,    
			 Order_Inst_Name,    
			 Order_Inst_Add1,    
			 BeneficiaryAccount,    
			 FLD_70,    
			 FLD_71A,    
			 BeneficiaryName,    
			 BeneficiaryAddress,    
			 Updator,    
			 DrValueDate,    
			 CrValueDate,    
			 DrNarrative,    
			 CrNarrative,    
			 FLD_20,    
			 FLD_23,    
			 FLD_33,    
			 FLD_52,    
			 FLD_53,    
			 MsgType,    
			 ExceptionList,    
			 Is_FLD_20_Duplicate,    
			 DrRealExchangeRate,    
			 CrRealExchangeRate,     
			 TTAmount ,    
			 TTCurrency ,    
			 DrSellExchangeRate,    
			 CrBuyExchangeRate ,  
			 IBAN   ,    
			 Ordering_IBAN,    
			 Sender_BIC,    
			 CrRimNo,  
			 --Ben_Inst_BIC,
			 FLD_111,
			 FLD_121,
			 IsMX,
			 FLD_72,
			 Ben_Inst_BIC,
			 Ben_Inst_Name,
			 Ben_Inst_AddLn1,
			 Ben_Inst_AddLn2,
			 Ben_Inst_AddLn3 
		)       
		SELECT 
		
			 irbt.FileRefNo,        
			 irbt.FilePathName,        
			 irbt.MsgRefNo,        
			 irbt.StatusID,        
			 irbt.ActionId,        
			 irbt.PaymentMethodID,        
			 irbt.DateTimeStamp,        
			 irbt.PreparedBy,        
			 irbt.MsgValueDate,        
			 irbt.ValueDate,        
			 irbt.DrAccountNo,        
			 irbt.DrAccountNo_AcctType,      
			 irbt.DrAccountNo_ApplType,      
			 irbt.DrAccountNo_DepLoan,      
			 irbt.DrAccountName,        
			 irbt.DrCurrency,       
			 irbt.DrAmount,        
			 irbt.DrAddress,        
			 irbt.SenderBank,        
			 irbt.DrExchangeRate,        
			 irbt.DrCommission,        
			 irbt.CrAccountNo,      
			 irbt.CrAccountNo_AcctType,      
			 irbt.CrAccountNo_ApplType,      
			 irbt.CrAccountNo_DepLoan,       
			 irbt.CrAccountName,        
			 irbt.CrCurrency,     
			 irbt.CrAmount,        
			 irbt.CrAddress,        
			 irbt.OrderingCustomer,        
			 irbt.CrExchangeRate,        
			 irbt.CrCommission,        
			 irbt.OriginalMsg,        
			 irbt.Fld_50K,        
			 irbt.Fld_59,        
			 irbt.Charge_Det,    
			 irbt.Account_With_Ref,    
			 irbt.Account_With_Ac,    
			 irbt.Account_With_Name,    
			 irbt.ValueCurrency,    
			 irbt.Order_Cust_Name,    
			 irbt.Order_Cust_Add1,    
			 irbt.Order_Cust_Add2,    
			 irbt.Order_Inst,    
			 irbt.Order_Inst_Name,    
			 irbt.Order_Inst_Add1,    
			 irbt.BeneficiaryAccount,    
			 irbt.FLD_70,     
			 irbt.FLD_71A,    
			 irbt.BeneficiaryName,    
			 irbt.BeneficiaryAddress,    
			 irbt.Updator,  
			 irbt.DB_DrValueDate,   
			 irbt.DB_CrValueDate,    
			 irbt.DB_DrNarrative,    
			 irbt.DB_CrNarrative,    
			 irbt.DB_FLD_20,    
			 irbt.DB_FLD_23,    
			 irbt.DB_FLD_33,    
			 irbt.DB_FLD_52,    
			 irbt.DB_FLD_53,    
			 irbt.MsgType,    
			 irbt.ExceptionList,    
			 irbt.Is_FLD_20_Duplicate,    
			 irbt.DrRealExchangeRate,        
			 irbt.CrRealExchangeRate,    
			 irbt.TTAmount,    
			 irbt.TTCurrency,    
			 irbt.DrSellExchangeRate,    
			 irbt.CrBuyExchangeRate,  
			 irbt.IBAN,  
			 irbt.Ordering_IBAN,    
			 irbt.Sender_BIC,   
			 irbt.CrRimNo, --'',--CrRimNo varchar(100),  
			-- '',--Ben_Inst_BIC varchar(100)
			 irbt.FLD_111,
			 irbt.FLD_121,
			 irbt.IsMX,
			 irbt.FLD_72,
			 irbt.Ben_Inst_BIC,
			 irbt.Ben_Inst_Name,
			 irbt.Ben_Inst_AddLn1,
			 irbt.Ben_Inst_AddLn2,
			 irbt.Ben_Inst_AddLn3
		
		FROM @Table irbt
    COMMIT  
END TRY  
BEGIN CATCH  
  
    IF @@TRANCOUNT > 0  
        ROLLBACK  
    return -1;
END CATCH  
  
GO

--Devolper	 :	Shaimaa Nasser
--Date       :	[10/08/2022]		
--Reason     :  ACM000000019738 - MT202 and MT199
------------------------------------------------------------------------------------------------
PRINT 'Start. Script for CR# GFSY00919 Proc Script'
GO
 

Go
drop_old_proc 'dbo.GET_MT199_Templates'
Go
CREATE PROC dbo.GET_MT199_Templates   
 @type  nvarchar(3) = null
As  
			/*   
			CreationDate: 10/08/2022 
			OriginalName: dbo.GET_MT199_Templates   
			Programmer: Shaimaa Nasser      
			Description: GET all Templates for MT199 Message 
			*/  
 
	  SELECT * FROM Field79Templates  
GO
PRINT 'End. Script for CR# GFSY00919 Proc Script'
go
USE [Globalfs]
GO
/****** Object:  StoredProcedure [dbo].[GetCashDrawerAvailableBalance]    Script Date: 29-08-2022 1:09:08 PM ******/
PRINT 'Start. Script for CR# GFSY00921 Proc Script - dbo.GetCashDrawerAvailableBalance'
GO
drop_old_proc 'GetCashDrawerAvailableBalance'   
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  PROCEDURE GetCashDrawerAvailableBalance  --exec GetCashDrawerAvailableBalance 'ITSOFT\ahmed.amohamed'
@TellerID    nvarchar(40),
@Currency  varchar(3) = NULL

AS           
           
SET NOCOUNT ON    
/*     
 Created: 29-08-2022         
 Developer: Ahmed Atef  
 Description: CR# GFSY00921 - ECC Denomination - GetCashDrawerAvailableBalance     
*/  

DECLARE @ErrorDescription nvarchar(max)
DECLARE @UserNumber nvarchar(max)
DECLARE @CashDrawerNumber nvarchar(max)
DECLARE @CashDrawerBalance decimal

IF NOT EXISTS(SELECT * FROM Operator WHERE LoginID = @TellerID)
	BEGIN
		SET @ErrorDescription = 'Sent TellerId is not valid GFS operator.'
		SELECT	'' AS 'UserNumber' , '' AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription'
		SELECT	'' AS 'DrawerAmount' , '' AS 'CurrencyType'
		RETURN;
	END

SELECT @UserNumber = user_number FROM Operator WHERE LoginID = @TellerID
SELECT @CashDrawerNumber = CashDrawerNumber FROM CashDrawers WHERE AssignedToTeller = @UserNumber AND IsActive = 1
SELECT @CashDrawerBalance = SUM(InDrawerAmount) FROM CashDrawerDetails  WHERE CashDrawerNumber = @CashDrawerNumber AND CurrencyType = @Currency
    
IF NOT EXISTS(SELECT * FROM CashDrawers WHERE AssignedToTeller = @UserNumber AND IsActive = 1)
	BEGIN
		SET @ErrorDescription = 'There is not an active cash drawer attached on this TellerId.'
		SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription'
		SELECT	'' AS 'DrawerAmount' , '' AS 'CurrencyType'
		RETURN;
	END

IF NOT EXISTS(SELECT * FROM CashDrawers WHERE AssignedToTeller = @UserNumber AND IsActive = 1 AND CanSeeAvailableAmount = 1)
	BEGIN
		SET @ErrorDescription = 'Cannot see the available balance for this teller id cash drawer.'
		SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription'
		SELECT	'' AS 'DrawerAmount' , '' AS 'CurrencyType'
		RETURN;
	END

IF NOT EXISTS(SELECT * FROM CashDrawerDetails  WHERE CashDrawerNumber = @CashDrawerNumber)
	BEGIN
		SET @ErrorDescription = 'There are no denomination defined on this teller id cash drawer.'
		SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription'
		SELECT	'' AS 'DrawerAmount' , '' AS 'CurrencyType'
		RETURN;
	END

BEGIN
	IF(@Currency IS NOT NULL)
		IF EXISTS(SELECT CurrencyType FROM CashDrawerDetails 
			WHERE CashDrawerNumber IN  (SELECT CashDrawerNumber 
								FROM CashDrawers WHERE AssignedToTeller IN 
								(SELECT user_number FROM Operator WHERE LoginID = @TellerID) 
								AND IsActive = 1) AND (CurrencyType = @Currency)) 
		BEGIN
			--CASE currency type is found in cash drawer details like 'EGP' on active cash drawer
			SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription'

			SELECT SUM(InDrawerAmount) AS DrawerAmount, CurrencyType FROM CashDrawerDetails 
			WHERE CashDrawerNumber IN  (SELECT CashDrawerNumber 
										FROM CashDrawers WHERE AssignedToTeller IN 
										(SELECT user_number FROM Operator WHERE LoginID = @TellerID) 
										AND IsActive = 1)
			AND (CurrencyType = @Currency)
			GROUP BY CurrencyType
			RETURN;
		END
		ELSE
		BEGIN
			--CASE currency type not attached in cash drawer details on active cash drawer 
			SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription'

			SELECT SUM(InDrawerAmount) AS DrawerAmount, CurrencyType FROM CashDrawerDetails 
			WHERE CashDrawerNumber IN  (SELECT CashDrawerNumber 
										FROM CashDrawers WHERE AssignedToTeller IN 
										(SELECT user_number FROM Operator WHERE LoginID = @TellerID) 
										AND IsActive = 1)
			AND (CurrencyType IS NOT NULL AND CurrencyType <> '')
			GROUP BY CurrencyType
			RETURN;
		END
	ELSE
		BEGIN
			--CASE currency type has not value in input param
			SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription'

			SELECT SUM(InDrawerAmount) AS DrawerAmount, CurrencyType FROM CashDrawerDetails 
			WHERE CashDrawerNumber IN  (SELECT CashDrawerNumber 
										FROM CashDrawers WHERE AssignedToTeller IN 
										(SELECT user_number FROM Operator WHERE LoginID = @TellerID) 
										AND IsActive = 1)
			AND (CurrencyType IS NOT NULL AND CurrencyType <> '')
			GROUP BY CurrencyType
			RETURN;
		END
END       
  
    
PRINT 'End... Script for CR# GFSY00921 Proc Script - GetCashDrawerAvailableBalance'
go


USE [Globalfs]
GO
/****** Object:  StoredProcedure [dbo].[GetSuggestedDenomination]    Script Date: 05-09-2022 1:09:08 PM ******/
PRINT 'Start. Script for CR# GFSY00921 Proc Script - dbo.GetSuggestedDenomination'
GO
drop_old_proc 'GetSuggestedDenomination'   
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  PROCEDURE GetSuggestedDenomination  --exec GetSuggestedDenomination 'ITSOFT\ahmed.amohamed','EGP'
@TellerID    nvarchar(40),
@Currency  varchar(3),
@ChequeAmount decimal = NULL

AS           
           
SET NOCOUNT ON    
/*     
 Created: 05-09-2022         
 Developer: Ahmed Atef  
 Description: CR# GFSY00921 - ECC Denomination - GetSuggestedDenomination     
*/


DECLARE @ErrorDescription nvarchar(max)
DECLARE @UserNumber nvarchar(max)
DECLARE @CashDrawerNumber nvarchar(max)
DECLARE @CashDrawerBalance decimal
DECLARE @BankID int
DECLARE @BrID int
DECLARE @OwnerID int
DECLARE @type nvarchar(10)

Select @BrID = BrID FROM Operator WHERE LoginID = @TellerID

IF EXISTS(Select * from OrganizationHierarchy where id = @BrID)
	BEGIN
		Select @type = type from OrganizationHierarchy where id = @BrID
		Select @OwnerID = owner from OrganizationHierarchy where id = @BrID
	
		WHILE (@type <> 'bk')
			BEGIN
				Set @BrID = @OwnerID
				Select @OwnerID = owner from OrganizationHierarchy where id = @BrID
				Select @type = type from OrganizationHierarchy where id = @BrID
			END;
		Select @BankID = id from OrganizationHierarchy where id = @BrID
	END

IF NOT EXISTS(SELECT * FROM Operator WHERE LoginID = @TellerID)
	BEGIN
		SET @ErrorDescription = 'Sent TellerId is not valid GFS operator.'
		SELECT	'' AS 'UserNumber' , '' AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription' , 'False' AS 'SuggestedDenomination'
		SELECT	'' AS 'DenominationValue' , '' AS 'DenominationType' , '' AS 'DenominationCount'
		RETURN;
	END

SELECT @UserNumber = user_number FROM Operator WHERE LoginID = @TellerID
SELECT @CashDrawerNumber = CashDrawerNumber FROM CashDrawers WHERE AssignedToTeller = @UserNumber AND IsActive = 1
SELECT @CashDrawerBalance = SUM(InDrawerAmount) FROM CashDrawerDetails  WHERE CashDrawerNumber = @CashDrawerNumber AND CurrencyType = @Currency

IF NOT EXISTS(SELECT * FROM CashDrawers WHERE AssignedToTeller = @UserNumber AND IsActive = 1)
	BEGIN
		SET @ErrorDescription = 'There is not an active cash drawer attached on this TellerId.'
		SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription', 'False' AS 'SuggestedDenomination'
		SELECT	'' AS 'DenominationValue' , '' AS 'DenominationType' , '' AS 'DenominationCount'
		RETURN;
	END

IF NOT EXISTS(SELECT * FROM CashDrawers WHERE AssignedToTeller = @UserNumber AND IsActive = 1 AND CanSeeAvailableAmount = 1)
	BEGIN
		SET @ErrorDescription = 'Cannot see the available balance for this teller id cash drawer.'
		SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription', 'False' AS 'SuggestedDenomination'
		SELECT	'' AS 'DenominationValue' , '' AS 'DenominationType' , '' AS 'DenominationCount'
		RETURN;
	END

IF NOT EXISTS(SELECT * FROM CashDrawerDetails  WHERE CashDrawerNumber = @CashDrawerNumber)
	BEGIN
		SET @ErrorDescription = 'There are no denomination defined on this teller id cash drawer.'
		SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription', 'False' AS 'SuggestedDenomination'
		SELECT	'' AS 'DenominationValue' , '' AS 'DenominationType' , '' AS 'DenominationCount'
		RETURN;
	END

IF NOT EXISTS(SELECT * FROM CashDrawerDetails  WHERE CashDrawerNumber = @CashDrawerNumber AND CurrencyType = @Currency)
	BEGIN
		SET @ErrorDescription = 'This currency not attached on this teller id cash drawer.'
		SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription', 'False' AS 'SuggestedDenomination'
		SELECT	'' AS 'DenominationValue' , '' AS 'DenominationType' , '' AS 'DenominationCount'
		RETURN;
	END

IF(@ChequeAmount IS NOT NULL AND @ChequeAmount <> 0)
	BEGIN
		IF(@CashDrawerBalance < @ChequeAmount)
			BEGIN
				SET @ErrorDescription = 'The cheque amount is bigger than total cash drawer balance.'
				SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription', 'False' AS 'SuggestedDenomination'
				SELECT	'' AS 'DenominationValue' , '' AS 'DenominationType' , '' AS 'DenominationCount'
				RETURN;
			END
		ELSE
			BEGIN
			IF EXISTS(SELECT * FROM CashDrawerDetails  WHERE CashDrawerNumber = @CashDrawerNumber AND CurrencyType = @Currency 
						  AND Denomination <= @ChequeAmount AND InDrawerAmount > 0)--check denomination covered cheque amount
				BEGIN
					IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'AutoPopulateDenomination' AND Value = '1' AND Bank = @BankID)
						BEGIN
							SET @ErrorDescription = 'System will Not retrieve the suggested denomination.'
							SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription', 'False' AS 'SuggestedDenomination'
							
							-- retrieve all available denomination count from 'CashDrawerDetails'						
							SELECT CD.Denomination AS 'DenominationValue', CD.CashDrawerType AS 'DenominationType', (CDD.InDrawerAmount / CDD.Denomination) AS 'DenominationCount'
							FROM CashDrawerDetails CDD  INNER JOIN CashDenomination CD
							ON CDD.CurrencyType = CD.CurrencyType 
							AND CDD.Denomination = CD.Denomination
							AND CDD.CashDrawerType = CD.CashDrawerType
							WHERE CDD.CashDrawerNumber =  @CashDrawerNumber AND CDD.CurrencyType = @Currency
							RETURN;
						END
					ELSE
						BEGIN -- retrieve all available denomination count & Suggested Denomination flag is true
							SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription', 'True' AS 'SuggestedDenomination'

							SELECT CD.Denomination AS 'DenominationValue', CD.CashDrawerType AS 'DenominationType', (CDD.InDrawerAmount / CDD.Denomination) AS 'DenominationCount'
							FROM CashDrawerDetails CDD  INNER JOIN CashDenomination CD
							ON CDD.CurrencyType = CD.CurrencyType 
							AND CDD.Denomination = CD.Denomination
							AND CDD.CashDrawerType = CD.CashDrawerType
							WHERE CDD.CashDrawerNumber =  @CashDrawerNumber AND CDD.CurrencyType = @Currency
						END
				END
			ELSE --denomination not covered cheque amount
				BEGIN
					--retrieve all available denomination count from 'CashDrawerDetails'
					SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription' , 'False' AS 'SuggestedDenomination'

					SELECT CD.Denomination AS 'DenominationValue', CD.CashDrawerType AS 'DenominationType', (CDD.InDrawerAmount / CDD.Denomination) AS 'DenominationCount'
					FROM CashDrawerDetails CDD  INNER JOIN CashDenomination CD
					ON CDD.CurrencyType = CD.CurrencyType 
					AND CDD.Denomination = CD.Denomination
					AND CDD.CashDrawerType = CD.CashDrawerType
					WHERE CDD.CashDrawerNumber =  @CashDrawerNumber AND CDD.CurrencyType = @Currency
					RETURN;
				END
			END
	END
ELSE
	BEGIN
		--retrieve all available denomination count from 'CashDrawerDetails'
		SELECT	@UserNumber AS 'UserNumber' , @CashDrawerNumber AS 'CashdrawerNumber' , @ErrorDescription AS 'ErrorDescription', 'False' AS 'SuggestedDenomination'

		SELECT CD.Denomination AS 'DenominationValue', CD.CashDrawerType AS 'DenominationType', (CDD.InDrawerAmount / CDD.Denomination) AS 'DenominationCount'
		FROM CashDrawerDetails CDD  INNER JOIN CashDenomination CD
		ON CDD.CurrencyType = CD.CurrencyType 
		AND CDD.Denomination = CD.Denomination
		AND CDD.CashDrawerType = CD.CashDrawerType
		WHERE CDD.CashDrawerNumber =  @CashDrawerNumber AND CDD.CurrencyType = @Currency
		RETURN;
	END

GO

PRINT 'End... Procedure Created.. CR# GFSY00921 Proc Script - GetSuggestedDenomination'

go

drop_old_proc 'Get_Journal_Summary'
  go
  CREATE PROC [dbo].[Get_Journal_Summary]  
 @start_date smalldate,       
 @end_date smalldate,        
 @criteria nvarchar(3000) = '',         
 @order_time_ascending bit = 0,        
 @max_rows int = 9,  -- Zero means return only one row.        
 @page_back bit = 0,        
 @LCID int = NULL, -- May be used to get local tran Description.        
 @for_user internal_user_ID =0,        
 @debug int = 0        
AS        

      
SET NOCOUNT ON        
declare @sql nvarchar(4000), @param_defs nvarchar(1000)        
declare @summary_sql nvarchar(4000), @position int, @operator_columns nvarchar(500)        
declare @position_of_from int        
declare @date_string varchar(30), @date_string2 varchar(30)        
declare @normal_descending_order nvarchar(300)        
 , @normal_ascending_order nvarchar(300)        
 , @inside_order nvarchar(300)        
 , @outer_order nvarchar(300)        
declare @tran_def_columns nvarchar(200)        
declare @start_year_month smallint, @end_year_month smallint, @start_day tinyint, @end_day tinyint        
declare @table_name sysname, @suffix char(7)        
declare @where nvarchar(1000)      
declare @AcctEntries_table sysname    
declare @AcctEntries_sql nvarchar(4000)      
-- ** CR14330 ** S        
declare @no_lock_hint nvarchar(14)   
declare @audit_sql    nvarchar(4000)
if @max_rows < 22        
 set @no_lock_hint = N' WITH (NOLOCK)' -- Read uncommitted when not for a print report.        
else        
 set @no_lock_hint = ''        
-- ** CR14330 ** E        
set @start_year_month = dbo.YYMM_of_SmallDate(@Start_Date)        
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)        
set @start_day = DatePart(dd, dbo.datetime_of_smalldate(@start_date))        
set @end_day = DatePart(dd, dbo.datetime_of_smalldate(@end_date))        
if @start_year_month = @end_year_month BEGIN        
 set @suffix = dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@start_date))        
 set @table_name = 'ZJournal'+ @suffix       
  set @AcctEntries_table = 'ZJNL_AccingEnt'+ @suffix      
 -- Adel Shaban - Fixing issue when table doesn't exist in database      
 if(Not Exists( Select 1 from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @table_name))      
 BEGIN      
 select * FROM Journal WHERE 1 = 2 -- return dataset with correct schema and no rows      
 RETURN -1 -- exist from proc       
 END      
 -- End of Adel Shaban - Fixing issue when table doesn't exist in database      
 set @where = N'WHERE J.year_month = @start_ym' + char(10)         
 + ' AND J.BusinessDate_Day '        
 + case when @start_day = @end_day         
  then '= @start_day AND J.BusinessDate = @start_date'        
  else 'between @start_day and @end_day         
  and J.BusinessDate between @start_date and @end_date'        
  end        
END         
ELSE BEGIN        
 set @table_name = 'Journal'       
 set @AcctEntries_table = 'JNL_AccingEnt'      
 set @where = N'WHERE J.year_month between @start_ym and @end_ym        
 and J.BusinessDate between @start_date and @end_date'        
END        
        
if @for_user >0 and dbo.operator_has_wildcard_permissions(@for_user)<1        
 set @where =@where+' AND dbo.is_BranchAllowed(@for_user,J.Bank,J.Region,J.Branch)=1 '        
        
IF isNULL(@LCID,0) = 0         
--**CR16728 ** S        
 set @tran_def_columns = N'        
 , Tran_Title = T.Description collate SQL_Latin1_General_CP1_CI_AS, T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable  ,  ChangedControlsData '        
else        
 --**CR16728 ** E        
 set @tran_def_columns = N'        
 , Tran_Title = isNULL(isnull(RD.LocalDescription, D.Descriptor), T.Description collate SQL_Latin1_General_CP1_CI_AS), T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable , ChangedControlsData'          
        
select @summary_sql =         
 substring(dbo.f_insert_new_lines(AccessString,72),7,3990)         
from dbo.SQLstrings         
where AccessName = 'JOURNAL_SUMMARY'        
      
select @AcctEntries_sql =    
 char(10)+N',(select  x.Subscript, x.JNL_Acct_ENT_ACCOUNT,    
x.JNL_Acct_ENT_DB_CURR,    
x.JNL_Acct_ENT_DB_AMOUNT,    
x.JNL_Acct_ENT_CR_CURR,    
x.JNL_Acct_ENT_CR_AMOUNT    
' + char(10)        
+ 'FROM dbo.'+@AcctEntries_table+N' x'    +' where J.BusinessDate = x.BusinessDate    
and J.user_Number= x.user_Number    
and J.Bank = x.Bank     
and J.Region = x.Region     
and J.Branch = x.Branch     
and J.JNLSequence = x.JNLSequence     
for xml path(''AccountEntries'')    
) as AccountEntries    
'        
set @position = charindex(', dbo.opID_of_U#', @summary_sql, 100)        
if @position = 0 begin        
  raiserror('Get_Journal_Summary can not find ", dbo.opID_of_U#" in JOURNAL_SUMMARY SQLstrings.AccessString', 16, 1)        
  return -1        
end        
set @position_of_from = charindex(' FROM ', @summary_sql, @position) - (@position + 2)        
set @operator_columns = substring(@summary_sql, @position+2, @position_of_from)        
set @operator_columns = replace(@operator_columns, '(user_number', '(JS.user_number')        
set @position = @position -1        
if @debug > 0 or @@servername like '%DBMASTER%'begin        
 declare @min_date smalldate        
 if db_name() like '%archive'        
  set @min_date = dbo.smalldate_of(dbo.f_Teller_Base_date())        
 else        
  set @min_date = dbo.f_min_journal_business_date(dbo.smalldate_of(getdate()))        
         
 if @start_date < @min_date begin        
  if @min_date < dbo.smalldate_of(getdate()) begin        
   set @date_string = isNULL(cast (@start_date as varchar), '-NULL-')        
   set @date_string2 = convert(varchar(10), @min_date)        
   raiserror('Get_Journal_Summary @start_date,"%s" must be > "%s"'        
    , 16, 1, @date_string, @date_string2)        
   return -1        
  end        
 end        
 if @start_date > @end_date or @end_date is null begin        
  set @date_string = isNULL(cast(@end_date as varchar), '-NULL-')        
  set @date_string2 = cast(@start_date as varchar)         
        
  raiserror('Get_Journal_Summary @end_date, "%s" must be >= @startdate = "%s"'        
   , 16, 1, @date_string, @date_string2)        
  return -1        
 end        
end        
set @criteria = dbo.TRIM(@criteria)  -- TRIM off left and right spaces.        
if @criteria <> '' and substring(@criteria,1,8) not like '%where %' begin        
 if left(@criteria, 4) = 'AND '         
  set @criteria = @where + ' ' + @criteria        
 else begin        
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)        
  return -1        
 end        
end        
         
if @criteria = ''        
 set @criteria = @where        
else begin        
 if @criteria like '%[^a-z_0-9.]Bank %'         
  set @criteria = replace (@criteria, 'bank ', 'J.Bank ')        
        
 if @criteria like '%[^a-z_0-9.]user_number %'       set @criteria = replace (@criteria, 'user_number ', 'J.user_number')        
        
 if @criteria like '%[^a-z_0-9.]Region %'         
  set @criteria = replace (@criteria, 'region ', 'J.Region ')        
        
 if @criteria like '%[^a-z_0-9.]Branch %'         
  set @criteria = replace (@criteria, 'branch ', 'J.Branch ')        
        
 if substring(@criteria,1,8) not like '%where %' begin        
  if left(@criteria, 4) = 'AND '         
   set @criteria = @where + ' ' + @criteria        
  else begin        
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)        
   return -1        
  end        
 end else         
  set @criteria = @where +REPLACE(@criteria,'where', ' AND')        
end         
if @max_rows < 0 begin        
 raiserror('Get_Journal_Summary @max_rows "%d", must be at least 0', 16, 1, @max_rows)        
 return -1        
end        
        
set @normal_descending_order = N'        
 order by Bank,Region,Branch,user_number,TransactionTime desc, JNLSequence desc'        
set @normal_ascending_order = N'        
 order by Bank,Region,Branch,user_number,TransactionTime,JNLSequence'        
set @inside_order = case         
when @order_time_ascending = 0 and @page_back = 0 then @normal_descending_order        
when @order_time_ascending = 0 and @page_back = 1 then N'        
 order by Bank desc,Region desc,Branch desc, user_number desc,TransactionTime, JNLSequence'        
when @order_time_ascending = 1 and @page_back = 0 then @normal_ascending_order        
else N'        
 order by Bank desc,Region desc,Branch desc,user_number desc,TransactionTime desc, JNLSequence desc'        
end        
        
set @audit_sql = ' left join RimAuditTrails r
on JS.Bank = r.Bank and JS.Branch = r.Branch and JS.Region = r.Region and JS.JNLSequence = r.JNLSequance and JS.TID = r.TID '
select @sql = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)         
+ substring(@summary_sql,1, @position)    
+ @AcctEntries_sql          
+ char(10)        
-- ** CR14330 ** S        
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint   
  
-- ** CR14330 ** E        
+ char(10) + @criteria + @inside_order        
        
if @page_back = 1 begin        
 set @outer_order = case @order_time_ascending        
          when 0 then @normal_descending_order        
   else @normal_ascending_order        
   end        
        
 set @sql = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql+N') BOTTOM' + @outer_order        
end        
IF isNULL(@LCID,0) = 0         
 set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns         
+ N'        
FROM (' + @sql + ') AS JS  '      
+ ' '+ @audit_sql   
+ ' JOIN dbo.RulesTranName T        
 on T.TransactionName = JS.TranName'        
         
ELSE         
 set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns         
+ N'        
FROM (' + @sql + ') AS JS        
JOIN dbo.RulesTranName T        
  on T.TransactionName = JS.TranName        
LEFT OUTER JOIN dbo.RulesDescriptor D        
  on D.DescriptorID = T.DSC_Description        
LEFT OUTER JOIN dbo.RulesDescriptorLocal RD        
  on RD.DescriptorID = D.DescriptorID and LCID = @LCID'        
-- ** CR15838 ** S        
+ char(10) + @inside_order        
-- ** CR15838 ** E     
       
set @param_defs = N'@LCID int, @start_date smalldate, @end_date smalldate, @start_ym smallint, @end_ym smallint, @start_day tinyint, @end_day tinyint, @for_user internal_user_ID'        
if @debug > 0 begin        
 print '-------cut here ---------'         
 print 'declare ' + @param_defs + char(10)         
 print 'select @LCID = ' + isnull(cast(@LCID as varchar), 'NULL')        
 print '    , @start_date = '''+cast(@start_date as varchar) + ''''        
 print '    , @end_date = '''+cast(@end_date as varchar) + ''''        
 print '    , @start_ym = '+cast(@start_year_month as varchar)        
 print '    , @end_ym = '+cast(@end_year_month as varchar)        
 print '    , @start_day = '+cast(@start_day as varchar)        
 print '    , @end_day = '+cast(@end_day as varchar)        
 print ' ,@for_user='+cast(@for_user as varchar)        
 /*print '    , @user_number = ' + case @user_number when NULL then ' NULL ' else cast(@user_number as varchar) end*/        
 print @sql         
 if @debug > 3 return -1        
end        
 print @sql 
exec dbo.sp_executesql @sql, @param_defs, @LCID, @start_date, @end_date        
 , @start_year_month, @end_year_month, @start_day, @end_day, @for_user 
go
drop_old_proc 'Get_Journal_Summary_Audit'
  go
  CREATE  PROC [dbo].[Get_Journal_Summary_Audit]           
 @start_date smalldate,       
 @end_date smalldate,        
 @criteria nvarchar(3000) = '',         
 @order_time_ascending bit = 0,        
 @max_rows int = 9,  -- Zero means return only one row.        
 @page_back bit = 0,        
 @LCID int = NULL, -- May be used to get local tran Description.        
 @for_user internal_user_ID =0,        
 @debug int = 0        
AS        

      
SET NOCOUNT ON        
declare @sql nvarchar(4000), @param_defs nvarchar(1000)        
declare @summary_sql nvarchar(4000), @position int, @operator_columns nvarchar(500)        
declare @position_of_from int        
declare @date_string varchar(30), @date_string2 varchar(30)        
declare @normal_descending_order nvarchar(300)        
 , @normal_ascending_order nvarchar(300)        
 , @inside_order nvarchar(300)        
 , @outer_order nvarchar(300)        
declare @tran_def_columns nvarchar(200)        
declare @start_year_month smallint, @end_year_month smallint, @start_day tinyint, @end_day tinyint        
declare @table_name sysname, @suffix char(7)        
declare @where nvarchar(1000)      
declare @AcctEntries_table sysname    
declare @AcctEntries_sql nvarchar(4000)      
-- ** CR14330 ** S        
declare @no_lock_hint nvarchar(14)   
declare @audit_sql    nvarchar(4000)
if @max_rows < 22        
 set @no_lock_hint = N' WITH (NOLOCK)' -- Read uncommitted when not for a print report.        
else        
 set @no_lock_hint = ''        
-- ** CR14330 ** E        
set @start_year_month = dbo.YYMM_of_SmallDate(@Start_Date)        
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)        
set @start_day = DatePart(dd, dbo.datetime_of_smalldate(@start_date))        
set @end_day = DatePart(dd, dbo.datetime_of_smalldate(@end_date))        
if @start_year_month = @end_year_month BEGIN        
 set @suffix = dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@start_date))        
 set @table_name = 'ZJournal'+ @suffix       
  set @AcctEntries_table = 'ZJNL_AccingEnt'+ @suffix      
 -- Adel Shaban - Fixing issue when table doesn't exist in database      
 if(Not Exists( Select 1 from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @table_name))      
 BEGIN      
 select * FROM Journal WHERE 1 = 2 -- return dataset with correct schema and no rows      
 RETURN -1 -- exist from proc       
 END      
 -- End of Adel Shaban - Fixing issue when table doesn't exist in database      
 set @where = N'WHERE J.year_month = @start_ym' + char(10)         
 + ' AND J.BusinessDate_Day '        
 + case when @start_day = @end_day         
  then '= @start_day AND J.BusinessDate = @start_date'        
  else 'between @start_day and @end_day         
  and J.BusinessDate between @start_date and @end_date'        
  end        
END         
ELSE BEGIN        
 set @table_name = 'Journal'       
 set @AcctEntries_table = 'JNL_AccingEnt'      
 set @where = N'WHERE J.year_month between @start_ym and @end_ym        
 and J.BusinessDate between @start_date and @end_date'        
END        
        
if @for_user >0 and dbo.operator_has_wildcard_permissions(@for_user)<1        
 set @where =@where+' AND dbo.is_BranchAllowed(@for_user,J.Bank,J.Region,J.Branch)=1 '        
        
IF isNULL(@LCID,0) = 0         
--**CR16728 ** S        
 set @tran_def_columns = N'        
 , Tran_Title = T.Description collate SQL_Latin1_General_CP1_CI_AS, T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable ,  ChangedControlsData'        
else        
 --**CR16728 ** E        
 set @tran_def_columns = N'        
 , Tran_Title = isNULL(isnull(RD.LocalDescription, D.Descriptor), T.Description collate SQL_Latin1_General_CP1_CI_AS), T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable ,  ChangedControlsData'          
        
select @summary_sql =         
 substring(dbo.f_insert_new_lines(AccessString,72),7,3990)         
from dbo.SQLstrings         
where AccessName = 'JOURNAL_SUMMARY'        
      
select @AcctEntries_sql =    
 char(10)+N',(select  x.Subscript, x.JNL_Acct_ENT_ACCOUNT,    
x.JNL_Acct_ENT_DB_CURR,    
x.JNL_Acct_ENT_DB_AMOUNT,    
x.JNL_Acct_ENT_CR_CURR,    
x.JNL_Acct_ENT_CR_AMOUNT    
' + char(10)        
+ 'FROM dbo.'+@AcctEntries_table+N' x'    +' where J.BusinessDate = x.BusinessDate    
and J.user_Number= x.user_Number    
and J.Bank = x.Bank     
and J.Region = x.Region     
and J.Branch = x.Branch     
and J.JNLSequence = x.JNLSequence     
for xml path(''AccountEntries'')    
) as AccountEntries    
'        
set @position = charindex(', dbo.opID_of_U#', @summary_sql, 100)        
if @position = 0 begin        
  raiserror('Get_Journal_Summary can not find ", dbo.opID_of_U#" in JOURNAL_SUMMARY SQLstrings.AccessString', 16, 1)        
  return -1        
end        
set @position_of_from = charindex(' FROM ', @summary_sql, @position) - (@position + 2)        
set @operator_columns = substring(@summary_sql, @position+2, @position_of_from)        
set @operator_columns = replace(@operator_columns, '(user_number', '(JS.user_number')        
set @position = @position -1        
if @debug > 0 or @@servername like '%DBMASTER%'begin        
 declare @min_date smalldate        
 if db_name() like '%archive'        
  set @min_date = dbo.smalldate_of(dbo.f_Teller_Base_date())        
 else        
  set @min_date = dbo.f_min_journal_business_date(dbo.smalldate_of(getdate()))        
         
 if @start_date < @min_date begin        
  if @min_date < dbo.smalldate_of(getdate()) begin        
   set @date_string = isNULL(cast (@start_date as varchar), '-NULL-')        
   set @date_string2 = convert(varchar(10), @min_date)        
   raiserror('Get_Journal_Summary @start_date,"%s" must be > "%s"'        
    , 16, 1, @date_string, @date_string2)        
   return -1        
  end        
 end        
 if @start_date > @end_date or @end_date is null begin        
  set @date_string = isNULL(cast(@end_date as varchar), '-NULL-')        
  set @date_string2 = cast(@start_date as varchar)         
        
  raiserror('Get_Journal_Summary @end_date, "%s" must be >= @startdate = "%s"'        
   , 16, 1, @date_string, @date_string2)        
  return -1        
 end        
end        
set @criteria = dbo.TRIM(@criteria)  -- TRIM off left and right spaces.        
if @criteria <> '' and substring(@criteria,1,8) not like '%where %' begin        
 if left(@criteria, 4) = 'AND '         
  set @criteria = @where + ' ' + @criteria        
 else begin        
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)        
  return -1        
 end        
end        
         
if @criteria = ''        
 set @criteria = @where        
else begin        
 if @criteria like '%[^a-z_0-9.]Bank %'         
  set @criteria = replace (@criteria, 'bank ', 'J.Bank ')        
        
 if @criteria like '%[^a-z_0-9.]user_number %'       set @criteria = replace (@criteria, 'user_number ', 'J.user_number')        
        
 if @criteria like '%[^a-z_0-9.]Region %'         
  set @criteria = replace (@criteria, 'region ', 'J.Region ')        
        
 if @criteria like '%[^a-z_0-9.]Branch %'         
  set @criteria = replace (@criteria, 'branch ', 'J.Branch ')        
        
 if substring(@criteria,1,8) not like '%where %' begin        
  if left(@criteria, 4) = 'AND '         
   set @criteria = @where + ' ' + @criteria        
  else begin        
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)        
   return -1        
  end        
 end else         
  set @criteria = @where +REPLACE(@criteria,'where', ' AND')        
end         
if @max_rows < 0 begin        
 raiserror('Get_Journal_Summary @max_rows "%d", must be at least 0', 16, 1, @max_rows)        
 return -1        
end        
        
set @normal_descending_order = N'        
 order by Bank,Region,Branch,user_number,TransactionTime desc, JNLSequence desc'        
set @normal_ascending_order = N'        
 order by Bank,Region,Branch,user_number,TransactionTime,JNLSequence'        
set @inside_order = case         
when @order_time_ascending = 0 and @page_back = 0 then @normal_descending_order        
when @order_time_ascending = 0 and @page_back = 1 then N'        
 order by Bank desc,Region desc,Branch desc, user_number desc,TransactionTime, JNLSequence'        
when @order_time_ascending = 1 and @page_back = 0 then @normal_ascending_order        
else N'        
 order by Bank desc,Region desc,Branch desc,user_number desc,TransactionTime desc, JNLSequence desc'        
end        
        
set @audit_sql = ' inner join RimAuditTrails r
on JS.Bank = r.Bank and JS.Branch = r.Branch and JS.Region = r.Region and JS.JNLSequence = r.JNLSequance and JS.TID = r.TID '
select @sql = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)         
+ substring(@summary_sql,1, @position)    
+ @AcctEntries_sql          
+ char(10)        
-- ** CR14330 ** S        
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint       
-- ** CR14330 ** E        
+ char(10) + @criteria + @inside_order        
        
if @page_back = 1 begin        
 set @outer_order = case @order_time_ascending        
          when 0 then @normal_descending_order        
   else @normal_ascending_order        
   end        
        
 set @sql = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql+N') BOTTOM' + @outer_order        
end        
IF isNULL(@LCID,0) = 0         
 set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns         
+ N'        
FROM (' + @sql + ') AS JS   '
 + ' '+ @audit_sql   +    
'JOIN dbo.RulesTranName T        
 on T.TransactionName = JS.TranName'        
         
ELSE         
 set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns         
+ N'        
FROM (' + @sql + ') AS JS '        
+ ' '+ @audit_sql   +
' JOIN dbo.RulesTranName T        
  on T.TransactionName = JS.TranName        
LEFT OUTER JOIN dbo.RulesDescriptor D        
  on D.DescriptorID = T.DSC_Description        
LEFT OUTER JOIN dbo.RulesDescriptorLocal RD        
  on RD.DescriptorID = D.DescriptorID and LCID = @LCID'        
-- ** CR15838 ** S        
+ char(10) + @inside_order        
-- ** CR15838 ** E     
       
set @param_defs = N'@LCID int, @start_date smalldate, @end_date smalldate, @start_ym smallint, @end_ym smallint, @start_day tinyint, @end_day tinyint, @for_user internal_user_ID'        
if @debug > 0 begin        
 print '-------cut here ---------'         
 print 'declare ' + @param_defs + char(10)         
 print 'select @LCID = ' + isnull(cast(@LCID as varchar), 'NULL')        
 print '    , @start_date = '''+cast(@start_date as varchar) + ''''        
 print '    , @end_date = '''+cast(@end_date as varchar) + ''''        
 print '    , @start_ym = '+cast(@start_year_month as varchar)        
 print '    , @end_ym = '+cast(@end_year_month as varchar)        
 print '    , @start_day = '+cast(@start_day as varchar)        
 print '    , @end_day = '+cast(@end_day as varchar)        
 print ' ,@for_user='+cast(@for_user as varchar)        
 /*print '    , @user_number = ' + case @user_number when NULL then ' NULL ' else cast(@user_number as varchar) end*/        
 print @sql         
 if @debug > 3 return -1        
end        
 print @sql 
exec dbo.sp_executesql @sql, @param_defs, @LCID, @start_date, @end_date        
 , @start_year_month, @end_year_month, @start_day, @end_day, @for_user 
go
Drop_Old_Proc '[Get_Journal_Summary_For_Printing]' 
GO  
Create PROC [dbo].[Get_Journal_Summary_For_Printing]      
 @criteria nvarchar(max) = '',    
 @criteria2 nvarchar(max) = '',    
 @start_date smalldate,         
 @end_date smalldate,       
 @order_time_ascending bit = 0,          
 @max_rows int = 9,  -- Zero means return only one row.          
 @page_back bit = 0,          
 @LCID int = NULL, -- May be used to get local tran Description.          
 @for_user internal_user_ID =0,          
 @debug int = 0        
AS          
-- Query the Teller journal summary view for records that match the criteria.          
-- For just the @max_rows that match the criteria, join in the description          
--  of the transaction as "Tran_Title".          
          
-- When @page_back is ON, you get the last n rows that match the criteria.          
          
-- This uses the select projection list developed by proc SetJnlSummaryColumns2.          
-- Copyright 2003, 2004, 2005, 2006, 2007, 2008 Getronics USA, INC. All rights reserved.          
-- Created 05Feb03 by Bodhi Densmore          
-- 07FEB03 Bodhi added start_date and end_date parameters to ensure quick retrieval.          
-- 02APR03 Bodhi - To improve performance, don'T use RulesDecriptorLOCAL table when it is not useful.          
-- 02JUL03 Bodhi - Join in isDupable and isCorrectable from RulesTranName, per request from Mike Chandler.          
-- 11JUL03 Bodhi - Normal order is ascending by operator and descending by time and jnlSequence.          
-- 10Mar04 Bodhi - Support having only user_number and not LoginID (Operator) in Journal.          
--                 Using a late-binding join to the Operator table for best performance.          
-- 22Apr04 Bodhi - Fix syntax bug in retrieving local descriptors for transaction name.          
-- 21May04 Bodhi - Support conversion of user_numbers to login IDS.          
-- 06JUL04 Bodhi - Join in isSuperDupable from RulesTranName, per CR9728.          
-- 31JAN04 Bodhi - Support additional fields like "Supervisor" as interual_user_ID. CR10172          
-- 27Jul05 Kevens - Support additional column names like bank, region and branch that are not exactly those names.          
-- 17Aug05 Bodhi - Support queries with only date criteria, - initial value of @criteria empty.          
-- 23SEP05 Bodhi - For better performance, calculate table name when only one month is used.          
--                 Replace f_OperatorID_of_user_number with opID_of_U#          
-- 31AUG06 Bodhi - Use nolock hint when number of @max_rows is small, indicating not-for-report.           
-- 15JAN07 Diana - Add extra condition to the 'where' clause for checking privileges in OperatorRoles. CR14966          
-- 22Apr07 Bodhi - Use "inside order" for ORDER BY after the final join.          
-- 22Apr07 B & D - Support SmallDate as integer.          
-- 22May07 Bodhi - Complain about start_date too early on DBMaster or if debugging.          
-- 16MAR08 DEEPAK D R - Collation cast added CR16728          
-- 08APR10 Bodhi - Forgive dates less than minimum when minimum is today (because Journal is empty).          
        
/*        
Modified by: Adel Shaban        
Date: 9/2/2011        
Reason: Fixing issue when table doesn't exist in database - issue#103687        
      
Modified by: Amira Kamel      
Date: 28/12/2013       
Reason: Selact Accounting Entries, host ref no , cheque no      
      
Modified by: Ibrahim Harby      
Date: 20/01/2021       
Reason: add @Sql2 , @where2 , @criteria2 for union sql2 with sql one       
 to get old behaviour data with new PostingFromSupervisor data       
*/        
        
SET NOCOUNT ON          
declare @sql nvarchar(max), @sql2 nvarchar(max), @param_defs nvarchar(1000)          
declare @summary_sql nvarchar(4000), @position int, @operator_columns nvarchar(500)          
declare @position_of_from int          
declare @date_string varchar(30), @date_string2 varchar(30)          
declare @normal_descending_order nvarchar(300)          
 , @normal_ascending_order nvarchar(300)          
 , @inside_order nvarchar(300)          
 , @outer_order nvarchar(300)          
declare @tran_def_columns nvarchar(200)          
declare @start_year_month smallint, @end_year_month smallint, @start_day tinyint, @end_day tinyint          
declare @table_name sysname, @suffix char(7)          
declare @where nvarchar(1000) , @where2 nvarchar(max)      
declare @AcctEntries_table sysname      
declare @AcctEntries_sql nvarchar(4000)        
declare @audit_sql    nvarchar(4000) -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}  
-- Begin Ibrahim Harby  (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value      
declare @LikeParamFirstPart nvarchar(100)      
set @LikeParamFirstPart =   '''%n="PostingFromSupervisor_RequesterUserNumber" v="'      
declare @LikeParamLastPart nvarchar(100)      
set @LikeParamLastPart =  '"%'''      
-- End Ibrahim Harby (17-12-2020)       
-- ** CR14330 ** S          
declare @no_lock_hint nvarchar(14)          
if @max_rows < 22          
 set @no_lock_hint = N' WITH (NOLOCK)' -- Read uncommitted when not for a print report.          
else          
 set @no_lock_hint = ''          
-- ** CR14330 ** E          
set @start_year_month = dbo.YYMM_of_SmallDate(@Start_Date)          
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)          
set @start_day = DatePart(dd, dbo.datetime_of_smalldate(@start_date))          
set @end_day = DatePart(dd, dbo.datetime_of_smalldate(@end_date))          
if @start_year_month = @end_year_month BEGIN          
 set @suffix = dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@start_date))          
 set @table_name = 'ZJournal'+ @suffix         
  set @AcctEntries_table = 'ZJNL_AccingEnt'+ @suffix        
 -- Adel Shaban - Fixing issue when table doesn't exist in database        
 if(Not Exists( Select 1 from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @table_name))        
 BEGIN        
 select * FROM Journal WHERE 1 = 2 -- return dataset with correct schema and no rows        
 RETURN -1 -- exist from proc         
 END        
 -- End of Adel Shaban - Fixing issue when table doesn't exist in database      
     
Declare @Expression varchar(max) = null    
Declare @individual varchar(max) = null    
Declare @usernumber varchar(max) = NULL    
    
SET @Expression = @criteria    
SET @Expression = REPLACE(@Expression, 'and', ',')    
SET @Expression = REPLACE(@Expression, ' ', '')    
    
WHILE LEN(@Expression) > 0    
BEGIN    
    IF PATINDEX('%,%', @Expression) > 0    
  BEGIN    
      SET @individual = SUBSTRING(@Expression, 0, PATINDEX('%,%', @Expression))    
    
      IF @individual LIKE 'user_number=%'    
    BEGIN      SET @usernumber = @individual    
    END    
    
      SET @Expression = SUBSTRING(@Expression, LEN(@individual + ',') + 1, LEN(@Expression))    
  END    
    ELSE    
  BEGIN    
   SET @individual = @Expression    
   SET @Expression = NULL    
       IF @individual LIKE 'user_number=%'    
    BEGIN      SET @usernumber = @individual    
    END    
  END    
END    
SET @usernumber = REPLACE(@usernumber, 'user_number=', '')    
    
 --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value      
  -- @where2 for union criteria       
 set @where2 = N'WHERE  J.TLR_DUMMY_FIELDS like '+ @LikeParamFirstPart +cast (@usernumber as nvarchar(10))  +@LikeParamLastPart      
   +' AND J.year_month = @start_ym' + char(10)         
 + ' AND J.BusinessDate_Day '          
 + case when @start_day = @end_day           
  then '= @start_day AND J.BusinessDate = @start_date'          
  else 'between @start_day and @end_day           
  and J.BusinessDate between @start_date and @end_date'          
  end          
      
   set @where = N'WHERE   J.year_month = @start_ym' + char(10)         
 + ' AND J.BusinessDate_Day '          
 + case when @start_day = @end_day           
  then '= @start_day AND J.BusinessDate = @start_date'          
  else 'between @start_day and @end_day        
  and J.BusinessDate between @start_date and @end_date'          
  end          
     -- End Ibrahim Harby (17-12-2020)       
  -------------*******---      
      
END           
ELSE BEGIN          
 set @table_name = 'Journal'         
 set @AcctEntries_table = 'JNL_AccingEnt'        
  --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value      
 set @where2 = N'WHERE J.year_month between @start_ym and @end_ym          
 and J.BusinessDate between @start_date and @end_date'        
  + ' and   J.TLR_DUMMY_FIELDS like '+  @LikeParamFirstPart +cast (@for_user as nvarchar(10))  +@LikeParamLastPart       
      
  set @where = N'WHERE J.year_month between @start_ym and @end_ym          
 and J.BusinessDate between @start_date and @end_date'        
   -- End Ibrahim Harby (17-12-2020)      
END          
          
if @for_user >0 and dbo.operator_has_wildcard_permissions(@for_user)<1          
 set @where =@where+' AND dbo.is_BranchAllowed(@for_user,J.Bank,J.Region,J.Branch)=1 '          
          
IF isNULL(@LCID,0) = 0           
--**CR16728 ** S          
 set @tran_def_columns = N'          
 , Tran_Title = T.Description collate SQL_Latin1_General_CP1_CI_AS, T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable , ChangedControlsData  '          
else          
 --**CR16728 ** E          
 set @tran_def_columns = N'          
 , Tran_Title = isNULL(isnull(RD.LocalDescription, D.Descriptor), T.Description collate SQL_Latin1_General_CP1_CI_AS), T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable , ChangedControlsData   '          
          
select @summary_sql =           
 substring(dbo.f_insert_new_lines(AccessString,72),7,3990)           
from dbo.SQLstrings           
where AccessName = 'JOURNAL_SUMMARY'      -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}    

select @AcctEntries_sql =      
 char(10)+N',(select       
x.Subscript,      
x.JNL_Acct_ENT_ACCOUNT,      
x.JNL_Acct_ENT_DB_CURR,      
x.JNL_Acct_ENT_DB_AMOUNT,      
x.JNL_Acct_ENT_CR_CURR,      
x.JNL_Acct_ENT_CR_AMOUNT      
'      
+ char(10)          
+ 'FROM dbo.'+@AcctEntries_table+N' x'         
+'      
where J.BusinessDate = x.BusinessDate      
and J.user_Number= x.user_Number      
and J.Bank = x.Bank       
and J.Region = x.Region       
and J.Branch = x.Branch       
and J.JNLSequence = x.JNLSequence       
for xml path(''AccountEntries'')      
) as AccountEntries      
'          
set @position = charindex(', dbo.opID_of_U#', @summary_sql, 100)          
if @position = 0 begin          
  raiserror('Get_Journal_Summary can not find ", dbo.opID_of_U#" in JOURNAL_SUMMARY SQLstrings.AccessString', 16, 1)          
  return -1          
end          
set @position_of_from = charindex(' FROM ', @summary_sql, @position) - (@position + 2)          
set @operator_columns = substring(@summary_sql, @position+2, @position_of_from)          
set @operator_columns = replace(@operator_columns, '(user_number', '(JS.user_number')          
set @position = @position -1          
if @debug > 0 or @@servername like '%DBMASTER%'begin          
 declare @min_date smalldate          
 if db_name() like '%archive'          
  set @min_date = dbo.smalldate_of(dbo.f_Teller_Base_date())          
 else          
  set @min_date = dbo.f_min_journal_business_date(dbo.smalldate_of(getdate()))          
           
 if @start_date < @min_date begin          
  if @min_date < dbo.smalldate_of(getdate()) begin          
   set @date_string = isNULL(cast (@start_date as varchar), '-NULL-')          
   set @date_string2 = convert(varchar(10), @min_date)          
   raiserror('Get_Journal_Summary @start_date,"%s" must be > "%s"'          
    , 16, 1, @date_string, @date_string2)          
   return -1          
  end          
 end          
 if @start_date > @end_date or @end_date is null begin          
  set @date_string = isNULL(cast(@end_date as varchar), '-NULL-')          
  set @date_string2 = cast(@start_date as varchar)           
          
  raiserror('Get_Journal_Summary @end_date, "%s" must be >= @startdate = "%s"'          
   , 16, 1, @date_string, @date_string2)          
  return -1          
 end          
end          
set @criteria = dbo.TRIM(@criteria)  -- TRIM off left and right spaces.          
if @criteria <> '' and substring(@criteria,1,8) not like '%where %' begin          
 if left(@criteria, 4) = 'AND '           
  set @criteria = @where + ' ' + @criteria          
 else begin          
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)          
  return -1          
 end          
end         
           
if @criteria = ''          
 set @criteria = @where          
else begin          
 if @criteria like '%[^a-z_0-9.]Bank %'           
  set @criteria = replace (@criteria, 'bank ', 'J.Bank ')          
          
 if @criteria like '%[^a-z_0-9.]user_number %'       set @criteria = replace (@criteria, 'user_number ', 'J.user_number')          
          
 if @criteria like '%[^a-z_0-9.]Region %'           
  set @criteria = replace (@criteria, 'region ', 'J.Region ')          
          
 if @criteria like '%[^a-z_0-9.]Branch %'           
  set @criteria = replace (@criteria, 'branch ', 'J.Branch ')          
          
 if substring(@criteria,1,8) not like '%where %' begin          
  if left(@criteria, 4) = 'AND '           
   set @criteria = @where + ' ' + @criteria          
  else begin          
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)          
   return -1          
  end          
 end else           
  set @criteria = @where +REPLACE(@criteria,'where', ' AND')          
end           
--*****************      
--***************  for union criteria      
set @criteria2 = dbo.TRIM(@criteria2)  -- TRIM off left and right spaces.          
if @criteria2 <> '' and substring(@criteria2,1,8) not like '%where %' begin          
 if left(@criteria2, 4) = 'AND '           
  set @criteria2 = @where2 + ' ' + @criteria2          
 else begin          
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)          
  return -1          
 end          
end         
           
if @criteria2 = ''          
 set @criteria2 = @where2          
else begin          
 if @criteria2 like '%[^a-z_0-9.]Bank %'           
  set @criteria2 = replace (@criteria2, 'bank ', 'J.Bank ')          
          
 if @criteria2 like '%[^a-z_0-9.]user_number %'       set @criteria2 = replace (@criteria2, 'user_number ', 'J.user_number')          
          
 if @criteria2 like '%[^a-z_0-9.]Region %'           
  set @criteria2 = replace (@criteria2, 'region ', 'J.Region ')          
          
 if @criteria2 like '%[^a-z_0-9.]Branch %'           
  set @criteria2 = replace (@criteria2, 'branch ', 'J.Branch ')          
          
 if substring(@criteria2,1,8) not like '%where %' begin          
  if left(@criteria2, 4) = 'AND '           
   set @criteria2 = @where2 + ' ' + @criteria2          
  else begin          
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)          
   return -1          
  end          
 end else           
  set @criteria2 = @where2 +REPLACE(@criteria2,'where', ' AND')     
end       
---***************************      
--------------------------------          
if @max_rows < 0 begin          
 raiserror('Get_Journal_Summary @max_rows "%d", must be at least 0', 16, 1, @max_rows)          
 return -1          
end          
          
set @normal_descending_order = N'          
 order by Bank,Region,Branch,user_number,TransactionTime desc, JNLSequence desc'          
set @normal_ascending_order = N'          
 order by Bank,Region,Branch,user_number,TransactionTime,JNLSequence'          
set @inside_order = case           
when @order_time_ascending = 0 and @page_back = 0 then @normal_descending_order          
when @order_time_ascending = 0 and @page_back = 1 then N'          
 order by Bank desc,Region desc,Branch desc, user_number desc,TransactionTime, JNLSequence'          
when @order_time_ascending = 1 and @page_back = 0 then @normal_ascending_order          
else N'          
 order by Bank desc,Region desc,Branch desc,user_number desc,TransactionTime desc, JNLSequence desc'          
end     
-- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}       
set @audit_sql = ' left join RimAuditTrails r on JS.Bank = r.Bank and JS.Branch = r.Branch and JS.Region = r.Region and JS.JNLSequence = r.JNLSequance and JS.TID = r.TID ' 
 -- [End:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}         
select @sql = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)           
+ substring(@summary_sql,1, @position)      
+ @AcctEntries_sql            
+ char(10)          
-- ** CR14330 ** S          
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint      

-- ** CR14330 ** E          
+ char(10) + @criteria + @inside_order          
          
--*****************      
--***************  for union       
 select @sql2 = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)           
+ substring(@summary_sql,1, @position)      
+ @AcctEntries_sql            
+ char(10)          
-- ** CR14330 ** S          
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint       
  
-- ** CR14330 ** E          
+ char(10) + @criteria2 + @inside_order          
--*****************      
if @page_back = 1 begin          
 set @outer_order = case @order_time_ascending          
          when 0 then @normal_descending_order          
   else @normal_ascending_order          
   end          
          
 set @sql = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql+N') BOTTOM' + @outer_order          
      
--***************  for union       
set @sql2 = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql2+N') BOTTOM' + @outer_order          
--*****************      
end          
IF isNULL(@LCID,0) = 0       
begin      
 --Begin Ibrahim Harby (20-01-2021)      
set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns   ++ N' FROM (' + @sql +       
                     '    union all '      
                     + @sql2 + ' ) AS JS    '+
  + ' '+ @audit_sql    +  -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}
  '    JOIN dbo.RulesTranName T     on T.TransactionName = JS.TranName'        
 end      
ELSE           
 set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns          
+ N'          
FROM (' + @sql + '       
union all      
  '+ @sql2 + ' ) AS JS   '+
  + ' '+ @audit_sql    +  -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}
  '       JOIN dbo.RulesTranName T          
  on T.TransactionName = JS.TranName          
LEFT OUTER JOIN dbo.RulesDescriptor D          
  on D.DescriptorID = T.DSC_Description          
LEFT OUTER JOIN dbo.RulesDescriptorLocal RD          
  on RD.DescriptorID = D.DescriptorID and LCID = @LCID'          
-- ** CR15838 ** S          
+ char(10) + @inside_order          
-- ** CR15838 ** E          
   --End Ibrahim Harby (20-01-2021)          
set @param_defs = N'@LCID int, @start_date smalldate, @end_date smalldate, @start_ym smallint, @end_ym smallint, @start_day tinyint, @end_day tinyint, @for_user internal_user_ID'          
if @debug > 0 begin          
 print '-------cut here ---------'           
 print 'declare ' + @param_defs + char(10)           
 print 'select @LCID = ' + isnull(cast(@LCID as varchar), 'NULL')          
 print '    , @start_date = '''+cast(@start_date as varchar) + ''''          
 print '    , @end_date = '''+cast(@end_date as varchar) + ''''          
 print '    , @start_ym = '+cast(@start_year_month as varchar)          
 print '    , @end_ym = '+cast(@end_year_month as varchar)          
 print '    , @start_day = '+cast(@start_day as varchar)          
 print '    , @end_day = '+cast(@end_day as varchar)          
 print ' ,@for_user='+cast(@for_user as varchar)          
 /*print '    , @user_number = ' + case @user_number when NULL then ' NULL ' else cast(@user_number as varchar) end*/          
 print @sql          
 if @debug > 3 return -1          
end        
print @sql    
 print '-----------------end sql --------------------'  
print @sql2   
 print '-----------------end sql2 --------------------'  
print @inside_order  
print '-----------------end @inside_order --------------------'  
exec dbo.sp_executesql @sql, @param_defs, @LCID, @start_date, @end_date          
 , @start_year_month, @end_year_month, @start_day, @end_day, @for_user         
  
go
drop_old_proc 'Get_Journal_Summary_For_Printing_Audit'
  go
CREATE PROC [dbo].[Get_Journal_Summary_For_Printing_Audit]          
 @criteria nvarchar(max) = '',    
 @criteria2 nvarchar(max) = '',    
 @start_date smalldate,         
 @end_date smalldate,       
 @order_time_ascending bit = 0,          
 @max_rows int = 9,  -- Zero means return only one row.          
 @page_back bit = 0,          
 @LCID int = NULL, -- May be used to get local tran Description.          
 @for_user internal_user_ID =0,          
 @debug int = 0        
AS          
-- Query the Teller journal summary view for records that match the criteria.          
-- For just the @max_rows that match the criteria, join in the description          
--  of the transaction as "Tran_Title".          
          
-- When @page_back is ON, you get the last n rows that match the criteria.          
          
-- This uses the select projection list developed by proc SetJnlSummaryColumns2.          
-- Copyright 2003, 2004, 2005, 2006, 2007, 2008 Getronics USA, INC. All rights reserved.          
-- Created 05Feb03 by Bodhi Densmore          
-- 07FEB03 Bodhi added start_date and end_date parameters to ensure quick retrieval.          
-- 02APR03 Bodhi - To improve performance, don'T use RulesDecriptorLOCAL table when it is not useful.          
-- 02JUL03 Bodhi - Join in isDupable and isCorrectable from RulesTranName, per request from Mike Chandler.          
-- 11JUL03 Bodhi - Normal order is ascending by operator and descending by time and jnlSequence.          
-- 10Mar04 Bodhi - Support having only user_number and not LoginID (Operator) in Journal.          
--                 Using a late-binding join to the Operator table for best performance.          
-- 22Apr04 Bodhi - Fix syntax bug in retrieving local descriptors for transaction name.          
-- 21May04 Bodhi - Support conversion of user_numbers to login IDS.          
-- 06JUL04 Bodhi - Join in isSuperDupable from RulesTranName, per CR9728.          
-- 31JAN04 Bodhi - Support additional fields like "Supervisor" as interual_user_ID. CR10172          
-- 27Jul05 Kevens - Support additional column names like bank, region and branch that are not exactly those names.          
-- 17Aug05 Bodhi - Support queries with only date criteria, - initial value of @criteria empty.          
-- 23SEP05 Bodhi - For better performance, calculate table name when only one month is used.          
--                 Replace f_OperatorID_of_user_number with opID_of_U#          
-- 31AUG06 Bodhi - Use nolock hint when number of @max_rows is small, indicating not-for-report.           
-- 15JAN07 Diana - Add extra condition to the 'where' clause for checking privileges in OperatorRoles. CR14966          
-- 22Apr07 Bodhi - Use "inside order" for ORDER BY after the final join.          
-- 22Apr07 B & D - Support SmallDate as integer.          
-- 22May07 Bodhi - Complain about start_date too early on DBMaster or if debugging.          
-- 16MAR08 DEEPAK D R - Collation cast added CR16728          
-- 08APR10 Bodhi - Forgive dates less than minimum when minimum is today (because Journal is empty).          
        
/*        
Modified by: Adel Shaban        
Date: 9/2/2011        
Reason: Fixing issue when table doesn't exist in database - issue#103687        
      
Modified by: Amira Kamel      
Date: 28/12/2013       
Reason: Selact Accounting Entries, host ref no , cheque no      
      
Modified by: Ibrahim Harby      
Date: 20/01/2021       
Reason: add @Sql2 , @where2 , @criteria2 for union sql2 with sql one       
 to get old behaviour data with new PostingFromSupervisor data       
*/        
        
SET NOCOUNT ON          
declare @sql nvarchar(max), @sql2 nvarchar(max), @param_defs nvarchar(1000)          
declare @summary_sql nvarchar(4000), @position int, @operator_columns nvarchar(500)          
declare @position_of_from int          
declare @date_string varchar(30), @date_string2 varchar(30)          
declare @normal_descending_order nvarchar(300)          
 , @normal_ascending_order nvarchar(300)          
 , @inside_order nvarchar(300)          
 , @outer_order nvarchar(300)          
declare @tran_def_columns nvarchar(200)          
declare @start_year_month smallint, @end_year_month smallint, @start_day tinyint, @end_day tinyint          
declare @table_name sysname, @suffix char(7)          
declare @where nvarchar(1000) , @where2 nvarchar(max)      
declare @AcctEntries_table sysname      
declare @AcctEntries_sql nvarchar(4000)        
declare @audit_sql    nvarchar(4000) -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}  
-- Begin Ibrahim Harby  (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value      
declare @LikeParamFirstPart nvarchar(100)      
set @LikeParamFirstPart =   '''%n="PostingFromSupervisor_RequesterUserNumber" v="'      
declare @LikeParamLastPart nvarchar(100)      
set @LikeParamLastPart =  '"%'''      
-- End Ibrahim Harby (17-12-2020)       
-- ** CR14330 ** S          
declare @no_lock_hint nvarchar(14)          
if @max_rows < 22          
 set @no_lock_hint = N' WITH (NOLOCK)' -- Read uncommitted when not for a print report.          
else          
 set @no_lock_hint = ''          
-- ** CR14330 ** E          
set @start_year_month = dbo.YYMM_of_SmallDate(@Start_Date)          
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)          
set @start_day = DatePart(dd, dbo.datetime_of_smalldate(@start_date))          
set @end_day = DatePart(dd, dbo.datetime_of_smalldate(@end_date))          
if @start_year_month = @end_year_month BEGIN          
 set @suffix = dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@start_date))          
 set @table_name = 'ZJournal'+ @suffix         
  set @AcctEntries_table = 'ZJNL_AccingEnt'+ @suffix        
 -- Adel Shaban - Fixing issue when table doesn't exist in database        
 if(Not Exists( Select 1 from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @table_name))        
 BEGIN        
 select * FROM Journal WHERE 1 = 2 -- return dataset with correct schema and no rows        
 RETURN -1 -- exist from proc         
 END        
 -- End of Adel Shaban - Fixing issue when table doesn't exist in database      
     
Declare @Expression varchar(max) = null    
Declare @individual varchar(max) = null    
Declare @usernumber varchar(max) = NULL    
    
SET @Expression = @criteria    
SET @Expression = REPLACE(@Expression, 'and', ',')    
SET @Expression = REPLACE(@Expression, ' ', '')    
    
WHILE LEN(@Expression) > 0    
BEGIN    
    IF PATINDEX('%,%', @Expression) > 0    
  BEGIN    
      SET @individual = SUBSTRING(@Expression, 0, PATINDEX('%,%', @Expression))    
    
      IF @individual LIKE 'user_number=%'    
    BEGIN      SET @usernumber = @individual    
    END    
    
      SET @Expression = SUBSTRING(@Expression, LEN(@individual + ',') + 1, LEN(@Expression))    
  END    
    ELSE    
  BEGIN    
   SET @individual = @Expression    
   SET @Expression = NULL    
       IF @individual LIKE 'user_number=%'    
    BEGIN      SET @usernumber = @individual    
    END    
  END    
END    
SET @usernumber = REPLACE(@usernumber, 'user_number=', '')    
    
 --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value      
  -- @where2 for union criteria       
 set @where2 = N'WHERE  J.TLR_DUMMY_FIELDS like '+ @LikeParamFirstPart +cast (@usernumber as nvarchar(10))  +@LikeParamLastPart      
   +' AND J.year_month = @start_ym' + char(10)         
 + ' AND J.BusinessDate_Day '          
 + case when @start_day = @end_day           
  then '= @start_day AND J.BusinessDate = @start_date'          
  else 'between @start_day and @end_day           
  and J.BusinessDate between @start_date and @end_date'          
  end          
      
   set @where = N'WHERE   J.year_month = @start_ym' + char(10)         
 + ' AND J.BusinessDate_Day '          
 + case when @start_day = @end_day           
  then '= @start_day AND J.BusinessDate = @start_date'          
  else 'between @start_day and @end_day        
  and J.BusinessDate between @start_date and @end_date'          
  end          
     -- End Ibrahim Harby (17-12-2020)       
  -------------*******---      
      
END           
ELSE BEGIN          
 set @table_name = 'Journal'         
 set @AcctEntries_table = 'JNL_AccingEnt'        
  --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value      
 set @where2 = N'WHERE J.year_month between @start_ym and @end_ym          
 and J.BusinessDate between @start_date and @end_date'        
  + ' and   J.TLR_DUMMY_FIELDS like '+  @LikeParamFirstPart +cast (@for_user as nvarchar(10))  +@LikeParamLastPart       
      
  set @where = N'WHERE J.year_month between @start_ym and @end_ym          
 and J.BusinessDate between @start_date and @end_date'        
   -- End Ibrahim Harby (17-12-2020)      
END          
          
if @for_user >0 and dbo.operator_has_wildcard_permissions(@for_user)<1          
 set @where =@where+' AND dbo.is_BranchAllowed(@for_user,J.Bank,J.Region,J.Branch)=1 '          
          
IF isNULL(@LCID,0) = 0           
--**CR16728 ** S          
 set @tran_def_columns = N'          
 , Tran_Title = T.Description collate SQL_Latin1_General_CP1_CI_AS, T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable ,  ChangedControlsData '          
else          
 --**CR16728 ** E          
 set @tran_def_columns = N'          
 , Tran_Title = isNULL(isnull(RD.LocalDescription, D.Descriptor), T.Description collate SQL_Latin1_General_CP1_CI_AS), T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable ,  ChangedControlsData  '          
          
select @summary_sql =           
 substring(dbo.f_insert_new_lines(AccessString,72),7,3990)           
from dbo.SQLstrings           
where AccessName = 'JOURNAL_SUMMARY'      -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}    
select @AcctEntries_sql =      
 char(10)+N',(select       
x.Subscript,      
x.JNL_Acct_ENT_ACCOUNT,      
x.JNL_Acct_ENT_DB_CURR,      
x.JNL_Acct_ENT_DB_AMOUNT,      
x.JNL_Acct_ENT_CR_CURR,      
x.JNL_Acct_ENT_CR_AMOUNT      
'      
+ char(10)          
+ 'FROM dbo.'+@AcctEntries_table+N' x'         
+'      
where J.BusinessDate = x.BusinessDate      
and J.user_Number= x.user_Number      
and J.Bank = x.Bank       
and J.Region = x.Region       
and J.Branch = x.Branch       
and J.JNLSequence = x.JNLSequence       
for xml path(''AccountEntries'')      
) as AccountEntries      
'          
set @position = charindex(', dbo.opID_of_U#', @summary_sql, 100)          
if @position = 0 begin          
  raiserror('Get_Journal_Summary can not find ", dbo.opID_of_U#" in JOURNAL_SUMMARY SQLstrings.AccessString', 16, 1)          
  return -1          
end          
set @position_of_from = charindex(' FROM ', @summary_sql, @position) - (@position + 2)          
set @operator_columns = substring(@summary_sql, @position+2, @position_of_from)          
set @operator_columns = replace(@operator_columns, '(user_number', '(JS.user_number')          
set @position = @position -1          
if @debug > 0 or @@servername like '%DBMASTER%'begin          
 declare @min_date smalldate          
 if db_name() like '%archive'          
  set @min_date = dbo.smalldate_of(dbo.f_Teller_Base_date())          
 else          
  set @min_date = dbo.f_min_journal_business_date(dbo.smalldate_of(getdate()))          
           
 if @start_date < @min_date begin          
  if @min_date < dbo.smalldate_of(getdate()) begin          
   set @date_string = isNULL(cast (@start_date as varchar), '-NULL-')          
   set @date_string2 = convert(varchar(10), @min_date)          
   raiserror('Get_Journal_Summary @start_date,"%s" must be > "%s"'          
    , 16, 1, @date_string, @date_string2)          
   return -1          
  end          
 end          
 if @start_date > @end_date or @end_date is null begin          
  set @date_string = isNULL(cast(@end_date as varchar), '-NULL-')          
  set @date_string2 = cast(@start_date as varchar)           
          
  raiserror('Get_Journal_Summary @end_date, "%s" must be >= @startdate = "%s"'          
   , 16, 1, @date_string, @date_string2)          
  return -1          
 end          
end          
set @criteria = dbo.TRIM(@criteria)  -- TRIM off left and right spaces.          
if @criteria <> '' and substring(@criteria,1,8) not like '%where %' begin          
 if left(@criteria, 4) = 'AND '           
  set @criteria = @where + ' ' + @criteria          
 else begin          
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)          
  return -1          
 end          
end         
           
if @criteria = ''          
 set @criteria = @where          
else begin          
 if @criteria like '%[^a-z_0-9.]Bank %'           
  set @criteria = replace (@criteria, 'bank ', 'J.Bank ')          
          
 if @criteria like '%[^a-z_0-9.]user_number %'       set @criteria = replace (@criteria, 'user_number ', 'J.user_number')          
          
 if @criteria like '%[^a-z_0-9.]Region %'           
  set @criteria = replace (@criteria, 'region ', 'J.Region ')          
          
 if @criteria like '%[^a-z_0-9.]Branch %'           
  set @criteria = replace (@criteria, 'branch ', 'J.Branch ')          
          
 if substring(@criteria,1,8) not like '%where %' begin          
  if left(@criteria, 4) = 'AND '           
   set @criteria = @where + ' ' + @criteria          
  else begin          
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)          
   return -1          
  end          
 end else           
  set @criteria = @where +REPLACE(@criteria,'where', ' AND')          
end           
--*****************      
--***************  for union criteria      
set @criteria2 = dbo.TRIM(@criteria2)  -- TRIM off left and right spaces.          
if @criteria2 <> '' and substring(@criteria2,1,8) not like '%where %' begin          
 if left(@criteria2, 4) = 'AND '           
  set @criteria2 = @where2 + ' ' + @criteria2          
 else begin          
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)          
  return -1          
 end          
end         
           
if @criteria2 = ''          
 set @criteria2 = @where2          
else begin          
 if @criteria2 like '%[^a-z_0-9.]Bank %'           
  set @criteria2 = replace (@criteria2, 'bank ', 'J.Bank ')          
          
 if @criteria2 like '%[^a-z_0-9.]user_number %'       set @criteria2 = replace (@criteria2, 'user_number ', 'J.user_number')          
          
 if @criteria2 like '%[^a-z_0-9.]Region %'           
  set @criteria2 = replace (@criteria2, 'region ', 'J.Region ')          
          
 if @criteria2 like '%[^a-z_0-9.]Branch %'           
  set @criteria2 = replace (@criteria2, 'branch ', 'J.Branch ')          
          
 if substring(@criteria2,1,8) not like '%where %' begin          
  if left(@criteria2, 4) = 'AND '           
   set @criteria2 = @where2 + ' ' + @criteria2          
  else begin          
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)          
   return -1          
  end          
 end else           
  set @criteria2 = @where2 +REPLACE(@criteria2,'where', ' AND')     
end       
---***************************      
--------------------------------          
if @max_rows < 0 begin          
 raiserror('Get_Journal_Summary @max_rows "%d", must be at least 0', 16, 1, @max_rows)          
 return -1          
end          
          
set @normal_descending_order = N'          
 order by Bank,Region,Branch,user_number,TransactionTime desc, JNLSequence desc'          
set @normal_ascending_order = N'          
 order by Bank,Region,Branch,user_number,TransactionTime,JNLSequence'          
set @inside_order = case           
when @order_time_ascending = 0 and @page_back = 0 then @normal_descending_order          
when @order_time_ascending = 0 and @page_back = 1 then N'          
 order by Bank desc,Region desc,Branch desc, user_number desc,TransactionTime, JNLSequence'          
when @order_time_ascending = 1 and @page_back = 0 then @normal_ascending_order          
else N'          
 order by Bank desc,Region desc,Branch desc,user_number desc,TransactionTime desc, JNLSequence desc'          
end     
-- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}       
set @audit_sql = ' inner join RimAuditTrails r on JS.Bank = r.Bank and JS.Branch = r.Branch and JS.Region = r.Region and JS.JNLSequence = r.JNLSequance and JS.TID = r.TID '  
 -- [End:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}         
select @sql = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)           
+ substring(@summary_sql,1, @position)      
+ @AcctEntries_sql            
+ char(10)          
-- ** CR14330 ** S          
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint      
-- ** CR14330 ** E          
+ char(10) + @criteria + @inside_order          
          
--*****************      
--***************  for union       
 select @sql2 = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)           
+ substring(@summary_sql,1, @position)      
+ @AcctEntries_sql            
+ char(10)          
-- ** CR14330 ** S          
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint       
-- ** CR14330 ** E          
+ char(10) + @criteria2 + @inside_order          
--*****************      
if @page_back = 1 begin          
 set @outer_order = case @order_time_ascending          
          when 0 then @normal_descending_order          
   else @normal_ascending_order          
   end          
          
 set @sql = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql+N') BOTTOM' + @outer_order          
      
--***************  for union       
set @sql2 = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql2+N') BOTTOM' + @outer_order          
--*****************      
end          
IF isNULL(@LCID,0) = 0       
begin      
 --Begin Ibrahim Harby (20-01-2021)      
set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns   ++ N' FROM (' + @sql +       
                     '    union all '      
                     + @sql2 + ' ) AS JS '
					 + ' '+ @audit_sql       -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}  
					    +'JOIN dbo.RulesTranName T     on T.TransactionName = JS.TranName'        
 end      
ELSE           
 set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns          
+ N'          
FROM (' + @sql + '       
union all      
  '+ @sql2 + ' ) AS JS  '
 + ' '+ @audit_sql    +  -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}          
' JOIN dbo.RulesTranName T          
  on T.TransactionName = JS.TranName          
LEFT OUTER JOIN dbo.RulesDescriptor D          
  on D.DescriptorID = T.DSC_Description          
LEFT OUTER JOIN dbo.RulesDescriptorLocal RD          
  on RD.DescriptorID = D.DescriptorID and LCID = @LCID'          
-- ** CR15838 ** S          
+ char(10) + @inside_order          
-- ** CR15838 ** E          
   --End Ibrahim Harby (20-01-2021)          
set @param_defs = N'@LCID int, @start_date smalldate, @end_date smalldate, @start_ym smallint, @end_ym smallint, @start_day tinyint, @end_day tinyint, @for_user internal_user_ID'          
if @debug > 0 begin          
 print '-------cut here ---------'           
 print 'declare ' + @param_defs + char(10)           
 print 'select @LCID = ' + isnull(cast(@LCID as varchar), 'NULL')          
 print '    , @start_date = '''+cast(@start_date as varchar) + ''''          
 print '    , @end_date = '''+cast(@end_date as varchar) + ''''          
 print '    , @start_ym = '+cast(@start_year_month as varchar)          
 print '    , @end_ym = '+cast(@end_year_month as varchar)          
 print '    , @start_day = '+cast(@start_day as varchar)          
 print '    , @end_day = '+cast(@end_day as varchar)          
 print ' ,@for_user='+cast(@for_user as varchar)          
 /*print '    , @user_number = ' + case @user_number when NULL then ' NULL ' else cast(@user_number as varchar) end*/          
 print @sql          
 if @debug > 3 return -1          
end        
print @sql    
 print '-----------------end sql --------------------'  
print @sql2   
 print '-----------------end sql2 --------------------'  
print @inside_order  
print '-----------------end @inside_order --------------------'  
exec dbo.sp_executesql @sql, @param_defs, @LCID, @start_date, @end_date          
 , @start_year_month, @end_year_month, @start_day, @end_day, @for_user         
  
go
drop_old_proc 'List_Journal_Transaction_Names_Audit'
  go
    
Create PROC List_Journal_Transaction_Names_Audit @bank BankID = 0,    
  @region RegionID = 0    
, @branch BranchID = 0    
, @teller OperatorID = ''    
, @cashdrawer CashDrawerNumber = NULL    
, @start_date SmallDate = null    
, @end_date SmallDate = null    
, @LCID LanguageLCID = 1033    
, @debug int = 0    
as     
-- Get transaction names from journal according to variable criteria.    
-- Copyright 1999-2005 GetronicsWang Co., LLC.  All rights reserved.    
-- Bodhi 30Oct01    
-- 15Jul02 0 === NULL    
-- 04SEP02 recode with sp_executesql    
-- 02APR03 Option to avoid using RulesDescriptorLocal    
-- 29AUG03 Order by transaction description. Restrict to isUITranOnly = 0 for better performance.    
-- 19SEP03 rearrange for performance.    
-- 03March04 - Allow for @Teller to be a User_Number    
-- 20AUG05 Bodhi - Optimize by using TellerStats when reasonable to reduces locking contention on the journal.    
--               - Also allow bank and region numbers greater than 254.    
-- 15Nov05 Bodhi - Use indexed view V_Teller_Journaling_Transaction_Names.    
-- 04Jun08 bodhi - Fix bug in handling localized descriptions.    
-- 13Nov16 May Hassan - Fix Issue# GFSX11195 Performance Issue, After replacing "TelleStats" with dbo.TellerTranStatus in selecting min(BusinessDate)  
--      the execution time is now 3s at the opening of jscan transaction.  
set nocount on    
declare @need_locale bit    
declare @user_number internal_user_ID, @start_year_month smallint, @end_year_month smallint    
declare @sql nvarchar(3000), @column_list nvarchar(500)    
declare @where nvarchar(1000)    
declare @param_list nvarchar(300)    
declare @journal_name sysname    
set @param_list = N'@bank bankID, @region regionID, @branch branchID    
, @teller OperatorID, @cashdrawer CashDrawerNumber    
, @start_date smalldate, @end_date smalldate, @LCID int, @user_number internal_user_ID'    
    
if @start_date is null     
       set @start_date = dbo.SmallDateAdd('dd', -7, dbo.smalldate_of(CURRENT_TIMESTAMP))    
if @end_date is null     
       set @end_date = dbo.SmallDateAdd('dd', +6, dbo.smalldate_of(CURRENT_TIMESTAMP))    
if @start_date > @end_date begin    
       raiserror('List_Journal_Transaction_Names start_date > end_date', 16, 1)    
       return -1    
end    
if @cashdrawer is null set @cashdrawer = ''    
              -- '' gives zero if CashDrawerNumber type is numeric.    
if (@cashdrawer = '')     
and @start_date >= (select min(BusinessDate) from dbo.TellerTranStats) begin    
       set @journal_name = 'TellerStats'    
       set @where = N'WHERE BusinessDate between @start_date and @end_date '    
end     
ELSE BEGIN    
       set @journal_name = 'Journal'    
       set @start_year_month = dbo.YYMM_of_SmallDate(@start_date)    
       set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)    
       if @start_year_month = @end_year_month    
              set @where = N'WHERE year_month = ' + cast(@start_year_month as varchar)    
       else    
              set @where = N'WHERE year_month between ' + cast(@start_year_month as varchar)     
                                         + N' AND '+ cast(@end_year_month as varchar)    
       set @where = @where + char(10)     
              + N' and BusinessDate >= @start_date and BusinessDate < = @end_date'    
       if @cashdrawer <> ''    
              set @where = @where + N' and CashDrawer = @cashdrawer'    
END    
if @Bank is null     
       set @bank = 0    
if @Region < 1  or @Region is null     
       set @region = 0    
if @Branch < 1 or @Branch is null     
       set @branch = 0    
if (@bank > 0)    
       set @where = @where + N'     
  and Bank = @bank'    
if @region > 0    
       set @where = @where + N'    
  and Region = @region'    
if @branch > 0    
       set @where = @where + N'    
  and Branch = @branch'    
if (@teller > '') begin    
              if dbo.is_integer(@Teller) = 1     
              set @user_number = cast(@Teller as smallint)    
       else    
              set @user_number = dbo.f_user_number_of_LoginID(@Teller)    
    
       if @user_number is null    
              set @user_number = 0    
       else     
              set @where = @where + N'    
      and user_number = @user_number'    
end else    
       set @user_number = 0    
    
IF EXISTS (select * from dbo.RulesDescriptorLocal where LCID = @LCID) BEGIN    
       SET @need_locale = 1    
       SET @column_list     
              = N'SET NOCOUNT ON     
select DISTINCT T.TransactionName as TranName, isNULL(RDL.LocalDescription,T.Descriptor) Descriptor, T.DSC_Description '    
END ELSE    
       SET @column_list     
              = N'SET NOCOUNT ON     
select DISTINCT T.TransactionName as TranName, T.Descriptor, T.DSC_Description '    
    
if @journal_name = 'TellerStats'    
SET @sql = @column_list + N'    
from  (SELECT DISTINCT TranID from dbo.TellerStats' + char(10)    
+@where +N') as J    
JOIN dbo.V_Teller_Journaling_Transaction_Names T    
  on T.TranID = J.TranID' 
  + ' join RimAuditTrails r on t.TransactionName = r.TransactionName '    
-- ** CR17258 ** S    
+ case  @need_locale when 1 then N'    
LEFT JOIN dbo.RulesDescriptorLocal RDL    
 on T.DSC_Description = RDL.DescriptorID and RDL.LCID = @LCID    
'    
       else ''     
       end    
+ N'    
ORDER BY 2'    
-- ** CR17258 ** E    
ELSE    
SET @sql = @column_list + N'    
from  (SELECT DISTINCT TranName from dbo.'+@journal_name+char(10)    
+@where +N') as J    
LEFT JOIN dbo.V_Teller_Journaling_Transaction_Names T    
on T.TransactionName = J.TranName'    
 + case  @need_locale when 1 then N'    
LEFT JOIN dbo.RulesDescriptorLocal RDL    
 on T.DSC_Description = RDL.DescriptorID and RDL.LCID = @LCID    
'    
       else ''     
       end    
+ N'    
ORDER BY 2'    
   print @sql   
if @debug > 0 begin     
       print 'declare ' + @param_list + char(10)     
       print 'select  @bank = ' + cast(@bank as varchar)    
       print '    , @region = ' + cast(@region as varchar)    
       print '    , @branch = ' + cast(@branch as varchar)    
       print '    , @teller = ''' + @teller + ''''    
       print '    , @user_number = ' + cast(@user_number as varchar)    
       print '    , @cashdrawer = ''' + cast(@cashdrawer as varchar) + ''''    
       print '    , @start_date = ''' + cast(@start_date as varchar)+ ''''    
       print '    , @end_date = ''' + cast(@end_date as varchar) + ''''    
       print @sql     
end    
set nocount OFF    
exec dbo.sp_executesql @sql, @param_list,    
       @bank, @region, @branch, @teller , @cashdrawer , @start_date, @end_date, @LCID, @user_number    
    
return @@error 
go


Drop_Old_Proc '[Get_Journal_Summary_For_Printing]' 
GO  
Create PROC [dbo].[Get_Journal_Summary_For_Printing]      
 @criteria nvarchar(max) = '',    
 @criteria2 nvarchar(max) = '',    
 @start_date smalldate,         
 @end_date smalldate,       
 @order_time_ascending bit = 0,          
 @max_rows int = 9,  -- Zero means return only one row.          
 @page_back bit = 0,          
 @LCID int = NULL, -- May be used to get local tran Description.          
 @for_user internal_user_ID =0,          
 @debug int = 0        
AS          
-- Query the Teller journal summary view for records that match the criteria.          
-- For just the @max_rows that match the criteria, join in the description          
--  of the transaction as "Tran_Title".          
          
-- When @page_back is ON, you get the last n rows that match the criteria.          
          
-- This uses the select projection list developed by proc SetJnlSummaryColumns2.          
-- Copyright 2003, 2004, 2005, 2006, 2007, 2008 Getronics USA, INC. All rights reserved.          
-- Created 05Feb03 by Bodhi Densmore          
-- 07FEB03 Bodhi added start_date and end_date parameters to ensure quick retrieval.          
-- 02APR03 Bodhi - To improve performance, don'T use RulesDecriptorLOCAL table when it is not useful.          
-- 02JUL03 Bodhi - Join in isDupable and isCorrectable from RulesTranName, per request from Mike Chandler.          
-- 11JUL03 Bodhi - Normal order is ascending by operator and descending by time and jnlSequence.          
-- 10Mar04 Bodhi - Support having only user_number and not LoginID (Operator) in Journal.          
--                 Using a late-binding join to the Operator table for best performance.          
-- 22Apr04 Bodhi - Fix syntax bug in retrieving local descriptors for transaction name.          
-- 21May04 Bodhi - Support conversion of user_numbers to login IDS.          
-- 06JUL04 Bodhi - Join in isSuperDupable from RulesTranName, per CR9728.          
-- 31JAN04 Bodhi - Support additional fields like "Supervisor" as interual_user_ID. CR10172          
-- 27Jul05 Kevens - Support additional column names like bank, region and branch that are not exactly those names.          
-- 17Aug05 Bodhi - Support queries with only date criteria, - initial value of @criteria empty.          
-- 23SEP05 Bodhi - For better performance, calculate table name when only one month is used.          
--                 Replace f_OperatorID_of_user_number with opID_of_U#          
-- 31AUG06 Bodhi - Use nolock hint when number of @max_rows is small, indicating not-for-report.           
-- 15JAN07 Diana - Add extra condition to the 'where' clause for checking privileges in OperatorRoles. CR14966          
-- 22Apr07 Bodhi - Use "inside order" for ORDER BY after the final join.          
-- 22Apr07 B & D - Support SmallDate as integer.          
-- 22May07 Bodhi - Complain about start_date too early on DBMaster or if debugging.          
-- 16MAR08 DEEPAK D R - Collation cast added CR16728          
-- 08APR10 Bodhi - Forgive dates less than minimum when minimum is today (because Journal is empty).          
        
/*        
Modified by: Adel Shaban        
Date: 9/2/2011        
Reason: Fixing issue when table doesn't exist in database - issue#103687        
      
Modified by: Amira Kamel      
Date: 28/12/2013       
Reason: Selact Accounting Entries, host ref no , cheque no      
      
Modified by: Ibrahim Harby      
Date: 20/01/2021       
Reason: add @Sql2 , @where2 , @criteria2 for union sql2 with sql one       
 to get old behaviour data with new PostingFromSupervisor data       
*/        
        
SET NOCOUNT ON          
declare @sql nvarchar(max), @sql2 nvarchar(max), @param_defs nvarchar(1000)          
declare @summary_sql nvarchar(4000), @position int, @operator_columns nvarchar(500)          
declare @position_of_from int          
declare @date_string varchar(30), @date_string2 varchar(30)          
declare @normal_descending_order nvarchar(300)          
 , @normal_ascending_order nvarchar(300)          
 , @inside_order nvarchar(300)          
 , @outer_order nvarchar(300)          
declare @tran_def_columns nvarchar(200)          
declare @start_year_month smallint, @end_year_month smallint, @start_day tinyint, @end_day tinyint          
declare @table_name sysname, @suffix char(7)          
declare @where nvarchar(1000) , @where2 nvarchar(max)      
declare @AcctEntries_table sysname      
declare @AcctEntries_sql nvarchar(4000)        
declare @audit_sql    nvarchar(4000) -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}  
-- Begin Ibrahim Harby  (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value      
declare @LikeParamFirstPart nvarchar(100)      
set @LikeParamFirstPart =   '''%n="PostingFromSupervisor_RequesterUserNumber" v="'      
declare @LikeParamLastPart nvarchar(100)      
set @LikeParamLastPart =  '"%'''      
-- End Ibrahim Harby (17-12-2020)       
-- ** CR14330 ** S          
declare @no_lock_hint nvarchar(14)          
if @max_rows < 22          
 set @no_lock_hint = N' WITH (NOLOCK)' -- Read uncommitted when not for a print report.          
else          
 set @no_lock_hint = ''          
-- ** CR14330 ** E          
set @start_year_month = dbo.YYMM_of_SmallDate(@Start_Date)          
set @end_year_month = dbo.YYMM_of_SmallDate(@end_date)          
set @start_day = DatePart(dd, dbo.datetime_of_smalldate(@start_date))          
set @end_day = DatePart(dd, dbo.datetime_of_smalldate(@end_date))          
if @start_year_month = @end_year_month BEGIN          
 set @suffix = dbo.jnl_partition_suffix_of_date (dbo.datetime_of_smalldate(@start_date))          
 set @table_name = 'ZJournal'+ @suffix         
  set @AcctEntries_table = 'ZJNL_AccingEnt'+ @suffix        
 -- Adel Shaban - Fixing issue when table doesn't exist in database        
 if(Not Exists( Select 1 from INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @table_name))        
 BEGIN        
 select * FROM Journal WHERE 1 = 2 -- return dataset with correct schema and no rows        
 RETURN -1 -- exist from proc         
 END        
 -- End of Adel Shaban - Fixing issue when table doesn't exist in database      
     
Declare @Expression varchar(max) = null    
Declare @individual varchar(max) = null    
Declare @usernumber varchar(max) = NULL    
    
SET @Expression = @criteria    
SET @Expression = REPLACE(@Expression, 'and', ',')    
SET @Expression = REPLACE(@Expression, ' ', '')    
    
WHILE LEN(@Expression) > 0    
BEGIN    
    IF PATINDEX('%,%', @Expression) > 0    
  BEGIN    
      SET @individual = SUBSTRING(@Expression, 0, PATINDEX('%,%', @Expression))    
    
      IF @individual LIKE 'user_number=%'    
    BEGIN      SET @usernumber = @individual    
    END    
    
      SET @Expression = SUBSTRING(@Expression, LEN(@individual + ',') + 1, LEN(@Expression))    
  END    
    ELSE    
  BEGIN    
   SET @individual = @Expression    
   SET @Expression = NULL    
       IF @individual LIKE 'user_number=%'    
    BEGIN      SET @usernumber = @individual    
    END    
  END    
END    
SET @usernumber = REPLACE(@usernumber, 'user_number=', '')    
    
 --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value      
  -- @where2 for union criteria       
 set @where2 = N'WHERE  J.TLR_DUMMY_FIELDS like '+ @LikeParamFirstPart +cast (@usernumber as nvarchar(10))  +@LikeParamLastPart      
   +' AND J.year_month = @start_ym' + char(10)         
 + ' AND J.BusinessDate_Day '          
 + case when @start_day = @end_day           
  then '= @start_day AND J.BusinessDate = @start_date'          
  else 'between @start_day and @end_day           
  and J.BusinessDate between @start_date and @end_date'          
  end          
      
   set @where = N'WHERE   J.year_month = @start_ym' + char(10)         
 + ' AND J.BusinessDate_Day '          
 + case when @start_day = @end_day           
  then '= @start_day AND J.BusinessDate = @start_date'          
  else 'between @start_day and @end_day        
  and J.BusinessDate between @start_date and @end_date'          
  end          
     -- End Ibrahim Harby (17-12-2020)       
  -------------*******---      
      
END           
ELSE BEGIN          
 set @table_name = 'Journal'         
 set @AcctEntries_table = 'JNL_AccingEnt'        
  --Begin Ibrahim Harby (17-12-2020) add this part to select where TLR_DUMMY_FIELDS contain this dummy filed and user_id value      
 set @where2 = N'WHERE J.year_month between @start_ym and @end_ym          
 and J.BusinessDate between @start_date and @end_date'        
  + ' and   J.TLR_DUMMY_FIELDS like '+  @LikeParamFirstPart +cast (@for_user as nvarchar(10))  +@LikeParamLastPart       
      
  set @where = N'WHERE J.year_month between @start_ym and @end_ym          
 and J.BusinessDate between @start_date and @end_date'        
   -- End Ibrahim Harby (17-12-2020)      
END          
          
if @for_user >0 and dbo.operator_has_wildcard_permissions(@for_user)<1          
 set @where =@where+' AND dbo.is_BranchAllowed(@for_user,J.Bank,J.Region,J.Branch)=1 '          
          
IF isNULL(@LCID,0) = 0           
--**CR16728 ** S          
 set @tran_def_columns = N'          
 , Tran_Title = T.Description collate SQL_Latin1_General_CP1_CI_AS, T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable , ChangedControlsData  '          
else          
 --**CR16728 ** E          
 set @tran_def_columns = N'          
 , Tran_Title = isNULL(isnull(RD.LocalDescription, D.Descriptor), T.Description collate SQL_Latin1_General_CP1_CI_AS), T.DSC_Description, T.isDupable, T.isCorrectable, T.isSuperDupable , ChangedControlsData   '          
          
select @summary_sql =           
 substring(dbo.f_insert_new_lines(AccessString,72),7,3990)           
from dbo.SQLstrings           
where AccessName = 'JOURNAL_SUMMARY'      -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}    

select @AcctEntries_sql =      
 char(10)+N',(select       
x.Subscript,      
x.JNL_Acct_ENT_ACCOUNT,      
x.JNL_Acct_ENT_DB_CURR,      
x.JNL_Acct_ENT_DB_AMOUNT,      
x.JNL_Acct_ENT_CR_CURR,      
x.JNL_Acct_ENT_CR_AMOUNT      
'      
+ char(10)          
+ 'FROM dbo.'+@AcctEntries_table+N' x'         
+'      
where J.BusinessDate = x.BusinessDate      
and J.user_Number= x.user_Number      
and J.Bank = x.Bank       
and J.Region = x.Region       
and J.Branch = x.Branch       
and J.JNLSequence = x.JNLSequence       
for xml path(''AccountEntries'')      
) as AccountEntries      
'          
set @position = charindex(', dbo.opID_of_U#', @summary_sql, 100)          
if @position = 0 begin          
  raiserror('Get_Journal_Summary can not find ", dbo.opID_of_U#" in JOURNAL_SUMMARY SQLstrings.AccessString', 16, 1)          
  return -1          
end          
set @position_of_from = charindex(' FROM ', @summary_sql, @position) - (@position + 2)          
set @operator_columns = substring(@summary_sql, @position+2, @position_of_from)          
set @operator_columns = replace(@operator_columns, '(user_number', '(JS.user_number')          
set @position = @position -1          
if @debug > 0 or @@servername like '%DBMASTER%'begin          
 declare @min_date smalldate          
 if db_name() like '%archive'          
  set @min_date = dbo.smalldate_of(dbo.f_Teller_Base_date())          
 else          
  set @min_date = dbo.f_min_journal_business_date(dbo.smalldate_of(getdate()))          
           
 if @start_date < @min_date begin          
  if @min_date < dbo.smalldate_of(getdate()) begin          
   set @date_string = isNULL(cast (@start_date as varchar), '-NULL-')          
   set @date_string2 = convert(varchar(10), @min_date)          
   raiserror('Get_Journal_Summary @start_date,"%s" must be > "%s"'          
    , 16, 1, @date_string, @date_string2)          
   return -1          
  end          
 end          
 if @start_date > @end_date or @end_date is null begin          
  set @date_string = isNULL(cast(@end_date as varchar), '-NULL-')          
  set @date_string2 = cast(@start_date as varchar)           
          
  raiserror('Get_Journal_Summary @end_date, "%s" must be >= @startdate = "%s"'          
   , 16, 1, @date_string, @date_string2)          
  return -1          
 end          
end          
set @criteria = dbo.TRIM(@criteria)  -- TRIM off left and right spaces.          
if @criteria <> '' and substring(@criteria,1,8) not like '%where %' begin          
 if left(@criteria, 4) = 'AND '           
  set @criteria = @where + ' ' + @criteria          
 else begin          
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)          
  return -1          
 end          
end         
           
if @criteria = ''          
 set @criteria = @where          
else begin          
 if @criteria like '%[^a-z_0-9.]Bank %'           
  set @criteria = replace (@criteria, 'bank ', 'J.Bank ')          
          
 if @criteria like '%[^a-z_0-9.]user_number %'       set @criteria = replace (@criteria, 'user_number ', 'J.user_number')          
          
 if @criteria like '%[^a-z_0-9.]Region %'           
  set @criteria = replace (@criteria, 'region ', 'J.Region ')          
          
 if @criteria like '%[^a-z_0-9.]Branch %'           
  set @criteria = replace (@criteria, 'branch ', 'J.Branch ')          
          
 if substring(@criteria,1,8) not like '%where %' begin          
  if left(@criteria, 4) = 'AND '           
   set @criteria = @where + ' ' + @criteria          
  else begin          
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria)          
   return -1          
  end          
 end else           
  set @criteria = @where +REPLACE(@criteria,'where', ' AND')          
end           
--*****************      
--***************  for union criteria      
set @criteria2 = dbo.TRIM(@criteria2)  -- TRIM off left and right spaces.          
if @criteria2 <> '' and substring(@criteria2,1,8) not like '%where %' begin          
 if left(@criteria2, 4) = 'AND '           
  set @criteria2 = @where2 + ' ' + @criteria2          
 else begin          
  raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)          
  return -1          
 end          
end         
           
if @criteria2 = ''          
 set @criteria2 = @where2          
else begin          
 if @criteria2 like '%[^a-z_0-9.]Bank %'           
  set @criteria2 = replace (@criteria2, 'bank ', 'J.Bank ')          
          
 if @criteria2 like '%[^a-z_0-9.]user_number %'       set @criteria2 = replace (@criteria2, 'user_number ', 'J.user_number')          
          
 if @criteria2 like '%[^a-z_0-9.]Region %'           
  set @criteria2 = replace (@criteria2, 'region ', 'J.Region ')          
          
 if @criteria2 like '%[^a-z_0-9.]Branch %'           
  set @criteria2 = replace (@criteria2, 'branch ', 'J.Branch ')          
          
 if substring(@criteria2,1,8) not like '%where %' begin          
  if left(@criteria2, 4) = 'AND '           
   set @criteria2 = @where2 + ' ' + @criteria2          
  else begin          
   raiserror('Get_Journal_Summary @criteria must begin with WHERE. "%s"', 16, 1, @criteria2)          
   return -1          
  end          
 end else           
  set @criteria2 = @where2 +REPLACE(@criteria2,'where', ' AND')     
end       
---***************************      
--------------------------------          
if @max_rows < 0 begin          
 raiserror('Get_Journal_Summary @max_rows "%d", must be at least 0', 16, 1, @max_rows)          
 return -1          
end          
          
set @normal_descending_order = N'          
 order by Bank,Region,Branch,user_number,TransactionTime desc, JNLSequence desc'          
set @normal_ascending_order = N'          
 order by Bank,Region,Branch,user_number,TransactionTime,JNLSequence'          
set @inside_order = case           
when @order_time_ascending = 0 and @page_back = 0 then @normal_descending_order          
when @order_time_ascending = 0 and @page_back = 1 then N'          
 order by Bank desc,Region desc,Branch desc, user_number desc,TransactionTime, JNLSequence'          
when @order_time_ascending = 1 and @page_back = 0 then @normal_ascending_order          
else N'          
 order by Bank desc,Region desc,Branch desc,user_number desc,TransactionTime desc, JNLSequence desc'          
end     
-- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}       
set @audit_sql = ' left join RimAuditTrails r on JS.Bank = r.Bank and JS.Branch = r.Branch and JS.Region = r.Region and JS.JNLSequence = r.JNLSequance and JS.TID = r.TID ' 
 -- [End:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022} 
 --[Ibrahim Harby] [BEGIN: Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2 -FIX Issues]{27/09/2022}        
-- select @sql = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)      
select @sql = N'SELECT TOP 1000 '     
-- [Ibrahim Harby] [END: Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2 -FIX Issues]{27/09/2022} 
+ substring(@summary_sql,1, @position)      
+ @AcctEntries_sql            
+ char(10)          
-- ** CR14330 ** S          
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint      

-- ** CR14330 ** E          
+ char(10) + @criteria + @inside_order          
          
--*****************      
--***************  for union     
-- [Ibrahim Harby] [BEGIN: Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2 -FIX Issues]{27/09/2022}   
 select @sql2 = N'SELECT TOP '+cast((@max_rows+1) as nvarchar)   
 select @sql2 = N'SELECT TOP 1000 '  
 -- [Ibrahim Harby] [END: Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2 -FIX Issues]{27/09/2022}         
+ substring(@summary_sql,1, @position)      
+ @AcctEntries_sql            
+ char(10)          
-- ** CR14330 ** S          
+ 'FROM dbo.'+@table_name+N' J' + @no_lock_hint       
  
-- ** CR14330 ** E          
+ char(10) + @criteria2 + @inside_order          
--*****************      
if @page_back = 1 begin          
 set @outer_order = case @order_time_ascending          
          when 0 then @normal_descending_order          
   else @normal_ascending_order          
   end          
 -- [Ibrahim Harby] [BEGIN: Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2 -FIX Issues]{27/09/2022}          
 --set @sql = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql+N') BOTTOM' + @outer_order          
 --set @sql2 = N'select TOP '+cast((@max_rows+1) as nvarchar)+N' * from ('+@sql2+N') BOTTOM' + @outer_order    

 set @sql = N'select TOP 1000 '+N' * from ('+@sql+N') BOTTOM' + @outer_order          
 set @sql2 = N'select TOP 1000 '+N' * from ('+@sql2+N') BOTTOM' + @outer_order    
--***************  for union       
  
-- [Ibrahim Harby] [END: Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2 -FIX Issues]{27/09/2022}        
--*****************      
end          
IF isNULL(@LCID,0) = 0       
begin      
 --Begin Ibrahim Harby (20-01-2021)      
set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns   ++ N' FROM (' + @sql +       
                     '    union all '      
                     + @sql2 + ' ) AS JS    '+
  + ' '+ @audit_sql    +  -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}
  '    JOIN dbo.RulesTranName T     on T.TransactionName = JS.TranName'        
 end      
ELSE           
 set @sql = N'SELECT JS.*,' + @operator_columns + @tran_def_columns          
+ N'          
FROM (' + @sql + '       
union all      
  '+ @sql2 + ' ) AS JS   '+
  + ' '+ @audit_sql    +  -- [BEGIN:Enh GFSY00922 - ACM000000020167 - RIM Override Audit part 2]{05/09/2022}
  '       JOIN dbo.RulesTranName T          
  on T.TransactionName = JS.TranName          
LEFT OUTER JOIN dbo.RulesDescriptor D          
  on D.DescriptorID = T.DSC_Description          
LEFT OUTER JOIN dbo.RulesDescriptorLocal RD          
  on RD.DescriptorID = D.DescriptorID and LCID = @LCID'          
-- ** CR15838 ** S          
+ char(10) + @inside_order          
-- ** CR15838 ** E          
   --End Ibrahim Harby (20-01-2021)          
set @param_defs = N'@LCID int, @start_date smalldate, @end_date smalldate, @start_ym smallint, @end_ym smallint, @start_day tinyint, @end_day tinyint, @for_user internal_user_ID'          
if @debug > 0 begin          
 print '-------cut here ---------'           
 print 'declare ' + @param_defs + char(10)           
 print 'select @LCID = ' + isnull(cast(@LCID as varchar), 'NULL')          
 print '    , @start_date = '''+cast(@start_date as varchar) + ''''          
 print '    , @end_date = '''+cast(@end_date as varchar) + ''''          
 print '    , @start_ym = '+cast(@start_year_month as varchar)          
 print '    , @end_ym = '+cast(@end_year_month as varchar)          
 print '    , @start_day = '+cast(@start_day as varchar)          
 print '    , @end_day = '+cast(@end_day as varchar)          
 print ' ,@for_user='+cast(@for_user as varchar)          
 /*print '    , @user_number = ' + case @user_number when NULL then ' NULL ' else cast(@user_number as varchar) end*/          
 print @sql          
 if @debug > 3 return -1          
end        
print @sql    
 print '-----------------end sql --------------------'  
print @sql2   
 print '-----------------end sql2 --------------------'  
print @inside_order  
print '-----------------end @inside_order --------------------'  
exec dbo.sp_executesql @sql, @param_defs, @LCID, @start_date, @end_date          
 , @start_year_month, @end_year_month, @start_day, @end_day, @for_user         
  
go
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc TLR_IR_LockupMsgs
Go
create  procedure dbo.TLR_IR_LockupMsgs --'ITSOFT\karim.mahmoud','2017/04/29'
 @OperatorID     OperatorID,    
 @business_date  smalldatetime,
 @FileRefNo     ReferenceNumber  = null,
 @StatusId       int  = null,      
 @PaymentMethodId  int  = null       ,
 @CorresBank  varchar(100) = null,
 @DrCurrency  char(3) = null,
 @CrCurrency  char(3) = null,
 @MsgDate  varchar(10) = null,
 @CrAccountNo  varchar(12) = null,
 @OredringCustomer varchar(100) = null,
 @SenderReference varchar(50) = null ,
 @DrAmount  decimal(21,6) = 0 ,
 @CrAmount  decimal(21,6) = 0 ,
 @MsgRefNo     ReferenceNumber   = null
as      
/*      
CreationDate: 2005-7-20      
OriginalName: dbo.TLR_IR_LockupMsgsByFileRef      
Programmer  : Sayed Hussein      
Description : Select Messages filter by one (or all) of the following criteria       
              {FileRefNo,StatusId,PaymentMethodId}   
         And operator id for visibility   
Output:        
Assumption:       
      
ModifiedDate: 2005-7-21      
Modifer:      Sayed Hussein        
ModifyReason: Group by file ref     

ModifiedDate: 29/4/2008     
Modifer:      hany nasr        
ModifyReason: performance issue


ModifiedDate: 23/6/2008     
Modifer:      Mohamed Gad        
ModifyReason: Adding Branch,MsgType,DrAccountNo_DepLoan and IR.* to the return result

ModifiedDate: 26 January 2009
Modifer:   Hany A Hassan	   
ModifyReason:   Change the Data Type of @FileRefNo,@MsgRefNo to ReferenceNumber 

ModifiedDate:	2011-04-06
Modifer:		Osama Orabi	   
ModifyReason:   add two columns two return recordset

ModifiedDate: 2012-10-29  
Modifer:  Hatim ALSum      
ModifyReason:   add Missing Columns to return RecordSet 

ModifiedDate: 2015-05-27 
Modifer:  Asmaa Gamal       
ModifyReason:   Fix issue # GFSX08949 remove dublicate retrive columns (ValueDate,MsgValueDate)

ModifiedDate: 2018-08-28 
Modifer:  Nada Elshafie      
ModifyReason:  GFSY00717 - retrieve FLD_111 and FLD_121

ModifiedDate: 2021-08-08 
Modifer:  Ahmed Atef      
ModifyReason:  GFSY00870 - retrieve MT199Generated

ModifiedDate: 2022-09-29
Modifer:  Aya Tarek     
ModifyReason:  GFSX15238 - retrieve IsMX

*/      
      
declare @IS_IR_SuperVisor as int    
select @IS_IR_SuperVisor = T.IR_SuperVisor 
from  dbo.TellerConfig T 
inner  join 
 dbo.Operator O 
on  O.user_number = T.[User_Id] 
where  O.LoginID = @OperatorID    
 
declare @sql varchar(8000)
 
set  @sql = 
'select MsgRefNo,
 FLD_20 as SenderRefNo,
 S1.ShortDescription as Status, 
 DrAmount as DebitAmount,
 ValueDate ,
 SenderBank,
 FileRefNo,
 FilePathName,
 S2.ShortDescription as PaymentMethod ,
 isnull(S3.ShortDescription, '''') as Action,
 isnull(S4.ShortDescription, '''') as SendTo,
 StatusID,
 PaymentMethodID,
 ActionID,
 SendToID,
 AccountOfficerID,
 DateTimeStamp,
 PreparedBy,
 SpecialRateNeeded,
 MsgValueDate,
 VoucherOK,
 AuthorizedBy,
 ApprovedBy,
 DrAccountNo,
 DrAccountName,
 DrCurrency,
 DrAmount,
 DrAddress,
 DrExchangeRate,
 DrCommission,
 CrAccountNo,
 CrAccountName,
 CrCurrency,
 CrAmount,
 CrAddress,
 OrderingCustomer,
 CrExchangeRate,
 CrCommission,
 GTDTicket,
 OriginalMsg,
 Fld_50K,
 Fld_59,
 Charge_Det,
 BeneficiaryAmount,
 BeneficiaryCurrency,
 BeneficiarySellRate,
 BeneficiaryBuyRate,
 BeneficiaryGTDTicket,
 BeneficiaryName,
 BeneficiaryIDType,
 BeneficiaryIDNumber,
 BeneficiaryPhone,
 BeneficiaryAddress,
 BeneficiaryNarrative,
 Row_Version,
 LockedByID,
 IR.Updator,
 IR.LastChanged,
 Branch,
 MsgType,
 DrAccountNo_DepLoan,
 MsgValueDate, 
 IR.DrAccountNo_AcctType,
 IR.DrAccountNo_ApplType,
 IR.CrAccountNo_AcctType,  
 IR.CrAccountNo_ApplType,  
 IR.CrAccountNo_DepLoan,
 IR.MT103Generated,
 IR.MT202Generated,
 IR.Account_With_Ref,
 IR.Account_With_Ac,
 IR.Account_With_Name,
 IR.ValueCurrency,
 IR.Order_Cust_Name,
 IR.Order_Cust_Add1,
 IR.Order_Cust_Add2,
 IR.Order_Inst,
 IR.Order_Inst_Name,
 IR.Order_Inst_Add1,
 IR.BeneficiaryAccount,
 IR.FLD_70,
 IR.FLD_71A,
 IR.DrValueDate,
 IR.CrValueDate,
 IR.CrNarrative,
 IR.DrNarrative,
 IR.FLD_20,
 IR.FLD_23,
 IR.FLD_33,
 IR.FLD_52,
 IR.FLD_53,
 IR.Is_FLD_20_Duplicate,
 IR.ExceptionList,
 IR.OldStatusID,
 IR.OldDrAccountNo,
 IR.OldDrAccountNo_AcctType,
 IR.OldDrAccountNo_ApplType,
 IR.OldDrAccountNo_DepLoan,
 IR.OldDrAccountName,
 IR.OldDrCurrency,
 IR.OldDrAmount,
 IR.OldDrExchangeRate,
 IR.OldDrCommission,
 IR.OldCrAccountNo,
 IR.OldCrAccountNo_AcctType,
 IR.OldCrAccountNo_ApplType,
 IR.OldCrAccountNo_DepLoan,
 IR.OldCrAccountName,
 IR.OldCrCurrency,
 IR.OldCrAmount,
 IR.OldCrExchangeRate,
 IR.OldCrCommission,
 IR.OldDrValueDate,
 IR.OldCrValueDate,
 IR.OldCrNarrative,
 IR.OldDrNarrative,
 IR.DrRealExchangeRate,
 IR.CrRealExchangeRate,
 IR.TTAmount,
 IR.TTCurrency,
 IR.DrSellExchangeRate,
 IR.CrBuyExchangeRate,
 IR.IBAN,
 IR.Ordering_IBAN,
 IR.CrRimNo,
 IR.Sender_BIC,
 IR.FLD_72,
 IR.Ben_Inst_BIC,
 0 as CrExchangeGain,   
 0 as DrExchangeGain,
 IR.FLD_111,
 IR.FLD_121,
 IR.MT199Generated,
 IR.IsMX  
from    IR
inner  join 
 Status S1  
on   IR.StatusID = S1.[Id]
And S1.StatusTypeID = 12  
inner  join 
 Status S2  
on   IR.PaymentMethodID = S2.[Id] 
And S2.StatusTypeID = 13
LEFT  join 
 Status S3  
on   IR.ActionID = S3.[Id]
And S3.StatusTypeID = 14
Left  join 
 Status S4
on   IR.SendToID = S4.[Id]
And S4.StatusTypeID = 15
where     
(
 (SendToID = 5 /*SendToTeller*/OR SendToID = 6 /*SendAllToTeller*/)    
    OR 
 (    
     (SendToID = 1 /*SendToAccountOfficer*/OR SendToID = 2 /*SendAllToAccountOfficer*/)
  And AccountOfficerID = '''+@OperatorID+'''    
 )    
 OR
 (
  (SendToID = 3 /*SendToSupervisor*/OR SendToID = 4 /*SendAllToSupervisor*/)
  And '+convert(varchar(10),@IS_IR_SuperVisor)+' = 1
 )    
)
 
AND ValueDate <= ''' + convert(varchar, @business_date,111) + ''''
 
if (@FileRefNo is not null)       
 set @sql = @sql + ' AND (FileRefNo      = '''+@FileRefNo+''')'
 
if (@MsgRefNo is not null)       
 set @sql = @sql + ' AND (MsgRefNo       = '''+@MsgRefNo+''')'
 
if (@PaymentMethodId is not null)       
 set @sql = @sql + ' AND (PaymentMethodId   = '+convert(varchar(10),@PaymentMethodId)+')'
 
if (@StatusId is not null)       
 set @sql = @sql + ' AND  (StatusId     = '+convert(varchar(10),@StatusId) +' )'
 
if ((@CorresBank is not null) and (@CorresBank <> ''))
 set @sql = @sql + ' AND DrAccountName = '''+@CorresBank+''''
 
if ((@DrCurrency is not null) and (@DrCurrency <> ''))
 set @sql = @sql + ' AND DrCurrency = '''+@DrCurrency+''''
 
if ((@CrCurrency is not null) and (@CrCurrency <> ''))
 set @sql = @sql + ' AND CrCurrency = '''+@CrCurrency+''''
 
if ((@MsgDate is not null) and (@MsgDate <> ''))
 set @sql = @sql + ' AND MsgValueDate = '''+@MsgDate+''''
 
if ((@CrAccountNo is not null) and (@CrAccountNo <> ''))
 set @sql = @sql + ' AND ( CrAccountNo = '''+@CrAccountNo+''')'
 
if ((@OredringCustomer is not null) and (@OredringCustomer <> ''))
 set @sql = @sql + ' AND ( Fld_50K like ''%'+@OredringCustomer+'%'')'
 
if ((@SenderReference is not null) and (@SenderReference <> ''))
 set @sql = @sql + ' AND ( Fld_20 LIKE ''%'+@SenderReference+'%'')'
 
if ((@DrAmount is not null) and (@DrAmount <> 0))
 set @sql = @sql + ' AND ( DrAmount = '+convert(varchar(50),@DrAmount)+')'
 
if ((@CrAmount is not null) and (@CrAmount <> 0))
 set @sql = @sql + ' AND ( CrAmount = '+convert(varchar(50),@CrAmount)+')'
 
 set @sql= @sql + ' And (LockedByID is NULL or LockedByID ='''' or LockedByID <> ''' + @OperatorID+ ''')'
--print @sql
EXEC (@sql)
go
--End of Automatic Generation
