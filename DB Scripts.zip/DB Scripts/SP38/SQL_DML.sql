USE [Globalfs]
GO
       
If Not Exists(Select * From ServicePacks Where BasePackageName = 'ETHIX-Branch_2.00.46' And SP_Number = 38)
Begin
Insert Into ServicePacks(BasePackageName,SP_Number,SP_Name, LastPackageName, BriefDescription, DetailedDescription,IncludeWholeFilesOnly,DontRemoveTmpFldrWhenFinished,OptionalSourceList,Comments,PatchNumber)
Values('ETHIX-Branch_2.00.46', 38,'SP38_ETHIX-Branch_2.0.46.0','SP37_ETHIX-Branch_2.0.46.0','SP38_ETHIX-Branch_2.0.46.0','', 1, 0, '', '',0)
End
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1104531)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1104531,N'TLR_loadfil',0,N'Labels',N'Load File')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1103175)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES (1,1103175,'TLR_FileLoading',0,'Labels','File Loading')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1103174)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES (1,1103174,'TLR_FileLocation',0,'Labels','File Location')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1100051)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	VALUES (1,1100051,'TLR_Load',0,'Labels','Load')
END
GO
--******************************************
--*********************** RulesTranField_ex
--******************************************

IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=257 AND FieldIDInPage='txt_BNK_TO_BNK_INFO_L0')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(257,NULL,N'Teller',N'txt_BNK_TO_BNK_INFO_L0',-1,-1,-1,1,0,N'',N'',N'',1)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=260 AND FieldIDInPage='txt_BNK_TO_BNK_INFO_L0')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(260,NULL,N'Teller',N'txt_BNK_TO_BNK_INFO_L0',-1,-1,-1,1,0,N'',N'',N'',1)
END
GO
--************** Begin Mostafa Helmy Defect #GFSX14132*****************


DELETE FROM RulesLocalErrorDescription where DescriptionNumber IN (SELECT DescriptionNumber FROM RulesErrorDescription WHERE Name='TLR_SpecialNeeds_Repetition' AND DescriptionNumber=1200000)
DELETE FROM RulesLocalErrorDescription where DescriptionNumber IN (SELECT DescriptionNumber FROM RulesErrorDescription WHERE Name='TLR_SpecialNeedsType_Select' AND DescriptionNumber=1200001)
DELETE FROM RulesLocalErrorDescription where DescriptionNumber IN (SELECT DescriptionNumber FROM RulesErrorDescription WHERE Name='TLR_SpecialNeedsType_NotSelect' AND DescriptionNumber=1200002)
DELETE FROM RulesLocalErrorDescription where DescriptionNumber IN (SELECT DescriptionNumber FROM RulesErrorDescription WHERE Name='TLR_Disaple_SpecialNeeds' AND DescriptionNumber=1200004)



DELETE FROM RulesTranErrorDescriptions WHERE Error_Name IN (SELECT Name FROM RulesErrorDescription WHERE Name='TLR_SpecialNeeds_Repetition' AND DescriptionNumber=1200000)
DELETE FROM RulesTranErrorDescriptions WHERE Error_Name IN (SELECT Name FROM RulesErrorDescription WHERE Name='TLR_SpecialNeedsType_Select' AND DescriptionNumber=1200001)
DELETE FROM RulesTranErrorDescriptions WHERE Error_Name IN (SELECT Name FROM RulesErrorDescription WHERE Name='TLR_SpecialNeedsType_NotSelect' AND DescriptionNumber=1200002)
DELETE FROM RulesTranErrorDescriptions WHERE Error_Name IN (SELECT Name FROM RulesErrorDescription WHERE Name='TLR_Disaple_SpecialNeeds' AND DescriptionNumber=1200004)




DELETE FROM RulesErrorDescription WHERE Name='TLR_SpecialNeeds_Repetition' AND DescriptionNumber=1200000
DELETE FROM RulesErrorDescription WHERE Name='TLR_SpecialNeedsType_Select' AND DescriptionNumber=1200001
DELETE FROM RulesErrorDescription WHERE Name='TLR_SpecialNeedsType_NotSelect' AND DescriptionNumber=1200002
DELETE FROM RulesErrorDescription WHERE Name='TLR_Disaple_SpecialNeeds' AND DescriptionNumber=1200004











/*********************RulesErrorDescription**************/
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber =1801 )
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate) 
 Values (1801,'TLR_Disaple_SpecialNeeds','Please disable the special needs flag because all the special needs types for this rim are closed','Please disable the special needs flag because all the special needs types for this rim are closed',4,'',1,'ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM',1,'Dec 31 2222 12:00AM')
End



If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1802)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate) 
 Values (1802,'TLR_SpecialNeeds_Repetition','Special Needs Type Can not be rpeated','Special Needs Type Can not be rpeated',4,'',1,'ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM',1,'Dec 31 2222 12:00AM')
End

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1803)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate) 
 Values (1803,'TLR_SpecialNeedsType_Select','Please enter the special needs info because this is a special needs customer','Please enter the special needs info because this is a special needs customer',4,'',1,'ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM',1,'Dec 31 2222 12:00AM')
End

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1804)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate) 
 Values (1804,'TLR_SpecialNeedsType_NotSelect','Please enable the special needs flag','Please enable the special needs flag',4,'',1,'ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM',1,'Dec 31 2222 12:00AM')
End



/******************************RulesLocalErrorDescription*******************************/
If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1801)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1801,N'����� ����� ���� ���������� ������ �� ��� ��� �� ��� �� �������� ������ ���� ������ �� �������',N'����� ����� ���� ���������� ������ �� ��� ��� �� ��� �� �������� ������ ���� ������ �� �������','','ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM')
End

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1802)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1802,N'��� ���������� ������ �� ���� �������',N'��� ���������� ������ �� ���� �������','','ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM')
End

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1803)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1803,N'����� ����� �������� �� ��� ������ ��� ������ �� ��� ���������� ������',N'����� ����� �������� �� ��� ������ ��� ������ �� ��� ���������� ������','','ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM')
End

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1804)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer,LastChanged)
 Values (1025,1804,N'����� ����� ���������� ������ ������',N'����� ����� ���������� ������ ������','','ITSOFT\mostafa.helmy','Dec 20 2018 10:08AM')
End
/**************************RulesTranErrorDescriptions***********************/
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'TLR_SpecialNeeds_Repetition')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','TLR_SpecialNeeds_Repetition','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'TLR_SpecialNeedsType_Select')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','TLR_SpecialNeedsType_Select','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'TLR_SpecialNeedsType_NotSelect')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('OpenPersonalRim','TLR_SpecialNeedsType_NotSelect','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'TLR_SpecialNeeds_Repetition')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('EditPersonalRim','TLR_SpecialNeeds_Repetition','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'TLR_SpecialNeedsType_Select')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('EditPersonalRim','TLR_SpecialNeedsType_Select','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'TLR_SpecialNeedsType_NotSelect')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('EditPersonalRim','TLR_SpecialNeedsType_NotSelect','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'TLR_Disaple_SpecialNeeds')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('EditPersonalRim','TLR_Disaple_SpecialNeeds','Dec  20 2018 11:43AM','ITSOFT\mostafa.helmy',1,'Dec 31 9998 12:00AM','Sep  25 2018 11:43AM')
End
go

--************** End Mostafa Helmy Defect #GFSX14132*****************
--          	Aya Tarek  20/5/2020		
--    CR_ACM-GFSY00796 - BARWA_ACM18597_Outward transfers 
--------------------------------------------


---------------------------------
-- SQLStrings -------------------
---------------------------------
IF Not  EXISTS (select * from SQLstrings where AccessID =1100064)
Begin

insert into SQLstrings (AppID,AccessID ,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values ( 1,1100064 ,'TLR_GET_DEFAULT_CORRES_BANKS','P',1,'Globalfs','dbo.Get_DEFAULTCorres_Banks',0,'ITSOFT\aya.tarek','ITSOFT\aya.tarek','may 20 2020  1:00PM','Get default correspondent banks for currency in Issue tt',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','Apr 19 2020  4:00PM','','',0,0,1,0,0,0,0,0)
End

GO
--Programmer : Mostafa Sayed
--Date       : [01/06/2020]
--Reason     : CR#GFSY00805 - BARWA_ACM18599_General Enhancement
--==============================================================
--RulesDescriptor
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105617)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105617,N'TLR_JNL_PRINTING',1,N'Labels',N'Teller Journal Printing')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105617 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105617,1025,N'����� ���� ����� ������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105618)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105618,N'TLR_PRT_VOUCHERS',1,N'Labels',N'Print Vouchers')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105618 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105618,1025,N'����� ���������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105623)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105623,N'TLR_NUM_TRAN_PER_PAGE',1,N'Labels',N'Number Of Transactions Per Page:')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105623 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105623,1025,N'��� ��������� �� �����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105621)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105621,N'TLR_SEL_ONE_RECORD',1,N'Labels',N'Select at least one record.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105621 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105621,1025,N'��� ����� ����� ��� �����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105629)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105629,N'TLR_ENTER_NUM_OF_TRANS',1,N'Labels',N'Enter Number Of Transactions Per Page')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105629 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105629,1025,N'�� ������ ��� ��������� �� �����')
END
GO
--RulesTranName
If Not Exists(Select * From RulesTranName Where TranID = 861)
Begin
 Insert Into RulesTranName(TransactionName,TranID,Description,DSC_Description,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,RowStatus,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,TotalsType,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
 Values ('TJPrinting',861,'Teller Journal Printing',1105617,10,'Teller',1,1,'',0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,0)
End
go
--RulesContainerTrans
If Not Exists(Select * From RulesContainerTrans Where container_name = 'Teller' And TranName = 'TJPrinting')
Begin
 Insert Into RulesContainerTrans(container_name,TranName)
 Values ('Teller','TJPrinting')
End
go
--Component
If Not Exists(Select * From Component Where ComponentID = 306)
Begin
 Insert Into Component(ComponentID,AppID,ComponentName,ComponentType,Description,ProjectDirectory,ProjectFile,ProjectType,ProjectTarget,ProductionGroup,isSourceShipped,TargetDirectory,TypeLibrary,TypeLibVersion,GUID,VersionInfoFile,FileVersion,ComponentSize,InstallDirectory,ProductionGroup2,InstallDirectory2,RowStatus,WiseProject,BuildChangesOnly,SymbolsFile)
 Values (306,1,N'TJPrinting','DLL','',N'Teller.Net\Source\BP\Custom\TJPrinting',N'TJPrinting.csproj','C#2010',N'Debug','Client_NonRegistered',1,N'..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\',NULL,NULL,NULL,NULL,'2.0.46.0',32768,N'shared.net\Source\bin\Common\Teller',NULL,NULL,1,N'GFSTellerdotNetClient.wsm',1,N'TJPrinting.pdb')
End
go
--RulesTranConfig
If Not Exists(Select * From RulesTranConfig Where TranID = 861)
Begin
 Insert Into RulesTranConfig(TranID,DenomRequired,AccountingEntries,DrAccountCategoryID,CrAccountCategoryID,LimitCategoryID,FeesCategoryID,ExchangeType,OffLineAmount,AllowEmptyAccountingEntries,VerifySignatrue,ReadAllAccountingEntries,ShowInAdmin,OD_DrAccountCategoryID,PrintOption,ForcePositioning,EnableCharges,SalesMessageActive,FutureStaleChequeDays,BackDatedStaleChequeDays,ValidateStaleCheque,StaleChequeAction,StaleChequeDefaultDate,EscWarningEnabled,ChqRngVal,ChqRngAction,Blacklisted,BlacklistedAction,BenPmtStrict,BenPmtWarning,HasCheckList,CheckListCategoryID,ShowAvlBal,AutoPrintPassBook,TranCommissionGroupID,UseSimpleChargeControl,GLCategoryID,DaysAllowedForReversal,TranLimitID,ChequeType,CashFollowAcctCurr,useFX,CheckDrawerTypeRestrictions,use_XPath_app,SameRIMForCharge,SameCurrencyForCharge,PrimaryIDExpiryVal,PrimaryIDExpiryAction,Channel_Id,RecoveryReversal,Pack_ID,CustomerInquiry,TransOptPickListID,ReviewVouchersBeforePrinting,Charge_AcctCategoryID,UpdDateReqired,UpdDateValue,UpdDateAction,IsFinancialTran,ShortDescription,TranOptionFLD,CHK_IncludeAccumilative,CHK_AccumilativeInfoMessage,OpenSessionRequired,SupportResend,CheckBillPastDueDT,PastDueDTAction,UseExpressions,WorkOnNightlyModeAllowed,CheqTypeConfig,StaffsRelativeValidation,UseTCR)
 Values (861,0,0,0,0,0,0,NULL,1002.00,1,0,0,1,64,0,2,0,0,2,13,1,'STOP',0,0,1,'Warning',0,'',0,0,0,3,0,0,1,0,13,10,NULL,NULL,1,0,0,0,0,0,1,N'Warning',NULL,1,NULL,0,NULL,0,NULL,0,1,'0',0,'','',0,0,1,0,0,'Warning',0,1,N'N',NULL,0)
End
go
--Menu_Action
If Not Exists(Select * From Menu_Action Where MenuActionID = 884)
Begin
 Insert Into Menu_Action(MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Image,Enabled)
 Values (884,1,1105617,'Teller Journal Printing',2,'TJPrinting','',1)
End
go
--Menu_Definition
If Not Exists(Select * From Menu_Definition Where MenuID = 2502 And MenuKey = '36')
Begin
 Insert Into Menu_Definition(MenuID,MenuKey,Parent,MenuActionID)
 Values (2502,'36','3',884)
End
go
--TransactionScopes
IF NOT EXISTS(SELECT * FROM TransactionScopes Where Scope = 1001 And TranID = 861)
BEGIN
	INSERT INTO TransactionScopes(Scope,TranID)
	Values (1001,861)
END
GO
--RulesTranDescriptors
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=861 AND DSC_Name='TLR_JNL_PRINTING')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(861,N'TLR_JNL_PRINTING')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=861 AND DSC_Name='TLR_PRT_VOUCHERS')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(861,N'TLR_PRT_VOUCHERS')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=861 AND DSC_Name='TLR_SELECT_ALL')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(861,N'TLR_SELECT_ALL')
END
GO
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '1092')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'1092')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24165')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24165')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24260')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24260')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24303')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24303')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24304')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24304')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24305')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24305')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24306')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24306')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24308')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24308')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24309')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24309')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24310')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24310')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24311')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24311')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24312')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24312')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24313')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24313')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24314')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24314')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24319')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24319')
End
go
--If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '243861')
--Begin
-- Insert Into RulesTranDescriptors(TranID,DSC_Name)
-- Values (861,'243861')
--End
--go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24321')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24321')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24322')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24322')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24323')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24323')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24324')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24324')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24400')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24400')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '3030')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'3030')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '4003')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'4003')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '9016')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'9016')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '9017')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'9017')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'ACCOUNTNUM')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'ACCOUNTNUM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'AMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'AMOUNT')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'BACKWARD')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'BACKWARD')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'BANK')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'BANK')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'BRANCH')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'BRANCH')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'BRANCH_LABEL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'BRANCH_LABEL')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'BUTTON_CANCEL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'BUTTON_CANCEL')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'BUTTON_OK')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'BUTTON_OK')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'DISPLAY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'DISPLAY')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'DRAWER_NUM')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'DRAWER_NUM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'FORWARD')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'FORWARD')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'FromDB')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'FromDB')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'JSCN_ABSENTEE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'JSCN_ABSENTEE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'JSCN_HOSTOVR')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'JSCN_HOSTOVR')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'JSCN_OFFNET')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'JSCN_OFFNET')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'JSCN_OPOVR')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'JSCN_OPOVR')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'JSCN_SUPOVR')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'JSCN_SUPOVR')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'LOGON_ID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'LOGON_ID')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'MATCH')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'MATCH')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'MIEL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'MIEL')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'N_D')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'N_D')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'OffNetTrans')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'OffNetTrans')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'PRINT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'PRINT')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'REGION')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'REGION')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RowsToPrint')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RowsToPrint')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPT_JNL_SCAN_DIRECTION')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPT_JNL_SCAN_DIRECTION')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPT_JNL_SEQ_NUM')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPT_JNL_SEQ_NUM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPT_JNLSCN_BUS_DATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPT_JNLSCN_BUS_DATE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPT_JNLSCN_FLAGS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPT_JNLSCN_FLAGS')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPT_JNLSCN_TRAN_TIME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPT_JNLSCN_TRAN_TIME')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPT_REPORT_PAGE_OF')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPT_REPORT_PAGE_OF')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPT_REPORT_TO')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPT_REPORT_TO')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPT_SEQUENCE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPT_SEQUENCE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPTAMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPTAMOUNT')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPTBUSINESSDATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPTBUSINESSDATE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPTJOURNAL_SCAN_REPORT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPTJOURNAL_SCAN_REPORT')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPTPAGEPAGELABEL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPTPAGEPAGELABEL')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPTPRINTDATETIME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPTPRINTDATETIME')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'RPTTRANSACTIONDETAIL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'RPTTRANSACTIONDETAIL')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'SB_CORRECTION')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'SB_CORRECTION')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'SB_CORRECTION_BUSINESS_DATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'SB_CORRECTION_BUSINESS_DATE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'SB_REENTRY_REQUIRED')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'SB_REENTRY_REQUIRED')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'SCAN_CRITERIA')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'SCAN_CRITERIA')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'SCAN_RESULTS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'SCAN_RESULTS')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'ScanRange')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'ScanRange')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'SEQUENCE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'SEQUENCE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'STS_LINE_BUSDATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'STS_LINE_BUSDATE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TENK')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TENK')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TimeOut')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TimeOut')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_ADJUSTAMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_ADJUSTAMOUNT')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_APPLY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_APPLY')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_BTN_CLEAR')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_BTN_CLEAR')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_CASHIN')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_CASHIN')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_CashOut')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_CashOut')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_CHECKAMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_CHECKAMOUNT')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_CRITERIA')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_CRITERIA')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_JnlScan_RefNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_JnlScan_RefNo')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_Next_')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_Next_')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_Previous_')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_Previous_')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_SEARCH_VALUE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_SEARCH_VALUE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_TRANSACTION_TYPE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_TRANSACTION_TYPE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TM_VISIT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TM_VISIT')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TRAN_DATE_TIME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TRAN_DATE_TIME')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TRAN_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TRAN_NAME')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'UseArchive')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'UseArchive')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'UTCDisplay')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'UTCDisplay')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'VISIT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'VISIT')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = '24320')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'24320')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_NUM_TRAN_PER_PAGE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_NUM_TRAN_PER_PAGE')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_SEL_ONE_RECORD')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_SEL_ONE_RECORD')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 861 And DSC_Name = 'TLR_ENTER_NUM_OF_TRANS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name)
 Values (861,'TLR_ENTER_NUM_OF_TRANS')
End
go
--RulesParam
If Not Exists(Select * From RulesParam Where ParamName='MaxNumberOfTransactions')
Begin
	DECLARE @paramID1 int
	SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
	Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
	Values (@paramID1,'MaxNumberOfTransactions','To set maximum number of transactions to be printed from journal','',0,1,0,'','Static','')
End
go
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'TJPrinting' And FieldName = 'MaxNumberOfTransactions' And Param = 'MaxNumberOfTransactions')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value)
 VALUES ('TJPrinting','MaxNumberOfTransactions','MaxNumberOfTransactions','50')
END
GO
------------------------------------------------------------------------------------------------------------------------------------
--**Devolper	:	Shaimaa AbdElnasser
--**Date		:	[14/07/2020]		
--**For	        :   GFSY00802 - AJF - Employer List Classification
------------------------------------------------------------------------------------------------------------------------------------

PRINT 'Start. Script for CR# GFSY00802 DML Script'
GO
-------------------------------------------------------
-- Add combo box for sector type rules tran Db field EX
-------------------------------------------------------
		DECLARE @tranIdEmployerNamesList int 
		DECLARE @tranIdOpenPersonalRim int 
		DECLARE @tranIdEditPersonalRim int 
		DECLARE @fieldID int
		SELECT @tranIdEmployerNamesList = TranID FROM RulesTranName WHERE TransactionName = 'EmployerNamesList'
		SELECT @tranIdOpenPersonalRim = TranID FROM RulesTranName WHERE TransactionName = 'OpenPersonalRim'
		SELECT @tranIdEditPersonalRim = TranID FROM RulesTranName WHERE TransactionName = 'EditPersonalRim'
		SELECT @fieldID = FieldID FROM RulesDBField WHERE Name = 'TLR_PURPOSE'

		IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldID = @fieldID and TranID = @tranIdEmployerNamesList)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (@tranIdEmployerNamesList,@fieldID,'Teller','cbo_SectorType',-1,-1,-1,0,0,0)
END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'cbo_certification' and TranID = @tranIdEmployerNamesList)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (@tranIdEmployerNamesList,null,'Teller','cbo_certification',-1,-1,-1,1,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'cbo_certification' and TranID = @tranIdOpenPersonalRim)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (@tranIdOpenPersonalRim,null,'Teller','cbo_certification',-1,-1,-1,1,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'cbo_certification' and TranID = @tranIdEditPersonalRim)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (@tranIdEditPersonalRim,null,'Teller','cbo_certification',-1,-1,-1,1,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_certification' and TranID = @tranIdEmployerNamesList)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (@tranIdEmployerNamesList,null,'Teller','lbl_certification',-1,-1,-1,0,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_certification' and TranID = @tranIdOpenPersonalRim)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (@tranIdOpenPersonalRim,null,'Teller','lbl_certification',-1,-1,-1,0,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_certification' and TranID = @tranIdEditPersonalRim)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (@tranIdEditPersonalRim,null,'Teller','lbl_certification',-1,-1,-1,0,0,1)
		END
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_SectorType' and TranID = @tranIdEmployerNamesList)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (@tranIdEmployerNamesList,null,'Teller','lbl_SectorType',-1,-1,-1,0,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_SectorType' and TranID = @tranIdOpenPersonalRim)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (@tranIdOpenPersonalRim,null,'Teller','lbl_SectorType',-1,-1,-1,0,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_SectorType' and TranID = @tranIdEditPersonalRim)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (@tranIdEditPersonalRim,null,'Teller','lbl_SectorType',-1,-1,-1,0,0,1)
		END 

----------------------------------
-- Insert Certification Picklist -
----------------------------------
IF(not EXISTS (SELECT * from PickLists where PickList_Name = 'Certification' or PickListID = '561') )
	BEGIN 
		INSERT  INTO PickLists (AppID,PickList_Name,PickListID) 
			VALUES('1','Certification','561')
	END
IF(not EXISTS (SELECT * FROM PickList_Entries WHERE PickListID = '561' and DescriptorName = 'TLR_Certified') )
	BEGIN 
		INSERT INTO PickList_Entries (PickListID,AppID,DisplayOrder,DescriptorName,Value) 
		VALUES 
				('561','1','1','TLR_Certified','Certified')
	END
IF(not EXISTS (SELECT * FROM PickList_Entries WHERE PickListID = '561' and DescriptorName = 'TLR_Uncertified') )
	BEGIN 
		INSERT INTO PickList_Entries (PickListID,AppID,DisplayOrder,DescriptorName,Value) 
		VALUES 
				('561','1','2','TLR_Uncertified','Uncertified')
	END
-------------------------------------
--Add label for Certifcation picklist
-------------------------------------
 IF(not EXISTS (SELECT * FROM RulesDescriptor WHERE  Descriptor like '%Certification%' and DescriptorID = '1105640') )
	BEGIN 
		INSERT INTO RulesDescriptor (AppID,DescriptorID,Name,TypeName,Descriptor) 
		VALUES
			('1','1105640','TLR_Certification','Labels','Certification')
	END
IF(not EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = @tranIdEmployerNamesList  and  DSC_Name = 'TLR_Certification'   ) )
		BEGIN 
			INSERT INTO RulesTranDescriptors(TranID,DSC_Name) 
			VALUES
			 (@tranIdEmployerNamesList,'TLR_Certification')
		END

--------------------------------------
--add field to ALL USED transaction --
--------------------------------------
		SET @fieldID = (SELECT FieldID FROM RulesDBField WHERE Name = 'WF_TaskName')
	IF(not EXISTS (SELECT * FROM RulesTranField WHERE TranID = @tranIdEmployerNamesList  and  FieldID = @fieldID   ) )
		BEGIN 
			INSERT INTO RulesTranField (TranID,FieldID,Optional)
			VALUES
			 (@tranIdEmployerNamesList,@fieldID,1)
		END
	IF(not EXISTS (SELECT * FROM RulesTranField WHERE TranID = @tranIdOpenPersonalRim  and  FieldID = @fieldID   ) )
		BEGIN 
			INSERT INTO RulesTranField (TranID,FieldID,Optional)
			VALUES
			 (@tranIdOpenPersonalRim,@fieldID,1)
		END
IF(not EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = @tranIdOpenPersonalRim  and  DSC_Name = 'TLR_Certification'   ) )
		BEGIN 
			INSERT INTO RulesTranDescriptors(TranID,DSC_Name) 
			VALUES
			 (@tranIdOpenPersonalRim,'TLR_Certification')
		END
	IF(not EXISTS (SELECT * FROM RulesTranField WHERE TranID = @tranIdEditPersonalRim  and  FieldID = @fieldID   ) )
		BEGIN 
			INSERT INTO RulesTranField (TranID,FieldID,Optional)
			VALUES
			 (@tranIdEditPersonalRim,@fieldID,1)
		END
IF(not EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = @tranIdEditPersonalRim  and  DSC_Name = 'TLR_Certification'   ) )
		BEGIN 
			INSERT INTO RulesTranDescriptors(TranID,DSC_Name) 
			VALUES
			 (@tranIdEditPersonalRim,'TLR_Certification')
		END
-----------------------------------------
----- HostCore Services --#add new field 
-----------------------------------------
	DECLARE @serviceID INT
IF  EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'GetPersonalRimInfo')
BEGIN
    SELECT @serviceID =  ServiceId FROM HostCoreService WHERE ServiceName='GetPersonalRimInfo'       
    IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetPersonalRimInfo') And FieldId = 210)
    BEGIN   
        INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
        VALUES (@serviceID,210,'Certification','varchar',0,0,N'NULL','O','ITSOFT\shaimaa.nasser','Jul 13 2020 10:36AM',N'ITSOFT\shaimaa.nasser','Jul 13 2020 10:36AM')       
    END
   
END	
-------------------------------
----Update Bank Interface------
-------------------------------
	UPDATE  BankTPIInterface SET NoOfParameters = 239 WHERE FieldCode = 'CUS'
	
	Go	
--==================================================================================================================================================================
--Devolper	:	Mostafa Helmy
--Date		:	[16/07/2020]		
--Reason	:	Enh GFSY00777 - ACM000000017667 - KFH - Stop Validating Birth Date from Civil ID

--=====================================================================

PRINT 'Start. Script for CR# GFSY00777 DML Script'
GO

If Not Exists(Select * From RulesParam Where ParamName='AllowBirthDateModify')
Begin
    DECLARE @ParamID INT
	SELECT @ParamID = MAX(ParamID) +1 FROM RulesParam
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@ParamID,'AllowBirthDateModify','allow user to modify extracted birthdate value ',NULL,0,1,0,'','Static','','Nov 27 2019  9:54AM',N'ITSOFT\mai.gamal','Jan  1 1901 12:00AM','Dec 31 9999 12:00AM',1)
End
go


If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenPersonalRim' And FieldName = 'dt_BirthDate' And Param = 'AllowBirthDateModify')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
 Values ('OpenPersonalRim','dt_BirthDate','AllowBirthDateModify','0',N'ITSOFT\mai.gamal','nvarchar','Nov 27 2019 11:09AM',NULL)
End
go


If Not Exists(Select * From RulesTranFldParam Where TranName = 'EditPersonalRim' And FieldName = 'dt_BirthDate' And Param = 'AllowBirthDateModify')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
 Values ('EditPersonalRim','dt_BirthDate','AllowBirthDateModify','0',N'ITSOFT\mai.gamal','nvarchar','Nov 27 2019 11:09AM',NULL)
End
go
PRINT 'End... Script for CR# GFSY00777 DML Script'
GO
------------------------------------------------------------------------------------------------------------------------------------
--**Devolper	:	Shaimaa AbdElnasser
--**Date		:	[14/07/2020]		
--**For	        :   GFSY00802 - AJF - Employer List Classification
------------------------------------------------------------------------------------------------------------------------------------

PRINT 'Start. Script for CR# GFSY00802 DML Script'
GO
-------------------------------------------------------
-- Add combo box for sector type rules tran Db field EX
-------------------------------------------------------
		IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'cbo_SectorType' and TranID = 626)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (626,Null,'Teller','cbo_SectorType',-1,-1,-1,1,0,0)
END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'cbo_certification' and TranID = 626)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (626,null,'Teller','cbo_certification',-1,-1,-1,1,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'cbo_certification' and TranID = 547)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (547,null,'Teller','cbo_certification',-1,-1,-1,1,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'cbo_certification' and TranID = 564)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (564,null,'Teller','cbo_certification',-1,-1,-1,1,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_certification' and TranID = 626)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (626,null,'Teller','lbl_certification',-1,-1,-1,0,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_certification' and TranID = 547)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (547,null,'Teller','lbl_certification',-1,-1,-1,0,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_certification' and TranID = 564)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (564,null,'Teller','lbl_certification',-1,-1,-1,0,0,1)
		END
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_SectorType' and TranID = 626)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (626,null,'Teller','lbl_SectorType',-1,-1,-1,0,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_SectorType' and TranID = 547)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (547,null,'Teller','lbl_SectorType',-1,-1,-1,0,0,1)
		END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'lbl_SectorType' and TranID = 564)
		BEGIN
				INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
				VALUES   (564,null,'Teller','lbl_SectorType',-1,-1,-1,0,0,1)
		END 

----------------------------------
-- Insert Certification Picklist -
----------------------------------
IF(not EXISTS (SELECT * from PickLists where PickList_Name = 'Certification' or PickListID = '561') )
	BEGIN 
		INSERT  INTO PickLists (AppID,PickList_Name,PickListID) 
			VALUES('1','Certification','561')
	END
IF(not EXISTS (SELECT * FROM PickList_Entries WHERE PickListID = '561' and DescriptorName = 'TLR_Certified') )
	BEGIN 
		INSERT INTO PickList_Entries (PickListID,AppID,DisplayOrder,DescriptorName,Value) 
		VALUES 
				('561','1','1','TLR_Certified','Certified')
	END
IF(not EXISTS (SELECT * FROM PickList_Entries WHERE PickListID = '561' and DescriptorName = 'TLR_Uncertified') )
	BEGIN 
		INSERT INTO PickList_Entries (PickListID,AppID,DisplayOrder,DescriptorName,Value) 
		VALUES 
				('561','1','2','TLR_Uncertified','Uncertified')
	END
-------------------------------------
--Add label for Certifcation picklist
-------------------------------------
 IF(not EXISTS (SELECT * FROM RulesDescriptor WHERE  Descriptor like '%Certification%' and DescriptorID = '1105640') )
	BEGIN 
		INSERT INTO RulesDescriptor (AppID,DescriptorID,Name,TypeName,Descriptor) 
		VALUES
			('1','1105640','TLR_Certification','Labels','Certification')
	END
IF(not EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 626  and  DSC_Name = 'TLR_Certification'   ) )
		BEGIN 
			INSERT INTO RulesTranDescriptors(TranID,DSC_Name) 
			VALUES
			 (626,'TLR_Certification')
		END

--------------------------------------
--add field to ALL USED transaction --
--------------------------------------
DECLARE @fieldID int
		SET @fieldID = (SELECT FieldID FROM RulesDBField WHERE Name = 'WF_TaskName')
	IF(not EXISTS (SELECT * FROM RulesTranField WHERE TranID = 626  and  FieldID = @fieldID   ) )
		BEGIN 
			INSERT INTO RulesTranField (TranID,FieldID,Optional)
			VALUES
			 (626,@fieldID,1)
		END
	IF(not EXISTS (SELECT * FROM RulesTranField WHERE TranID = 547  and  FieldID = @fieldID   ) )
		BEGIN 
			INSERT INTO RulesTranField (TranID,FieldID,Optional)
			VALUES
			 (547,@fieldID,1)
		END
IF(not EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 547  and  DSC_Name = 'TLR_Certification'   ) )
		BEGIN 
			INSERT INTO RulesTranDescriptors(TranID,DSC_Name) 
			VALUES
			 (547,'TLR_Certification')
		END
	IF(not EXISTS (SELECT * FROM RulesTranField WHERE TranID = 564  and  FieldID = @fieldID   ) )
		BEGIN 
			INSERT INTO RulesTranField (TranID,FieldID,Optional)
			VALUES
			 (564,@fieldID,1)
		END
IF(not EXISTS (SELECT * FROM RulesTranDescriptors WHERE TranID = 564  and  DSC_Name = 'TLR_Certification'   ) )
		BEGIN 
			INSERT INTO RulesTranDescriptors(TranID,DSC_Name) 
			VALUES
			 (564,'TLR_Certification')
		END
-----------------------------------------
----- HostCore Services --#add new field 
-----------------------------------------
	DECLARE @serviceID INT
IF  EXISTS(SELECT * FROM HostCoreService WHERE ServiceName = 'GetPersonalRimInfo')
BEGIN
    SELECT @serviceID =  ServiceId FROM HostCoreService WHERE ServiceName='GetPersonalRimInfo'       
    IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId = (SELECT ServiceId FROM HostCoreService WHERE ServiceName='GetPersonalRimInfo') And FieldId = 210)
    BEGIN   
        INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Created,Updator,LastChanged)
        VALUES (@serviceID,210,'Certification','varchar',0,0,N'NULL','O','ITSOFT\shaimaa.nasser','Jul 13 2020 10:36AM',N'ITSOFT\shaimaa.nasser','Jul 13 2020 10:36AM')       
    END
   
END	
-------------------------------
----Update Bank Interface------
-------------------------------
	UPDATE  BankTPIInterface SET NoOfParameters = 239 WHERE FieldCode = 'CUS'
	
	Go	
--******************************************
--*********************** RulesDescriptor
--******************************************

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105643)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105643,N'lblTLR_BENEFICIARY_Age',0,N'Labels',N'Beneficiary Age')
END
GO


IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105644)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105644,N'chkWaiveCharge',0,N'Labels',N'Waive Charge')
END
GO

--******************************************
--******************* RulesDescriptorLocal
--******************************************

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105643 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105643,1025,N'��� ��������')
END
GO


IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105644 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105644,1025,N'������� �� ������')
END
GO

--******************************************
--******************* RulesTranDescriptors
--******************************************

IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=162 AND DSC_Name='lblTLR_BENEFICIARY_Age')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(162,N'lblTLR_BENEFICIARY_Age')
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=162 AND DSC_Name='chkWaiveCharge')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(162,N'chkWaiveCharge')
END
GO

--******************************************
--******************* RulesTranField_ex
--******************************************

IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=162 AND FieldIDInPage='txtBnfcryAge')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(162,NULL,N'Teller',N'txtBnfcryAge',-1,-1,-1,1,0,N'',N'',N'',0)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=162 AND FieldIDInPage='lblTLR_BENEFICIARY_Age')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(162,NULL,N'Teller',N'lblTLR_BENEFICIARY_Age',-1,-1,-1,1,0,N'',N'',N'',0)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=162 AND FieldIDInPage='chkWaiveCharge')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(162,NULL,N'Teller',N'chkWaiveCharge',-1,-1,-1,1,0,N'',N'',N'',0)
END
GO

--******************************************
--******************* RulesParam
--******************************************
    DECLARE @paramID int
	SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
	IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'CivilIDPara')
		BEGIN
			INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
			VALUES (@paramID,'CivilIDPara','Used for hold civil id in picklist',NULL,0,1,0,'','Static','',N'ITSOFT\abdelrhman.kamal',1)
	END
	GO
	IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CashWithdrawal' AND FieldName = 'TLR_ID_NAME' AND Param = 'CivilIDPara')
	BEGIN
	 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
	 VALUES ('CashWithdrawal','TLR_ID_NAME','CivilIDPara','AMLReferenceNumber',N'ITSOFT\abdelrhman.kamal','nvarchar',NULL)
	END
	GO


--Programmer : Mostafa Sayed
--Date       : [01/06/2020]
--Reason     : CR#GFSY00811 - BARWA_ACM18599_General Enhancement
--==============================================================
--RulesDescriptor
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105656)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105656,N'TLR_OV_MARK_COLOR_SD',0,N'Labels',N'Override Repair Mark Color')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105657)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105657,N'TLR_OV_MARK_COLOR_LD',0,N'Labels',N'This property is used to setup the color code used to mark fields which need a repair after override rejection by supervisor.')
END
GO
--SQLstrings
IF NOT EXISTS(SELECT * FROM SQLstrings WHERE AccessID=1100076)
BEGIN
	INSERT INTO SQLstrings(AppID,AccessID,AccessName,AccessString,CommandType,GetsRows,DataSource,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
	Values(1,1100076,N'TLR_GET_OV_REPAIR_FLDS',N'dbo.TLR_OV_GetRepairFields',N'P',1,N'Globalfs',0,N'',N'',N'Get marked fields to repair in case resend',1,N'',N'',0,0,1,NULL,NULL,0,0,0,0)
END
GO
--BankConfig
IF NOT EXISTS(SELECT * FROM BankConfig WHERE Name = 'OV_REPAIR_MARK_COLOR')
BEGIN
	EXEC dbo.BANK_CONFIG_INSERT @Name= 'OV_REPAIR_MARK_COLOR',@Value = 'EDD1E4',@DataType = 'Color',@ShortDescr = 'TLR_OV_MARK_COLOR_SD',@LongDescr = 'TLR_OV_MARK_COLOR_LD',@MaxVal = '6',@MinVal='0'
END
GO
IF not exists (select 1 from SQLstrings where AccessID  = 1100071)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile , Developer , Updator , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	SELECT 1 , 1100071 , 'TLR_IR_SELECT_PAID_MSG' , 'p' , 1, 'Globalfs' , 'dbo.IR_SELECT_PAID_MSG' , 0 , '' , '' , 'ITSOFT\sara.badwy' , 'ITSOFT\sara.badwy' , 'Return messages with status paid which found in IR table for given msgrefnums' , '' , '' , 0 , -1 , 0 , NULL , 0 , 0 , 0 , 0 , 0
END

------New Param -----------
  declare @ID int
select @ID = MAX(ParamID)+1 from RulesParam 

IF NOT EXISTS(SELECT * FROM RulesParam WHERE  ParamName = 'CheckForStatusPaid')
BEGIN
INSERT INTO RulesParam (ParamID, ParamName , Description , Parm_DSC , isGeneral , isCustomized , isDBCheck , DB_procName , ValuesTypes , DB_procValuesName )  
SELECT @ID, 'CheckForStatusPaid' , 'To Define If bank need to check paid status before posting or not' , NULL , 0 , 1 , 0 , '' , 'Static' , '' 
END
GO

-----------------------------------------------------------------// RulesParamValue //-------------------------------------------------------------------------------
 declare @ID int
 SELECT @ID =ParamID FROM RulesParam WHERE  ParamName = 'CheckForStatusPaid'
If Not Exists(Select * From RulesParamValue Where ParamID=@ID and ParamValue='False' )
Begin
 Insert Into RulesParamValue(ParamID,ParamValue,UPdator)
 Values (@ID,'False','ITSOFT\sara.badwy')
End

If Not Exists(Select * From RulesParamValue Where ParamID=@ID and ParamValue='True' )
Begin
 Insert Into RulesParamValue(ParamID,ParamValue,UPdator)
 Values (@ID,'True','ITSOFT\sara.badwy')
End
go


-----------------------------------------------------------------// RulesTranFldParam //-------------------------------------------------------------------------------

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardRemittanceHOSwift' And FieldName = 'CheckForStatusPaid' And Param = 'CheckForStatusPaid')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,DataType,Description)
 Values ('InwardRemittanceHOSwift','CheckForStatusPaid','CheckForStatusPaid','False','bit',NULL)
End
GO
-----------------------------------------------------------------// RulesDescriptor //-------------------------------------------------------------------------------
IF NOT EXISTS ( Select * From  dbo.RulesDescriptor Where  AppID = 1  AND  DescriptorID =  1105639  AND  Name = 'TLR_IR_ALREADY_PAID'  ) 
BEGIN 
INSERT INTO RulesDescriptor (AppID , DescriptorID , Name , forVB , TypeName , Descriptor , Creator , Updator )  
SELECT 1 , 1105639 , 'TLR_IR_ALREADY_PAID' , 0 , 'Labels' , 'Already Paid.' , 'ITSOFT\Sara.Badwy' , 'ITSOFT\Sara.Badwy'
END 
GO
-----------------------------------------------------------------// RulesTranDescriptors //-------------------------------------------------------------------------------

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID = 266  AND  DSC_Name = 'TLR_IR_ALREADY_PAID'  ) 
BEGIN 
	INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  SELECT 266   ,  'TLR_IR_ALREADY_PAID'  ,  'ITSOFT\Sara.Badwy'  ,  'ITSOFT\Sara.Badwy' 
END 
GO
If Not Exists(Select * From SQLstrings Where AccessID = 1100082)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName    ,CommandType ,GetsRows     , DataSource        ,AccessString              ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose            ,RowStatus ,RScmdType ,RScmd,ReadOnly ,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values                (1     ,  1100082  ,'GetLockRolls' ,'p'         ,1            ,'Globalfs'         ,'dbo.GetLockRolls'        ,0          ,''               ,''               ,'sql GetLockRolls' ,1         ,' '       ,''   ,0        ,0           ,1               ,NULL      ,0          ,0       ,0             ,0                  ,0)
End
go
--***************************************************
If Not Exists(Select * From SQLstrings Where AccessID = 1100083)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName            ,CommandType ,GetsRows    , DataSource        ,AccessString                      ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose                    ,RowStatus ,RScmdType ,RScmd ,ReadOnly ,CacheMinutes ,UseNewCacheRules ,CacheGroup ,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values                (1    ,  1100083  ,'GetLockAccountStatus' ,'p'         ,1           ,'Globalfs'         ,'dbo.GetLockAccountStatus'        ,0          ,''               ,''               ,'sql GetLockAccountStatus' ,1         ,' '       ,''    ,0        ,0            ,1                ,NULL       ,0          ,0       ,0             ,0                  ,0)
End
go
--***************************************************
If Not Exists(Select * From SQLstrings Where AccessID = 1100084)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName                      ,CommandType ,GetsRows     , DataSource        ,AccessString                        ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose                               ,RowStatus ,RScmdType ,RScmd ,ReadOnly ,CacheMinutes,UseNewCacheRules,CacheGroup   ,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values                (1    ,  1100084  ,'InsertOrUpdateLockAccountRoll'  ,'p'         ,0            ,'Globalfs'         ,'dbo.InsertOrUpdateLockAccountRoll' ,0          ,''               ,''               ,'sql InsertOrUpdateLockAccountRoll'   ,1         ,' '       ,''    ,0        ,0           ,1               ,NULL         ,0          ,0       ,0             ,0                  ,0)
End
go
--***************************************************
If Not Exists(Select * From SQLstrings Where AccessID = 1100085)
Begin
 Insert Into SQLstrings(AppID,  AccessID , AccessName             ,CommandType ,GetsRows    , DataSource   ,AccessString                ,OutputsXML ,OBSOLETE_XSLFile ,OBSOLETE_XDRFile ,Purpose                      ,RowStatus ,RScmdType ,RScmd,ReadOnly ,CacheMinutes ,UseNewCacheRules ,CacheGroup   ,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout)
 Values                (1    ,  1100085  ,'DeleteLockAccountRoll' ,'p'         ,0           ,'Globalfs'    ,'dbo.DeleteLockAccountRoll' ,0          ,''               ,''               ,'sql DeleteLockAccountRoll'  ,1         ,' '       ,''   ,0        ,0            ,1                ,NULL         ,0          ,0       ,0             ,0                  ,0)
End
go

--***************************************************
IF NOT EXISTS (SELECT * FROM RulesDescriptor WHERE NAME = 'LockRollAccountStatusError' AND DescriptorID = 1105662)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name                     , forVB , TypeName  , Descriptor , Creator , Updator )  
	values                      ( 1    , 1105662      , 'LockRollAccountStatusError' , 0     , 'Labels'  , 'only user with roll {0} can change status' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

--***************************************************
If Not Exists(Select * From RulesTranDescriptors Where TranID = 616 And DSC_Name = 'LockRollAccountStatusError')
Begin
 Insert Into RulesTranDescriptors(TranID,    DSC_Name          ,LastChanged             ,Updator                   , Creator                ,  Created               , RowStatus , EffectiveDate         ,ExpirationDate)
                           Values(  616 ,   'LockRollAccountStatusError', 'August  05 2020  10:44PM',  N'ITSOFT\ahmed.eliwa' , N'ITSOFT\ahmed.eliwa', 'August  05 2020  10:44PM', 1         ,'Jan  1 1901 12:00AM'  ,'Dec 31 9998 12:00AM')
End
Go
--***************************************************

--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00813 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00813 DML Script'
GO
 
--------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal --
--------------------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105646)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105646,'TLR_POSTTRANSACTION',0,'Labels','Post Transaction','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105646 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105646,1025,N'����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105647)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105647,'TLR_CANCELTRANSACTION',0,'Labels','Cancel Transaction','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105647 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105647,1025,N'����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105648)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105648,'TLR_CANNOTPOSTREASON',0,'Labels','You cannot post the transaction while selecting reason, You must select the main request','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105648 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105648,1025,N'�� ����� ����� �������� ����� ����� ����� � ��� ���� ����� ����� �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105649)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105649,'TLR_POSTINGCONFIRMATION',0,'Labels','Are you sure you want to post the transaction','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105649 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105649,1025,N'�� ��� ����� �� ��� ���� ��� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105650)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105650,'TLR_OVERRIDEPOSTEDBYSUPERVISOR',0,'Labels','Override Posted By Supervisor','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105650 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105650,1025,N'����� ����� ������ ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105651)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105651,'TLR_CANNOTCANCELREASON',0,'Labels','You cannot cancel the transaction while selecting reason, You must select the main request','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105651 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105651,1025,N'�� ����� ����� �������� ����� ����� ����� � ��� ���� ����� ����� �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105652)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105652,'TLR_CANCELINGCONFIRMATION',0,'Labels','Are you sure you want to cancel the transaction','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105652 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105652,1025,N'�� ��� ����� �� ��� ���� ����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105653)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105653,'TLR_OVERRIDECANCELBYSUPERVISOR',0,'Labels','Override Cancelled By Supervisor','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105653 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105653,1025,N'�� ����� ������� ������ ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105654)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105654,'TLR_OV_Status_CancelTran',0,'Labels','Transaction Cancelled','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105654 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105654,1025,N'�� ����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105655)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105655,'TLR_CannotPostTransaction',0,'Labels','Cannot post the transaction , there are some other reason waiting supervisor approval','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105655 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105655,1025,N'�� ���� ����� �������� � ����� ��� ��� ����� ������ ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

------------
-- Status --
------------
If Not Exists(Select * From Status Where StatusTypeID = 28 And id = 15)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (28,15,'OverridePostedBySupervisor','Supervisor post the trarnsaction by himself','TLR_OVERRIDEPOSTEDBYSUPERVISOR','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 28 And id = 16)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (28,16,'OverrideCancelledBySupervisor','Supervisor cancel the trarnsaction by himself','TLR_OVERRIDECANCELBYSUPERVISOR','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed')
End
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLStrings Where AccessID = 1100077)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100077,'SelectTranConfig','p',1,'Globalfs','dbo.SelectTranConfig',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select Tran Config',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100078)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100078,'SelectTellerConfig','p',1,'Globalfs','dbo.SelectTellerConfig',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select Teller Config',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100079)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100079,'SelectOverrideRequestReasons','p',1,'Globalfs','dbo.SelectOverrideRequestReasons',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select Override Request Reasons',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

PRINT 'End... Script for CR# GFSY00813 DML Script'
GO
--==================================================================================================================================================================

IF EXISTS (SELECT * FROM RulesDescriptor WHERE NAME = 'LockRollAccountStatusError' AND DescriptorID = 1105662)
Begin
 update RulesDescriptor
 set  Descriptor = 'Status can only be changed by a user with a role '
 where DescriptorID = 1105662
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105662 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105662,1025,N'�� ���� ����� ������ ��� ������ ������ �� ���','ITSOFT\ahmed.eliwa','August 12 2010  12:20PM',N'ITSOFT\ahmed.eliwa')
End
go

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1104531)
BEGIN
INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
Values(1,1104531,N'TLR_loadfil',0,N'Labels',N'Load File')
END
GO

--RulesDescriptor
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105659)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105659,N'TLR_FILE_WILL_NEGLECTED',0,N'Labels',N'The currently loaded file will be neglected.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105659 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105659,1025,N'.���� ����� ����� ���� �� ������ ������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105670)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105670,N'TLR_MISSING_CHQ_VALUE_DATE',0,N'Labels',N'Missing ChequeValueDate value.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105670 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105670,1025,N'.������ ChequeValueDate ����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105671)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105671,N'TLR_MISSING_POSTING_TYPE',0,N'Labels',N'Missing PostingType value.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105671 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105671,1025,N'.������ PostingType ����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105672)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105672,N'TLR_MISSING_DP_GL',0,N'Labels',N'Missing DP_GL value.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105672 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105672,1025,N'.������ DP_GL ����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105673)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105673,N'TLR_MISSING_ACCOUNT_NUMBER',0,N'Labels',N'Missing AccountNumber value.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105673 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105673,1025,N'.������ AccountNumber ����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105674)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105674,N'TLR_MISSING_AMOUNT',0,N'Labels',N'Missing TransferAmount/Local value.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105674 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105674,1025,N'.������ TransferAmount/Local ����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105675)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105675,N'TLR_INVALID_FILE_PROCESSING',0,N'Labels',N'Invalid file for processing.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105675 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105675,1025,N'.��� ����� ��� ���� ��������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105677)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105677,N'TLR_ROWS_LOADED_SUCCESSFULLY',0,N'Labels',N'Rows loaded successfully.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105677 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105677,1025,N'.���� �� �������')
END
GO

--RulesDescriptorLocal
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1104531 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1104531,1025,N'����� ���')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1103175 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1103175,1025,N'����� �����')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1103174 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1103174,1025,N'���� �����')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1100051 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1100051,1025,N'�����  ')
END
GO
--RulesTranDescriptors
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=269 AND DSC_Name='TLR_loadfil')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(269,N'TLR_loadfil')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=269 AND DSC_Name='TLR_FileLoading')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(269,N'TLR_FileLoading')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=269 AND DSC_Name='TLR_FileLocation')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(269,N'TLR_FileLocation')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=269 AND DSC_Name='TLR_Load')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(269,N'TLR_Load')
END
GO
--RulesTranField
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 269 AND FieldID = 286)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (269,286,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'LoadFile',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 269 AND FieldID = 207)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (269,207,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'FileName',0,-1)
END
GO
--RulesTranField_ex
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=269 AND FieldIDInPage='_chk_UploadFile')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(269,286,N'Teller',N'_chk_UploadFile',-1,-1,-1,1,0,N'TLR_loadfil',N'',N'',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=269 AND FieldIDInPage='_grb_FileLoading')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(269,NULL,N'Teller',N'_grb_FileLoading',-1,-1,-1,1,0,N'TLR_FileLoading',N'',N'',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=269 AND FieldIDInPage='_lbl_FileLocation')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(269,NULL,N'Teller',N'_lbl_FileLocation',-1,-1,-1,1,0,N'TLR_FileLocation',N'',N'',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=269 AND FieldIDInPage='_txt_FileName')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(269,207,N'Teller',N'_txt_FileName',-1,-1,-1,1,1,N'TLR_FileLocation',N'',N'',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=269 AND FieldIDInPage='_btn_LoadFile')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(269,NULL,N'Teller',N'_btn_LoadFile',-1,-1,-1,1,0,N'TLR_Load',N'',N'',0)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=269 AND FieldIDInPage='_btn_BrowseFile')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(269,NULL,N'Teller',N'_btn_BrowseFile',-1,-1,-1,1,0,N'',N'',N'',0)
END
GO


--Programmer : Mostafa Sayed
--Date       : [01/06/2020]
--Reason     : CR#GFSY00798 - BARWA_ACM18599_General Enhancement
--==============================================================
--RulesDescriptor
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105641 AND Name='TLR_REQUEST_ID')
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105641,N'TLR_REQUEST_ID',0,N'Labels',N'Request ID')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105645)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105645,N'TLR_OV_REQUESTS',0,N'Labels',N'Override Requests')
END
GO

--RulesTranDescriptors
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=383 AND DSC_Name='TLR_AMOUNT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(383,N'TLR_AMOUNT')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=383 AND DSC_Name='TLR_REQUEST_ID')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(383,N'TLR_REQUEST_ID')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=383 AND DSC_Name='TLR_CURRENCY')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(383,N'TLR_CURRENCY')
END
GO
IF NOT EXISTS(SELECT * FROM RulesContainerDescriptors WHERE container_name='Teller' AND Descriptor_Name='TLR_OV_REQUESTS')
BEGIN
	INSERT INTO RulesContainerDescriptors(container_name,Descriptor_Name)
	Values(N'Teller',N'TLR_OV_REQUESTS')
END
GO
-- =============================================
-- Author:		Aya Tarek and Shaimaa AbdelNasser
-- Create date: 27/5/2020
-- Description:	SKB_GFSY000809 DML 
-- =============================================

--------------------------------
--RulesDescriptor-----------
--------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE Name = 'TLR_TRANSFER_PURPOSE' and DescriptorID = 1105775) 
BEGIN
   INSERT INTO RulesDescriptor (DescriptorID,Name,TypeName,AppID,Descriptor) values (1105775,'TLR_TRANSFER_PURPOSE','Labels',1,'Transfer Purpose')
END
if(not EXISTS (select * from RulesDescriptorLocal where DescriptorID = '1105775' and LCID = '1025'  ) )
begin 
				insert into RulesDescriptorLocal (DescriptorID,LCID,LocalDescription)
						Values('1105775','1025',N'��� �������')
end
--------------------------------
--RulesParam-----------
--------------------------------
If Not Exists(Select * From RulesParam Where ParamName='NewSetupForTranPurpose')
Begin
    DECLARE @paramID1 int
    SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
    Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
    Values (@paramID1,'NewSetupForTranPurpose','This pick list will be loaded from the new setup table','',0,1,0,'','Static','')
End
--------------------------------
--RulesTranField-----------
--------------------------------
--- PurposeDescription AccountToAccountTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 192  AND  FieldID   =  1125   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 192   ,   1125   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode AccountToAccountTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 192  AND  FieldID   =  1154   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 192   ,   1154   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeDescription MultCreditTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 193 AND  FieldID   =  1660   ) 
BEGIN 
INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 193   ,   1660   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    9999    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode MultCreditTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 193  AND  FieldID   =  1890   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 193   ,   1890   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    999    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeDescription MultDepitTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 195 AND  FieldID   =  1660   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 195   ,   1660   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    9999    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode MultDepitTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 195  AND  FieldID   =  1890   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 195   ,  1890   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    999    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeDescription GLToGLTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 443 AND  FieldID   =  1125   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 443   ,   1125   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode GLToGLTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 443  AND  FieldID   =  1154   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 443   ,   1154   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode MultiTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 269  AND  FieldID   =  1890   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 269   ,   1890   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    999   ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
Go



----------------------------------------------------------------------------
---------------------  [RulesTranField]-------------------------------------
----------------------------------------------------------------------------
-----   TLR_SO_ACCOUNT_OFFICER_NAME
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 162 and FieldID = 1274) ---Cash Withdrawal
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (162,1274,1)
END
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 362 and FieldID = 1274) ---GL Cash Withdrawal
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (362,1274,1)
END
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 360 and FieldID = 1274) ---Account Closure
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (360,1274,1)
END
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 172 and FieldID = 1274) ---Buy Forign Currency
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (172,1274,1)
END
-----   TLR_ID_TYPE1

IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 162 and FieldID = 375) ---Cash Withdrawal
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (162,375,1)
END

IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 362 and FieldID = 375) --- GL Cash Withdrawal
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (362,375,1)
END
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 172 and FieldID = 375) --- Buy Forign Currency
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (172,375,1)
END
-----   TLR_SO_TYPE
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 360 and FieldID = 1151) --- Account Closure
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (360,1151,1)
END


--------------------------------
--RulesTranField_ex-----------
--------------------------------

-- PurposeDescription AccountToAccountTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 192 AND FieldIDInPage   = 'TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 192   ,  1125  ,  'Teller'  ,  'TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label AccountToAccountTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 192 AND   FieldIDInPage   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 192   ,    NULL    ,  'Teller'  ,  'TLR_TRANSFER_PURPOSE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO

-- PurposeDescription MultCreditTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 193   AND FieldIDInPage   = 'TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 193   ,  1660  ,  'Teller'  ,  'TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label MultCreditTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 193 AND   FieldIDInPage   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 193   ,    NULL    ,  'Teller'  ,  'TLR_TRANSFER_PURPOSE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO

-- PurposeDescription MultdebitTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 195  AND FieldIDInPage   = 'TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 195   ,  1660  ,  'Teller'  ,  'TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label MultdebitTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 195  AND  FieldIDInPage   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 195   ,    NULL    ,  'Teller'  ,  'TLR_TRANSFER_PURPOSE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO

-- PurposeDescription GLToGLTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 443    AND FieldIDInPage   = 'TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 443   ,  1125  ,  'Teller'  ,  'TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label GLToGLTransfer
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 443   AND  FieldIDInPage   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 443   ,    NULL    ,  'Teller'  ,  'TLR_TRANSFER_PURPOSE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO


----------------------------------------------------------------------------
---------------------  [RulesTranField_ex]-------------------------------------
----------------------------------------------------------------------------
--    TransferPurpose 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'TransferPurpose' and TranID = 162)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (162,Null,'Teller','TransferPurpose',-1,-1,-1,1,0,0)
END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'TransferPurpose' and TranID = 362)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (362,Null,'Teller','TransferPurpose',-1,-1,-1,1,0,0)
END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'TransferPurpose' and TranID = 360)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (360,Null,'Teller','TransferPurpose',-1,-1,-1,1,0,0)
END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'TransferPurpose' and TranID = 172)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (172,Null,'Teller','TransferPurpose',-1,-1,-1,1,0,0)
END 

--   TLR_TRANSFER_PURPOSE 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'TLR_TRANSFER_PURPOSE' and TranID = 162)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (162,Null,'Teller','TLR_TRANSFER_PURPOSE',-1,-1,-1,1,0,0)
END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'TLR_TRANSFER_PURPOSE' and TranID = 362)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (362,Null,'Teller','TLR_TRANSFER_PURPOSE',-1,-1,-1,1,0,0)
END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'TLR_TRANSFER_PURPOSE' and TranID = 360)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (360,Null,'Teller','TLR_TRANSFER_PURPOSE',-1,-1,-1,1,0,0)
END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'TLR_TRANSFER_PURPOSE' and TranID = 172)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (172,Null,'Teller','TLR_TRANSFER_PURPOSE',-1,-1,-1,1,0,1)
END 




--------------------------------
--RulesTranFldParam-----------
--------------------------------
-- PurposeDescription MultiTransfer


IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'MultiTransfer'  AND FieldName = 'TransferPurpose' AND Param = 'NewSetupForTranPurpose' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType,Description)
   Values( 'MultiTransfer' , 'TransferPurpose' , 'NewSetupForTranPurpose' , 0 ,'ITSOFT\aya.tarek' , 'nvarchar','This pick list will be loaded from the new setup table')
 END 
GO




---------------------------------
-- RulesTranDescriptors ---------
---------------------------------
-- PurposeDescription AccountToAccountTransfer

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 192 AND  DSC_Name   = 'TLR_TRANSACTION_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 192   ,  'TLR_TRANSACTION_PURPOSE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

-- PurposeDescription MultCreditTransfer

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 193 AND  DSC_Name   = 'TLR_TRANSACTION_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 193   ,  'TLR_TRANSACTION_PURPOSE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO


-- PurposeDescription MultdebitTransfer

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 195 AND  DSC_Name   = 'TLR_TRANSACTION_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 195   ,  'TLR_TRANSACTION_PURPOSE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

-- PurposeDescription GLToGLTransfer

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 443 AND  DSC_Name   = 'TLR_TRANSACTION_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 443   ,  'TLR_TRANSACTION_PURPOSE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

----------------------------------------------------------------------------
---------------------  [RulesTranDescriptors]-------------------------------
----------------------------------------------------------------------------
--   TLR_TRANSFER_PURPOSE
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 162 and DSC_Name = 'TLR_TRANSFER_PURPOSE') ---Cash Withdrawal
BEGIN
   INSERT INTO RulesTranDescriptors (TranID,DSC_Name) values (162,'TLR_TRANSFER_PURPOSE')
END
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 362 and DSC_Name = 'TLR_TRANSFER_PURPOSE') ---- GL Cash Withdrawal
BEGIN
   INSERT INTO RulesTranDescriptors (TranID,DSC_Name) values (362,'TLR_TRANSFER_PURPOSE')
END
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 360 and DSC_Name = 'TLR_TRANSFER_PURPOSE') ---- Account closure

BEGIN
   INSERT INTO RulesTranDescriptors (TranID,DSC_Name) values (360,'TLR_TRANSFER_PURPOSE')
END
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 172 and DSC_Name = 'TLR_TRANSFER_PURPOSE') ---- Buy Forign Currency

BEGIN
   INSERT INTO RulesTranDescriptors (TranID,DSC_Name) values (172,'TLR_TRANSFER_PURPOSE')
END

----------------------------------Credit
--------------------------------------- Cash Withdrawal //
-------------------------------------------------------//

--  [RulesTranField] === TLR_DEST_BANK_DETAIL 
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 162 and FieldID = 1322) 
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (162,1322,1)
END

-- [RulesTranField] === TLR_ID_TYPE1_3
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 162 and FieldID = 1086) 
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (162,1086,1)
END

--  [RulesTranField_ex] === DebitPurpose 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'DebitPurpose' and TranID = 162)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (162,Null,'Teller','DebitPurpose',-1,-1,-1,1,0,0)
END 

IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = '_lblTLR_TranPurpose' and TranID = 162)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (162,Null,'Teller','_lblTLR_TranPurpose',-1,-1,-1,1,0,0)
END 

--  [RulesTranDescriptors] === TLR_TRANSACTION_PURPOSE 
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 162 and DSC_Name = 'TLR_TRANSACTION_PURPOSE') 
BEGIN
   INSERT INTO RulesTranDescriptors (TranID,DSC_Name) values (162,'TLR_TRANSACTION_PURPOSE')
END
Go
--------------------------------------- Buy FCY Against GL //
-----------------------------------------------------------//

--  [RulesTranField] === TLR_DEST_BANK_DETAIL 
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 172 and FieldID = 1322) ----TLR_DEST_BANK_DETAIL   100
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (172,1322,1)
END

-- [RulesTranField] === TLR_ID_TYPE1_3
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 172 and FieldID = 1086) ------TLR_ID_TYPE1_3  30
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (172,1086,1)
END

--  [RulesTranField_ex] === DebitPurpose 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'DebitPurpose' and TranID = 172)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (172,Null,'Teller','DebitPurpose',-1,-1,-1,1,0,0)
END 

IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = '_lblTLR_TranPurpose' and TranID = 172)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (172,Null,'Teller','_lblTLR_TranPurpose',-1,-1,-1,1,0,0)
END 


--  [RulesTranDescriptors] === TLR_TRANSACTION_PURPOSE 
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 172 and DSC_Name = 'TLR_TRANSACTION_PURPOSE') 
BEGIN
   INSERT INTO RulesTranDescriptors (TranID,DSC_Name) values (172,'TLR_TRANSACTION_PURPOSE')
END
Go
--------------------------------------- GL Cash Withdrawal => BackOfficeCashWithdrawal 362 //
-----------------------------------------------------------//

--  [RulesTranField] === TLR_DEST_BANK_DETAIL 
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 362 and FieldID = 1322)
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (362,1322,1)
END

--  [RulesTranField] === TLR_ID_TYPE1_3 
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 362 and FieldID = 1086) 
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (362,1086,1)
END

--  [RulesTranField_ex] === DebitPurpose 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'DebitPurpose' and TranID = 362)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (362,Null,'Teller','DebitPurpose',-1,-1,-1,1,0,0)
END 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = '_lblTLR_TranPurpose' and TranID = 362)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (362,Null,'Teller','_lblTLR_TranPurpose',-1,-1,-1,1,0,0)
END 





--  [RulesTranDescriptors] === TLR_TRANSACTION_PURPOSE 
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 362 and DSC_Name = 'TLR_TRANSACTION_PURPOSE') 
BEGIN
   INSERT INTO RulesTranDescriptors (TranID,DSC_Name) values (362,'TLR_TRANSACTION_PURPOSE')
END


--------------------------------------- Account Closure =>  360 //
-----------------------------------------------------------//
--  [RulesTranField] === TLR_DEST_BANK_DETAIL 
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 360 and FieldID = 1322) 
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (360,1322,1)
END

--  [RulesTranField] === TLR_ID_TYPE 
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 360 and FieldID = 387)
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (360,387,1)
END

--  [RulesTranField_ex] === DebitPurpose 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'DebitPurpose' and TranID = 360)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (360,Null,'Teller','DebitPurpose',-1,-1,-1,1,0,0)
END 
 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = '_lblTLR_TranPurpose' and TranID = 360)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (360,Null,'Teller','_lblTLR_TranPurpose',-1,-1,-1,1,0,0)
END 




--  [RulesTranDescriptors] === TLR_TRANSACTION_PURPOSE 
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 360 and DSC_Name = 'TLR_TRANSACTION_PURPOSE') 
BEGIN
   INSERT INTO RulesTranDescriptors (TranID,DSC_Name) values (360,'TLR_TRANSACTION_PURPOSE')
END








-------------------------------------------
-- SQLString
-------------------------------------------
IF Not  EXISTS (select * from SQLstrings where AccessID =1100081)
Begin
insert into SQLstrings (AppID,AccessID ,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values ( 1,1100081 ,'TLR_GET_PURPOSE_DESCRIPTION','P',1,'Globalfs','dbo.Get_PurposeDescription',0,'ITSOFT\shaimaa.nasser','ITSOFT\shaimaa.nasser','jul 27 2020  1:00PM','Get Purpose Code and Purpose Description for all cashcredit,cashdebit and cashtransfer transactions',1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000','Apr 19 2020  4:00PM','','',0,0,1,0,0,0,0,0)
End
GO

--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/07/2020]		
--Reason	:	Enh GFSY00804 - BARWA - ACM000000018599 General Enhancement
--=========================================================================

PRINT 'Start. Script for CR# GFSY00804 DML Script'
GO
 
--------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal --
--------------------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105646)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105646,'TLR_POSTTRANSACTION',0,'Labels','Post Transaction','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105646 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105646,1025,N'����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105647)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105647,'TLR_CANCELTRANSACTION',0,'Labels','Cancel Transaction','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105647 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105647,1025,N'����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105648)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105648,'TLR_CANNOTPOSTREASON',0,'Labels','You cannot post the transaction while selecting reason, You must select the main request','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105648 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105648,1025,N'�� ����� ����� �������� ����� ����� ����� � ��� ���� ����� ����� �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105649)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105649,'TLR_POSTINGCONFIRMATION',0,'Labels','Are you sure you want to post the transaction','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105649 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105649,1025,N'�� ��� ����� �� ��� ���� ��� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105650)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105650,'TLR_OVERRIDEPOSTEDBYSUPERVISOR',0,'Labels','Override Posted By Supervisor','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105650 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105650,1025,N'����� ����� ������ ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105651)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105651,'TLR_CANNOTCANCELREASON',0,'Labels','You cannot cancel the transaction while selecting reason, You must select the main request','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105651 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105651,1025,N'�� ����� ����� �������� ����� ����� ����� � ��� ���� ����� ����� �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105652)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105652,'TLR_CANCELINGCONFIRMATION',0,'Labels','Are you sure you want to cancel the transaction','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105652 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105652,1025,N'�� ��� ����� �� ��� ���� ����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105653)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105653,'TLR_OVERRIDECANCELBYSUPERVISOR',0,'Labels','Override Cancelled By Supervisor','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105653 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105653,1025,N'�� ����� ������� ������ ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105654)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105654,'TLR_OV_Status_CancelTran',0,'Labels','Transaction Cancelled','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105654 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105654,1025,N'�� ����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105655)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105655,'TLR_CannotPostTransaction',0,'Labels','Cannot post the transaction , there are some other reason waiting supervisor approval','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105655 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105655,1025,N'�� ���� ����� �������� � ����� ��� ��� ����� ������ ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO


------------
-- Status --
------------
If Not Exists(Select * From Status Where StatusTypeID = 28 And id = 15)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (28,15,'OverridePostedBySupervisor','Supervisor post the trarnsaction by himself','TLR_OVERRIDEPOSTEDBYSUPERVISOR','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 28 And id = 16)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (28,16,'OverrideCancelledBySupervisor','Supervisor cancel the trarnsaction by himself','TLR_OVERRIDECANCELBYSUPERVISOR','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed')
End
GO

----------------------------------
-- RulesParam & RulesParamValue --
----------------------------------
DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'UseNewResendMode')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'UseNewResendMode','Flag used to determine if use old resend behaviour or new one',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
		
		IF NOT EXISTS(Select * From RulesParamValue Where ParamID = @paramID And ParamValue = 'True')
			BEGIN
				INSERT INTO RulesParamValue(ParamID,ParamValue,UPdator)
				VALUES (@paramID,N'True',N'ITSOFT\ahmed.orashed')
			END
		IF NOT EXISTS(SELECT * FROM RulesParamValue WHERE ParamID = @paramID And ParamValue = 'False')
			BEGIN 
				INSERT INTO RulesParamValue(ParamID,ParamValue,UPdator)
				VALUES (@paramID,N'False',N'ITSOFT\ahmed.orashed')
			END
END
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLStrings Where AccessID = 1100074)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100074,'Select_ResendControlsEvents','p',1,'Globalfs','dbo.Select_ResendControlsEvents',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','SELECT data FROM ResendControlsEvents table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100075)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100075,'Select_ResendAutoFillFields','p',1,'Globalfs','dbo.Select_ResendAutoFillFields',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','SELECT data FROM ResendControlsEvents table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100077)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100077,'SelectTranConfig','p',1,'Globalfs','dbo.SelectTranConfig',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select Tran Config',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100078)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100078,'SelectTellerConfig','p',1,'Globalfs','dbo.SelectTellerConfig',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select Teller Config',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100079)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100079,'SelectOverrideRequestReasons','p',1,'Globalfs','dbo.SelectOverrideRequestReasons',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select Override Request Reasons',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

--------------------------
-- ResendControlsEvents --
--------------------------
If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'OpenPersonalRim' AND ControlName = 'cur_TurnOverAmount' AND EventName = 'cur_TurnOverAmount_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('OpenPersonalRim',N'cur_TurnOverAmount',N'cur_TurnOverAmount_Validated',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'OpenPersonalRim' AND ControlName = 'txt_IntroByRimNo' AND EventName = 'txt_IntroByRimNo_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('OpenPersonalRim',N'txt_IntroByRimNo',N'txt_IntroByRimNo_Validated',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'EditPersonalRim' AND ControlName = 'cur_TurnOverAmount' AND EventName = 'cur_TurnOverAmount_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('EditPersonalRim',N'cur_TurnOverAmount',N'cur_TurnOverAmount_Validated',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'EditPersonalRim' AND ControlName = 'txt_IntroByRimNo' AND EventName = 'txt_IntroByRimNo_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('EditPersonalRim',N'txt_IntroByRimNo',N'txt_IntroByRimNo_Validated',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'AddNewSO' AND ControlName = '_curAmount' AND EventName = '_curAmount_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('AddNewSO',N'_curAmount',N'_curAmount_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'ModifyExistingSO' AND ControlName = '_txtTLR_RIM_NO' AND EventName = '_txtTLR_RIM_NO_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('ModifyExistingSO',N'_txtTLR_RIM_NO',N'_txtTLR_RIM_NO_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'ModifyExistingSO' AND ControlName = '_curAmount' AND EventName = '_curAmount_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('ModifyExistingSO',N'_curAmount',N'_curAmount_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstAccount' AND ControlName = '_curAmount' AND EventName = '_curAmount_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstAccount',N'_curAmount',N'_curAmount_Validated',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstGL' AND ControlName = '_curAmount' AND EventName = '_curAmount_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstGL',N'_curAmount',N'_curAmount_Validated',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstAccount' AND ControlName = '_curAmount' AND EventName = '_curAmount_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstAccount',N'_curAmount',N'_curAmount_Validated',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstGL' AND ControlName = '_curAmount' AND EventName = '_curAmount_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstGL',N'_curAmount',N'_curAmount_Validated',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstGL' AND ControlName = '_optIssueOptions' AND EventName = 'HandleInternalTransferModeInResendMode')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstGL',N'_optIssueOptions',N'HandleInternalTransferModeInResendMode',N'Method',N'2')
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueLatchAgainstAccount' AND ControlName = '_curAmount' AND EventName = '_curAmount_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueLatchAgainstAccount',N'_curAmount',N'_curAmount_Validated',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueLatchAgainstGL' AND ControlName = '_curAmount' AND EventName = '_curAmount_Validated')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueLatchAgainstGL',N'_curAmount',N'_curAmount_Validated',N'Event',NULL)
End
GO

PRINT 'End... Script for CR# GFSY00804 DML Script'
GO
--==================================================================================================================================================================
Print 'Script for Defect GFSX14215 Starts ...'
----------------------------------- RulesTranDescriptors Begin ------------------------------------------------------------------------------------------------

If Not Exists(Select * From RulesTranDescriptors Where TranID = 842 And DSC_Name = 'TLR_ACCOUNT_CURR_NOT_VALID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (842,'TLR_ACCOUNT_CURR_NOT_VALID','Sep 03 2020  1:32PM',N'ITSOFT\sara.badwy',N'ITSOFT\sara.badwy','Sep 03 2020  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 841 And DSC_Name = 'TLR_ACCOUNT_CURR_NOT_VALID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (841,'TLR_ACCOUNT_CURR_NOT_VALID','Sep 03 2020  1:32PM',N'ITSOFT\sara.badwy',N'ITSOFT\sara.badwy','Sep 03 2020  1:32PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
----------------------------------- RulesTranDescriptors End ------------------------------------------------------------------------------------------------
Print 'Script for Defect GFSX14215 Completed.'
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105802)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105802,N'TLR_DATA_WILL_NEGLECTED',0,N'Labels',N'The currently loaded data will be neglected.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105802 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105802,1025,N'.���� ����� �������� ������� �����')
END
GO

IF NOT EXISTS (SELECT * FROM RulesDescriptor WHERE NAME = 'lbl_OtherPurpose' AND DescriptorID = 1105788)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name           , forVB , TypeName  , Descriptor      , Creator              , Updator )  
	values                      ( 1    , 1105788      , 'lbl_OtherPurpose' , 0     , 'Labels'  , 'Other Purpose' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

IF NOT EXISTS (SELECT * FROM RulesDescriptor WHERE NAME = 'lbl_DocumentsReceived' AND DescriptorID = 1105789)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name                , forVB , TypeName  , Descriptor      , Creator              , Updator )  
	values                      ( 1    , 1105789      , 'lbl_DocumentsReceived' , 0     , 'Labels'  , 'Documents Received' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************
If Not Exists(Select * From RulesTranDescriptors Where TranID = 160 And DSC_Name = 'lbl_OtherPurpose')
Begin
 Insert Into RulesTranDescriptors(TranID,    DSC_Name          ,LastChanged                 ,Updator                   , Creator                ,  Created               , RowStatus , EffectiveDate         ,ExpirationDate)
                           Values(  160 ,   'lbl_OtherPurpose'     , 'August  26 2020  10:44PM',  N'ITSOFT\ahmed.eliwa' , N'ITSOFT\ahmed.eliwa', 'August  26 2020  10:44PM', 1         ,'Jan  1 1901 12:00AM'  ,'Dec 31 9998 12:00AM')
End
Go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 160 And DSC_Name = 'lbl_DocumentsReceived')
Begin
 Insert Into RulesTranDescriptors(TranID,    DSC_Name               ,LastChanged                 ,Updator                   , Creator                ,  Created               , RowStatus , EffectiveDate         ,ExpirationDate)
                           Values(  160 ,   'lbl_DocumentsReceived'     , 'August  26 2020  10:44PM',  N'ITSOFT\ahmed.eliwa' , N'ITSOFT\ahmed.eliwa', 'August  26 2020  10:44PM', 1         ,'Jan  1 1901 12:00AM'  ,'Dec 31 9998 12:00AM')
End
Go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 160 And DSC_Name = 'TLR_OTHER')
Begin
 Insert Into RulesTranDescriptors(TranID,    DSC_Name               ,LastChanged                 ,Updator                   , Creator                ,  Created               , RowStatus , EffectiveDate         ,ExpirationDate)
                           Values(  160 ,   'TLR_OTHER'     , 'August  26 2020  10:44PM',  N'ITSOFT\ahmed.eliwa' , N'ITSOFT\ahmed.eliwa', 'August  26 2020  10:44PM', 1         ,'Jan  1 1901 12:00AM'  ,'Dec 31 9998 12:00AM')
End
Go

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

If Not Exists(Select * From RulesTranField_ex Where TranID = 160 AND FieldIDInPage = '_txtOtherTransactionPurpose')
Begin
 Insert Into RulesTranField_ex(TranID ,FieldID ,Module   ,FieldIDInPage                 ,FirstPage ,LastPage ,ControlPage ,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged          ,Updator                ,IsVisible)
 Values                       (160    ,NULL    ,'Teller' ,'_txtOtherTransactionPurpose' ,-1        ,-1       ,-1          ,1       ,1         ,'lbl_OtherPurpose' ,''          ,''      ,'jun  3 2020  2:18PM',N'ITSOFT\ahmed.eliwa'  , 1       )
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 160 AND FieldIDInPage = 'cbo_DocumentsReceived')
Begin
 Insert Into RulesTranField_ex(TranID ,FieldID ,Module   ,FieldIDInPage                 ,FirstPage ,LastPage ,ControlPage ,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged          ,Updator                ,IsVisible)
 Values                       (160    ,NULL    ,'Teller' ,'cbo_DocumentsReceived'       ,-1        ,-1       ,-1          ,1       ,0         ,'lbl_DocumentsReceived' ,''          ,''      ,'jun  3 2020  2:18PM',N'ITSOFT\ahmed.eliwa'  , 0       )
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 160 AND FieldIDInPage = '_lblOtherTransactionPurpose')
Begin
 Insert Into RulesTranField_ex(TranID ,FieldID ,Module   ,FieldIDInPage                 ,FirstPage ,LastPage ,ControlPage ,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged          ,Updator                ,IsVisible)
 Values                       (160    ,NULL    ,'Teller' ,'_lblOtherTransactionPurpose' ,-1        ,-1       ,-1          ,1       ,1         ,'lbl_OtherPurpose' ,''          ,''      ,'jun  3 2020  2:18PM',N'ITSOFT\ahmed.eliwa'  , 1       )
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 160 AND FieldIDInPage = '_lblDocumentsReceived')
Begin
 Insert Into RulesTranField_ex(TranID ,FieldID ,Module   ,FieldIDInPage                 ,FirstPage ,LastPage ,ControlPage ,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged          ,Updator                ,IsVisible)
 Values                       (160    ,NULL    ,'Teller' ,'_lblDocumentsReceived' ,-1        ,-1       ,-1          ,1       ,0         ,'lbl_DocumentsReceived' ,''          ,''      ,'jun  3 2020  2:18PM',N'ITSOFT\ahmed.eliwa'  , 0       )
End
go

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

If Not Exists(Select * From RulesTranField Where TranID = 160 And FieldID = 395)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged             ,isDupable ,MaxArray ,Notes  ,Created                   ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (160,     395     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa'  ,'August 27 2020 12:59PM' ,1         ,NULL     ,''     ,'August 27 2020 12:59PM' ,N'ITSOFT\ahmed.eliwa'    ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,'OtherTransactionPurpose',1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 160 And FieldID = 264)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged             ,isDupable ,MaxArray ,Notes  ,Created                   ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (160,     264     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa'  ,'August 27 2020 12:59PM' ,1         ,NULL     ,''     ,'August 27 2020 12:59PM' ,N'ITSOFT\ahmed.eliwa'    ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,'DocumentsReceived',1,-1)
End
go


--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

Declare @max_display_order int
select @max_display_order = IsNull(Max(DisplayOrder + 1),1) from PickList_Entries where PickListID = 508
If Not Exists(Select * From PickList_Entries Where PickListID = 508 And Value = 'other')
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder       ,DescriptorName,Value   ,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values                      (508       ,1    ,@max_display_order ,'TLR_OTHER'  ,'other' ,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','August 27 2020  2:41PM','August 27 2020  2:41PM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa',1,NULL)
End
go

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

If Not Exists(Select * From PickLists Where PickListID =563)
Begin
INSERT INTO PickLists(AppID, PickListID, PickList_Name)
VALUES     (1,563,'DocumentsReceived')
End
go

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105788 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105788,1025,N'��� ���','ITSOFT\ahmed.eliwa','August 12 2010  12:20PM',N'ITSOFT\ahmed.eliwa')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105789 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105789,1025,N'��������� ��������','ITSOFT\ahmed.eliwa','August 12 2010  12:20PM',N'ITSOFT\ahmed.eliwa')
End
go
----------------------------------------
--------RulesDescriptorLocal -----------
----------------------------------------

----------------- TLR_Uncertified-------
if(not EXISTS (select * from RulesDescriptorLocal where DescriptorID = '1104083' and LCID = '1025'  ) )
begin 
				insert into RulesDescriptorLocal (DescriptorID,LCID,LocalDescription)
						Values('1104083','1025',N'��� ����')
end
----------------- TLR_Certified-------
if(not EXISTS (select * from RulesDescriptorLocal where DescriptorID = '1104082' and LCID = '1025'  ) )
begin 
				insert into RulesDescriptorLocal (DescriptorID,LCID,LocalDescription)
						Values('1104082','1025',N'����')
end
Go

-- =============================================
-- Author:		Aya Tarek and Shaimaa AbdelNasser and Ahmed Almgharby
-- Create date: 28/8/2020
-- Description:	SKB_GFSY000812 DML 
-- =============================================
--------------------------------
--------------------------------
--RulesParam-----------
--------------------------------
If Not Exists(Select * From RulesParam Where ParamName='SetupForTransferPurpose')
Begin
    DECLARE @paramID1 int
    SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
    Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
    Values (@paramID1,'SetupForTransferPurpose','The Transfer Purpose pick list will be loaded from the new setup table','',0,1,0,'','Static','')
End
--------------------------------
--------------------------------
--RulesTranField-----------
--------------------------------

--------transaction purpose-------
--- PurposeDescription FixedDepositBreak [TLR_PHYS_VERIF_DSCR]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 245 AND  FieldID   =  1125   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 245  ,   1125   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode FixedDepositBreak [TLR_ID_TYPE]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 245 AND  FieldID   =  387   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 245  ,   387   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--------transfer purpose-------
--- PurposeDescription FixedDepositBreak [TLR_DEST_BANK_DETAIL]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 245 AND  FieldID   =  1322   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 245  ,   1322   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode FixedDepositBreak [IDNumber]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 245 AND  FieldID   =  -269869   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 245  ,   -269869   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go


--- PurposeDescription AddNewSO [TLR_PHYS_VERIF_DSCR]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 257 AND  FieldID   =  1125   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 257  ,   1125   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode AddNewSO [TLR_DESCRIPTION]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 257 AND  FieldID   =  1154   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 257  ,   1154   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeDescription IssueTT [TLR_DEST_BANK_DETAIL]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 262 AND  FieldID   =  1322   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 262  ,   1322   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode IssueTT [TLR_DESCRIPTION]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 262 AND  FieldID   =  1154   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 262  ,   1154   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeDescription IssueTTAgainstAccount [TLR_DEST_BANK_DETAIL]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 277 AND  FieldID   =  1322   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 277  ,   1322   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--- PurposeCode IssueTTAgainstAccount [TLR_ID_TYPE1_3]
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 277 AND  FieldID   =  1086   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 277  ,   1086   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

--------------------------------------------------
----------------RulesTranField--------------------
--------------------------------------------------
------ TLR_DEST_BANK_DETAIL 
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 278 and FieldID = 1322) 
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (278,1322,1)
END

------ TLR_CURRENT_OWNER
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 278 and FieldID = 435) 
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (278,435,1)
END

------ TLR_ID_TYPE1_3
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 278 and FieldID = 1086) 
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (278,1086,1)
END
------ TLR_ID_TYPE2_3
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 278 and FieldID = 1087) 
BEGIN
   INSERT INTO RulesTranField (TranID,FieldID,Optional) values (278,1087,1)
END

--insert Tran Fields For Transaction Purpose

IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID=160 and FieldID=1370)
BEGIN
  insert into RulesTranField (TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,
  EffectiveDate,  ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
  values 
  ('160','1370',1,0,0,NULL,'ITSOFT\Ahmed.Almaghraby',GETDATE(),1,null,'',GETDATE(),'ITSOFT\Ahmed.Almaghraby',1,'1901-01-01 00:00:00.000',
	'9999-12-31 00:00:00.000',0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
END
GO

 --insert Tran Fields For Transfer Purpose

 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 160  AND  FieldID   =  436   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 160   ,   436   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go


 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 160  AND  FieldID   =  1304   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 160   ,   1304   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

 --insert Tran Fields
 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 211  AND  FieldID   =  1370   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 211   ,   1370   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go


 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 211  AND  FieldID   =  1125   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 211   ,   1125   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
------------------------------
 --insert Tran Fields For Transfer Purpose

 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 211  AND  FieldID   =  436   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 211   ,   436   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go


 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 211  AND  FieldID   =  1304   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 211   ,   1304   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

 --insert Tran Fields DepositPurpose
 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 173  AND  FieldID   =  1370   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 173   ,   1370   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go


 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 173  AND  FieldID   =  1125   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 173   ,   1125   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
-------------------------
 --insert Tran Fields For Transfer Purpose

 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 173  AND  FieldID   =  436   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 173   ,   436   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go


 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 173  AND  FieldID   =  1304   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 173   ,   1304   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
---------------------------
--insert Tran Fields
 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 280  AND  FieldID   =  1370   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 280   ,   1370   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go


 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 280  AND  FieldID   =  1125   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 280   ,   1125   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go

 --insert Tran Fields For Transfer Purpose

 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 280  AND  FieldID   =  436   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 280   ,   436   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go


 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 280  AND  FieldID   =  1304   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 280   ,   1304   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\Ahmed.Almaghraby' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
Go
---------------------------

--------------------------------
--RulesTranField_ex-----------
--------------------------------
-- PurposeDescription FixedDepositBreak
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 245  AND  FieldIDInPage   = 'DebitPurpose'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 245  ,  1125  ,  'Teller'  ,  'DebitPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label FixedDepositBreak
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 245  AND  FieldIDInPage   = '_lblTLR_TranPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 245   ,    NULL    ,  'Teller'  ,  '_lblTLR_TranPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO

-- PurposeDescription FixedDepositBreak
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 245  AND FieldIDInPage   = 'TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 245  ,  1322  ,  'Teller'  ,  'TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_TRANSFER_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label FixedDepositBreak
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 245 AND   FieldIDInPage   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 245   ,    NULL    ,  'Teller'  ,  'TLR_TRANSFER_PURPOSE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO


-- PurposeDescription AddNewSO
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 257  AND  FieldIDInPage   = 'TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 257  ,  1125  ,  'Teller'  ,  'TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label AddNewSO
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 257 AND   FieldIDInPage   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 257   ,    NULL    ,  'Teller'  ,  'TLR_TRANSFER_PURPOSE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO


-- PurposeDescription IssueTT
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 262 AND  FieldIDInPage   = 'TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 262  ,  1322  ,  'Teller'  ,  'TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   0,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- PurposeDescription label IssueTT
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 262 AND   FieldIDInPage   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 262   ,    NULL    ,  'Teller'  ,  'TLR_TRANSFER_PURPOSE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   0,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO


------------------------------------------------
--------- RulesTranField_ex---------------------
------------------------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = 'CreditPurpose' and TranID = 278)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (278,Null,'Teller','CreditPurpose',-1,-1,-1,1,0,0)
END 

--  [RulesTranField_ex] === _lblTLR_TranPurpose 
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE FieldIDInPage = '_lblTLR_TranPurpose' and TranID = 278)
BEGIN
		INSERT INTO RulesTranField_ex (TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,IsVisible)
		VALUES   (278,Null,'Teller','_lblTLR_TranPurpose',-1,-1,-1,1,0,0)
END 

 --insert Tran Fields_ex For Transfer Purpose

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 160   AND FieldIDInPage   = 'transferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 160   ,  436  ,  'Teller'  ,  'transferPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  'TLR_TRANSFER_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 160  AND FieldIDInPage   = '_lblTLR_TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 160   ,  NULL  ,  'Teller'  ,  '_lblTLR_TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  ''  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

 --insert Tran Fields_ex

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 211  AND FieldIDInPage   = 'DepositPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 211   ,  1125  ,  'Teller'  ,  'DepositPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 211  AND FieldIDInPage   = '_lblTLR_TranPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 211   ,  NULL  ,  'Teller'  ,  '_lblTLR_TranPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  ''  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-----------------
 --insert Tran Fields_ex For Transfer Purpose

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 211  AND FieldIDInPage   = 'transferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 211   ,  436  ,  'Teller'  ,  'transferPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  'TLR_TRANSFER_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 211  AND FieldIDInPage   = '_lblTLR_TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 211   ,  NULL  ,  'Teller'  ,  '_lblTLR_TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  ''  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

 --insert Tran Fields_ex DepositPurpose

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 173  AND FieldIDInPage   = 'DepositPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 173   ,  1125  ,  'Teller'  ,  'DepositPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 173  AND FieldIDInPage   = '_lblTLR_TranPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 173   ,  NULL  ,  'Teller'  ,  '_lblTLR_TranPurpose'  ,   -1   ,   -1   ,   -1   ,   1  ,   0  ,  ''  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-----------------
 --insert Tran Fields_ex For Transfer Purpose

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 173  AND FieldIDInPage   = 'transferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 173   ,  436  ,  'Teller'  ,  'transferPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_TRANSFER_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 173  AND FieldIDInPage   = '_lblTLR_TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 173   ,  NULL  ,  'Teller'  ,  '_lblTLR_TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  ''  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO
 --insert Tran Fields_ex

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 280 AND FieldIDInPage   = 'DepositPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 280   ,  1125  ,  'Teller'  ,  'DepositPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_TRANSACTION_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 280  AND FieldIDInPage   = '_lblTLR_TranPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 280   ,  NULL  ,  'Teller'  ,  '_lblTLR_TranPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  ''  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-----------------
 --insert Tran Fields_ex For Transfer Purpose

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 280   AND FieldIDInPage = 'transferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 280   ,  436  ,  'Teller'  ,  'transferPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_TRANSFER_PURPOSE'  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0 ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 280  AND FieldIDInPage   = '_lblTLR_TransferPurpose'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 280   ,  NULL  ,  'Teller'  ,  '_lblTLR_TransferPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  ''  ,    NULL    ,    NULL    ,  'ITSOFT\Ahmed.Almaghraby'  ,   0  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


--------------------------------
--RulesTranFldParam-----------
--------------------------------
-- PurposeDescription IssueTTAgnistAccount

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'IssueTTAgainstAccount'  AND FieldName = '_cbo_TLR_PURPOSE_OF_TRANS' AND Param = 'SetupForTransferPurpose' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
   Values( 'IssueTTAgainstAccount' , '_cbo_TLR_PURPOSE_OF_TRANS' , 'SetupForTransferPurpose' , 0 ,'ITSOFT\aya.tarek' , 'nvarchar')
 END 
GO

--------------------------------
--RulesTranFldParam-----------
--------------------------------

IF NOT EXISTS ( Select * From RulesTranFldParam Where  TranName= 'IssueTTAgainstCash'  AND FieldName = '_cbo_TLR_PURPOSE_OF_TRANS' AND Param = 'SetupForTransferPurpose' ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,DataType,Description)
   Values( 'IssueTTAgainstCash' , '_cbo_TLR_PURPOSE_OF_TRANS' , 'SetupForTransferPurpose' , 0 , 'nvarchar','The Transfer Purpose pick list will be loaded from the new setup table')
 END 
GO
 --Insert Rulestranfield Param
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'CashDeposit'  AND FieldName = 'DepositPurpose' AND Param = 'NewSetupForTranPurpose' )
BEGIN
 INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType,Description)
   Values( 'CashDeposit' , 'DepositPurpose' , 'NewSetupForTranPurpose' , 0,'ITSOFT\Ahmed.Almaghraby' , 'nvarchar','This pick list will be loaded from the new setup table')
 END
GO

---------------------------------
-- RulesTranDescriptors ---------
---------------------------------

-- PurposeDescription FixedDepositBreak

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 245 AND  DSC_Name   = 'TLR_TRANSACTION_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 245   ,  'TLR_TRANSACTION_PURPOSE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 245 AND  DSC_Name   = 'TLR_TRANSFER_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 245   ,  'TLR_TRANSFER_PURPOSE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

-- PurposeDescription AddNewSO
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 257 AND  DSC_Name   = 'TLR_TRANSACTION_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 257   ,  'TLR_TRANSACTION_PURPOSE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

-- PurposeDescription IssueTT
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 262 AND  DSC_Name   = 'TLR_TRANSACTION_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 262   ,  'TLR_TRANSACTION_PURPOSE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO
---------------------------------------------------
-------------- RulesTranDescriptors----------------
---------------------------------------------------

IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID = 278 and DSC_Name = 'TLR_TRANSACTION_PURPOSE') 
BEGIN
   INSERT INTO RulesTranDescriptors (TranID,DSC_Name) values (278,'TLR_TRANSACTION_PURPOSE')
END

--insert Descriptor 
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 160  AND  DSC_Name  =  'TLR_TRANSFER_PURPOSE' ) 

 begin 
 insert into RulesTranDescriptors (TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate) values 
    (160,'TLR_TRANSFER_PURPOSE',GETDATE(),'ITSOFT\Ahmed.Almaghraby','ITSOFT\Ahmed.Almaghraby',getdate(),1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000')

 end

 --insert descriptiors

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 211  AND  DSC_Name   =  'TLR_TRANSACTION_PURPOSE' ) 

 begin 
 insert into RulesTranDescriptors (TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate) values 
    (211,'TLR_TRANSACTION_PURPOSE',GETDATE(),'ITSOFT\Ahmed.Almaghraby','ITSOFT\Ahmed.Almaghraby',getdate(),1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000')

 end
 
  IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 211  AND  DSC_Name  =  'TLR_TRANSFER_PURPOSE' ) 

 begin 
 insert into RulesTranDescriptors (TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate) values 
    (211,'TLR_TRANSFER_PURPOSE',GETDATE(),'ITSOFT\Ahmed.Almaghraby','ITSOFT\Ahmed.Almaghraby',getdate(),1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000')

 end

 --insert descriptiors 

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 173  AND  DSC_Name   =  'TLR_TRANSACTION_PURPOSE' ) 

 begin 
 insert into RulesTranDescriptors (TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate) values 
    (173,'TLR_TRANSACTION_PURPOSE',GETDATE(),'ITSOFT\Ahmed.Almaghraby','ITSOFT\Ahmed.Almaghraby',getdate(),1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000')

 end
 --
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 173  AND  DSC_Name  =  'TLR_TRANSFER_PURPOSE' ) 

 begin 
 insert into RulesTranDescriptors (TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate) values 
    (173,'TLR_TRANSFER_PURPOSE',GETDATE(),'ITSOFT\Ahmed.Almaghraby','ITSOFT\Ahmed.Almaghraby',getdate(),1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000')

 end

 --insert descriptiors

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 280  AND  DSC_Name   =  'TLR_TRANSACTION_PURPOSE' ) 

 begin 
 insert into RulesTranDescriptors (TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate) values 
    (280,'TLR_TRANSACTION_PURPOSE',GETDATE(),'ITSOFT\Ahmed.Almaghraby','ITSOFT\Ahmed.Almaghraby',getdate(),1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000')

 end
 
   IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 280  AND  DSC_Name  =  'TLR_TRANSFER_PURPOSE' ) 

 begin 
 insert into RulesTranDescriptors (TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate) values 
    (280,'TLR_TRANSFER_PURPOSE',GETDATE(),'ITSOFT\Ahmed.Almaghraby','ITSOFT\Ahmed.Almaghraby',getdate(),1,'1901-01-01 00:00:00.000','9998-12-31 00:00:00.000')

 end


GO


-- ISSUE GFSX14060
-- Ahmed Almaghraby
--  13-09-2020 

USE Globalfs

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105810)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105810,'CardReader_NotAttached',0,'Labels','Card reader not Attached or No Card Inserted','ITSOFT\AHMED.ALMAGHRABY',1,N'ITSOFT\AHMED.ALMAGHRABY')
END 
GO

 

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105810 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105810,1025,N'���� ������� ��� ���� �� �� ��� ����� �����','ITSOFT\AHMED.ALMAGHRABY',N'ITSOFT\AHMED.ALMAGHRABY')
End
GO
--Programmer : Mostafa Sayed
--Date       : [09/07/2020]
--Reason     : INC000000282143
--===========================================================================
--ExternalWebService
IF NOT EXISTS (SELECT * FROM ExternalWebService WHERE WebServiceName='CreditCardMultiplePayment_Search')
BEGIN
	INSERT INTO ExternalWebService(WebServiceName,Description,WebServiceIP,MachineName,URL,UserName,Password,ApplyWSE,WebServiceMapName,Servicetype)
	Values('CreditCardMultiplePayment_Search', 'Credit Card Multiple Payment Service for Search','10.100.0.120','10.100.0.120','http://localhost:62508/api/Transactions/','username','password',0,'CreditCardMultiplePayment_Search','REST')
END
GO
--ExternalWebServiceTran
IF EXISTS(SELECT * FROM ExternalWebServiceTran WHERE TranID=858 AND WebServiceName='CreditCardMultiplePayment' AND Methods='ONLINE_CARD_DETAILS' AND MethodsMapName='SearchByCard')
BEGIN
	UPDATE ExternalWebServiceTran
	SET WebServiceName='CreditCardMultiplePayment_Search'
	WHERE TranID=858 AND WebServiceName='CreditCardMultiplePayment' AND Methods='ONLINE_CARD_DETAILS' AND MethodsMapName='SearchByCard'
END
GO
IF EXISTS(SELECT * FROM ExternalWebServiceTran WHERE TranID=858 AND WebServiceName='CreditCardMultiplePayment' AND Methods='ONLINE_CLIENT_DETAILS' AND MethodsMapName='SearchByClientCode')
BEGIN
	UPDATE ExternalWebServiceTran
	SET WebServiceName='CreditCardMultiplePayment_Search'
	WHERE TranID=858 AND WebServiceName='CreditCardMultiplePayment' AND Methods='ONLINE_CLIENT_DETAILS' AND MethodsMapName='SearchByClientCode'
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1883)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1883,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'ClientCode',0,-1)
END
GO

DECLARE @tranID INT
SELECT @tranID=ID FROM ExternalWebServiceTran WHERE WebServiceName='CreditCardMultiplePayment_Search' AND MethodsMapName='SearchByCard'
IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@tranID AND ParamName='CLIENT_ID')
BEGIN
	insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
	values(@tranID,null,@tranID,'CLIENT_ID','string',9,'DUMY_ClientID',0,null)
END
GO
--  Sara Badwy  08-09-2020
--Defect #GFSX14225 INC000000287151 : AJF-BRANCH-POS Madatory Fields Issue
GO
IF  EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807   AND  FieldIDInPage   = '_Card_Number') 
BEGIN 
update  RulesTranField_ex set FieldIDInPage= '__Card_Number' Where  TranID   = 807   AND  FieldIDInPage   = '_Card_Number'  
END 
GO
IF  EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807   AND  FieldIDInPage   = '_Card_Number2') 
BEGIN 
update  RulesTranField_ex set FieldIDInPage= '__Card_Number2' Where  TranID   = 807   AND  FieldIDInPage   = '_Card_Number2'  
END 
GO
--Devolper	:	Ahmed Osman
--Date		:	[12/02/2020]		
--Reason	:	Issue# GFSX13947 - BDL - UAT - Rim No in edit rim journal
--==============================================================================

If Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1418)
Begin
 UPDATE RulesTranField SET FieldAlias = NULL WHERE TranID = 564 AND FieldID = 1418
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1442)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (564,1442,1,0,0,NULL,'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'RimNumber',0,-1,NULL,NULL,NULL)

End
GO

/* Ahmed Almaghraby [22-07-2020] GFSX14102  */ 

USE GLOBALFS

/*BuyFCYAgainstCash*/
 IF NOT EXISTS (select * from RulesTranFldParam where PARAM = 'CoreCustIDCode' AND TranName ='BuyFCYAgainstCash')


   BEGIN
           insert into RulesTranFldParam (TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description) VALUES

			 ('BuyFCYAgainstCash','_cboTLR_ID_NAME','CoreCustIDCode',0,'ITSOFT\ahmed.almaghraby','nvarchar',getdate(),NULL )
END

GO 
/*SellFCYAgainstCash*/
 IF NOT EXISTS (select * from RulesTranFldParam where PARAM = 'CoreCustIDCode' AND TranName ='SellFCYAgainstCash')


   BEGIN
           insert into RulesTranFldParam (TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description) VALUES

			 ('SellFCYAgainstCash','_cboTLR_ID_NAME','CoreCustIDCode',0,'ITSOFT\ahmed.almaghraby','nvarchar',getdate(),NULL )
END

GO 
/*cashexchange*/
 IF NOT EXISTS (select * from RulesTranFldParam where PARAM = 'CoreCustIDCode' AND TranName ='cashexchange')


   BEGIN
           insert into RulesTranFldParam (TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)  VALUES

			 ('cashexchange','_cboTLR_ID_NAME','CoreCustIDCode',0,'ITSOFT\ahmed.almaghraby','nvarchar',getdate(),NULL )
END

  update RulesTranFldParam set Value = (select TOP 1 value from bankconfig WHERE NAME ='ID1INDEX' order by bank  desc  ) 
    where  PARAM = 'CoreCustIDCode' AND TranName in ('BuyFCYAgainstCash','SellFCYAgainstCash','cashexchange')

GO 

--==================================================================================================================================================================
--Devolper	:	Mostafa Helmy
--Date		:	[27/07/2020]		
--Reason	:	Enh GFSY00806 BARWA_ACM18595_Inward Transfers_Part1

--=====================================================================

PRINT 'Start. Script for CR# GFSY00806 DML Script'
GO

--------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal --
--------------------------------------------

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105658)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105658,'TLR_CREATED_DATE_TIME',0,'Labels','Created Date Time','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105658 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105658,1025,N'����� ���� �������','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105660)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105660,'TLR_TotalNumOfMessages',0,'Labels','Total # Of Messages','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105660 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105660,1025,N'������ ��� �������','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO


IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105661)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105661,'TLR_TotalMessagesAmount',0,'Labels','Total Messages Amount','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105661 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105661,1025,N'������ ���� �������','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105663)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105663,'TLR_ApprovedMessgs',0,'Labels','Approved Messages','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105663 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105663,1025,N'������� ��������','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105664)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105664,'TLR_PostedMessgs',0,'Labels','Posted Messages','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105664 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105664,1025,N'������� ��������','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO



IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105667)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105667,'TLR_MsgRjectionReasons',0,'Labels','Rejection Reason','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105667 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105667,1025,N'��� �����','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105668)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105668,'TLR_MsgRjection',0,'Labels','Are you sure you want to reverse the Transfer ?','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105668 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105668,1025,N'�� ��� ����� �� ��� ���� ��� ����� ������� � ','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105669)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105669,'TLR_MsgNotApproved',0,'Labels','The Message number: {0} could not be approved , please check the exception reason','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105669 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105669,1025,N'������� ��� : {0} �� ���� �������� ����� ����� ������ ��� ���������','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105676)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105676,'TLR_BtnReverse',0,'Labels','Reverse','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105676 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105676,1025,N'���','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105792)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105792,'LATCH_StartPostingTime_SD',0,'Labels','LATCH Start Posting Time','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105792 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105792,1025,N'��� ��� ������ ������','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105793)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105793,'Latch_StartPostingTime_LD',0,'Labels','Specify Start Time for posting messages of LATCH Service','ITSOFT\mostafa.helmy',1,N'ITSOFT\mostafa.helmy')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105793 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105793,1025,N'������ �� ����� ��� ��� ������ ������ ������','ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy')
End
GO




-------------------------------------------------------------------
----------------------------RulesTranDescriptors-------------------
------------------------------------------------------------------- 

If Not Exists(Select * From RulesTranDescriptors Where TranID = 772 And DSC_Name = 'TLR_CREATED_DATE_TIME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (772,'TLR_CREATED_DATE_TIME','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 773 And DSC_Name = 'TLR_CREATED_DATE_TIME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (773,'TLR_CREATED_DATE_TIME','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 772 And DSC_Name = 'TLR_MsgRjectionReasons')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (772,'TLR_MsgRjectionReasons','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 773 And DSC_Name = 'TLR_MsgRjectionReasons')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (773,'TLR_MsgRjectionReasons','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 772 And DSC_Name = 'TLR_TotalNumOfMessages')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (772,'TLR_TotalNumOfMessages','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 773 And DSC_Name = 'TLR_TotalNumOfMessages')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (773,'TLR_TotalNumOfMessages','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 772 And DSC_Name = 'TLR_TotalMessagesAmount')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (772,'TLR_TotalMessagesAmount','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 773 And DSC_Name = 'TLR_TotalMessagesAmount')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (773,'TLR_TotalMessagesAmount','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 772 And DSC_Name = 'TLR_PostedMessgs')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (772,'TLR_PostedMessgs','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 773 And DSC_Name = 'TLR_PostedMessgs')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (773,'TLR_PostedMessgs','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 772 And DSC_Name = 'TLR_ApprovedMessgs')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (772,'TLR_ApprovedMessgs','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 773 And DSC_Name = 'TLR_ApprovedMessgs')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (773,'TLR_ApprovedMessgs','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 772 And DSC_Name = 'TLR_ApprovedMessgs')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (772,'TLR_ApprovedMessgs','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 773 And DSC_Name = 'TLR_ApprovedMessgs')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (773,'TLR_ApprovedMessgs','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesTranDescriptors Where TranID = 773 And DSC_Name = 'TLR_MsgNotApproved')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (773,'TLR_MsgNotApproved','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesTranDescriptors Where TranID = 772 And DSC_Name = 'TLR_BtnReverse')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (772,'TLR_BtnReverse','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

--------------------------------------------
-- RulesParam & RulesTranFldParam-----------
--------------------------------------------

If Not Exists(Select * From RulesParam Where  ParamName='NotApproved_ExceptionReasons')
Begin
	DECLARE @ParamID INT
	SELECT @ParamID = MAX(ParamID) +1 FROM RulesParam
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@ParamID,'NotApproved_ExceptionReasons','define the codes of exception reasons that will prevent message to be approved',NULL,0,0,0,'','Static','','Aug 01 2020  3:22PM',N'ITSOFT\mostafa.helmy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)

End
go
	
If Not Exists(Select * From RulesTranFldParam Where TranName = 'ExceptionMessageQueue' And FieldName = 'ExceptionReasons' And Param = 'NotApproved_ExceptionReasons')
Begin
	Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	Values ('ExceptionMessageQueue','ExceptionReasons','NotApproved_ExceptionReasons','',N'ITSOFT\mostafa.helmy','nvarchar','Aug 01 2020 9:22AM',NULL)
End
go

If Not Exists(Select * From RulesTranFldParam Where TranName = 'ApprovedMessageQueue' And FieldName = 'Transaction' And Param = 'ExpressionName')
Begin
	Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	Values ('ApprovedMessageQueue','Transaction','ExpressionName','MSGReference',N'ITSOFT\mostafa.helmy','nvarchar','Aug 01 2020 9:22AM',NULL)
End
go

-------------------------------------------------------------------------------------------
------------------------------------RulesTranField--------------------------------------
-------------------------------------------------------------------------------------------


If Not Exists(Select * From RulesTranField Where TranID = 772 And FieldID = 1695) --TLR_PDC_DEST_INSTRUCTIONS
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (772,1695,1,0,0,NULL,'ITSOFT\mostafa.helmy',1,NULL,'',N'ITSOFT\mostafa.helmy',1,0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 772 And FieldID = 1715) --TLR_PDC_TYPR_STATUS_DESC
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (772,1715,1,0,0,NULL,'ITSOFT\mostafa.helmy',1,NULL,'',N'ITSOFT\mostafa.helmy',1,0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 773 And FieldID = 1715) --TLR_PDC_TYPR_STATUS_DESC
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (773,1715,1,0,0,NULL,'ITSOFT\mostafa.helmy',1,NULL,'',N'ITSOFT\mostafa.helmy',1,0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
End
GO


If Not Exists(Select * From RulesTranField Where TranID = 775 And FieldID = 1715) --TLR_PDC_TYPR_STATUS_DESC
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (775,1715,1,0,0,NULL,'ITSOFT\mostafa.helmy',1,NULL,'',N'ITSOFT\mostafa.helmy',1,0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
End
GO

-------------------------------------------------------------------------------------------
------------------------------------RulesTranField_ex--------------------------------------
-------------------------------------------------------------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 772 And FieldIDInPage = 'lbl_TotalNumMessages')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (772,'','Teller','lbl_TotalNumMessages',-1,-1,-1,1,1,'TLR_TotalNumOfMessages',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 773 And FieldIDInPage = 'lbl_TotalNumMessages')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (773,'','Teller','lbl_TotalNumMessages',-1,-1,-1,1,1,'TLR_TotalNumOfMessages',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 772 And FieldIDInPage = 'lbl_ToatlMessagesAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (772,'','Teller','lbl_ToatlMessagesAmount',-1,-1,-1,1,1,'TLR_TotalMessagesAmount',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 773 And FieldIDInPage = 'lbl_ToatlMessagesAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (773,'','Teller','lbl_ToatlMessagesAmount',-1,-1,-1,1,1,'TLR_TotalMessagesAmount',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 772 And FieldIDInPage = 'txt_TotalAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (772,'','Teller','txt_TotalAmount',-1,-1,-1,1,1,'TLR_TotalMessagesAmount',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 773 And FieldIDInPage = 'txt_TotalAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (773,'','Teller','txt_TotalAmount',-1,-1,-1,1,1,'TLR_TotalMessagesAmount',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 772 And FieldIDInPage = 'txt_NumOfMessages')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (772,'','Teller','txt_NumOfMessages',-1,-1,-1,1,1,'TLR_TotalNumOfMessages',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 773 And FieldIDInPage = 'txt_NumOfMessages')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (773,'','Teller','txt_NumOfMessages',-1,-1,-1,1,1,'TLR_TotalNumOfMessages',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 772 And FieldIDInPage = 'opt_MessageType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (772,'','Teller','opt_MessageType',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 773 And FieldIDInPage = 'cbo_RejectionReason')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (773,'','Teller','cbo_RejectionReason',-1,-1,-1,1,1,'TLR_MsgRjectionReasons',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 772 And FieldIDInPage = 'cbo_RejectionReason')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (772,'','Teller','cbo_RejectionReason',-1,-1,-1,1,1,'TLR_MsgRjectionReasons',NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go
-------------------------------------------------------------------------------------------
------------------------------------BANKCONFIG---------------------------------------------
-------------------------------------------------------------------------------------------
If Not Exists(Select * From BANKCONFIG Where Bank = 1056 And Name = 'Latch_StartPostingTime')
Begin
 Insert Into BANKCONFIG(Bank,Name,Value,DataType,ShortDescription,LongDescription,MaxValue,MinValue,ErrDescriptor,PickListName,PickListAccessName,GroupID,Updator,LastChanged,MinFieldLength,MaxFieldLength,LoadingMandatory)
 Values (1056,'Latch_StartPostingTime',N'0800','time','LATCH_StartPostingTime_SD','Latch_StartPostingTime_LD','255','0','TLR_INVALID_DATA','','',NULL,N'ITSOFT\mostafa.helmy','May 21 2013 10:32AM',0,255,0)
End
go

PRINT 'End... Script for CR# GFSY00806 DML Script'
GO
----------------------------------------
--------RulesDescriptorLocal -----------
----------------------------------------

----------------- Certification-------
if(not EXISTS (select * from RulesDescriptorLocal where DescriptorID = '1105640' and LCID = '1025'  ) )
begin 
				insert into RulesDescriptorLocal (DescriptorID,LCID,LocalDescription)
						Values('1105640','1025',N'������ ')
end
GO
--Programmer : Mostafa Sayed
--Date       : [22/09/2020]
--Reason     : Issue#GFSX14257 - INC000000286634 ...
----------------------------------------------------
IF NOT EXISTS(SELECT * FROM ReaderDeviceClasses WHERE Name = 'ExcellaSTX001')
BEGIN
	INSERT INTO ReaderDeviceClasses(Name,Assembly,ClassName,CommPort,BaudRate,Parity,DataBits,StopBits,OtherProperties,Description)
	VALUES ('ExcellaSTX001','ExcellaSTXUSBMicrController','ExcellaSTXUSBMicr.ExcellaSTXUSB','5','9600','N',8,1,N'6',N'Excella MICR in USB mode')
END
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[01/08/2020]		
--Reason	:	Enh GFSY00807 - BARWA - ACM18595 Inward Transfers
--===============================================================
PRINT 'Start. Script for CR# GFSY00807 DML Script'
GO

---------------------
-- RulesDescriptor --
---------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105678)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105678,'InwardTransfersHOSwiftProcess',0,'Labels','Inward Transfers HO Swift Process','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105678 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105678,1025,N'������ ����� ������� HO Swift','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105679)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105679,'TLR_ApprovedQueue',0,'Labels','Approved Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105679 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105679,1025,N'����� �������� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105680)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105680,'TLR_ExceptionQueue',0,'Labels','Exception Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105680 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105680,1025,N'����� ������ �����������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105681)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105681,'TLR_PostedQueue',0,'Labels','Posted Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105681 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105681,1025,N'�� ����� �� ����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105682)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105682,'TLR_FilePathAndName',0,'Labels','File Path\Name','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105682 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105682,1025,N'���� ����� \ �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105683)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105683,'TLR_Messages',0,'Labels','The Messages','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105683 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105683,1025,N'�������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105684)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105684,'TLR_MoveToApprovedQueue',0,'Labels','Move To Approved Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105684 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105684,1025,N'�������� ��� ����� �������� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105685)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105685,'TLR_MoveToExceptionQueue',0,'Labels','Move To Exception Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105685 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105685,1025,N'�������� ��� ����� ������ �����������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105686)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105686,'TLR_QueueType',0,'Labels','Queue Type','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105686 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105686,1025,N'��� ����� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105687)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105687,'TLR_OriginalSwiftMessage',0,'Labels','Original Swift Message','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105687 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105687,1025,N'����� Swift �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105688)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105688,'TLR_IR_AccountOfficerID',0,'Labels','AccountOfficerID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105688 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105688,1025,N'���� ����� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105688)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105688,'TLR_IR_AccountOfficerID',0,'Labels','AccountOfficerID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105688 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105688,1025,N'���� ����� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105689)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105689,'TLR_IR_PaymentMethodID',0,'Labels','PaymentMethodID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105689 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105689,1025,N'���� ����� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105690)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105690,'TLR_IR_DrAccountNo_AcctType',0,'Labels','DrAccountNo_AcctType','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105690 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105690,1025,N'DrAccountNo_AcctType','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105691)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105691,'TLR_IR_DrAccountNo_ApplType',0,'Labels','DrAccountNo_ApplType','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105691 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105691,1025,N'DrAccountNo_ApplType','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105692)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105692,'TLR_IR_CrAccountNo_AcctType',0,'Labels','CrAccountNo_AcctType','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105692 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105692,1025,N'CrAccountNo_AcctType','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105693)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105693,'TLR_IR_CrAccountNo_ApplType',0,'Labels','CrAccountNo_ApplType','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105693 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105693,1025,N'CrAccountNo_ApplType','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105694)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105694,'TLR_IR_CrAccountNo_DepLoan',0,'Labels','CrAccountNo_DepLoan','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105694 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105694,1025,N'CrAccountNo_DepLoan','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105695)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105695,'TLR_IR_MT103Generated',0,'Labels','MT103Generated','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105695 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105695,1025,N'�� ����� MT103','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105696)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105696,'TLR_IR_MT202Generated',0,'Labels','MT202Generated','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105696 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105696,1025,N'�� ����� MT202','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105697)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105697,'TLR_IR_Account_With_Ref',0,'Labels','Account_With_Ref','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105697 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105697,1025,N'Account_With_Ref','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105698)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105698,'TLR_IR_Account_With_Ac',0,'Labels','Account_With_Ac','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105698 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105698,1025,N'Account_With_Ac','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105699)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105699,'TLR_IR_Account_With_Name',0,'Labels','Account_With_Name','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105699 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105699,1025,N'Account_With_Name','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105700)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105700,'TLR_IR_ValueCurrency',0,'Labels','ValueCurrency','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105700 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105700,1025,N'���� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105701)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105701,'TLR_IR_Order_Cust_Name',0,'Labels','Order_Cust_Name','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105701 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105701,1025,N'Order_Cust_Name','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105702)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105702,'TLR_IR_Order_Cust_Add1',0,'Labels','Order_Cust_Add1','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105702 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105702,1025,N'Order_Cust_Add1','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105703)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105703,'TLR_IR_Order_Cust_Add2',0,'Labels','Order_Cust_Add2','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105703 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105703,1025,N'Order_Cust_Add2','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105704)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105704,'TLR_IR_Order_Inst2',0,'Labels','Order_Inst','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105704 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105704,1025,N'Order_Inst','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105705)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105705,'TLR_IR_Order_Inst_Name',0,'Labels','Order_Inst_Name','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105705 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105705,1025,N'Order_Inst_Name','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105706)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105706,'TLR_IR_Order_Inst_Add1',0,'Labels','Order_Inst_Add1','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105706 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105706,1025,N'Order_Inst_Add1','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105707)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105707,'TLR_IR_BeneficiaryAccount',0,'Labels','BeneficiaryAccount','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105707 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105707,1025,N'���� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105708)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105708,'TLR_IR_FLD_70',0,'Labels','FLD_70','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105708 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105708,1025,N'FLD_70','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105709)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105709,'TLR_IR_FLD_71A',0,'Labels','FLD_71A','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105709 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105709,1025,N'FLD_71A','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105710)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105710,'TLR_IR_DrValueDate',0,'Labels','DrValueDate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105710 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105710,1025,N'DrValueDate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105711)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105711,'TLR_IR_CrValueDate',0,'Labels','CrValueDate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105711 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105711,1025,N'CrValueDate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105712)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105712,'TLR_IR_CrNarrative',0,'Labels','CrNarrative','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105712 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105712,1025,N'CrNarrative','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105713)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105713,'TLR_IR_DrNarrative',0,'Labels','DrNarrative','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105713 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105713,1025,N'DrNarrative','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105714)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105714,'TLR_IR_FLD_20',0,'Labels','FLD_20','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105714 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105714,1025,N'FLD_20','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105715)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105715,'TLR_IR_FLD_23',0,'Labels','FLD_23','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105715 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105715,1025,N'FLD_23','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105716)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105716,'TLR_IR_FLD_33',0,'Labels','FLD_33','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105716 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105716,1025,N'FLD_33','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105717)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105717,'TLR_IR_FLD_52',0,'Labels','FLD_52','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105717 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105717,1025,N'FLD_52','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105718)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105718,'TLR_IR_FLD_53',0,'Labels','FLD_53','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105718 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105718,1025,N'FLD_53','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105719)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105719,'TLR_IR_Is_FLD_20_Duplicate',0,'Labels','Is_FLD_20_Duplicate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105719 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105719,1025,N'Is_FLD_20_Duplicate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105720)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105720,'TLR_IR_ExceptionList',0,'Labels','ExceptionList','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105720 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105720,1025,N'����� �����������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105721)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105721,'TLR_IR_OldStatusID',0,'Labels','OldStatusID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105721 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105721,1025,N'����� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105722)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105722,'TLR_IR_OldDrAccountNo',0,'Labels','OldDrAccountNo','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105722 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105722,1025,N'OldDrAccountNo','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105723)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105723,'TLR_IR_OldDrAccountNo_AcctType',0,'Labels','OldDrAccountNo_AcctType','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105723 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105723,1025,N'OldDrAccountNo_AcctType','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105724)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105724,'TLR_IR_OldDrAccountNo_ApplType',0,'Labels','OldDrAccountNo_ApplType','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105724 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105724,1025,N'OldDrAccountNo_ApplType','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105725)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105725,'TLR_IR_OldDrAccountNo_DepLoan',0,'Labels','OldDrAccountNo_DepLoan','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105725 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105725,1025,N'OldDrAccountNo_DepLoan','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105726)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105726,'TLR_IR_OldDrAccountName',0,'Labels','OldDrAccountName','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105726 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105726,1025,N'OldDrAccountName','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105727)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105727,'TLR_IR_OldDrCurrency',0,'Labels','OldDrCurrency','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105727 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105727,1025,N'OldDrCurrency','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105728)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105728,'TLR_IR_OldDrAmount',0,'Labels','OldDrAmount','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105728 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105728,1025,N'OldDrAmount','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105729)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105729,'TLR_IR_OldDrExchangeRate',0,'Labels','OldDrExchangeRate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105729 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105729,1025,N'OldDrExchangeRate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105730)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105730,'TLR_IR_OldDrCommission',0,'Labels','OldDrCommission','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105730 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105730,1025,N'OldDrCommission','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105731)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105731,'TLR_IR_OldCrAccountNo',0,'Labels','OldCrAccountNo','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105731 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105731,1025,N'OldCrAccountNo','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105732)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105732,'TLR_IR_OldCrAccountNo_AcctType',0,'Labels','OldCrAccountNo_AcctType','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105732 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105732,1025,N'OldCrAccountNo_AcctType','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105733)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105733,'TLR_IR_OldCrAccountNo_ApplType',0,'Labels','OldCrAccountNo_ApplType','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105733 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105733,1025,N'OldCrAccountNo_ApplType','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105734)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105734,'TLR_IR_OldCrAccountNo_DepLoan',0,'Labels','OldCrAccountNo_DepLoan','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105734 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105734,1025,N'OldCrAccountNo_DepLoan','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105735)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105735,'TLR_IR_OldCrAccountName',0,'Labels','OldCrAccountName','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105735 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105735,1025,N'OldCrAccountName','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105736)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105736,'TLR_IR_OldCrCurrency',0,'Labels','OldCrCurrency','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105736 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105736,1025,N'OldCrCurrency','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105737)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105737,'TLR_IR_OldCrAmount',0,'Labels','OldCrAmount','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105737 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105737,1025,N'OldCrAmount','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105738)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105738,'TLR_IR_OldCrExchangeRate',0,'Labels','OldCrExchangeRate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105738 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105738,1025,N'OldCrExchangeRate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105739)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105739,'TLR_IR_OldCrCommission',0,'Labels','OldCrCommission','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105739 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105739,1025,N'OldCrCommission','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105740)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105740,'TLR_IR_OldDrValueDate',0,'Labels','OldDrValueDate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105740 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105740,1025,N'OldDrValueDate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105741)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105741,'TLR_IR_OldCrValueDate',0,'Labels','OldCrValueDate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105741 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105741,1025,N'OldCrValueDate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105742)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105742,'TLR_IR_DrRealExchangeRate',0,'Labels','DrRealExchangeRate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105742 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105742,1025,N'DrRealExchangeRate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105743)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105743,'TLR_IR_CrRealExchangeRate',0,'Labels','CrRealExchangeRate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105743 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105743,1025,N'CrRealExchangeRate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105744)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105744,'TLR_IR_TTAmount',0,'Labels','TTAmount','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105744 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105744,1025,N'TTAmount','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105745)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105745,'TLR_IR_TTCurrency',0,'Labels','TTCurrency','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105745 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105745,1025,N'TTCurrency','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105746)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105746,'TLR_IR_DrSellExchangeRate',0,'Labels','DrSellExchangeRate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105746 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105746,1025,N'DrSellExchangeRate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105747)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105747,'TLR_IR_CrBuyExchangeRate',0,'Labels','CrBuyExchangeRate','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105747 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105747,1025,N'CrBuyExchangeRate','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105748)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105748,'TLR_IR_IBAN',0,'Labels','IBAN','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105748 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105748,1025,N'IBAN','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105749)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105749,'TLR_IR_HostRefNo',0,'Labels','HostRefNo','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105749 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105749,1025,N'HostRefNo','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105750)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105750,'TLR_IR_Sender_BIC',0,'Labels','Sender_BIC','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105750 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105750,1025,N'������ BIC','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105751)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105751,'TLR_IR_Ben_Inst_BIC',0,'Labels','Ben_Inst_BIC','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105751 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105751,1025,N'Ben_Inst_BIC','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105752)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105752,'TLR_IR_FLD_72',0,'Labels','FLD_72','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105752 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105752,1025,N'FLD_72','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105754)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105754,'TLR_IR_CrRimNo',0,'Labels','CrRimNo','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105754 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105754,1025,N'CrRimNo','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105755)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105755,'TLR_IR_Ordering_IBAN',0,'Labels','Ordering_IBAN','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105755 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105755,1025,N'Ordering_IBAN','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105756)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105756,'TLR_IR_Ben_Inst_Name',0,'Labels','Ben_Inst_Name','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105756 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105756,1025,N'Ben_Inst_Name','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105757)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105757,'TLR_IR_Ben_Inst_AddLn1',0,'Labels','Ben_Inst_AddLn1','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105757 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105757,1025,N'Ben_Inst_AddLn1','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105758)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105758,'TLR_IR_Ben_Inst_AddLn2',0,'Labels','Ben_Inst_AddLn2','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105758 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105758,1025,N'Ben_Inst_AddLn2','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105759)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105759,'TLR_IR_Ben_Inst_AddLn3',0,'Labels','Ben_Inst_AddLn3','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105759 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105759,1025,N'Ben_Inst_AddLn3','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105760)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105760,'TLR_IR_FLD_111',0,'Labels','FLD_111','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105760 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105760,1025,N'FLD_111','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105761)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105761,'TLR_IR_FLD_121',0,'Labels','FLD_121','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105761 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105761,1025,N'FLD_121','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105762)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105762,'TLR_IR_StatusID',0,'Labels','StatusID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105762 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105762,1025,N'���� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105763)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105763,'TLR_IR_ActionID',0,'Labels','ActionID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105763 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105763,1025,N'���� �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105764)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105764,'TLR_IR_SendToID',0,'Labels','SendToID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105764 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105764,1025,N'SendToID','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105765)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105765,'TLR_IR_Updated',0,'Labels','Updated','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105765 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105765,1025,N'����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105766)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105766,'TLR_IR_SelectedSendToID',0,'Labels','SelectedSendToID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105766 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105766,1025,N'SelectedSendToID','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105767)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105767,'TLR_IR_SelectedActionID',0,'Labels','SelectedActionID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105767 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105767,1025,N'SelectedActionID','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105769)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105769,'TLR_IR_SelectedAccntOfficerID',0,'Labels','SelectedAccountOfficerID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105769 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105769,1025,N'SelectedAccountOfficerID','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105770)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105770,'TLR_IR_OldCrNarrative',0,'Labels','OldCrNarrative','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105770 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105770,1025,N'OldCrNarrative','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105771)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105771,'TLR_IR_OldDrNarrative',0,'Labels','OldDrNarrative','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105771 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105771,1025,N'OldDrNarrative','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105772)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105772,'TLR_IR_CrExchangeGain',0,'Labels','CrExchangeGain','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105772 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105772,1025,N'CrExchangeGain','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105773)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105773,'TLR_IR_DrExchangeGain',0,'Labels','DrExchangeGain','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105773 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105773,1025,N'DrExchangeGain','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105753)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105753,'TLR_IR_SelectQueueOption',0,'Labels','Please select Queue type first ...','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105753 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105753,1025,N'������ ����� ��� ����� �������� ����� ...','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105774)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105774,'TLR_IR_LoadMessgesAgain',0,'Labels','There are messages loaded ,And all changes will be unsaved','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105774 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105774,1025,N'�� ����� ����� � ��� ��� ��� ���� ���������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105776)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105776,'TLR_IR_CannotPostMSG',0,'Labels','You need to repair message with ref no "{0}" before post it','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105776 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105776,1025,N'����� ��� ����� ������� �� ������ "{0}" ��� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105777)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105777,'TLR_IR_SelectMsgToPost',0,'Labels','Please select the checkbox on the messages you want to post','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105777 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105777,1025,N'������ ����� ���� �������� �� ������� ���� ���� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105778)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105778,'TLR_IR_SelectMsgToReverse',0,'Labels','Please select the checkbox on the messages you want to reverse','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105778 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105778,1025,N'������ ����� ���� �������� �� ������� ���� ���� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105779)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105779,'TLR_IR_MoveMsgToApproved',0,'Labels','Please select message record to move to Approved Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105779 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105779,1025,N'������ ����� ��� ������� �������� ��� ����� �������� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105819)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105819,'TLR_IR_SelectMSGToReject',0,'Labels','Please select message record to reject it','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105819 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105819,1025,N'������ ����� ��� ������� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105780)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105780,'TLR_IR_CannotMoveMsgToApproved',0,'Labels','Cannot move this message to Approved Queue because this message will be post','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105780 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105780,1025,N'�� ���� ��� ��� ������� ��� ����� �������� �������� ��� ��� ������� ���� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105820)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105820,'TLR_IR_CannotRejectMSG',0,'Labels','Cannot reject this message because this message will be post','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105820 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105820,1025,N'�� ���� ��� ��� ������� ��� ��� ������� ���� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105822)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105822,'TLR_IR_RejectApprovedMSG',0,'Labels','Cannot reject this message because this message will be move to Approved Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105822 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105822,1025,N'�� ���� ��� ��� ������� ���� ���� ��� ��� ������� ��� ����� �������� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105781)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105781,'TLR_IR_ApprovedMsgHasExeption',0,'Labels','You need to repair this message before move it to Approved Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105781 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105781,1025,N'����� ��� ����� ��� ������� ��� ����� ��� ����� �������� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105825)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105825,'TLR_IR_ApprovedMsgWillReject',0,'Labels','You cannot move this message to Approved Queue because this message has will be rejected','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105825 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105825,1025,N'�� ����� ��� ��� ������� ��� ����� ������ �������� ���� ���� ��� ��� �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105821)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105821,'TLR_IR_RejectMsgHasExeption',0,'Labels','You cannot reject this message because this message has special exeption','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105821 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105821,1025,N'�� ����� ��� ��� ������� ��� ��� ������� ��� ������� ���','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105782)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105782,'TLR_IR_ReturnToExceptionQueue',0,'Labels','Return To Exception Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105782 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105782,1025,N'������ ��� ����� ������ �����������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105823)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105823,'TLR_IR_UndoReject',0,'Labels','Undo Reject','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105823 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105823,1025,N'������� �� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105783)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105783,'TLR_IR_ReturnToApprovedQueue',0,'Labels','Return To Approved Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105783 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105783,1025,N'������ ��� ����� �������� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105784)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105784,'TLR_IR_MoveMsgToException',0,'Labels','Please select message record to move to Exception Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105784 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105784,1025,N'������ ����� ��� ������� �������� ��� ����� ������ �����������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105785)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105785,'TLR_IR_CanntMoveMsgToException',0,'Labels','Cannot move this message to Exception Queue because this message will be post','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105785 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105785,1025,N'�� ���� ��� ��� ������� ��� ����� ������ ����������� ��� ��� ������� ���� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105786)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105786,'TLR_IR_CannotPostMSGLocked',0,'Labels','You cannot post the message with ref no "{0}" because it is locked by another user','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105786 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105786,1025,N'�� ����� ��� ������� �� ������ "{0}" ���� ���� �� ��� ������ ���','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105787)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105787,'TLR_IR_CannotReverseMSGLocked',0,'Labels','You cannot reverse the message with ref no "{0}" because it is locked by another user','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105787 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105787,1025,N'�� ����� ��� ������� ��� ������ "{0}" ���� �� ����� �� ��� ������ ���','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105790)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105790,'TLR_IR_UpdateMSG',0,'Labels','Please select message record to update','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105790 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105790,1025,N'������ ����� ��� ������� �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105791)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105791,'TLR_IR_MSGDetails',0,'Labels','Please select message record to show its details','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105791 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105791,1025,N'������ ����� ��� ������� ������ ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105794)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105794,'TLR_NoDataToProcessed',0,'Labels','There no data to processed','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105794 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105794,1025,N'�� ���� ������ ���������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105795)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105795,'TLR_IR_MsgsPaid',0,'Labels','There are some message already paid','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105795 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105795,1025,N'���� ��� ������� �������� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105798)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105798,'TLR_RefreshGrid',0,'Labels','Refresh Grid','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105798 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105798,1025,N'����� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105799)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105799,'TLR_IR_RefreshGrid',0,'Labels','Are you want to load grid data again? {0} This action will discard your old changes...','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105799 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105799,1025,N'�� ���� ����� ������ ������ ��� ���� {0} ����� ��� ������� ��� ����� ��������� ������� ...','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105800)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105800,'TLR_IR_UpdateNewMSG',0,'Labels','You must check the new message with ref no {0} berfore post it','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105800 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105800,1025,N'��� ������ �� ������� ������� �� ������ ��� {0} ��� ����� "','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105803)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105803,'TLR_IR_NumberOfMSG',0,'Labels','# Of Messages','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1897)
 Begin
  Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
  Values (1,1897,'TLR_IR_ORDER_INST',0,'Labels','Ordering Institution','GFSDOMAIN\myoussif','Mar  4 2012 10:41AM',1,'Jan  1 1901 12:00AM','Dec 31 9999 12:00AM','Jun 12 2006 11:22AM',N'ITSOFT\halsum')
 End
 go


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105803 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105803,1025,N'# �� �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105804)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105804,'TLR_IR_ReverseReason',0,'Labels','Reverse Reason','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105804 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105804,1025,N'����� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105805)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105805,'TLR_IR_CantPostMSGWithQueue1',0,'Labels','You cannot post message with ref no "{0}" because its moved to Exception Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105805 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105805,1025,N'�� ����� ����� ����� ����� ��� ������ "{0}" ���� �� ����� ��� ����� ������ �����������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105806)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105806,'TLR_IR_CantPostMSGWithQueue2',0,'Labels','You cannot post message with ref no "{0}" because its moved to Approved Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105806 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105806,1025,N'�� ����� ��� ����� �� ������ "{0}" ���� �� ����� ��� ����� �������� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105824)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105824,'TLR_IR_CantPostMSGRejected',0,'Labels','You cannot post message with ref no "{0}" because it will be rejected','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105824 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105824,1025,N'�� ����� ����� ����� ������� ��� "{0}" ���� ���� ����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105807)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105807,'TLR_IR_ApprovedMsgManual',0,'Labels','You cant move this message to Approved Queue, you should first change its payment method from manual to other','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105807 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105807,1025,N'�� ����� ��� ��� ������� ��� ����� ������ �������� � ��� ���� ����� ����� ����� ����� ������ ��� �� ����� ��� ����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105808)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105808,'TLR_IR_ApprovedMsgNotAllowed',0,'Labels','You are not allowed to move this message to Approved Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105808 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105808,1025,N'��� ����� �� ���� ��� ������� ��� ����� �������� ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105809)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105809,'TLR_IR_ExceptionMsgNotAllowed',0,'Labels','You are not allowed to move this message to Exception Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105809 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105809,1025,N'��� ����� �� ���� ��� ������� ��� ����� ������ �����������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105811)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105811,'TLR_IR_ReverseReadPath',0,'Labels','Cannot detect Reverse Generation Read Path','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105811 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105811,1025,N'�� ���� ����� �� ���� ������� ������ �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105812)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105812,'TLR_IR_ReverseWritePath',0,'Labels','Cannot detect Reverse Generation Write Path','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105812 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105812,1025,N'�� ���� ����� �� ���� ����� ������� ������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105813)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105813,'TLR_IR_ReverseFileName',0,'Labels','Cannot detect Reverse File Name','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105813 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105813,1025,N'�� ���� ����� �� ��� ��� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105814)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105814,'TLR_IR_ClearChanges',0,'Labels','Clear Changes','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105814 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105814,1025,N'��� ���������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105815)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105815,'TLR_IR_OtherQueue',0,'Labels','Other Queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105815 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105815,1025,N'����� ������ ����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105816)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105816,'TLR_IR_MessageDateFrom',0,'Labels','Message Date (From)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105816 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105816,1025,N'����� ������� (��)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105817)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105817,'TLR_IR_MessageDateTo',0,'Labels','Message Date (To)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105817 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105817,1025,N'����� ������� (���)','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105818)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105818,'TLR_IR_Reject',0,'Labels','Reject','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105818 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105818,1025,N'���','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105826)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105826,'TLR_IR_BtnPostHint',0,'Labels','Check the messages checkbox to determined which messages will be posted','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105826 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105826,1025,N'��� ���� ������ ������� ������ ������� ���� ���� �������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105827)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105827,'TLR_IR_BtnReverseHint',0,'Labels','Check the messages checkbox to determined which messages will be reversed','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105827 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105827,1025,N'��� ���� ������ ������� ������ ������� ���� ���� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105828)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105828,'TLR_IR_BtnRejectHint',0,'Labels','Select the message record to can reject it','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105828 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105828,1025,N'��� ��� ������� ������ ����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105829)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105829,'TLR_IR_BtnMoveApproveHint',0,'Labels','Select the message record to can move it to approve queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105829 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105829,1025,N'��� ��� ������� ����� ��� ����� ������ ��������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105830)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105830,'TLR_IR_BtnMoveExceptionHint',0,'Labels','Select the message record to can move it to exception queue','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105830 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105830,1025,N'��� ��� ������� ����� ��� ����� ������ �����������','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

-------------------
-- RulesTranName --
-------------------
If Not Exists(Select * From RulesTranName Where TranID = 862)
Begin
 Insert Into RulesTranName(TransactionName,TranID,Description,Developer,DSC_Description,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,RowStatus,Updator,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,TotalsType,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
 Values ('InwardTransfersHOSwiftProcess',862,'Inward Transfers HO Swift Process',N'ITSOFT\ahmed.orashed',1105678,10,'Teller',101,1,'ROP',1,0,0,0,0,0,1,1,N'ITSOFT\ahmed.orashed',0,0,0,0,0,0,0,0,0,0,1,NULL,NULL,NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,1)
End
GO

-------------------------
-- RulesContainerTrans --
-------------------------
If Not Exists(Select * From RulesContainerTrans Where container_name = 'Teller' And TranName = 'InwardTransfersHOSwiftProcess')
Begin
 Insert Into RulesContainerTrans(container_name,TranName,Updator,RowStatus)
 Values ('Teller','InwardTransfersHOSwiftProcess',N'ITSOFT\ahmed.orashed',1)
End
GO

-----------------------
-- TransactionScopes --
-----------------------
If Not Exists(Select * From TransactionScopes Where Scope = 1001 And TranID = 862)
Begin
 Insert Into TransactionScopes(Scope,TranID,Developer,Updator,RowStatus)
 Values (1001,862,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

---------------
-- Component --
---------------
If Not Exists(Select * From Component Where ComponentID = 307)
Begin
 Insert Into Component(ComponentID,AppID,ComponentName,ComponentType,Description,ProjectDirectory,ProjectFile,ProjectType,ProjectTarget,ProductionGroup,isSourceShipped,TargetDirectory,TypeLibrary,TypeLibVersion,GUID,VersionInfoFile,FileVersion,ComponentSize,Developer,InstallDirectory,Updator,ProductionGroup2,InstallDirectory2,RowStatus,WiseProject,BuildChangesOnly,SymbolsFile,ProjectGUID)
 Values (307,1,N'InwardTransfersHOSwiftProcess','DLL','',N'Teller.Net\Source\BP\Custom\InwardTransfersHOSwiftProcess',N'InwardTransfersHOSwiftProcess.csproj','C#2010',N'Debug','Client_NonRegistered',0,N'..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\',NULL,NULL,NULL,NULL,'2.0.46.0',57344,N'ITSOFT\ahmed.orashed',N'shared.net\Source\bin\Common\Teller',N'ITSOFT\ahmed.orashed',NULL,NULL,1,N'GFSTellerdotNetClient.wsm',1,N'InwardTransfersHOSwiftProcess.pdb',NULL)
End
GO

---------------------
-- RulesTranConfig --
---------------------
If Not Exists(Select * From RulesTranConfig Where TranID = 862)
Begin
 Insert Into RulesTranConfig(TranID,DenomRequired,AccountingEntries,DrAccountCategoryID,CrAccountCategoryID,LimitCategoryID,FeesCategoryID,ExchangeType,OffLineAmount,AllowEmptyAccountingEntries,VerifySignatrue,ReadAllAccountingEntries,ShowInAdmin,Updator,OD_DrAccountCategoryID,PrintOption,ForcePositioning,EnableCharges,SalesMessageActive,FutureStaleChequeDays,BackDatedStaleChequeDays,ValidateStaleCheque,StaleChequeAction,StaleChequeDefaultDate,EscWarningEnabled,ChqRngVal,ChqRngAction,Blacklisted,BlacklistedAction,BenPmtStrict,BenPmtWarning,HasCheckList,CheckListCategoryID,ShowAvlBal,AutoPrintPassBook,TranCommissionGroupID,UseSimpleChargeControl,GLCategoryID,DaysAllowedForReversal,TranLimitID,ChequeType,CashFollowAcctCurr,useFX,CheckDrawerTypeRestrictions,use_XPath_app,SameRIMForCharge,SameCurrencyForCharge,PrimaryIDExpiryVal,PrimaryIDExpiryAction,Channel_Id,RecoveryReversal,Pack_ID,CustomerInquiry,TransOptPickListID,ReviewVouchersBeforePrinting,Charge_AcctCategoryID,UpdDateReqired,UpdDateValue,UpdDateAction,IsFinancialTran,ShortDescription,TranOptionFLD,CHK_IncludeAccumilative,CHK_AccumilativeInfoMessage,OpenSessionRequired,SupportResend,CheckBillPastDueDT,PastDueDTAction,UseExpressions,WorkOnNightlyModeAllowed,CheqTypeConfig,StaffsRelativeValidation,UseTCR,PostTranAsSupervisor,CancelTranAsSupervisor)
 Values (862,0,0,NULL,NULL,NULL,NULL,NULL,0.00,1,0,1,1,N'ITSOFT\ahmed.orashed',NULL,0,0,0,0,0,0,0,'Warning',0,0,1,'Warning',0,'',0,0,0,0,0,0,NULL,0,NULL,0,NULL,NULL,0,0,0,0,0,0,0,N'Warning',NULL,0,NULL,0,NULL,0,NULL,0,0,'0',0,'',NULL,0,0,1,0,0,'Warning',1,0,N'N',NULL,0,0,0)
End
GO

-------------------
---- Menu_Action --
-------------------
--If Not Exists(Select * From Menu_Action Where MenuActionID = 885)
--Begin
-- Insert Into Menu_Action(MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Image,Enabled,RowStatus,Updator,Creator)
-- Values (885,1,1105678,NULL,2,'InwardTransfersHOSwiftProcess',NULL,1,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
--End
--GO

---------------------
-- Menu_Definition --
---------------------
--If Not Exists(Select * From Menu_Definition Where MenuID = 2501 And MenuKey = '456')
--Begin
-- Insert Into Menu_Definition(MenuID,MenuKey,Parent,MenuActionID,RowStatus,Updator,Creator)
-- Values (2501,'456','45',885,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
--End
--GO

--If Not Exists(Select * From Menu_Definition Where MenuID = 2518 And MenuKey = '56')
--Begin
-- Insert Into Menu_Definition(MenuID,MenuKey,Parent,MenuActionID,RowStatus,Updator,Creator)
-- Values (2518,'56','5',885,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
--End
--GO

--------------------------
-- RulesTranDescriptors --
--------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_ApprovedQueue')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_ApprovedQueue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_ExceptionQueue')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_ExceptionQueue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_PostedQueue')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_PostedQueue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SwiftFile')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SwiftFile',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_FilePathAndName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_FilePathAndName',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ReadNewFile')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ReadNewFile',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'SEARCH_CRITERIA')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'SEARCH_CRITERIA',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FileRefNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FileRefNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_STATUS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_STATUS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_PAYMENT_METHOD')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_PAYMENT_METHOD',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_SO_CORRESPONDENT_BANK')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_SO_CORRESPONDENT_BANK',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MessageRefNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MessageRefNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DEBIT_CURRENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DEBIT_CURRENCY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CREDIT_CURRENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CREDIT_CURRENCY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'MSG_DATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'MSG_DATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OrderingCustomer')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OrderingCustomer',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_20')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_20',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DebitAmount')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DebitAmount',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CREDITAMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CREDITAMOUNT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SEARCH')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SEARCH',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_Messages')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_Messages',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_MSG_DETAILS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_MSG_DETAILS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'UPDATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'UPDATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_POST')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_POST',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_BtnReverse')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_BtnReverse',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_MoveToApprovedQueue')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_MoveToApprovedQueue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_MoveToExceptionQueue')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_MoveToExceptionQueue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_TotalNumOfMessages')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_TotalNumOfMessages',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_TotalMessagesAmount')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_TotalMessagesAmount',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_QueueType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_QueueType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_SELECTION')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_SELECTION',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MessageRefNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MessageRefNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_20')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_20',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_STATUS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_STATUS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DEBIT_AMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DEBIT_AMOUNT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'ValueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'ValueDate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SenderBank')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SenderBank',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FileRefNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FileRefNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FilePathAndName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FilePathAndName',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_PAYMENT_METHOD')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_PAYMENT_METHOD',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_ACTION')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_ACTION',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SendTo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SendTo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DateTimeStamp')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DateTimeStamp',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_PreparedBy')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_PreparedBy',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SpecialRateNeeded')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SpecialRateNeeded',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MessageValueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MessageValueDate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_VoucherOK')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_VoucherOK',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_AuthorizedBy')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_AuthorizedBy',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ApprovedBy')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ApprovedBy',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DebitAccountNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DebitAccountNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'DrAccountName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'DrAccountName',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DEBIT_CURRENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DEBIT_CURRENCY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DEBIT_AMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DEBIT_AMOUNT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'DebitAddress')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'DebitAddress',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DEBIT_EXCHANGE_RATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DEBIT_EXCHANGE_RATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'DebitCommision')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'DebitCommision',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CreditAccountNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CreditAccountNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'CrAccountName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'CrAccountName',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CREDIT_CURRENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CREDIT_CURRENCY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CREDITAMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CREDITAMOUNT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'CreditAddress')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'CreditAddress',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OrderingCustomer')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OrderingCustomer',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CREDIT_EXCHANGE_RATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CREDIT_EXCHANGE_RATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'CreditCommision')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'CreditCommision',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_GTD_TKT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_GTD_TKT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'OriginalMsg')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'OriginalMsg',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'FLD_50K')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'FLD_50K',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'FLD_59')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'FLD_59',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'ChargeDebit')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'ChargeDebit',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BeneficiaryAmount')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BeneficiaryAmount',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BeneficiaryCurrency')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BeneficiaryCurrency',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BeneficiarySellRate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BeneficiarySellRate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BeneficiaryBuyRate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BeneficiaryBuyRate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BeneficiaryGTDTicket')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BeneficiaryGTDTicket',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_SO_BENEFICIARY_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_SO_BENEFICIARY_NAME',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BeneficiaryIDType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BeneficiaryIDType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BeneficiaryIDNumber')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BeneficiaryIDNumber',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BeneficiaryPhone')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BeneficiaryPhone',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_BENEFICIARY_ADDRESS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_BENEFICIARY_ADDRESS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BeneficiaryNarrative')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BeneficiaryNarrative',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'Row_Version')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'Row_Version',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_LOCKED_BY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_LOCKED_BY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Updator')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Updator',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_LastChanged')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_LastChanged',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SENDTOBRANCH')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SENDTOBRANCH',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MSG_TYPE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MSG_TYPE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'DrAccountNo_DepLoan')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'DrAccountNo_DepLoan',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MessageDetails')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MessageDetails',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MessageRefNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MessageRefNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_STATUS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_STATUS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DateTimeStamp')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DateTimeStamp',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_PreparedBy')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_PreparedBy',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ORDER_INST')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ORDER_INST',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_20')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_20',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Order_Inst2')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Order_Inst2',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_PAYMENT_METHOD')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_PAYMENT_METHOD',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MessageValueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MessageValueDate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_33B')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_33B',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_PAYMENT_DETAILS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_PAYMENT_DETAILS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OrderingCustomer')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OrderingCustomer',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ORDER_CUST_ADDRESS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ORDER_CUST_ADDRESS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_71A')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_71A',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MSG_TYPE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MSG_TYPE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_EXCEPTION_LIST')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_EXCEPTION_LIST',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CHANGES')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CHANGES',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DebitDetails')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DebitDetails',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DP_GL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DP_GL',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_AccountNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_AccountNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CURRENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CURRENCY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_AccountName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_AccountName',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DEBIT_EXCHANGE_RATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DEBIT_EXCHANGE_RATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'SELL_RATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'SELL_RATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'ValueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'ValueDate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_ADDRESS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_ADDRESS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SenderBank')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SenderBank',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_AMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_AMOUNT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Commission')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Commission',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_NARRAIVE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_NARRAIVE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_GTD_TKT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_GTD_TKT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CREDIT_DETAILS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CREDIT_DETAILS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DP_GL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DP_GL',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_AccountNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_AccountNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CURRENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CURRENCY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_AccountName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_AccountName',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'BUY_RATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'BUY_RATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'SELL_RATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'SELL_RATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_AMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_AMOUNT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Commission')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Commission',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'ValueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'ValueDate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_SO_BENEFICIARY_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_SO_BENEFICIARY_NAME',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_NARRAIVE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_NARRAIVE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_GTD_TKT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_GTD_TKT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_OriginalSwiftMessage')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_OriginalSwiftMessage',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_AccountOfficerID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_AccountOfficerID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_PaymentMethodID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_PaymentMethodID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DrAccountNo_AcctType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DrAccountNo_AcctType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DrAccountNo_ApplType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DrAccountNo_ApplType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CrAccountNo_AcctType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CrAccountNo_AcctType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CrAccountNo_ApplType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CrAccountNo_ApplType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CrAccountNo_DepLoan')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CrAccountNo_DepLoan',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MT103Generated')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MT103Generated',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MT202Generated')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MT202Generated',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Account_With_Ref')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Account_With_Ref',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Account_With_Ac')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Account_With_Ac',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Account_With_Name')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Account_With_Name',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ValueCurrency')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ValueCurrency',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Order_Cust_Name')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Order_Cust_Name',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Order_Cust_Add1')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Order_Cust_Add1',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Order_Cust_Add2')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Order_Cust_Add2',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO


If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Order_Inst_Name')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Order_Inst_Name',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Order_Inst_Add1')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Order_Inst_Add1',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_BeneficiaryAccount')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_BeneficiaryAccount',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_70')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_70',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_71A')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_71A',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DrValueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DrValueDate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CrValueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CrValueDate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CrNarrative')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CrNarrative',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DrNarrative')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DrNarrative',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_20')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_20',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_23')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_23',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_33')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_33',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_52')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_52',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_53')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_53',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Is_FLD_20_Duplicate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Is_FLD_20_Duplicate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ExceptionList')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ExceptionList',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldStatusID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldStatusID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrAccountNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrAccountNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrAccountNo_ApplType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrAccountNo_ApplType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrAccountNo_DepLoan')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrAccountNo_DepLoan',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrAccountName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrAccountName',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrCurrency')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrCurrency',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrAmount')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrAmount',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrExchangeRate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrExchangeRate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrCommission')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrCommission',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrAccountNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrAccountNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrAccountNo_AcctType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrAccountNo_AcctType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrAccountNo_ApplType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrAccountNo_ApplType',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrAccountNo_DepLoan')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrAccountNo_DepLoan',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrAccountName')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrAccountName',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrCurrency')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrCurrency',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrExchangeRate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrExchangeRate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrCommission')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrCommission',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrValueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrValueDate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrValueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrValueDate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DrRealExchangeRate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DrRealExchangeRate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CrRealExchangeRate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CrRealExchangeRate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_TTAmount')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_TTAmount',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_TTCurrency')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_TTCurrency',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DrSellExchangeRate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DrSellExchangeRate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CrBuyExchangeRate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CrBuyExchangeRate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_IBAN')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_IBAN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_HostRefNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_HostRefNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Sender_BIC')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Sender_BIC',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Ben_Inst_BIC')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Ben_Inst_BIC',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_72')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_72',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CrRimNo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CrRimNo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Ordering_IBAN')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Ordering_IBAN',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Ben_Inst_Name')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Ben_Inst_Name',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Ben_Inst_AddLn1')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Ben_Inst_AddLn1',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Ben_Inst_AddLn2')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Ben_Inst_AddLn2',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Ben_Inst_AddLn3')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Ben_Inst_AddLn3',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_111')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_111',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_FLD_121')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_FLD_121',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_StatusID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_StatusID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ActionID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ActionID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_AccountOfficerID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_AccountOfficerID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SendToID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SendToID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Updated')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Updated',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SelectedSendToID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SelectedSendToID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SelectedActionID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SelectedActionID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SelectedAccntOfficerID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SelectedAccntOfficerID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrNarrative')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrNarrative',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldDrNarrative')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldDrNarrative',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CrExchangeGain')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CrExchangeGain',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DrExchangeGain')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DrExchangeGain',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OldCrNarrative')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OldCrNarrative',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_READ_FILE_STATUS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_READ_FILE_STATUS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_LoadMessgesAgain')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_LoadMessgesAgain',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ReturnToExceptionQueue')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ReturnToExceptionQueue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_UndoReject')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_UndoReject',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ReturnToApprovedQueue')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ReturnToApprovedQueue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CURRENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CURRENCY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DebitDetails')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DebitDetails',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_CREDIT_DETAILS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_CREDIT_DETAILS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_AMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_AMOUNT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_DP_GL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_DP_GL',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_GL_NUMBER')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_GL_NUMBER',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_SEARCH_MSG_REJ')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_SEARCH_MSG_REJ',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CannotPostMSGLocked')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CannotPostMSGLocked',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_CannotReverseMSGLocked')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_CannotReverseMSGLocked',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_ParamValue')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_ParamValue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ORG_MSG_VALUE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ORG_MSG_VALUE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_NEW_MSG_VALUE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_NEW_MSG_VALUE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DUP_REF')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DUP_REF',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_DUP_REF_SFT_MSG')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_DUP_REF_SFT_MSG',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_RefreshGrid')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_RefreshGrid',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_NumberOfMSG')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_NumberOfMSG',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ReverseReason')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ReverseReason',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'COR_REASON')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'COR_REASON',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_ClearChanges')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_ClearChanges',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_OtherQueue')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_OtherQueue',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MessageDateFrom')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MessageDateFrom',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_MessageDateTo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_MessageDateTo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_IR_Reject')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_IR_Reject',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 862 And DSC_Name = 'TLR_OTHERREASON')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (862,'TLR_OTHERREASON',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

-----------------------
-- RulesTranField_ex --
-----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_QueueType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_QueueType',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_rdo_ApprovedQueue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_rdo_ApprovedQueue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_rdo_ExceptionQueue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_rdo_ExceptionQueue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_rdo_PostedQueue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_rdo_PostedQueue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_SwiftFile')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_SwiftFile',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lblFilePathAndName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lblFilePathAndName',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_FilePathAndName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_FilePathAndName',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_ReadNewFile')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_ReadNewFile',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_SearchCriteria')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_SearchCriteria',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_FileRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_FileRefNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_FileRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_FileRefNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_Status')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_Status',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_Status')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_Status',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_PaymentMethod')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_PaymentMethod',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_PaymentMethod')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_PaymentMethod',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CorrespondentBank')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CorrespondentBank',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cboCorrespondentBank')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cboCorrespondentBank',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_MessageRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_MessageRefNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_MsgRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_MsgRefNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DebitCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DebitCurrency',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_DebitCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_DebitCurrency',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CreditCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CreditCurrency',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_CreditCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_CreditCurrency',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_MessageDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_MessageDate',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_dt_MsgValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_dt_MsgValueDate',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_OrderingCustomer')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_OrderingCustomer',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_OrderingCustomer')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_OrderingCustomer',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_SenderReference')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_SenderReference',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_SenderReference')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_SenderReference',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DebitAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DebitAmount',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cur_DrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cur_DrAmount',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
END
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CreditAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CreditAmount',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cur_CrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cur_CrAmount',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_Search')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_Search',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_TheMessagesResult')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_TheMessagesResult',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_MSGDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_MSGDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_Update')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_Update',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_Post')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_Post',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_Reverse')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_Reverse',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_MoveToApprovedQueue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_MoveToApprovedQueue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_MoveToExceptionQueue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_MoveToExceptionQueue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_TotalNoOfMessages')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_TotalNoOfMessages',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_TotalNoOfMessages')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_TotalNoOfMessages',-1,-1,-1,0,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_TotalMessagesAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_TotalMessagesAmount',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cur_TotalMessagesAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cur_TotalMessagesAmount',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Selection')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Selection',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FileRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FileRefNo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FilePathName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FilePathName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_MsgRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_MsgRefNo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Status')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Status',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Action')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Action',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_SendTo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_SendTo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_AccountOfficerID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_AccountOfficerID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_PaymentMethodID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_PaymentMethodID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DateTimeStamp')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DateTimeStamp',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_PreparedBy')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_PreparedBy',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_SpecialRateNeeded')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_SpecialRateNeeded',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_MsgValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_MsgValueDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_ValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_ValueDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_VoucherOK')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_VoucherOK',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_AuthorizedBy')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_AuthorizedBy',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_ApprovedBy')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_ApprovedBy',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountNo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountNo_AcctType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountNo_AcctType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountNo_ApplType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountNo_ApplType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountNo_DepLoan')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountNo_DepLoan',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrCurrency',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAddress')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAddress',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_SenderBank')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_SenderBank',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrExchangeRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrCommission')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrCommission',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountNo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountNo_AcctType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountNo_AcctType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountNo_ApplType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountNo_ApplType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountNo_DepLoan')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountNo_DepLoan',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrCurrency',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAddress')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAddress',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OrderingCustomer')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OrderingCustomer',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrExchangeRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrCommission')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrCommission',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_GTDTicket')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_GTDTicket',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OriginalMsg')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OriginalMsg',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Fld_50K')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Fld_50K',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Fld_59')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Fld_59',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Charge_Det')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Charge_Det',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryCurrency',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiarySellRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiarySellRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
END
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryBuyRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryBuyRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryGTDTicket')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryGTDTicket',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryIDType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryIDType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryIDNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryIDNumber',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryPhone')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryPhone',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryAddress')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryAddress',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryNarrative')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryNarrative',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_MT103Generated')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_MT103Generated',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_MT202Generated')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_MT202Generated',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Account_With_Ref')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Account_With_Ref',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Account_With_Ac')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Account_With_Ac',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Account_With_Name')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Account_With_Name',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_ValueCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_ValueCurrency',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Order_Cust_Name')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Order_Cust_Name',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Order_Cust_Add1')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Order_Cust_Add1',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Order_Cust_Add2')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Order_Cust_Add2',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Order_Inst')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Order_Inst',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Order_Inst_Name')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Order_Inst_Name',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Order_Inst_Add1')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Order_Inst_Add1',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryAccount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryAccount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_70')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_70',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_71A')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_71A',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrValueDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrValueDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrNarrative')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrNarrative',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrNarrative')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrNarrative',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_20')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_20',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_23')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_23',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_33')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_33',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_52')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_52',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_53')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_53',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Is_FLD_20_Duplicate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Is_FLD_20_Duplicate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_MsgType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_MsgType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_ExceptionList')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_ExceptionList',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldStatusID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldStatusID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountNo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountNo_AcctType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountNo_AcctType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountNo_ApplType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountNo_ApplType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountNo_DepLoan')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountNo_DepLoan',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrCurrency',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrExchangeRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrCommission')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrCommission',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountNo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountNo_AcctType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountNo_AcctType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountNo_ApplType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountNo_ApplType',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountNo_DepLoan')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountNo_DepLoan',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountName',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrCurrency',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrExchangeRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrCommission')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrCommission',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrValueDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrValueDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrRealExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrRealExchangeRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrRealExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrRealExchangeRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Row_Version')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Row_Version',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_LockedByID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_LockedByID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Updator')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Updator',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_LastChanged')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_LastChanged',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Branch')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Branch',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_TTAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_TTAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_TTCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_TTCurrency',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrSellExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrSellExchangeRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrBuyExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrBuyExchangeRate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_IBAN')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_IBAN',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_HostRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_HostRefNo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Sender_BIC')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Sender_BIC',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Ben_Inst_BIC')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Ben_Inst_BIC',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_72')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_72',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrRimNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrRimNo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Ordering_IBAN')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Ordering_IBAN',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Ben_Inst_Name')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Ben_Inst_Name',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Ben_Inst_AddLn1')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Ben_Inst_AddLn1',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Ben_Inst_AddLn2')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Ben_Inst_AddLn2',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Ben_Inst_AddLn3')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Ben_Inst_AddLn3',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_111')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_111',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_FLD_121')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_FLD_121',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_SenderRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_SenderRefNo',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DebitAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DebitAmount',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_PaymentMethod')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_PaymentMethod',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_StatusID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_StatusID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_ActionID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_ActionID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_SendToID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_SendToID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Updated')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Updated',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_SelectedSendToID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_SelectedSendToID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_SelectedActionID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_SelectedActionID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_SelectedAccountOfficerID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_SelectedAccountOfficerID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrNarrative')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrNarrative',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrNarrative')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrNarrative',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrExchangeGain')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrExchangeGain',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrExchangeGain')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrExchangeGain',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_ReverseReason')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_ReverseReason',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OtherReason')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OtherReason',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldPostStatusID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldPostStatusID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldReverseStatusID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldReverseStatusID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldMovetoApprovedStatusID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldMovetoApprovedStatusID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldPaymentMethodID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldPaymentMethodID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldRejectedMessageStatusID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldRejectedMessageStatusID',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_MessageUpdated')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_MessageUpdated',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CreditAccount_AccOpeningDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CreditAccount_AccOpeningDate',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldReverseReason')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldReverseReason',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_IsMessageWillbeHold')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_IsMessageWillbeHold',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_IsMessageHasSpecificExceptions')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_IsMessageHasSpecificExceptions',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountNo_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountNo_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountNo_AcctType_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountNo_AcctType_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountNo_ApplType_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountNo_ApplType_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountName_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountName_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountNo_DepLoan_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountNo_DepLoan_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrCurrency_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrCurrency_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAmount_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAmount_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrCommission_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrCommission_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrExchangeRate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrExchangeRate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrValueDate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrValueDate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrNarrative_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrNarrative_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountNo_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountNo_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountNo_AcctType_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountNo_AcctType_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountNo_ApplType_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountNo_ApplType_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountName_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountName_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Ordering_IBAN_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Ordering_IBAN_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAccountNo_DepLoan_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAccountNo_DepLoan_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrCurrency_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrCurrency_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrAmount_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrAmount_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrCommission_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrCommission_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrExchangeRate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrExchangeRate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrSellExchangeRate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrSellExchangeRate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrValueDate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrValueDate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DrNarrative_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DrNarrative_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_GTDTicket_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_GTDTicket_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountNo_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountNo_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountNo_AcctType_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountNo_AcctType_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountNo_ApplType_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountNo_ApplType_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountName_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountName_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAccountNo_DepLoan_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAccountNo_DepLoan_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrCurrency_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrCurrency_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrAmount_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrAmount_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrCommission_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrCommission_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrExchangeRate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrExchangeRate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrValueDate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrValueDate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldCrNarrative_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldCrNarrative_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountNo_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountNo_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountNo_AcctType_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountNo_AcctType_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountNo_ApplType_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountNo_ApplType_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountName_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountName_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_IBAN_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_IBAN_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrRimNo_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrRimNo_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAccountNo_DepLoan_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAccountNo_DepLoan_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrCurrency_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrCurrency_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrAmount_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrAmount_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrCommission_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrCommission_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrBuyExchangeRate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrBuyExchangeRate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrExchangeRate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrExchangeRate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrValueDate_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrValueDate_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_CrNarrative_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_CrNarrative_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_BeneficiaryGTDTicket_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_BeneficiaryGTDTicket_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldStatusID_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldStatusID_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_PaymentMethodID_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_PaymentMethodID_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_Updator_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_Updator_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_DBValuesSaved')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_DBValuesSaved',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grd_Messages_Column_OldDrAccountNo_DBValue')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grd_Messages_Column_OldDrAccountNo_DBValue',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',0)
End
GO

---------------------------------------------------

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_MessageDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_MessageDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_MessageRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_MessageRefNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_MessageRefNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_MessageRefNo',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_Status')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_Status',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_Status')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_Status',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DateTimeStamp')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DateTimeStamp',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_DateTimeStamp')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_DateTimeStamp',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_PreparedBy')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_PreparedBy',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_PreparedBy')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_PreparedBy',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_OrderingInstitution')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_OrderingInstitution',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_FLD_52')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_FLD_52',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_SenderReference')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_SenderReference',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_SenderReference')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_SenderReference',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_PaymentMethod')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_PaymentMethod',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_PaymentMethod')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_PaymentMethod',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_MessageDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_MessageDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_MsgValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_MsgValueDate',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_MsgValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_MsgValueDate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_FLD33B')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_FLD33B',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_TLR_FLD_33B')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_TLR_FLD_33B',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_PaymentDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_PaymentDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_PaymentDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_PaymentDetails',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_OrderingCustomer')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_OrderingCustomer',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_OrderingCustomer')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_OrderingCustomer',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_OrderingCustomerAddress')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_OrderingCustomerAddress',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_CrAddress')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_CrAddress',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_TLR_CORRESPONDENT_CHARGES')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_TLR_CORRESPONDENT_CHARGES',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_TLR_CORRESPONDENT_CHARGES')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_TLR_CORRESPONDENT_CHARGES',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_MessageType')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_MessageType',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_TLR_MSG_TYPE')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_TLR_MSG_TYPE',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_ExceptionList')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_ExceptionList',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_Changes')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_Changes',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_DebitDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_DebitDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_Dr_DP_GL')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_Dr_DP_GL',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_Dr_GL_DP')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_Dr_GL_DP',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DrAccountNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DrAccountNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_gl_Dr_GLNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_gl_Dr_GLNumber',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_GLCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_GLCurrency',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_DrCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_DrCurrency',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DrAccountName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DrAccountName',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_num_Dr_BuyRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_num_Dr_BuyRate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DrSellExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DrSellExchangeRate',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_num_Dr_SellRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_num_Dr_SellRate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_DebitExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_DebitExchangeRate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_DrAccountName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_DrAccountName',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DebitValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DebitValueDate',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_dt_DebitValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_dt_DebitValueDate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DrAddress')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DrAddress',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_DrAddress')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_DrAddress',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_SenderBank')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_SenderBank',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_DrSenderBank')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_DrSenderBank',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DrAmount',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cur_DrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cur_DrAmount',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DrCommission')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DrCommission',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cur_DrCommission')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cur_DrCommission',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DebitNarrative')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DebitNarrative',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_DrNarrative')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_DrNarrative',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DrGTDDealTicket')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DrGTDDealTicket',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_GTDDealTicket_Dr')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_GTDDealTicket_Dr',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_CreditDetails')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_CreditDetails',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl__Cr_DP_GL')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl__Cr_DP_GL',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_Cr_GL_DP')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_Cr_GL_DP',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CrAccountNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CrAccountNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_gl_Cr_GLNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_gl_Cr_GLNumber',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CreditCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CreditCurrency',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_CrCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_CrCurrency',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CrAccountName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CrAccountName',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_CrAccountName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_CrAccountName',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CrExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CrExchangeRate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_num_Cr_BuyRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_num_Cr_BuyRate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CrSellExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CrSellExchangeRate',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_num_Cr_SellRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_num_Cr_SellRate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_CreditExchangeRate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_CreditExchangeRate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CrAmount',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cur_CrAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cur_CrAmount',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CrCommission')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CrCommission',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cur_CrCommission')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cur_CrCommission',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CreditValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CreditValueDate',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_dt_CreditValueDate')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_dt_CreditValueDate',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CrBeneficiaryName')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CrBeneficiaryName',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_FLD_59')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_FLD_59',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CreditNarrative')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CreditNarrative',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_CrNarrative')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_CrNarrative',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CrGTDDealTicket')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CrGTDDealTicket',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txt_GTDDealTicket_Cr')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txt_GTDDealTicket_Cr',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_btn_OriginalSwiftMessage')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_btn_OriginalSwiftMessage',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_DebitInfo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_DebitInfo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_grb_CreditInfo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_grb_CreditInfo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_AccountLookup_Debit')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_AccountLookup_Debit',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_AccountLookup_Credit')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_AccountLookup_Credit',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_Debit_DP_GL')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_Debit_DP_GL',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_Debit_GL_DP')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_Debit_GL_DP',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_DebitGLNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_DebitGLNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_gl_Debit_GLNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_gl_Debit_GLNumber',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_Credit_DP_GL')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_Credit_DP_GL',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cbo_Credit_GL_DP')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cbo_Credit_GL_DP',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_lbl_CreditGLNo')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_lbl_CreditGLNo',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_gl_Credit_GLNumber')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_gl_Credit_GLNumber',-1,-1,-1,1,0,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_Dr_AccountLookup')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_Dr_AccountLookup',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_Cr_AccountLookup')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_Cr_AccountLookup',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txtDrAmountWithCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txtDrAmountWithCurrency',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_txtCrAmountWithCurrency')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_txtCrAmountWithCurrency',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cur_CreditAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cur_CreditAmount',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 862 AND FieldIDInPage = '_cur_DebitAmount')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible)
 Values (862,NULL,'Teller','_cur_DebitAmount',-1,-1,-1,1,1,'','','',N'ITSOFT\ahmed.orashed',1)
End
GO

-------------------------
-- RulesTranAcctStatus --
-------------------------
If Not Exists(Select * From RulesTranAcctStatus WHERE StatusID = 10000996 AND TranID = 862 AND FieldName = 'Account' AND Status = 'Active')
Begin
 Insert Into RulesTranAcctStatus(TranID,FieldName,Status,Updator,ApplicationType,StatusID,Creator,Type,AccountType)
 Values (862,'Account','Active',N'ITSOFT\ahmed.orashed',NULL,10000996,N'ITSOFT\ahmed.orashed',N'Acct',NULL)
End
GO

If Not Exists(Select * From RulesTranAcctStatus WHERE StatusID = 10000997 AND TranID = 862 AND FieldName = 'DrAccount' AND Status = 'Active')
Begin
 Insert Into RulesTranAcctStatus(TranID,FieldName,Status,Updator,ApplicationType,StatusID,Creator,Type,AccountType)
 Values (862,'DrAccount','Active',N'ITSOFT\ahmed.orashed',NULL,10000997,N'ITSOFT\ahmed.orashed',N'Acct',NULL)
End
GO

If Not Exists(Select * From RulesTranAcctStatus WHERE StatusID = 10000998 AND TranID = 862 AND FieldName = 'CrAccount' AND Status = 'Active')
Begin
 Insert Into RulesTranAcctStatus(TranID,FieldName,Status,Updator,ApplicationType,StatusID,Creator,Type,AccountType)
 Values (862,'CrAccount','Active',N'ITSOFT\ahmed.orashed',NULL,10000998,N'ITSOFT\ahmed.orashed',N'Acct',NULL)
End
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLStrings Where AccessID = 1100086)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100086,'Select_IR_QueueOptionsMapping','p',1,'Globalfs','dbo.Select_IR_QueueOptionsMapping',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','SELECT data FROM IR_QueueOptionsMapping table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100087)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100087,'Select_IR_QueueMessages','p',1,'Globalfs','dbo.Select_IR_QueueMessages',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select all messages from table IR based on specify status',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100088)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100088,'GetIRTotalMessagesAndAmount','p',1,'Globalfs','dbo.GetIRTotalMessagesAndAmount',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select Total Messages And Total Amount from table IR based on specify status ',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100089)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100089,'TLR_UPDATEIRMESSAGES','p',0,'Globalfs','dbo.UpdateIRMessages',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Update IR Messages',1,' ','',0,0,0,NULL,NULL,0,0,0,0,0)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100091)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100091,'Select_IR_DynamicException','p',1,'Globalfs','dbo.Select_IR_DynamicException',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','SELECT data FROM IR_DynamicException table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100092)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100092,'Select_IR_DynamicCondition','p',1,'Globalfs','dbo.Select_IR_DynamicExceptionCondition',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','SELECT data FROM IR_DynamicExceptionCondition table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

----------------
-- RulesParam --
----------------
DECLARE @paramID int
SELECT @paramID = MAX(ISNULL(ParamID , 0)) + 1 FROM RulesParam
If Not Exists(Select * From RulesParam Where ParamName = 'IRUseLockingMessages')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
 Values (@paramID,'IRUseLockingMessages','IRUseLockingMessages',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
End
GO

DECLARE @paramID int
SELECT @paramID = MAX(ISNULL(ParamID , 0)) + 1 FROM RulesParam
If Not Exists(Select * From RulesParam Where ParamName = 'SWIFT_ReversePath_Read')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
 Values (@paramID,'SWIFT_ReversePath_Read','SWIFT_ReversePath_Read',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
End
GO

DECLARE @paramID int
SELECT @paramID = MAX(ISNULL(ParamID , 0)) + 1 FROM RulesParam
If Not Exists(Select * From RulesParam Where ParamName = 'SWIFT_ReverseFileName')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
 Values (@paramID,'SWIFT_ReverseFileName','SWIFT_ReverseFileName',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
End
GO

DECLARE @paramID int
SELECT @paramID = MAX(ISNULL(ParamID , 0)) + 1 FROM RulesParam
If Not Exists(Select * From RulesParam Where ParamName = 'SWIFT_ReversePath_Write')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
 Values (@paramID,'SWIFT_ReversePath_Write','SWIFT_ReversePath_Write',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
End
GO

DECLARE @paramID int
SELECT @paramID = MAX(ISNULL(ParamID , 0)) + 1 FROM RulesParam
If Not Exists(Select * From RulesParam Where ParamName = 'SWIFT_NameMatchingPercent')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
 Values (@paramID,'SWIFT_NameMatchingPercent','SWIFT_NameMatchingPercent',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
End
GO

-----------------------
-- RulesTranFldParam --
-----------------------
If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'ExchangeRate' And Param = 'LoadRatesFromIR')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','ExchangeRate','LoadRatesFromIR','0',N'ITSOFT\ahmed.orashed','bit',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'DrAccount' And Param = 'OverdrawnValidation')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','DrAccount','OverdrawnValidation','1',N'ITSOFT\ahmed.orashed','bit',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'DrAccount' And Param = 'ProcessType')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','DrAccount','ProcessType','D',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'CrAccount' And Param = 'ProcessType')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','CrAccount','ProcessType','C',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'OverrideAccountLookupData' And Param = 'OverrideAccountLookupData')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','OverrideAccountLookupData','OverrideAccountLookupData','false',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'IRMinDpCrAmtValidation' And Param = 'IRMinDpCrAmtValidation')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','IRMinDpCrAmtValidation','IRMinDpCrAmtValidation','True',N'ITSOFT\ahmed.orashed','bit',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'CheckForStatusPaid' And Param = 'CheckForStatusPaid')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','CheckForStatusPaid','CheckForStatusPaid','False',N'ITSOFT\ahmed.orashed','bit',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'Error' And Param = 'ErrorConfirmation')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','Error','ErrorConfirmation','w',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'AmountCurrType' And Param = 'CurrencyCategoryID')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','AmountCurrType','CurrencyCategoryID','29',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'IRMsgsLimitInFile' And Param = 'IRMsgsLimitInFile')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','IRMsgsLimitInFile','IRMsgsLimitInFile','2',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'LimitIR' And Param = 'IRMessagesLimit')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','LimitIR','IRMessagesLimit','30',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'FATCA' And Param = 'FatcaValidation')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','FATCA','FatcaValidation','0',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'IRMsgValueDateValidation' And Param = 'IRMsgValueDateValidation')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','IRMsgValueDateValidation','IRMsgValueDateValidation','False',N'ITSOFT\ahmed.orashed','bit',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'IRUseLockingMessages' And Param = 'IRUseLockingMessages')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','IRUseLockingMessages','IRUseLockingMessages','1',N'ITSOFT\ahmed.orashed','bit',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'Transaction' And Param = 'ExpressionName')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','Transaction','ExpressionName','MSGReference',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'SWIFT_ReversePath_Read' And Param = 'SWIFT_ReversePath_Read')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','SWIFT_ReversePath_Read','SWIFT_ReversePath_Read','',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'SWIFT_ReverseFileName' And Param = 'SWIFT_ReverseFileName')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','SWIFT_ReverseFileName','SWIFT_ReverseFileName','',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'SWIFT_ReversePath_Write' And Param = 'SWIFT_ReversePath_Write')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','SWIFT_ReversePath_Write','SWIFT_ReversePath_Write','',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' And FieldName = 'SWIFT_NameMatchingPercent' And Param = 'SWIFT_NameMatchingPercent')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardTransfersHOSwiftProcess','SWIFT_NameMatchingPercent','SWIFT_NameMatchingPercent','0',N'ITSOFT\ahmed.orashed','decimal',NULL)
End
GO

If Not Exists(Select * From RulesTranFldParam Where TranName = 'InwardRemittanceHOSwiftService' And FieldName = 'SWIFT_NameMatchingPercent' And Param = 'SWIFT_NameMatchingPercent')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 Values ('InwardRemittanceHOSwiftService','SWIFT_NameMatchingPercent','SWIFT_NameMatchingPercent','0',N'ITSOFT\ahmed.orashed','decimal',NULL)
End
GO

--------------------
-- RulesTranField --
--------------------
If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = -1099996)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Created,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,-1099996,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'','Oct  4 2006  6:57PM',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = -1099995)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Created,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,-1099995,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'','Oct  4 2006  6:57PM',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = -1099994)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Created,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,-1099994,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'','Oct  4 2006  6:57PM',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 186)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
 Values (862,186,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1497)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Created,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1497,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'','Oct  4 2006  6:57PM',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 435)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Created,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,435,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'','Oct  4 2006  6:57PM',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'QueueType',1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1475)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Created,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1475,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'','Oct  4 2006  6:57PM',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FilePathAndName',1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1322)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Created,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1322,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'','Oct  4 2006  6:57PM',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'TotalMessages',1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2176)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Created,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2176,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'','Oct  4 2006  6:57PM',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'TotalMessagesAmount',1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1462)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1462,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaRimType',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1463)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1463,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaStatus',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1466)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1466,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaUsTin',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1881)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1881,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaFormW9',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2264)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2264,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaFormW8',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1883)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1883,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaFormReqDt',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1890)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1890,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaFormRecvDt',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2263)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2263,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaGIIN',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1882)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1882,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaClassId',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 247)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,247,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'FatcaSubClassId',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 276)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,276,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'CountryCode',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1515)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1515,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1514)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1514,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1526)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1526,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1527)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1527,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1528)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1528,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1519)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1519,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1518)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1518,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1520)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1520,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1517)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1517,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1516)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1516,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1532)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1532,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1533)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1533,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1534)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1534,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1535)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1535,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1536)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1536,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1537)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1537,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1538)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1538,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1539)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1539,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1540)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1540,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1541)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1541,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1542)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1542,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1543)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1543,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1544)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1544,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1545)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1545,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1546)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1546,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1547)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1547,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1548)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1548,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1549)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1549,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1513)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1513,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1529)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1529,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1530)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1530,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1531)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1531,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1525)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1525,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1522)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1522,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1521)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1521,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1523)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1523,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1524)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1524,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1550)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1550,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1551)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1551,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1552)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1552,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1553)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1553,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1554)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1554,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1555)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1555,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1556)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1556,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1660)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1660,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1557)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1557,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1558)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1558,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1559)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1559,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1560)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1560,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1561)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1561,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1562)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1562,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1563)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1563,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1564)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1564,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1565)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1565,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1566)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1566,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1567)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1567,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1628)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1628,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1629)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1629,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1648)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1648,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1647)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1647,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1646)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1646,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1645)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1645,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1649)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1649,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1650)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1650,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 969)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,969,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1828)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1828,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1988)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1988,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1989)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1989,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1992)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1992,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1993)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1993,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1994)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1994,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1995)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1995,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 583)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,583,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 584)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,584,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1661)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1661,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 274)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,274,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2009)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2009,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 275)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,275,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1812)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1812,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1717)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1717,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1716)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1716,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1652)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1652,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1805)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1805,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 846)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,846,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 968)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,968,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1658)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1658,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 238)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,238,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1508)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1508,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1657)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1657,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1653)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1653,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1659)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1659,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 236)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,236,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 248)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,248,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 492)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,492,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1802)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1802,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1615)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1615,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1631)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1631,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1654)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1654,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1655)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1655,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1656)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1656,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1999)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1999,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2002)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2002,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1803)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1803,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1804)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1804,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1801)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1801,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2044)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2044,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2045)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2045,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1693)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1693,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1694)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1694,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1808)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1808,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1509)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1509,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1896)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1896,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1915)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1915,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 991)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,991,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1998)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1998,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2036)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2036,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1917)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1917,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2034)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2034,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1540)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1540,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2037)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2037,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1785)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1785,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1914)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1914,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 583)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,583,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1916)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1916,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2035)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2035,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1567)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1567,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2007)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2007,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2003)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2003,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2001)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2001,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1911)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1911,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1909)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1909,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1908)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1908,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1691)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1691,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1627)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1627,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1626)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1626,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1625)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1625,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1624)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1624,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1464)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1464,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1309)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1309,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1612)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1612,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1568)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1568,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1569)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1569,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1570)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1570,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 1571)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,1571,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 992)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,992,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 992)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,992,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,NULL,0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 2030)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,2030,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'HoldAmount',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 862 And FieldID = 514)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (862,514,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'MessageRefNo',0,-1,0,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 354 And FieldID = 2030)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (354,2030,1,0,0,NULL,N'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'HoldAmount',0,-1,0,NULL,NULL)
End
GO

--------------------
-- RulesTranSteps --
--------------------
If Not Exists(Select * From RulesStepAction Where Action = 'SendToPhoenixWithUpdateIRMessages' And StepType = 413)
Begin
 Insert Into RulesStepAction(Action,StepType,AppID,Updator,Developer,WritesJournal)
 Values ('SendToPhoenixWithUpdateIRMessages',413,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',0)
End
GO

--------------------
-- RulesTranSteps --
--------------------
If Not Exists(Select * From RulesTranSteps Where TranID = 862 And StepSequence = 10)
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,Developer,Updator,RowStatus,ConditionID)
 Values (862,10,305,0,0,'JournalInsert',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
End
GO

If Not Exists(Select * From RulesTranSteps Where TranID = 862 And StepSequence = 20)
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,Developer,Updator,RowStatus,ConditionID)
 Values (862,20,413,0,0,'SendToPhoenixWithUpdateIRMessages',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
End
GO

If Not Exists(Select * From RulesTranSteps Where TranID = 862 And StepSequence = 30)
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,Developer,Updator,RowStatus,ConditionID)
 Values (862,30,305,0,1,'JournalUpdate',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
End
GO

---------------
-- PickLists --
---------------
If Not Exists(Select * From PickLists Where PickListID = 564)
Begin
 Insert Into PickLists(AppID,PickListID,PickList_Name,Updator,Creator,RowStatus)
 Values (1,564,'TLR_IR_REVERSE_REASON',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

----------------------
-- PickList_Entries --
----------------------
If Not Exists(Select * From PickList_Entries Where PickListID = 564 And DisplayOrder = 1)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (564,1,1,'COR_REASON','Reason',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
End
GO

If Not Exists(Select * From PickList_Entries Where PickListID = 564 And DisplayOrder = 2)
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,Updator,Creator,RowStatus,CustomValues)
 Values (564,1,2,'TLR_OTHERREASON','Other',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1,NULL)
End
GO

------------
-- Status --
------------
If Not Exists(Select * From Status Where StatusTypeID = 12 And id = 15)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (12,15,'Reversed','Reversed',NULL,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 14 And id = 21)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (14,21,'Reverse','Reverse',NULL,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

----------------------------
-- IR_QueueOptionsMapping --
----------------------------
If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ApprovedQueue' AND IRStatusID = 1)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ApprovedQueue',1)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'PostedQueue' AND IRStatusID = 8)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('PostedQueue',8)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'OtherQueue' AND IRStatusID = 13)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('OtherQueue',13)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'OtherQueue' AND IRStatusID = 15)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('OtherQueue',15)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 1)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',1)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 2)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',2)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 3)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',3)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 4)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',4)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 5)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',5)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 6)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',6)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 7)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',7)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 9)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',9)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 10)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',10)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 11)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',11)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 12)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',12)
End
GO

If Not Exists(Select * From IR_QueueOptionsMapping Where QueueType = 'ExceptionQueue' AND IRStatusID = 14)
Begin
 Insert Into IR_QueueOptionsMapping(QueueType,IRStatusID)
 Values ('ExceptionQueue',14)
End
GO

PRINT 'End... Script for CR# GFSY00807 DML Script'
GO
--==================================================================================================================================================================
IF NOT EXISTS (SELECT * FROM RulesDescriptor WHERE NAME = 'lbl_OtherPurpose' AND DescriptorID = 1105788)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name           , forVB , TypeName  , Descriptor      , Creator              , Updator )  
	values                      ( 1    , 1105788      , 'lbl_OtherPurpose' , 0     , 'Labels'  , 'Other Purpose' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

IF NOT EXISTS (SELECT * FROM RulesDescriptor WHERE NAME = 'lbl_DocumentsReceived' AND DescriptorID = 1105789)
BEGIN
	INSERT INTO RulesDescriptor (AppID , DescriptorID , Name                , forVB , TypeName  , Descriptor      , Creator              , Updator )  
	values                      ( 1    , 1105789      , 'lbl_DocumentsReceived' , 0     , 'Labels'  , 'Documents Received' , 'ITSOFT\ahmed.eliwa' , 'ITSOFT\ahmed.eliwa')
END
GO

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************
If Not Exists(Select * From RulesTranDescriptors Where TranID = 160 And DSC_Name = 'lbl_OtherPurpose')
Begin
 Insert Into RulesTranDescriptors(TranID,    DSC_Name          ,LastChanged                 ,Updator                   , Creator                ,  Created               , RowStatus , EffectiveDate         ,ExpirationDate)
                           Values(  160 ,   'lbl_OtherPurpose'     , 'August  26 2020  10:44PM',  N'ITSOFT\ahmed.eliwa' , N'ITSOFT\ahmed.eliwa', 'August  26 2020  10:44PM', 1         ,'Jan  1 1901 12:00AM'  ,'Dec 31 9998 12:00AM')
End
Go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 160 And DSC_Name = 'lbl_DocumentsReceived')
Begin
 Insert Into RulesTranDescriptors(TranID,    DSC_Name               ,LastChanged                 ,Updator                   , Creator                ,  Created               , RowStatus , EffectiveDate         ,ExpirationDate)
                           Values(  160 ,   'lbl_DocumentsReceived'     , 'August  26 2020  10:44PM',  N'ITSOFT\ahmed.eliwa' , N'ITSOFT\ahmed.eliwa', 'August  26 2020  10:44PM', 1         ,'Jan  1 1901 12:00AM'  ,'Dec 31 9998 12:00AM')
End
Go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 160 And DSC_Name = 'TLR_OTHER')
Begin
 Insert Into RulesTranDescriptors(TranID,    DSC_Name               ,LastChanged                 ,Updator                   , Creator                ,  Created               , RowStatus , EffectiveDate         ,ExpirationDate)
                           Values(  160 ,   'TLR_OTHER'     , 'August  26 2020  10:44PM',  N'ITSOFT\ahmed.eliwa' , N'ITSOFT\ahmed.eliwa', 'August  26 2020  10:44PM', 1         ,'Jan  1 1901 12:00AM'  ,'Dec 31 9998 12:00AM')
End
Go

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

If Not Exists(Select * From RulesTranField_ex Where TranID = 160 AND FieldIDInPage = '_txtOtherTransactionPurpose')
Begin
 Insert Into RulesTranField_ex(TranID ,FieldID ,Module   ,FieldIDInPage                 ,FirstPage ,LastPage ,ControlPage ,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged          ,Updator                ,IsVisible)
 Values                       (160    ,NULL    ,'Teller' ,'_txtOtherTransactionPurpose' ,-1        ,-1       ,-1          ,1       ,1         ,'lbl_OtherPurpose' ,''          ,''      ,'jun  3 2020  2:18PM',N'ITSOFT\ahmed.eliwa'  , 1       )
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 160 AND FieldIDInPage = 'cbo_DocumentsReceived')
Begin
 Insert Into RulesTranField_ex(TranID ,FieldID ,Module   ,FieldIDInPage                 ,FirstPage ,LastPage ,ControlPage ,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged          ,Updator                ,IsVisible)
 Values                       (160    ,NULL    ,'Teller' ,'cbo_DocumentsReceived'       ,-1        ,-1       ,-1          ,1       ,0         ,'lbl_DocumentsReceived' ,''          ,''      ,'jun  3 2020  2:18PM',N'ITSOFT\ahmed.eliwa'  , 0       )
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 160 AND FieldIDInPage = '_lblOtherTransactionPurpose')
Begin
 Insert Into RulesTranField_ex(TranID ,FieldID ,Module   ,FieldIDInPage                 ,FirstPage ,LastPage ,ControlPage ,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged          ,Updator                ,IsVisible)
 Values                       (160    ,NULL    ,'Teller' ,'_lblOtherTransactionPurpose' ,-1        ,-1       ,-1          ,1       ,1         ,'lbl_OtherPurpose' ,''          ,''      ,'jun  3 2020  2:18PM',N'ITSOFT\ahmed.eliwa'  , 1       )
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 160 AND FieldIDInPage = '_lblDocumentsReceived')
Begin
 Insert Into RulesTranField_ex(TranID ,FieldID ,Module   ,FieldIDInPage                 ,FirstPage ,LastPage ,ControlPage ,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged          ,Updator                ,IsVisible)
 Values                       (160    ,NULL    ,'Teller' ,'_lblDocumentsReceived' ,-1        ,-1       ,-1          ,1       ,0         ,'lbl_DocumentsReceived' ,''          ,''      ,'jun  3 2020  2:18PM',N'ITSOFT\ahmed.eliwa'  , 0       )
End
go

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

If Not Exists(Select * From RulesTranField Where TranID = 160 And FieldID = 395)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged             ,isDupable ,MaxArray ,Notes  ,Created                   ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (160,     395     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa'  ,'August 27 2020 12:59PM' ,1         ,NULL     ,''     ,'August 27 2020 12:59PM' ,N'ITSOFT\ahmed.eliwa'    ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,'OtherTransactionPurpose',1,-1)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 160 And FieldID = 264)  
Begin
 Insert Into RulesTranField(TranID,  FieldID ,Optional  ,ToHost ,FromHost ,DSC_Pattern  ,Developer              ,LastChanged             ,isDupable ,MaxArray ,Notes  ,Created                   ,Updator                 ,RowStatus ,EffectiveDate         ,ExpirationDate             ,IsReadOnly  ,jTarget   ,BindValue ,isReadOnlyImaging ,FieldAlias ,ShowInDWH ,IndexInDWH)
                    Values (160,     264     ,1         ,0      ,0         ,NULL        ,'ITSOFT\ahmed.eliwa'  ,'August 27 2020 12:59PM' ,1         ,NULL     ,''     ,'August 27 2020 12:59PM' ,N'ITSOFT\ahmed.eliwa'    ,1         ,'Jan  1 1901 12:00AM' ,'Dec 31 9998 12:00AM'      ,0           ,NULL      ,0         ,0                 ,'DocumentsReceived',1,-1)
End
go


--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

Declare @max_display_order int
select @max_display_order = IsNull(Max(DisplayOrder + 1),1) from PickList_Entries where PickListID = 508
If Not Exists(Select * From PickList_Entries Where PickListID = 508 And Value = 'other')
Begin
 Insert Into PickList_Entries(PickListID,AppID,DisplayOrder       ,DescriptorName,Value   ,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values                      (508       ,1    ,@max_display_order ,'TLR_OTHER'  ,'other' ,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','August 27 2020  2:41PM','August 27 2020  2:41PM',N'ITSOFT\ahmed.eliwa',N'ITSOFT\ahmed.eliwa',1,NULL)
End
go

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

If Not Exists(Select * From PickLists Where PickListID =563)
Begin
INSERT INTO PickLists(AppID, PickListID, PickList_Name)
VALUES     (1,563,'DocumentsReceived')
End
go

--***************************************************************************************************************************************************************************************************************************
--***************************************************************************************************************************************************************************************************************************

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105788 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105788,1025,N'��� ���','ITSOFT\ahmed.eliwa','August 12 2010  12:20PM',N'ITSOFT\ahmed.eliwa')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105789 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105789,1025,N'��������� ��������','ITSOFT\ahmed.eliwa','August 12 2010  12:20PM',N'ITSOFT\ahmed.eliwa')
End
go