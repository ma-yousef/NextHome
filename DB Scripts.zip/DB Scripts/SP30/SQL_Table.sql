-- Mohamed Elabd [Start: 28-March-2018 - Issue# GFSX12951]
-- Script for changing size of column FLD_52
USE [Globalfs]
GO

-----------------------------------
-- Alter table IR -----------------
-- change coulmn size "FLD_52" ----
-- from 150 to 200 ----------------
-----------------------------------
ALTER TABLE IR 
ALTER COLUMN FLD_52 Varchar(200)
GO

-----------------------------------
-- Drop proc IRBulkInsertIntoIR ---
-----------------------------------
DROP_OLD_PROC 'IRBulkInsertIntoIR'
GO

-----------------------------------
-- Alter type IRBulkTableType -----
-- change coulmn size "DB_FLD_52"--
-- from 150 to 200 ----------------
-----------------------------------

IF  EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'IRBulkTableType' AND ss.name = N'dbo')
DROP TYPE [dbo].[IRBulkTableType]
GO

CREATE TYPE [dbo].[IRBulkTableType] AS TABLE(
	[FileRefNo] [varchar](11) NULL,
	[FilePathName] [varchar](255) NULL,
	[MsgRefNo] [char](13) NULL,
	[StatusID] [int] NULL,
	[ActionId] [int] NULL,
	[PaymentMethodID] [int] NULL,
	[DateTimeStamp] [smalldatetime] NULL,
	[PreparedBy] [varchar](60) NULL,
	[MsgValueDate] [datetime2](7) NULL,
	[ValueDate] [datetime2](7) NULL,
	[DrAccountNo] [varchar](60) NULL,
	[DrAccountNo_AcctType] [varchar](5) NULL,
	[DrAccountNo_ApplType] [varchar](5) NULL,
	[DrAccountNo_DepLoan] [varchar](5) NULL,
	[DrAccountName] [nvarchar](255) NULL,
	[DrCurrency] [varchar](4) NULL,
	[DrAmount] [decimal](21, 6) NULL,
	[DrAddress] [nvarchar](255) NULL,
	[SenderBank] [nvarchar](255) NULL,
	[DrExchangeRate] [decimal](21, 6) NULL,
	[DrCommission] [decimal](21, 6) NULL,
	[CrAccountNo] [varchar](60) NULL,
	[CrAccountNo_AcctType] [varchar](5) NULL,
	[CrAccountNo_ApplType] [varchar](5) NULL,
	[CrAccountNo_DepLoan] [varchar](5) NULL,
	[CrAccountName] [nvarchar](255) NULL,
	[CrCurrency] [varchar](4) NULL,
	[CrAmount] [decimal](21, 6) NULL,
	[CrAddress] [nvarchar](255) NULL,
	[OrderingCustomer] [varchar](255) NULL,
	[CrExchangeRate] [decimal](21, 6) NULL,
	[CrCommission] [decimal](21, 6) NULL,
	[OriginalMsg] [varchar](1000) NULL,
	[Fld_50K] [varchar](255) NULL,
	[Fld_59] [varchar](255) NULL,
	[Charge_Det] [char](3) NULL,
	[Account_With_Ref] [varchar](100) NULL,
	[Account_With_Ac] [varchar](100) NULL,
	[Account_With_Name] [nvarchar](100) NULL,
	[ValueCurrency] [varchar](5) NULL,
	[Order_Cust_Name] [nvarchar](100) NULL,
	[Order_Cust_Add1] [varchar](150) NULL,
	[Order_Cust_Add2] [varchar](150) NULL,
	[Order_Inst] [varchar](100) NULL,
	[Order_Inst_Name] [varchar](100) NULL,
	[Order_Inst_Add1] [varchar](150) NULL,
	[BeneficiaryAccount] [varchar](100) NULL,
	[FLD_70] [varchar](150) NULL,
	[FLD_71A] [varchar](150) NULL,
	[BeneficiaryName] [nvarchar](140) NULL,
	[BeneficiaryAddress] [varchar](255) NULL,
	[Updator] [varchar](60) NULL,
	[DB_DrValueDate] [datetime2](7) NULL,
	[DB_CrValueDate] [datetime2](7) NULL,
	[DB_DrNarrative] [varchar](150) NULL,
	[DB_CrNarrative] [varchar](150) NULL,
	[DB_FLD_20] [varchar](100) NULL,
	[DB_FLD_23] [varchar](100) NULL,
	[DB_FLD_33] [varchar](100) NULL,
	[DB_FLD_52] [varchar](200) NULL,
	[DB_FLD_53] [varchar](150) NULL,
	[MsgType] [varchar](10) NULL,
	[ExceptionList] [varchar](8000) NULL,
	[Is_FLD_20_Duplicate] [bit] NULL,
	[DrRealExchangeRate] [decimal](21, 6) NULL,
	[CrRealExchangeRate] [decimal](21, 6) NULL,
	[TTAmount] [decimal](21, 6) NULL,
	[TTCurrency] [varchar](4) NULL,
	[DrSellExchangeRate] [decimal](21, 6) NULL,
	[CrBuyExchangeRate] [decimal](21, 6) NULL,
	[IBAN] [varchar](100) NULL,
	[Ordering_IBAN] [varchar](100) NULL,
	[Sender_BIC] [nvarchar](150) NULL
)
GO

-----------------------------------
-- Create proc IRBulkInsertIntoIR -
-----------------------------------      
CREATE PROCEDURE dbo.IRBulkInsertIntoIR       
    @Table IRBulkTableType READONLY          
    AS          
/*            
CreationDate: 2017-5-31           
OriginalName: dbo.IRBulkInsertIntoIR            
Programmer  : Karim Mahmoud      
Description : Bulk Insert rows in IR Table      
*/         
BEGIN TRY        
    BEGIN TRANSACTION         
       INSERT INTO IR      
        (              
    FileRefNo,              
    FilePathName,             
    MsgRefNo,              
    StatusID,              
    ActionId,              
    PaymentMethodID,              
    DateTimeStamp,              
    PreparedBy,              
    MsgValueDate,              
    ValueDate,              
    DrAccountNo,              
    DrAccountNo_AcctType,            
    DrAccountNo_ApplType,            
    DrAccountNo_DepLoan,            
    DrAccountName,              
    DrCurrency,              
    DrAmount,              
    DrAddress,              
    SenderBank,              
    DrExchangeRate,              
    DrCommission,              
    CrAccountNo,              
    CrAccountNo_AcctType,           
    CrAccountNo_ApplType,            
    CrAccountNo_DepLoan,            
    CrAccountName,              
    CrCurrency,              
    CrAmount,              
    CrAddress,              
    OrderingCustomer,              
    CrExchangeRate,              
    CrCommission,              
    OriginalMsg,              
    Fld_50K,              
    Fld_59,              
    Charge_Det,             
    Account_With_Ref,          
    Account_With_Ac,          
    Account_With_Name,          
    ValueCurrency,          
    Order_Cust_Name,          
    Order_Cust_Add1,          
    Order_Cust_Add2,          
    Order_Inst,          
    Order_Inst_Name,          
    Order_Inst_Add1,          
    BeneficiaryAccount,          
    FLD_70,          
    FLD_71A,          
    BeneficiaryName,          
    BeneficiaryAddress,          
    Updator,          
    DrValueDate,          
    CrValueDate,          
    DrNarrative,          
    CrNarrative,          
    FLD_20,          
    FLD_23,          
    FLD_33,          
    FLD_52,          
    FLD_53,          
    MsgType,          
    ExceptionList,          
    Is_FLD_20_Duplicate,          
    DrRealExchangeRate,          
    CrRealExchangeRate,           
    TTAmount ,          
    TTCurrency ,          
    DrSellExchangeRate,          
    CrBuyExchangeRate ,        
    IBAN   ,          
    Ordering_IBAN,          
    Sender_BIC,          
    CrRimNo,        
    Ben_Inst_BIC        
  )             
  SELECT       
        
    irbt.FileRefNo,              
    irbt.FilePathName,              
    irbt.MsgRefNo,              
    irbt.StatusID,              
    irbt.ActionId,              
    irbt.PaymentMethodID,              
    irbt.DateTimeStamp,              
    irbt.PreparedBy,              
    irbt.MsgValueDate,              
    irbt.ValueDate,              
    irbt.DrAccountNo,              
    irbt.DrAccountNo_AcctType,            
    irbt.DrAccountNo_ApplType,            
    irbt.DrAccountNo_DepLoan,            
    irbt.DrAccountName,              
    irbt.DrCurrency,             
    irbt.DrAmount,              
    irbt.DrAddress,              
    irbt.SenderBank,              
    irbt.DrExchangeRate,              
    irbt.DrCommission,              
    irbt.CrAccountNo,            
    irbt.CrAccountNo_AcctType,            
    irbt.CrAccountNo_ApplType,            
    irbt.CrAccountNo_DepLoan,             
    irbt.CrAccountName,              
    irbt.CrCurrency,           
    irbt.CrAmount,              
    irbt.CrAddress,              
    irbt.OrderingCustomer,              
    irbt.CrExchangeRate,              
    irbt.CrCommission,              
    irbt.OriginalMsg,              
    irbt.Fld_50K,              
    irbt.Fld_59,              
    irbt.Charge_Det,          
    irbt.Account_With_Ref,          
    irbt.Account_With_Ac,          
    irbt.Account_With_Name,          
    irbt.ValueCurrency,          
    irbt.Order_Cust_Name,          
    irbt.Order_Cust_Add1,          
    irbt.Order_Cust_Add2,          
    irbt.Order_Inst,          
    irbt.Order_Inst_Name,          
    irbt.Order_Inst_Add1,          
    irbt.BeneficiaryAccount,          
    irbt.FLD_70,     
    irbt.FLD_71A,          
    irbt.BeneficiaryName,          
    irbt.BeneficiaryAddress,          
    irbt.Updator,        
    irbt.DB_DrValueDate,         
    irbt.DB_CrValueDate,          
    irbt.DB_DrNarrative,          
    irbt.DB_CrNarrative,          
    irbt.DB_FLD_20,          
    irbt.DB_FLD_23,          
    irbt.DB_FLD_33,          
    irbt.DB_FLD_52,          
    irbt.DB_FLD_53,          
    irbt.MsgType,          
    irbt.ExceptionList,          
    irbt.Is_FLD_20_Duplicate,          
    irbt.DrRealExchangeRate,              
    irbt.CrRealExchangeRate,          
    irbt.TTAmount,          
    irbt.TTCurrency,          
    irbt.DrSellExchangeRate,          
    irbt.CrBuyExchangeRate,        
    irbt.IBAN,        
    irbt.Ordering_IBAN,          
    irbt.Sender_BIC,         
    '',--CrRimNo varchar(100),        
    ''--Ben_Inst_BIC varchar(100)        
        
  FROM @Table irbt      
    COMMIT        
END TRY        
BEGIN CATCH        
    IF @@TRANCOUNT > 0        
        ROLLBACK        
    return -1;      
END CATCH        
GO
IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'BranchConfig' AND COLUMN_NAME = 'DealCashCompany')                   
BEGIN
	ALTER TABLE [dbo].BranchConfig
	ADD  DealCashCompany  bit not NULL DEFAULT 0
END
GO

-- Mohamed Elabd [End: 28-March-2018 - Issue# GFSX12951]
--  Developer:  Rokaia KAdry   Issue:GFSX13022 27-05-2018  
If Not Exists(Select * from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME = 'CorporateCOs' And COLUMN_NAME ='DebitAccountType')
Begin
	Alter Table CorporateCOs Add DebitAccountType Char(3) null
End

GO
/*
	CreationDate : [22/05/2018]
	Programmer   : Sara Badwy
	Description  :CR[CRQ13289] Adding new Column to save Name2 ...
*/
------------------------------------------------------------------------------------------------------------------
------------------------------------------- //*ATMCardRequest*\\ -------------------------------------------
------------------------------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'ATMCardRequest' AND Column_Name = 'Name2')
BEGIN
	ALTER TABLE ATMCardRequest
	ADD Name2 NVARCHAR(40) 
	 
END
GO