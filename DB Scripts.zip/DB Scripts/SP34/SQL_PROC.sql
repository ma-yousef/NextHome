Drop_old_proc get_tcr_deviceID
Go
create proc get_tcr_deviceID
    @user_number internal_user_ID
AS
	declare @deviceID int
	SELECT @deviceID=TCRDeviceID FROM Operator WHERE user_number=@user_number
	
	if @deviceID is not null
	return @deviceID
	else return 0
GO
drop_old_proc 'dbo.GetAllOperatorInfo'
go

create proc dbo.GetAllOperatorInfo @LoginID OperatorID, @now datetime = NULL          
, @bank BankID = NULL, @region RegionID = NULL, @branch BranchID = NULL          
, @user_number internal_user_id = null          
, @debug int = 0           
AS          
-- Obtain all Globalfs authorization information for a specified LoginID.          
-- Copyright 2003 - 2009 Compucom Systems, Inc.  All rights reserved.          
-- Bill Davidson, March 15, 2003          
-- Bodhi & Bill 12JUN03 - Add many columns from various tables.          
-- Bill Davidson 14JUL03 - Now return Last_Bank, Last_Region, Last_Branch          
-- Bodhi 29JUL03 - Don't count unposted transactions.            
-- Bodhi 08JAN04 - Accept optional parameter @now = current time at user's work station.          
--               - This is to support Teller Journal Re-Entry, CR#8395           
-- 12JUL04 BillD - Added SecondaryLogonID parameter to projection list           
-- 24FEB05 Bodhi - Allow LoginID to be either simple acount or domain\account name.          
-- 29Nov05 Keven - Added a call to GetAllRolesForThisOperator. So we now return two row sets.           
-- 17Aug06 Bodhi - Raise 52071 when operator is missing, 52072 when expired.          
-- 05Sep06 Bodhi - Get better speed and clarity by eliminating dynamic T-SQL code.          
-- 08MAR07 Bodhi & Gilberto - Updated use new OperatorStatus table.          
--         - Don't raise error when user has active drawer in another branch. (Think off net).          
-- 30JUL07 Bodhi - Don't raise error when the user has an open day in another branch. Let that happen in the logon, not the info query.          
-- 08JAN08 Bodhi - Lower the severity of messages 71 and 72 (unknown and expired operator) to not create an event log at the mid tier.          
-- 14MAY08 Juan Hdz - Changed to use new Workstations table (instead of workstation) CR15845          
-- 20MAY2008 Juan Hdz - Added changes to display Workstation Id and Location.          
-- 04JUN08 Juan Hdz - Included GetAllTellerInfo code in this procedure.          
--  30Jul08 TimG - Replaced RowStatus check with dbo.isRowActive().          
-- 02Sep08 TimG - CR17422.  Drop obsolete columns isSalesRep and CanApproveCTR.           
-- 19FEB09 Bodhi - Add BrID column to the result.          
-- 14APR09 Bodhi - Add computed integer column, LastSequenceNumberOffNetwork, to the end of the first rowset (value always zero).         
-- 12JUN11 MelMasry - add new 3 columns to be genrated [IsExceedCashMaxLimit-HasSwitchedCD-LastSequenceNumber]         
-- 26JUN11 Mfarouk  - read IsOpenDay, and LastBusinessDate from Teller table      
-- 04AUG11 Hatim AlSum - make left outer join with Teller Config to get Notification flag CR:7482    
-- 24Nov11 Osama Orabi - Stop the validation on the cashdrawer existance. Teller can have no cashdrawer and continue posting transaction     
-- 14Dec11 Osama Orabi - Return IsTeller Flag. This flag will be used on openeing any business transaction (which requires business date).    
--21-02-2013 osama nabil retrieve ad_gb_rsm.user_name as HostLoginID instead of operator.HostLoginID  
-- 03Dec14 Nada Elshafie - Fix issue GFSX08035 - Retrive operator.LanguageLCID   
-- 28Jan15 May Hassan - Enh.GFSY00439 - Retrive TellerConfig.EnableOTP   
-- 24May16 Rokaia Kadry - Enh.GFSY00566 - Retrive TellerConfig.StopValidateGLRestriction 
-- 12FEB19 Mostafa Sayed - Enh.GFSY00749 - Retrive Operator.TCRLoginID and Operator.TCRDeviceID
SET NOCOUNT ON          
DECLARE @IsSignedOn bit          
declare @bankPrev bankID, @regionPrev regionID, @branchPrev branchID -- for error messages          
DECLARE @err int, @brID internal_branch#          
DECLARE @ExpireDate varchar(10)          
declare @WSID WKSTN_ID          
declare @WSLocation nvarchar(12)          
          
declare @Super internal_user_ID, @working_as_u# internal_user_ID, @workingAs OperatorID          
declare @CashDrawer CashDrawerNumber ,@hasCountedCash bit          
declare @CashDrawerSecondary CashDrawerNumber, @SecondaryHasCountedCash bit          
declare @DrawerType varchar(30)          
declare @IsOpenDay bit          
declare @LastBusinessDate smalldate, @year_month smallint, @BusinessDate_Day tinyint    
declare @Reentry bit, @IsReEntryReqSecondary  bit          
declare @next_year_month smallint, @today smalldate, @next_day tinyint          
declare @next_business_date smalldate -- Next BusinessDate after dbo.now()          
declare @BusinessDate SmallDate          
declare @JNLSequence int          
declare @SecondaryDrawerType varchar(30)          
declare @StartingCash money          
declare @TCurrency CurrencyType          
declare @LastBank BankID, @LastRegion RegionID, @LastBranch BranchID          
declare @SignedOnAt MachineName          
declare @IsOpenDayHost bit, @isTeller bit          
          
if @debug > 0          
    print 'In GetAllOperatorInfo'          
          
if @user_number is null          
    set @User_Number = dbo.f_user_number_of_LoginID(@LoginID)          
if @user_number is null begin          
    raiserror(52071, 11, 1, @LoginID) -- Unknown user.          
return -52071          
end          
if @now is NULL          
   SET @now = dbo.now()          
          
          
if (@bank is not null or @region is not null or @branch is not null)          
    --If any one is not null then all must be not null.          
    if (@bank is null or @region is null or @branch is null) BEGIN          
        raiserror('Missing bank, region or branch parameter', 16, 1)          
        return -1          
    END          
          
if @bank is null begin -- Normally bank is passed in.          
    select @bank = B.bank, @region = B.region, @branch = B.branch          
        , @brID = ws.BrID          
    from dbo.Workstations ws          
    join dbo.Branch_Static B          
      on ws.BrID=B.BrID          
    join dbo.OperatorStatus S          
      on ws.WorkStation = S.SignedOnAt          
     and S.user_number = @user_number          
    if @@rowcount > 1 begin          
        raiserror('Developer error allowed %s to sign on to more than one workstation.'          
        , 16, 1, @LoginID)          
        return -16          
    end          
end          
if @bank is null begin          
    set @isSignedOn = 0          
    select TOP 1 @bank = bank, @region = region, @branch = branch          
        , @brID = BrID          
    from dbo.OperatorStatus          
    where user_number = @user_number          
    ORDER BY Last_Branch_Sign_On_Time DESC          
end          
else          
    set @isSignedOn = 1          
              
if @bank is null -- Not signed on and not in OperatorStatus table.          
    select TOP 1 @bank = bank, @region = region, @branch = branch          
        , @brID = BrID          
    from dbo.CashDrawer          
    where AssignedToTeller = @user_number          
    and IsActive = 1          
    ORDER BY ToActive DESC          
          
-- ** CR16140  ** S          
--****************************************************************************          
-- this code seems to be useless          
select @bankPrev = bank, @regionPrev = region, @branchPrev = branch          
from dbo.CashDrawer           
where AssignedToTeller = @user_number          
  AND isActive = 1          
  and NOT (Bank = @bank and Region = @region and Branch = @branch)          
--****************************************************************************          
-- ** CR16140  ** E          
          
-- ** CR16390 ** S          
-- ** CR16390 ** E          
          
-- ** CR16140  ** S          
 Select @WSID = ID, @WSLocation=Location from Workstations          
    where BrId=@brID              
-- ** CR16140  ** E          
          
--if has permission to do teller trans as defined in OperatorRoles.          
IF exists (select 1 from dbo.OperatorRoles OPR          
            JOIN dbo.MTSRole R          
                on R.RoleID = OPR.RoleID          
              and OPR.user_number = @user_number          
              -- ** CR17002 ** S          
              and dbo.isRowActive(R.RowStatus, R.Created, R.ExpirationDate, getdate()) = 1          
              -- ** CR17002 ** E          
              and R.RequiresTellerRow = 1)          
begin          
-- ** CR16140  ** S          
    set @isTeller=1          
    select @working_as_U# = AssignedToTeller           
    FROM dbo.CashDrawer           
    where WorkingForAbsentee = @user_number          
    if @@rowcount > 0          
        select @workingAs = dbo.simple_name_of_LoginID(O.LoginID)          
        from dbo.Operator O           
        where user_number = @working_as_U#          
          
    select @CashDrawer = CD.CashDrawerNumber, @DrawerType = CD.DrawerType          
        , @hasCountedCash = CD.HasCountedCash, @super = CD.WorkingForAbsentee          
    from dbo.CashDrawer CD          
    join dbo.CashDrawerDefinition CDD           
      on CD.DrawerType = CDD.DrawerType          
     and CD.AssignedToTeller = @user_number          
     and CD.Bank = @bank and CD.Branch = @branch and CD.Region = @region          
     and CD.IsActive = 1 and CDD.PrimaryOrSecondary = 'P'          
          
    --Start Mfarouk 26JUN11, read IsOpenDay, and LastBusinessDate  from teller table      
    /*       
    if @@rowcount > 0          
        set @IsOpenDay = 1          
    else          
        set @IsOpenDay = 0          
    select top 1 @LastBusinessDate = T.BusinessDate          
    from dbo.Totals2 T            
    WHERE T.user_number = @user_number          
     and T.Bank=@bank and T.Region=@region and T.Branch=@branch          
    ORDER BY BusinessDate DESC          
    */      
          
      
          
    select top 1 @IsOpenDay = IsOpenDay,@LastBusinessDate =LastBusinessDate      
    from Operator_Status      
  where User_Number = @user_number      
    order by Last_Branch_Sign_On_Time desc      
              
    --select @IsOpenDay = T.IsOpenDay,@LastBusinessDate = dbo.smalldate_of(T.LastBusinessDate)      
    --from dbo.Teller T      
    --where T.User_Number = @user_number      
    --End Mfarouk      
    -- If we are here, the Operator row is not expired.          
          
    set @ReEntry = 0          
    set @IsReEntryReqSecondary  = 0          
    set @today = dbo.smalldate_of(@now)          
    IF @LastBusinessDate >= @today BEGIN -- Could have re-enterable transactions?          
        -- If Teller.LastBusinessDate is null then user has no transactions in the journal.          
        -- If Teller.LastBusinessDate preceeds today,           
        --   then this user has no re-enterable transactions in the journal.          
          
        set @year_month = dbo.yyMM_of_date(@now)           
        set @BusinessDate_Day = DatePart(dd, @now)          
        exec dbo.compute_Date_plus_business_days -- Compute next business date from Calendar table.          
              @today, 1, @bank, @region, @branch, @result = @next_business_date out          
        set @next_year_month = dbo.YYMM_of_SmallDate(@next_business_date)          
          
        if exists (SELECT 1 from dbo.V_Journal_Unposted VJ          
            join dbo.CashDrawer CD           
              on CD.CashDrawerNumber = VJ.CashDrawer          
             and CD.bank = @bank and CD.region = @region and CD.branch = @branch          
             and CD.bank = VJ.bank and CD.region = VJ.region and CD.Branch = CD.Branch          
                and VJ.user_number = @user_number           
                and VJ.Bank = @bank          
                and VJ.Branch = @branch and VJ.Region = @region          
                and VJ.year_month = @year_month          
                and VJ.BusinessDate_Day >= @BusinessDate_Day          
            join dbo.CashDrawerDefinition CDD           
                on CDD.DrawerType = CD.DrawerType          
               and CDD.PrimaryOrSecondary = 'P'          
        )           
            set @ReEntry = 1  -- User has unposted re-enterable trans this month.          
                    -- No need to look at next month.          
        else begin          
            if @next_year_month > @year_month begin  -- Could there be rows in next month?          
        set @next_day = DatePart(dd, dbo.datetime_of_smalldate(@next_business_date))          
                if exists (SELECT 1 from dbo.V_Journal_Unposted VJ          
                join dbo.CashDrawer CD           
                  on CD.CashDrawerNumber = VJ.CashDrawer          
                 and CD.bank = @bank and CD.region = @region and CD.branch = @branch          
                 and CD.bank = VJ.bank and CD.region = VJ.region and CD.Branch = CD.Branch          
                    and VJ.user_number = @user_number           
                    and VJ.Bank = @bank          
                    and VJ.Branch = @branch and VJ.Region = @region          
                    and VJ.year_month = @next_year_month          
                    and VJ.BusinessDate_Day = @next_day          
                join dbo.CashDrawerDefinition CDD on CDD.DrawerType = CD.DrawerType          
                  and PrimaryOrSecondary = 'P'          
                )           
                   set @ReEntry = 1          
            end          
        end          
          
        if exists (SELECT 1 from dbo.V_Journal_Unposted VJ          
            join dbo.CashDrawer CD           
              on CD.CashDrawerNumber = VJ.CashDrawer          
             and CD.bank = @bank and CD.region = @region and CD.branch = @branch          
             and CD.bank = VJ.bank and CD.region = VJ.region and CD.Branch = CD.Branch          
                and VJ.user_number = @user_number           
                and VJ.Bank = @bank          
                and VJ.Branch = @branch and VJ.Region = @region          
                and VJ.year_month = @year_month          
                and VJ.BusinessDate_Day >= @BusinessDate_Day          
            join dbo.CashDrawerDefinition CDD           
                on CDD.DrawerType = CD.DrawerType          
           and CDD.PrimaryOrSecondary = 'S'          
        )           
          set @IsReEntryReqSecondary = 1  -- User has unposted re-enterable trans this month.          
                            -- No need to look at next month.          
        else begin          
            if @next_year_month > @year_month begin  -- Could there be rows in next month?          
                set @next_day = DatePart(dd, dbo.datetime_of_smalldate(@next_business_date))          
                if exists (SELECT 1 from dbo.V_Journal_Unposted VJ          
                join dbo.CashDrawer CD           
                  on CD.CashDrawerNumber = VJ.CashDrawer          
                 and CD.bank = @bank and CD.region = @region and CD.branch = @branch          
                 and CD.bank = VJ.bank and CD.region = VJ.region and CD.Branch = CD.Branch          
         and VJ.user_number = @user_number           
                    and VJ.Bank = @bank          
                    and VJ.Branch = @branch and VJ.Region = @region          
                    and VJ.year_month = @next_year_month          
                    and VJ.BusinessDate_Day = @next_day          
                join dbo.CashDrawerDefinition CDD           
                    on CDD.DrawerType = CD.DrawerType          
                    and CDD.PrimaryOrSecondary = 'S'          
                )          
                   set @IsReEntryReqSecondary  = 1          
            end          
        end          
    END          
          
    if @LastBusinessDate is not null begin          
set @year_month = dbo.YYMM_of_SmallDate(@LastBusinessDate)          
       set @BusinessDate_Day = DatePart(dd, dbo.datetime_of_smalldate(@LastBusinessDate))          
    end           
    else          
        set @year_month = dbo.YYMM_of_date(@now)          
          
    if (@IsOpenDay = 1) begin   -- Get Journal, CashDrawer Info.          
    -- ** CR16971 ** S          
    --  if @LastBusinessDate is null begin          
    --        raiserror(          
    --        '"%s", Teller''s last business date is NULL and Teller has opened day on drawer %d'          
  --        , 16, 1, @LoginID, @CashDrawer)   -- Need to log this because it should never happen.          
    --        return -12          
    --  end          
    -- ** CR16971 ** E       
    -- Osama Orabi [BEGIN: Allowing teller to open application withoug cashdrawer]       
        --if (@CashDrawer is null) BEGIN          
        --      set @CashDrawer = 0           
        --      raiserror(52730, 16, 1) --This should never happen. If it does, it is a developer error.          
        --END          
      -- Osama Orabi [END]    
        set @BusinessDate = @LastBusinessDate          
        set @JNLSequence = 0 /* Sequence number now calculated in real-time by server during transaction submittal */          
          
        select @CashDrawerSecondary = CD.CashDrawerNumber          
        , @SecondaryDrawerType = CD.DrawerType          
  , @SecondaryHasCountedCash = CD.HasCountedCash          
        from dbo.CashDrawer CD          
        join dbo.CashDrawerDefinition CDD           
         on CD.DrawerType = CDD.DrawerType          
        and CD.AssignedToTeller = @user_number          
        and CD.Bank = @bank and CD.Branch = @branch and CD.Region = @region          
        and CD.IsActive = 1 and CDD.PrimaryOrSecondary = 'S'          
          
         -- Discover Currency type from dbo.CashDrawerStart table.          
        select TOP 1 @TCurrency = CurrencyType          
        from dbo.CashDrawerStart           
        where Bank = @bank and Region = @region and Branch = @branch           
        and CashDrawerNumber = @CashDrawer           
        ORDER BY LastChanged DESC          
          
        if @TCurrency is null -- Discover Currency from branch table.          
            select @TCurrency = DefaultCurrency          
            from dbo.Branch_Static          
            where Bank = @bank and Region = @region and Branch = @branch           
          
        select @StartingCash=StartingCash           
        from dbo.CashDrawerStart           
       where Bank = @bank and Region = @region and Branch = @branch           
        and CashDrawerNumber = @CashDrawer           
        and CurrencyType = @TCurrency                 
          
        select top 1 @SignedOnAt=SignedOnAt, @IsOpenDayHost=isnull(IsOpenDayHost,0), @LastBank=Bank, @LastRegion=Region,@LastBranch= Branch          
        from dbo.OperatorStatus          
        where user_number = @user_number          
        ORDER BY SignedOnAt DESC, LastBusinessDate DESC, Last_Branch_Sign_On_Time DESC          
          
        END          
          
end else begin-- not Teller          
    set @isTeller=0          
end          
          
  select           
    @bank as Bank, @region as Region, @branch as Branch          
    -- ** CR17002 ** S          
    , @bank as BankNumber, @region as RegionNumber, @branch as BranchNumber          
    -- ** CR17002 ** E          
    , O.EmployeeID, O.Title, O.LastName, O.FirstName, O.Middle          
    , O.EmailAddress, O.Phone, O.user_number          
    , O.windows_domain, O.StartingApplication, O.LoginID           
    , O.SecondaryLogonID           
    /* Default Teller credentials */          
    --HostLoginID=      Case @isTeller when 1 then O.HostLoginID  else '' end --osama nabil fixing defect#GFSX02707          
    , HostLoginID=      Case @isTeller when 1 then Rtrim(rsm.user_name)  else '' end   
    , HostRegion =      ''          
    , StartingMenu =    case @isTeller when 1 then O.StartingMenu else null end           
    , IsReEntryReq =    cast( (case @isTeller when 1 then @Reentry else  0 end) as bit)          
    , IsHostMode =      cast(0 as bit)          
    , IsOpenDay  =      cast( (case @isTeller when 1 then @IsOpenDay else  0 end) as bit)          
    , IsCustomStatusBit = cast(0 as bit)          
    , UserClassID =     case @isTeller when 1 then O.UserClassID else 99 end          
    , BusinessDate= case @isTeller when 1 then @BusinessDate else NULL end          
    , CashDrawer =    cast( (case @isTeller when 1 then isnull(@CashDrawer,-1) else -1 end) as smallint)          
    , StartingCash =    case @isTeller when 1 then @StartingCash else NULL end          
    , IsDrawerOpenSecondary =cast( (case @isTeller when 1 then isnull(@CashDrawerSecondary,0) else 0 end) as bit)          
    , CashDrawerSecondary = cast( (case @isTeller when 1 then isnull(@CashDrawerSecondary,-1) else -1 end) as smallint)          
    , IsReEntryReqSecondary = cast( (case @isTeller when 1 then  @IsReEntryReqSecondary else 0 end) as bit)          
    , 'UserClassIDName' = case @isTeller when 1 then IsNull(RD.Descriptor, U.[Name]) else null end           
    , dbo.simple_name_of_LoginID(O.LoginID) as LoginIDSimple          
 , @BrID as BrID          
 , cast(0 as int) as LastSequenceNumberOffNetwork          
 , CAST(0 as bit) as IsExceedCashMaxLimit        
 , CAST(0 as bit) as HasSwitchedCD        
 , cast(0 as int) as LastSequenceNumber    
 , TC.CashMax_Notify   
 , TC.EnableOTPLogin as EnableOTPLogin      
 , @isTeller as IsTeller   
 , cast(0 as int) as PostBranch   
 , cast(0 as int) as HostBusinessDate  
 , O.LanguageLCID as LCID  --Nada Elshafie-fixing issue GFSX08035-Retrive operator LCID 
 , TC.StopValidateGLRestriction
 --Mostafa Sayed Begin-CR#GFSY00749 - Assaraya_CRQ12278_TCR
 ,O.TCRLoginID    
 ,O.TCRDeviceID   
 --Mostafa Sayed End-CR#GFSY00749 - Assaraya_CRQ12278_TCR    
  from dbo.Operator O          
  JOIN dbo.User_Classes U           
    ON O.UserClassID = U.ClassID          
  LEFT OUTER JOIN dbo.RulesDescriptor RD          
    ON U.Name_DSC = RD.Name       
    -- 04AUG11 Hatim AlSum - CR:7482 :Start    
  LEFT OUTER Join TellerConfig TC     
    ON TC.User_ID=O.user_number   
 left OUTER JOIN ad_gb_rsm rsm  
    ON rsm.employee_id=O.EmployeeID     
  where O.user_number = @user_number          
  -- 04AUG11 Hatim AlSum - CR:7482 :Finish    
-- ** CR16140  ** E          
set @err = @@error          
if @err = 0           
    exec @err = dbo.GetAllRolesForUser @user_number, @bank, @region, @branch, @now          
return @err          
-- ** CR13901 ** E           
GO
drop_old_proc 'dbo.GetTCRDevices'
go
CREATE PROCEDURE dbo.GetTCRDevices
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2019-02-12
	Reason		: Assaraya_CRQ12278_TCR
    */
    SELECT ID,DeviceName FROM TCRDevices
GO
drop_old_proc 'dbo.Log_TCR_XML'
go
CREATE PROCEDURE dbo.Log_TCR_XML
	@user_nmuber int,
	@bank int,
	@region int,
	@branch int,
	@businessDate date,
	@tranName TransactionName,
	@XML xml,
	@XML_Type nvarchar(20),
	@session_GUID nvarchar(max),
	@TCR_JNL_ID int = null,
	@jnlSequance int = null
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2019-02-12
	Reason		: Assaraya_CRQ12278_TCR
    */
    DELETE FROM TCR_LOG 
    WHERE user_number=@user_nmuber AND Bank=@bank AND Region=@region AND Branch=@branch
		AND BusinessDate=@businessDate AND TranName=@tranName 
		AND Session_GUID=@session_GUID AND XML_Type = @XML_Type
    
    INSERT INTO TCR_LOG(user_number,Bank,Region,Branch,JNLSequance,BusinessDate,InsertTime,TranName,TCR_JNL_ID,XML,XML_Type,Session_GUID)
	VALUES(@user_nmuber,@bank,@region,@branch,@jnlSequance,@businessDate,getdate(),@tranName,@TCR_JNL_ID,@XML,@XML_Type,@session_GUID)
GO
drop_old_proc 'Select_RulesTranConfig'
Go
CREATE PROCEDURE dbo.Select_RulesTranConfig          
@LCID LanguageLCID = NULL ,  
@OnlyShowInAdmin smallint = 1     
As                      
/*                      
 CreationDate: 2004-08-11                      
 OriginalName: dbo.Select_RulesTranConfig                      
 Programmer: Mahmoud Elkabary                      
 Description: Select Transaction Configuration from RulesTranConfig                      
 Output:  Bank, Region, Branch, TranId, TranName, Denom Required, Default_Currency                      
 Assumption:                       
                       
 ModifiedDate: 2004-08-19                      
 Modifer: Mohamed Mustafa                      
 ModifyReason: 1. Adding Currency Count Column                      
   2. Added Sort by TransactionName                      
                      
 ModifiedDate: 2004-08-19                      
 Modifer: Mohamed Mustafa                      
 ModifyReason: Removing Currency Count Column ( Desgin changed )                      
                      
 ModifiedDate: 2004-09-12                      
 Modifer: Mahmoud Elkabary                      
 ModifyReason: Add column AccountigEntries                      
                      
                      
 ModifiedDate: 2004-09-18                      
 Modifer: Mahmoud Elkabary                      
 ModifyReason: Delete columns Bank,Region,Branch from table RulesTranConfig                      
                      
 ModifiedDate: 2004-09-22                      
 Modifer: Mahmoud Elkabary                      
 ModifyReason: Add column AccountCategoryID and Add Column LimitCategoryID                      
                      
 ModifiedDate: 2004-09-23                      
 Modifer: Mahmoud Elkabary                      
 ModifyReason: Add column FeesCategoryID                      
                      
 ModifiedDate: 2004-09-26                      
 Modifer: Mahmoud Elkabary                      
 ModifyReason: Add column ExchangeType                      
                      
 ModifiedDate: 2004-10-10                      
 Modifer: Mahmoud Elkabary                      
 ModifyReason: Add column OffLineAmount                      
                      
 ModifiedDate: 2005-03-03                      
 Modifer: Mahmoud Elkabary                      
 ModifyReason: Add column VerifySignatrue                      
                      
 ModifiedDate: 2005-02-18                      
 Modifer: Mohamed Gad                      
 ModifyReason: Adding some columns (from AllowEmptyAccountingEntries ,....., to BackDatedStaleChequeDays)                      
                     
 ModifiedDate: 2008-02-13                      
 Modifer: Mohamed Gad                      
 ModifyReason: Adding commission group                    
                    
 modifier : hany nasr                   
 date : 8-5-2008                  
 reason : performance tunning                    
                
 modifier : Mariam moneeb                 
 date : 22-12-2008                  
 reason : Remove pre & post sending flags from rulestrancong               
              
 modifier : Amira Kamel                  
 date : 16-4-2009                  
 reason : repalce table LimitCategory with limitstype            
          
Modifier: Hassan E. Halim          
Date : 2011-09-19           
Reason  : Returning DaysAllowedForReversal attribute          
        
Modifier: Lamiaa Mostafa        
Date : 2011-12-22        
Reason  : Retrive Rim Ristriction Package ID        
22Feb2012: Osama Orabi :Return the Local Descriptor According to the passed @LCID      
    
Modifier: Mohammed Farouk    
Date : 2012-05-28    
Reason  : Retrive ReviewVouchersBeforePrinting    
  
Modifier: Amr Salah El-din   
Date : 2012-07-17    
Reason  : Retrive OpenSessionRequired    
  
Modifier: Mohammed Farouk      
Date : 2013-05-15  
Reason  : Retrive ExchangeTypeId, defect GFSX03787  
  
Modifier: Amr Salah El-din   
Date : 2013-08-20    
Reason  : Retrive UpdDateReqired, UpdDateValue, UpdDateAction    

Modifier: Amira Kamel
Date : 2013-12-17    
Reason  : Retrive TranOptionFLD

Modifier: Mohamed Sobhy
Date : 2013-12-19    
Reason  : Retrive CHK_IncludeAccumilative & CHK_AccumilativeInfoMessage

Modifier: Mohammed Farouk   
Date : 2014-01-09  
Reason  : Retrive SupportResend, CBD CR GFSY00321


Modifier: Mohammed Barakat
Date : 2014-02-26
Reason  : Retrive Top 1 of ExchangeTypeId, defect GFSX06584 

Modifer: May Hassan 
Date: 2015-01-14  
ModifyReason: Add column PastDueDtAction, CheckBillPastDueDt  

Modifer: Nada Elshafie
Date: 2017-02-20
ModifyReason: retrieve   WorkOnNightlyModeAllowed GFSY00630


Modifer: Muhammad Mabrouk

Date: 2017-03-22

ModifyReason: retrieve   CheqTypeConfig column GFSY00638


Modifier : Nada Elshafie    
Date  : 2017-07-09
Reason  : Retrieve StaffsRelativeValidation for BIsB  - CRQ13394

Modifier : Mostafa Sayed  
Date  : 2019-02-12
Reason  : CR#GFSY00749 - Retrieve UseTCR column
*/                      
set nocount on                      
                      
 SELECT distinct   rtc.TranID,                      
       ISNULL(LD.LocalDescription,RD.Descriptor) as Descriptor,--rd.Descriptor,                      
       rtc.DenomRequired,                      
       rtc.AccountingEntries,                      
       rtc.DrAccountCategoryID,                      
       ac.name,                      
       rtc.CrAccountCategoryID,                      
       ac2.name,                      
       rtc.LimitCategoryID,       
       lc.LimitTypeName,                      
       rtc.FeesCategoryID,                      
       fc.name as FeesCategory,                      
       rtc.ExchangeType,                      
       et.ExchangeName,                      
       rtc.OffLineAmount,          
       rtc.VerifySignatrue,                      
       rtc.PrintOption,                      
       rtn.TransactionName,                      
       rtc.EnableCharges,                      
  rtc.Blacklisted,                      
       rtc.BlacklistedAction,                      
       rtc.BenPmtStrict,                      
       rtc.BenPmtWarning,                      
       rtc.ShowAvlBal,                      
  GLc.id ,                      
       GLc.Name,                      
       rtc.AllowEmptyAccountingEntries ,                      
       rtc.ReadAllAccountingEntries ,                      
       rtc.SalesMessageActive ,                      
       rtc.ValidateStaleCheque ,                      
       rtc.StaleChequeDefaultDate ,                
       rtc.EscWarningEnabled ,                      
       rtc.ChqRngVal ,                      
       rtc.HasCheckList ,                      
       rtc.AutoPrintPassBook ,                        
       rtc.UseSimpleChargeControl ,                      
       rtc.ForcePositioning ,                      
       rtc.OD_DrAccountCategoryID ,                      
       ac3.Name ,                      
       rtc.CheckListCategoryID ,                      
       chklst.CategoryName ,                      
       rtc.StaleChequeAction ,                      
       rtc.ChqRngAction ,                      
       rtc.FutureStaleChequeDays ,                      
       rtc.BackDatedStaleChequeDays  ,                 
       rtc.TranCommissionGroupID,          
       rtc.DaysAllowedForReversal,        
       atp.Name RimRestrictionName,        
       rtc.Pack_ID RimRestrictionID,    
       rtc.ReviewVouchersBeforePrinting,  
       rtc.OpenSessionRequired,  
     --  et.ExchangeID,
	   /*       Mohamed Barakat Fix */
		(select top(1) et2.ExchangeID from ExchangeType_2 et2
	   where et2.ExchangeType = rtc.ExchangeType ) as ExchangeID,
       rtc.UpdDateReqired,  
       rtc.UpdDateValue,  
       rtc.UpdDateAction ,
       rtc.TranOptionFLD ,
	   rtc.CHK_IncludeAccumilative,
	   rtc.CHK_AccumilativeInfoMessage,
	   rtc.SupportResend,  --CBD CR GFSY00321 
	   rtc.CheckBillPastDueDT,
       rtc.PastDueDTAction  ,
	   rtc.WorkOnNightlyModeAllowed ,
	   CASE rtc.CheqTypeConfig
		WHEN '0' THEN 'Cheque' 
		WHEN '1' THEN 'LCN'  
		WHEN '2' THEN 'Both' 
		ELSE 'Cheque' 
		END as 'CheqTypeConfig',
	   rtc.staffsRelativeValidation,
	   rtc.UseTCR  

                      
 FROM   dbo.RulesTranName as rtn                      
 inner join dbo.RulesTranConfig as rtc                      
 on   rtn.TranID=rtc.TranID                      
 INNER JOIN dbo.RulesDescriptor rd                      
 on  rtn.DSC_Description = rd.DescriptorID      
LEFT OUTER JOIN dbo.RulesDescriptorLocal LD       
 on LD.DescriptorID= RD.DescriptorID       
  and LD.LCID = @LCID      
                       
 left join       dbo.GlCategory as GLc                      
 on              GLc.id=rtc.GLCategoryID                      
 left  outer join dbo.AccountCategory as ac                      
 on  ac.id=rtc.DrAccountCategoryID                      
 left   outer join dbo.AccountCategory as ac2                      
 on  ac2.id=rtc.CrAccountCategoryID                      
                      
 left   outer join dbo.AccountCategory as ac3                      
 on  ac3.id=rtc.OD_DrAccountCategoryID                      
 left   outer join dbo.CheckListCategory as chklst                      
 on  chklst.id=rtc.CheckListCategoryID                        
 --left  outer join dbo.LimitCategory as lc               
  --on  lc.id=rtc.LimitCategoryID                      
 left  outer join dbo.LimitsType as lc                      
 on  lc.LimitTypeID=rtc.TranLimitID                  
               
 left  outer join dbo.FeeCategory as fc            
 on  fc.id=rtc.FeesCategoryID                      
 left  outer join dbo.ExchangeType_2 as et                      
 on  et.ExchangeType=rtc.ExchangeType        
left join AuthTranPackages as atp        
on rtc.Pack_ID = atp.Pack_ID                            
 
 where                        
   ((rtc.ShowInAdmin = @OnlyShowInAdmin) or @OnlyShowInAdmin = -1)                      
 order by                       
   2 -- ISNULL(LD.LocalDescription,RD.Descriptor) as Descriptor, -- rd.Descriptor    

go
drop_old_proc 'Select_RulesTranConfigOne'
Go
create  PROCEDURE [dbo].[Select_RulesTranConfigOne] --exec  Select_RulesTranConfigOne 'CashDeposit'                      
 @TranName varchar(30),  
 @OnlyShowInAdmin smallint = 1                          
                            
As                                
/*                                
 CreationDate: 18 June 2008                              
 OriginalName: dbo.Select_RulesTranConfigOne                                
 Programmer: Mohamed Zaatar                               
 Description: Select Transaction Configuration from RulesTranConfig For One Tran                          
 Assumption:                               
                          
 Modified by : Mohamed Gad                          
 Modification Date : 10-8-2008                          
 Reason : Adding DaysAllowedForRevesral to the result set                            
                          
                          
modifier : Mariam moneeb                           
date : 22-12-2008                            
reason : Remove pre & post sending flags from rulestrancong                          
                        
modifier : Ahmed Hashem                         
date : 14-09-2009                            
reason : Adding cashfollowacctcurr to the result set                        
                          
ModifiedDate: 20-April-2010                        
Modifer: Ahmed Helmi                        
ModifyReason: Add UseFX column to the result.                        
                      
ModifiedDate: 26-April-2010                        
Modifer: Aya Mahmoud                      
ModifyReason: select the CheckDrawerTypeRestrictions from RulesTranConfig                      
                      
Modifying Date: Sept-11-2011                      
Modifer: Mahmod Anis                      
ModifyReason: Selecting the flag (Use_XPath_app) indicating wether CR#7304 should be used or not - from RulesTranConfig                      
               
Modifying Date: 2011-10-09              
Modifer: Mostafa Elbarbary              
ModifyReason: change the order of Use_XPath_app to be the last retrieved column              
                       
Modifying Date: 11-10-2011                      
Modifer: Lamiaa Mostafa                    
ModifyReason: Adding Channel_Id to the result                   
                
Modifying Date: 12-10-2011                      
Modifer: Doaa Nassar                   
ModifyReason: CR# 7438, Adding PrimaryIDExpiryVal and PrimaryIDExpiryAction to the result                  
              
Modifying Date: 19-10-2011                      
Modifer: Hatim Al Sum                    
ModifyReason: CR# 7862, Adding Blacklisted, BlacklistedAction to the result                                  
          
Modifying Date: 22-12-2011                      
Modifer: Lamiaa Mostafa                    
ModifyReason: Adding Pack_ID to the result             
        
Modifying Date: 13/2/2012        
Modifer: Adel Shaban                    
ModifyReason: Adding DaysAllowedForRecovery to the result ==>> Rolled back on 16/2/2012            
    
Modifier: Mohammed Farouk    
Date : 2012-05-28    
Reason  : Retrive ReviewVouchersBeforePrinting   
  
Modifier: Amr Salah El-din    
Date : 2012-07-17    
Reason  : Retrive OpenSessionRequired Column added for CR#9626 KIB   

Modifier: Mohammed El-Masry    
Date : 2012-10-07    
Reason  : Replace LimitCategory with LimitType

Modifier: Mohammed Farouk    
Date : 2013-05-15
Reason  : Retrive ExchangeTypeId, defect GFSX03787

Modifier: Amr Salah El-din    
Date : 2013-08-27
Reason  : Retrive  rtc.UpdDateReqired, rtc.UpdDateValue, rtc.UpdDateAction, rtn.TranCategory --Enhancement #GFSY00273 

Modifier: Mohamed Sobhy
Date : 2013-12-19
Reason  : Retrive  rtc.CHK_IncludeAccumilative, rtc.CHK_AccumilativeInfoMessage

Modifier: Mohammed Farouk   
Date : 2014-01-09  
Reason  : Retrive SupportResend, CBD CR GFSY00321

Modifer: May Hassan 
Date: 2015-01-18  
ModifyReason: Add column PastDueDtAction, CheckBillPastDueDt  

Modifer: May Hassan   
Date: 2015-01-11    
ModifyReason: Add column UseExpressions  

Modifier : Nada Elshafie    
Date  : 2017-03-06
Reason  : Retrieve WorkOnNightlyModeAllowed for CBD - CRQ0000000013504 (retrofit KFH-CRQ000000001959)    

Modifier : Nada Elshafie    
Date  : 2017-07-09
Reason  : Retrieve StaffsRelativeValidation for BIsB  - CRQ13394

Modifier : Mostafa Sayed  
Date  : 2019-02-12
Reason  : CR#GFSY00749 - Retrieve UseTCR column
*/                
                          
set nocount on                                
                                
 SELECT distinct rtc.TranID,                                
   rd.Descriptor,                      
   rtc.DenomRequired,                      
   rtc.AccountingEntries,                                
   rtc.DrAccountCategoryID,                                
   ac.name,                                
   rtc.CrAccountCategoryID,                                
   ac2.name,  
                                 
   --rtc.LimitCategoryID,                                
   rtc.TranLimitID,
   --lc.category,                                
   lt.LimitTypeName ,
   
   rtc.FeesCategoryID,                                
   fc.name as FeesCategory,                              
   rtc.ExchangeType,                                
   et.ExchangeName,                                
   rtc.OffLineAmount,                       
   rtc.VerifySignatrue,                                
   rtc.PrintOption,                                
   rtn.TransactionName,             
   rtc.EnableCharges,                                
   rtc.Blacklisted,                                
   rtc.BlacklistedAction,                                
   rtc.BenPmtStrict,                                
   rtc.BenPmtWarning,                                
   rtc.ShowAvlBal,                  
   GLc.id ,                                
   GLc.Name,                                
                                
   rtc.AllowEmptyAccountingEntries ,                                
   rtc.ReadAllAccountingEntries ,                          
   rtc.SalesMessageActive ,                                
   rtc.ValidateStaleCheque ,          
   rtc.StaleChequeDefaultDate ,                                
   rtc.EscWarningEnabled ,                                
   rtc.ChqRngVal ,                                
   rtc.HasCheckList ,                      
   rtc.AutoPrintPassBook ,                                
   --rtc.PreSendPrinting ,                                
  -- rtc.PostSendPrinting ,                                
   rtc.UseSimpleChargeControl ,                                
   rtc.ForcePositioning ,                                
   rtc.OD_DrAccountCategoryID ,                      
   ac3.Name ,                                
   rtc.CheckListCategoryID ,                                
   chklst.CategoryName ,                                
   rtc.StaleChequeAction ,                                
   rtc.ChqRngAction ,                                
   rtc.FutureStaleChequeDays ,                                
   rtc.BackDatedStaleChequeDays  ,                              
   rtc.TranCommissionGroupID    ,                          
   rtc.DaysAllowedForReversal ,                        
   rtc.cashfollowacctcurr ,                        
   rtc.UseFX  ,                      
   rtc.CheckDrawerTypeRestrictions ,                    
   rtc.use_XPath_app,                  
   rtc.Channel_Id,                
   rtc.PrimaryIDExpiryVal,                
   rtc.PrimaryIDExpiryAction,              
   --CR7862 : start              
   rtc.Blacklisted,              
   rtc.BlacklistedAction,              
   --CR7862 : finish              
   rtc.Pack_ID RimRestrictionID,    
   rtc.ReviewVouchersBeforePrinting,  
   rtc.OpenSessionRequired,
   et.ExchangeID,
   --Amr Salah El-din, 27/8/2013, Apply Enhancement #GFSY00273, Start
   rtc.UpdDateReqired,
   rtc.UpdDateValue,
   rtc.UpdDateAction,
   rtn.TranCategory ,
   --Amr Salah El-din, 27/8/2013, Apply Enhancement #GFSY00273, End
   rtc.CHK_IncludeAccumilative,
   rtc.CHK_AccumilativeInfoMessage,
   rtc.SupportResend,  --CBD CR GFSY00321   
   rtc.CheckBillPastDueDT,
   rtc.PastDueDTAction,
   rtc.UseExpressions,
   rtc.WorkOnNightlyModeAllowed,
   rtc.staffsRelativeValidation,
   rtc.UseTCR               
                                
 FROM   dbo.RulesTranName as rtn                                
 inner join dbo.RulesTranConfig as rtc                                
 on   rtn.TranID=rtc.TranID                                
 INNER JOIN dbo.RulesDescriptor rd                                
 on  rtn.DSC_Description = rd.DescriptorID                                
 left join       dbo.GlCategory as GLc                 
 on              GLc.id=rtc.GLCategoryID                                
 left   outer join dbo.AccountCategory as ac                                
 on  ac.id=rtc.DrAccountCategoryID                                
 left   outer join dbo.AccountCategory as ac2                                
 on  ac2.id=rtc.CrAccountCategoryID                                
                                
 left   outer join dbo.AccountCategory as ac3                                
 on  ac3.id=rtc.OD_DrAccountCategoryID                                
 left   outer join dbo.CheckListCategory as chklst                                
 on  chklst.id=rtc.CheckListCategoryID                                
                                
 --left  outer join dbo.LimitCategory as lc                                
 --on  lc.id=rtc.LimitCategoryID 
  left outer join dbo.LimitsType as lt
  on lt.LimitTypeID = rtc.TranLimitID
                                 
 left  outer join dbo.FeeCategory as fc                                
 on  fc.id=rtc.FeesCategoryID                              
 left  outer join dbo.ExchangeType_2 as et                                
 on  et.ExchangeType=rtc.ExchangeType                                
 where rtc.TranID = ( select Tranid from dbo.Rulestranname where Transactionname = @TranName )                            
and                                  
   ((rtc.ShowInAdmin =  @OnlyShowInAdmin) or @OnlyShowInAdmin = -1)                               
 order by                                 
   rd.Descriptor       
go
Drop_old_proc TCR_Totals_CashInOut
Go
CREATE procedure TCR_Totals_CashInOut  
 @Bank BankID,  
 @Region RegionID,  
 @Branch BranchID,  
 @BusinessDate SmallDate,   
 @currency CurrencyType,
 @deviceID int
as  
-- 12FEB19 Mostafa Sayed - Enh.GFSY00749 - get TCR In and TCR Out buckets amounts
	SELECT BucketID,sum(Amount) as Amount FROM tcr_totals
	where BusinessDate=@BusinessDate and CurrencyType=@currency and TCRDeviceID=@deviceID
	and Branch_unit=dbo.id_of_branch(@Bank,@Region,@Branch)
	group BY BusinessDate,TCRDeviceID,CurrencyType,BucketID
go
Drop_old_proc TCR_Totals_GetBusinessDates
Go
CREATE procedure TCR_Totals_GetBusinessDates  
 @Bank BankID,  
 @Region RegionID,  
 @Branch BranchID,  
 @deviceID int
as  
-- 12FEB19 Mostafa Sayed - Enh.GFSY00749 - get business dates
  select distinct BusinessDate from TCR_totals
  where Branch_unit=dbo.id_of_branch(@Bank,@Region,@Branch) and TCRDeviceID = @deviceID  
  order by BusinessDate desc  
go
Drop_old_proc TCR_Totals_GetCurrency
Go
create procedure TCR_Totals_GetCurrency  
 @Bank BankID,  
 @Region RegionID,  
 @Branch BranchID,  
 @BusinessDate SmallDate,   
 @tcr_deviceID int,  
 @LCID LanguageLCID  
as  
-- 12FEB19 Mostafa Sayed - Enh.GFSY00749 - Pulls distinct list of currencies available for a given bank,region,branch,date,device  
select distinct   
 isnull(isnull(LD.LocalDescription, RD.Descriptor),T.CurrencyType) Descriptor,  
 T.CurrencyType,  
 CT.DSC_CurrencyName DescriptorID  
from dbo.TCR_TOTALS T  
join dbo.CurrencyType CT on CT.CurrencyType = T.CurrencyType  
left join dbo.RulesDescriptor RD on RD.DescriptorID = CT.DSC_CurrencyName  
left join dbo.RulesDescriptorLocal LD on LD.DescriptorID=RD.DescriptorID and LD.LCID=@LCID  
where Branch_unit=dbo.id_of_branch(@Bank,@Region,@Branch)
 and T.BusinessDate=@BusinessDate  
 and T.TCRDeviceID = @tcr_deviceID  
order by T.CurrencyType  
go
drop_old_proc 'Update_RulesTranConfig'
Go

CREATE procedure dbo.Update_RulesTranConfig        
@TranID   varchar(8000),                                    
@DenomRequired  bit,                                    
@ExchangeType varchar(20),                                  
@OffLineAmount money,                              
@AccountingEntries bit,                  
@VerifySignatrue bit,                  
@GLCategoryID int, --                  
@Updator  OperatorID,                                  
@AllowEmptyAccountingEntries bit ,   --7                               
@ReadAllAccountingEntries bit ,                                  
@SalesMessageActive bit ,                                  
@ValidateStaleCheque bit ,                                  
@StaleChequeDefaultDate bit ,                                  
@EscWarningEnabled bit ,                                  
@ChqRngVal bit ,                                
@HasCheckList bit ,                                  
@AutoPrintPassBook bit ,                                  
@UseSimpleChargeControl bit ,                                  
@ForcePositioning int ,                                  
@OD_DrAccountCategoryID int ,   --20                               
@CheckListCategoryID int ,                                  
@StaleChequeAction varchar(50) ,                                  
@ChqRngAction varchar(50) ,                                  
@FutureStaleChequeDays int ,                                  
@BackDatedStaleChequeDays int,         
@DaysAllowedForReversal tinyint,      
@RistrictionPackageID int,    
@ReviewVouchersBeforePrinting bit,  
@OpenSessionRequired bit = 1,  
@UpdSVDateRequired bit = 0,  
@UpdSVDateValue smallint = 1,  
@UpdSVDateAction char = '0',
@TranOptionFLD    field__name = null,
@CHK_IncludeAccumilative  bit = 0, 
@CHK_AccumilativeInfoMessage  bit = 0,
@CheckBillPastDueDt  bit = 0,   
@PastDueDtAction   varchar(50),
@WorkOnNightlyModeAllowed bit = 0 ,
@TranConfigCheqType nvarchar(1) = 'N',
@UseTCR bit = 0
As                                    
/*                                    
CreationDate: 2004-08-11                                    
OriginalName: dbo.Update_RlesTranConfig                                    
Programmer: Mahmoud Elkabary                                    
Description: Update Table RulesTranConfig                                    
Output:                                      
Assumption:                                     
                                    
ModifiedDate: 2004-09-12                                    
Modifer:  Mahmoud ELkabary                                    
ModifyReason: Add AccountingEntries Coulmn                                    
                                    
ModifiedDate: 2004-09-18                                    
Modifer:  Mahmoud ELkabary                                    
ModifyReason: Delete coulmns RulesTranConfig                                    
                                    
ModifiedDate: 2007-02-20                                    
Modifer:      Mohamed Gad                                    
ModifyReason: Adding Updator  parameter to the procedure                                    
                                    
ModifiedDate: 2007-03-28                                    
Modifer:      Mohamed Gad                                    
ModifyReason: To allow Parameter @TranID to exexute correctly  when contain more than one ID                                    
                                  
                                  
ModifiedDate: 2008-02-18                                    
Modifer:      Mohamed Gad                                    
ModifyReason: Updating some params                                    
                                
                                
ModifiedDate: 2008-03-25                                  
Modifer:      Mariam moneeb                                    
ModifyReason: Updating when select all rows                              
                          
ModifiedDate: 2008-09-09                               
Modifer:      Mariam moneeb                                    
ModifyReason: modify @GLCategoryID to be int instead of bit                         
                        
modifier : Mariam moneeb                         
date : 22-12-2008   
reason : Remove pre & post sending flags from rulestrancong              
                        
modifier : Mariam moneeb                         
date : 22-12-2008                          
reason : Remove pre & post sending flags from rulestrancong              
       
modifier : Hassan Ebrahim              
date : 2009-01-29                  
reason : Solving null concatenation problem              
              
Modifier : Amira kamel       
Date:     2010-4-7          
Reason :   change the update statment for ExchangeType            
        
Modifier : Hassan E. Halim        
Date  : 2011-09-15        
Reason  : Adding attribute; DaysAllowedForReversal        
            
Modifier : Lamiaa Mostafa      
Date  : 2011-12-22      
Reason  : Adding Rim Ristriction paramerter          
      
Modifier : Hatim AL Sum       
Date  : 2012-02-02      
Reason  : Increase Size of @SQLString1 to 8000 charachters : Issue #103487  
  
Modifier : Amr Salah Eldin       
Date  : 2012-07-17      
Reason  : update OpenSessionRequired column for CR# 9626 KIB  
  
Modifier : Amr Salah Eldin       
Date  : 2013-08-20      
Reason  : update UpdSVDateRequired, UpdSVDateValue, UpdSVDateAction  

Modifier : Amira Kamel    
Date  : 2012-12-17      
Reason  : update TranOptionFLD column for CR# 304 Barwa 

Modifier : Mohamed sobhy  
Date  : 2012-12-19     
Reason  : update CHK_IncludeAccumilative & CHK_AccumilativeInfoMessage column 

Modifer: May Hassan 
Date: 2015-01-14  
ModifyReason: Add column PastDueDtAction, CheckBillPastDueDt

Modifier : Nada Elshafie
Date  : 2017-03-06
Reason  : update WorkOnNightlyModeAllowed column for CBD - CRQ0000000013504 (retrofit KFH-CRQ000000001959)

Modifer: Muhammad Mabrouk
Date: 2017-03-26  
ModifyReason: Add column CheqTypeConfig

Modifier : Mostafa Sayed  
Date  : 2019-02-12
Reason  : CR#GFSY00749 - Update UseTCR column
*/                                    
begin tran        
--set nocount off 
--if(@TranConfigCheqType = 'N')  
--begin
--	Set @TranConfigCheqType = '0'
--end  
--else if(@TranConfigCheqType = 'Y')  
--begin
--	Set @TranConfigCheqType = '1'
--end   
--else if(@TranConfigCheqType = 'B')  
--begin
--	Set @TranConfigCheqType = '2'
--end                                   
Declare @SQLString char (8000)                                
Set @SQLString = '                                    
UPDATE  RULESTRANCONFIG                                     
SET  '+                       
'DENOMREQUIRED= ' + cast ( @DenomRequired as char) +                                  
',AccountingEntries = ' + cast (@AccountingEntries as varchar(10)) +                                  
',VerifySignatrue = ' + cast (@VerifySignatrue as varchar(10)) +                                  
--',ExchangeType =''' + isnull (cast (@ExchangeType as varchar(20)), 'NULL') +''                                      
',OffLineAmount = ' + cast (@OffLineAmount as varchar(10)) +                                  
',GLCategoryID = ' + isnull (cast (@GLCategoryID as varchar(10)), 'NULL') +                                  
',AllowEmptyAccountingEntries =  '+ cast (@AllowEmptyAccountingEntries as varchar(10)) +                                  
',ReadAllAccountingEntries =  '+ cast (@ReadAllAccountingEntries as varchar(10)) +                                  
',SalesMessageActive =  '+ cast (@SalesMessageActive as varchar(10)) +                                  
',ValidateStaleCheque =  '+ cast (@ValidateStaleCheque as varchar(10)) +                                  
',StaleChequeDefaultDate =  '+ cast (@StaleChequeDefaultDate as varchar(10)) +                                  
',EscWarningEnabled =  '+ cast (@EscWarningEnabled as varchar(10)) +                                  
',ChqRngVal =  '+ cast (@ChqRngVal as varchar(10)) +                                  
',HasCheckList =  '+ cast (@HasCheckList as varchar(10)) +                                  
',AutoPrintPassBook =  '+ cast (@AutoPrintPassBook as varchar(10)) +                                  
',UseSimpleChargeControl =  '+ cast (@UseSimpleChargeControl as varchar(10)) +                                  
',ForcePositioning =  '+ cast (@ForcePositioning as varchar(10)) +                                  
',OD_DrAccountCategoryID =  '+ isnull (cast (@OD_DrAccountCategoryID as varchar(10)) , 'NULL') +                                  
',CheckListCategoryID =  '+ isnull (cast (@CheckListCategoryID as varchar(10)), 'NULL') +                                  
',StaleChequeAction =  '''+ cast (@StaleChequeAction as varchar(10)) +                                  
''',ChqRngAction =  '''+ cast (@ChqRngAction as varchar(10)) +                                  
''',FutureStaleChequeDays =  '+ cast (@FutureStaleChequeDays as varchar(10)) +                                  
',BackDatedStaleChequeDays =  '+ cast (@BackDatedStaleChequeDays as varchar(10)) +          
',DaysAllowedForReversal =  '+ cast (@DaysAllowedForReversal as varchar(10)) +        
',Pack_ID =  '+ isnull (cast (@RistrictionPackageID as varchar(10)), 'NULL') +                                 
',ReviewVouchersBeforePrinting =  '+ isnull (cast (@ReviewVouchersBeforePrinting as varchar(10)), 'NULL') +  
',OpenSessionRequired = '+ cast (@OpenSessionRequired as varchar(10)) +  
',UpdDateReqired = '+ cast (@UpdSVDateRequired as varchar(10)) +  
',UpdDateValue = '+ cast (@UpdSVDateValue as varchar(10)) +  
',UpdDateAction = '+ cast (@UpdSVDateAction as varchar(10)) +                                
',TranOptionFLD = '''+ cast(@TranOptionFLD as varchar(31))  +   ''''+
 ',CHK_IncludeAccumilative = '+ cast ( @CHK_IncludeAccumilative  as char)  +                               
 ',CHK_AccumilativeInfoMessage = '+ cast ( @CHK_AccumilativeInfoMessage  as char)   + 
 ',CheckBillPastDueDt = '+ cast ( @CheckBillPastDueDt  as char)   + 
 ',PastDueDtAction =  '''+ cast (@PastDueDtAction as varchar(10)) + ''''+ 
 ',WorkOnNightlyModeAllowed = '+ cast ( @WorkOnNightlyModeAllowed  as char)   +
', Updator = ''' + @Updator  +  
''', CheqTypeConfig = ''' + @TranConfigCheqType  +
''', UseTCR = ' + cast ( @UseTCR as char) +            
--''' WHERE TranID in (' + cast ( @TranID as varchar) +')'                                 
--marim 25-03-2008                                 
' WHERE TranID in (' + @TranID +')'         
--select   @SQLString                               
exec (  @SQLString )                                          
--Hatim Al Sum Issue#103487 : start      
--Declare @SQLString1 char (300)                                
Declare @SQLString1 char (8000)                                
--Hatim Al Sum Issue#103487 : finish        
        
if(@ExchangeType=''or @ExchangeType is null)        
begin         
 Set @SQLString1 = ' update RULESTRANCONFIG        
 set ExchangeType = null         
 WHERE TranID in (' + @TranID +')'        
end        
else        
begin        
 Set @SQLString1 = 'update RULESTRANCONFIG        
 set ExchangeType = ''' + cast (@ExchangeType as varchar(20)) +'''         
 WHERE TranID in (' + @TranID +')'        
end                                    
exec (  @SQLString1 )            
if(@@error<>0)                                   
begin                                    
 rollback tran                                    
 return -1                                    
end                                    
else                                    
begin                                    
 commit tran                                  
 return 0                                    
end 
go


drop_old_proc 'dbo.Update_TCR_JNLSequance'
go
CREATE PROCEDURE dbo.Update_TCR_JNLSequance
	@user_nmuber int,
	@bank int,
	@region int,
	@branch int,
	@businessDate date,
	@tranName TransactionName,
	@session_GUID nvarchar(max),
	@jnlSequance int = null
AS
	/*
	Developer	: Mostafa Sayed
	Date		: 2019-02-12
	Reason		: Assaraya_CRQ12278_TCR
    */
    UPDATE TCR_LOG
    SET JNLSequance=@jnlSequance
    WHERE user_number=@user_nmuber AND Bank=@bank AND Region=@region AND Branch=@branch
		AND BusinessDate=@businessDate AND TranName=@tranName AND Session_GUID=@session_GUID
GO
Drop_old_proc write_tcr_totals
Go
create proc write_tcr_totals
     @Bank   BankID
    ,@Region RegionID
    ,@Branch BranchID
    ,@user_number internal_user_ID
    ,@BusinessDate SmallDate
    ,@Correction bit
    ,@BucketID  Bucket_ID
    ,@Amount    money
    ,@ctype     CurrencyType
    ,@Batch     int
    ,@Counter   int
    ,@debug     int = 0
    ,@TransactionTime datetime = null
	,@BrID hierarchy_node# = null
AS
-- 12FEB19 Mostafa Sayed - Enh.GFSY00749 - write TCR totals to TCR_Totals table
set nocount on
if @BrID is null
	select @BrID = dbo.id_of_branch(@Bank,@Region,@Branch)  

if @TransactionTime is null set @TransactionTime=getdate()
declare @deviceID int
exec @deviceID = dbo.get_tcr_deviceID @user_number
if @Amount = 0
    return 0 -- Do not insert or update if the Amount parameter is zero.
IF @BucketID = 12059 or @BucketID = 12060
UPDATE dbo.TCR_Totals WITH (UPDLOCK ROWLOCK)
set  Counter = Counter + @Counter
    ,Amount = Amount + @Amount
    ,TransactionTime = case when @TransactionTime > isnull(TransactionTime,0) 
                            then @TransactionTime else TransactionTime end
where 
		Branch_unit = @BrID
     and BusinessDate = @BusinessDate
     and user_number = @user_number
     and BucketID = @BucketID
     and CurrencyType = @ctype
     and Batch = @Batch
if @@rowcount = 0 begin
    if @debug > 1 
        select 'inserting ' + cast(@BucketID as varchar) as bucketID
            ,@cType as ctype, @Batch as batch 
    if (@Correction = 0 and (@BucketID = 12059 or @BucketID = 12060)) 
        insert dbo.TCR_Totals WITH (UPDLOCK ROWLOCK) (
			 Branch_Unit
			 ,BusinessDate
            ,user_number,BucketID,CurrencyType,Batch 
            ,Counter,Amount,TransactionTime,TCRDeviceID
        )values(
			 @BrID
			 ,@BusinessDate
            ,@user_number,@BucketID,@ctype,@Batch
            ,@Counter,@Amount,@TransactionTime,@deviceID
        )
    else  begin
        declare @BusinessDateString varchar(30)
        set @BusinessDateString = cast(@BusinessDate as varchar)
        print 'raising error'
        raiserror('Can not find Totals2 record to correct for Bank %d, Region %d, Branch %d
                ,BusinessDate %s,Teller %d, BucketID %d, Currency %s, Batch %d.'
                ,9,1,@Bank,@Region,@Branch,@BusinessDateString,@user_number,@BucketID
                ,@ctype,@Batch)
        return -16
    end
end
return 0

Go
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc write_totals
Go
create proc write_totals
     @Bank   BankID
    ,@Region RegionID
    ,@Branch BranchID
    ,@user_number internal_user_ID
    ,@BusinessDate SmallDate
    ,@CashDrawerNumber CashDrawerNumber
    ,@Correction bit
    ,@BucketID  Bucket_ID
    ,@Amount    money
    ,@ctype     CurrencyType
    ,@Batch     int
    ,@Counter   int
    ,@debug     int = 0
    ,@TransactionTime datetime = null
	,@BrID hierarchy_node# = null
AS
-- Insert or Update a totals bucket for the user-day.
-- See also: Update_Totals_Bucket and update_totals_array (which calls this).
-- Copyright 2006 GetronicsWang Co., LLC.  All rights reserved.
-- 22Mar06 Bodhi Version 1. 
-- 27FEB08 Bodhi - Do not insert or update if the Amount parameter is zero, unless bucket is "starting cash".
-- 09Jul08   TimG - CR17241 Add update of TransactionTime
-- 2014-07-21: Osama Orabi: Issue# GFSX07456: 2.0.46.1319. Enhance the performane by passing the BrID to write to Totals Directly instead of Totlas_2 or V_Old_Totals.
-- 12FEB19 Mostafa Sayed - Enh.GFSY00749 - call dbo.write_tcr_totals to write TCR totals to TCR_Totals table
set nocount on
if @BrID is null
	select @BrID = dbo.id_of_branch(@Bank,@Region,@Branch)  

if @TransactionTime is null set @TransactionTime=getdate()
-- ** CR16965 ** S
if @Amount = 0 and @BucketID <> 12042
    return 0 -- Do not insert or update if the Amount parameter is zero.
IF @BucketID <> 12042 -- Starting cash may not be updated, only inserted.
-- ** CR16965 ** E
UPDATE dbo.Totals WITH (UPDLOCK ROWLOCK)
set  Counter = Counter + @Counter
    ,Amount = Amount + @Amount
    ,TransactionTime = case when @TransactionTime > isnull(TransactionTime,0) 
                            then @TransactionTime else TransactionTime end
where 
		--Bank = @Bank
  --   and Region = @Region
  --   and Branch = @Branch
		Branch_unit = @BrID
     and BusinessDate = @BusinessDate
     and user_number = @user_number
     and CashDrawerNumber = @CashDrawerNumber
     and BucketID = @BucketID
     and CurrencyType = @ctype
     and Batch = @Batch
if @@rowcount = 0 begin
    if @debug > 1 
        select 'inserting ' + cast(@BucketID as varchar) as bucketID
            , @CashDrawerNumber as drawer, @cType as ctype, @Batch as batch 
    if (@Correction = 0) 
        insert dbo.Totals WITH (UPDLOCK ROWLOCK) (
             --Bank,Region,Branch,
			 Branch_Unit
			 ,BusinessDate
            ,user_number,CashDrawerNumber,BucketID,CurrencyType,Batch 
            ,Counter,Amount,TransactionTime
        )values(
             --@Bank,@Region,@Branch,
			 @BrID
			 ,@BusinessDate
            ,@user_number,@CashDrawerNumber,@BucketID,@ctype,@Batch
            ,@Counter,@Amount,@TransactionTime
        )
    else  begin
    -- ** CR14674 ** S
        declare @BusinessDateString varchar(30)
        set @BusinessDateString = cast(@BusinessDate as varchar)
    -- ** CR14674 ** E
        print 'raising error'
        raiserror('Can not find Totals2 record to correct for Bank %d, Region %d, Branch %d
                ,BusinessDate %s,Teller %d, BucketID %d, Currency %s, Batch %d.'
                ,9,1,@Bank,@Region,@Branch,@BusinessDateString,@user_number,@BucketID
                ,@ctype,@Batch)
        return -16
    end
end

exec dbo.write_tcr_totals 
	 @Bank
    ,@Region
    ,@Branch
    ,@user_number
    ,@BusinessDate
    ,@Correction
    ,@BucketID
    ,@Amount
    ,@ctype
    ,@Batch
    ,@Counter
    ,@debug
    ,@TransactionTime
	,@BrID
return 0

Go
--End of Automatic Generation
Drop_Old_Proc 'Insert_ClearDetail'
GO
Create PROCEDURE dbo.Insert_ClearDetail                  
 @Grid    as varchar(8000),                                
 @AccountNumber  as AccountNumber,                                
 @Branch    as BranchID,                                
 @User_Number  as internal_user_ID,                                
 @Narrative   as nvarchar(40),                                
 @ChequeTypeStatusID as int,                                
 @BusinessDate   as BusinessDate='1900/01/01',                                
 @ShadowAccType  as char(3)='',  --Marwa Arafat                                
 @ShadowAccNo  as AccountNumber='',--Marwa Arafat                                
 @AccountCurrency as CurrencyType='', --Marwa Arafat                                
 @AccountType  as char(3)='',  --Marwa Arafat                                
 @AccountAppType  as varchar(50)='', --Marwa Arafat                                
 @ShadowAccCurrency as CurrencyType='', --Marwa Arafat                                
 @ShadowAccAppType as varchar(50),  --Marwa Arafat                                
 @AccountStatus  as varchar(30),    --Marwa Arafat                        
 @FloatWithProfile     as bit = 0,  --Kareem Ezz                                    
 @ForUtility   as bit = 0,                                      
 @ForCreditCardPayment   as bit = 0,                            
 @ForStockMarketPayment   as bit = 0,              
 @AccountBranch      as BranchID = NULL,--mfarouk. save OutClearing account branch no to be used in FloatDatesAmend transaction              
 --@RefNo  as varchar(20)  
  @RimNumber as  int  = -1                               
AS                                
/*Version 2.00.46.20.11 Modification Date : 2016-08-15*/

/*                                
CreationDate: 2004-11-18                                
OriginalName: dbo.Insert_ClearDetail                                
Programmer: Mahmoud Elkabary                                
Description: Insert Out of Clear Cheques into ClearDetail and set status by Deposited                                
Output:                                  
Assumption:                                 
                                
ModifiedDate: 21/5/2006                                
Modifer:  mkandiel                                
ModifyReason: CR 31 BIB                                
                                
ModifiedDate: 06/12/2006                                
Modifer  :Mfattah                                
ModifyReason: Convert all text status to numbers                                
                                
ModifiedDate: 27/12/2006                                
Modifer: Ahmed Rafat                                
ModifyReason: Add GL and Routing numbers                                
                                
ModifiedDate: 11/01/2007                                
Modifer: Mohamed Gad                                
ModifyReason: Replacing the stars in the GL number with the current branch code                                 
                                
ModifiedDate: 12/02/2007                                
Modifer: Maie kandiel                                
ModifyReason: adding refno to tgrid as it is updated in the TPI step                                 
                                
ModifiedDate: 19/3/2007                                
Modifer: arafat                                
ModifyReason: cancel check if cheques exist                                
                                
ModifiedDate: 20/6/2007                                
Modifer: mzaatar                                
ModifyReason: cancel check if cheques exist                                
                                
ModifiedDate: 29/8/2007                                
Modifer: Marwa Arafat                                
ModifyReason: Update Shadow Account No and Type                                
                              
ModifiedDate: 05/12/2007                                
Modifer: Shimaa Saeed                                
ModifyReason: Add Chequedate And Creator to the grid                          
                          
Changed by:      Alaa Amer                          
Changed Date:    24-04-2008                          
Changed Reasons: Performance Enhancement                              
                        
Changed by:      Hatem Noaman                        
Changed Date:    07-06-2008                          
Changed Reasons: Add @ForCreditCardPayment,@ForStockMarketPayment                          
                      
Changed by:      Kareem Ezz                      
Changed Date:    14-09-2009                          
Changed Reasons: Add @FloatWithProfile  indicate the account has a profile in table CustomerPurChequesProfile                      
                  
                  
Changed by:      Adel Shaban                  
Changed Date:    12/3/2009                  
Changed Reasons: Uncomment the inserting statements of ChequeDate and Creator Fields                  
                  
Modifier: Hisham Nassef                  
Date:  2009-04-09                  
Reason:  1. Using Next_Table_MaxID procedure to generate id and TxnID                  
   2. Changing the text in proper and readable SQL statements                  
                
Modifier: Hoda Sayed                  
Date:  2010-06-27                
Reason: Insert Customer Cheque Reference                
              
ModifiedDate: 2010-08-04                        
Modifer: Mohammed Farouk                     
ModifyReason:  save customer account branch no, to be used in transaction 'FloatDatesAmend' when updating value date               
    based on account branch criteria ADIB CR 5766              
                
Modifier: Amira kamel                  
Date:  2010-0-08                
Reason:  CR # 5850 --Insert ISCertifiedCheque           
          
Modifier: Mohammed Farouk          
Date:  2012-08-23                
Reason:  CR # 9636 --change   DrawerAccNumber to be varchar (40) to support IBAN numbers  

Modifier: Muhammad Mabrouk            
Date:  2016-01-12                  
Reason:  CR # 9636 -- Adding RIM Number to the insert   

ModifiedDate: 	2016/08/15
Modifer:  		Mahmoud Kamel   
ModifyReason: 	Issue#GFSX10968 -  Setting ClearBankName and RimNumber       

ModifiedDate: 	05-1-2017
Modifer:  		Mostafa Abdlrazek
ModifyReason: 	CR#GFSY00614 ADIB_CRQ7501_xp - Cmdshell Alternative - Core System Intregration 

ModifiedDate: 	08-05-2019
Modifer:  		Mahmoud Saad   
ModifyReason: 	Issue#GFSX13649  

*/                                
                                
set nocount on                     
                                
begin Transaction                          
                                     
--Declare @Status varchar(30)                                
--set @Status='Deposited'                                
                                
Declare @Status int                                
set @Status=1                                
                                
declare @y int                            
set @y = 0                                
while ((select t.IsInProcess from dbo.TableLock as t Where t.TableName = 'ClearDetail') <> 0 or                         
 (select t.IsInProcess from dbo.TableLock as t Where t.TableName = 'TableID') <> 0 )                                
begin                                
 if(@y = 120) return -1 -- timeout                                
 set @y = @y + 1                                
 waitfor delay '00:00:01'                                
end                                
                                
update dbo.TableLock set dbo.TableLock.IsInProcess = 1 Where dbo.TableLock.TableName = 'ClearDetail'                                
update dbo.TableLock set dbo.TableLock.IsInProcess = 1 Where dbo.TableLock.TableName = 'TableID'                                
                                
                                
declare @RowDelimiter  char(1),                           
 @ColDelimiter  char(1),                                
 @RowPos   int,                                
 @ColPos   int,                                
 @i   int,                                
 @j   int,                                
 @DataRow  varchar(350),                                
 @ColCount  int,                                
 @RowNumber  int,                                
 @ValueDate  smalldatetime,                                
 @tRefNo   varchar(20)  ,
 @ClearBankName	nvarchar(250)                             
                                 
declare @tGrid table (                                
 ChequeNumber  varchar(15)   NULL,                                
 DrawerAccNumber  varchar(40)   NULL,                               
 ChequeAmount  money     NULL,                                
 ClearBankBranchID  int     NULL,                      
                     
                                      
 ValueDate   smalldatetime   NULL,                                
 RowID    int     NULL,                                
 ClearCenter   int     NULL,                                
 ClearBillNumber  varchar(24)   NULL,                                
 SourceOfCheque  varchar(50)   NULL,                                
 Other    varchar(50)   NULL,                                
 Narrative   varchar(40)   NULL,                                
 AfterCutoffTime  varchar(10)   NULL,                                
 RoutingNo   varchar(16)   Null,                                
 GLNumber   varchar(60)   Null,                                
 ProviderID   smallint   NULL,                                
 tRefNo    varchar(20)   NULL,                                
 charges    money    NULL ,--mzaatar                                
                                
        ChequeDate   smalldatetime   NULL ,--ShimaaSaeed                                
        Creator                     nvarchar(40),                
CustomerReference varchar(20),            
ISCertifiedCheque   varchar(10), -- Amira kamel [8/8/2010]  
ClearDetailName      varchar(250)                       
 )                                
                                
                                
Declare @RowID     int                                
Declare @Txn    int                                
Declare @ChequeNumber   varchar(15),                                
  @ClearBankBranchID  int,                                
  @DrawerAccNumber  varchar(40)              
               
                                
DECLARE @InputString   varchar(60)                                
DECLARE @InputStringIndex INT;                                
DECLARE @BranchIndex  INT;                                
DECLARE @TempStr    NVARCHAR(1);                            
                                
-- set @RowID = (select b.LastValue from dbo.TableID as b where lower(b.TableName) ='cleardetail' and lower(b.FieldName)='id')                                
                  
exec Next_Table_MaxID 'ClearDetail', 'id', @RowID output                  
                                
--if(@RowID is null)                                
--begin                                
-- insert into dbo.TableID(TableName,FieldName,LastValue) values('cleardetail','id',0)                                
-- if(@@error<>0)                                
-- begin                                
--  Rollback Transaction                                
--  return 0                                
-- end                                
-- set @RowID = 0                                
--end                                
                                
-- set @Txn = (select b.LastValue from dbo.TableID as b where lower(b.TableName) ='cleardetail' and lower(b.FieldName)='txnid')                                
                  
exec Next_Table_MaxID 'ClearDetail', 'TxnID', @Txn output                  
                  
--if(@Txn is null)                                
--begin                                
-- insert into dbo.TableID(TableName,FieldName,LastValue) values('cleardetail','txnid',0)                                
-- if(@@error<>0)                                
-- begin                                
--  Rollback Transaction                                
--  return 0                                
-- end                                
-- set @Txn = 0                                
--end                                
                                
                                
--set @Txn = @Txn + 1                  
                                
set @RowDelimiter = '|'           
set @ColDelimiter = ','                                
set @i = 1                                
set @RowPos = charindex(@RowDelimiter, @Grid, @i)                                
set @ColPos = 0                                
set @ColCount = 0                                
set @RowNumber = 0                                
                                
while (@RowPos > 0) -- row tabel                                
begin                           
 set @j = 1                                
 set @DataRow = substring(@Grid, @i, @RowPos-@i)+@RowDelimiter                                
 set @ColPos = charindex(@ColDelimiter, @DataRow, @j)                                
                              
 insert into @tGrid select null,null, null, null, null, null, null, null, null, null, null , null , null , null , null , null ,null,null,null,null ,null ,null                               
               
 set @ColCount = 0                                
 -- set @RowID = @RowID + 1                  
 set @RowNumber = @RowNumber + 1                                 
                             
 update @tGrid set RowID = @RowID where RowID is null                                
                                
 while (@ColPos > 0) -- column table                  
 begin                  
  set @ColCount = @ColCount + 1                  
                  
  if (@ColCount = 1)                                
  begin               update @tGrid set ChequeNumber = substring(@DataRow, @j, @ColPos-@j) where ChequeNumber is null                                
   set @ChequeNumber = substring(@DataRow, @j, @ColPos-@j)                                
  end                                
  else if (@ColCount = 2)                                
  begin                                
   update @tGrid set DrawerAccNumber = substring(@DataRow, @j, @ColPos-@j) where DrawerAccNumber is null                                
   set @DrawerAccNumber=substring(@DataRow, @j, @ColPos-@j)                                 
  end                                
  else if (@ColCount = 3)                                
  begin                                
   update @tGrid set ChequeAmount = cast(substring(@DataRow, @j, @ColPos-@j) as money) where ChequeAmount is null                                   
  end                                
  else if (@ColCount = 4)                                  
  begin                                  
   update @tGrid set ClearBankBranchID = substring(@DataRow, @j, @ColPos-@j) where ClearBankBranchID is null                                
   set @ClearBankBranchID = substring(@DataRow, @j, @ColPos-@j)  
   --MAhmoud Saad Issue # GFSX13649         
   
   SELECT @ClearBankName = B.ClearBankName
   From   dbo.ClearBank B with(nolock)
   left  Join dbo.ClearBankBranch BR with(nolock)
   On BR.ClearBankCode=B.ClearBankCode
   WHERE BR.ClearBankBranchID = @ClearBankBranchID

  update @tGrid set ClearDetailName = @ClearBankName where ClearDetailName is null                                
   --MAhmoud Saad Issue # GFSX13649             
  end               
  else if (@ColCount = 5)                                  
  begin                                
   update @tGrid set ClearCenter = cast(substring(@DataRow, @j, @ColPos-@j)as int) where ClearCenter is null                                
  end                                
  else if (@ColCount = 6)                                   
  begin                                
   update @tGrid set ValueDate = cast(substring(@DataRow, @j, @ColPos-@j)as smalldatetime) where ValueDate is null                                
  end                                
  else if (@ColCount = 7)                                   
  begin                                
   if (substring(@DataRow, @j, @ColPos-@j) <> 'NULL')                                
    update @tGrid set ClearBillNumber = substring(@DataRow, @j, @ColPos-@j) where ClearBillNumber is null                                
  end                                
  else if (@colCount = 8)                                
  begin                                
   update @tGrid set SourceOfCheque = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where SourceOfCheque is null                                
  end                                
  else if (@colCount = 9)                                
  begin                                
   update @tGrid set Other = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where Other is null                                
  end                                
  else if (@colCount = 10)                                
  begin                                
   update @tGrid set Narrative = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where Narrative is null                                
  end                                
  else if (@colCount = 11)                                
  begin                             
   update @tGrid set AfterCutoffTime = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where AfterCutoffTime is null                                
  end                                
  else if (@colCount = 12)                                
  begin                                
   update @tGrid set ProviderID = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where ProviderID is null                                
  end                                
  else if (@colCount = 13)                                
  begin                                
   update @tGrid set RoutingNo = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where RoutingNo is null                                     
  end                                
  else if (@colCount = 14)                                
  begin                                              
   --Gad 11-1-2007                                
   set @InputString = cast(substring(@DataRow, @j, @ColPos-@j)as varchar)                                
                                  
   set @InputStringIndex = LEN(@InputString)                                
   set @BranchIndex = LEN(@Branch)                                
   set @TempStr = '';                                
                                    
   while(@InputStringIndex >0)                                
   begin                                
    set @TempStr = SUBSTRING(@InputString, @InputStringIndex, 1);                                
                  
    if(@TempStr = '*')                                
    begin                                
     if(@BranchIndex > 0)                                
     begin                                
      set @InputString = STUFF(@InputString, @InputStringIndex, 1, SUBSTRING(CAST ( @Branch AS VARCHAR ), @BranchIndex, 1))                                
      set @BranchIndex = @BranchIndex - 1                                
     end                                
     else                                
     begin                            
      set @InputString = STUFF(@InputString, @InputStringIndex, 1, 0)                                
     end                                
    end                                
                                     
    set @InputStringIndex = @InputStringIndex - 1;                                
   end                                
                                
   update @tGrid set GLNumber = @InputString  where GLNumber is null                                
   ----------------------------------------------------------                                
  end                                
  else if (@ColCount = 15)                                   
  begin                                
   update @tGrid set tRefNo = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where tRefNo is null                 
  end                                
  --Mzaatar 20-6-2007-----                                 
  else if (@ColCount = 16)                                   
  begin                                
   update @tGrid set Charges = cast(substring(@DataRow, @j, @ColPos-@j)as money) where Charges is null                                
  end                                
  -------------------                                
               --ShimaaSaeed 04/12/2007-----                                 
  else if (@ColCount = 17)                                   
  begin                                
   update @tGrid set ChequeDate = cast(substring(@DataRow, @j, @ColPos-@j)as smalldatetime) where ChequeDate is null                                
  end                                
  -------------------                                
                                
               --ShimaaSaeed 04/12/2007-----                                 
  else if (@ColCount = 18)                         begin                                
   update @tGrid set Creator = cast(substring(@DataRow, @j, @ColPos-@j)as nvarchar) where Creator is null                                
  end                                
  -------------------                                    
  --Hoda Sayed [27-06-2010]                
  else if (@ColCount = 19)                                   
  begin                                
   update @tGrid set CustomerReference = cast(substring(@DataRow, @j, @ColPos-@j)as nvarchar) where CustomerReference is null                                
  end                                
  -------------------              
  --Amira kamel [8/8/2010] -- [CR # 5850 -- Add certified routing number ]            
  else if (@colCount = 20)                                
  begin                                
   update @tGrid set ISCertifiedCheque = cast(substring(@DataRow, @j, @ColPos-@j)as varchar) where ISCertifiedCheque is null                                
  end                
  ---------------------                                 
   
      
  set @j = @ColPos+1                                
                                
  if (@ColCount < 20)                                
  begin                                
   set @ColPos = charindex(@ColDelimiter, @DataRow, @ColPos+1)                                
  end                                 
  else if (@ColCount = 20)                                
  begin                                
   set @ColPos = 0                                
                                
   if ( @ForUtility = 1)                                
   begin                                
    if exists ( select  cd.ChequeNumber                                
       from dbo.ClearDetail as cd                                
       where cd.ChequeNumber = @ChequeNumber                  
       and  cd.AccountNumber = @AccountNumber                  
       and  cd.ClearBankBranchID = @ClearBankBranchID                  
       and  cd.ChequeTypeStatusID = @ChequeTypeStatusID)                  
    begin                                
     Rollback Transaction                                
     return -1                                
    end                                
   end                                
  end                                
 end -- end of column                                
                                
 set @i = @RowPos+1                                
 set @RowPos = charindex(@RowDelimiter, @Grid, @i+1)                     
                  
 if (@RowPos > 0)                  
  exec Next_Table_MaxID 'ClearDetail', 'id', @RowID output                  
end -- end of rows                  
    --Commented By MAhmoud Saad Issue # GFSX13649                            
--ITS Code Start [Mahmoud Kamel - 2016/08/15] Issue#GFSX10968 -  Setting ClearBankName and RimNumber
--DECLARE @ClearBankName	nvarchar(250);

--SELECT @ClearBankName = B.ClearBankName
--From   dbo.ClearBank B with(nolock)
--left  Join dbo.ClearBankBranch BR with(nolock)
--On BR.ClearBankCode=B.ClearBankCode
--WHERE BR.ClearBankBranchID = @ClearBankBranchID
--ITS Code End [Mahmoud Kamel - 2016/08/15] Issue#GFSX10968 -  Setting ClearBankName and RimNumber                                   
           --Commented By MAhmoud Saad Issue # GFSX13649                 
Insert Into dbo.ClearDetail(                  
  [ID],                                
  ChequeNumber,                                
  DrawerAccNumber,                                
  ChequeAmount,                                  
  TxnID,                                
  AccountNumber,                                
  ClearBankBranchID,                                
  Status,                                
  Branch,                                
  User_Number,                                
  ValueDate,                                
  Narrative,                                
  ChequeTypeStatusID,                            
  BusinessDate,                                
  RefNo,                                
  ClearingCenter,                                
  ClearBillNumber,                         
  SourceOfCheque,                                
  Other,                                
  AfterCutoffTime,                                
  Routing_No,                                
  GLNumber,                                
  ProviderID,                         
  Charges ,                              
  --mzaatar                                
  ChequeDate,                                
  Creator,                                
  ForUtilityPayment,                            
  ForCreditCardPayment, --H. Noaman                                
  ForStockMarketPayment,--H. Noaman                        
  FloatWithProfile,                
  CustomerReference,              
  AccountBranch,            
  ISCertifiedCheque,
  RIM_No,  --- Muhammad Mabrouk ADIB 101_CR_GFSY00544_2_OutClearingCR   12-1-2016                  
  ClearBankName)  --[Mahmoud Kamel - 2016/08/15] Issue#GFSX10968 -  Setting ClearBankName and RimNumber
Select [RowID],                                
  --ChequeNumber,
  CAST(REPLACE(REPLACE(ChequeNumber, CHAR(13), ''), CHAR(10), '') AS DECIMAL(15,0)), -- Mostafa.Abdelrazek CR#GFSY00614 ADIB_CRQ7501_xp -  Cmdshell Alternative-  Core System Intregration 05-1-2017                                  
  DrawerAccNumber,                                
  ChequeAmount,                                  
  @Txn,                                
  @AccountNumber,                                
  ClearBankBranchID,                                
  @Status,                                
  @Branch,                                
  @User_Number,                                
  ValueDate,                                
  @Narrative,                                
  @ChequeTypeStatusID,                                
  @BusinessDate,                                
  tRefNo,                           
  ClearCenter,                                
  ClearBillNumber,                                
  SourceOfCheque,                                
  Other,      
  AfterCutoffTime,--CASE AfterCutoffTime WHEN 'True' THEN 1 else 0 end, --Lamiaa Mostafa                               
  RoutingNo,                                
  GLNumber,                                
  CASE ProviderID WHEN 0 THEN null else ProviderID end,                                
  Charges ,--mzaatar                                
  ChequeDate,                                
  Creator,                                
  @ForUtility,                            
@ForCreditCardPayment,                            
  @ForStockMarketPayment,                       
  @FloatWithProfile ,   --this line added by kareem ezz                                
  CASE CustomerReference WHEN '' THEN NULL ELSE CustomerReference END,              
  @AccountBranch --mfarouk ADIB CR 5766                 
  ,ISCertifiedCheque --CASE ISCertifiedCheque WHEN 'True' THEN 1 ELSE 0 END             
  ,@RIMNumber       --- Muhammad Mabrouk ADIB 101_CR_GFSY00544_2_OutClearingCR   12-1-2016
 -- ,ClearBankName	--[Mahmoud Kamel - 2016/08/15] Issue#GFSX10968 -  Setting ClearBankName and RimNumber
 ,ClearDetailName
From @tGrid                               
                  
-- Added by Marwa Arafat 30/08/2007                                
update ClearDetail                  
set  ClearDetail.ShadowAccountType = @ShadowAccType ,                                 
  ClearDetail.CustomerShadowAcc = @ShadowAccNo,                                 
  ClearDetail.ShadowAccountCurrency = @ShadowAccCurrency,                                
  ClearDetail.ShadowAccApplicationType = @ShadowAccAppType,                                
  ClearDetail.AccountType = @AccountType,                                
  ClearDetail.AccountCurrency = @AccountCurrency,                                
  ClearDetail.AccountApplictopnType = @AccountAppType,                                
  ClearDetail.AccountStatus = @AccountStatus                       
where ClearDetail.TxnID=@Txn                  
-- end                                
                             
--update dbo.TableID set dbo.TableID.LastValue = @RowID  where lower(dbo.TableID.TableName) ='cleardetail' and lower(dbo.TableID.FieldName)='id'                                
--update dbo.TableID set dbo.TableID.LastValue = @Txn  where lower(dbo.TableID.TableName) ='cleardetail' and lower(dbo.TableID.FieldName)='txnid'                      
                                
update dbo.TableLock set dbo.TableLock.IsInProcess = 0 Where dbo.TableLock.TableName = 'ClearDetail'                                
update dbo.TableLock set dbo.TableLock.IsInProcess = 0 Where dbo.TableLock.TableName = 'TableID'                                
               
if(@@error<>0)                                
begin                                
 Rollback Transaction                                
 return 0                                
end                                
else                                
begin                                 
 Commit Transaction                                
 return @Txn                                
end  
GO          
Drop_old_proc write_tcr_totals
Go
create proc write_tcr_totals
     @Bank   BankID
    ,@Region RegionID
    ,@Branch BranchID
    ,@user_number internal_user_ID
    ,@BusinessDate SmallDate
    ,@Correction bit
    ,@BucketID  Bucket_ID
    ,@Amount    money
    ,@ctype     CurrencyType
    ,@Batch     int
    ,@Counter   int
    ,@debug     int = 0
    ,@TransactionTime datetime = null
	,@BrID hierarchy_node# = null
AS
-- 12FEB19 Mostafa Sayed - Enh.GFSY00749 - write TCR totals to TCR_Totals table
set nocount on
if @BrID is null
	select @BrID = dbo.id_of_branch(@Bank,@Region,@Branch)  

if @TransactionTime is null set @TransactionTime=getdate()
declare @deviceID int
exec @deviceID = dbo.get_tcr_deviceID @user_number
if @Amount = 0
    return 0 -- Do not insert or update if the Amount parameter is zero.
IF @BucketID = 12059 or @BucketID = 12060
UPDATE dbo.TCR_Totals WITH (UPDLOCK ROWLOCK)
set  Counter = Counter + @Counter
    ,Amount = Amount + @Amount
    ,TransactionTime = case when @TransactionTime > isnull(TransactionTime,0) 
                            then @TransactionTime else TransactionTime end
where 
		Branch_unit = @BrID
     and BusinessDate = @BusinessDate
     and user_number = @user_number
     and BucketID = @BucketID
     and CurrencyType = @ctype
     and Batch = @Batch
if @@rowcount = 0 begin
    if @debug > 1 
        select 'inserting ' + cast(@BucketID as varchar) as bucketID
            ,@cType as ctype, @Batch as batch 
    if (@Correction = 0 and (@BucketID = 12059 or @BucketID = 12060)) 
        insert dbo.TCR_Totals WITH (UPDLOCK ROWLOCK) (
			 Branch_Unit
			 ,BusinessDate
            ,user_number,BucketID,CurrencyType,Batch 
            ,Counter,Amount,TransactionTime,TCRDeviceID
        )values(
			 @BrID
			 ,@BusinessDate
            ,@user_number,@BucketID,@ctype,@Batch
            ,@Counter,@Amount,@TransactionTime,@deviceID
        )
    else  begin
        declare @BusinessDateString varchar(30)
        set @BusinessDateString = cast(@BusinessDate as varchar)
        print 'raising error'
        raiserror('Can not find Totals2 record to correct for Bank %d, Region %d, Branch %d
                ,BusinessDate %s,Teller %d, BucketID %d, Currency %s, Batch %d.'
                ,9,1,@Bank,@Region,@Branch,@BusinessDateString,@user_number,@BucketID
                ,@ctype,@Batch)
        return -16
    end
end
return 0

Go
Drop_old_proc write_tcr_totals
Go
create proc write_tcr_totals
     @Bank   BankID
    ,@Region RegionID
    ,@Branch BranchID
    ,@user_number internal_user_ID
    ,@BusinessDate SmallDate
    ,@Correction bit
    ,@BucketID  Bucket_ID
    ,@Amount    money
    ,@ctype     CurrencyType
    ,@Batch     int
    ,@Counter   int
    ,@debug     int = 0
    ,@TransactionTime datetime = null
	,@BrID hierarchy_node# = null
AS
-- 12FEB19 Mostafa Sayed - Enh.GFSY00749 - write TCR totals to TCR_Totals table
set nocount on
if @BrID is null
	select @BrID = dbo.id_of_branch(@Bank,@Region,@Branch)  

if @TransactionTime is null set @TransactionTime=getdate()
declare @deviceID int
exec @deviceID = dbo.get_tcr_deviceID @user_number
if @Amount = 0
    return 0 -- Do not insert or update if the Amount parameter is zero.
IF @BucketID = 12059 or @BucketID = 12060
UPDATE dbo.TCR_Totals WITH (UPDLOCK ROWLOCK)
set  Counter = Counter + @Counter
    ,Amount = Amount + @Amount
    ,TransactionTime = case when @TransactionTime > isnull(TransactionTime,0) 
                            then @TransactionTime else TransactionTime end
where 
		Branch_unit = @BrID
     and BusinessDate = @BusinessDate
     and user_number = @user_number
     and BucketID = @BucketID
     and CurrencyType = @ctype
     and Batch = @Batch
     and TCRDeviceID = @deviceID
if @@rowcount = 0 begin
    if @debug > 1 
        select 'inserting ' + cast(@BucketID as varchar) as bucketID
            ,@cType as ctype, @Batch as batch 
    if (@Correction = 0 and (@BucketID = 12059 or @BucketID = 12060)) 
        insert dbo.TCR_Totals WITH (UPDLOCK ROWLOCK) (
			 Branch_Unit
			 ,BusinessDate
            ,user_number,BucketID,CurrencyType,Batch 
            ,Counter,Amount,TransactionTime,TCRDeviceID
        )values(
			 @BrID
			 ,@BusinessDate
            ,@user_number,@BucketID,@ctype,@Batch
            ,@Counter,@Amount,@TransactionTime,@deviceID
        )
    else  begin
        declare @BusinessDateString varchar(30)
        set @BusinessDateString = cast(@BusinessDate as varchar)
        print 'raising error'
        raiserror('Can not find TCR_Totals record to correct for Bank %d, Region %d, Branch %d
                ,BusinessDate %s,Teller %d, BucketID %d, Currency %s, Batch %d.'
                ,9,1,@Bank,@Region,@Branch,@BusinessDateString,@user_number,@BucketID
                ,@ctype,@Batch)
        return -16
    end
end
return 0

Go
Drop_old_proc TLR__UpdateDrawer
Go
CREATE PROCEDURE dbo.TLR__UpdateDrawer
@DrawerID                  VARCHAR(25),
@DrawerName                NVARCHAR(100),
@DrawerCurrency            CHAR(3),
@DrawerExpiryDate          DATE,
@DrawerLimit               float,
@DrawerAmount              decimal(21,6),
@TotalAssignedAmount       decimal(21,6),
@UtilizedLimit             decimal(21,6),
@AvailableLimit            decimal(21,6),
@PastDue                   BIT,
@Remarks                   NVARCHAR(250),
@AvailabiltyOfCBRBStatus   char,
@CommentsOnCBRBStatus      NVARCHAR(30),
@CBRBStatusDate            DATE,
@Status                    char(30),
@DateOfDeactivation        DATE,
@StartDate                 Date,
@Tenor                     int,
@Period                    char(8),
@ModifiedDate              Date ,
@Updator                   OperatorID=''
 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Update table Drawer "LBDDrawer" 

Developer: Mahmoud Saad
Date: 11-06-2018
Reason: add updator to the proc issue #GFSX13658
*/
if(@Updator='')
BEGIN 
SELECT @Updator=system_user
END

DECLARE @oldStatus nvarchar(30)
SELECT @oldStatus=Status FROM drawer WHERE DrawerID=@DrawerID 
update drawer
SET DrawerName=@DrawerName,Currency=@DrawerCurrency,
ExpiryDate=@DrawerExpiryDate,DrawerLimit=@DrawerLimit,
DrawerAmount=@DrawerAmount,TotalAssignedAmount=@TotalAssignedAmount,
UtilizedLimit=@UtilizedLimit,AvailableLimit=@AvailableLimit,
PastDue=@PastDue,Remarks=@Remarks,
AvailabiltyOfCBRBStatus=@AvailabiltyOfCBRBStatus,
CommentsOnCBRBStatus=@CommentsOnCBRBStatus,
CBRBStatusDate=@CBRBStatusDate,
Status=@Status,DateOfDeactivation=@DateOfDeactivation,
StartDate=@StartDate,Tenor=@Tenor,Period=@Period,
ModifiedDate=@ModifiedDate,Updator=@Updator
WHERE  DrawerID=@DrawerID
	   

	if((@Status='Active' or @oldStatus='Active') and (@Status<>@oldStatus AND @Status<>'Active')) 
		BEGIN
			update CommitmentDrawer SET Status=@Status,Updator=@Updator WHERE DrawerID=@DrawerID AND Status=@oldStatus
		END 
end 
GO       
Drop_old_proc TLR_OperationsTableCMTDRW
GO
Create PROCEDURE dbo.TLR_OperationsTableCMTDRW  
@Mode                   char          ,
@CommitmentNo            NVARCHAR(12)  ,
@DrawerID                VARCHAR(25)   ,
@RimNo                   int           ,
@Currency                char(3)       ,
@DrawerLimit             float         ,
@DrawerLimitInAmount     decimal(21,6) ,
@ExpiryDate              DATE          ,
@UtilizedLimit           decimal(21,6) ,
@AvailableLimit          decimal(21,6) ,
@FOLReferenceNo          NVARCHAR(40)  ,
@FOLDate                 DATE          ,
@Remark                  NVARCHAR(250) ,
@Status                  NVARCHAR(20)  ,
@Tenor                   int           ,
@Period                  char(8)       ,
@StartDate               date          ,
@Updator                 OperatorID=''     
 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: CRUD Operation on table CommitmentDrawer "LBDDrawer CR" 

Developer: Mahmoud Saad
Date: 11-06-2018
Reason: add updator to the proc issue #GFSX13658
*/
if(@Updator='')
BEGIN 
SELECT @Updator=system_user
END

DECLARE @TotalAssignedLimit decimal(21,6),
		@OldLimit decimal(21,6),
		@AddedValue decimal(21,6)
if(lower(@Mode)='a')
	BEGIN

		SELECT * FROM CommitmentDrawer 
		INSERT INTO CommitmentDrawer (CommitmentNo,DrawerID,RimNo,Currency,DrawerLimit,DrawerLimitInAmount,ExpiryDate,UtilizedLimit,AvailableLimit,FOLReferenceNo,FOLDate
									,Remark,Status,tenor,period,StartDate,Updator,Creator)
		VALUES(@CommitmentNo,@DrawerID,@RimNo,@Currency,@DrawerLimit,@DrawerLimitInAmount,@ExpiryDate,@UtilizedLimit,@AvailableLimit,@FOLReferenceNo,@FOLDate
									,@Remark,@Status,@Tenor,@Period,@StartDate,@Updator,@Updator)


		select @TotalAssignedLimit= TotalAssignedAmount from Drawer WHERE DrawerID=@DrawerID
		SELECT @TotalAssignedLimit=@TotalAssignedLimit+@DrawerLimitInAmount

		UPDATE Drawer  SET TotalAssignedAmount=@TotalAssignedLimit,Updator=@Updator WHERE DrawerID=@DrawerID
	END
ELSE IF (lower(@Mode)='u')
	BEGIN 

		select @TotalAssignedLimit= TotalAssignedAmount from Drawer WHERE DrawerID=@DrawerID
		SELECT @OldLimit = DrawerLimitInAmount FROM CommitmentDrawer  WHERE CommitmentNo=@CommitmentNo and DrawerID=@DrawerID AND RimNo=@RimNo
		if(@OldLimit <> @DrawerLimitInAmount)
			BEGIN 
				SELECT @AddedValue=@DrawerLimitInAmount-@OldLimit
				select @TotalAssignedLimit=@TotalAssignedLimit+@AddedValue
				UPDATE Drawer  SET TotalAssignedAmount=@TotalAssignedLimit,Updator=@Updator WHERE DrawerID=@DrawerID
			END 


		UPDATE CommitmentDrawer SET CommitmentNo=@CommitmentNo, DrawerID=@DrawerID,
		RimNo=@RimNo,Currency=@Currency,DrawerLimit=@DrawerLimit,DrawerLimitInAmount=@DrawerLimitInAmount,
		ExpiryDate=@ExpiryDate,UtilizedLimit=@UtilizedLimit,AvailableLimit=@AvailableLimit,
		FOLReferenceNo=@FOLReferenceNo,FOLDate=@FOLDate,Remark=@Remark,Status=@Status,Tenor=@Tenor,
		Period=@Period,StartDate=@StartDate,Updator=@Updator
		WHERE CommitmentNo=@CommitmentNo and DrawerID=@DrawerID AND RimNo=@RimNo
	END 
else if(lower(@Mode)='d')
	begin
		SELECT @AddedValue = DrawerLimitInAmount FROM CommitmentDrawer  WHERE CommitmentNo=@CommitmentNo and DrawerID=@DrawerID
		select @TotalAssignedLimit= TotalAssignedAmount from Drawer WHERE DrawerID=@DrawerID
		SELECT @TotalAssignedLimit=@TotalAssignedLimit-@AddedValue
		UPDATE Drawer  SET TotalAssignedAmount=@TotalAssignedLimit,Updator=@Updator WHERE DrawerID=@DrawerID

		delete FROM CommitmentDrawer WHERE CommitmentNo=@CommitmentNo and DrawerID=@DrawerID 
	 
	END 

END


GO
Drop_old_proc TLR_InsertDrawer
GO
Create PROCEDURE dbo.TLR_InsertDrawer  
@DrawerID                  VARCHAR(25),
@DrawerName                NVARCHAR(100),
@DrawerCurrency            CHAR(3),
@DrawerExpiryDate          DATE,
@DrawerLimit               float,
@DrawerAmount              decimal(21,6),
@TotalAssignedAmount       decimal(21,6),
@UtilizedLimit             decimal(21,6),
@AvailableLimit            decimal(21,6),
@PastDue                   BIT,
@Remarks                   NVARCHAR(250),
@AvailabiltyOfCBRBStatus   char,
@CommentsOnCBRBStatus      NVARCHAR(30),
@CBRBStatusDate            DATE,
@Status                    char(30),
@DateOfDeactivation        DATE,
@StartDate                 Date,
@Tenor                     int,
@Period                    char(8),
@ModifiedDate              Date ,
@Updator                   OperatorID=''
 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Inser to table Drawer "LBDDrawer" 

Developer: Mahmoud Saad
Date: 11-06-2018
Reason: add updator to the proc issue #GFSX13658
*/
if(@Updator='')
BEGIN 
SELECT @Updator=system_user
end

insert into Drawer(DrawerID,DrawerName,Currency,ExpiryDate,DrawerLimit,DrawerAmount,TotalAssignedAmount,UtilizedLimit ,AvailableLimit ,PastDue,Remarks,AvailabiltyOfCBRBStatus ,CommentsOnCBRBStatus,CBRBStatusDate,Status,DateOfDeactivation,StartDate,Tenor,Period,ModifiedDate,Updator,Creator)
values(@DrawerID,@DrawerName,@DrawerCurrency,@DrawerExpiryDate,@DrawerLimit,@DrawerAmount,@TotalAssignedAmount,@UtilizedLimit ,@AvailableLimit ,@PastDue,@Remarks,@AvailabiltyOfCBRBStatus ,@CommentsOnCBRBStatus,@CBRBStatusDate,@Status,@DateOfDeactivation,@StartDate,@Tenor,@Period,@ModifiedDate,@Updator,@Updator)
END
go
Drop_old_proc TLR_ReturnDrawerAmounts
GO
CREATE PROCEDURE dbo.TLR_ReturnDrawerAmounts  
@LoanAcountNo char(12),
@amount   decimal(21,6),
@Updator  OperatorID =''

 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Return Drawer 

Developer: Mahmoud Saad
Date: 11-06-2018
Reason: add updator to the proc issue #GFSX13658
*/

if(@Updator='')
BEGIN 
SELECT @Updator=system_user
END

	DECLARE @drawercode nvarchar(25)=''
	DECLARE @commitmentNo nvarchar(12)=''


	SELECT @drawercode=cd.DrawerCode,@commitmentNo=c.CommitmentNumber
	FROM DiscChequesDetail cd LEFT JOIN DiscCheques c 
	ON cd.Track_No = c.Track_No 
	WHERE cd.LoanAccountNumber=@LoanAcountNo

	if((@commitmentNo is not null and @commitmentNo <> '') AND  (@drawercode is not NULL AND  @drawercode<>''))
		BEGIN
			UPDATE CommitmentDrawer 
			SET UtilizedLimit=UtilizedLimit-@Amount,AvailableLimit=AvailableLimit+@Amount ,Updator=@Updator
			WHERE DrawerID=@drawercode AND CommitmentNo=@commitmentNo

			UPDATE Drawer 
			SET UtilizedLimit=UtilizedLimit-@Amount,AvailableLimit=AvailableLimit+@Amount,Updator=@Updator
			WHERE DrawerID=@drawercode
		END
	ELSE
		BEGIN
			RETURN -1
		END


END
GO 
--Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc update_cheque_details_loan
Go

create PROCEDURE dbo.update_cheque_details_loan      
@Cheque_Number char(20),      
@ref_no ReferenceNumber,      
@loan_acct_no accountnumber  ,    
@error_no int,    
@error_desc varchar(500),    
@hoststatus varchar(100),
@Updator   OperatorID=''    
as       
 /*
 
ModifiedDate: 8-7-2009            
Modifer     : Amira Kamel         
ModifyReason: Retrofit proce from CBD To UBS  

Developer: Mahmoud Saad
Date: 11-06-2018
Reason: add updator to the proc issue #GFSX13658
*/
if(@Updator='')
BEGIN 
SELECT @Updator=system_user
END

   
update discchequesdetail       
set LoanAccountNumber = @loan_acct_no      
, hosterrorno = @error_no    
, hosterrordescription = @error_desc    
, hoststatus = @hoststatus  
, Updator=@Updator  
where ref_no=@ref_no      
and chequeNo=@cheque_number    


Go
--End of Automatic Generation
  
  drop_old_proc 'dbo.Get_Charge_Category_Details'
  go
create PROC dbo.Get_Charge_Category_Details  --2,320, 1,'CashDeposit',5,'20583','100000084431','CUR','BHD'                          
  @FeeCategoryID int,                                                  
  @AmountLocal money,                                
  @DebitRate decimal(24,9),                              
  @TranID int, --@TranName VARCHAR(40),                              
  @RimClass int,                               
  @RimNo varchar(20),                              
  @AcctNo varchar(60) ,                            
  @AccountType AccountTypeCode = null,                            
  @AccountCurrency CurrencyType = null,                        
  @ProfileId int,                
  @BusDate datetime   = null,              
-- @TranOption int = -1,              
  @TranOption nvarchar(40) = NULL,         
  @TranCurrency CurrencyType = null,    
  @AccountClass int = -1,  
  @DefaultCurr varchar(4)=NULL  
  --@LocationCharge int =-1               
                                    
/*                                                        
  CreationDate: 31-MAY-2007                                                  
  OriginalName: dbo.Select_Charges_Details                                                  
  Programmer: Hebrahim                                                  
  Description: Convert the amount to local then calculate the total charges and returns the amount and the dtails                                                  
  Output:  Charges in local currency                                                         
  Assumption:                                                    
                                                  
  ModifiedDate:14-09-2008                                           
  Modifer: Eman Gouda                                           
  ModifyReason: add customer profile id as a search criteria in retreiving exceptional charges                       
                      
  ModifiedDate:27-10-2008                                           
  Modifer: Eman Gouda                                           
  ModifyReason: add @AccountType as a search criteria in retreiving exceptional charges                                                         
                      
  ModifiedDate:23-03-2009                                           
  Modifer: Amira Kamel                                           
  ModifyReason: pass TranID to the [GetExceptionalCharge] procedure Instead of TranName and pass DebitRate                  
                  
  ModifiedDate: 20-08-2009                                           
  Modifer:  Amira Kamel                                           
  ModifyReason: Add new parameter @BusDate to use in get Exceptional charges                  
                  
  ModifiedDate: 28-1-2010                                                 
  Modifer:  Aya Mahmoud                
  ModifyReason:   Enlarge decimal parameters from (21,6) to (24,9)               
                
  ModifiedDate: 25-7-2011              
  Modifer: Lamiaa Mostafa              
  Modify Reason: Add TransactionOption and TransactionCurrency as a search criteria in retreiving exceptional charges               
              
  ModifiedDate: 27-10-2011              
  Modifer: Mohammed El-Masry            
  Modify Reason: Add LocationCharge as a search criteria in retreiving exceptional charges             
            
  ModifiedDate: 14-11-2011              
  Modifer: Mohammed El-Masry            
  Modify Reason: Returns New Column that if FeeAmount comes from Exception or normal setup          
          
  ModifiedDate: 2011-12-29              
  Modifer: Ahmed Eldeeb            
  Modify Reason: change the tranOption from int to nvarchar depend on the transaction option in various Transactions Like [Cashwithdrawal,MEWPayment]        
          
  ModifiedDate: 2012-01-08              
  Modifer: Mohamed Sobhy            
  Modify Reason: Remove Location      
      
  ModifiedDate: 2012-07-11              
  Modifer: Amira Kamel & Asmaa Hafez          
  Modify Reason: Adding Order by FeeGroupID (CR#7948 Cash Deposit)    
      
 ModifiedDate: 2013-04-01        
 Modifer: Mohamed Farouk      
 Modify Reason: CBD CR GFSY00210, exceptional charges with account class code    
   
 ModifiedDate: 2013-05-20        
 Modifer: Lamiaa Mostafa   
 Modify Reason: change @AmountPercent data type from money to Decimal(18,15)  
   
  ModifiedDate: 2014-12-12      
  Modifer: Karim Mahmoud    
  Modify Reason: BBK CR GFSY00362, exceptional charges with fixed or percentage amounts, transaction amount and operator value.   
 
ModifiedDate	: 2018-12-03        
 Modifer		: Ahmed Osman     
 Modify Reason	: CR#GFSY00739 - Add Custom Exception Charges
     
*/                                                  
as                                                  
  CREATE TABLE #T                                                     
 (                                                   
   FeeCode varchar(50)                                                
  ,FeeName nvarchar(100)                                                    
  ,AmountPercent Money                                    
  ,DebitAmount Money                                            
  ,Min Money              
  ,Max Money                                                  
  ,IsFixed bit                
  ,FeeCategoryID int                                              
  ,Selected bit                                     
  ,CoreFeeCode varchar(100)           
  ,IsException bit                   
,CustomExceptionID varchar(100)	-- Ahmed Osman CR#GFSY00739 		                          
,  OriginalAmount Money				-- Ahmed Osman CR#GFSY00739	
,  OriginalDebitAmount Money			-- Ahmed Osman CR#GFSY00739                                      
                    
 )                                                   
                                                  
declare @IsFixed bit,                                                        
 @AmountPercent Decimal(21,6),                          
 @Temp  Money,                                                  
 @FeeName nvarchar(100),                                                
 @FeeCode varchar(100),                                                
 @Min Money,                                                
 @Max Money,                                    
 @CoreFeeCode varchar(100),                          
 @IsException bit ,         
@CustomExceptionID varchar(100) = null ,	-- Ahmed Osman CR#GFSY00739 		                          
 @OriginalAmount Money = null ,				-- Ahmed Osman CR#GFSY00739	  
 @OriginalDebitAmount Money = null			-- Ahmed Osman CR#GFSY00739            

                                    
DECLARE table_cursor cursor forward_only local for                                                        
select f.FeeCode, f.FeeName, f.IsFixed, f.AmountPercent,                 
case  when  (fac.MinFee is not null)  then fac.MinFee  else f.min end , f.Max, f.CoreFeeCode                                          
from Fee as f                                                
inner join FeeGroupDetail as gd                                                        
on f.FeeCode = gd.FeeCode                                                        
inner join (select cd.FeeGroupID,                                                
   min(f2.EndAmount) as EndAmount                                                        
  from FeeCategoryGroupDetail as cd                                  
  inner join FeeGroupDetail as gd2                                                        
  on cd.FeeGroupID = gd2.FeeGroupID                                 
  inner join Fee as f2                                                  
  on f2.FeeCode = gd2.FeeCode                                                        
  where  cd.IsCategory = '0' AND cd.FeeCategoryID = @FeeCategoryID                                                        
  and f2.EndAmount >= @AmountLocal                                                  
  group by cd.FeeGroupID) as t                                                        
on f.EndAmount = t.EndAmount                                                        
and gd.FeeGroupID = t.FeeGroupID                           
LEFT OUTER JOIN (SELECT TOP 100 FeeCode, MinFee                            
  FROM FEE_ACCOUNT_MIN                            
  WHERE AccountTypeCode=@AccountType                            
  AND (AccountCurrency=@AccountCurrency OR                             
   AccountCurrency IS NULL                            
      )                            
  ORDER BY AccountCurrency DESC) AS fac                         
ON  f.FeeCode= fac.FeeCode    
    
--Amira Kamel & Asmaa Hafez [CR#7948 Cash Deposit]                            
 ORDER BY t.FeeGroupID   ASC                                                 
--Amira Kamel & Asmaa Hafez [CR#7948 Cash Deposit]    
    
--Hebrahim [BEGIN : CR-Exceptional Charges]                              
DECLARE @ExceptionAmount DECIMAL(18, 6)                              
--Hebrahim [END : CR-Exceptional Charges]                              
open table_cursor                                                   
fetch next from table_cursor into                                                        
@FeeCode, @FeeName, @IsFixed, @AmountPercent, @Min, @Max, @CoreFeeCode                                    
while (@@fetch_status = 0)                            
BEGIN                            
 --Hebrahim [BEGIN : CR-Exceptional Charges]                         
 SET @ExceptionAmount = NULL   
        
    SET @CustomExceptionID = NULL		-- Ahmed Osman CR#GFSY00739       

 EXEC GetExceptionalCharge  @TranID, @AmountLocal, @FeeCode, @RimClass, @RimNo,                 
 @AcctNo,@ProfileId, @ExceptionAmount OUT , @AccountType,@AccountCurrency,@DebitRate,@BusDate, @TranOption,@TranCurrency,@AccountClass,@DefaultCurr, @CustomExceptionID out--,@LocationCharge                
 --Hebrahim [END : CR-Exceptional Charges]                              
 IF (@IsFixed = 0)                                                       
 BEGIN              
   SET @Temp = @AmountLocal * (@AmountPercent / 100)                                        
 END                                        
 ELSE                                        
 BEGIN                                        
SET @Temp = @AmountPercent                                        
 END                 
 IF (@Temp < @Min)                                        
   SET @Temp = @Min                                           
 ELSE IF (@Temp > @Max AND @Max <> 0.0)                                        
   SET @Temp = @Max                                         
   
--Karim Mahmoud  BBK CR GFSY00362    
 IF(@ExceptionAmount = -1)      
 begin            
   SET @ExceptionAmount = NULL                                                 
 end    
--Karim Mahmoud  BBK CR GFSY00362   
set @OriginalAmount = @AmountPercent						-- Ahmed Osman CR#GFSY00739	  
set @OriginalDebitAmount = (@AmountPercent / @DebitRate)	-- Ahmed Osman CR#GFSY00739	                              
 IF(@ExceptionAmount IS NULL)                              
 begin          
   SET @AmountPercent = @Temp           
   -- No Exception Occurred          
   set @IsException = 0;                                     
 end          
 ELSE                               
 begin          
   SET @AmountPercent = @ExceptionAmount           
   -- Exception Exist          
   set @IsException = 1;                              
 end          
                              
  Insert into #T (FeeCode, FeeName,IsFixed, AmountPercent,DebitAmount, Min, Max, FeeCategoryId, Selected, CoreFeeCode, IsException, CustomExceptionID , OriginalAmount , OriginalDebitAmount)                      
  VALUES (@FeeCode, @FeeName, @IsFixed, @AmountPercent,(@AmountPercent / @DebitRate), @Min, @Max, @FeeCategoryID, 0, @CoreFeeCode, @IsException, @CustomExceptionID , @OriginalAmount , @OriginalDebitAmount)                           
       
           
                                           
  FETCH next from table_cursor into                                                        
     @FeeCode, @FeeName, @IsFixed, @AmountPercent, @Min, @Max, @CoreFeeCode                                               
end                                                    
close table_cursor                                                        
deallocate table_cursor                                                  
select * from #T       
go


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Get_Tran_Charges]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Get_Tran_Charges]
GO

CREATE procedure dbo.Get_Tran_Charges                       
 @TranName TransactionName,                                
 @Amount  decimal(21,6),                              
 @Rate  decimal(24,9),                        
 @DebitRate decimal (24,9),                      
 @RimClass int = -1,                      
 @RimNo varchar(20) = '123',                      
 @AcctNo varchar(60) = '123',                      
 @AccountType AccountTypeCode = null,                      
 @AccountCurrency CurrencyType = null,                     
 @ProfileId int = -1,            
 @BusDate datetime = '1900/1/1',      
-- @TranOption int = -1,      
@TranOption nvarchar(40) = NULL, 
 @TranCurrency CurrencyType = null,
 @AccountClass int = -1,
 @DefaultCurr varchar(4)=NULL
 --@LocationCharge int =-1                   
as                          
                                      
/*                                      
  CreationDate: 31-MAY-2007                                
  OriginalName: dbo.Select_Charges_Details                                
  Programmer: Hebrahim                                
  Description: Convert the amount to local then calculate the total charges and returns the amount and the dtails                                
  Output:  Charges in local currency                                       
  Assumption:                                  
                                
  ModifiedDate:14-09-2008                                       
  Modifer: Eman Gouda                                       
  ModifyReason: add customer profile id as a search criteria in retreiving exceptional charges                                      
                  
  ModifiedDate:23-03-2009                                       
  Modifer: Amira Kamel                                       
  ModifyReason: pass TranID to the [Get_Charge_Category_Details] procedure Instead of TranName                
              
  ModifiedDate: 20-08-2009                                       
  Modifer:  Amira Kamel                                       
  ModifyReason: Add new parameter @BusDate to use in get Exceptional charges         
          
  ModifiedDate: 28-1-2010                                         
  Modifer:  Aya Mahmoud        
  ModifyReason:   Enlarge decimal parameters from (21,6) to (24,9)      
        
  ModifiedDate: 25-7-2011      
  Modifer: Lamiaa Mostafa      
  Modify Reason: Add TransactionOption and TransactionCurrency as a search criteria in retreiving exceptional charges       
      
  ModifiedDate: 27-10-2011      
  Modifer: Mohammed El-Masry    
  Modify Reason: Add LocationCharge as a search criteria in retreiving exceptional charges     
    
  ModifiedDate: 14-11-2011      
  Modifer: Mohammed El-Masry    
  Modify Reason: Returns New Column that if FeeAmount comes from Exception or normal setup           
  
   ModifiedDate: 2011-12-29      
  Modifer: Ahmed Eldeeb    
  Modify Reason: change the tranOption from int to nvarchar depend on the transaction option in various Transactions Like [Cashwithdrawal,MEWPayment]
  
 ModifiedDate: 2012-01-08      
 Modifer: Mohamed Sobhy    
 Modify Reason: Remove Location 
 
 ModifiedDate: 2013-04-01    
 Modifer: Mohamed Farouk  
 Modify Reason: CBD CR GFSY00210, exceptional charges with account class code
 
  ModifiedDate: 2014-12-25    
  Modifer: Karim Mahmoud  
  Modify Reason: BBK CR GFSY00362, add default curr.
  	
  ModifiedDate: 2015-04-12    
  Modifer: Asmaa Gamal  
  Modify Reason: Blom Issue # GFSX08489 Arabic Fee Name .	
 ModifiedDate	: 2018-12-03        
 Modifer		: Ahmed Osman     
 Modify Reason	: CR#GFSY00739 - Add Custom Exception Charges	
*/                              
set nocount on                                
                              
DECLARE @TranID  int,                                
        @FeeCategoryID int,                                
   @AmountLocal decimal(21,6),                                
   @FeeGroupID int                                
                              
  CREATE TABLE #T                                   
 (                                 
   FeeCode varchar(50)                              
  ,FeeName nvarchar(100)                                  
  ,AmountPercent Money                        
  ,DebitAmount Money                        
  ,Min Money                              
  ,Max Money                                
  ,IsFixed bit                              
  ,FeeCategoryID int                          
  ,Selected bit           
  ,CoreFeeCode varchar(100)   
  ,IsException bit                        
  ,CustomExceptionID varchar(100)	-- Ahmed Osman CR#GFSY00739 		                          
  ,OriginalAmount Money			-- Ahmed Osman CR#GFSY00739 
 , OriginalDebitAmount Money			-- Ahmed Osman CR#GFSY00739   
 )                               
                              
--Get Category's groups fees                                            
set @TranID = (select TranID from RulesTranName where TransactionName = @TranName)                                      
set @FeeCategoryID = (select FeesCategoryID from RulesTranConfig where tranid = @TranID)                                
set @AmountLocal = @Amount*@Rate                              
INSERT INTO #T VALUES ('0','0',0,0,0,0,0,@FeeCategoryID,0,0,0,NULL,0,0)                                  
         -- select @FeeCategoryID,@AmountLocal, @DebitRate, @TranName, @RimClass, @RimNo, @AcctNo,@AccountType,@AccountCurrency                      
INSERT INTO #T exec Get_Charge_Category_Details @FeeCategoryID,@AmountLocal, @DebitRate, @TranID, @RimClass, @RimNo, @AcctNo,@AccountType,@AccountCurrency,@ProfileID,@BusDate, @TranOption, @TranCurrency,@AccountClass,@DefaultCurr--,@LocationCharge                    
                              
--Get Category's subCategories fees                     
declare subcategories_cursor cursor forward_only local for                                
  select FeeGroupID from FeeCategoryGroupDetail WHERE FeeCategoryID = @FeeCategoryID AND IsCategory = '1'                                
                                
open subcategories_cursor                              
fetch next from subcategories_cursor into @FeeGroupID                                
while (@@fetch_status = 0)                                
begin                                
--select @FeeGroupID,@AmountLocal, @DebitRate  , @TranName, @RimClass, @RimNo, @AcctNo,@AccountType,@AccountCurrency                    
  INSERT INTO #T exec Get_Charge_Category_Details @FeeGroupID,@AmountLocal, @DebitRate  , @TranID, @RimClass, @RimNo, @AcctNo,@AccountType,@AccountCurrency,@ProfileID,@BusDate, @TranOption, @TranCurrency,@AccountClass,@DefaultCurr --,@LocationCharge                  
                                
  fetch next from subcategories_cursor into @FeeGroupID                                
end                                
close subcategories_cursor                                      
deallocate subcategories_cursor                                
SELECT * FROM #T                              
DROP TABLE #T                              

GO

USE [Globalfs]
GO
/****** Object:  StoredProcedure [dbo].[TLR_SearchDrawer]    Script Date: 03/13/2019 12:10:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[TLR_SearchDrawer]  --TLR_SearchDrawer '','',1033,'600000002535',10462,'EGP'
@DrawerID char(8) = '',
@DrawerName VARCHAR(100) = '',
@LCID int = 1033,
@CommitmentNo nvarchar(12) = '',
@RimNo int = 0,
@Currency char(3) = ''
 
AS
BEGIN
/*
Developer: Mahmoud Saad
Date: 24-10-2018
Reason: Search table Drawer "LBDDrawer" 

Developer: Mostafa Helmy
Date: 13-03-2019
Reason: get the CD.DrawerLimitInAmount and CD.AvailableLimit 

Developer: Nehal Ramadan
Date: 13-07-2019
Reason: get the d.cashdrawer status in english
*/

IF (@CommitmentNo <> '')
BEGIN

select d.DrawerID,DrawerName,d.Currency,d.ExpiryDate,d.DrawerLimit,DrawerAmount,TotalAssignedAmount,
d.UtilizedLimit,d.AvailableLimit,PastDue,Remarks,AvailabiltyOfCBRBStatus,CommentsOnCBRBStatus ,CBRBStatusDate,
Status=CASE @LCID

		WHEN 1033 THEN RulesDescriptor.Descriptor

		ELSE RDL.LocalDescription

		END ,
CBRBStatusDate,DateOfDeactivation,d.StartDate,d.Tenor,d.Period,ModifiedDate
,CD.DrawerLimitInAmount,CD.AvailableLimit as [Total_Available_Limit],
d.Status as 'selectedDrawerStatus' -- nehal GFSX13712
from Drawer d  
LEFT JOIN CommitmentDrawer CD
ON CD.DrawerID = d.DrawerID
 LEFT JOIN
 PickList_Entries pe2 ON pe2.PickListID =526
 AND pe2.[Value] =d.Status
 LEFT JOIN 
 RulesDescriptor ON (pe2.DescriptorName=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CI_AS )
 LEFT JOIN 
 dbo.RulesDescriptorLocal RDL ON RulesDescriptor.DescriptorID =RDL.DescriptorID and RDL.LCID=@LCID
WHERE CD.CommitmentNo = @CommitmentNo        
AND CD.RimNo = @RimNo        
AND CD.Currency = @Currency    
AND CD.Status = 'Active'  
 
END
ELSE
BEGIN

select DrawerID,DrawerName,Currency,ExpiryDate,DrawerLimit,DrawerAmount,TotalAssignedAmount
,UtilizedLimit,AvailableLimit,PastDue,Remarks
,AvailabiltyOfCBRBStatus,
CommentsOnCBRBStatus ,CBRBStatusDate,
Status=CASE @LCID

		WHEN 1033 THEN RulesDescriptor.Descriptor

		ELSE RDL.LocalDescription

		END ,CBRBStatusDate,DateOfDeactivation,StartDate,Tenor,Period,ModifiedDate,
		null as DrawerLimitInAmount,null as [Total_Available_Limit],
         d.Status as 'selectedDrawerStatus' -- nehal GFSX13712

		 from Drawer d  
 LEFT JOIN
 PickList_Entries pe2 ON pe2.PickListID =526
 AND pe2.[Value] =d.Status
 LEFT JOIN 
 RulesDescriptor ON (pe2.DescriptorName=RulesDescriptor.Name COLLATE SQL_Latin1_General_CP1_CI_AS )
 LEFT JOIN 
 dbo.RulesDescriptorLocal RDL ON RulesDescriptor.DescriptorID =RDL.DescriptorID and RDL.LCID=@LCID
 where (@DrawerID ='' OR d.DrawerID=@DrawerID)
 and  (@DrawerName ='' or d.DrawerName LIKE '%'+ @DrawerName+'%')

END

END
GO
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Get_Tran_Commission]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Get_Tran_Commission]
GO


CREATE procedure dbo.Get_Tran_Commission                          
 @TranName TransactionName,                            
 @Amount  decimal(21,6),                          
 @Rate  decimal(24,9),                    
 @DebitRate decimal (24,9),                  
 @RimClass int = -1,                  
 @RimNo varchar(20) = '123',                  
 @AcctNo varchar(60) = '123',                  
 @AccountType AccountTypeCode = null,                  
 @AccountCurrency CurrencyType = null,                 
 @ProfileId int = -1,
 @DefaultCurr varchar(4)=NULL,        
 @BusDate datetime = '1900/1/1',    
 @TranOption nvarchar(40) = NULL ,--int = -1,    
 @TranCurrency CurrencyType = null,
 @AccountClass int = -1
 --@LocationCharge int = -1                  
as                      
                                  
/*                                  
  CreationDate: 31-MAY-2007                            
  OriginalName: dbo.Select_Charges_Details                            
  Programmer: Hebrahim                            
  Description: Convert the amount to local then calculate the total charges and returns the amount and the dtails                            
  Output:  Charges in local currency                                   
  Assumption:                              
                            
  ModifiedDate:14-09-2008                                   
  Modifer: Eman Gouda                                   
  ModifyReason: add customer profile id as a search criteria in retreiving exceptional charges                                  
              
  ModifiedDate:23-03-2009                                   
  Modifer: Amira Kamel                                   
  ModifyReason: pass TranID to the [Get_Charge_Category_Details] procedure Instead of TranName            
          
  ModifiedDate: 20-08-2009                                   
  Modifer:  Amira Kamel                                   
  ModifyReason: Add new parameter @BusDate to use in get Exceptional charges         
         
  ModifiedDate: 28-1-2010                                       
  Modifer:  Aya Mahmoud      
  ModifyReason:   Enlarge decimal parameters from (21,6) to (24,9)      
    
  ModifiedDate: 28-7-2011    
  Modifer: Lamiaa Mostafa    
  Modify Reason: Add TransactionOption and TransactionCurrency as a search criteria in retreiving exceptional charges     
    
  ModifiedDate: 27-10-2011    
  Modifer: Mohammed El-Masry  
  Modify Reason: Add LocationCharge as a search criteria in retreiving exceptional charges  
  
  ModifiedDate: 14-11-2011    
  Modifer: Mohammed El-Masry  
  Modify Reason: Returns New Column that if FeeAmount comes from Exception or normal setup   
  
 ModifiedDate: 2012-01-08      
 Modifer: Mohamed Sobhy    
 Modify Reason: Remove Location 
 
 ModifiedDate: 2013-04-01    
 Modifer: Mohamed Farouk  
 Modify Reason: CBD CR GFSY00210, exceptional charges with account class code
 
 2012Jan09: Osama Orabi: Converting  @TranOption data type from int = -1 to nvarchar(40) = NULL 
 
 ModifiedDate: 2015-04-23    
 Modifer: Asmaa Gamal  
 Modify Reason: BLOM: fee name in arabic appear wrong in the transaction Issue #GFSX08489
 
 ModifiedDate	: 2018-12-03        
 Modifer		: Ahmed Osman     
 Modify Reason	: CR#GFSY00739 - Add Custom Exception Charges 
*/                          
set nocount on                            
                          
DECLARE @TranID  int,                            
        @FeeCategoryID int,                            
   @AmountLocal decimal(21,6),                            
   @FeeGroupID int                            
                          
  CREATE TABLE #T                               
 (                             
   FeeCode varchar(50)                          
  ,FeeName nvarchar(100)                              
  ,AmountPercent Money                    
  ,DebitAmount Money                    
  ,Min Money                          
  ,Max Money                            
  ,IsFixed bit                          
  ,FeeCategoryID int                      
  ,Selected bit                      
  ,CoreFeeCode varchar(100)  
  ,IsException bit             
,CustomExceptionID varchar(100)	-- Ahmed Osman CR#GFSY00739 		                          
 , OriginalAmount Money			-- Ahmed Osman CR#GFSY00739 
  ,OriginalDebitAmount Money			-- Ahmed Osman CR#GFSY00739        
 )                           
                          
--Get Category's groups fees                                        
set @TranID = (select TranID from RulesTranName where TransactionName = @TranName)                                  
set @FeeCategoryID = (select TranCommissionGroupID from RulesTranConfig where tranid = @TranID)                            
set @AmountLocal = @Amount*@Rate                    
INSERT INTO #T VALUES ('0','0',0,0,0,0,0,@FeeCategoryID,0,0,0,NULL,0,0)                        
         -- select @FeeCategoryID,@AmountLocal, @DebitRate, @TranName, @RimClass, @RimNo, @AcctNo,@AccountType,@AccountCurrency                  
INSERT INTO #T exec Get_Charge_Category_Details @FeeCategoryID,@AmountLocal, @DebitRate, @TranID, @RimClass, @RimNo, @AcctNo,@AccountType,@AccountCurrency,@ProfileID,@BusDate, @TranOption, @TranCurrency, @AccountClass,@DefaultCurr --,@LocationCharge                 
                          
--Get Category's subCategories fees                            
declare subcategories_cursor cursor forward_only local for                            
  select FeeGroupID from FeeCategoryGroupDetail WHERE FeeCategoryID = @FeeCategoryID AND IsCategory = '1'                            
                            
open subcategories_cursor                          
fetch next from subcategories_cursor into @FeeGroupID                            
while (@@fetch_status = 0)                            
begin                            
--select @FeeGroupID,@AmountLocal, @DebitRate  , @TranName, @RimClass, @RimNo, @AcctNo,@AccountType,@AccountCurrency                
  INSERT INTO #T exec Get_Charge_Category_Details @FeeGroupID,@AmountLocal, @DebitRate  , @TranID, @RimClass, @RimNo, @AcctNo,@AccountType,@AccountCurrency,@ProfileID,@BusDate, @TranOption, @TranCurrency, @AccountClass,@DefaultCurr --,@LocationCharge                   
                            
  fetch next from subcategories_cursor into @FeeGroupID                            
end                            
close subcategories_cursor                                  
deallocate subcategories_cursor                            
SELECT * FROM #T                          
DROP TABLE #T        

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




 Drop_old_proc GetConditionalOperator
GO
 create  procedure dbo.GetConditionalOperator    
AS                                
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetConditionalOperator                                
Programmer: Mostafa Helmy                                
Description: Get Conditional Operator   #GFSY00754   
*/                      
  
If Exists(Select * From ConditionalOperator)   
Begin  
 Select Id,conditional_operator_name,conditional_operator From ConditionalOperator   
End  
go
 drop_old_proc 'GetCustomExceptionCharges'
GO
 create  procedure dbo.GetCustomExceptionCharges             
  @ConditionID nvarchar(100)
AS                              
/*                              
CreationDate: 2018-12-02                    
OriginalName: dbo.GetCustomExceptionCharges                              
Programmer: Ahmed Osman                              
Description: Get Conditions from CustomExceptionChargesConditions || CR#GFSY00739 - Add Custom Exception Charges       
*/                    
If Exists(Select * From CustomExceptionChargesConditions Where ConditionId = @ConditionID)	
	BEGIN
		Select Seq, ODT.Id as 'DataType', Operand1, CO.Id as 'Operator', Operand2, LogicalOperator 
		From OperandDataType ODT RIGHT JOIN CustomExceptionChargesConditions CECC
			ON ODT.Id = CECC.OperandsDataType
		LEFT JOIN ConditionalOperator CO
			ON CECC.Operator = CO.Id
		where ConditionId = @ConditionID
	End
	
GO
 drop_old_proc 'GetEvaluationCustomException'
GO
 create  procedure dbo.GetEvaluationCustomException             
  @ConditionID nvarchar(100)
AS                              
/*                              
CreationDate: 2018-12-02                    
OriginalName: dbo.GetEvaluationCustomException                              
Programmer: Ahmed Osman                              
Description: Get Conditions from CustomExceptionChargesConditions  || CR#GFSY00739 - Add Custom Exception Charges      
*/                    

If Exists(Select * From CustomExceptionChargesConditions Where ConditionId = @ConditionID)	
	Begin
		Select ID, Seq, OperandsDataType as 'DataType', Operand1, Operator, Operand2, LogicalOperator
		From CustomExceptionChargesConditions Where ConditionId = @ConditionID
	End

GO
drop_old_proc 'GetExceptionalCharge'
GO
CREATE PROC dbo.GetExceptionalCharge --160, 100000,'101010',1,'20582','100000084421',0,@ExceptionAmount OUT ,'CUR','BHD',1          
 @TranID int,--@TranName varchar(40),              
 @TranAmount money ,              
 @ChrgCode varchar(20),              
 @RimClass int ,              
 @RimNo char(10) ,              
 @AcctNo varchar(60),              
 @ProfileId int,              
 @ChrgAmt decimal (18, 6) OUT,            
 @AcctType AccountTypeCode = null,          
 @AccountCurrency CurrencyType = null,          
 @DebitRate  decimal(24,9) ,      
 @BusDate datetime,     
-- @TranOption int = -1,      
 @TranOption nvarchar(40) = NULL,  
 @TranCurrency CurrencyType = null,
 @AccountClass int = -1,
 @DefaultCurr varchar(4)=NULL ,
 @CustomExceptionID varchar(100) out  
 --@LocationCharge int =-1    
        
 AS          
 /*              
  CreationDate: 22-JUN-2008              
  OriginalName: dbo.GetExceptionalCharge              
  Programmer: Hasan Ebrahim              
  Description: Select exceptional charges for Transaction | Rim Class | Rim Number | Account Number              
  Output: Exceptional Charge Amount              
  Assumption:               
              
  ModifiedDate:14-09-2008                                 
  Modifer: Eman Gouda                                 
  ModifyReason: add customer profile id as a search criteria in retreiving exceptional charges               
            
  ModifiedDate:14-09-2008                                 
  Modifer: Osama Orabi                               
  ModifyReason: add AcctType as a search criteria in retreiving exceptional charges             
             
  ModifiedDate:26-10-2008                                 
  Modifer: Osama Orabi                               
  ModifyReason: Retrieve Exceptional Exchange Rates according to priority [Account#, AccoutType, CustomerProfileID, Rim#, RimClass]             
            
  ModifiedDate:23-03-2009                                 
  Modifer: Amira Kamel                                 
  ModifyReason: Change Exception table to ExceptionCharges table and calculate exception amount accourding to selected currancy           
                  
  ModifiedDate:29-7-2009                                 
  Modifer: Mostafa Essam                                 
  ModifyReason: Change in where search citria to get also if value string.Empty       
        
  ModifiedDate: 20-08-2009                                 
  Modifer:  Amira Kamel                                 
  ModifyReason: Add new parameter @BusDate to use in get Exceptional charges       
                  
  ModifiedDate: 28-1-2010                                       
  Modifer:  Aya Mahmoud      
  ModifyReason:   Enlarge decimal parameters from (21,6) to (24,9)     
      
  ModifiedDate: 25-7-2011    
  Modifer: Lamiaa Mostafa    
  Modify Reason: Add TransactionOption and TransactionCurrency as a search criteria in retreiving exceptional charges       
     
  ModifiedDate: 27-10-2011    
  Modifer: Mohammed El-Masry  
  Modify Reason: Add LocationCharge as a search criteria in retreiving exceptional charges         
  
  ModifiedDate: 2012-01-08      
  Modifer: Mohamed Sobhy    
  Modify Reason: Remove Location 
  
  ModifiedDate: 2013-04-01    
  Modifer: Mohamed Farouk  
  Modify Reason: CBD CR GFSY00210, exceptional charges with account class code
  
  ModifiedDate: 2014-01-14
  Modifer: Mohamed Farouk  
  Modify Reason: Defect GFSX06079 on CBD CR GFSY00318 exceptional charges amount shoulf override min and max
				 charge amount in case of percent fee
				 
  ModifiedDate: 2014-12-12    
  Modifer: Karim Mahmoud  
  Modify Reason: BBK CR GFSY00362, exceptional charges with fixed or percentage amounts, transaction amount and operator value.				 
     
 ModifiedDate: 2018-12-03     
  Modifer: Ahmed Osman   
  Modify Reason: CR#GFSY00739 - Add Custom Exception Charges            
*/              
BEGIN          
--set @TranAmount=@TranAmount*@DebitRate
	declare @DefaultCurrency tinyint
	set @DefaultCurrency=(select DecimalPlaces from CurrencyType where CurrencyType=@DefaultCurr)
   declare @isChargeInLocal Bit          
   SELECT @isChargeInLocal =E.isChargeInLocal, 
  @CustomExceptionID = CustomException ,	-- Ahmed Osman CR#GFSY00739
@ChrgAmt = CASE  WHEN  ((E.Operator='') or
																				 (E.Operator='<' and ROUND(@TranAmount,@DefaultCurrency) < E.TransactionAmount ) or 
																				 (E.Operator='<=' and ROUND(@TranAmount,@DefaultCurrency) <= E.TransactionAmount) or
																				 (E.Operator='>' and ROUND(@TranAmount,@DefaultCurrency) > E.TransactionAmount) or
																				 (E.Operator='>=' and ROUND(@TranAmount,@DefaultCurrency) >= E.TransactionAmount) or
																				 (E.Operator='=' and ROUND(@TranAmount,@DefaultCurrency) = E.TransactionAmount))  
																			THEN
																				CASE E.IsFixedCharge WHEN  1 THEN  E.ChargeAmount WHEN  0 THEN 
																					CASE WHEN (((ROUND(@TranAmount,@DefaultCurrency) * E.Percentage) / 100) < E.MinimumAmount)
																							THEN E.MinimumAmount
																						WHEN (((ROUND(@TranAmount,@DefaultCurrency) * E.Percentage) / 100) > E.MaximumAmount)
																							THEN E.MaximumAmount
																						ELSE ((ROUND(@TranAmount,@DefaultCurrency) * E.Percentage) / 100)
																					END
																				END  
															ELSE
																-1           
															END        
   --(              
   --  CASE              
   --   WHEN (((@TranAmount * E.ChargeAmount) / 100) < F.[MIN]) THEN F.[MIN]               
   --   WHEN (((@TranAmount * E.ChargeAmount) / 100) > F.[Max]) THEN F.[Max]               
   --   ELSE ((@TranAmount * E.ChargeAmount) / 100) END               
   --)END --,@BookingFeeName = FeeName ,@BookingCoreFeeCode = CoreFeeCode              
   FROM   ExceptionCharges E              
   INNER JOIN Fee F              
 ON E.ChargeCode = F.FeeCode              
 WHERE E.ChargeCode  = @ChrgCode             
 AND (E.TranID  = @TranID )            
 --AND (AccountCurrency = @AccountCurrency OR AccountCurrency is null)            
 --AND (AccountNumber  = @AcctNo   Or AccountNumber is null)         
 AND ((AccountCurrency  = case when(@AccountCurrency is null or ltrim(rtrim(@AccountCurrency))='') then AccountCurrency Else @AccountCurrency end ) or AccountCurrency is null or AccountCurrency = '')                   
 AND (AccountNumber  = @AcctNo OR (1=1 AND AccountNumber ='') OR (1=1 AND AccountNumber is null))         
 AND (AccountType  = @AcctType OR (1=1 AND AccountType is null)  OR (1=1 AND AccountType = ''))      
 --AND (AccountType  = @AcctType   OR AccountType is null)            
 AND (CustomerNumber = @RimNo   OR CustomerNumber is null)            
 AND (CustomerClass  = @RimClass   OR CustomerClass is null)            
 AND (CustomerProfileId = @ProfileID  OR CustomerProfileID is null)    
 AND (TransactionCurrency = @TranCurrency OR TransactionCurrency is null)   
 AND (AccountClass = @AccountClass Or AccountClass = -1 Or AccountClass is null)
 AND (TransactionOption = @TranOption OR TransactionOption is null)      
 AND  (CAST( convert(varchar, E.EffectiveDate, 111)as datetime) <= @BusDate)      
 AND  (CAST( convert(varchar, E.ExpirationDate, 111)as datetime)>= @BusDate)            
 --AND (LocationCharge = @LocationCharge OR LocationCharge is null OR LocationCharge =-1)          
        
           
  ORDER BY        
      
  case when AccountNumber     is null then '0' else '1' end,      
  case when AccountCurrency   is null then '0' else '1' end,                  
  case when AccountType       is null then '0' else '1' end,            
  case when CustomerNumber    is null then '0' else '1' end,            
  case when CustomerClass     is null then '0' else '1' end,            
  case when CustomerProfileID is null then '0' else '1' end,    
  case when TransactionCurrency is null then '0' else '1' end,     
  case when TransactionOption is null then '0' else '1' end --,  
  --case when LocationCharge is null or LocationCharge=-1 then '0' else '1' end 
        --print ROUND(@TranAmount,3)          
   IF(@ChrgAmt = -1)          
	BEGIN
		SELECT @ChrgAmt = -1
	END
  Else
    BEGIN
		SELECT @ChrgAmt = CASE @isChargeInLocal WHEN  1 THEN @ChrgAmt WHEN  0 THEN @ChrgAmt*@DebitRate end 
    END 
    /*AND (RIMClass  = @RimClass or (1=1 AND RimClass is null))              
    AND (RIM  = @RimNo or (1=1 AND RIM =''))              
    AND (Account  = @AcctNo OR (1=1 AND Account =''))              
    AND (TranName  = @TranName OR (1=1 AND TranName = ''))              
    AND (CustomerProfileId  = @ProfileId OR (1=1 AND CustomerProfileId is null))            
    AND (AccountType = @AcctType or AccountType is null)              
   */            
             
END
Return     
GO

 Drop_old_proc GetOperandDataType
GO
 create  procedure dbo.GetOperandDataType      
AS                                
/*                                
CreationDate: 2019-03-20                      
OriginalName: dbo.GetOperandDataType                                
Programmer: Mostafa Helmy                                
Description: Get Operand DataType || CR#GFSY00754 - ID Expiry Date       
*/                      
  
If Exists(Select * From OperandDataType)   
BEGIN  
 SELECT Id,data_type FROM OperandDataType   
End  
  
Go
drop_old_proc 'InsertCustomeExcepCharges'
GO
create  Proc dbo.InsertCustomeExcepCharges 
@Custome_Excep_DataTable  CustomeExcepCharges readonly,
@TranID int,
@FeeChargeCode int
as                
/*
 CreationDate	:	29-11-2018       
 Programmer		:	Ahmed Osman
 Description	:	Insert data into table CustomExceptionChargesConditions || CR#GFSY00739 - Add Custom Exception Charges
*/   
declare @ConditionID int = -1 , @Id int
declare @DataTypeID int , @Operator int

If Exists(SELECT CustomException FROM ExceptionCharges WHERE TranID = @TranID AND ChargeCode = @FeeChargeCode)
BEGIN
	SELECT @ConditionID = CustomException FROM ExceptionCharges WHERE TranID = @TranID AND ChargeCode = @FeeChargeCode AND CustomException IS NOT NULL
END

IF(@ConditionID = -1)	-- New
begin
	If Exists(SELECT * FROM CustomExceptionChargesConditions)	-- in case CustomExceptionChargesConditions table hasn't any rows
		SELECT @ConditionID = max(ConditionId) + 1 FROM  CustomExceptionChargesConditions
	ELSE
		SELECT @ConditionID = 1
End
ELSE	-- Update
	DELETE FROM CustomExceptionChargesConditions WHERE [ConditionId] = @ConditionID
	
SELECT * INTO #CustomeExcepTemp from @Custome_Excep_DataTable

While (Select Count(*) From #CustomeExcepTemp) > 0
Begin

	SET @DataTypeID = null 
	SET @Operator = null
	
    Select Top 1 @Id = Seq From #CustomeExcepTemp

	SELECT @DataTypeID = id FROM OperandDataType WHERE id IN (Select Top 1 DataType From #CustomeExcepTemp)
	SELECT @Operator = id FROM ConditionalOperator WHERE id IN (Select Top 1 Operator From #CustomeExcepTemp)
	
    INSERT INTO CustomExceptionChargesConditions ([ConditionId],[Seq],[OperandsDataType],[Operand1],[Operator],[Operand2],[LogicalOperator])
	SELECT TOP(1)@ConditionID,Seq,@DataTypeID,Operand1,@Operator,Operand2,LogicalOperator FROM #CustomeExcepTemp

    Delete #CustomeExcepTemp Where Seq = @Id
END

SELECT @ConditionID

IF OBJECT_ID('tempdb..#CustomeExcepTemp') IS NOT NULL DROP TABLE #CustomeExcepTemp
GO

  drop_old_proc 'dbo.Insert_Update_Excep_Charges'
  go
 CREATE  procedure dbo.Insert_Update_Excep_Charges  --Insert_Update_Excep_Charges 0,160,2,null,'','','',null,'000011',"SecondSubFee",10,'','2010-2-15','2010-2-15',1            
 @Flag  [int] ,                           
 @TranID [int] = null ,                             
 @ProfileID [int]=null,                          
 @RimClass [int]=null,                          
 @RIM  [int] =null,                           
 @AccountType [varchar] (10)  ='',       
 @AccountClass [int],    
 @Account [char] (12)  ='',                          
 @ExceptionId [int] = null,                            
 @ChargeCode FeeID = null,                            
 @ChargeName [string_30] = '' ,                            
 @ChargeAmount [money]  = null ,                      
 @CurrencyType [CurrencyType]  ='',          
 @TranOption nvarchar(40) = null,          
 @TranCurr [CurrencyType]  ='',                    
 @EffectiveDate datetime,                
 @ExpirationDate datetime,                                
 @isChargeInLocal [bit] =1 ,      
-- @LocationCharge int = -1   
 @PostponedCharges [bit] = 0    ,
  @IsFixedCharge bit,
 @Percentage money,
 @Min money,
 @Max money ,
 @TranAmt money,
 @Operator varchar(20),
 @CustomException int ,
 @UserName OperatorID = null              
as                            
/*                            
 CreationDate: 2009-3-19                            
 OriginalName: dbo.Insert_Update_Excep_Charges                            
 Programmer: Amira Kamel                           
 Description: Insert new charge record in the ExceptionCharges table                        
 Output:  return 1 if insert rwo and -1 if not inserted due to duplicated values                            
 Assumption:                         
                      
Updated BY  : HaTiM SuM                      
Updated Date : 2009-03-23                      
Reason   : Add CurrencyType as parameter to search options                     
                  
Updated BY  : Amira kamel                      
Updated Date: 2009-03-23                      
Reason  : Update column isChargeInLocal                
            
Updated BY  : Amira kamel                      
Updated Date: 2010-03-22                      
Reason  : change data type for @ChargeCode to be feeid                
          
Updator BY: Lamiaa Mostafa          
Updated Date: 7/21/2011          
Reason: Add TransactionOption and TransactionCurrency as Exception parameters          
        
 ModifiedDate: 27-10-2011          
 Modifer: Mohammed El-Masry        
 Modify Reason: Add LocationCharge as a search criteria in retreiving exceptional charges        
     
 ModifiedDate: 2011-12-28          
 Modifer: Ahmed Eldeeb        
 Modify Reason: Issue # 100374 convert exceptional charges transaction Option [ @TranOption] frm int to nvarchar(40) to accept various charge type depend on the combo in transaction    
     
 ModifiedDate: 2012-01-08          
 Modifer: Mohamed Sobhy        
 Modify Reason: Remove Location     
     
      
 ModifiedDate: 2013-04-01    
 Modifer: Mohammed Farouk      
 Modify Reason: CR CBD CR GFSY00210, add account class    
   
 ModifiedDate:   2014-01-29  
 Modifer:  Asmaa Hafez        
 Modify Reason:  CBD Defect # GFSX05373, add postpone charges  
     
 ModifiedDate:  01-04-2014
 Modifer:  Aya Mahmoud    
 Modify Reason:  Add the @UserName parameter
 
 ModifiedDate:  09-12-2014
 Modifer:  Karim Mahmoud    
 Modify Reason:  CR# GFSY00362, add isFixed,Percentage,Min,Max,TranAmt and Operator

 ModifiedDate:  01-02-2017
 Modifer:  Mostafa Abdlrazek
 Modify Reason:  CR#GFSY00613 Remove "and" from where clause of TranId, Change default value of tranId to be Null instead of ''

 ModifiedDate:  27-08-2017
 Modifer:  Asmaa Gamal    
 Modify Reason:  Issue GFSX12410 allow add a charge name having character ' in its name.
 ModifiedDate:  29-11-2018  
 Modifer:  Ahmed Osman        
 Modify Reason: CR#GFSY00739 - Add Custom Exception Charges
*/                            
                      
select @TranID = CASE WHEN @TranID IS NULL THEN -1 ELSE @TranID END           
select @ProfileID = case @ProfileID  when '' then null else @ProfileID  end                          
select @RimClass = case @RimClass  when '' then null else @RimClass  end                          
select @RIM  = case @RIM   when '' then null else @RIM   end                            
select @AccountType = case @AccountType when '' then null else @AccountType end          
select @AccountClass = case @AccountClass when -1 then null else @AccountClass end                          
select @Account = case @Account  when '' then null else @account  end                          
--select @ChargeName = case @ChargeName when '' then null else @ChargeName end                        
select @CurrencyType = case @CurrencyType when '' then null else @CurrencyType end          
select @TranOption = case convert(varchar(40) , @TranOption ) when '' then null else @TranOption end           
select @TranCurr = case  @TranCurr when '' then null else  @TranCurr end                          
--select @LocationCharge = case  @LocationCharge when null then -1 else  @LocationCharge end                
        
declare @Sql varchar(1000)                              
if @Flag = -1 -- check case                            
begin -- check case                            
                           
                       
                           
 set @sql = ' if exists (Select ExceptionChargesID from ExceptionCharges Where '                           
   + case when @TranID  is null  then ' TranID = -1 '    else ' TranID = ' + convert(varchar, @TranID)end                       
   + case when @ProfileID   is null  then ' and CustomerProfileId is Null ' else ' and CustomerProfileId = '  + CAST(@ProfileID AS varchar(5))   end                          
   + case when @RimClass    is null  then ' and CustomerClass is Null '  else ' and CustomerClass = '   + CAST(@RimClass AS varchar(20))    end                          
   + case when @RIM   is null  then ' and CustomerNumber is Null '  else ' and CustomerNumber = '''    + CAST(@RIM AS varchar(20))    + '''' end                          
   + case when @AccountType is null  then ' and AccountType is Null '  else ' and AccountType = '''  + @AccountType    + '''' end                          
   + case when @AccountClass is null  then ' and AccountClass is Null '  else ' and AccountClass = '  + CAST(@AccountClass AS varchar(20)) end                          
   + case when @Account     is null  then ' and AccountNumber is Null '  else ' and AccountNumber = '''   + @Account     + '''' end                      
   + case when @ChargeName  is null  then ' and ChargeName is Null '   else ' and ChargeName= '''  +  REPLACE(@ChargeName,'''','''''')    + '''' end                        
   + case when @CurrencyType  is null then ' and AccountCurrency is Null ' else ' and AccountCurrency= '''  + @CurrencyType    + '''' end                          
   + case when @TranOption  is null then ' and TransactionOption is Null ' else ' and TransactionOption= '''  + CAST(@TranOption  AS varchar(40))+ '''' end                          
  + case when @TranCurr  is null then ' and TransactionCurrency is Null ' else ' and TransactionCurrency= '''  + @TranCurr    + '''' end        
     + case when @CustomException  is null then ' and CustomException is Null ' else ' and CustomException = 1 ' end		--Ahmed Osman CR#GFSY00739  
 --+ case when @LocationCharge  = -1 then ' and LocationCharge =-1 ' else ' and LocationCharge= '  + CAST(@LocationCharge AS varchar(2)) end                            
 +')select 1 else select 0'                          
                             
                             
       print(@sql)                   
 execute (@sql)                          
                           
                          
end         else if @Flag = 0                          
BEGIN -- inserts case                           
 declare @maxid  as numeric                          
 exec Next_Table_MaxID 'ExceptionCharges','ExceptionChargesID',@maxid output                 
                           
 INSERT INTO ExceptionCharges                          
 (                            
  ExceptionChargesID,                            
  TranID,                            
  CustomerProfileId,                           
  CustomerClass,                           
  CustomerNumber,                          
  AccountType,        
  AccountClass,                        
  AccountNumber,                              
  ChargeCode,                          
  ChargeName,                           
  ChargeAmount,                      
  AccountCurrency ,                      
  isChargeInLocal ,
  IsFixedCharge ,
  Percentage ,
  MinimumAmount ,
  MaximumAmount ,  
  TransactionAmount,
  Operator,                 
  EffectiveDate,                
  ExpirationDate,          
  TransactionOption,          
  TransactionCurrency ,                       
  --LocationCharge    
  PostponedCharges,
  CustomException,	--Ahmed Osman CR#GFSY00739     
  Creator,
  Updator           
      
 )                            
 VALUES                            
 (                            
  @maxid,                              
  @TranID,                              
  @ProfileID,                           
  @RimClass,                           
  @RIM,                            
  @AccountType,       
  @AccountClass,                       
  @Account,                             
  @ChargeCode,                           
  @ChargeName,                           
  @ChargeAmount,                      
  @CurrencyType,                      @isChargeInLocal ,
  @IsFixedCharge,
  @Percentage,
  @Min,
  @Max,
  @TranAmt,
  @Operator,                
  @EffectiveDate,                
  @ExpirationDate,          
  @TranOption,          
  @TranCurr ,     
--  @LocationCharge    
  @PostponedCharges,
  @CustomException,		--Ahmed Osman CR#GFSY00739   
  @UserName,
  @UserName       
   
 )                            
  set @sql ='select 0'           
   execute (@sql)                         
END-- inserts case                           
                           
else                           
 if @Flag = 1                           
BEGIN--updates case                            
                           
   begin                            
    UPDATE ExceptionCharges                        
    SET                       
   --ChargeCode = @ChargeCode,                            
   --ChargeName = @ChargeName,                            
   ChargeAmount = @ChargeAmount,                  
   isChargeInLocal =  @isChargeInLocal   ,
   IsFixedCharge =@IsFixedCharge,
  Percentage =@Percentage,
  MinimumAmount =@Min,
  MaximumAmount =@Max,
  TransactionAmount =@TranAmt,
  Operator =@Operator,                   
  EffectiveDate=@EffectiveDate,                
  ExpirationDate=@ExpirationDate ,  
  PostponedCharges = @PostponedCharges ,
  Updator = @UserName                     
  WHERE                           
   ExceptionChargesID=@ExceptionId                          
 end                            
   set @sql ='select 1'           
   execute (@sql)          
                             
END--updates case   
go                         
drop_old_proc  'Search_Charge_Exception'
 GO
 create  procedure dbo.Search_Charge_Exception            
  @TranID [int] ='',                              
  @RIM  [int] ='',                      
  @AccountType [char] (10)='',                            
  @Account [char] (12)  ='',                      
  @RimClass [int]  ='',                      
  @CustomerProfileId [int] ='',                  
  @CurrencyType [CurrencyType]  ='' ,           
  @TranOption nvarchar(40) = '',          
  @TranCurr [CurrencyType] ='',  
  @AccountClass [int] = -1,           
  @LCID LanguageLCID = 1030 --,      
  --@LocationCharge int = -1                   
                            
AS                            
/*                            
CreationDate: 2009-3-19                  
OriginalName: dbo.Search_Charge_Exception                            
Programmer: Amira Kamel                            
Description: Search for Charge Exception                    
                  
Updated BY  : HaTiM SuM                  
Updated Date : 2009-03-23                  
Reason   : Add CurrencyType as parameter to search options                   
                  
Updated BY  : HaTiM SuM                  
Updated Date : 2009-03-29                  
Reason   : Enhance Performance of procedure                  
              
Updated BY  : Mostafa Essam                  
Updated Date : 3-8-2009               
Reason   : make check of Dashes of account number              
             
Updated BY  : Amira kamel                 
Updated Date: 2010-3-22               
Reason   :   select tran desc accourding to LCID            
          
Updated BY  : Lamiaa Mostafa           
Updated Date: 2011-7-27               
Reason   : Add Transaction curreny and Transaction Option as search parameter       
      
 ModifiedDate: 27-10-2011        
 Modifer: Mohammed El-Masry      
 Modify Reason: Add LocationCharge as a search criteria in retreiving exceptional charges       
     
 ModifiedDate: 2011-12-28      
 Modifer: Ahmed Eldeeb      
 Modify Reason: Issue # 100374 change the transaction Option to nvarchar to allow multiple values    
   
     
ModifiedDate: 2012-01-08        
Modifer: Mohamed Sobhy      
Modify Reason: Remove Location   
  
ModifiedDate: 2012-01-15        
Modifer: Mohamed Sobhy      
Modify Reason: Adapt @TranOption to varchar  
  
ModifiedDate: 2013-03-31  
Modifer: Mohamed Farouk      
Modify Reason: CBD CR GFSY00210, add exception setup by account class code 

ModifiedDate: 2013-03-31  
Modifer: Mohamed Farouk      
Modify Reason: CBD CR GFSY00210, add exception setup by account class code   

ModifiedDate:   2014-01-29
Modifer:		Asmaa Hafez      
Modify Reason:  CBD Defect # GFSX05373, add postponed charges
     
 ModifiedDate:  10-12-2014
 Modifer:  Karim Mahmoud    
 Modify Reason:  CR# GFSY00362, add isFixed,Percentage,Min,Max,TranAmt and Operator   

 ModifiedDate	:	29-11-2018       
 Programmer		:	Ahmed Osman
 Description	:	return CustomException condition ID CR#GFSY00739
*/                  
                            
set nocount on                            
if (len(replace(@Account,'-','')) = 0) set    @Account = null                         
select @TranID = case convert(varchar(10) ,  @TranID)  when '' then null else @TranID  end                      
select @RIM  = case convert(varchar(10) , @RIM )  when '' then null else @RIM   end                      
select @AccountType = case @AccountType when '' then null else @AccountType end                      
--select @Account = case @Account  when ''  then null else @account  end                      
select @RimClass =case convert(varchar(10) ,  @RimClass)  when '' then null else @RimClass  end                      
select @CustomerProfileId = case convert(varchar(10) ,  @CustomerProfileId)  when '' then null else @CustomerProfileId  end                      
select @CurrencyType = case @CurrencyType when '' then null else @CurrencyType end           
select @TranOption = case convert(varchar(40) ,  @TranOption)  when '' then null --when -1 then null   
                else @TranOption end           
select @TranCurr = case @TranCurr when '' then null else @TranCurr end           
--select @LocationCharge = case @LocationCharge when -1 then null else @LocationCharge end                     
          
select                   
 ExceptionChargesID,                      
 ExceptionCharges.TranID,                        
 isnull(L.LocalDescription,RD.Descriptor)  as TransactionName,                            
 TransactionCurrency,                   
 cp.Descriptor as CustomerProfile,                     
 rm.Descriptor as RimClassDesc,                      
 CustomerNumber,                  
 AccountNumber,                   
 AccountCurrency,                    
 AccountType,                              
 ChargeCode,                            
 ChargeName,                            
 ChargeAmount,                     
 isChargeInLocal,   
 CustomerProfileId ,                      
 CustomerClass   ,           
 ExceptionCharges.EffectiveDate,              
 ExceptionCharges.ExpirationDate,     
 -- topt.Descriptor as TransOption ,  
 TransactionOption as TransOption,  
 IsNull(AccountClass,-1) As AccountClass,  
 '' as AccountClassDesc,
 IsNull (PostponedCharges,0) As PostponedCharges,
 IsFixedCharge ,
  Percentage ,
  MinimumAmount ,
  MaximumAmount ,  
  TransactionAmount,
  Operator ,
	CASE 
		WHEN CustomException IS NULL THEN 0  
		WHEN CustomException IS NOT NULL THEN 1 
	END as 	CustomCharges,	--Ahmed Osman CR#GFSY00739
  CustomException as CustomExceptionConditionID	--Ahmed Osman CR#GFSY00739
 --LocationCharge                       
 from                      
 ExceptionCharges                      
 left outer join  picklist_entries as p1 on (ExceptionCharges.CustomerProfileId = p1.Value  and p1.PickListID =1000049)                      
 left outer join RulesDescriptor as cp on p1.DescriptorName = cp.Name                     
 left outer join  picklist_entries as p2 on (ExceptionCharges.CustomerClass = p2.Value  and p2.PickListID =1000004)                      
 left outer join RulesDescriptor as rm on p2.DescriptorName = rm.Name            
  left outer join  picklist_entries as p3 on (ExceptionCharges.TransactionOption = p3.Value  and p3.PickListID =237)                      
 left outer join RulesDescriptor as topt on p3.DescriptorName = topt.Name                     
 inner join RulesTranName   as RTN on (ExceptionCharges.TranID=RTN.TranID)            
 inner join dbo.RulesDescriptor  as RD  on RTN.DSC_Description = RD.DescriptorID      Left outer JOIN  RulesDescriptorLocal L               
 on L.DescriptorID = RD.DescriptorID             
 and LCID =  @LCID                 
             
where                  
  (ExceptionCharges.TranID = @TranID      or  @TranID =0)          
   AND (ExceptionCharges.AccountType = @AccountType   or @AccountType  is null)              
  And (ExceptionCharges.CustomerClass = @RimClass or @RimClass =0)                  
  AND (ExceptionCharges.CustomerNumber = @RIM     or @RIM    = 0)                  
 AND (ExceptionCharges.AccountType = @AccountType   or @AccountType  is null)                  
 AND (ExceptionCharges.AccountNumber = @Account    or @Account    is null)                  
 AND (ExceptionCharges.CustomerProfileId =@CustomerProfileId or @CustomerProfileId = 0)                   
 AND (ExceptionCharges.AccountCurrency = @CurrencyType  or @CurrencyType is null)           
 AND (ExceptionCharges.TransactionOption = @TranOption OR @TranOption is null)          
 AND (ExceptionCharges.TransactionCurrency = @TranCurr OR @TranCurr is null)       
 And (ExceptionCharges.AccountClass = @AccountClass Or @AccountClass is null or @AccountClass = -1)  
 --AND (ExceptionCharges.LocationCharge = @LocationCharge OR @LocationCharge is null) 
                 
  GO
  --Start of Automatic Generation By Zaatar And Barbary
Drop_old_proc Delete_Exceptional_Charges
Go

CREATE procedure dbo.Delete_Exceptional_Charges
   @ExceptionChargesID [numeric]
As      
/*      
 Creation Date	: 23 March 2009    
 Original Name	: dbo.Delete_Exceptional_Charges      
 Programmer		: HaTiM Description	: Delete ESuM      
 xceptional Charges From table ExceptionCharges      
 Output			: Delete Selected Row      
 
 Programmer		: Nehal Ramadan	: Delete customsExceptionalCharge     
*/

 begin tran 
 begin
 --nehal ramadan GFSX13713 start
DELETE cec
FROM CustomExceptionChargesConditions cec
INNER JOIN ExceptionCharges e
  ON e.CustomException=cec.ConditionId
WHERE ExceptionChargesID=@ExceptionChargesID
 --nehal ramadan GFSX13713 end

 delete ExceptionCharges       
 where ExceptionCharges.ExceptionChargesID=@ExceptionChargesID
end           
      
if(@@error=0)      
begin      
 commit tran      
 return 1      
end      
else      
begin      
 rollback tran       
 return -1      
end    


Go
--End of Automatic Generation

Drop_old_proc Get_SQLstrings3
Go
create proc Get_SQLstrings3    
as    
-- Get a list of SQL strings for use by DataAccess into     
-- a recordset format    
-- 17- 12 - 2013   
-- developer : ahussein  
set nocount off    
SELECT AccessID, CommandType, AccessName,AccessString  
from dbo.SQLstrings     
Where ExpirationDate >= getdate()  and CommandType = 'p'  
order by AccessName 
GO

DROP_OLD_PROC GetBranchCombo
GO
CREATE PROC GetBranchCombo 
@Bank BankID, @Region RegionID
AS
/*
Modifier: Reem Mandour
Modification Date : 2014-11-27
Purpose: get branches based on whether "DiplayAllBranchs" is '0' or '1'


Modifier: Asmaa Gamal
Modification Date : 2015-06-28
Purpose: Open/Edit Account -Account branch picklist retrieves all regions and all banks not branch only


Modifier: Nehal Ramadan 
Modification Date : 2019-07-28
Purpose: restore id that was removed by the Asmaa Edition, it is used in productRate  transaction to retrieve all branch ids.

*/
SET NOCOUNT ON 

Declare @DisplayAllBranches bit
EXECUTE Get_BankConfigProperty @Bank,'DisplayAllBranchs',@DisplayAllBranches OUTPUT    
         
if(@Region = -1)            
 select  B.Bank,              
   B.Region,              
   B.Branch,              
   B.Name,    
   Bc.Prefix    
 from  dbo.Branches as B     
 Inner join dbo.BranchConfig BC  
 on B.Bank = BC.Bank   
 AND B.Region = BC.Region  
 AND B.Branch = BC.Branch              
 where B.Bank=@Bank  order by Name asc      
else            
 select  B.Bank,              
   B.Region,              
   B.Branch,              
   B.Name,  
   Bc.Prefix    ,
   B.id -- nehal ramadan issue GFSX13756
 from  dbo.Branch as B  
 Inner join dbo.BranchConfig BC  
 on B.Bank = BC.Bank   
 AND B.Region = BC.Region  
 AND B.Branch = BC.Branch               
 where B.Bank=@Bank              
 and (@DisplayAllBranches = 1 OR B.Region=@Region)
order by Name asc     
Go 
--End of Automatic Generation


