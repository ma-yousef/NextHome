﻿USE [Globalfs]
GO
       
If Not Exists(Select * From ServicePacks Where BasePackageName = 'ETHIX-Branch_2.00.46' And SP_Number = 41)
Begin
Insert Into ServicePacks(BasePackageName,SP_Number,SP_Name, LastPackageName, BriefDescription, DetailedDescription,IncludeWholeFilesOnly,DontRemoveTmpFldrWhenFinished,OptionalSourceList,Comments,PatchNumber)
Values('ETHIX-Branch_2.00.46', 41,'SP41_ETHIX-Branch_2.0.46.0','SP40_ETHIX-Branch_2.0.46.0','SP41_ETHIX-Branch_2.0.46.0','', 1, 0, '', '',0)
End
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================
PRINT 'Start. Script for CR# GFSY00865 DML Script'
GO

--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105925)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105925,'TLR_OPS_PendingReview',0,'Labels','Pending Review','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105925 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105925,1025,N'في انتظار المراجعة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105926)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105926,'TLR_OPS_PendingApproval',0,'Labels','Pending Approval','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105926 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105926,1025,N'ما زال يحتاج بتصدير','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105927)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105927,'TLR_OPS_Approved',0,'Labels','Approved','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105927 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105927,1025,N'وافق','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105928)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105928,'TLR_OPS_Repaired',0,'Labels','Repaired','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105928 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105928,1025,N'تم الاصلاح','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105929)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105929,'TLR_OPS_Posted',0,'Labels','Posted','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105929 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105929,1025,N'تم النشر','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105930)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105930,'TLR_OPS_Rejected',0,'Labels','Rejected','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105930 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105930,1025,N'مرفوض','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105931)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105931,'TLR_OPS_Returned',0,'Labels','Returned','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105931 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105931,1025,N'عاد','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105932)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105932,'TLR_OPS_DisplayOPSWorkFlow',0,'Labels','Display OPS WorkFlow','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105932 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105932,1025,N'عرض سير عمل OPS','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105933)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105933,'TLR_OPS',0,'Labels','OPS...','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 15391)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,15391,'SEARCH_CRITERIA',0,'Labels','Search Criteria','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105934)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105934,'TLR_BusinessDateFrom',0,'Labels','Business Date (From)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105935)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105935,'TLR_BusinessDateTo',0,'Labels','Business Date (To)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1000026)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1000026,'COR_TRANSACTIONS',0,'Labels','Transactions','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 340)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,340,'TLR_STATUS',0,'Labels','Status','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105641)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105641,'TLR_REQUEST_ID',0,'Labels','Request ID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105641)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105641,'TLR_REQUEST_ID',0,'Labels','Request ID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105936)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105936,'TLR_Submitter',0,'Labels','Submitter','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -269869)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-269869,'REGION',0,'Labels','Region','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -269868)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-269868,'BRANCH_LABEL',0,'Labels','Branch','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105289)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105289,'TLR_RIM_NUMBER',0,'Labels','Rim Number','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10042)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-10042,'TLR_CURRENCY',0,'Labels','Currency','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10190)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-10190,'TLR_SEARCH',0,'Labels','Search','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105937)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105937,'TLR_OPS_WorkFlowTrans',0,'Labels','WorkFlow Transactions','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105937 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105937,1025,N'معاملات تدفق العمل','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1439)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1439,'TLR_SO_PRINT_VIEW',0,'Labels','View','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1138)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1138,'TLR_POST',0,'Labels','Post','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1101035)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1101035,'TLR_REJECT',0,'Labels','Reject','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10043)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-10043,'TLR_AMOUNT',0,'Labels','Amount','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 2746)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,2746,'TLR_TRAN_NAME',0,'Labels','Transaction Name','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -269870)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-269870,'BANK',0,'Labels','Bank','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105938)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105938,'TLR_JNLSequence',0,'Labels','JNL Sequence','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -19820)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-19820,'TLR_BUSINESSDATE',0,'Labels','Business Date','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1101018)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1101018,'TLR_TRANSACTION_TIME',0,'Labels','Transaction Time','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105939)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105939,'TLR_BranchUser',0,'Labels','Branch User','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105940)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105940,'TLR_BranchSupervisor',0,'Labels','Branch Supervisor','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105941)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105941,'TLR_TID',0,'Labels','TID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1650)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1650,'TLR_IR_LastChanged',0,'Labels','Last Changed','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10019)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-10019,'TLR_ACCOUNTNUMBER',0,'Labels','Account Number','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105942)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105942,'TLR_OPSUser',0,'Labels','OPS User','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105943)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105943,'TLR_OPSSupervisor',0,'Labels','OPS Supervisor','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1104601)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1104601,'TLR_RejectionReason',0,'Labels','Rejection Reason','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105944)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105944,'TLR_IsLocked',0,'Labels','Is Locked','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1101061)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1101061,'TLR_LOCKED_BY',0,'Labels','Locked By','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105946)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105946,'TLR_OPS_SELECTRECOREDTOVIEW',0,'Labels','Please select a record before click view','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105947)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105947,'TLR_OPS_SELECTRECOREDTOPOST',0,'Labels','Please select a record before click post','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105948)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105948,'TLR_OPS_SELECTRECOREDTOREJECT',0,'Labels','Please select a record before click reject','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105949)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105949,'TLR_OPS_SELECTRECOREDTORETURN',0,'Labels','Please select a record before click return to branch','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105950)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105950,'TLR_OPS_REQUESTISLOCKED',0,'Labels','This request is locked','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105951)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105951,'TLR_OPS_CANNOTDEFINEREQSTATUS',0,'Labels','Cannot define the selected request status','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105955)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105955,'TLR_OPS_POSTINGCONFIRMATION',0,'Labels','Are you sure you want to post this transaction?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105956)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105956,'TLR_OPS_REJECTCONFIRMATION',0,'Labels','Are you sure you want to reject this transaction?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO


If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105958)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105958,'TLR_OPS_REJECTFAILED',0,'Labels','Failed to reject the selected request','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105957)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105957,'TLR_OPS_Reversed',0,'Labels','Reversed','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105959)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105959,'TLR_OPS_CANNOTREJECT_REVERSED',0,'Labels','Cannot reject this transaction as this OPS request was reversed by branch team','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105960)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105960,'TLR_OPS_CANNOTREJECT_POSTED',0,'Labels','Cannot reject this transaction as this OPS request was handled by another teller','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105962)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105962,'TLR_OPSWF',0,'Labels','OPS WF','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105963)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105963,'TLR_OPSWF_Requests',0,'Labels','OPS WF Requests','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

---------------
-- StatusType -
---------------
If Not Exists(Select * From StatusType Where id = 77)
Begin
 Insert Into StatusType(id,Description,Updator,Creator)
 Values (77,'OPSWorkFlow',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

-----------------
-- StatusTypeID -
-----------------
If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 1)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,1,'PendingReview','PendingReview','TLR_OPS_PendingReview',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 2)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,2,'PendingApproval','PendingApproval','TLR_OPS_PendingApproval',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 3)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,3,'Approved','Approved','TLR_OPS_Approved',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 4)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,4,'Repaired','Repaired','TLR_OPS_Repaired',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 5)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,5,'Posted','Posted','TLR_OPS_Posted',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 6)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,6,'Rejected','Rejected','TLR_OPS_Rejected',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 7)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,7,'Returned','Returned','TLR_OPS_Returned',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 8)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,8,'Reversed','Reversed','TLR_OPS_Reversed',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

------------------
-- RulesTranName -
------------------
If Not Exists(Select * From RulesTranName Where TranID = 866)
Begin
 Insert Into RulesTranName(TransactionName,TranID,Description,Developer,DSC_Description,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,RowStatus,Updator,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,TotalsType,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
 Values ('DisplayOPSWorkFlow',866,'Display OPS WorkFlow',N'ITSOFT\ahmed.orashed',1105932,10,'Teller',101,1,'ROP',1,0,0,0,0,0,0,1,N'ITSOFT\ahmed.orashed',0,0,0,0,0,0,0,0,0,0,1,NULL,NULL,NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,1)
End
GO

------------------------
-- RulesContainerTrans -
------------------------
If Not Exists(Select * From RulesContainerTrans Where container_name = 'Teller' And TranName = 'DisplayOPSWorkFlow')
Begin
 Insert Into RulesContainerTrans(container_name,TranName,Updator,RowStatus)
 Values ('Teller','DisplayOPSWorkFlow',N'ITSOFT\ahmed.orashed',1)
End
GO

----------------------
-- TransactionScopes -
----------------------
If Not Exists(Select * From TransactionScopes Where Scope = 1001 And TranID = 866)
Begin
 Insert Into TransactionScopes(Scope,TranID,Developer,Updator,RowStatus)
 Values (1001,866,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

--------------
-- Component -
--------------
If Not Exists(Select * From Component Where ComponentID = 310)
Begin
 Insert Into Component(ComponentID,AppID,ComponentName,ComponentType,Description,ProjectDirectory,ProjectFile,ProjectType,ProjectTarget,ProductionGroup,isSourceShipped,TargetDirectory,TypeLibrary,TypeLibVersion,GUID,VersionInfoFile,FileVersion,ComponentSize,Developer,InstallDirectory,Updator,ProductionGroup2,InstallDirectory2,RowStatus,WiseProject,BuildChangesOnly,SymbolsFile,ProjectGUID)
 Values (310,1,N'DisplayOPSWorkFlow','DLL','',N'Teller.Net\Source\BP\Custom\DisplayOPSWorkFlow',N'DisplayOPSWorkFlow.csproj','C#2010',N'Debug','Client_NonRegistered',0,N'..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\',NULL,NULL,NULL,NULL,'2.0.46.0',57344,N'ITSOFT\ahmed.orashed',N'shared.net\Source\bin\Common\Teller',N'ITSOFT\ahmed.orashed',NULL,NULL,1,N'GFSTellerdotNetClient.wsm',1,N'DisplayOPSWorkFlow.pdb',NULL)
End
GO

--------------------
-- RulesTranConfig -
--------------------
If Not Exists(Select * From RulesTranConfig Where TranID = 866)
Begin
 Insert Into RulesTranConfig(TranID,DenomRequired,AccountingEntries,DrAccountCategoryID,CrAccountCategoryID,LimitCategoryID,FeesCategoryID,ExchangeType,OffLineAmount,AllowEmptyAccountingEntries,VerifySignatrue,ReadAllAccountingEntries,ShowInAdmin,Updator,OD_DrAccountCategoryID,PrintOption,ForcePositioning,EnableCharges,SalesMessageActive,FutureStaleChequeDays,BackDatedStaleChequeDays,ValidateStaleCheque,StaleChequeAction,StaleChequeDefaultDate,EscWarningEnabled,ChqRngVal,ChqRngAction,Blacklisted,BlacklistedAction,BenPmtStrict,BenPmtWarning,HasCheckList,CheckListCategoryID,ShowAvlBal,AutoPrintPassBook,TranCommissionGroupID,UseSimpleChargeControl,GLCategoryID,DaysAllowedForReversal,TranLimitID,ChequeType,CashFollowAcctCurr,useFX,CheckDrawerTypeRestrictions,use_XPath_app,SameRIMForCharge,SameCurrencyForCharge,PrimaryIDExpiryVal,PrimaryIDExpiryAction,Channel_Id,RecoveryReversal,Pack_ID,CustomerInquiry,TransOptPickListID,ReviewVouchersBeforePrinting,Charge_AcctCategoryID,UpdDateReqired,UpdDateValue,UpdDateAction,IsFinancialTran,ShortDescription,TranOptionFLD,CHK_IncludeAccumilative,CHK_AccumilativeInfoMessage,OpenSessionRequired,SupportResend,CheckBillPastDueDT,PastDueDTAction,UseExpressions,WorkOnNightlyModeAllowed,CheqTypeConfig,StaffsRelativeValidation,UseTCR,PostTranAsSupervisor,CancelTranAsSupervisor)
 Values (866,0,0,NULL,NULL,NULL,NULL,NULL,0.00,1,0,0,1,N'ITSOFT\ahmed.orashed',NULL,0,0,0,0,0,0,0,'Warning',0,1,1,'Warning',0,'',0,0,0,0,0,0,NULL,0,NULL,0,NULL,NULL,0,0,0,0,0,0,0,N'Warning',NULL,0,NULL,0,NULL,0,NULL,0,0,'0',0,'',NULL,0,0,1,0,0,'Warning',0,0,N'N',NULL,0,0,0)
End
GO

----------------
-- Menu_Action -
----------------
If Not Exists(Select * From Menu_Action Where MenuActionID = 888)
Begin
 Insert Into Menu_Action(MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Image,Enabled,RowStatus,Updator,Creator)
 Values (888,1,1105933,'OPS...',1,'OPS',NULL,1,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Menu_Action Where MenuActionID = 889)
Begin
 Insert Into Menu_Action(MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Image,Enabled,RowStatus,Updator,Creator)
 Values (889,1,1105932,'Display OPS WorkFlow',2,'DisplayOPSWorkFlow',NULL,1,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

--------------------
-- Menu_Definition -
--------------------
If Not Exists(Select * From Menu_Definition Where MenuID = 2502 And MenuKey = '8')
Begin
 Insert Into Menu_Definition(MenuID,MenuKey,MenuActionID,RowStatus,Updator,Creator)
 Values (2502,'8',888,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Menu_Definition Where MenuID = 2502 And MenuKey = '81')
Begin
 Insert Into Menu_Definition(MenuID,MenuKey,Parent,MenuActionID,RowStatus,Updator,Creator)
 Values (2502,'81','8',889,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

-------------------------
-- RulesTranDescriptors -
-------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'SEARCH_CRITERIA')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'SEARCH_CRITERIA',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BusinessDateFrom')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BusinessDateFrom',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BusinessDateTo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BusinessDateTo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'COR_TRANSACTIONS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'COR_TRANSACTIONS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_STATUS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_STATUS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_REQUEST_ID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_REQUEST_ID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_REQUEST_ID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_REQUEST_ID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_Submitter')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_Submitter',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'REGION')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'REGION',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'BRANCH_LABEL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'BRANCH_LABEL',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_RIM_NUMBER')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_RIM_NUMBER',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_AMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_AMOUNT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_CURRENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_CURRENCY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_SEARCH')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_SEARCH',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_OPS_WorkFlowTrans')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_OPS_WorkFlowTrans',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_SO_PRINT_VIEW')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_SO_PRINT_VIEW',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_POST')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_POST',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_REJECT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_REJECT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_TRAN_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_TRAN_NAME',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'BANK')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'BANK',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_JNLSequence')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_JNLSequence',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BUSINESSDATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BUSINESSDATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_TRANSACTION_TIME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_TRANSACTION_TIME',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BranchUser')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BranchUser',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BranchSupervisor')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BranchSupervisor',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_TID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_TID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_IR_LastChanged')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_IR_LastChanged',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_ACCOUNTNUMBER')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_ACCOUNTNUMBER',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_OPSUser')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_OPSUser',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_OPSSupervisor')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_OPSSupervisor',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_RejectionReason')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_RejectionReason',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_IsLocked')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_IsLocked',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_LOCKED_BY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_LOCKED_BY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_REJECT_REASON')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_REJECT_REASON',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'COR_REASON')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'COR_REASON',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

----------------------
-- RulesTranField_ex -
----------------------
DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'RequestID'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','200','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'TranName'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'TransactionDescription'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','200','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Bank'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Region'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Branch'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'JNLSequence'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'BusinessDate'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'TransactionTime'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Branch_User'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Branch_Supervisor'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'TID'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Status'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'StatusDescription'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'LastChanged'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'RimNo'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'AccountNumber'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Amount'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Currency'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'OPS_User'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'OPS_Supervisor'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'RejectionReason'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'IsLocked'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'LockedBy'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = 'tab_OPSWF')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','tab_OPSWF',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = '_lbl_OPSWFRequests')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','_lbl_OPSWFRequests',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = '_grd_OPSWF_Transactions')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','_grd_OPSWF_Transactions',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = '_btn_RefreshOPSWF')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','_btn_RefreshOPSWF',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = 'grp_OPSWF_PieChart')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','grp_OPSWF_PieChart',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

---------------
-- SQLstrings -
---------------
If Not Exists(Select * From SQLstrings Where AccessID = 1100109)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100109,'GetOPSWorkFlowTrans','p',1,'Globalfs','dbo.GetOPSWorkFlowTrans',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select all transaction from table OPSWorkFlow based on specify criteria',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100110)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100110,'GetTranNameDescriptor','p',1,'Globalfs','dbo.GetTranNameDescriptor',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select transaction name descriptor value',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100114)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100114,'GetOPS_TranFieldEX','p',1,'Globalfs','dbo.GetOPS_TranFieldEX',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select all data from table OPS_TranField_ex based on tran name',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100116)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100116,'RejectOPSRequest','p',0,'Globalfs','dbo.RejectOPSRequest',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Reject an OPS request based on request id',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100118)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100118,'InsertAndUpdateIntoOPSWorkFlow','p',1,'Globalfs','dbo.InsertAndUpdateIntoOPSWorkFlow',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Insert And Update Into OPSWorkFlow',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100119)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100119,'SelectOPSStatus','p',1,'Globalfs','dbo.SelectOPSStatus',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select OPS Request status based on request id',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100120)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100120,'GetAllOPSRequestsPerUser','p',1,'Globalfs','dbo.GetAllOPSRequestsPerUser',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select all pending transaction, and all today rejected and posted transaction for specific user',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

---------------------
-- OPS_TranField_ex -
---------------------
If Not Exists(Select * From OPS_TranField_ex Where TranID = 277 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (277,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 277 AND FieldIDInPage = 'C_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (277,'C_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 296 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (296,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 296 AND FieldIDInPage = 'C_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (296,'C_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 185 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (185,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 281 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (281,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 257 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (257,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 257 AND FieldIDInPage = '_btnTLR_SO_OK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (257,'_btnTLR_SO_OK',0)
End
GO
-------------------------
-- ResendControlsEvents -
-------------------------
If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstAccount' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstAccount',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstAccount' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstAccount',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstGL' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstGL',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstGL' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstGL',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstAccount' AND EventName = '_curAmount_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstAccount',N'_curAmount',N'_curAmount_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstAccount' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstAccount',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstAccount' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstAccount',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstGL' AND EventName = '_curAmount_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstGL',N'_curAmount',N'_curAmount_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstGL' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstGL',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstGL' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstGL',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'AddNewSO' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('AddNewSO',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'AddNewSO' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('AddNewSO',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

--PRINT 'End... Script for CR# GFSY00865 DML Script'
--GO
--==================================================================================================================================================================

-- =============================================
-- Author:		Ibrahim Harby 
-- Create date: 04-July-2021
-- Description:	 CR# GFSY00865

--------------------------------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal && RulesTranDescriptors -
--------------------------------------------------------------------

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105961)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105961,'TLR_OPS_DATA_LOADED',0,'Labels','There are already data loaded ,do you want to discard and reload again ?','ITSOFT\ibrahim.harby',1,N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105961 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105961,1025,N'تم تحميل بيانات بالفعل ، هل تريد تجاهلها وإعادة التحميل مرة أخرى؟','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 889)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,889,'TLR_GL_NUMBER',0,'Labels','GL Number','ITSOFT\ibrahim.harby',1,N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 889 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (889,1025,N'رقم حساب أ.ع','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1738)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1738,'TLR_DP_GL',0,'Labels','DP/GL','ITSOFT\ibrahim.harby',1,N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1738 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1738,1025,N'حساب/أ.ع','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 4750)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,4750,'CAPTION_MESSAGE',1,'Labels','Message','ITSOFT\ibrahim.harby',1,N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 4750 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (4750,1025,N'رسالة','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105939 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105939,1025,N'مستخدم الفرع','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105940 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105940,1025,N'مشرف الفرع','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105963 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105963,1025,N'طلبات OPS WF','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105942 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105942,1025,N'مستخدم OPS','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105943 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105943,1025,N'مشرف OPS','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105944 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105944,1025,N'مغلق','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105934 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105934,1025,N'التاريخ العمل من','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105935 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105935,1025,N'التاريخ العمل إلى','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105641 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105641,1025,N'رقم الطلب','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105936 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105936,1025,N'المرسل','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105946 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105946,1025,N'الرجاء تحديد سجل قبل النقر فوق عرض','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105947 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105947,1025,N'الرجاء تحديد سجل قبل النقر فوق نشر','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105955 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105955,1025,N'هل أنت متأكد أنك تريد نشر هذه العملية؟','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105948 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105948,1025,N'الرجاء تحديد سجل قبل النقر فوق رفض','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105960 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105960,1025,N'لا يمكن رفض هذه المعاملة حيث تم التعامل مع طلب OPS هذا بواسطة صراف آخر','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105956 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105956,1025,N'هل أنت متأكد أنك تريد رفض هذه العملية؟','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105950 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105950,1025,N'هذا الطلب مغلق','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105951 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105951,1025,N'لا يمكن تحديد حالة الطلب المحدد','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105957 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105957,1025,N'عكس','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_GL_NUMBER')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_GL_NUMBER','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_DP_GL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_DP_GL','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby',1)
End
GO
--***************************************************************************************
--***************************************************************************************
--------------------------------------------------------------------------------------
-- RulesErrorDescription && RulesLocalErrorDescription && RulesTranErrorDescriptions-
--------------------------------------------------------------------------------------

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1811)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID)
 Values (1811,'OPS_NOTALLOWED_CHARGE_CASH','Cash charge is not allowed with OPS Workflow','Cash charge is not allowed with OPS Workflow',4,'ErrDesc.hlp',1)
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1811 And LanguageLCID = 1025)
BEGIN
 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
 Values (1811,1025,N'الرسوم النقدية غير مسموح بها مع سير عمل OPS',N'الرسوم النقدية غير مسموح بها مع سير عمل OPS')
END
GO

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = -179999)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help)
 Values (-179999,'IB_INVALIDDATES','The FROM Date must be on or before the TO Date.  Please update and resubmit.','The FROM Date must be on or before the TO Date.  Please update and resubmit.',4,'ErrDesc.hlp')
End
go

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstAccount' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueTTAgainstAccount'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstGL' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueTTAgainstGL'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstGL' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueCOAgainstGL'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstGL' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueCOAgainstAccount'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstGL' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'AddNewSO'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

--***************************************************************************************
--***************************************************************************************
---------------------------------------------
-- RulesExpression & RulesExpressionDetail --
---------------------------------------------
DECLARE @ExpressionId int
SELECT @ExpressionId = MAX(ExpressionId) +1 from RulesExpression
IF NOT EXISTS(SELECT * FROM RulesExpression WHERE ExpressionName = 'OPSReferenceNumber')
BEGIN
 INSERT INTO RulesExpression(ExpressionId,ExpressionName,SerialNumberLength,PaddingCharacter,IsLeftPadded,ExpressionCategroyId)
 VALUES (@ExpressionId,'OPSReferenceNumber',7,'0',1,1)

 DECLARE @Id int
 SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 1)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,1,1,'Branch',1,3,'0',1)
 END

 SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 2)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,2,1,'"_OPS"',1,4,'0',1)
 END

  SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 3)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,3,1,'BusinessDate_YYYYMMDD',1,8,'0',1)
 END

  SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 4)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,4,1,'"_"',1,1,'0',1)
 END

END
GO

--***************************************************************************************
--***************************************************************************************
---------------
-- SQLstrings -
---------------

If Not Exists(Select * From SQLstrings Where AccessID = 1100112)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100112,'GetOPSWorkFlowTrans_Picklists','p',1,'Globalfs','dbo.GetOPSWorkFlowTrans_Picklists',0,'','','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby','Select all picklists from table OPSWorkFlow based on specify criteria',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100113)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100113,'List_OPS_Transactions','p',1,'Globalfs','dbo.List_OPS_Transactions',0,'','','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby','Select all data from table OPSWorkFlow based on specify criteria',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100117)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100117,'UPDATE_LOCKED_OPS_TRANSACTIONS','p',0,'Globalfs','dbo.UpdateLockedOPSTransaction',0,'','','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby','Update locked flag in OPSWorkFlow table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

--***************************************************************************************
--***************************************************************************************
-----------------------
-- SQL_RowSet_Columns -
-----------------------

IF Not Exists (SELECT* FROM SQL_RowSet_Columns WHERE AccessID = 1100112 ) 
	BEGIN
		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'Region', 0, 'VarChar')


		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'Branch', 1, 'VarChar')


		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'Currency', 2, 'VarChar')

		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'TranName', 3, 'VarChar')

		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'Status', 4, 'VarChar')

		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'BranchUser_Name', 5, 'VarChar')

	END

--***************************************************************************************
--***************************************************************************************
-----------------------------------
-- RulesParam & RulesTranFldParam -
-----------------------------------

If Not Exists(Select * From RulesParam Where ParamName='USE_OPS_WF')
BEGIN
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'USE_OPS_WF','specify To use OPS Workfolw if true','',0,1,0,'','Static','')
End


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstAccount' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstAccount' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstGL' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstGL' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstGL' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstGL' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstAccount' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstAccount' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'AddNewSO' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'AddNewSO' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


If Not Exists(Select * From RulesParam Where ParamName='CO_Branch_Limit')
Begin
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'CO_Branch_Limit','specify the Max CO Branch Limit Amount','',0,1,0,'','Static','')
End


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstGL' AND FieldName = 'CO_Branch_Limit' AND Param = 'CO_Branch_Limit' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstGL' , 'CO_Branch_Limit' , 'CO_Branch_Limit' , 0,'ITSOFT\ibrahim.harby' , 'decimal')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstAccount' AND FieldName = 'CO_Branch_Limit' AND Param = 'CO_Branch_Limit' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstAccount' , 'CO_Branch_Limit' , 'CO_Branch_Limit' , 0 ,'ITSOFT\ibrahim.harby' , 'decimal')
END
GO

DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'OPSExpressionName')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'OPSExpressionName','Used for generating reference number for OPSWorkFlow',NULL,0,1,0,'','Static','',N'ITSOFT\ibrahim.harby',1)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueCOAgainstAccount' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueCOAgainstAccount','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueCOAgainstGL' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueCOAgainstGL','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueTTAgainstGL' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueTTAgainstGL','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueTTAgainstAccount' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueTTAgainstAccount','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'AddNewSO' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('AddNewSO','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


--***************************************************************************************
--***************************************************************************************
---------------------
-- RulesTranField_ex  
---------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_grb_SearchCriteria')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_grb_SearchCriteria',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_BusinessDateTo')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_BusinessDateTo',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_dt_BusinessDateTo')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_dt_BusinessDateTo',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_BusinessDateFrom')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_BusinessDateFrom',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_dt_BusinessDateFrom')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_dt_BusinessDateFrom',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_btn_Search')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_btn_Search',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Transactions')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Transactions',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Transactions')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Transactions',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Status')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Status',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Status')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Status',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Submitter')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Submitter',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Submitter')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Submitter',-1,-1,-1,1,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Region')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Region',-1,-1,-1,1,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Region')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Region',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_RequestID')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_RequestID',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_txt_RimNumber')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_txt_RimNumber',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_txt_RequestID')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_txt_RequestID',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_RimNumber')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_RimNumber',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Currency')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Currency',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Currency')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Currency',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Amount')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Amount',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_AccountLookup_Debit')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_AccountLookup_Debit',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cur_Amount')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cur_Amount',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Branch')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Branch',-1,-1,-1,1,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Branch')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Branch',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_grb_WorkFlowTransactions')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_grb_WorkFlowTransactions',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_btn_Reject')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_btn_Reject',-1,-1,-1,0,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_grd_WorkFlowTransactions')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_grd_WorkFlowTransactions',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_btn_View')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_btn_View',-1,-1,-1,0,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Debit_GL_DP')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Debit_GL_DP',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Debit_DP_GL')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Debit_DP_GL',-1,-1,-1,0,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_GLNo')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_GLNo',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_gl_GLNumber')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_gl_GLNumber',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_btn_Post')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_btn_Post',-1,-1,-1,0,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO
--***************************************************************************************
--***************************************************************************************

PRINT 'End... Script for CR# GFSY00865 DML Script'
GO


----------------------------------------------------- RulesParam ---------------------------------------------------------------------------
declare @paramid int
select @paramid=MAX(paramid)+1 from RulesParam
 If Not Exists(Select * From RulesParam Where ParamName = 'DeductChargesFromChequeFCY')
Begin
 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
 Values (@paramid,'DeductChargesFromChequeFCY','get if charges will be Discounted from cheque',NULL,0,0,0,'','Static    ','','Aug  28 2021 8:22AM',N'ITSOFT\shaimaa.nasser','Aug  28 1900 12:00AM','Dec 31 9999 12:00AM',1)
End
go
----------------------------------------------------- RulesTranFldParam ---------------------------------------------------------------------------
 --**** CashWithdrawal ***--
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CashWithdrawal' And Param = 'DeductChargesFromChequeFCY')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
 Values ('CashWithdrawal','NetCashAmount','DeductChargesFromChequeFCY','0',N'ITSOFT\shaimaa.nasser','nvarchar','Aug  28 2021 8:22AM','get if charges will be Discounted from cheque')
End
go


--Devolper	 :	Aya Tarek 
--Date       :	[22/8/2021]		
--Reason     :	CR#GFSY00869 [Swift Modification Part2_Retrofit]
------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
--------------------------RulesDescriptor & RulesDesceiptorLocal-------------------------------------------------------
------------------------------------------------------------------------------------------------
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105945 and Name = 'TLR_Attach_MT199' )
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105945,'TLR_Attach_MT199',0,'Labels','Attach Mt199','ITSoft\aya.tarek','April 14 2021 10:19AM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 14 2021 10:19AM',N'ITSOFT\aya.tarek')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105945 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,LastChanged)
 Values (1105945,1025,N'إرفاق MT199 ','Mar 10 2021 10:19AM')
End
go

------------------------------------------------------------------------------------------------
--------------------------RulesTranDescriptors-------------------------------------------------------
---------------------------------------------------------------------------------------------
--Attach MT199
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 266 AND  Dsc_name =  'TLR_Attach_MT199'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 266   ,'TLR_Attach_MT199' ,'ITSOFT\aya.tarek'  ) 
END
Go
--InwardTransfersHOSwiftProcess
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 862 AND  Dsc_name =  'TLR_Attach_MT199'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 862   ,'TLR_Attach_MT199' ,'ITSOFT\aya.tarek'  ) 
END
Go


IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where TranID = 862 AND  Dsc_name =  'TLR_IR_OldDrAccountNo_AcctType'  )
BEGIN
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , Dsc_name , creator) 
  Values( 862   ,'TLR_IR_OldDrAccountNo_AcctType' ,'ITSOFT\aya.tarek'  ) 
END
Go


--------------------------RulesParam-------------------------------------------------------
---------------------------------------------------------------------------------------------
If Not Exists(Select * From RulesParam Where ParamName='GenerateMT199')
Begin
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'GenerateMT199','to specify generating MT199 after posting the transaction or not ','',0,1,0,'','Static','')
End

------------------------------------RulesTranFldParam----------------------------------------
-----------------------------------------------------------------------------------------------
--Inward Remittance HO Swift
IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'InwardRemittanceHOSwift' AND FieldName = 'GenerateMT199' AND Param = 'GenerateMT199' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'InwardRemittanceHOSwift' , 'GenerateMT199' , 'GenerateMT199' , '0' ,'ITSOFT\aya.tarek' , 'bit')
END
GO

--IRservice
IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'InwardRemittanceHOSwiftService' AND FieldName = 'GenerateMT199' AND Param = 'GenerateMT199' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'InwardRemittanceHOSwiftService' , 'GenerateMT199' , 'GenerateMT199' , '0' ,'ITSOFT\aya.tarek' , 'bit')
END
GO

--InwardTransfersHOSwiftProcess
IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'InwardTransfersHOSwiftProcess' AND FieldName = 'GenerateMT199' AND Param = 'GenerateMT199' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'InwardTransfersHOSwiftProcess' , 'GenerateMT199' , 'GenerateMT199' , '0' ,'ITSOFT\aya.tarek' , 'bit')
END
GO

--------------------------------------------------------------------------------------------------------
----- HostCoreService && HostCoreServiceFields
----------------------------------------------
--Fld79Ln1
IF Exists(Select * From HostCoreService Where ServiceName = 'CreateSwift')
	BEGIN
		DECLARE @serviceID int , @fieldId int
		SELECT @serviceID = ServiceId from HostCoreService WHERE ServiceName = 'CreateSwift'
		SELECT @fieldId = max(FieldId) + 1  from HostCoreServiceFields  WHERE ServiceId = @serviceID
		BEGIN
			If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @serviceID And FieldName = 'psFld79Ln1')
				BEGIN
					Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
					Values (@serviceID,@fieldId,'psFld79Ln1','varchar',0,0,'','I','ITSOFT\aya.tarek',N'ITSOFT\aya.tarek')
				END
		END
	END

GO

--Fld79Ln2
IF Exists(Select * From HostCoreService Where ServiceName = 'CreateSwift')
	BEGIN
		DECLARE @serviceID int , @fieldId int
		SELECT @serviceID = ServiceId from HostCoreService WHERE ServiceName = 'CreateSwift'
		SELECT @fieldId = max(FieldId) + 1  from HostCoreServiceFields  WHERE ServiceId = @serviceID
		BEGIN
			If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @serviceID And FieldName = 'psFld79Ln2')
				BEGIN
					Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
					Values (@serviceID,@fieldId,'psFld79Ln2','varchar',0,0,'','I','ITSOFT\aya.tarek',N'ITSOFT\aya.tarek')
				END
		END
	END

GO

--Fld79Ln3
IF Exists(Select * From HostCoreService Where ServiceName = 'CreateSwift')
	BEGIN
		DECLARE @serviceID int , @fieldId int
		SELECT @serviceID = ServiceId from HostCoreService WHERE ServiceName = 'CreateSwift'
		SELECT @fieldId = max(FieldId) + 1  from HostCoreServiceFields  WHERE ServiceId = @serviceID
		BEGIN
			If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @serviceID And FieldName = 'psFld79Ln3')
				BEGIN
					Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
					Values (@serviceID,@fieldId,'psFld79Ln3','varchar',0,0,'','I','ITSOFT\aya.tarek',N'ITSOFT\aya.tarek')
				END
		END
	END

GO

--Fld79Ln4
IF Exists(Select * From HostCoreService Where ServiceName = 'CreateSwift')
	BEGIN
		DECLARE @serviceID int , @fieldId int
		SELECT @serviceID = ServiceId from HostCoreService WHERE ServiceName = 'CreateSwift'
		SELECT @fieldId = max(FieldId) + 1  from HostCoreServiceFields  WHERE ServiceId = @serviceID
		BEGIN
			If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @serviceID And FieldName = 'psFld79Ln4')
				BEGIN
					Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
					Values (@serviceID,@fieldId,'psFld79Ln4','varchar',0,0,'','I','ITSOFT\aya.tarek',N'ITSOFT\aya.tarek')
				END
		END
	END

GO
--------------------------------------------------SQLstrings----------------------------------------------------------------------


IF Not Exists(select * from SQLstrings where AccessID = 1100121)
BEGIN
	INSERT INTO SQLstrings (AppID , AccessID , AccessName , CommandType , GetsRows , DataSource , AccessString , OutputsXML , OBSOLETE_XSLFile , OBSOLETE_XDRFile , Developer , Updator , Purpose , RScmdType , RScmd , ReadOnly , CacheMinutes , UseNewCacheRules , CacheGroup , CacheByUser , SkipTest , ExpirationDays , is_development_only , CommandTimeout )  
	Values( 1 , 1100121 , 'TLR_UpdateSwiftMessageInIR' , 'p' , 0, 'Globalfs' , 'dbo.UpdateSwiftMessageInIR' , 0 , '' , '' , 'ITSOFT\aya.tarek' , 'ITSOFT\aya.tarek' , 'Update MT103,MT202,MT199 In IR Table' , '' , '' , 0 , -1 , 1 , NULL , Null , 0 , 0 , 0 , 0)
END 
GO

-------------------------------------RulesTRanField-----------------------------
--------------------------------------------------------------------------------
--Attach MT199   TLR_SWIFT_REQUIRED
--Inward Remittance HO Swift
If Not Exists(select * From RulesTranField Where TranID = 266 And FieldID = 385 )
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional)
 Values (266,385,1)
End
go



-----------------------------RulesTranField_ex-----------
--------------------------------------------------------------
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=266 AND FieldIDInPage='_chk_MT199')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 266 , NULL , 'Teller' , '_chk_MT199' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=266 AND FieldIDInPage='_lbl_MT199')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 266 , NULL , 'Teller' , '_lbl_MT199' , -1 , -1 , -1 , 1 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO

--new column in Gridview
IF NOT EXISTS(select * FROM RulesTranField_ex WHERE TranID=862 AND FieldIDInPage='_grd_Messages_Column_Attach_MT199')
BEGIN
	INSERT INTO RulesTranField_ex (TranID , FieldID , Module , FieldIDInPage , FirstPage , LastPage , ControlPage , Optional , IsReadOnly , TranFieldDescr , DefaultValue , FieldType , Updator , IsVisible)
	values( 862 , NULL , 'Teller' , '_grd_Messages_Column_Attach_MT199' , -1 , -1 , -1 , 0 , 0 , '' , '' , '' , 'ITSOFT\aya.tarek' , 1)
END
GO



--==================================================================================================================================================================
--Devolper	:	Ibrahim Harby
--Date		:	{21/09/2021}
--Reason	:	GFSX14743
--=============================================================
PRINT 'Start. Script for CR# GFSX14743  DML Script'
GO

DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'RoleName')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'RoleName','Operation Role Name',NULL,0,1,0,'','Static','',N'ITSOFT\ibrahim.harby',1)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueCOAgainstAccount' AND FieldName = 'RoleName' AND Param = 'RoleName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueCOAgainstAccount','RoleName','RoleName','',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueCOAgainstGL' AND FieldName = 'RoleName' AND Param = 'RoleName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueCOAgainstGL','RoleName','RoleName','',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueTTAgainstGL' AND FieldName = 'RoleName' AND Param = 'RoleName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueTTAgainstGL','RoleName','RoleName','',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueTTAgainstAccount' AND FieldName = 'RoleName' AND Param = 'RoleName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueTTAgainstAccount','RoleName','RoleName','',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'AddNewSO' AND FieldName = 'RoleName' AND Param = 'RoleName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('AddNewSO','RoleName','RoleName','',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO

PRINT 'End... Script for CR# GFSX14743 DML Script'
GO

IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='AccountRimNumber')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'AccountRimNumber',N'int',999,0,N'0',N'O')
END
GO
IF NOT EXISTS(SELECT * FROM HostCoreServiceFields WHERE ServiceId=(SELECT HostCoreService.ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile') AND FieldName='AccountRimClassCode')
BEGIN
	DECLARE @serviceID INT
	SELECT @serviceID = ServiceId FROM HostCoreService WHERE ServiceName='CustomerProfile'
	DECLARE @fieldID INT
	SET @fieldID = (select max(FieldID) from HostCoreServiceFields WHERE ServiceId = @serviceID) +1
	IF(@fieldID IS NULL) SET @fieldID = 1
	INSERT INTO HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction)
	Values(@serviceID,@fieldID,N'AccountRimClassCode',N'int',999,0,N'0',N'O')
END
GO

--=====================================================================
--Devolper	:	Ahmed Atef
--Date		:	[04/10/2021]
--Reason	:	Enh GFSY00881 - BARWA - ACM19130 - OPS Workflow Part 2
--=====================================================================

-----------------------------------
-- RulesParam & RulesTranFldParam -
-----------------------------------
IF EXISTS(Select * From dbo.RulesTranFldParam Where FieldName = 'CO_Branch_Limit' AND Param = 'CO_Branch_Limit')
BEGIN
Delete From RulesTranFldParam Where FieldName = 'CO_Branch_Limit' AND Param = 'CO_Branch_Limit'
END
GO

IF EXISTS(Select * From RulesParam Where ParamName='CO_Branch_Limit')
BEGIN
Delete From RulesParam where ParamName='CO_Branch_Limit'
END
GO

IF NOT EXISTS(Select * From RulesParam Where ParamName='OPS_Limit')
BEGIN
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'OPS_Limit','Specify the Max OPS Limit Amount','',0,1,0,'','Static','')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstGL' AND FieldName = 'OPS_Limit' AND Param = 'OPS_Limit' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstGL' , 'OPS_Limit' , 'OPS_Limit' , 100,'ITSOFT\ahmed.atef' , 'decimal')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstAccount' AND FieldName = 'OPS_Limit' AND Param = 'OPS_Limit' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstAccount' , 'OPS_Limit' , 'OPS_Limit' , 10 ,'ITSOFT\ahmed.atef' , 'decimal')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstGL' AND FieldName = 'OPS_Limit' AND Param = 'OPS_Limit' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstGL' , 'OPS_Limit' , 'OPS_Limit' , 100,'ITSOFT\ahmed.atef' , 'decimal')
END
GO

IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstAccount' AND FieldName = 'OPS_Limit' AND Param = 'OPS_Limit' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstAccount' , 'OPS_Limit' , 'OPS_Limit' , 10 ,'ITSOFT\ahmed.atef' , 'decimal')
END
GO

--------------------------------
-- Alter Table RulesTranConfig -
--------------------------------

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'RulesTranConfig' AND COLUMN_NAME = 'GrantRequest')
	BEGIN
		ALTER TABLE RulesTranConfig
		ADD GrantRequest bit DEFAULT 1 WITH VALUES
	END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'RulesTranConfig' AND COLUMN_NAME = 'DenyRequest')
	BEGIN
		ALTER TABLE RulesTranConfig
		ADD DenyRequest bit DEFAULT 1 WITH VALUES
	END
GO
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105743 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105743,1025,N'سعر الصرف الحقيقي','ITSOFT\shaimaa.nasser',N'ITSOFT\shaimaa.nasser')
End
ELSE 
UPDATE RulesDescriptorLocal set LocalDescription = N'سعر الصرف الحقيقي' where DescriptorID = 1105743 And LCID = 1025
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105678 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105678,1025,N'عمليات النقل الداخلي سويفت للفرع الرئيسي','ITSOFT\shaimaa.nasser',N'ITSOFT\shaimaa.nasser')
End
ELSE 
UPDATE RulesDescriptorLocal set LocalDescription = N'عمليات النقل الداخلي سويفت للفرع الرئيسي' where DescriptorID = 1105678 And LCID = 1025
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================
PRINT 'Start. Script for CR# GFSY00865 DML Script'
GO

--------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal -
--------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105925)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105925,'TLR_OPS_PendingReview',0,'Labels','Pending Review','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105925 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105925,1025,N'في انتظار المراجعة','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105926)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105926,'TLR_OPS_PendingApproval',0,'Labels','Pending Approval','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105926 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105926,1025,N'ما زال يحتاج بتصدير','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105927)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105927,'TLR_OPS_Approved',0,'Labels','Approved','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105927 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105927,1025,N'وافق','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105928)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105928,'TLR_OPS_Repaired',0,'Labels','Repaired','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105928 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105928,1025,N'تم الاصلاح','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105929)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105929,'TLR_OPS_Posted',0,'Labels','Posted','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105929 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105929,1025,N'تم النشر','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105930)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105930,'TLR_OPS_Rejected',0,'Labels','Rejected','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105930 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105930,1025,N'مرفوض','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105931)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105931,'TLR_OPS_Returned',0,'Labels','Returned','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105931 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105931,1025,N'عاد','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105932)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105932,'TLR_OPS_DisplayOPSWorkFlow',0,'Labels','Display OPS WorkFlow','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105932 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105932,1025,N'عرض سير عمل OPS','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105933)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105933,'TLR_OPS',0,'Labels','OPS...','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 15391)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,15391,'SEARCH_CRITERIA',0,'Labels','Search Criteria','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105934)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105934,'TLR_BusinessDateFrom',0,'Labels','Business Date (From)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105935)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105935,'TLR_BusinessDateTo',0,'Labels','Business Date (To)','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1000026)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1000026,'COR_TRANSACTIONS',0,'Labels','Transactions','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 340)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,340,'TLR_STATUS',0,'Labels','Status','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105641)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105641,'TLR_REQUEST_ID',0,'Labels','Request ID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105641)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105641,'TLR_REQUEST_ID',0,'Labels','Request ID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105936)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105936,'TLR_Submitter',0,'Labels','Submitter','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -269869)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-269869,'REGION',0,'Labels','Region','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -269868)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-269868,'BRANCH_LABEL',0,'Labels','Branch','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105289)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105289,'TLR_RIM_NUMBER',0,'Labels','Rim Number','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10042)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-10042,'TLR_CURRENCY',0,'Labels','Currency','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10190)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-10190,'TLR_SEARCH',0,'Labels','Search','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105937)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105937,'TLR_OPS_WorkFlowTrans',0,'Labels','WorkFlow Transactions','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105937 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105937,1025,N'معاملات تدفق العمل','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1439)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1439,'TLR_SO_PRINT_VIEW',0,'Labels','View','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1138)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1138,'TLR_POST',0,'Labels','Post','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1101035)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1101035,'TLR_REJECT',0,'Labels','Reject','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10043)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-10043,'TLR_AMOUNT',0,'Labels','Amount','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 2746)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,2746,'TLR_TRAN_NAME',0,'Labels','Transaction Name','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -269870)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-269870,'BANK',0,'Labels','Bank','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105938)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105938,'TLR_JNLSequence',0,'Labels','JNL Sequence','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -19820)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-19820,'TLR_BUSINESSDATE',0,'Labels','Business Date','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1101018)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1101018,'TLR_TRANSACTION_TIME',0,'Labels','Transaction Time','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105939)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105939,'TLR_BranchUser',0,'Labels','Branch User','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105940)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105940,'TLR_BranchSupervisor',0,'Labels','Branch Supervisor','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105941)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105941,'TLR_TID',0,'Labels','TID','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1650)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1650,'TLR_IR_LastChanged',0,'Labels','Last Changed','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = -10019)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,-10019,'TLR_ACCOUNTNUMBER',0,'Labels','Account Number','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105942)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105942,'TLR_OPSUser',0,'Labels','OPS User','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105943)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105943,'TLR_OPSSupervisor',0,'Labels','OPS Supervisor','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1104601)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1104601,'TLR_RejectionReason',0,'Labels','Rejection Reason','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105944)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105944,'TLR_IsLocked',0,'Labels','Is Locked','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1101061)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1101061,'TLR_LOCKED_BY',0,'Labels','Locked By','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105946)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105946,'TLR_OPS_SELECTRECOREDTOVIEW',0,'Labels','Please select a record before click view','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105947)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105947,'TLR_OPS_SELECTRECOREDTOPOST',0,'Labels','Please select a record before click post','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105948)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105948,'TLR_OPS_SELECTRECOREDTOREJECT',0,'Labels','Please select a record before click reject','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105949)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105949,'TLR_OPS_SELECTRECOREDTORETURN',0,'Labels','Please select a record before click return to branch','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105950)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105950,'TLR_OPS_REQUESTISLOCKED',0,'Labels','This request is locked','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105951)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105951,'TLR_OPS_CANNOTDEFINEREQSTATUS',0,'Labels','Cannot define the selected request status','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105955)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105955,'TLR_OPS_POSTINGCONFIRMATION',0,'Labels','Are you sure you want to post this transaction?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105956)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105956,'TLR_OPS_REJECTCONFIRMATION',0,'Labels','Are you sure you want to reject this transaction?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105958)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105958,'TLR_OPS_REJECTFAILED',0,'Labels','Failed to reject the selected request','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105957)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105957,'TLR_OPS_Reversed',0,'Labels','Reversed','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105959)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105959,'TLR_OPS_CANNOTREJECT_REVERSED',0,'Labels','Cannot reject this transaction as this OPS request was reversed by branch team','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105960)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105960,'TLR_OPS_CANNOTREJECT_POSTED',0,'Labels','Cannot reject this transaction as this OPS request was handled by another teller','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105962)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105962,'TLR_OPSWF',0,'Labels','OPS WF','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105963)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105963,'TLR_OPSWF_Requests',0,'Labels','OPS WF Requests','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
End
GO

---------------
-- StatusType -
---------------
If Not Exists(Select * From StatusType Where id = 77)
Begin
 Insert Into StatusType(id,Description,Updator,Creator)
 Values (77,'OPSWorkFlow',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

-----------------
-- StatusTypeID -
-----------------
If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 1)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,1,'PendingReview','PendingReview','TLR_OPS_PendingReview',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 2)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,2,'PendingApproval','PendingApproval','TLR_OPS_PendingApproval',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 3)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,3,'Approved','Approved','TLR_OPS_Approved',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 4)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,4,'Repaired','Repaired','TLR_OPS_Repaired',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 5)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,5,'Posted','Posted','TLR_OPS_Posted',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 6)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,6,'Rejected','Rejected','TLR_OPS_Rejected',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 7)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,7,'Returned','Returned','TLR_OPS_Returned',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Status Where StatusTypeID = 77 And id = 8)
Begin
 Insert Into Status(StatusTypeID,id,ShortDescription,LongDescription,DSC_Name,Updator,Creator)
 Values (77,8,'Reversed','Reversed','TLR_OPS_Reversed',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

------------------
-- RulesTranName -
------------------
If Not Exists(Select * From RulesTranName Where TranID = 866)
Begin
 Insert Into RulesTranName(TransactionName,TranID,Description,Developer,DSC_Description,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,RowStatus,Updator,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,TotalsType,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
 Values ('DisplayOPSWorkFlow',866,'Display OPS WorkFlow',N'ITSOFT\ahmed.orashed',1105932,10,'Teller',101,1,'ROP',1,0,0,0,0,0,0,1,N'ITSOFT\ahmed.orashed',0,0,0,0,0,0,0,0,0,0,1,NULL,NULL,NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,1)
End
GO

------------------------
-- RulesContainerTrans -
------------------------
If Not Exists(Select * From RulesContainerTrans Where container_name = 'Teller' And TranName = 'DisplayOPSWorkFlow')
Begin
 Insert Into RulesContainerTrans(container_name,TranName,Updator,RowStatus)
 Values ('Teller','DisplayOPSWorkFlow',N'ITSOFT\ahmed.orashed',1)
End
GO

----------------------
-- TransactionScopes -
----------------------
If Not Exists(Select * From TransactionScopes Where Scope = 1001 And TranID = 866)
Begin
 Insert Into TransactionScopes(Scope,TranID,Developer,Updator,RowStatus)
 Values (1001,866,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

--------------
-- Component -
--------------
If Not Exists(Select * From Component Where ComponentID = 310)
Begin
 Insert Into Component(ComponentID,AppID,ComponentName,ComponentType,Description,ProjectDirectory,ProjectFile,ProjectType,ProjectTarget,ProductionGroup,isSourceShipped,TargetDirectory,TypeLibrary,TypeLibVersion,GUID,VersionInfoFile,FileVersion,ComponentSize,Developer,InstallDirectory,Updator,ProductionGroup2,InstallDirectory2,RowStatus,WiseProject,BuildChangesOnly,SymbolsFile,ProjectGUID)
 Values (310,1,N'DisplayOPSWorkFlow','DLL','',N'Teller.Net\Source\BP\Custom\DisplayOPSWorkFlow',N'DisplayOPSWorkFlow.csproj','C#2010',N'Debug','Client_NonRegistered',0,N'..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\',NULL,NULL,NULL,NULL,'2.0.46.0',57344,N'ITSOFT\ahmed.orashed',N'shared.net\Source\bin\Common\Teller',N'ITSOFT\ahmed.orashed',NULL,NULL,1,N'GFSTellerdotNetClient.wsm',1,N'DisplayOPSWorkFlow.pdb',NULL)
End
GO

--------------------
-- RulesTranConfig -
--------------------
If Not Exists(Select * From RulesTranConfig Where TranID = 866)
Begin
 Insert Into RulesTranConfig(TranID,DenomRequired,AccountingEntries,DrAccountCategoryID,CrAccountCategoryID,LimitCategoryID,FeesCategoryID,ExchangeType,OffLineAmount,AllowEmptyAccountingEntries,VerifySignatrue,ReadAllAccountingEntries,ShowInAdmin,Updator,OD_DrAccountCategoryID,PrintOption,ForcePositioning,EnableCharges,SalesMessageActive,FutureStaleChequeDays,BackDatedStaleChequeDays,ValidateStaleCheque,StaleChequeAction,StaleChequeDefaultDate,EscWarningEnabled,ChqRngVal,ChqRngAction,Blacklisted,BlacklistedAction,BenPmtStrict,BenPmtWarning,HasCheckList,CheckListCategoryID,ShowAvlBal,AutoPrintPassBook,TranCommissionGroupID,UseSimpleChargeControl,GLCategoryID,DaysAllowedForReversal,TranLimitID,ChequeType,CashFollowAcctCurr,useFX,CheckDrawerTypeRestrictions,use_XPath_app,SameRIMForCharge,SameCurrencyForCharge,PrimaryIDExpiryVal,PrimaryIDExpiryAction,Channel_Id,RecoveryReversal,Pack_ID,CustomerInquiry,TransOptPickListID,ReviewVouchersBeforePrinting,Charge_AcctCategoryID,UpdDateReqired,UpdDateValue,UpdDateAction,IsFinancialTran,ShortDescription,TranOptionFLD,CHK_IncludeAccumilative,CHK_AccumilativeInfoMessage,OpenSessionRequired,SupportResend,CheckBillPastDueDT,PastDueDTAction,UseExpressions,WorkOnNightlyModeAllowed,CheqTypeConfig,StaffsRelativeValidation,UseTCR,PostTranAsSupervisor,CancelTranAsSupervisor)
 Values (866,0,0,NULL,NULL,NULL,NULL,NULL,0.00,1,0,0,1,N'ITSOFT\ahmed.orashed',NULL,0,0,0,0,0,0,0,'Warning',0,1,1,'Warning',0,'',0,0,0,0,0,0,NULL,0,NULL,0,NULL,NULL,0,0,0,0,0,0,0,N'Warning',NULL,0,NULL,0,NULL,0,NULL,0,0,'0',0,'',NULL,0,0,1,0,0,'Warning',0,0,N'N',NULL,0,0,0)
End
GO

----------------
-- Menu_Action -
----------------
If Not Exists(Select * From Menu_Action Where MenuActionID = 888)
Begin
 Insert Into Menu_Action(MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Image,Enabled,RowStatus,Updator,Creator)
 Values (888,1,1105933,'OPS...',1,'OPS',NULL,1,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Menu_Action Where MenuActionID = 889)
Begin
 Insert Into Menu_Action(MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Image,Enabled,RowStatus,Updator,Creator)
 Values (889,1,1105932,'Display OPS WorkFlow',2,'DisplayOPSWorkFlow',NULL,1,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

--------------------
-- Menu_Definition -
--------------------
If Not Exists(Select * From Menu_Definition Where MenuID = 2502 And MenuKey = '8')
Begin
 Insert Into Menu_Definition(MenuID,MenuKey,MenuActionID,RowStatus,Updator,Creator)
 Values (2502,'8',888,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From Menu_Definition Where MenuID = 2502 And MenuKey = '81')
Begin
 Insert Into Menu_Definition(MenuID,MenuKey,Parent,MenuActionID,RowStatus,Updator,Creator)
 Values (2502,'81','8',889,1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

-------------------------
-- RulesTranDescriptors -
-------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'SEARCH_CRITERIA')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'SEARCH_CRITERIA',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BusinessDateFrom')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BusinessDateFrom',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BusinessDateTo')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BusinessDateTo',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'COR_TRANSACTIONS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'COR_TRANSACTIONS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_STATUS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_STATUS',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_REQUEST_ID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_REQUEST_ID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_REQUEST_ID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_REQUEST_ID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_Submitter')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_Submitter',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'REGION')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'REGION',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'BRANCH_LABEL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'BRANCH_LABEL',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_RIM_NUMBER')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_RIM_NUMBER',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_AMOUNT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_AMOUNT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_CURRENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_CURRENCY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_SEARCH')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_SEARCH',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_OPS_WorkFlowTrans')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_OPS_WorkFlowTrans',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_SO_PRINT_VIEW')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_SO_PRINT_VIEW',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_POST')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_POST',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_REJECT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_REJECT',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_TRAN_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_TRAN_NAME',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'BANK')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'BANK',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_JNLSequence')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_JNLSequence',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BUSINESSDATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BUSINESSDATE',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_TRANSACTION_TIME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_TRANSACTION_TIME',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BranchUser')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BranchUser',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_BranchSupervisor')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_BranchSupervisor',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_TID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_TID',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_IR_LastChanged')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_IR_LastChanged',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_ACCOUNTNUMBER')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_ACCOUNTNUMBER',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_OPSUser')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_OPSUser',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_OPSSupervisor')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_OPSSupervisor',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_RejectionReason')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_RejectionReason',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_IsLocked')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_IsLocked',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_LOCKED_BY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_LOCKED_BY',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_REJECT_REASON')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_REJECT_REASON',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'COR_REASON')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'COR_REASON',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

----------------------
-- RulesTranField_ex -
----------------------
DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'RequestID'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','200','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'TranName'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'TransactionDescription'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','200','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Bank'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Region'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Branch'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'JNLSequence'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'BusinessDate'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'TransactionTime'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Branch_User'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Branch_Supervisor'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'TID'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Status'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'StatusDescription'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'LastChanged'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'RimNo'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'AccountNumber'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Amount'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'Currency'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'OPS_User'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'OPS_Supervisor'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'RejectionReason'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'IsLocked'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

DECLARE @Name nvarchar(max) = '_grd_WorkFlowTransactions_Column_' + 'LockedBy'
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = @Name)
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,NULL,'Teller',@Name,-1,-1,-1,0,0,'','150','',N'ITSOFT\ahmed.orashed',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = 'tab_OPSWF')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','tab_OPSWF',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = '_lbl_OPSWFRequests')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','_lbl_OPSWFRequests',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = '_grd_OPSWF_Transactions')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','_grd_OPSWF_Transactions',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = '_btn_RefreshOPSWF')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','_btn_RefreshOPSWF',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 865 And FieldID Is Null And FieldIDInPage = 'grp_OPSWF_PieChart')
BEGIN
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (865,NULL,'Teller','grp_OPSWF_PieChart',-1,-1,-1,0,0,'','','',N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

---------------
-- SQLstrings -
---------------
If Not Exists(Select * From SQLstrings Where AccessID = 1100109)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100109,'GetOPSWorkFlowTrans','p',1,'Globalfs','dbo.GetOPSWorkFlowTrans',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select all transaction from table OPSWorkFlow based on specify criteria',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100110)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100110,'GetTranNameDescriptor','p',1,'Globalfs','dbo.GetTranNameDescriptor',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select transaction name descriptor value',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100114)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100114,'GetOPS_TranFieldEX','p',1,'Globalfs','dbo.GetOPS_TranFieldEX',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select all data from table OPS_TranField_ex based on tran name',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100116)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100116,'RejectOPSRequest','p',0,'Globalfs','dbo.RejectOPSRequest',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Reject an OPS request based on request id',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100118)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100118,'InsertAndUpdateIntoOPSWorkFlow','p',1,'Globalfs','dbo.InsertAndUpdateIntoOPSWorkFlow',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Insert And Update Into OPSWorkFlow',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100119)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100119,'SelectOPSStatus','p',1,'Globalfs','dbo.SelectOPSStatus',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select OPS Request status based on request id',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100120)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100120,'GetAllOPSRequestsPerUser','p',1,'Globalfs','dbo.GetAllOPSRequestsPerUser',0,'','','ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Select all pending transaction, and all today rejected and posted transaction for specific user',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

---------------------
-- OPS_TranField_ex -
---------------------
If Not Exists(Select * From OPS_TranField_ex Where TranID = 277 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (277,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 277 AND FieldIDInPage = 'C_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (277,'C_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 296 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (296,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 296 AND FieldIDInPage = 'C_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (296,'C_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 185 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (185,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 281 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (281,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 257 AND FieldIDInPage = '_btnOK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (257,'_btnOK',0)
End
GO

If Not Exists(Select * From OPS_TranField_ex Where TranID = 257 AND FieldIDInPage = '_btnTLR_SO_OK')
Begin
 Insert Into OPS_TranField_ex(TranID,FieldIDInPage,IsReadOnly)
 Values (257,'_btnTLR_SO_OK',0)
End
GO
-------------------------
-- ResendControlsEvents -
-------------------------
If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstAccount' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstAccount',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstAccount' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstAccount',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstGL' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstGL',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueTTAgainstGL' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueTTAgainstGL',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstAccount' AND EventName = '_curAmount_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstAccount',N'_curAmount',N'_curAmount_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstAccount' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstAccount',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstAccount' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstAccount',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstGL' AND EventName = '_curAmount_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstGL',N'_curAmount',N'_curAmount_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstGL' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstGL',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'IssueCOAgainstGL' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('IssueCOAgainstGL',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'AddNewSO' AND EventName = '_txtCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('AddNewSO',N'_chargeControl',N'_txtCharges_Validating',N'Event',NULL)
End
GO

If Not Exists(Select * From ResendControlsEvents Where TransactionName = 'AddNewSO' AND EventName = '_txtDebitCharges_Validating')
Begin
 Insert Into ResendControlsEvents(TransactionName,ControlName,EventName,EventType,ControlValue)
 Values ('AddNewSO',N'_chargeControl',N'_txtDebitCharges_Validating',N'Event',NULL)
End
GO

--PRINT 'End... Script for CR# GFSY00865 DML Script'
--GO
--==================================================================================================================================================================

-- =============================================
-- Author:		Ibrahim Harby 
-- Create date: 04-July-2021
-- Description:	 CR# GFSY00865

--------------------------------------------------------------------
-- RulesDescriptor && RulesDescriptorLocal && RulesTranDescriptors -
--------------------------------------------------------------------

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105961)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105961,'TLR_OPS_DATA_LOADED',0,'Labels','There are already data loaded ,do you want to discard and reload again ?','ITSOFT\ibrahim.harby',1,N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105961 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105961,1025,N'تم تحميل بيانات بالفعل ، هل تريد تجاهلها وإعادة التحميل مرة أخرى؟','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 889)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,889,'TLR_GL_NUMBER',0,'Labels','GL Number','ITSOFT\ibrahim.harby',1,N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 889 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (889,1025,N'رقم حساب أ.ع','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1738)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1738,'TLR_DP_GL',0,'Labels','DP/GL','ITSOFT\ibrahim.harby',1,N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1738 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1738,1025,N'حساب/أ.ع','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 4750)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,4750,'CAPTION_MESSAGE',1,'Labels','Message','ITSOFT\ibrahim.harby',1,N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 4750 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (4750,1025,N'رسالة','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105939 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105939,1025,N'مستخدم الفرع','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105940 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105940,1025,N'مشرف الفرع','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105963 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105963,1025,N'طلبات OPS WF','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105942 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105942,1025,N'مستخدم OPS','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105943 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105943,1025,N'مشرف OPS','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105944 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105944,1025,N'مغلق','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105934 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105934,1025,N'التاريخ العمل من','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105935 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105935,1025,N'التاريخ العمل إلى','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105641 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105641,1025,N'رقم الطلب','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105936 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105936,1025,N'المرسل','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO


If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105946 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105946,1025,N'الرجاء تحديد سجل قبل النقر فوق عرض','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105947 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105947,1025,N'الرجاء تحديد سجل قبل النقر فوق نشر','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105955 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105955,1025,N'هل أنت متأكد أنك تريد نشر هذه العملية؟','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105948 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105948,1025,N'الرجاء تحديد سجل قبل النقر فوق رفض','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105960 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105960,1025,N'لا يمكن رفض هذه المعاملة حيث تم التعامل مع طلب OPS هذا بواسطة صراف آخر','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105956 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105956,1025,N'هل أنت متأكد أنك تريد رفض هذه العملية؟','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105950 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105950,1025,N'هذا الطلب مغلق','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105951 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105951,1025,N'لا يمكن تحديد حالة الطلب المحدد','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105957 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105957,1025,N'عكس','ITSOFT\ibrahim.harby',N'ITSOFT\ibrahim.harby')
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_GL_NUMBER')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_GL_NUMBER','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 866 And DSC_Name = 'TLR_DP_GL')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (866,'TLR_DP_GL','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby',1)
End
GO
--***************************************************************************************
--***************************************************************************************
--------------------------------------------------------------------------------------
-- RulesErrorDescription && RulesLocalErrorDescription && RulesTranErrorDescriptions-
--------------------------------------------------------------------------------------

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1811)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID)
 Values (1811,'OPS_NOTALLOWED_CHARGE_CASH','Cash charge is not allowed with OPS Workflow','Cash charge is not allowed with OPS Workflow',4,'ErrDesc.hlp',1)
End
go

If Not Exists(Select * From RulesLocalErrorDescription Where DescriptionNumber = 1811 And LanguageLCID = 1025)
BEGIN
 Insert Into RulesLocalErrorDescription(DescriptionNumber,LanguageLCID,DetailText,DisplayText)
 Values (1811,1025,N'الرسوم النقدية غير مسموح بها مع سير عمل OPS',N'الرسوم النقدية غير مسموح بها مع سير عمل OPS')
END
GO

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = -179999)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help)
 Values (-179999,'IB_INVALIDDATES','The FROM Date must be on or before the TO Date.  Please update and resubmit.','The FROM Date must be on or before the TO Date.  Please update and resubmit.',4,'ErrDesc.hlp')
End
go

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstAccount' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueTTAgainstAccount'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstGL' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueTTAgainstGL'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstGL' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueCOAgainstGL'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstGL' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'IssueCOAgainstAccount'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'IssueTTAgainstGL' AND  Error_Name   = 'OPS_NOTALLOWED_CHARGE_CASH'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name    ) 
  Values( 'AddNewSO'  ,  'OPS_NOTALLOWED_CHARGE_CASH'   )
END 
GO

--***************************************************************************************
--***************************************************************************************
---------------------------------------------
-- RulesExpression & RulesExpressionDetail --
---------------------------------------------
DECLARE @ExpressionId int
SELECT @ExpressionId = MAX(ExpressionId) +1 from RulesExpression
IF NOT EXISTS(SELECT * FROM RulesExpression WHERE ExpressionName = 'OPSReferenceNumber')
BEGIN
 INSERT INTO RulesExpression(ExpressionId,ExpressionName,SerialNumberLength,PaddingCharacter,IsLeftPadded,ExpressionCategroyId)
 VALUES (@ExpressionId,'OPSReferenceNumber',7,'0',1,1)

 DECLARE @Id int
 SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 1)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,1,1,'Branch',1,3,'0',1)
 END

 SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 2)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,2,1,'"_OPS"',1,4,'0',1)
 END

  SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 3)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,3,1,'BusinessDate_YYYYMMDD',1,8,'0',1)
 END

  SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 4)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,4,1,'"_"',1,1,'0',1)
 END

END
GO

--***************************************************************************************
--***************************************************************************************
---------------
-- SQLstrings -
---------------

If Not Exists(Select * From SQLstrings Where AccessID = 1100112)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100112,'GetOPSWorkFlowTrans_Picklists','p',1,'Globalfs','dbo.GetOPSWorkFlowTrans_Picklists',0,'','','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby','Select all picklists from table OPSWorkFlow based on specify criteria',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100113)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100113,'List_OPS_Transactions','p',1,'Globalfs','dbo.List_OPS_Transactions',0,'','','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby','Select all data from table OPSWorkFlow based on specify criteria',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100117)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100117,'UPDATE_LOCKED_OPS_TRANSACTIONS','p',0,'Globalfs','dbo.UpdateLockedOPSTransaction',0,'','','ITSOFT\ibrahim.harby','ITSOFT\ibrahim.harby','Update locked flag in OPSWorkFlow table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

--***************************************************************************************
--***************************************************************************************
-----------------------
-- SQL_RowSet_Columns -
-----------------------

IF Not Exists (SELECT* FROM SQL_RowSet_Columns WHERE AccessID = 1100112 ) 
	BEGIN
		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'Region', 0, 'VarChar')


		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'Branch', 1, 'VarChar')


		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'Currency', 2, 'VarChar')

		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'TranName', 3, 'VarChar')

		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'Status', 4, 'VarChar')

		INSERT INTO SQL_RowSet_Columns (AccessID, AppColumnName, seq, data_type)
			VALUES (1100112, 'BranchUser_Name', 5, 'VarChar')

	END

--***************************************************************************************
--***************************************************************************************
-----------------------------------
-- RulesParam & RulesTranFldParam -
-----------------------------------

If Not Exists(Select * From RulesParam Where ParamName='USE_OPS_WF')
BEGIN
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'USE_OPS_WF','specify To use OPS Workfolw if true','',0,1,0,'','Static','')
End


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstAccount' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstAccount' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueTTAgainstGL' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueTTAgainstGL' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstGL' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstGL' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstAccount' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstAccount' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'AddNewSO' AND FieldName = 'USE_OPS_WF' AND Param = 'USE_OPS_WF' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'AddNewSO' , 'USE_OPS_WF' , 'USE_OPS_WF' , 0 ,'ITSOFT\ibrahim.harby' , 'bit')
END
GO


If Not Exists(Select * From RulesParam Where ParamName='CO_Branch_Limit')
Begin
DECLARE @paramID1 int
SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
Values (@paramID1,'CO_Branch_Limit','specify the Max CO Branch Limit Amount','',0,1,0,'','Static','')
End


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstGL' AND FieldName = 'CO_Branch_Limit' AND Param = 'CO_Branch_Limit' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstGL' , 'CO_Branch_Limit' , 'CO_Branch_Limit' , 0,'ITSOFT\ibrahim.harby' , 'decimal')
END
GO


IF NOT EXISTS ( Select * From dbo.RulesTranFldParam Where TranName = 'IssueCOAgainstAccount' AND FieldName = 'CO_Branch_Limit' AND Param = 'CO_Branch_Limit' )
BEGIN
INSERT INTO dbo.RulesTranFldParam (TranName ,FieldName,Param,Value,Updator,DataType)
Values( 'IssueCOAgainstAccount' , 'CO_Branch_Limit' , 'CO_Branch_Limit' , 0 ,'ITSOFT\ibrahim.harby' , 'decimal')
END
GO

DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'OPSExpressionName')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'OPSExpressionName','Used for generating reference number for OPSWorkFlow',NULL,0,1,0,'','Static','',N'ITSOFT\ibrahim.harby',1)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueCOAgainstAccount' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueCOAgainstAccount','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueCOAgainstGL' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueCOAgainstGL','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueTTAgainstGL' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueTTAgainstGL','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'IssueTTAgainstAccount' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('IssueTTAgainstAccount','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'AddNewSO' AND FieldName = 'OPSExpressionName' AND Param = 'OPSExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('AddNewSO','OPSExpressionName','OPSExpressionName','OPSReferenceNumber',N'ITSOFT\ibrahim.harby','nvarchar',NULL)
END
GO


--***************************************************************************************
--***************************************************************************************
---------------------
-- RulesTranField_ex  
---------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_grb_SearchCriteria')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_grb_SearchCriteria',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_BusinessDateTo')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_BusinessDateTo',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_dt_BusinessDateTo')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_dt_BusinessDateTo',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_BusinessDateFrom')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_BusinessDateFrom',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_dt_BusinessDateFrom')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_dt_BusinessDateFrom',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_btn_Search')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_btn_Search',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Transactions')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Transactions',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Transactions')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Transactions',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Status')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Status',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Status')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Status',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Submitter')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Submitter',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Submitter')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Submitter',-1,-1,-1,1,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Region')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Region',-1,-1,-1,1,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Region')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Region',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_RequestID')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_RequestID',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_txt_RimNumber')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_txt_RimNumber',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_txt_RequestID')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_txt_RequestID',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_RimNumber')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_RimNumber',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Currency')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Currency',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Currency')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Currency',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Amount')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Amount',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_AccountLookup_Debit')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_AccountLookup_Debit',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cur_Amount')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cur_Amount',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Branch')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Branch',-1,-1,-1,1,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Branch')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Branch',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_grb_WorkFlowTransactions')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_grb_WorkFlowTransactions',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_btn_Reject')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_btn_Reject',-1,-1,-1,0,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_grd_WorkFlowTransactions')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_grd_WorkFlowTransactions',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_btn_View')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_btn_View',-1,-1,-1,0,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_cbo_Debit_GL_DP')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_cbo_Debit_GL_DP',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_Debit_DP_GL')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_Debit_DP_GL',-1,-1,-1,0,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_lbl_GLNo')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_lbl_GLNo',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_gl_GLNumber')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_gl_GLNumber',-1,-1,-1,1,0,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 866 And FieldID Is Null And FieldIDInPage = '_btn_Post')
Begin
 Insert Into RulesTranField_ex(TranID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (866,'Teller','_btn_Post',-1,-1,-1,0,1,'','',N'ITSOFT\ibrahim.harby',1,NULL,NULL,NULL,NULL)
End
GO
--***************************************************************************************
--***************************************************************************************

PRINT 'End... Script for CR# GFSY00865 DML Script'
GO

