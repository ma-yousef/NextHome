IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = 'EnableCommitmentDrawers' AND Object_ID = Object_ID('LoanProductMap'))
BEGIN
 ALTER TABLE LoanProductMap
 ADD EnableCommitmentDrawers bit NOT NULL,
 CONSTRAINT DF_LoanProductMap_EnableCommitmentDrawers 
 DEFAULT ((0)) FOR [EnableCommitmentDrawers]
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = 'DrawerCode' AND Object_ID = Object_ID('DiscChequesDetail'))
BEGIN
 ALTER TABLE DiscChequesDetail
 ADD DrawerCode nvarchar(50)
END
GO
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name='CommitmentDrawer')
BEGIN 
CREATE TABLE CommitmentDrawer (
CommitmentNo            NVARCHAR(12)      NOT NULL,
DrawerID                VARCHAR(25)       NOT NULL,
RimNo                   int               NOT NULL,
Currency                char(3)           NULL,
DrawerLimit             float             NULL,
DrawerLimitInAmount     decimal(21,6)     NULL,
ExpiryDate              DATE              NULL,
UtilizedLimit           decimal(21,6)     NULL,
AvailableLimit          decimal(21,6)     NULL,
FOLReferenceNo          NVARCHAR(40)      NULL,
FOLDate                 DATE              NULL,
Remark                  NVARCHAR(250)     NULL,
Status                  NVARCHAR(20)      NULL,
Tenor                   int               NULL,
Period                  char(8)           Null,
StartDate               date              NULL,
Creator	 				OperatorID		  NOT NULL,
Created					datetime 		  NOT NULL,
Updator					OperatorID		  NOT NULL,
LastChanged				datetime		  NOT NULL,
Row_ID					uniqueidentifier  ROWGUIDCOL  NOT NULL 
)
ALTER TABLE CommitmentDrawer ADD PRIMARY KEY (RimNo,CommitmentNo,DrawerID)

ALTER TABLE CommitmentDrawer ADD CONSTRAINT DF_CommitmentDrawer_Creator DEFAULT (suser_sname()) FOR Creator
                             
ALTER TABLE CommitmentDrawer ADD CONSTRAINT DF_CommitmentDrawer_Created DEFAULT (getdate()) FOR Created
                             
ALTER TABLE CommitmentDrawer ADD CONSTRAINT DF_CommitmentDrawer_Updator DEFAULT (suser_sname()) FOR Updator
                             
ALTER TABLE CommitmentDrawer ADD CONSTRAINT DF_CommitmentDrawer_LastChanged DEFAULT (getdate()) FOR LastChanged
                             
ALTER TABLE CommitmentDrawer ADD CONSTRAINT DF_CommitmentDrawer_Row_ID DEFAULT (newid()) FOR Row_ID
END 
GO


IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'Drawer')
BEGIN
Create TABLE Drawer (
Id                        numeric(18,0)     IDENTITY,
DrawerID                  VARCHAR(25)       NOT NULL,
DrawerName                NVARCHAR(100)     NOT NULL,
Currency                  CHAR(3)           NOT NULL,
ExpiryDate                DATE              NULL,
DrawerLimit               float             NOT NULL,
DrawerAmount              decimal(21,6)     NULL,
TotalAssignedAmount       decimal(21,6)     NULL,
UtilizedLimit             decimal(21,6)     NULL,
AvailableLimit            decimal(21,6)     NULL,
PastDue                   BIT               NULL,
Remarks                   NVARCHAR(250)     Null,
AvailabiltyOfCBRBStatus   char              NULL,
CommentsOnCBRBStatus      NVARCHAR(30)      Null,
CBRBStatusDate            DATE              Null,
Status                    char(30)          NULL,
DateOfDeactivation        DATE              Null,
StartDate                 Date              Null,
Tenor                     int               NULL,
Period                    char(8)           Null,
ModifiedDate              Date              Null, 
Creator	 				  OperatorID		NOT NULL,
Created					  datetime 			NOT NULL,
Updator					  OperatorID		NOT NULL,
LastChanged				  datetime			NOT NULL,
Row_ID					  uniqueidentifier	ROWGUIDCOL  NOT NULL
)
ALTER TABLE Drawer ADD PRIMARY KEY (DrawerID,DrawerName,Currency)

ALTER TABLE Drawer ADD CONSTRAINT DF_Drawer_Creator DEFAULT (suser_sname()) FOR Creator
                                                    
ALTER TABLE Drawer ADD CONSTRAINT DF_Drawer_Created DEFAULT (getdate()) FOR Created
                                                    
ALTER TABLE Drawer ADD CONSTRAINT DF_Drawer_Updator DEFAULT (suser_sname()) FOR Updator
                                                    
ALTER TABLE Drawer ADD CONSTRAINT DF_Drawer_LastChanged DEFAULT (getdate()) FOR LastChanged

ALTER TABLE Drawer ADD CONSTRAINT DF_Drawer_Row_ID DEFAULT (newid()) FOR Row_ID

END 
go

--  Developer:  Rokaia KAdry Begin  Issue:GFSX13267 20-09-2018  
If Not Exists(Select * from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME = 'CorporateCOs' And COLUMN_NAME ='Host_RefNo')
Begin
	Alter Table CorporateCOs Add Host_RefNo nvarchar(20) null
End

If Not Exists(Select * from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME = 'CorporateCOs' And COLUMN_NAME ='HostResponse')
Begin
	Alter Table CorporateCOs Add HostResponse nvarchar(100) null
End
If Not Exists(Select * from INFORMATION_SCHEMA.COLUMNS Where TABLE_NAME = 'CorporateCOs' And COLUMN_NAME ='CONumber_Reissue')
Begin
	Alter Table CorporateCOs Add CONumber_Reissue char(15) null
End
GO

--  Developer:  Rokaia KAdry End   Issue:GFSX13267 20-09-2018 
USE [Globalfs]
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'StatementReqFreeCharges')                   
BEGIN


CREATE TABLE [dbo].[StatementReqFreeCharges](
	[OptionNo] [int] NOT NULL,
	[RIMClass] [nvarchar](50) NOT NULL,
	[MaxCharges] [money] NOT NULL,
	[FreeRequests] [int] NOT NULL,
 CONSTRAINT [PK_StatementReqFreeCharges] PRIMARY KEY CLUSTERED 
(
	[OptionNo] ASC,
	[RIMClass] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [DynamicData]
) ON [DynamicData]


ALTER TABLE [dbo].[StatementReqFreeCharges] ADD  CONSTRAINT [DF_StatementReqFreeCharges_FreeRequests]  DEFAULT ((0)) FOR [FreeRequests]
End
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'AccountStatementRequest')                   
BEGIN
  
CREATE TABLE [dbo].[AccountStatementRequest](
	[RIMClass] [nvarchar](50) NOT NULL,
	[AccountNumber] [nvarchar](50) NOT NULL,
	[No_of_Requests] [int] NULL,
 CONSTRAINT [PK_AccountStatementRequest] PRIMARY KEY CLUSTERED 
(
	[RIMClass] ASC,
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [DynamicData]
) ON [DynamicData]

End
GO
 Drop_old_proc IRBulkInsertIntoIR     
  go
  
IF EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
	drop TYPE IRBulkTableType
end
go

IF not EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'IRBulkTableType')
begin
CREATE TYPE IRBulkTableType AS TABLE   
(FileRefNo     varchar(20),        
 FilePathName   varchar(255),        
 MsgRefNo    char(13),        
 StatusID    int,        
 ActionId    int,        
 PaymentMethodID  int,        
 DateTimeStamp   smalldatetime,        
 PreparedBy    varchar(60),--OperatorID,        
 MsgValueDate   DATETIME2,        
 ValueDate    DATETIME2,        
 DrAccountNo    varchar(60),        
 DrAccountNo_AcctType varchar(5),      
 DrAccountNo_ApplType varchar(5),      
 DrAccountNo_DepLoan varchar(5),      
 DrAccountName   nvarchar(255),        
 DrCurrency    varchar(4),--CurrencyType,        
 DrAmount    decimal(21,6),        
 DrAddress    nvarchar(255),        
 SenderBank    nvarchar(255),        
 DrExchangeRate   decimal(21,6),        
 DrCommission   decimal(21,6),        
 CrAccountNo    varchar(60),      
 CrAccountNo_AcctType varchar(5),      
 CrAccountNo_ApplType varchar(5),      
 CrAccountNo_DepLoan varchar(5),       
 CrAccountName   nvarchar(255),        
 CrCurrency    varchar(4),--CurrencyType,        
 CrAmount    decimal(21,6),        
 CrAddress    nvarchar(255),        
 OrderingCustomer  varchar(255),        
 CrExchangeRate   decimal(21,6),        
 CrCommission   decimal(21,6),        
 OriginalMsg    varchar(1000),        
 Fld_50K    varchar(255),        
 Fld_59     varchar(255),        
 Charge_Det    char(3),    
 Account_With_Ref varchar(100),    --50
 Account_With_Ac varchar(100),    --50
 Account_With_Name nvarchar(100),    --50
 ValueCurrency varchar(5),    
 Order_Cust_Name nvarchar(100),    --50
 Order_Cust_Add1 varchar(150),    --50
 Order_Cust_Add2 varchar(150),   --50 
 Order_Inst varchar(100),    --50
 Order_Inst_Name varchar(100),    --50
 Order_Inst_Add1 varchar(150),    --50
 BeneficiaryAccount varchar(100),   --60 
 FLD_70 varchar(150),    --50
 FLD_71A varchar(150),    --50
 BeneficiaryName nvarchar(140),  --40  
 BeneficiaryAddress varchar(255) ,    
 Updator    varchar(60),--OperatorID  ,    
 DB_DrValueDate DATETIME2,    
 DB_CrValueDate DATETIME2,    
 DB_DrNarrative varchar(150),    --100
 DB_CrNarrative varchar(150),    --100
 DB_FLD_20 varchar(100),    --50
 DB_FLD_23 varchar(100),    --50
 DB_FLD_33 varchar(100),    --50
 DB_FLD_52 varchar(200),  --150),    --100
 DB_FLD_53 varchar(150),    --100
 MsgType varchar(10),    
 ExceptionList varchar(8000),    
 Is_FLD_20_Duplicate bit,    
 DrRealExchangeRate decimal(21,6),        
 CrRealExchangeRate decimal(21,6),    
 TTAmount decimal(21,6),    
 TTCurrency varchar(4),    
 DrSellExchangeRate decimal(21,6),    
 CrBuyExchangeRate decimal(21,6)  ,  
 IBAN varchar(100),  --60
 Ordering_IBAN  varchar(100), --60   
 Sender_BIC nvarchar(150),--,  --100  
 --CrRimNo varchar(100),  
 --Ben_Inst_BIC varchar(100) 
 FLD_111 nvarchar(3),
 FLD_121 nvarchar(36) 
);  
end
go
IF  NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'PastDueDrawersCodesTableType' AND ss.name = N'dbo')
	CREATE TYPE [dbo].[PastDueDrawersCodesTableType] AS TABLE(
		DrawerCode nvarchar(25)
	)
GO
