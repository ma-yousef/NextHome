--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	{04/07/2021}
--Reason	:	Enh GFSY00865 - BARWA - ACM19130 - OPS Workflow
--=============================================================

PRINT 'Start. Script for Issue# GFSY00865 Table Script'
GO

----------------------
-- Table OPSWorkFlow -
----------------------
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'OPSWorkFlow')
	BEGIN
		CREATE TABLE dbo.OPSWorkFlow
		(
		    RequestID			nvarchar(max)							NOT NULL,
		    TranName			TransactionName							NOT NULL,
			Bank				BankID									NOT NULL,
			Region				RegionID								NOT NULL,
			Branch				BranchID								NOT NULL,
			JNLSequence			int										NOT NULL,
			BusinessDate		SmallDate								NOT NULL,
			TransactionTime		datetime								NOT NULL,
			Branch_User			internal_user_ID						NOT NULL,
			Branch_Supervisor	internal_user_ID						NULL,
			TID					uniqueidentifier						NOT NULL,
			Status				int										NOT NULL,
			LastChanged			datetime			DEFAULT (getdate())	NULL,
			RimNo				nvarchar(max)							NULL,
			AccountNumber		nvarchar(max)							NULL,
			Amount				money									NULL,
			Currency			CurrencyType							NULL,
			OPS_User			internal_user_ID						NULL,
			OPS_Supervisor		internal_user_ID						NULL,
			RejectionReason		nvarchar(max)							NULL,
			IsLocked			bit										NULL,
			LockedBy			internal_user_ID						NULL
		)
	END
GO

---------------------------
-- Table OPS_TranField_ex -
---------------------------
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'OPS_TranField_ex')
	BEGIN
		CREATE TABLE dbo.OPS_TranField_ex
		(
		    TranID			Tran_ID			NOT NULL,
			FieldIDInPage	varchar(max)	NOT NULL,
			IsReadOnly		bit				NOT NULL
		)
	END
GO

PRINT 'End... Script for Issue# GFSY00865 Table Script'
GO
--==================================================================================================================================================================

--Devolper	 :	Aya Tarek && Ahmed Atef
--Date       :	[12/7/2021]		
--Reason     :	CR#GFSY00870 [Swift Modification Part2 [Alter Table IR  Add  Column
        --issue#GFSX14709
------------------------------------------------------------------------------

IF NOT EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'MT199Generated')
BEGIN
	ALTER TABLE IR
	ADD MT199Generated bit NOT NULL  Default '0' 
END
GO

IF EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'MT103Generated')
BEGIN
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF__IR_MT103Generated]') AND type = 'D')
BEGIN
   ALTER TABLE IR 
   DROP CONSTRAINT [DF__IR_MT103Generated]
END
END
GO
	


IF  EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'MT103Generated')
BEGIN
	ALTER TABLE IR
	 add constraint [DF__IR_MT103Generated]  DEFAULT ((0)) for MT103Generated
END
GO


IF EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'MT202Generated')
BEGIN
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF__IR_MT202Generated]') AND type = 'D')
BEGIN
   ALTER TABLE IR 
   DROP CONSTRAINT [DF__IR_MT202Generated]
END
END
GO
	


IF  EXISTS(SELECT Column_Name FROM INFORMATION_SCHEMA.Columns WHERE Table_Name = 'IR' AND Column_Name = 'MT202Generated')
BEGIN
	ALTER TABLE IR
	 add constraint [DF__IR_MT202Generated]  DEFAULT ((0)) for MT202Generated
END
GO




/*    
Creator : Ibrahim Harby
Date: 7-september-2021
Reason: alter table to add new column "ExportFormat" - CR# GFSX14724 ADIB_ACM16164 Export Reports In PDF
*/
IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'Reports_2' AND COLUMN_NAME = 'ExportFormat')                   
BEGIN
	ALTER TABLE [dbo].Reports_2
	ADD  ExportFormat  varchar(50)   NULL DEFAULT null;
END
GO

