--Developer	: Ahmed Osman
--Purpose	: GFSY00743  KFH_ACM15771_Upgrading-Downgrading Customer Class
--Date		: 18-06-2019 
----------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'emp_rsm_grp')
BEGIN
CREATE TABLE dbo.emp_rsm_grp
(
    emp_id       int      NOT NULL,
    grp_id       smallint NOT NULL,
    effective_dt datetime NOT NULL,
    row_version  smallint NOT NULL,
    ptid         int      NOT NULL,
    create_dt    datetime NOT NULL,
    empl_id      smallint NOT NULL,
    LastChanged smalldatetime  not null,
    Updator     OperatorID  not null
)

ALTER TABLE [dbo].[emp_rsm_grp] ADD  CONSTRAINT [DF_emp_rsm_grp_LastChanged]  DEFAULT (getdate()) FOR [LastChanged]
ALTER TABLE [dbo].[emp_rsm_grp] ADD  CONSTRAINT [DF_emp_rsm_grp_updator]  DEFAULT (suser_sname()) FOR [updator]
end
GO
--Developer	: Ahmed Osman
--Purpose	: GFSY00743  KFH_ACM15771_Upgrading-Downgrading Customer Class
--Date		: 18-06-2019 
----------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'rm_cls_rsm_grp')
BEGIN
CREATE TABLE dbo.rm_cls_rsm_grp
(
    class_code   int      NOT NULL,
    grp_id       smallint NOT NULL,
    effective_dt datetime NOT NULL,
    row_version  smallint NOT NULL,
    ptid         int      NOT NULL,
    create_dt    datetime NOT NULL,
    empl_id      smallint NOT NULL,
    LastChanged smalldatetime  not null,
    Updator     OperatorID  not null
)




ALTER TABLE [dbo].[rm_cls_rsm_grp] ADD  CONSTRAINT [DF_rm_cls_rsm_grp_LastChanged]  DEFAULT (getdate()) FOR [LastChanged]

ALTER TABLE [dbo].[rm_cls_rsm_grp] ADD  CONSTRAINT [DF_rm_cls_rsm_grp_Updator]  DEFAULT (suser_sname()) FOR [Updator]
end
GO
--Programmer :	Ahmed Osman
--Date       :	[03/07/2019]		
--Reason     :	CR#GFSY00761 - BIsB_ACM16832_Customer Balances Audit Trail
--=========================================================================
PRINT 'Start. Script for CR# GFSY00761 Table Script'
GO

-------------------------------
-- Add BalanceAuditTrails Table
-------------------------------
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'BalanceAuditTrails')
	BEGIN
		CREATE TABLE dbo.BalanceAuditTrails
		(
		    TranName			TransactionName		NOT NULL,
		    Action				nvarchar(100)		NOT NULL,
			UserNumber			internal_user_ID	NOT NULL,
			MachineName			MachineName			NOT NULL,
			BusinessDate		SmallDate			NOT NULL,
			TransactionTime		datetime			NOT NULL,
			SeqNo				int					NOT NULL,
		    RimNo				nvarchar(10)		NULL,
			AccountNo			AccountNumber		NULL,
		    ReportName			nvarchar(200)		NULL,
		    Parameters			xml					NULL,
			RefNo				uniqueidentifier	NOT NULL
		)
		ALTER TABLE [dbo].BalanceAuditTrails ADD CONSTRAINT [BalanceAuditTrails_TransactionTime]  DEFAULT (getdate()) FOR [TransactionTime]
	END
GO

-----------------------
-- Edit Reports_2 Table
-----------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'Reports_2' AND COLUMN_NAME = 'IsAuditable')                   
	BEGIN
		ALTER TABLE [dbo].Reports_2
		ADD  IsAuditable  bit DEFAULT 0
	END
GO

PRINT 'End... Script for CR# GFSY00761 Table Script'
GO
--Programmer :	Ahmed Osman
--Date       :	[03/07/2019]		
--Reason     :	CR#GFSY00761 - BIsB_ACM16832_Customer Balances Audit Trail
--=========================================================================
PRINT 'Start. Script for CR# GFSY00761 Table Script'
GO

-------------------------------
-- Add BalanceAuditTrails Table
-------------------------------
IF NOT EXISTS(SELECT * FROM sys.tables WHERE name = 'BalanceAuditTrails')
	BEGIN
		CREATE TABLE dbo.BalanceAuditTrails
		(
		    TranName			TransactionName		NOT NULL,
		    Action				nvarchar(100)		NOT NULL,
			UserNumber			internal_user_ID	NOT NULL,
			MachineName			MachineName			NOT NULL,
			BusinessDate		SmallDate			NOT NULL,
			TransactionTime		datetime			NOT NULL,
			SeqNo				int					NOT NULL,
		    RimNo				nvarchar(10)		NULL,
			AccountNo			AccountNumber		NULL,
		    ReportName			nvarchar(200)		NULL,
		    Parameters			xml					NULL,
			RefNo				uniqueidentifier	NOT NULL
		)
		ALTER TABLE [dbo].BalanceAuditTrails ADD CONSTRAINT [BalanceAuditTrails_TransactionTime]  DEFAULT (getdate()) FOR [TransactionTime]
	END
GO

-----------------------
-- Edit Reports_2 Table
-----------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'Reports_2' AND COLUMN_NAME = 'IsAuditable')                   
	BEGIN
		ALTER TABLE [dbo].Reports_2
		ADD  IsAuditable  bit DEFAULT 0
	END
GO

-----------------------
-- Add sys.types ------
-----------------------
IF NOT EXISTS(SELECT * FROM sys.types WHERE name = 'RimsTable')
BEGIN 
 CREATE TYPE RimsTable AS TABLE 
(
    RimNo nvarchar(max)
)
END
GO

IF NOT EXISTS(SELECT * FROM sys.types WHERE name = 'ChargesAccountsTable')
BEGIN
 CREATE TYPE ChargesAccountsTable AS TABLE 
(
    AccountNo nvarchar(max)
)
END
GO

PRINT 'End... Script for CR# GFSY00761 Table Script'
GO
IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'RulesTranAcctStatus' AND COLUMN_NAME = 'Type')                   
BEGIN
	ALTER TABLE [dbo].RulesTranAcctStatus
	ADD  [Type]  NVARCHAR(10) not NULL DEFAULT 'Acct'
END
GO

IF Not EXISTS(SELECT * FROM INFORMATION_SCHEMA.[COLUMNS] WHERE TABLE_NAME = 'RulesTranAcctStatus' AND COLUMN_NAME = 'AccountType')                   
BEGIN
	ALTER TABLE [dbo].RulesTranAcctStatus
	ADD [AccountType] char(3) Null
END
GO

IF  EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS where Table_Name = 'RulesTranAcctStatus' AND CONSTRAINT_NAME = 'UK_RulesTranAcctStatus')
BEGIN
ALTER TABLE [dbo].RulesTranAcctStatus  
DROP CONSTRAINT  UK_RulesTranAcctStatus 
  
ALTER TABLE [dbo].RulesTranAcctStatus  With NOCHECK
ADD  CONSTRAINT  UK_RulesTranAcctStatus UNIQUE  (TranID, FieldName, Status, ApplicationType,Type,AccountType)
END
Else
Begin  
ALTER TABLE [dbo].RulesTranAcctStatus  With NOCHECK
ADD  CONSTRAINT  UK_RulesTranAcctStatus UNIQUE  (TranID, FieldName, Status, ApplicationType,Type,AccountType)
End
GO