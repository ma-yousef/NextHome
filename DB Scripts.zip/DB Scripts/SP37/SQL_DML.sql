USE [Globalfs]
GO
       
If Not Exists(Select * From ServicePacks Where BasePackageName = 'ETHIX-Branch_2.00.46' And SP_Number = 37)
Begin
Insert Into ServicePacks(BasePackageName,SP_Number,SP_Name, LastPackageName, BriefDescription, DetailedDescription,IncludeWholeFilesOnly,DontRemoveTmpFldrWhenFinished,OptionalSourceList,Comments,PatchNumber)
Values('ETHIX-Branch_2.00.46', 37,'SP37_ETHIX-Branch_2.0.46.0','SP36_ETHIX-Branch_2.0.46.0','SP37_ETHIX-Branch_2.0.46.0','', 1, 0, '', '',0)
End
GO
if not exists (select * from RulesDescriptor where DescriptorID=1104518)
begin
       INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
       Values(1,1104518,N'TLR_Read_From_Card_Reader',0,N'Labels',N'Read From Card Reader')
end
go



If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 948)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (948,'ACCOUNT_NUMBER_REQUIRED','Account Number Required','Account Number Required',9,'ErrDesc.hlp',1,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1000074)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1000074,'COR_DENOMINATION_NOT_SET','You must set all denomination','You must set all denomination',1000000,'',0,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1000116)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1000116,'COR_HAYRAT_NUMBER_ERROR','Hayrat amount must be multiple of','Hayrat amount must be multiple of',1000001,'',0,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1459)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1459,'CUSID_SCAN','Customer ID Should Be Scanned','Customer ID Should Be Scanned',6,'ErrDesc.hlp',1,'ITSOFT\amr.salaheldin','Sep 17 2013 11:12AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1000204)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1000204,'EXCEED_CSH_DEP_LIMIT','The account exceeds the account cash deposit limit.','The account exceeds the account cash deposit limit.',1000000,'',0,'ITSOFT\ayamahmoud','Jul 29 2012  3:01PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = -179984)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (-179984,'IB_NOTNEGATIVE','The field value cannot be negative','The field value cannot be negative',4,'',17,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 50001)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (50001,'OPERATOR_ACCOUNT_EXPIRED','The account for this operator has expired or been disabled.  Please contact your system administrator.','Operator account has expired.',6,'',0,'STCA1\bdavidson','Apr 26 2005  4:21PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1000202)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1000202,'REJECT_OVER_CSH_DEP','The Account is configured to reject cash deposit over the allowed cash limit.','The Account is configured to reject cash deposit over the allowed cash limit.',1000000,'',0,'ITSOFT\ayamahmoud','Jul 29 2012  3:01PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1670)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1670,'TLR_BIRTHDATE','Birthdate can not be greater than system date.','Birthdate can not be greater than system date.',4,'',1,'ITSoft\mahmoud.saad','Dec  3 2017  8:14AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1493)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1493,'TLR_DIFF_DATE_FORMAT','You are working on different date format','You are working on different date format',14,'ErrDesc.hlp',1,'ITSOFT\Asmaa.Hafez','Apr 15 2014  1:07PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1669)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1669,'TLR_EXPIRATIONDATE','Expiration Date Must be Greater Than or Equal Sysem Date.','Expiration Date Must be Greater Than or Equal Sysem Date.',4,'',1,'ITSoft\mahmoud.saad','Dec  3 2017  8:14AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1587)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1587,'TLR_FX_RECORD_LOCKED','The record is locked by the supervisor.','The record is locked by the supervisor.',12,'ErrDesc.hlp',1,'ITSOFT\AyaMahmoud','Nov  2 2015  3:30PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1100185)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1100185,'TLR_INSUFFICIENT_DEPOSIT','Deposit amount must be greater than or equal to the minimum deposit amount  (\? \?)','Insufficient Deposit Amount',4,'',1,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1620)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1620,'TLR_OPERATORLOCKED_ERRORDESC','The Operator {0} is locked.','Operator is locked.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 22 2016  8:07AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1613)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1613,'TLR_SEC_LOGIN_PWCH_ERRORMSG','Password should be combination of characters, number & special characters. At least there is one small and capital letter.','Password should be combination of characters, number & special characters. At least there is one small and capital letter.',10,'ErrDesc.hlp',1,'ITSOFT\mostafa.abdelrazek','Dec  4 2016  3:24PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1619)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1619,'TLR_SECLOGCHPW_ERRORDESC','Cannot change secondary login password for operator {0}. The operator has a matching previous password.','Cannot change secondary login password.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 21 2016 12:09PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1618)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1618,'TLR_SECLOGEMPTYMAIL_ERRORDESC','Cannotreset secondary login password for operator {0}. either login id is not correct or this user has no email address.','Failed to reset secondary login password.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 18 2016  3:45PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1615)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1615,'TLR_SECLOGPW_ERRORDESC','Login attempt is not authorized. either login id or password is not correct.','Login attempt is not authorized.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 13 2016 10:24AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1616)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1616,'TLR_SECLOGPWCH_ERRORDESC','Change Secondary Login Password attempt is not authorized. either login id or old password is not correct.','Change Secondary Login Password attempt is not authorized.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 13 2016 10:25AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1617)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1617,'TLR_SECLOGPWRESET_ERRORDESC','Failed to reset secondary login password. either login id is not correct or this user has no active secondary login password.','Failed to reset secondary login password.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 13 2016 10:27AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1100232)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1100232,'TRAN_ACCEPT_UNFUND','This transaction accepts unfunded or today renewed fixed deposit accounts.','This transaction accepts unfunded or today renewed fixed deposit accounts.',4,'',1,'GFSDOMAIN\mohibrahim','Jun 15 2008  2:40PM',1,'Dec 31 9998 12:00AM')
End
go

IF NOT EXISTS (Select * From  dbo.RulesParam Where ParamName   = 'EnableScanPrint')
BEGIN
 INSERT INTO dbo.RulesParam ( ParamID,ParamName ,Description ,isGeneral,isCustomized,isDBCheck,ValuesTypes,RowStatus )
  Values( 447, 'EnableScanPrint'  , 'Enable scanning and printing documents after transaction acceptance',0,1,0,'Static',1)
END
GO
------------------------------------------------------------------------------------------
-----  Developer     : Mostafa Helmy -----------------------------------------------------
-----  Creation Date : 05-April-2020  ----------------------------------------------------
-----  Purpose       : ACM000000016934 - KIB - Maker-Checker Adding GL To Category_FRS----
------------------------------------------------------------------------------------------
PRINT 'Start Script for CR# GFSY00787'
GO
-------------------------------------------------------------------
----------------------------RulesDescriptor------------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105560)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105560,'TLR_CategoryChanges',0,'Labels','Category Changes','ITSOFT\mostafa.helmy','Jul 29 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 29 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105561)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105561,'TLR_CatNameStatus',0,'Labels','Category Name Status','ITSOFT\mostafa.helmy','Jul 29 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 29 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105562)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105562,'TLR_CatDetRawStatus',0,'Labels','Raw Status','ITSOFT\mostafa.helmy','Jul 29 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 29 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105547)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105547,'TLR_CatNoChanges',0,'Labels','There is no changes happened to post the transaction','ITSOFT\mostafa.helmy','Jul 29 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 29 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
go
-------------------------------------------------------------------
----------------------------RulesDescriptorLocal-------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105560 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105560,1025,N'������� �����','ITSOFT\mostafa.helmy','Aug  2 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105562 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105562,1025,N'���� ����','ITSOFT\mostafa.helmy','Aug  2 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105561 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105561,1025,N'���� ��� �����','ITSOFT\mostafa.helmy','Aug  2 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105547 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1105547,1025,N'�� ���� �� ������� ���� ��������','ITSOFT\mostafa.helmy','Aug  2 2018 11:20AM',N'ITSOFT\mostafa.helmy')
End
go
-------------------------------------------------------------------
----------------------------RulesTranField_ex----------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 378 And FieldID Is Null  And FieldIDInPage = '_lbl_CATEGORY_ID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (378,NULL,'Teller','_lbl_CATEGORY_ID',-1,-1,-1,1,0,'','',NULL,'Aug  5 2018 12:50PM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 378 And FieldID Is Null  And FieldIDInPage = '_txt_CATEGORY_ID')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (378,NULL,'Teller','_txt_CATEGORY_ID',-1,-1,-1,1,0,'','',NULL,'Aug  5 2018 12:50PM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 378 And FieldID Is Null  And FieldIDInPage = '_lbl_CATEGORY_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (378,NULL,'Teller','_lbl_CATEGORY_NAME',-1,-1,-1,1,0,'','',NULL,'Aug  5 2018 12:50PM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 378 And FieldID Is Null  And FieldIDInPage = '_txt_CATEGORY_NAME')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (378,NULL,'Teller','_txt_CATEGORY_NAME',-1,-1,-1,1,0,'','',NULL,'Aug  5 2018 12:50PM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 378 And FieldID Is Null  And FieldIDInPage = 'lbl_CatNameStatus')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (378,NULL,'Teller','lbl_CatNameStatus',-1,-1,-1,1,0,'','',NULL,'Aug  5 2018 12:44PM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 378 And FieldID Is Null  And FieldIDInPage = 'txt_NameStatus')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (378,NULL,'Teller','txt_NameStatus',-1,-1,-1,1,0,'','',NULL,'Aug  5 2018 12:50PM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
If Not Exists(Select * From RulesTranField_ex Where TranID = 378 And FieldID Is Null  And FieldIDInPage = 'btn_CatCahnges')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (378,NULL,'Teller','btn_CatCahnges',-1,-1,-1,1,0,'','',NULL,'Aug  5 2018 12:55PM',N'ITSOFT\mostafa.helmy',1,NULL,NULL,NULL,NULL)
End
go
-------------------------------------------------------------------
----------------------------RulesTranDescriptors-------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 378 And DSC_Name = 'TLR_CategoryChanges')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (378,'TLR_CategoryChanges','Jul 29 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Jul 29 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 378 And DSC_Name = 'TLR_CatNameStatus')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (378,'TLR_CatNameStatus','Jul 29 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Jul 29 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 378 And DSC_Name = 'TLR_CatDetRawStatus')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (378,'TLR_CatDetRawStatus','Jul 29 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Jul 29 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 378 And DSC_Name = 'TLR_CatNoChanges')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (378,'TLR_CatNoChanges','Jul 29 2018 11:43AM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy','Jul 29 2018 11:43AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
-------------------------------------------------------------------
----------------------------RulesStepAction------------------------
-------------------------------------------------------------------

If Not Exists(Select * From RulesStepAction Where Action = 'GLCategory' And StepType = 100)
Begin
 Insert Into RulesStepAction(Action,StepType,AppID,LastChanged,Updator,Developer,Created,WritesJournal)
 Values ('GLCategory',100,1,'Mar 26 2020  3:46PM',N'ITSOFT\mostafa.helmy','ITSOFT\mostafa.helmy','Mar 26 2020  3:46PM',0)
End
go
-------------------------------------------------------------------
----------------------------RulesTranSteps------------------------
-------------------------------------------------------------------



If Not Exists(Select * From RulesTranSteps Where TranID = 378 And StepSequence = 20)
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,Developer,LastChanged,Updator,EffectiveDate,ExpirationDate,Created,RowStatus,ConditionID)
 Values (378,20,100,0,0,'GLCategory','ITSOFT\mostafa.helmy','Mar 26 2020  3:47PM',N'ITSOFT\mostafa.helmy','Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','Mar 26 2020  3:46PM',1,NULL)
End
go

-------------------------------------------------------------------
----------------------------RulesTranField-------------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesTranField Where TranID = 378 And FieldID = 149) --COR_ADDRESS_1 -- GategoryName
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (378,149,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 378 And FieldID = 152) --COR_ADDRESS_3 -- New_GategoryName
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (378,152,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 378 And FieldID = 155) --COR_CLASS_CODE -- GategoryName_Status
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (378,155,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 378 And FieldID = 208) --TLR_INSTRUMENT_TYPE -- GategoryID
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (378,208,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go
--------------

If Not Exists(Select * From RulesTranField Where TranID = 378 And FieldID = 1514) --TLR_IR_DrAccountNo_Array -- Arr_RowStatus (Added - Deleted)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (378,1514,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go


If Not Exists(Select * From RulesTranField Where TranID = 378 And FieldID = 1519) --TLR_IR_DrAccountName_Array -- Arr_CategoryName --TLR_BillType_Array--1462
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (378,1519,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 378 And FieldID = 1525) --TLR_IR_CrAccountName_Array -- Arr_GLNumber 
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (378,1525,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 378 And FieldID = 1462) --TLR_IR_DrAcNo_AccType_Arr -- Arr_GLName --TLR_BillType_Array --1462
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (378,1462,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField Where TranID = 378 And FieldID = 416) --TLR_CLR_BANK_BRNCH_ID_ARR -- Arr_CategoryID
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,LastChanged,isDupable,MaxArray,Notes,Created,Updator,RowStatus,EffectiveDate,ExpirationDate,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (378,416,1,0,0,NULL,'ITSOFT\mostafa.helmy','Aug 05 2019 12:27PM',1,NULL,'','Aug 05 2019 12:27PM',N'ITSOFT\mostafa.helmy',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',0,NULL,0,0,NULL,0,-1,NULL,NULL,NULL)
End
go
-------------------------------------------------------------------
----------------------------SQLstrings-----------------------------
-------------------------------------------------------------------

If Not Exists(Select * From SQLstrings Where AccessID = 1100039)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100039,'Delete_GL_CatDetail_ByGLNumber','p',0,'GFSOLEDB','dbo.Delete_GL_CategoryDetail_ByGLNumber',0,NULL,NULL,'ITSOFT\mostafa.helmy','ITSOFT\mostafa.helmy','Mar 12 2019 11:53AM','Delete GL Category Detail By Gl Number',1,'Jan  1 1900 12:00AM','Dec 31 9998 12:00AM','Mar 11 2012 12:00AM',' ','',0,0,1,NULL,NULL,0,0,0,0,1)
End
go
------------------------------------------------------------------------------------------
PRINT 'End Script for CR# GFSY00787'
GO
------------------------------------------------------------------------------------------

sp_help 'dbo.Delete_GL_CategoryDetail_ByGLNumber'
GO
------------------------------------------------------------------------------------------
-----  Developer     : Mostafa Helmy -----------------------------------------------------
-----  Creation Date : 05-April-2020  ----------------------------------------------------
-----  Purpose       : GFSX14003-----------------------------------------------------------
------------------------------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105547 and Name='TLR_CatNoChanges')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105547,'TLR_CatNoChanges',0,'Labels','there is no changes happened  to post the transaction','ITSOFT\mostafa.helmy','Jul 29 2018 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Jul 29 2018 11:06AM',N'ITSOFT\mostafa.helmy')
End
else
begin
update RulesDescriptor set Descriptor='there is no changes happened  to post the transaction' where Name='TLR_CatNoChanges' and  DescriptorID = 1105547
end
go
/******Mostafa Helmy [Begin:GFSX14007]{22-04-2020}*************/
If Not Exists(Select * From RulesTranName Where TranID = 378)
Begin
 Insert Into RulesTranName(TransactionName,TranID,Description,Developer,DSC_Description,LastChanged,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,RowStatus,EffectiveDate,ExpirationDate,Created,Updator,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,TotalsType,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
 Values ('GLCategory',378,'GL Category','GFSDOMAIN\mariammoneeb',1000834,'Apr 21 2020  1:15PM',13,'Teller',1,1,'CSHCKDP',1,0,0,0,0,0,1,1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Nov 19 2007 11:14AM',N'ITSOFT\mostafa.helmy',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,0)
End
else
begin
update dbo.RulesTranName set isCorrectable=0 where TranID =378
end
go
/******Mostafa Helmy [End:GFSX14007]{22-04-2020}*************/
/*
CR        :GFSY00785 - Internal_ACM18632_Min Balance Charges
Developer :Mostafa Helmy
Date      :02-03-2020
*/

-------------------------------------------------------------------
-----------------------RulesParam----------------------------------
-------------------------------------------------------------------

	
If Not Exists(Select * From RulesParam Where  ParamName='MinBalanceChargeAcc')
Begin
	DECLARE @ParamID INT
	SELECT @ParamID = MAX(ParamID) +1 FROM RulesParam
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@ParamID,'MinBalanceChargeAcc','Apply charge on FromAccount',NULL,0,0,0,'','Static','','Feb 11 2014  3:22PM',N'ITSOFT\mostafa.helmy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)


	
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'AddNewSO' And FieldName = 'DrawerType' And Param = 'MinBalanceChargeAcc')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('AddNewSO','DrawerType','MinBalanceChargeAcc','ToAcc',N'ITSOFT\mostafa.helmy','nvarchar','March 02 2020 9:22AM',NULL)
	End
End
go




--Programmer : Mostafa Sayed
--Date       : [09/03/2020]
--Reason     : CR#GFSY00794 - BIsB_ACM17780_Credit Card Multiple Payment .....
-------------------------------------------------------------------
--------------------------RulesDescriptor--------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105570)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105570,N'TLR_CHQ_AMT_TO_BE_PAID',1,N'Labels',N'Cheque Amount Must Equal To Total Amount To Be Paid')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105570 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105570,1025,N'���� ����� ��� �� ����� ������ �������� ������ ����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105569)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105569,N'TLR_DISCARD_CONTINUE_MSG',1,N'Labels',N'Are you sure you want to discard current credit card payment details?')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105569 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105569,1025,N'�� ��� ����� ��� ���� ����� ������ ������ �������� �������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105563)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105563,N'TLR_LINK_RESPONSE',1,N'Labels',N'Response')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105563 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105563,1025,N'���������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105564)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105564,N'TLR_LINK_RESPONSE_DETAILS',1,N'Labels',N'Response Details')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105564 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105564,1025,N'������ ��������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105557)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105557,N'MULTI_PAYMENT_CARDNUMBER',1,N'Labels',N'99999******99999')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105556)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105556,N'TLR_CREDIT_CARD_EXISTS',1,N'Labels',N'This Credit Card Number Already Exists.')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105556 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105556,1025,N'��� ����� �������� ����� ������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105528)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105528,N'TLR_CREDIT_CARD_MUL_PAYMENT',1,N'Labels',N'Credit Card Multiple Payment')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105528 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105528,1025,N'����� ������� ������� ��������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105532)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105532,N'TLR_AMOUNT_TO_PAID',1,N'Labels',N'Amount To Paid')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105532 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105532,1025,N'������ �������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105533)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105533,N'TLR_TOTAL_AMT_TO_BE_PAID',1,N'Labels',N'Total Amount To Be Paid')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105533 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105533,1025,N'������ �������� ������ ����')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105534)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105534,N'TLR_CREDIT_CARD_NO',1,N'Labels',N'Credit Card Number')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105534 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105534,1025,N'��� ����� ��������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105535)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105535,N'TLR_CREDIT_CARD_LIST',1,N'Labels',N'Credit Card List')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105535 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105535,1025,N'����� ������ ��������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105536)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105536,N'TLR_TOTAL_MIN_DUE',1,N'Labels',N'Total Minimum Due')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105536 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105536,1025,N'������ ���� ������ �������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105537)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105537,N'TRL_AVL_CREDIT_LIMIT',1,N'Labels',N'Available Credit Limit')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105537 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105537,1025,N'�� �������� ������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105538)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105538,N'TLR_CARD_LIMIT',1,N'Labels',N'Card Limit')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105538 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105538,1025,N'�� �������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105539)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105539,N'TLR_ADD_CARD_PAY_DETAILS',1,N'Labels',N'Add Credit Card Payment Details')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105539 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105539,1025,N'��� ������ ����� ������ ��������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105558)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105558,N'TLR_CCARDS_EXCEEDED',1,N'Labels',N'You have Exceeded Maximum Number of Credit Cards')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105558 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105558,1025,N'��� ������ ���� ������ ���� ������ ��������')
END
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID=1105559)
BEGIN
	INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
	Values(1,1105559,N'TLR_CARDS_SERVICE_DOWN',1,N'Labels',N'No Response from GPS')
END
GO
IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID=1105559 AND LCID=1025)
BEGIN
	INSERT INTO RulesDescriptorLocal(DescriptorID,LCID,LocalDescription)
	Values(1105559,1025,N'�� ���� �� �� ���� ����� ������� ������� ��������')
END
GO

--------------------------Totals-----------------------------------
if not exists(select * from RulesTotalsType where TotallingName='CreditCardMultiplePayment')
begin
	DECLARE @nextID INT
	SELECT @nextID = MAX(TotalsID) +1 FROM RulesTotalsType

	insert into RulesTotalsType(TotallingName,TotallingName_DSC,TotalsID,AppID)
	values('CreditCardMultiplePayment',null,@nextID,1)

	Insert Into rulestotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,BumpByFieldID,BumpByFieldIndex)
	Values (@nextID,1,1,1000070,-1,215,-1,'Cash In',0,1,'',-1,-1)
	Insert Into rulestotals(TotalsID,Sequence,AppID,TranField,TranFieldIndex,CurrencyFieldID,CurrencyFieldIndex,Bucket,OperationType,BumpBy,PreTotalRoutine,BumpByFieldID,BumpByFieldIndex)
	Values (@nextID,2,1,1129,-1,1921,-1,'Cash In',0,1,'',-1,-1)
end
go
--------------------------RulesTranName----------------------------
IF NOT EXISTS(SELECT * FROM RulesTranName WHERE TransactionName='CreditCardMultiplePayment' AND TranID=858)
BEGIN
	INSERT INTO RulesTranName(TransactionName,TranID,Description,DSC_Description,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,TotalsType,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
	Values(N'CreditCardMultiplePayment',858,N'Credit Card Multiple Payment ',1105528,101,N'DDA',101,1,N'CCMulPay',1,1,0,1,1,0,1,0,0,0,0,0,0,0,0,0,0,1,N'',N'',N'',0,N'',0,'CreditCardMultiplePayment',0,0,0,N'',NULL,0)
END
GO

--------------------------RulesContainerTrans----------------------
IF NOT EXISTS(SELECT * FROM RulesContainerTrans WHERE container_name = 'Teller' And TranName = 'CreditCardMultiplePayment')
BEGIN
	INSERT INTO RulesContainerTrans(container_name,TranName)
	Values ('Teller','CreditCardMultiplePayment')
END
GO

----------------------------TransactionScopes------------------------
IF NOT EXISTS(SELECT * FROM TransactionScopes Where Scope = 1001 And TranID = 858)
BEGIN
	INSERT INTO TransactionScopes(Scope,TranID)
	Values (1001,858)
END
GO

--------------------------Component--------------------------------
IF NOT EXISTS(SELECT * FROM Component Where ComponentID = 304)
BEGIN
	INSERT INTO Component(ComponentID,AppID,ComponentName,ComponentType,Description,ProjectDirectory,ProjectFile,ProjectType,ProjectTarget,ProductionGroup,isSourceShipped,TargetDirectory,TypeLibrary,TypeLibVersion,GUID,VersionInfoFile,FileVersion,ComponentSize,InstallDirectory,ProductionGroup2,InstallDirectory2,RowStatus,WiseProject,BuildChangesOnly,SymbolsFile )
	Values (304,1,N'CreditCardMultiplePayment','DLL','',N'Teller.Net\Source\BP\Custom\CreditCardMultiplePayment',N'CreditCardMultiplePayment.csproj','C#2010',N'Debug|AnyCPU','Client_NonRegistered',0,N'..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\',N'','',NULL,N'','2.0.46.0',65536,N'Shared.Net\Source\bin\Common\Teller\',NULL,N'',1,N'GFSTellerdotNetClient.wsm',1,N'CreditCardMultiplePayment.pdb')
END
GO

--------------------------RulesTranConfig--------------------------
IF NOT EXISTS(SELECT * FROM RulesTranConfig WHERE TranID=858)
BEGIN
	INSERT INTO RulesTranConfig(TranID,DenomRequired,AccountingEntries,DrAccountCategoryID,CrAccountCategoryID,LimitCategoryID,ExchangeType,OffLineAmount,AllowEmptyAccountingEntries,VerifySignatrue,ReadAllAccountingEntries,ShowInAdmin,OD_DrAccountCategoryID,PrintOption,ForcePositioning,EnableCharges,SalesMessageActive,FutureStaleChequeDays,BackDatedStaleChequeDays,ValidateStaleCheque,StaleChequeAction,StaleChequeDefaultDate,EscWarningEnabled,ChqRngVal,ChqRngAction,Blacklisted,BlacklistedAction,BenPmtStrict,BenPmtWarning,HasCheckList,CheckListCategoryID,ShowAvlBal,AutoPrintPassBook,CashFollowAcctCurr,useFX,CheckDrawerTypeRestrictions,use_XPath_app,SameRIMForCharge,SameCurrencyForCharge,PrimaryIDExpiryVal,PrimaryIDExpiryAction,IsFinancialTran)
	Values(858,1,1,NULL,NULL,NULL,N'',0,1,0,0,1,NULL,0,1,0,0,0,0,0,N'',1,0,0,N'',0,N'',0,0,0,3,0,0,0,0,0,0,0,0,0,N'',0)
END
GO

--------------------------Menu_Action------------------------------
If Not Exists(Select * From Menu_Action Where MenuActionID = 882)
Begin
 Insert Into Menu_Action(MenuActionID,AppID,CaptionID,Caption,ActionType,MenuAction,Image,Enabled,RowStatus)
 Values (882,1,1105528,'Credit Card Multiple Payment',2,'CreditCardMultiplePayment',NULL,1,1)
End
go

--------------------------Menu_Definition--------------------------
If Not Exists(Select * From Menu_Definition Where MenuID = 2501 And MenuKey = '9515')
Begin
 Insert Into Menu_Definition(MenuID,MenuKey,Parent,MenuActionID)
 Values (2501,'9515','951',882)
End
go
--Teller Module
If Not Exists(Select * From Menu_Definition Where MenuID = 2517 And MenuKey = '215')
Begin
 Insert Into Menu_Definition(MenuID,MenuKey,Parent,MenuActionID)
 Values (2517,'215','21',882)
End
go
--------------------------RulesStepAction---------------------------
If Not Exists(Select * From RulesStepAction Where Action = 'CreditCardMultiPayment' And StepType = 100)
Begin
	Insert Into RulesStepAction(Action,StepType,AppID,WritesJournal)
	Values('CreditCardMultiPayment',100,1,0)
End
go
If Not Exists(Select * From RulesStepAction Where Action = 'SendToPhoenixWithCreditCardMultiPayment' And StepType = 413)
Begin
	Insert Into RulesStepAction(Action,StepType,AppID,WritesJournal)
	Values('SendToPhoenixWithCreditCardMultiPayment',413,1,0)
End
go

--------------------------RulesTranSteps---------------------------
If Not Exists(Select * From RulesTranSteps Where TranID = 858 And StepSequence = 5)
Begin
	Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,RowStatus,ConditionID)
	Values (858,5,305,0,0,'JournalInsert',1,NULL)
End
go
If Not Exists(Select * From RulesTranSteps Where TranID = 858 And StepSequence = 10)
Begin
	DECLARE @newId INT, @newCondID INT 
	SELECT @newId = MAX(Id)+1, @newCondID = MAX(ConditionID)+1 FROM RulesTranSteps_Conditions

	INSERT INTO RulesTranSteps_Conditions(Id, ConditionID, Seq, OperandsDataType, Operand1, Operator, Operand2, LogicalOperator)
	VALUES (@newId, @newCondID, 1, '2', 'FLD_15', '2', '1', null)

	Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,ConditionID)
	Values (858,10,413,0,0,'SendToPhoenixWithCreditCardMultiPayment',@newCondID)
End
go
If Not Exists(Select * From RulesTranSteps Where TranID = 858 And StepSequence = 15)
Begin
	DECLARE @newId INT, @newCondID INT 
	SELECT @newId = MAX(Id)+1, @newCondID = MAX(ConditionID)+1 FROM RulesTranSteps_Conditions

	INSERT INTO RulesTranSteps_Conditions(Id, ConditionID, Seq, OperandsDataType, Operand1, Operator, Operand2, LogicalOperator)
	VALUES (@newId, @newCondID, 1, '2', 'FLD_15', '1', '1', null)

	Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,ConditionID)
	Values (858,15,100,0,0,'CreditCardMultiPayment',@newCondID)
	Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,ConditionID)
	Values (858,20,413,0,0,'SendToPhoenix',@newCondID)
End
go
If Not Exists(Select * From RulesTranSteps Where TranID = 858 And StepSequence = 25)
Begin
	Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,RowStatus,ConditionID)
	Values (858,25,305,0,1,'JournalUpdate',1,NULL)
End
go

---------------------------RulesDBField--------------------------
IF EXISTS (SELECT * FROM RulesDBField WHERE Name='AO_HostCustomerID')
BEGIN
	UPDATE RulesDBField
	SET DataType='Nvarchar',FldPrecision='500'
	WHERE Name='AO_HostCustomerID'
END
GO

---------------------------RulesTranField--------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID=858 AND FieldID=-1099996)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	Values(858,-1099996,1,0,0,NULL,1,NULL,'',0,NULL,0,0,NULL,1,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID=858 AND FieldID=-1099995)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	Values(858,-1099995,1,0,0,NULL,1,NULL,'',0,NULL,0,0,NULL,1,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID=858 AND FieldID=-1099994)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	Values(858,-1099994,1,0,0,NULL,1,NULL,'',0,NULL,0,0,NULL,1,-1)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID=858 AND FieldID=232)
BEGIN
	INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	Values(858,232,1,0,0,NULL,1,NULL,'',0,NULL,0,0,NULL,1,-1)
END
GO
If Not Exists(Select * From RulesTranField Where TranID = 858 And FieldID = -129980)
Begin
	Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	Values (858,-129980,1,0,0,NULL,1,20,'Totals_Amount',0,NULL,0,0,NULL,1,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 858 And FieldID = -129979)
Begin
	Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	Values (858,-129979,1,0,0,NULL,1,20,'Totals_Batch',0,NULL,0,0,NULL,1,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 858 And FieldID = -129975)
Begin
	Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	Values (858,-129975,1,0,0,NULL,1,20,'Totals_Bucket',0,NULL,0,0,NULL,1,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 858 And FieldID = -129974)
Begin
	Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	Values (858,-129974,1,0,0,NULL,1,20,'Totals_BumpBy',0,NULL,0,0,NULL,1,-1)
End
go
If Not Exists(Select * From RulesTranField Where TranID = 858 And FieldID = -129973)
Begin
	Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	Values (858,-129973,1,0,0,NULL,1,20,'Totals_Currency_Type',0,NULL,0,0,NULL,1,-1)
End
go
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = -279997)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,-279997,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'WSResponseDetails',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 208)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,208,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'PaymentMethod',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 465)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,465,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'ChequeNumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 226)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,226,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'ChequeDate',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1156)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1156,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'ChequeAmount',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 215)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,215,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'Currency',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 271)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,271,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'CustomerName',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 146)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,146,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'IDNumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 170)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,170,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'PhoneNumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 343)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,343,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'TotalAmountToBePaid',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 9)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,9,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'DebitAmount',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1000070)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1000070,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'DebitAmountTotals',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 145)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,145,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'IDType',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 490)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,490,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'Nationality',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 15917)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,15917,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'CardNumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1463)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1463,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'CardHolderName',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1466)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1466,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'CardStatus',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1516)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1516,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'DueAmount',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1517)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1517,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'AmountToPaid',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 236)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,236,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'CardSerialNumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1890)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1890,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'MaskedCardNumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 186)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,186,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'TreasuryReference',0,-1)
END
GO

-------------------------RulesTranField_ex-------------------------
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_grb_paymentMethods')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_grb_paymentMethods',-1,-1,-1,1,0,N'TLR_PAYMENT_METHOD',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_opt_paymentMethods')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,208,N'Teller',N'_opt_paymentMethods',-1,-1,-1,1,0,N'TLR_PAYMENT_METHOD',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='micrControl1')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'micrControl1',-1,-1,-1,1,0,N'TLR_READ_MICR',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_chequeNumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_chequeNumber',-1,-1,-1,1,0,N'TLR_CHEQUE_NO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txtChequeNumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,465,N'Teller',N'_txtChequeNumber',-1,-1,-1,1,0,N'TLR_CHEQUE_NO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_chequeDate')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_chequeDate',-1,-1,-1,1,0,N'TLR_CHEQUE_DATE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_dt_chequeDate')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,226,N'Teller',N'_dt_chequeDate',-1,-1,-1,1,0,N'TLR_CHEQUE_DATE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_chequeAmount')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_chequeAmount',-1,-1,-1,1,0,N'TLR_CHEQUE_AMOUNT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_chequeAmount')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,1156,N'Teller',N'_txt_chequeAmount',-1,-1,-1,1,0,N'TLR_CHEQUE_AMOUNT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_accountLookup')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_accountLookup',-1,-1,-1,0,0,N'TLR_ACCOUNT_LOOKUP',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_currency')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_currency',-1,-1,-1,1,0,N'TLR_SO_CURRENCY',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_cbo_currency')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,215,N'Teller',N'_cbo_currency',-1,-1,-1,1,0,N'TLR_SO_CURRENCY',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_customerName')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_customerName',-1,-1,-1,1,0,N'TLR_CUST_NAME',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_customerName')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,271,N'Teller',N'_txt_customerName',-1,-1,-1,1,0,N'TLR_CUST_NAME',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_phoneNo')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_phoneNo',-1,-1,-1,1,0,N'TLR_PHONE_NO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_phoneNo')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,170,N'Teller',N'_txt_phoneNo',-1,-1,-1,1,0,N'TLR_PHONE_NO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_IDType')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_IDType',-1,-1,-1,1,0,N'IB_IDTYPE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_cbo_IDType')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,145,N'Teller',N'_cbo_IDType',-1,-1,-1,1,0,N'IB_IDTYPE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_IDNumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_IDNumber',-1,-1,-1,1,0,N'ICSR_ID_NO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_IDNumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,146,N'Teller',N'_txt_IDNumber',-1,-1,-1,1,0,N'ICSR_ID_NO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_nationality')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_nationality',-1,-1,-1,1,0,N'TLR_CRS_NATIONALITY',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_cbo_nationality')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,490,N'Teller',N'_cbo_nationality',-1,-1,-1,1,0,N'TLR_CRS_NATIONALITY',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_btn_add')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_btn_add',-1,-1,-1,1,0,N'TLR_PL_ADD',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_btn_remove')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_btn_remove',-1,-1,-1,1,0,N'TLR_REMOVE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_debitAmount')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_debitAmount',-1,-1,-1,1,0,N'TLR_DEBIT_AMOUNT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_debitAmount')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,343,N'Teller',N'_txt_debitAmount',-1,-1,-1,1,0,N'TLR_DEBIT_AMOUNT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_totalAmountToBePaid')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_totalAmountToBePaid',-1,-1,-1,1,0,N'TLR_TOTAL_AMT_TO_BE_PAID',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_totalAmountToBePaid')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,9,N'Teller',N'_txt_totalAmountToBePaid',-1,-1,-1,1,1,N'TLR_TOTAL_AMT_TO_BE_PAID',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_narrative')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_narrative',-1,-1,-1,1,0,N'TLR_NARRAIVE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_narrative')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_narrative',-1,-1,-1,1,0,N'TLR_NARRAIVE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_treasuryReferenceNumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_treasuryReferenceNumber',-1,-1,-1,1,0,N'TLR_TREASURY_REF_NO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_GTDDealTicket')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,186,N'Teller',N'_txt_GTDDealTicket',-1,-1,-1,1,0,N'TLR_TREASURY_REF_NO',N'',N'',1)
END
GO
--POPUP
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_grb_searchBy')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_grb_searchBy',-1,-1,-1,1,0,N'TLR_SEARCH_BY',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_opt_searchBy')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_opt_searchBy',-1,-1,-1,1,0,N'TLR_SEARCH_BY',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_creditCardNumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_creditCardNumber',-1,-1,-1,1,0,N'TLR_CREDIT_CARD_NO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_creditCardNumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_creditCardNumber',-1,-1,-1,1,0,N'TLR_CREDIT_CARD_NO',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_CPRNumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_CPRNumber',-1,-1,-1,1,0,N'ICSR_CPR_NUMBER',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_CPRNumber')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_CPRNumber',-1,-1,-1,1,0,N'ICSR_CPR_NUMBER',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_creditCardsList')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_creditCardsList',-1,-1,-1,1,0,N'TLR_CREDIT_CARD_LIST',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_cbo_creditCardsList')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_cbo_creditCardsList',-1,-1,-1,1,0,N'TLR_CREDIT_CARD_LIST',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_btn_search')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_btn_search',-1,-1,-1,1,0,N'TLR_SEARCH',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_grb_cardInformation')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_grb_cardInformation',-1,-1,-1,1,0,N'TLR_Card_Info',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_outstandingBalance')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_outstandingBalance',-1,-1,-1,1,0,N'TLR_OUTSTANDING_BALANCE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_outstandingBalance')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_outstandingBalance',-1,-1,-1,1,1,N'TLR_OUTSTANDING_BALANCE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_totalMinDue')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_totalMinDue',-1,-1,-1,1,0,N'TLR_TOTAL_MIN_DUE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_totalMinDue')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_totalMinDue',-1,-1,-1,1,1,N'TLR_TOTAL_MIN_DUE',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_availableCreditLimit')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_availableCreditLimit',-1,-1,-1,1,0,N'TRL_AVL_CREDIT_LIMIT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_availableCreditLimit')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_availableCreditLimit',-1,-1,-1,1,1,N'TRL_AVL_CREDIT_LIMIT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_cardHolderName')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_cardHolderName',-1,-1,-1,1,0,N'TLR_CARD_HOLDER_NAME',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_cardHolderName')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_cardHolderName',-1,-1,-1,1,1,N'TLR_CARD_HOLDER_NAME',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_creditLimit')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_creditLimit',-1,-1,-1,1,0,N'TLR_CARD_LIMIT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_creditLimit')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_creditLimit',-1,-1,-1,1,1,N'TLR_CARD_LIMIT',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_cardStatus')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_cardStatus',-1,-1,-1,1,0,N'CRD_CARD_STATUS',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_cardStatus')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_cardStatus',-1,-1,-1,1,1,N'CRD_CARD_STATUS',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_lbl_amountToPaid')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_lbl_amountToPaid',-1,-1,-1,1,0,N'TLR_AMOUNT_TO_PAID',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_txt_amountToPaid')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_txt_amountToPaid',-1,-1,-1,1,0,N'TLR_AMOUNT_TO_PAID',N'',N'',1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField_ex WHERE TranID=858 AND FieldIDInPage='_btn_addNext')
BEGIN
	INSERT INTO RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,IsVisible)
	Values(858,NULL,N'Teller',N'_btn_addNext',-1,-1,-1,1,0,N'TLR_ADD_NEXT',N'',N'',1)
END
GO

-------------------------RulesTranDescriptors-----------------------
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_RecordExist')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_RecordExist')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CREDIT_CARD_EXISTS')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CREDIT_CARD_EXISTS')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_PAYMENT_METHOD')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_PAYMENT_METHOD')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='ILON_LO_PMNT_METHOD_CASH')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'ILON_LO_PMNT_METHOD_CASH')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_ACCOUNT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_ACCOUNT')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CHEQUE_NO')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CHEQUE_NO')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CHEQUE_DATE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CHEQUE_DATE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CHEQUE_AMOUNT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CHEQUE_AMOUNT')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_Customer_Account_Detail')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_Customer_Account_Detail')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_SO_CURRENCY')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_SO_CURRENCY')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CUST_NAME')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CUST_NAME')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_PHONE_NO')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_PHONE_NO')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='IB_IDTYPE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'IB_IDTYPE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='ICSR_ID_NO')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'ICSR_ID_NO')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CRS_NATIONALITY')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CRS_NATIONALITY')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='IB_CARDNUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'IB_CARDNUMBER')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='ILON_LO_DueAmount_LB')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'ILON_LO_DueAmount_LB')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_AMOUNT_TO_PAID')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_AMOUNT_TO_PAID')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CARD_HOLDER_NAME')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CARD_HOLDER_NAME')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='CRD_CARD_STATUS')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'CRD_CARD_STATUS')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_DEBIT_AMOUNT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_DEBIT_AMOUNT')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_TOTAL_AMT_TO_BE_PAID')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_TOTAL_AMT_TO_BE_PAID')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_TREASURY_REF_NO')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_TREASURY_REF_NO')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_NARRAIVE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_NARRAIVE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_PL_ADD')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_PL_ADD')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_REMOVE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_REMOVE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='BUTTON_CANCEL')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'BUTTON_CANCEL')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='BUTTON_OK')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'BUTTON_OK')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_ADD_CARD_PAY_DETAILS')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_ADD_CARD_PAY_DETAILS')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_SEARCH_BY')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_SEARCH_BY')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CPR')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CPR')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CREDIT_CARD_NO')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CREDIT_CARD_NO')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='ICSR_CPR_NUMBER')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'ICSR_CPR_NUMBER')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CREDIT_CARD_LIST')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CREDIT_CARD_LIST')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_SEARCH')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_SEARCH')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_Card_Info')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_Card_Info')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_OUTSTANDING_BALANCE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_OUTSTANDING_BALANCE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='CLOSEBALANCE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'CLOSEBALANCE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_TOTAL_MIN_DUE')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_TOTAL_MIN_DUE')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TRL_AVL_CREDIT_LIMIT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TRL_AVL_CREDIT_LIMIT')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CARD_LIMIT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CARD_LIMIT')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_ADD_NEXT')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_ADD_NEXT')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CCARDS_EXCEEDED')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CCARDS_EXCEEDED')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CARDS_SERVICE_DOWN')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CARDS_SERVICE_DOWN')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='Tlr_No_Data_Posted')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'Tlr_No_Data_Posted')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_DISCARD_CONTINUE_MSG')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_DISCARD_CONTINUE_MSG')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_CHQ_AMT_TO_BE_PAID')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_CHQ_AMT_TO_BE_PAID')
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranDescriptors WHERE TranID=858 AND DSC_Name='TLR_DELETE_RECORD')
BEGIN
	INSERT INTO RulesTranDescriptors(TranID,DSC_Name)
	Values(858,N'TLR_DELETE_RECORD')
END
GO
-----------------------------Picklists---------------------------
IF NOT EXISTS(SELECT * FROM Picklists WHERE PickListID=554)
BEGIN
	INSERT INTO Picklists(AppID,PickListID,Picklist_Name)
	Values(1,554,N'TLR_CARD_SEARCH')
END
GO
IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID=554 AND DisplayOrder=0)
BEGIN
	INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value)
	Values(554,1,0,N'IB_CARDNUMBER',N'0')
END
GO
IF NOT EXISTS(SELECT * FROM PickList_Entries WHERE PickListID=554 AND DisplayOrder=1)
BEGIN
	INSERT INTO PickList_Entries(PickListID,AppID,DisplayOrder,DescriptorName,Value)
	Values(554,1,1,N'TLR_CPR',N'1')
END
GO

-------------------------ExternalWebService-----------------------
IF NOT EXISTS (SELECT * FROM ExternalWebService WHERE WebServiceName='CreditCardMultiplePayment')
BEGIN
	INSERT INTO ExternalWebService(WebServiceName,Description,WebServiceIP,MachineName,URL,UserName,Password,ApplyWSE,WebServiceMapName,Servicetype)
	Values('CreditCardMultiplePayment', 'Credit Card Multiple Payment Service','10.100.0.120','10.100.0.120','http://localhost:62508/api/Transactions/','username','password',0,'CreditCardMultiplePayment','REST')
END
GO
--SearchByCard
IF NOT EXISTS (SELECT * FROM ExternalWebServiceTran WHERE TranID=858 AND WebServiceName='CreditCardMultiplePayment' AND Methods='ONLINE_CARD_DETAILS' AND MethodsMapName='SearchByCard')
BEGIN
	declare @maxID int
	select @maxID=max(ID)+1 from ExternalWebServiceTran
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,MethodsMapName,ID)
	Values(858,'CreditCardMultiplePayment','ONLINE_CARD_DETAILS','SearchByCard',@maxID)
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='XMLParam')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'XMLParam','XMLString',0,'DUMY_XMLParam',1,'ONLINE_CARD_DETAILS.xsd')
	END 
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='OUTSTANDING_BALANCE')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'OUTSTANDING_BALANCE','decimal',1,'DUMY_OutstandingBalance',0,null)
	END 
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='MINIMUM_PAYMENT_DUE')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'MINIMUM_PAYMENT_DUE','decimal',2,'DUMY_TotalMinDue',0,null)
	END 
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='AVAILABLE_BALANCE')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'AVAILABLE_BALANCE','decimal',3,'DUMY_AvailableCreditLimit',0,null)
	END 
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='CARD_EMBOSSED_NAME')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'CARD_EMBOSSED_NAME','string',4,'DUMY_CardHolderName',0,null)
	END 
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='ACCOUNT_LIMIT')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'ACCOUNT_LIMIT','decimal',5,'DUMY_CreditLimit',0,null)
	END 
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='CARD_STATUS_DESC')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'CARD_STATUS_DESC','string',6,'DUMY_CardStatus',0,null)
	END 
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='Error_Code')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'Error_Code','string',7,'DUMY_ErrorCode',0,null)
	END 
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='Error_Desc')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'Error_Desc','string',8,'DUMY_ErrorDesc',0,null)
	END 
END
GO
--SearchByClientCode
IF NOT EXISTS (SELECT * FROM ExternalWebServiceTran WHERE TranID=858 AND WebServiceName='CreditCardMultiplePayment' AND Methods='ONLINE_CLIENT_DETAILS' AND MethodsMapName='SearchByClientCode')
BEGIN
	declare @maxID int
	select @maxID=max(ID)+1 from ExternalWebServiceTran
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,MethodsMapName,ID)
	Values(858,'CreditCardMultiplePayment','ONLINE_CLIENT_DETAILS','SearchByClientCode',@maxID)
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='XMLParam')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'XMLParam','XMLString',0,'DUMY_XMLParam',1,'ONLINE_CLIENT_DETAILS.xsd')
	END
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='Error_Code')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'Error_Code','string',1,'DUMY_ErrorCode',0,null)
	END 
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='Error_Desc')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'Error_Desc','string',2,'DUMY_ErrorDesc',0,null)
	END 
END
GO
--BulkPayment
IF NOT EXISTS (SELECT * FROM ExternalWebServiceTran WHERE TranID=858 AND WebServiceName='CreditCardMultiplePayment' AND Methods='Bulk_Payment' AND MethodsMapName='BulkPayment')
BEGIN
	declare @maxID int
	select @maxID=max(ID)+1 from ExternalWebServiceTran
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,MethodsMapName,ID)
	Values(858,'CreditCardMultiplePayment','Bulk_Payment','BulkPayment',@maxID)
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='XMLParam')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'XMLParam','XMLString',0,'DUMY_XMLParam',1,'Bulk_Payment.xsd')
	END 
END
GO
--BulkPaymentReversal
IF NOT EXISTS (SELECT * FROM ExternalWebServiceTran WHERE TranID=858 AND WebServiceName='CreditCardMultiplePayment' AND Methods='Bulk_Payment_Reversal' AND MethodsMapName='BulkPaymentReversal')
BEGIN
	declare @maxID int
	select @maxID=max(ID)+1 from ExternalWebServiceTran
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,MethodsMapName,ID)
	Values(858,'CreditCardMultiplePayment','Bulk_Payment_Reversal','BulkPaymentReversal',@maxID)
	IF NOT EXISTS (SELECT * FROM ExternalWebServiceTranParamLst WHERE WSTranMethodID=@maxID AND ParamName='XMLParam')
	BEGIN
		insert into ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,XSD)
		values(@maxID,null,@maxID,'XMLParam','XMLString',0,'DUMY_XMLParam',1,'Bulk_Reversal.xsd')
	END 
END
GO

-----------------------------RulesParam-----------------------------
If Not Exists(Select * From RulesParam Where ParamName = 'MaxNumberOfCreditCards')
Begin
	DECLARE @paramID1 int
	SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
	Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
	Values (@paramID1,'MaxNumberOfCreditCards','Define the maximum number of cards to be added in the data grid',NULL,0,1,0,'','Static','')
End
go
If Not Exists(Select * From RulesParam Where ParamName = 'CardNumberMask')
Begin
	DECLARE @paramID1 int
	SELECT @paramID1 = MAX(ParamID) +1 from RulesParam
	Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName)
	Values (305,'CardNumberMask','Setup mask for the credit card number','',0,1,0,'','Static','')
End
go

--------------------------RulesTranFldParam--------------------------
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CreditCardMultiplePayment' And FieldName = 'CreditCard' And Param = 'MaxNumberOfCreditCards')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value)
 VALUES ('CreditCardMultiplePayment','CreditCard','MaxNumberOfCreditCards','25')
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'CreditCardMultiplePayment' And FieldName = 'CreditCard' And Param = 'CardNumberMask')
BEGIN
	INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value)
	VALUES ('CreditCardMultiplePayment','CreditCard','CardNumberMask','xxxx********xxxx')
END
GO
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CreditCardMultiplePayment' And FieldName = 'Account' And Param = 'AvailableBalance')
Begin
	Insert Into RulesTranFldParam(TranName,FieldName,Param,Value)
	Values ('CreditCardMultiplePayment','Account','AvailableBalance','FALSE')
End
go
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CreditCardMultiplePayment' And FieldName = 'Account' And Param = 'ProcessType')
Begin
	Insert Into RulesTranFldParam(TranName,FieldName,Param,Value)
	Values ('CreditCardMultiplePayment','Account','ProcessType','D')
End
go
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CreditCardMultiplePayment' And FieldName = 'Account' And Param = 'ShowCustomerDetail')
Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value)
	 Values ('CreditCardMultiplePayment','Account','ShowCustomerDetail','0')
End
go
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CreditCardMultiplePayment' And FieldName = 'Account' And Param = 'ValueDateAction')
Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value)
	 Values ('CreditCardMultiplePayment','Account','ValueDateAction','N')
End
go
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CreditCardMultiplePayment' And FieldName = 'Amount' And Param = 'IsCashIn')
Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value)
	 Values ('CreditCardMultiplePayment','Amount','IsCashIn','1')
End
go
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CreditCardMultiplePayment' And FieldName = 'AmountCurrType' And Param = 'CurrencyCategoryID')
Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value)
	 Values ('CreditCardMultiplePayment','AmountCurrType','CurrencyCategoryID','4')
End
go
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CreditCardMultiplePayment' And FieldName = 'ChargesControl' And Param = 'ChargeDefaultAcc')
Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value)
	 Values ('CreditCardMultiplePayment','ChargesControl','ChargeDefaultAcc','CASH')
End
go
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CreditCardMultiplePayment' And FieldName = 'TLR_ID_NAME' And Param = 'CoreCustIDCode')
Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value)
	 Values ('CreditCardMultiplePayment','TLR_ID_NAME','CoreCustIDCode','-1')
End
go
If Not Exists(Select * From RulesTranFldParam Where TranName = 'CreditCardMultiplePayment' And FieldName = 'TLR_TOTAL_CHARGES_FORIGN' And Param = 'IsCashIn')
Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value)
	 Values ('CreditCardMultiplePayment','TLR_TOTAL_CHARGES_FORIGN','IsCashIn','1')
End
go
--------------------------RulesTranAcctStatus--------------------------
If Not Exists(Select * From RulesTranAcctStatus Where TranID = 858 AND FieldName='Account' AND Status='Active')
Begin
 Insert Into RulesTranAcctStatus(TranID,FieldName,Status,ApplicationType,StatusID,Type,AccountType)
 Values (858,'Account','Active',NULL,10000991,N'Acct',NULL)
End
go
If Not Exists(Select * From RulesTranAcctStatus Where TranID = 858 AND FieldName='TLR_CHARGE_ACCOUNT' AND Status='Active')
Begin
 Insert Into RulesTranAcctStatus(TranID,FieldName,Status,ApplicationType,StatusID,Type,AccountType)
 Values (858,'TLR_CHARGE_ACCOUNT','Active',NULL,10000992,N'Acct',NULL)
End
go
--          	Aya Tarek  26/4/2020		
--    CR_ACM-GFSY00792 - AJF_ACM18481_Point Of Sale Deposite 
--------------------------------------------


-------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal -
-------------------------------------------

---Name of transaction 
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105595 and Name ='TLR_POINT_OF_SALE_DEPOSIT')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105595,'TLR_POINT_OF_SALE_DEPOSIT',0,'Labels','Point Of Sale Deposit','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105595 AND LCID = 1025)
BEGIN
 INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 VALUES (1105595,1025,N'����� ���� �����','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
END 
GO

---POS Reference Number 
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105596 and Name = 'TLR_POS_REFERENCE_NUMBER')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105596,'TLR_POS_REFERENCE_NUMBER',0,'Labels','POS Reference Number','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
End
GO

IF NOT EXISTS(SELECT * from  RulesDescriptorLocal WHERE DescriptorID = 1105596 AND LCID = 1025)
BEGIN
 INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 VALUES (1105596,1025,N'����� ������� ����� �����','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
END 
GO


---CardType Picklist
If Not Exists(select  * From RulesDescriptor Where  DescriptorID = 1105599 and Name = 'TLR_NAPS')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105599,'TLR_NAPS',0,'Labels','NAPS','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID =1105599 AND LCID =1025)
BEGIN
 INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 VALUES (1105599,1025,N'NAPS','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
END 
GO

--If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105600 and Name = 'TLR_CREDIT_CARD')
--Begin
 --Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
-- Values (1,1105600,'TLR_CREDIT_CARD',0,'Labels','Credit card','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
--End
--GO

--IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105600 AND LCID = 1025)
--BEGIN
 --INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 --VALUES (1105600,1025,N'����� ������','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
--END 
--GO

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105600 and Name = 'TLR_PREMIUN_CARD')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105600,'TLR_PREMIUN_CARD',0,'Labels','Premium card','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105600 AND LCID = 1025)
BEGIN
 INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 VALUES (1105600,1025,N'����� �����','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
END 
GO

---------------------------------
-- RulesTranName ----------------
---------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranName WHERE TranID = 807)
BEGIN
 INSERT INTO  RulesTranName(TransactionName,TranID,Description,Developer,DSC_Description,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,RowStatus,Updator,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,TotalsType,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
 VALUES ('PointOfSaleDeposit',807,'Point Of Sale Deposit',N'ITSOFT\aya.tarek',1105595,10,'DDA',101,1,'PoSalDps',1,1,0,1,0,0,1,1,N'ITSOFT\aya.tarek',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,0)
END
GO

---------------------------------
-- RulesContainerTrans ----------------
---------------------------------
If Not Exists(Select * From RulesContainerTrans WHERE TranName = 'PointOfSaleDeposit')
BEGIN
 Insert Into RulesContainerTrans(container_name,TranName,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('Teller','PointOfSaleDeposit','2020-04-26 13:15:00',N'ITSOFT\aya.tarek',1,'9998-12-31 00:00:00.000','2020-04-26 13:15:00')
END
GO


---------------------------------
-- RulesContainerTrans ----------------
---------------------------------
IF NOT EXISTS(SELECT * FROM TransactionScopes WHERE Scope = 1001 AND TranID = 807)
BEGIN
 INSERT INTO TransactionScopes(Scope,TranID,Developer,Updator,RowStatus)
 VALUES (1001,807,N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1)
END
GO

---------------------------------
-- Component --------------------
---------------------------------

IF NOT EXISTS(SELECT * FROM Component WHERE ComponentID = 284)
BEGIN
 INSERT INTO Component(ComponentID,AppID,ComponentName,ComponentType,Description,ProjectDirectory,ProjectFile,ProjectType,ProjectTarget,ProductionGroup,isSourceShipped,TargetDirectory,TypeLibrary,TypeLibVersion,GUID,VersionInfoFile,FileVersion,ComponentSize,Developer,InstallDirectory,Updator,ProductionGroup2,InstallDirectory2,RowStatus,WiseProject,BuildChangesOnly,SourceChanged,LastBuilt,SymbolsFile)
 VALUES (284,1,N'PointOfSaleDeposit','DLL','',N'Teller.Net\Source\BP\Custom\PointOfSaleDeposit',N'PointOfSaleDeposit.csproj','C#2010',N'Debug','Client_NonRegistered',0,N'..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\',NULL,NULL,NULL,NULL,'2.0.46.0',86016,N'ITSOFT\aya.tarek',N'shared.net\Source\bin\Common\Teller',N'ITSOFT\aya.tarek',NULL,NULL,1,N'GFSTellerdotNetClient.wsm',1,NULL,NULL,N'PointOfSaleDeposit.pdb')
END
GO


---------------------------------
-- RulesTranConfig --------------
---------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranConfig WHERE TranID = 807)
Begin
 Insert Into RulesTranConfig(TranID,DenomRequired,AccountingEntries,AllowEmptyAccountingEntries,ReadAllAccountingEntries,LastChanged,Updator,PrintOption,ForcePositioning,EnableCharges,SalesMessageActive,FutureStaleChequeDays,BackDatedStaleChequeDays,ValidateStaleCheque,StaleChequeAction,StaleChequeDefaultDate,EscWarningEnabled,Blacklisted,BlacklistedAction,BenPmtStrict,BenPmtWarning,HasCheckList,CheckListCategoryID,ShowAvlBal,AutoPrintPassBook,DaysAllowedForReversal,CashFollowAcctCurr,useFX,CheckDrawerTypeRestrictions,use_XPath_app,SameRIMForCharge,SameCurrencyForCharge,PrimaryIDExpiryAction,PrimaryIDExpiryVal,RecoveryReversal,CustomerInquiry,ReviewVouchersBeforePrinting,UpdDateReqired,UpdDateValue,UpdDateAction,IsFinancialTran,CHK_AccumilativeInfoMessage,CHK_IncludeAccumilative,OpenSessionRequired,SupportResend,CheckBillPastDueDT,PastDueDTAction,UseExpressions,WorkOnNightlyModeAllowed,ShortDescription)
 Values (807,1,1,1,1,'2020-04-014 16:15:00',N'ITSOFT\aya.tarek',1,0,0,0,0,0,0,'Warning',0,0,1,'STOP', 0,0,1,3,1,0,10,1,1,0,0,0,0,'Warning',0,1,0,1,0,1,0,0,0,0,1,0,0,'Warning',1,0,'PoSalDps')    
End
GO

--------------------------------
--RulesTranAcctStatus-----------
--------------------------------

If Not Exists(SELECT * FROM RulesTranAcctStatus WHERE TranID =  807 )  
Begin
 Insert Into RulesTranAcctStatus (TranID,FieldName,Status,LastChanged,Updator,StatusID,Creator,Type)
  Values (807,'Account','Active','2020-04-26 13:15:00',N'ITSOFT\aya.tarek',10000993,N'ITSOFT\aya.tarek','Acct')

  Insert Into RulesTranAcctStatus (TranID,FieldName,Status,LastChanged,Updator,StatusID,Creator,Type)
  Values (807,'TLR_CHARGE_ACCOUNT','Active','2020-04-26 13:15:00',N'ITSOFT\aya.tarek',10000994,N'ITSOFT\aya.tarek','Acct')

End
GO

--------------------------------
--MenuAction-----------
--------------------------------

 IF NOT EXISTS(SELECT * FROM Menu_Action WHERE MenuActionID = 883)
BEGIN
INSERT INTO Menu_Action (MenuActionID,AppID,CaptionID,ActionType,MenuAction,Caption,Enabled,LastChanged,Created,RowStatus,EffectiveDate,ExpirationDate,Updator,Creator) 
 VALUES(883,1,1105595,2,'PointOfSaleDeposit' ,'Point Of Sale Deposit',1,'2020-04-26 13:56','2020-04-26 13:56',1,'1901-01-01 00:00','9998-12-31 00:00','ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END
GO

--------------------------------
--MenuDefiniation-----------
--------------------------------
IF NOT EXISTS(SELECT * FROM Menu_Definition WHERE MenuID = 2501 AND MenuKey = '27')
BEGIN
INSERT INTO Menu_Definition (MenuID,MenuKey,Parent,MenuActionID,LastChanged,Created,RowStatus,EffectiveDate,ExpirationDate,Updator,Creator) 
VALUES(2501,'27','2',883,'2020-04-26 14:56','2020-04-26 14:56',1,'1901-01-01 00:00','9998-12-31 00:00','ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END
GO
IF NOT EXISTS(SELECT * FROM Menu_Definition WHERE MenuID = 2517 AND MenuKey = '26')
BEGIN
INSERT INTO Menu_Definition (MenuID,MenuKey,Parent,MenuActionID,LastChanged,Created,RowStatus,EffectiveDate,ExpirationDate,Updator,Creator) 
VALUES(2517,'26','2',883,'2020-04-26 14:56','2020-04-26 14:56',1,'1901-01-01 00:00','9998-12-31 00:00','ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END
GO

--------------------------------
--Rulestransteps-----------
--------------------------------
 IF NOT EXISTS ( select * from RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  10 ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  ) 
  Values ( 807   ,   10   ,   305   ,   0   ,   0   ,  'JournalInsert'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  20   ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  ) 
  Values( 807   ,   20   ,   413   ,   0   ,   1   ,  'SendToPhoenixWithInsertCTSData'  , 'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek' ,    NULL  )
END  
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  30   ) 
BEGIN 
 INSERT INTO dbo.RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  ) 
  Values (807   ,   30   ,   413   ,   1   ,   0   ,  'SendToPhoenix'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  40   ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  )  
 Values( 807   ,   40   ,   100   ,   1   ,   0   ,  'UpdateTCDAccountState'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  50   ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  )  
 Values( 807   ,   50   ,   1000000   ,   1   ,   0   ,  'SendIFXRequest'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  60  ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  )  
 Values( 807   ,   60  ,   418   ,   1   ,   0   ,  'InsertCTSData'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  70   ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  ) 
  Values( 807   ,   70   ,   305   ,   0   ,   1   ,  'JournalUpdate'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek' ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  253  ) 
BEGIN 
      INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
      Values( 807   ,   253   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END
GO
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807   AND  FieldIDInPage   = '_Card_Number2'  ) 
BEGIN 
      INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
      Values( 807   ,  Null  ,  'Teller'  ,  '_Card_Number2'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  ''  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

--------------------------------
--RulesTranField-----------
--------------------------------

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -1099996   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   -1099996   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -1099995   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   -1099995   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -1099994   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
 Values( 807   ,   -1099994   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -1099978   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )
  Values( 807   ,   -1099978   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129980   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   -129980   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,   20   ,  'Totals_Amount'  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129979   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   -129979   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'    ,   1   ,   20   ,  'Totals_Batch'  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129975   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
Values (807   ,   -129975   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,   20   ,  'Totals_Bucket'  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
End
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129974   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values (807   ,   -129974   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,   20   ,  'Totals_BumpBy'  , 'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129973   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values (807   ,   -129973   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,   20   ,  'Totals_Currency_Type'  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -19959   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   -19959   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  9   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   9   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  145   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   145   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  146   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values (807 , 146   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  147   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   147   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  149   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values ( 807   ,   149   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO



IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  160   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values ( 807   ,   160   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  170   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   170   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  180   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   180   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  186   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   186   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  194   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   194   ,   1   ,   0   ,   0   ,  'TLR_DEPOSITER_NAME'  ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  207   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values ( 807   ,   207   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  209   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
   Values( 807   ,   209   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  210   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   210   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  214   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   214   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  218   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   218   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  221   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   221   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,  'FundAccount'  ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO
 
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  223   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   223   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
 END 
 GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  229   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   229   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  232   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   232   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  249   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values (807   ,   249   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  251   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   251   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  270   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   270   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1600   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1600   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  271   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   271   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'SourceOfFunds_text'  ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  272   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   272   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  343   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   343   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  345   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   345   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  374   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   374   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  389   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   389   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,   0   ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'TLR_DEPOSIT_SHORT_DESCRIPTION'  ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  426   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values (807   ,   426   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  433   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   433   ,   1   ,   0   ,   0   ,  'TLR_NAME'  ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,  'TLR_PHONE'  ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  434   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   434   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  521   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   521   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  523   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   523   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1063   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1063   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1069   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1069   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1081   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1081   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'IDImageName'  ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1128   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1128   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1131   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1131   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1132   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1132   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1150   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1150   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1151   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1151   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1154   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1154   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1158   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1158   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1259   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1259   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1282   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1282   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1283   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )
 Values( 807   ,   1283   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1284   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1284   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1292   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1292   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1293   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1293   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1318   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1318   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1321   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1321   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL)  
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1323   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1323   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1376   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1376   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1449   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1449   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1450   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1450   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1451   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1451   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1479   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1479   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  , 'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1497   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )
   Values( 807   ,   1497   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1500   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1500   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  8070   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   8070   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1682   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1682   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1725   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1725   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'ReferenceNumber'  ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1733   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1733   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1781   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1781   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,   0   ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'TLR_DEPOSIT_DESCRIPTION'  ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1783   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1783   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1974   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1974   ,   1   ,   0   ,   0   ,  'TLR_SO_NATIONALITY'  ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1976   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1976   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1000042   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1000042   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1000043   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1000043   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  1000140   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1000140   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 

--- new Field 
--- Card Number Numeric 

 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  284   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   284   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 

--- Card HolderName
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  179   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   179   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 

--- Picklist of CardType
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  1125   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1125   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 

--- POS Ref No 
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  1332   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1332   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END

---------------------------------
-- RulesTranField_ex----------------
---------------------------------
IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_AccountDetailBtn'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  '_AccountDetailBtn'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,    NULL    ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '7' AND  FieldIDInPage   = '_alCreditAccount'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '7'  ,  'Teller'  ,  '_alCreditAccount'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_ACCOUNT_DETAIL'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '' AND  FieldIDInPage   = '_btnCancel'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  ''  ,  'Teller'  ,  '_btnCancel'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,  'BUTTON_CANCEL'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_btnOK'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  '_btnOK'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'BUTTON_OK'  ,  'OK'  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

--IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_btnTLR_DENOMINATION_BTN'   ) 
--BEGIN 
-- INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
-- Values( 807   ,    NULL    ,  'Teller'  ,  '_btnTLR_DENOMINATION_BTN'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_DENOMINATION_BTN'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
--END 
--GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '40' AND  FieldIDInPage   = '_cboAmountCurrType'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '40'  ,  'Teller'  ,  '_cboAmountCurrType'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'COR_OTHER_DETAIL.TLR_CURRENCY'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1151' AND  FieldIDInPage   = '_cboSorceOfFunds'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1151'  ,  'Teller'  ,  '_cboSorceOfFunds'  ,   -1   ,   -1   ,   -1   ,   0   ,   1   ,  'TLR_SOURCE_OF_FUNDS'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek' ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '145' AND  FieldIDInPage   = '_cboTLR_DEPOSITOR_ID_NAME'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )
 Values( 807   ,  '145'  ,  'Teller'  ,  '_cboTLR_DEPOSITOR_ID_NAME'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  'TLR_IDTYPE'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1000043' AND  FieldIDInPage   = '_chkCOR_MAIL_ADVICE'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '1000043'  ,  'Teller'  ,  '_chkCOR_MAIL_ADVICE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'COR_MAIL_ADVICE'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_chkTLR_PRINT_CTS_NOW'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  '_chkTLR_PRINT_CTS_NOW'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '9' AND  FieldIDInPage   = '_curAmount'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '9'  ,  'Teller'  ,  '_curAmount'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_AMOUNT'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_curBalance'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  '_curBalance'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_DEPOSITOR_DETAL'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '345' AND  FieldIDInPage   = '_curCreditAmt'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '345'  ,  'Teller'  ,  '_curCreditAmt'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_CREDITAMOUNT'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = '_curFixedDeposit'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '0'  ,  'Teller'  ,  '_curFixedDeposit'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'Depositor Details'  ,  'TLR_DEPOSITOR_DETAL'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1752' AND  FieldIDInPage   = '_curNetCreditAmount'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1752'  ,  'Teller'  ,  '_curNetCreditAmount'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'NetCreditAmount'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek' ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1000041' AND  FieldIDInPage   = '_curTotalCharges'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )
   Values( 807   ,  '1000041'  ,  'Teller'  ,  '_curTotalCharges'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,  'TLR_TOTAL_CHARGES'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '232' AND  FieldIDInPage   = '_nrvDr_Narrative'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '232'  ,  'Teller'  ,  '_nrvDr_Narrative'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_NARRAIVE'  ,  'Cash Deposit'  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,   319   ,   321 )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1000040' AND  FieldIDInPage   = '_numBuyExchangeRate'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '1000040'  ,  'Teller'  ,  '_numBuyExchangeRate'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'COR_BUY_EXCHANGE_RATE'  ,  ''  ,    NULL    , 'ITSOFT\aya.tarek'  ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1000039' AND  FieldIDInPage   = '_numSellExchangeRate'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1000039'  ,  'Teller'  ,  '_numSellExchangeRate'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'COR_SELL_EXCHANGE_RATE'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek' ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1318' AND  FieldIDInPage   = '_optPrintOption'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1318'  ,  'Teller'  ,  '_optPrintOption'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_PRINT_OPTION_HAYRAT_DP'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '186' AND  FieldIDInPage   = '_txtGTD_DEAL_TICKET'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '186'  ,  'Teller'  ,  '_txtGTD_DEAL_TICKET'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_GTD_TKT'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1154' AND  FieldIDInPage   = '_txtSorceOfFunds_Other'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1154'  ,  'Teller'  ,  '_txtSorceOfFunds_Other'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_SOURCE_OF_FUNDS'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '146' AND  FieldIDInPage   = '_txtTLR_DEPOSITER_ID_NUMBER'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '146'  ,  'Teller'  ,  '_txtTLR_DEPOSITER_ID_NUMBER'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_ID_NUM'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '194' AND  FieldIDInPage   = '_txtTLR_DEPOSITER_NAME'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '194'  ,  'Teller'  ,  '_txtTLR_DEPOSITER_NAME'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_DEPOSITER_NAME'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = '_txtTLR_NARRATIVE'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '0'  ,  'Teller'  ,  '_txtTLR_NARRATIVE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_NARRAIVE'  ,  'fsds'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '147' AND  FieldIDInPage   = '_txtTLR_NARRATIVE_FUNDS'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '147'  ,  'Teller'  ,  '_txtTLR_NARRATIVE_FUNDS'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1293' AND  FieldIDInPage   = '_txtTLR_RcptNo'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1293'  ,  'Teller'  ,  '_txtTLR_RcptNo'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  'TLR_RECEIPT_NUMBER'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'exchangeRate1'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'exchangeRate1'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'COR_OTHER_DETAIL'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1974' AND  FieldIDInPage   = '_cboTLR_Nationality'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1974'  ,  'Teller'  ,  '_cboTLR_Nationality'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_SO_NATIONALITY'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
 GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '433' AND  FieldIDInPage   = '_txtTLR_DEPOSITOR_PHONE_NUM'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '433'  ,  'Teller'  ,  '_txtTLR_DEPOSITOR_PHONE_NUM'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_CCND_PHONE_NUMBER'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'idControl1'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'idControl1'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  'TLR_BENEFICIARY_ID_TYPE'  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_cboBnfcryIdType'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values(807   ,    NULL    ,  'Teller'  ,  '_cboBnfcryIdType'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  'TLR_BENEFICIARY_ID_TYPE'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_txtBnfcryNumber'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )
   Values( 807   ,    NULL    ,  'Teller'  ,  '_txtBnfcryNumber'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  'TLR_BENEFICIARY_ID_NUMBER'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1933' AND  FieldIDInPage   = '-1'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1933'  ,  'Teller'  ,  '-1'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '149' AND  FieldIDInPage   = 'cbo_Relationship'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '149'  ,  'Teller'  ,  'cbo_Relationship'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_RELATION'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1376' AND  FieldIDInPage   = 'chk_HimSelf'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1376'  ,  'Teller'  ,  'chk_HimSelf'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_HimSelf'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = 'SmartCardControl'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '-1'  ,  'Teller'  ,  'SmartCardControl'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,    NULL    ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = 'CivilIDScanControl'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '0'  ,  'Teller'  ,  'CivilIDScanControl'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = 'scrControl1'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '0'  ,  'Teller'  ,  'scrControl1'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = 'idScannerControl1'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '0'  ,  'Teller'  ,  'idScannerControl1'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '807' AND  FieldIDInPage   = '_txtGTDDealTicket'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '807'  ,  'Teller'  ,  '_txtGTDDealTicket'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_GTD_TKT'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = '_chargeControl'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '0'  ,  'Teller'  ,  '_chargeControl'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,    NULL    ,    NULL    ,    NULL    , 'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'scrControl1'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'scrControl1'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,    NULL    ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'idScannerControl1'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'idScannerControl1'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,    NULL    ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'accDepositer'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'accDepositer'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'btnDedupeChecking'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'btnDedupeChecking'  ,   -1   ,   -1   ,   -1   ,   0   ,   1   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek'  ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO



IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'btnIdReader'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'btnIdReader'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,   312   ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'cboIDType'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'cboIDType'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = 'txtIdNumber'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '-1'  ,  'Teller'  ,  'txtIdNumber'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,    NULL    ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO




IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_tlrDateOfBirth'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  '_tlrDateOfBirth'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO



IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_cboTLR_CountryOfIssuance'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  '_cboTLR_CountryOfIssuance'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      308   ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_tlrExpiryDate'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  '_tlrExpiryDate'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,    309   ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = '_cbo_TLR_Nationality'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '-1'  ,  'Teller'  ,  '_cbo_TLR_Nationality'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,    NULL    ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'SCRIdReader' ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'SCRIdReader'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'DateOfBirth'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'DateOfBirth'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'txtPhoneNumber'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'txtPhoneNumber'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'cboCountryOfIssuance'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'cboCountryOfIssuance'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      313   ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'ExpiryDate'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'ExpiryDate'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,   314   ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'cboNationality'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'cboNationality'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'txtDepositerName'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'txtDepositerName'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'btnIDInformation'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'btnIDInformation'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'txtIdNumber'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  values( 807   ,    NULL    ,  'Teller'  ,  'txtIdNumber'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek' ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = 'DepositPurpose'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '-1'  ,  'Teller'  ,  'DepositPurpose'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,    NULL    ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_lblTLR_TranPurpose'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  '_lblTLR_TranPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '7' AND  FieldIDInPage   = 'al_CreditAcct'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '7'  ,  'Teller'  ,  'al_CreditAcct'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_ACCOUNT_DETAIL'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO                                      

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = '_lblSorceOfFunds'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '-1'  ,  'Teller'  ,  '_lblSorceOfFunds'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,  'CTRBlank'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- Card Number
--IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = '_Card_Number'  ) 
--BEGIN 
-- INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
-- Values( 807   ,  Null  ,  'Teller'  ,  '_Card_Number'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_CARDNUMBER'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
--END 
--GO
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   is null AND  FieldIDInPage   = '_Card_Number'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  Null  ,  'Teller'  ,  '_Card_Number'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_CARDNUMBER'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


-- CardHoldername
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND   FieldIDInPage   = '_Card_Holder_Name'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  Null  ,  'Teller'  ,  '_Card_Holder_Name'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_CARD_HOLDER_NAME'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- picklist of card type
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND   FieldIDInPage   = '_Card_Type'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  Null  ,  'Teller'  ,  '_Card_Type'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_CARD_TYPE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO
 
 -- pos ref NO
 IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND   FieldIDInPage   = '_Pos_Ref_No'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  Null  ,  'Teller'  ,  '_Pos_Ref_No'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_POS_REFERENCE_NUMBER'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO



---------------------------------
-- RulesTranErrorDescriptions ---
---------------------------------

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'ACCOUNT_NUMBER_REQUIRED'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'ACCOUNT_NUMBER_REQUIRED'  ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'COR_DENOMINATION_NOT_SET'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'COR_DENOMINATION_NOT_SET'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'COR_HAYRAT_NUMBER_ERROR'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'COR_HAYRAT_NUMBER_ERROR'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'CUSID_SCAN'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'CUSID_SCAN'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'EXCEED_CSH_DEP_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'EXCEED_CSH_DEP_LIMIT'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'IB_NOTNEGATIVE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'IB_NOTNEGATIVE'  , 'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'OPERATOR_ACCOUNT_EXPIRED'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'OPERATOR_ACCOUNT_EXPIRED'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'REJECT_OVER_CSH_DEP'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'REJECT_OVER_CSH_DEP'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_BIRTHDATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_BIRTHDATE'  , 'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_DIFF_DATE_FORMAT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_DIFF_DATE_FORMAT'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_EXPIRATIONDATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_EXPIRATIONDATE'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_FX_RECORD_LOCKED'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_FX_RECORD_LOCKED'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_INSUFFICIENT_DEPOSIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_INSUFFICIENT_DEPOSIT'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_OPERATORLOCKED_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_OPERATORLOCKED_ERRORDESC'  ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SEC_LOGIN_PWCH_ERRORMSG'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_SEC_LOGIN_PWCH_ERRORMSG'  ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGCHPW_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGCHPW_ERRORDESC'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGEMPTYMAIL_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGEMPTYMAIL_ERRORDESC'  , 'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGPW_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGPW_ERRORDESC'  , 'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGPWCH_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGPWCH_ERRORDESC'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGPWRESET_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGPWRESET_ERRORDESC'  ,  'ITSOFT\aya.tarek' )
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TRAN_ACCEPT_UNFUND'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TRAN_ACCEPT_UNFUND'  ,  'ITSOFT\aya.tarek')
END 
GO

---------------------------------
-- RulesTranFldParam ------------
---------------------------------

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = '' AND  Param   = 'EnableScanPrint'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  ''  ,  'EnableScanPrint'  ,  '1'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = '_alCreditAccount' AND  Param   = 'SigCap'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  '_alCreditAccount'  ,  'SigCap'  ,  '_curAmount'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = '_chargeControl' AND  Param   = 'Charges'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  '_chargeControl'  ,  'Charges'  ,  'true'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'AvailableBalance'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'AvailableBalance'  ,  'TRUE'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'BlackListed'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'BlackListed'  ,  '0'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ProcessType'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ProcessType'  ,  'C'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ShowCustomerDetail'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ShowCustomerDetail'  ,  '1'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ValueDateAction'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )
   Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ValueDateAction'  ,  'N'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ValueDateBackDays'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ValueDateBackDays'  ,  '0'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ValueDateEnabled'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ValueDateEnabled'  ,  '0'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ValueDateFutureDays'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )
  Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ValueDateFutureDays'  ,  '0'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account_Balance' AND  Param   = 'Branch'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account_Balance'  ,  'Branch'  ,  'E'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'AccountCurrency' AND  Param   = 'SpecialForeignCurrency'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  values( 'PointOfSaleDeposit'  ,  'AccountCurrency'  ,  'SpecialForeignCurrency'  ,  ''  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'accountto' AND  Param   = 'CheckTDAccount'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'accountto'  ,  'CheckTDAccount'  ,  '1'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Amount' AND  Param   = 'IsCashIn'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Amount'  ,  'IsCashIn'  ,  '1'  ,  'GFSDOMAIN\mohgaber'  ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Amount' AND  Param   = 'UseTCR'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'Amount'  ,  'UseTCR'  ,  '0'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'AmountCurrType' AND  Param   = 'CurrencyCategoryID'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'AmountCurrType'  ,  'CurrencyCategoryID'  ,  '2'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'ChargesControl' AND  Param   = 'ChargeDefaultAcc'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'ChargesControl'  ,  'ChargeDefaultAcc'  ,  'DP'  ,  'ITSOFT\SQLADMIN'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'CustomerID' AND  Param   = 'DisplayScanningPopup'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'CustomerID'  ,  'DisplayScanningPopup'  ,  '0'  ,  'ITSOFT\aya.tarek'  ,  'bit'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'CustomerID' AND  Param   = 'ScanningCustomerID'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'CustomerID'  ,  'ScanningCustomerID'  ,  '0'  ,  'ITSOFT\aya.tarek'  ,  'bit'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'CustomerType' AND  Param   = 'QuestCategoryID'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'CustomerType'  ,  'QuestCategoryID'  ,  '1'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DisplayReport' AND  Param   = 'DisplayReport'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'DisplayReport'  ,  'DisplayReport'  ,  'true'  ,  'ITSOFT\aya.tarek'  ,  'bit'  ,  '' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'FcyToFcy'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'FcyToFcy'  ,  'None'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'FcyToFcySame'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'FcyToFcySame'  ,  'DrawerTellerFCDU,VAULTFCDU'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'FcyToLcy'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'FcyToLcy'  ,  'DrawerTellerRBU,VAULTRBU'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'LcyToFcy'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'LcyToFcy'  ,  'None'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'LcyToLcy'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'LcyToLcy'  ,  'DrawerTellerRBU,VAULTRBU'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'EffectiveDateCharges' AND  Param   = 'EffectiveDateCharges'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'EffectiveDateCharges'  ,  'EffectiveDateCharges'  ,  '0'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'GLNumber' AND  Param   = 'ChargeAccountCategory'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'GLNumber'  ,  'ChargeAccountCategory'  ,  'ALL TYPES'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'GLNumber' AND  Param   = 'ChargeDefaultAcct'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )
   Values( 'PointOfSaleDeposit'  ,  'GLNumber'  ,  'ChargeDefaultAcct'  ,  'GL'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'IDType' AND  Param   = 'AllowedIDType1Entries'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'IDType'  ,  'AllowedIDType1Entries'  ,  ''  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'IDValidationLimit' AND  Param   = 'IDValidationLimit'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'IDValidationLimit'  ,  'IDValidationLimit'  ,  '-1'  ,'ITSOFT\aya.tarek'  ,  'nvarchar'  ,  '' )
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'PopupIDType' AND  Param   = 'AllowedIDType1Entries'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'PopupIDType'  ,  'AllowedIDType1Entries'  ,  ''  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'TCR_CurrencyCategory' AND  Param   = 'TCR_CurrencyCategory'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'TCR_CurrencyCategory'  ,  'TCR_CurrencyCategory'  ,  ''  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'TLR_TOTAL_CHARGES_FORIGN' AND  Param   = 'IsCashIn'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_TOTAL_CHARGES_FORIGN'  ,  'IsCashIn'  ,  '1'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO


---------------------------------
-- RulesTranDescriptors ---------
---------------------------------
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BIRTHDATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'BIRTHDATE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BUTTON_CANCEL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'BUTTON_CANCEL'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BUTTON_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'BUTTON_NO'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BUTTON_OK'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'BUTTON_OK'  , 'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BUTTON_YES'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'BUTTON_YES'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_DETAIL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'COR_DETAIL'  ,  'ITSOFT\aya.tarek'  , 'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_MAIL_ADVICE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'COR_MAIL_ADVICE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_OK'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'COR_OK'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_OTHER_DETAIL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'COR_OTHER_DETAIL'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_PRINT_OPTION'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'COR_PRINT_OPTION'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_SELL_RATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'COR_SELL_RATE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_SUMMARY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'COR_SUMMARY'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'IBAN'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'IBAN'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'ICSR_SBS_RIM_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'ICSR_SBS_RIM_NUMBER'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'IDINFO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'IDINFO'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'ILON_MPRSS_Charge_BT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'ILON_MPRSS_Charge_BT'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'invalid_business_date'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'invalid_business_date'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'MOBILE_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'MOBILE_NO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'NotAllowedPrintCD'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'NotAllowedPrintCD'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACC_COMM'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ACC_COMM'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNT_ACTION_SUP'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ACCOUNT_ACTION_SUP'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNT_DETAIL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ACCOUNT_DETAIL'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Account_Question'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_Account_Question'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNT_STATUS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ACCOUNT_STATUS'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNT_TYPE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ACCOUNT_TYPE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNTNUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ACCOUNTNUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_AMOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_AMOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BANK_CODE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BANK_CODE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BANK_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_BANK_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BENEFICIARY_ID_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BENEFICIARY_ID_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BENEFICIARY_ID_TYPE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BENEFICIARY_ID_TYPE'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BRANCH_CODE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BRANCH_CODE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BUY_RATE_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BUY_RATE_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CASH_DEPOSIT_DAILY_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CASH_DEPOSIT_DAILY_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CCND_PHONE_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CCND_PHONE_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CERTIFICATE_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CERTIFICATE_NO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_AMOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CHEQUE_AMOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_CURRENCY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CHEQUE_CURRENCY'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_DATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CHEQUE_DATE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CHEQUE_NO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_RETURN_REASON_AUTO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CHEQUE_RETURN_REASON_AUTO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_SEQUENCE_IN_FILE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CHEQUE_SEQUENCE_IN_FILE'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CONTACT_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CONTACT_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CREDITAMOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CREDITAMOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CURRENCY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CURRENCY'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CUSTOMER_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CUSTOMER_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Dedupe_Checking'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_Dedupe_Checking'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DENOMINATION_BTN'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_DENOMINATION_BTN'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DEPOSITER_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_DEPOSITER_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DEPOSITOR_DETAL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_DEPOSITOR_DETAL'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DOWN_PAYMENT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_DOWN_PAYMENT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DRAWER_AC_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_DRAWER_AC_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_EARLY_SETTLEMENT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_EARLY_SETTLEMENT'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_EFFECTIVEDATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_EFFECTIVEDATE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_EXCEED_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_EXCEED_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_EXPIRY_DATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )
 Values( 807   ,  'TLR_EXPIRY_DATE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_FCY_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_FCY_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_FEES_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_FEES_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_FRACTION_NOT_ALLOWED'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_FRACTION_NOT_ALLOWED'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_FTD_UNFUNDED_ONLY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_FTD_UNFUNDED_ONLY'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_GTD_TKT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_GTD_TKT'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_GTDLIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_GTDLIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_HimSelf'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_HimSelf'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ID_Card_Reader'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ID_Card_Reader'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
 
GO
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ID_NUM'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ID_NUM'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_IDTYPE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_IDTYPE'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_INSUFFICIENT_DEPOSIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_INSUFFICIENT_DEPOSIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_INVALID_Busniess_Date'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_INVALID_Busniess_Date'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_IR_FileRefNo'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_IR_FileRefNo'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ISSUE_COUNTRY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ISSUE_COUNTRY'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_NARRAIVE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_NARRAIVE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_NARRATIVE_SOURCE_OF_FUND'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_NARRATIVE_SOURCE_OF_FUND'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Net_Credit_Amount'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )
   Values( 807   ,  'TLR_Net_Credit_Amount'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_NO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_NSF_CHQ_FEE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_NSF_CHQ_FEE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_OTHER_SOURCE_OF_FUNDS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_OTHER_SOURCE_OF_FUNDS'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PAST_DUE_SETTLEMENT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_PAST_DUE_SETTLEMENT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Payee_Information'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_Payee_Information'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PAYEE_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_PAYEE_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PHONE_NUM'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_PHONE_NUM'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_POPUP_IDINFORMATION'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_POPUP_IDINFORMATION'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_POSTING_ACCOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_POSTING_ACCOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PRINT_CTS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_PRINT_CTS'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PRINT_CTS_NOW'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_PRINT_CTS_NOW'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Read_From_Card_Reader'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_Read_From_Card_Reader'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_RECEIPT_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_RECEIPT_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_REGULAR_SETTLEMENT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_REGULAR_SETTLEMENT'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_RELATION'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_RELATION'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_RETURN_COUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_RETURN_COUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SELL_RATE_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_SELL_RATE_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SO_BRANCH_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_SO_BRANCH_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SO_CHARGES'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_SO_CHARGES'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SO_NATIONALITY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_SO_NATIONALITY'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SOURCE_OF_FUNDS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_SOURCE_OF_FUNDS'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_TOTAL_CHARGES'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_TOTAL_CHARGES'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_TRANSACTION_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_TRANSACTION_PURPOSE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_TREASUREY_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_TREASUREY_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_UNFUNDED_FACE_AMOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )
   Values( 807   ,  'TLR_UNFUNDED_FACE_AMOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_UPDATED_ACCUM_AMT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_UPDATED_ACCUM_AMT'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_VALIDATE_EFF_DAYS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_VALIDATE_EFF_DAYS'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_YES'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_YES'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ZERO_CHARGES_FIXED_DEPOSIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ZERO_CHARGES_FIXED_DEPOSIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

--Card Number 
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CARDNUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CARDNUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

-- Card Holder Name 
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CARD_HOLDER_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CARD_HOLDER_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

--Card Type
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CARD_TYPE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CARD_TYPE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

--Pos ref_No
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_POS_REFERENCE_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_POS_REFERENCE_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

-- trans name 
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_POINT_OF_SALE_DEPOSIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_POINT_OF_SALE_DEPOSIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO



--card details 
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'CRD_CARD_DETAIL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'CRD_CARD_DETAIL'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO


---------------------------
-----------PickLists-------
exec p_next_id 'PickLists' ,1


--cardtype
IF NOT EXISTS ( Select * From  dbo.PickLists Where  AppID   = 1  AND  PickListID   =  559  AND  PickList_Name   = 'CardTypes'  ) 
BEGIN 
 INSERT INTO dbo.PickLists ( AppID  , PickListID  , PickList_Name  , Updator  , Creator  )  
 Values( 1   ,   559   ,  'CardTypes'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO
 
------------------------------------------------
 
 
 GO
 
--PickList_Entries table :
--entries of Card Types

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 559  AND  DisplayOrder   =  0   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value  , Updator  , Creator  , CustomValues  )  
 Values( 559   ,   1   ,   0  ,  'TLR_NAPS'  ,  'NAPS'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek' ,  '<SubValues><mask></mask></SubValues>' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 559  AND  DisplayOrder   =  1   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value  , Updator  , Creator  , CustomValues  ) 
  Values( 559   ,   1   ,  1  ,  'TLR_CREDIT_CARD'  ,  'Credit card'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek'  ,  '<SubValues><mask>999999999</mask></SubValues>' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 559  AND  DisplayOrder   =  2   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value  , Updator  , Creator  , CustomValues  )  
 Values( 559   ,   1   ,   2  ,  'TLR_PREMIUN_CARD'  ,  'Premium card'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek'  ,  '<SubValues><mask>99999999999999999999</mask></SubValues>' )
END 
GO

---------------------------
-----------Totals setup-------
---------------------------

IF NOT EXISTS ( Select * From  RulesTotalsType Where  TotallingName   = 'PointOfSaleDeposit'  ) 
BEGIN 
 INSERT INTO RulesTotalsType ( TotallingName ,TotalsID,Developer,RowStatus,AppID )  
 Values( 'PointOfSaleDeposit' ,269, 'ITSOFT\aya.tarek',1,1)
END 
GO

IF EXISTS ( Select * From  RulesTranName Where  TransactionName  = 'PointOfSaleDeposit'  ) 
BEGIN 
 update RulesTranName set TotalsType ='PointOfSaleDeposit' Where  TransactionName  = 'PointOfSaleDeposit'
END 
GO



IF Not EXISTS ( Select * From  RulesTotals Where  TotalsID = 269) 
BEGIN 
 INSERT INTO RulesTotals ( TotalsID ,Sequence,AppID ,TranField,CurrencyFieldID,Bucket,BumpBy)  
 Values( 269, 1, 1,1129,1921,'Cash In',1)
END 
GO


--Programmer : Mostafa Sayed
--Date       : [19/05/2020]
--Reason     : Issue#GFSX14041 - Error when posting transaction after remote override approval
--============================================================================================
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1835)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1835,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'EncryptedCardNumber',0,-1)
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 147)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,147,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,NULL,0,-1)
END
GO
UPDATE RulesDBField
SET DataType='varchar'
where Name='TLR_INV_PMT_STATUS_AR'

go

IF EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1835)
BEGIN
	DELETE FROM RulesTranField WHERE TranID = 858 AND FieldID = 1835
END
GO
IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 858 AND FieldID = 1628)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (858,1628,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,'EncryptedCardNumber',0,-1)
END
GO
Print 'Begin:INC000000272176,Out Clearing chq rejected accepted and chq status doesnt change,Sara Badwy'
If Not Exists(Select * From RulesStepAction Where Action = 'SendToPhoenixWithOutClearingChequeRejected' And StepType = 413)
Begin
 Insert Into RulesStepAction(Action,StepType,AppID,Updator,Developer,WritesJournal)
 Values ('SendToPhoenixWithOutClearingChequeRejected',413,1,N'ITSOFT\Sara.Badwy','ITSOFT\Sara.Badwy',0)
End
go
If Not Exists(Select * From RulesTranSteps Where TranID = 220 And StepSequence = 30)
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,Developer,Updator,EffectiveDate,ExpirationDate, RowStatus,ConditionID)
 Values (220,30,413,0,0,'SendToPhoenixWithOutClearingChequeRejected',N'ITSOFT\Sara.Badwy',N'ITSOFT\Sara.Badwy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM', 1,NULL)
 If Not Exists(Select * From RulesTranSteps Where TranID = 220 And StepSequence = 40 and Action='SendToPhoenix')
Begin
 update   RulesTranSteps set StepDisabled=1 Where TranID = 220 And StepSequence = 40 and Action='SendToPhoenix'
 End
End
go
Print 'End:INC000000272176,Out Clearing chq rejected accepted and chq status doesnt change,Sara Badwy'
 
GO
Print 'Begin:INC000000272932,ASSR For OutClearingChequesSentbyBranch Duplication,Sara Badwy'
If Not Exists(Select * From RulesStepAction Where Action = 'SendToPhoenixWithOutClearingChequeSentByBranch'  And StepType = 413)
Begin
 Insert Into RulesStepAction(Action,StepType,AppID,Updator,Developer,WritesJournal)
 Values ('SendToPhoenixWithOutClearingChequeSentByBranch',413,1,N'ITSOFT\Sara.Badwy','ITSOFT\Sara.Badwy',0)
End
go
If Not Exists(Select * From RulesTranSteps Where TranID = 216 And StepSequence = 30)
Begin
 Insert Into RulesTranSteps(TranID,StepSequence,StepType,StepDisabled,ReEntryStep,Action,Developer,Updator,EffectiveDate,ExpirationDate, RowStatus,ConditionID)
 Values (216,30,413,0,0,'SendToPhoenixWithOutClearingChequeSentByBranch',N'ITSOFT\Sara.Badwy',N'ITSOFT\Sara.Badwy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM', 1,NULL)
 If Not Exists(Select * From RulesTranSteps Where TranID = 216 And StepSequence = 40 and Action='SendToPhoenix')
Begin
 update   RulesTranSteps set StepDisabled=1 Where TranID = 216 And StepSequence = 40 and Action='SendToPhoenix'
 End
End
go
Print 'End:INC000000272932,ASSR For OutClearingChequesSentbyBranch Duplication,Sara Badwy'
 
GO
--          	Aya Tarek  26/4/2020		
--    CR_ACM-GFSY00792 - AJF_ACM18481_Point Of Sale Deposite 
--------------------------------------------


-------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal -
-------------------------------------------
if not exists (select * from RulesDescriptor where DescriptorID=1104518)
begin
       INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor)
       Values(1,1104518,N'TLR_Read_From_Card_Reader',0,N'Labels',N'Read From Card Reader')
end
go

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807   AND  FieldIDInPage   = '_Card_Number2'  ) 
BEGIN 
      INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
      Values( 807   ,  Null  ,  'Teller'  ,  '_Card_Number2'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  ''  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  253  ) 
BEGIN 
      INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
      Values( 807   ,   253   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END
GO

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 948)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (948,'ACCOUNT_NUMBER_REQUIRED','Account Number Required','Account Number Required',9,'ErrDesc.hlp',1,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1000074)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1000074,'COR_DENOMINATION_NOT_SET','You must set all denomination','You must set all denomination',1000000,'',0,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1000116)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1000116,'COR_HAYRAT_NUMBER_ERROR','Hayrat amount must be multiple of','Hayrat amount must be multiple of',1000001,'',0,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1459)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1459,'CUSID_SCAN','Customer ID Should Be Scanned','Customer ID Should Be Scanned',6,'ErrDesc.hlp',1,'ITSOFT\amr.salaheldin','Sep 17 2013 11:12AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1000204)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1000204,'EXCEED_CSH_DEP_LIMIT','The account exceeds the account cash deposit limit.','The account exceeds the account cash deposit limit.',1000000,'',0,'ITSOFT\ayamahmoud','Jul 29 2012  3:01PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = -179984)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (-179984,'IB_NOTNEGATIVE','The field value cannot be negative','The field value cannot be negative',4,'',17,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 50001)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (50001,'OPERATOR_ACCOUNT_EXPIRED','The account for this operator has expired or been disabled.  Please contact your system administrator.','Operator account has expired.',6,'',0,'STCA1\bdavidson','Apr 26 2005  4:21PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1000202)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1000202,'REJECT_OVER_CSH_DEP','The Account is configured to reject cash deposit over the allowed cash limit.','The Account is configured to reject cash deposit over the allowed cash limit.',1000000,'',0,'ITSOFT\ayamahmoud','Jul 29 2012  3:01PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1670)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1670,'TLR_BIRTHDATE','Birthdate can not be greater than system date.','Birthdate can not be greater than system date.',4,'',1,'ITSoft\mahmoud.saad','Dec  3 2017  8:14AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1493)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1493,'TLR_DIFF_DATE_FORMAT','You are working on different date format','You are working on different date format',14,'ErrDesc.hlp',1,'ITSOFT\Asmaa.Hafez','Apr 15 2014  1:07PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1669)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1669,'TLR_EXPIRATIONDATE','Expiration Date Must be Greater Than or Equal Sysem Date.','Expiration Date Must be Greater Than or Equal Sysem Date.',4,'',1,'ITSoft\mahmoud.saad','Dec  3 2017  8:14AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1587)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1587,'TLR_FX_RECORD_LOCKED','The record is locked by the supervisor.','The record is locked by the supervisor.',12,'ErrDesc.hlp',1,'ITSOFT\AyaMahmoud','Nov  2 2015  3:30PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1100185)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1100185,'TLR_INSUFFICIENT_DEPOSIT','Deposit amount must be greater than or equal to the minimum deposit amount  (\? \?)','Insufficient Deposit Amount',4,'',1,'GFSDOMAIN\gfs','May 18 2008  3:57PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1620)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1620,'TLR_OPERATORLOCKED_ERRORDESC','The Operator {0} is locked.','Operator is locked.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 22 2016  8:07AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1613)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1613,'TLR_SEC_LOGIN_PWCH_ERRORMSG','Password should be combination of characters, number & special characters. At least there is one small and capital letter.','Password should be combination of characters, number & special characters. At least there is one small and capital letter.',10,'ErrDesc.hlp',1,'ITSOFT\mostafa.abdelrazek','Dec  4 2016  3:24PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1619)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1619,'TLR_SECLOGCHPW_ERRORDESC','Cannot change secondary login password for operator {0}. The operator has a matching previous password.','Cannot change secondary login password.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 21 2016 12:09PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1618)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1618,'TLR_SECLOGEMPTYMAIL_ERRORDESC','Cannotreset secondary login password for operator {0}. either login id is not correct or this user has no email address.','Failed to reset secondary login password.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 18 2016  3:45PM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1615)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1615,'TLR_SECLOGPW_ERRORDESC','Login attempt is not authorized. either login id or password is not correct.','Login attempt is not authorized.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 13 2016 10:24AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1616)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1616,'TLR_SECLOGPWCH_ERRORDESC','Change Secondary Login Password attempt is not authorized. either login id or old password is not correct.','Change Secondary Login Password attempt is not authorized.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 13 2016 10:25AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1617)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1617,'TLR_SECLOGPWRESET_ERRORDESC','Failed to reset secondary login password. either login id is not correct or this user has no active secondary login password.','Failed to reset secondary login password.',8,'',1,'ITSOFT\mostafa.abdelrazek','Dec 13 2016 10:27AM',1,'Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1100232)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,LastChanged,RowStatus,ExpirationDate)
 Values (1100232,'TRAN_ACCEPT_UNFUND','This transaction accepts unfunded or today renewed fixed deposit accounts.','This transaction accepts unfunded or today renewed fixed deposit accounts.',4,'',1,'GFSDOMAIN\mohibrahim','Jun 15 2008  2:40PM',1,'Dec 31 9998 12:00AM')
End
go

IF NOT EXISTS (Select * From  dbo.RulesParam Where ParamName   = 'EnableScanPrint')
BEGIN
 INSERT INTO dbo.RulesParam ( ParamID,ParamName ,Description ,isGeneral,isCustomized,isDBCheck,ValuesTypes,RowStatus )
  Values( 447, 'EnableScanPrint'  , 'Enable scanning and printing documents after transaction acceptance',0,1,0,'Static',1)
END
GO

---Name of transaction 
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105595 and Name ='TLR_POINT_OF_SALE_DEPOSIT')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105595,'TLR_POINT_OF_SALE_DEPOSIT',0,'Labels','Point Of Sale Deposit','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105595 AND LCID = 1025)
BEGIN
 INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 VALUES (1105595,1025,N'����� ���� �����','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
END 
GO

---POS Reference Number 
If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105596 and Name = 'TLR_POS_REFERENCE_NUMBER')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105596,'TLR_POS_REFERENCE_NUMBER',0,'Labels','POS Reference Number','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
End
GO

IF NOT EXISTS(SELECT * from  RulesDescriptorLocal WHERE DescriptorID = 1105596 AND LCID = 1025)
BEGIN
 INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 VALUES (1105596,1025,N'����� ������� ����� �����','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
END 
GO


---CardType Picklist
If Not Exists(select  * From RulesDescriptor Where  DescriptorID = 1105599 and Name = 'TLR_NAPS')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105599,'TLR_NAPS',0,'Labels','NAPS','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID =1105599 AND LCID =1025)
BEGIN
 INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 VALUES (1105599,1025,N'NAPS','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
END 
GO

--If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105600 and Name = 'TLR_CREDIT_CARD')
--Begin
 --Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
-- Values (1,1105600,'TLR_CREDIT_CARD',0,'Labels','Credit card','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
--End
--GO

--IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105600 AND LCID = 1025)
--BEGIN
 --INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 --VALUES (1105600,1025,N'����� ������','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
--END 
--GO

If Not Exists(select * From RulesDescriptor Where  DescriptorID = 1105600 and Name = 'TLR_PREMIUN_CARD')
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105600,'TLR_PREMIUN_CARD',0,'Labels','Premium card','ITSoft\aya.tarek','April 26 2020 12:22PM',1,'Jan  1 1900 12:00AM','Dec 31 9999 12:00AM','April 26 2020 12:22PM',N'ITSOFT\aya.tarek')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptorLocal WHERE DescriptorID = 1105600 AND LCID = 1025)
BEGIN
 INSERT INTO  RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 VALUES (1105600,1025,N'����� �����','ITSoft\aya.tarek',N'ITSoft\aya.tarek')
END 
GO

---------------------------------
-- RulesTranName ----------------
---------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranName WHERE TranID = 807)
BEGIN
 INSERT INTO  RulesTranName(TransactionName,TranID,Description,Developer,DSC_Description,TranCategory,HostTranType,HeaderID,AppID,TranMnemonic,isDupable,isCorrectable,isOpenDayRequired,isHostTran,isOnlineOnly,isUITranOnly,isTestable,RowStatus,Updator,TrackForStats,VisitRequired,Minimizable,CanBeSaved,ShowCustomerInTitle,isCTR,isMIEL,Linkable,SignOnRequired,SupervisorRequired,CanRunInLocalMode,SideMenuName,SideMenuAppName,SideMenuXSL,isBPOnly,HostTranCode,isSuperDupable,TotalsType,IsImagingTran,IsExternalTran,CanBeDeferred,Task_DSC,TaskID,ShowInDWH)
 VALUES ('PointOfSaleDeposit',807,'Point Of Sale Deposit',N'ITSOFT\aya.tarek',1105595,10,'DDA',101,1,'PoSalDps',1,1,0,1,0,0,1,1,N'ITSOFT\aya.tarek',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,NULL,0,NULL,0,0,0,NULL,NULL,0)
END
GO

---------------------------------
-- RulesContainerTrans ----------------
---------------------------------
If Not Exists(Select * From RulesContainerTrans WHERE TranName = 'PointOfSaleDeposit')
BEGIN
 Insert Into RulesContainerTrans(container_name,TranName,LastChanged,Updator,RowStatus,ExpirationDate,Created)
 Values ('Teller','PointOfSaleDeposit','2020-04-26 13:15:00',N'ITSOFT\aya.tarek',1,'9998-12-31 00:00:00.000','2020-04-26 13:15:00')
END
GO


---------------------------------
-- RulesContainerTrans ----------------
---------------------------------
IF NOT EXISTS(SELECT * FROM TransactionScopes WHERE Scope = 1001 AND TranID = 807)
BEGIN
 INSERT INTO TransactionScopes(Scope,TranID,Developer,Updator,RowStatus)
 VALUES (1001,807,N'ITSOFT\aya.tarek',N'ITSOFT\aya.tarek',1)
END
GO

---------------------------------
-- Component --------------------
---------------------------------

IF NOT EXISTS(SELECT * FROM Component WHERE ComponentID = 284)
BEGIN
 INSERT INTO Component(ComponentID,AppID,ComponentName,ComponentType,Description,ProjectDirectory,ProjectFile,ProjectType,ProjectTarget,ProductionGroup,isSourceShipped,TargetDirectory,TypeLibrary,TypeLibVersion,GUID,VersionInfoFile,FileVersion,ComponentSize,Developer,InstallDirectory,Updator,ProductionGroup2,InstallDirectory2,RowStatus,WiseProject,BuildChangesOnly,SourceChanged,LastBuilt,SymbolsFile)
 VALUES (284,1,N'PointOfSaleDeposit','DLL','',N'Teller.Net\Source\BP\Custom\PointOfSaleDeposit',N'PointOfSaleDeposit.csproj','C#2010',N'Debug','Client_NonRegistered',0,N'..\..\..\..\..\Shared.Net\Source\bin\Common\Teller\',NULL,NULL,NULL,NULL,'2.0.46.0',86016,N'ITSOFT\aya.tarek',N'shared.net\Source\bin\Common\Teller',N'ITSOFT\aya.tarek',NULL,NULL,1,N'GFSTellerdotNetClient.wsm',1,NULL,NULL,N'PointOfSaleDeposit.pdb')
END
GO


---------------------------------
-- RulesTranConfig --------------
---------------------------------
IF NOT EXISTS(SELECT * FROM RulesTranConfig WHERE TranID = 807)
Begin
 Insert Into RulesTranConfig(TranID,DenomRequired,AccountingEntries,AllowEmptyAccountingEntries,ReadAllAccountingEntries,LastChanged,Updator,PrintOption,ForcePositioning,EnableCharges,SalesMessageActive,FutureStaleChequeDays,BackDatedStaleChequeDays,ValidateStaleCheque,StaleChequeAction,StaleChequeDefaultDate,EscWarningEnabled,Blacklisted,BlacklistedAction,BenPmtStrict,BenPmtWarning,HasCheckList,CheckListCategoryID,ShowAvlBal,AutoPrintPassBook,DaysAllowedForReversal,CashFollowAcctCurr,useFX,CheckDrawerTypeRestrictions,use_XPath_app,SameRIMForCharge,SameCurrencyForCharge,PrimaryIDExpiryAction,PrimaryIDExpiryVal,RecoveryReversal,CustomerInquiry,ReviewVouchersBeforePrinting,UpdDateReqired,UpdDateValue,UpdDateAction,IsFinancialTran,CHK_AccumilativeInfoMessage,CHK_IncludeAccumilative,OpenSessionRequired,SupportResend,CheckBillPastDueDT,PastDueDTAction,UseExpressions,WorkOnNightlyModeAllowed,ShortDescription)
 Values (807,1,1,1,1,'2020-04-014 16:15:00',N'ITSOFT\aya.tarek',1,0,0,0,0,0,0,'Warning',0,0,1,'STOP', 0,0,1,3,1,0,10,1,1,0,0,0,0,'Warning',0,1,0,1,0,1,0,0,0,0,1,0,0,'Warning',1,0,'PoSalDps')    
End
GO

--------------------------------
--RulesTranAcctStatus-----------
--------------------------------

If Not Exists(SELECT * FROM RulesTranAcctStatus WHERE TranID =  807 )  
Begin
 Insert Into RulesTranAcctStatus (TranID,FieldName,Status,LastChanged,Updator,StatusID,Creator,Type)
  Values (807,'Account','Active','2020-04-26 13:15:00',N'ITSOFT\aya.tarek',10000993,N'ITSOFT\aya.tarek','Acct')

  Insert Into RulesTranAcctStatus (TranID,FieldName,Status,LastChanged,Updator,StatusID,Creator,Type)
  Values (807,'TLR_CHARGE_ACCOUNT','Active','2020-04-26 13:15:00',N'ITSOFT\aya.tarek',10000994,N'ITSOFT\aya.tarek','Acct')

End
GO

--------------------------------
--MenuAction-----------
--------------------------------

 IF NOT EXISTS(SELECT * FROM Menu_Action WHERE MenuActionID = 883)
BEGIN
INSERT INTO Menu_Action (MenuActionID,AppID,CaptionID,ActionType,MenuAction,Caption,Enabled,LastChanged,Created,RowStatus,EffectiveDate,ExpirationDate,Updator,Creator) 
 VALUES(883,1,1105595,2,'PointOfSaleDeposit' ,'Point Of Sale Deposit',1,'2020-04-26 13:56','2020-04-26 13:56',1,'1901-01-01 00:00','9998-12-31 00:00','ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END
GO

--------------------------------
--MenuDefiniation-----------
--------------------------------
IF NOT EXISTS(SELECT * FROM Menu_Definition WHERE MenuID = 2501 AND MenuKey = '27')
BEGIN
INSERT INTO Menu_Definition (MenuID,MenuKey,Parent,MenuActionID,LastChanged,Created,RowStatus,EffectiveDate,ExpirationDate,Updator,Creator) 
VALUES(2501,'27','2',883,'2020-04-26 14:56','2020-04-26 14:56',1,'1901-01-01 00:00','9998-12-31 00:00','ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END
GO
IF NOT EXISTS(SELECT * FROM Menu_Definition WHERE MenuID = 2517 AND MenuKey = '26')
BEGIN
INSERT INTO Menu_Definition (MenuID,MenuKey,Parent,MenuActionID,LastChanged,Created,RowStatus,EffectiveDate,ExpirationDate,Updator,Creator) 
VALUES(2517,'26','2',883,'2020-04-26 14:56','2020-04-26 14:56',1,'1901-01-01 00:00','9998-12-31 00:00','ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END
GO

--------------------------------
--Rulestransteps-----------
--------------------------------
 IF NOT EXISTS ( select * from RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  10 ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  ) 
  Values ( 807   ,   10   ,   305   ,   0   ,   0   ,  'JournalInsert'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  20   ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  ) 
  Values( 807   ,   20   ,   413   ,   0   ,   1   ,  'SendToPhoenixWithInsertCTSData'  , 'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek' ,    NULL  )
END  
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  30   ) 
BEGIN 
 INSERT INTO dbo.RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  ) 
  Values (807   ,   30   ,   413   ,   1   ,   0   ,  'SendToPhoenix'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  40   ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  )  
 Values( 807   ,   40   ,   100   ,   1   ,   0   ,  'UpdateTCDAccountState'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  50   ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  )  
 Values( 807   ,   50   ,   1000000   ,   1   ,   0   ,  'SendIFXRequest'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  60  ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  )  
 Values( 807   ,   60  ,   418   ,   1   ,   0   ,  'InsertCTSData'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranSteps Where  TranID   = 807  AND  StepSequence   =  70   ) 
BEGIN 
 INSERT INTO RulesTranSteps ( TranID  , StepSequence  , StepType  , StepDisabled  , ReEntryStep  , Action  , Developer  , Updator  , ConditionID  ) 
  Values( 807   ,   70   ,   305   ,   0   ,   1   ,  'JournalUpdate'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek' ,    NULL  )
END 
GO



--------------------------------
--RulesTranField-----------
--------------------------------

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -1099996   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   -1099996   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -1099995   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   -1099995   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -1099994   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
 Values( 807   ,   -1099994   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -1099978   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )
  Values( 807   ,   -1099978   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129980   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   -129980   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,   20   ,  'Totals_Amount'  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129979   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   -129979   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'    ,   1   ,   20   ,  'Totals_Batch'  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129975   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
Values (807   ,   -129975   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,   20   ,  'Totals_Bucket'  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
End
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129974   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values (807   ,   -129974   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,   20   ,  'Totals_BumpBy'  , 'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -129973   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values (807   ,   -129973   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,   20   ,  'Totals_Currency_Type'  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  -19959   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   -19959   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  9   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   9   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  145   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   145   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  146   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values (807 , 146   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  147   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   147   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  149   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values ( 807   ,   149   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO



IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  160   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values ( 807   ,   160   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  170   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   170   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  180   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   180   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  186   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   186   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  194   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   194   ,   1   ,   0   ,   0   ,  'TLR_DEPOSITER_NAME'  ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  207   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values ( 807   ,   207   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  209   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
   Values( 807   ,   209   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  210   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   210   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  214   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   214   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  218   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   218   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  221   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   221   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,  'FundAccount'  ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO
 
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  223   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   223   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
 END 
 GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  229   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   229   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  232   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   232   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  249   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values (807   ,   249   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  251   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   251   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  270   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   270   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1600   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1600   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  271   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   271   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'SourceOfFunds_text'  ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  272   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   272   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  343   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   343   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  345   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   345   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  374   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   374   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  389   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   389   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,   0   ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'TLR_DEPOSIT_SHORT_DESCRIPTION'  ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  426   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values (807   ,   426   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  433   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   433   ,   1   ,   0   ,   0   ,  'TLR_NAME'  ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,  'TLR_PHONE'  ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  434   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   434   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  521   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   521   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  523   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   523   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1063   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1063   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1069   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1069   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1081   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1081   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'IDImageName'  ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1128   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1128   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1131   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1131   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1132   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1132   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1150   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1150   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1151   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1151   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1154   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1154   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1158   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1158   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1259   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1259   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1282   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1282   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1283   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )
 Values( 807   ,   1283   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1284   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1284   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1292   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1292   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1293   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1293   ,   1   ,   0   ,   0   ,    NULL    , 'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1318   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1318   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'   ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1321   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1321   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'   ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL)  
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1323   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1323   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1376   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1376   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1449   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1449   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1450   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1450   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1451   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1451   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1479   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1479   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  , 'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1497   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )
   Values( 807   ,   1497   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1500   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1500   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  8070   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   8070   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1682   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1682   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1725   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1725   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'ReferenceNumber'  ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1733   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1733   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1781   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1781   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,   0   ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,  'TLR_DEPOSIT_DESCRIPTION'  ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1783   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1783   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1974   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1974   ,   1   ,   0   ,   0   ,  'TLR_SO_NATIONALITY'  ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1976   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1976   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   0   ,   -1   ,   0   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1000042   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  )  
 Values( 807   ,   1000042   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField Where  TranID   = 807  AND  FieldID   =  1000043   ) 
BEGIN 
 INSERT INTO RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1000043   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  1000140   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1000140   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 

--- new Field 
--- Card Number Numeric 

 IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  284   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   284   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 

--- Card HolderName
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  179   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   179   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 

--- Picklist of CardType
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  1125   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1125   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END 

--- POS Ref No 
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 807  AND  FieldID   =  1332   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  , IsPrimaryKey  , PrimaryKeyAlias  , PrimaryKeySeq  ) 
  Values( 807   ,   1332   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\aya.tarek' ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1   ,   NULL   ,    NULL    ,    NULL ) 
END

---------------------------------
-- RulesTranField_ex----------------
---------------------------------
IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_AccountDetailBtn'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  '_AccountDetailBtn'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,    NULL    ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '7' AND  FieldIDInPage   = '_alCreditAccount'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '7'  ,  'Teller'  ,  '_alCreditAccount'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_ACCOUNT_DETAIL'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '' AND  FieldIDInPage   = '_btnCancel'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  ''  ,  'Teller'  ,  '_btnCancel'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,  'BUTTON_CANCEL'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_btnOK'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  '_btnOK'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'BUTTON_OK'  ,  'OK'  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

--IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_btnTLR_DENOMINATION_BTN'   ) 
--BEGIN 
-- INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
-- Values( 807   ,    NULL    ,  'Teller'  ,  '_btnTLR_DENOMINATION_BTN'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_DENOMINATION_BTN'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
--END 
--GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '40' AND  FieldIDInPage   = '_cboAmountCurrType'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '40'  ,  'Teller'  ,  '_cboAmountCurrType'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'COR_OTHER_DETAIL.TLR_CURRENCY'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1151' AND  FieldIDInPage   = '_cboSorceOfFunds'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1151'  ,  'Teller'  ,  '_cboSorceOfFunds'  ,   -1   ,   -1   ,   -1   ,   0   ,   1   ,  'TLR_SOURCE_OF_FUNDS'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek' ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '145' AND  FieldIDInPage   = '_cboTLR_DEPOSITOR_ID_NAME'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )
 Values( 807   ,  '145'  ,  'Teller'  ,  '_cboTLR_DEPOSITOR_ID_NAME'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  'TLR_IDTYPE'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1000043' AND  FieldIDInPage   = '_chkCOR_MAIL_ADVICE'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '1000043'  ,  'Teller'  ,  '_chkCOR_MAIL_ADVICE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'COR_MAIL_ADVICE'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_chkTLR_PRINT_CTS_NOW'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  '_chkTLR_PRINT_CTS_NOW'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '9' AND  FieldIDInPage   = '_curAmount'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '9'  ,  'Teller'  ,  '_curAmount'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_AMOUNT'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
 
GO
IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_curBalance'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  '_curBalance'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_DEPOSITOR_DETAL'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '345' AND  FieldIDInPage   = '_curCreditAmt'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '345'  ,  'Teller'  ,  '_curCreditAmt'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_CREDITAMOUNT'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = '_curFixedDeposit'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '0'  ,  'Teller'  ,  '_curFixedDeposit'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'Depositor Details'  ,  'TLR_DEPOSITOR_DETAL'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1752' AND  FieldIDInPage   = '_curNetCreditAmount'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1752'  ,  'Teller'  ,  '_curNetCreditAmount'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'NetCreditAmount'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek' ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1000041' AND  FieldIDInPage   = '_curTotalCharges'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )
   Values( 807   ,  '1000041'  ,  'Teller'  ,  '_curTotalCharges'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,  'TLR_TOTAL_CHARGES'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '232' AND  FieldIDInPage   = '_nrvDr_Narrative'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '232'  ,  'Teller'  ,  '_nrvDr_Narrative'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_NARRAIVE'  ,  'Cash Deposit'  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,   319   ,   321 )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1000040' AND  FieldIDInPage   = '_numBuyExchangeRate'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '1000040'  ,  'Teller'  ,  '_numBuyExchangeRate'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'COR_BUY_EXCHANGE_RATE'  ,  ''  ,    NULL    , 'ITSOFT\aya.tarek'  ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1000039' AND  FieldIDInPage   = '_numSellExchangeRate'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1000039'  ,  'Teller'  ,  '_numSellExchangeRate'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'COR_SELL_EXCHANGE_RATE'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek' ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1318' AND  FieldIDInPage   = '_optPrintOption'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1318'  ,  'Teller'  ,  '_optPrintOption'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_PRINT_OPTION_HAYRAT_DP'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '186' AND  FieldIDInPage   = '_txtGTD_DEAL_TICKET'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '186'  ,  'Teller'  ,  '_txtGTD_DEAL_TICKET'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_GTD_TKT'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1154' AND  FieldIDInPage   = '_txtSorceOfFunds_Other'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1154'  ,  'Teller'  ,  '_txtSorceOfFunds_Other'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_SOURCE_OF_FUNDS'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '146' AND  FieldIDInPage   = '_txtTLR_DEPOSITER_ID_NUMBER'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '146'  ,  'Teller'  ,  '_txtTLR_DEPOSITER_ID_NUMBER'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_ID_NUM'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '194' AND  FieldIDInPage   = '_txtTLR_DEPOSITER_NAME'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '194'  ,  'Teller'  ,  '_txtTLR_DEPOSITER_NAME'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_DEPOSITER_NAME'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1      ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = '_txtTLR_NARRATIVE'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '0'  ,  'Teller'  ,  '_txtTLR_NARRATIVE'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_NARRAIVE'  ,  'fsds'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '147' AND  FieldIDInPage   = '_txtTLR_NARRATIVE_FUNDS'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '147'  ,  'Teller'  ,  '_txtTLR_NARRATIVE_FUNDS'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1293' AND  FieldIDInPage   = '_txtTLR_RcptNo'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1293'  ,  'Teller'  ,  '_txtTLR_RcptNo'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  'TLR_RECEIPT_NUMBER'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'exchangeRate1'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'exchangeRate1'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'COR_OTHER_DETAIL'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1974' AND  FieldIDInPage   = '_cboTLR_Nationality'  ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1974'  ,  'Teller'  ,  '_cboTLR_Nationality'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_SO_NATIONALITY'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
 GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '433' AND  FieldIDInPage   = '_txtTLR_DEPOSITOR_PHONE_NUM'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '433'  ,  'Teller'  ,  '_txtTLR_DEPOSITOR_PHONE_NUM'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_CCND_PHONE_NUMBER'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'idControl1'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'idControl1'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  'TLR_BENEFICIARY_ID_TYPE'  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_cboBnfcryIdType'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values(807   ,    NULL    ,  'Teller'  ,  '_cboBnfcryIdType'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  'TLR_BENEFICIARY_ID_TYPE'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_txtBnfcryNumber'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )
   Values( 807   ,    NULL    ,  'Teller'  ,  '_txtBnfcryNumber'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  'TLR_BENEFICIARY_ID_NUMBER'  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1933' AND  FieldIDInPage   = '-1'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1933'  ,  'Teller'  ,  '-1'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   0   ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '149' AND  FieldIDInPage   = 'cbo_Relationship'    ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '149'  ,  'Teller'  ,  'cbo_Relationship'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_RELATION'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '1376' AND  FieldIDInPage   = 'chk_HimSelf'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '1376'  ,  'Teller'  ,  'chk_HimSelf'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  'TLR_HimSelf'  ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = 'SmartCardControl'   ) 
BEGIN 
 INSERT INTO RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '-1'  ,  'Teller'  ,  'SmartCardControl'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,    NULL    ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek' ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = 'CivilIDScanControl'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '0'  ,  'Teller'  ,  'CivilIDScanControl'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = 'scrControl1'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '0'  ,  'Teller'  ,  'scrControl1'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = 'idScannerControl1'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '0'  ,  'Teller'  ,  'idScannerControl1'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '807' AND  FieldIDInPage   = '_txtGTDDealTicket'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '807'  ,  'Teller'  ,  '_txtGTDDealTicket'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_GTD_TKT'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '0' AND  FieldIDInPage   = '_chargeControl'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '0'  ,  'Teller'  ,  '_chargeControl'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,    NULL    ,    NULL    ,    NULL    , 'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'scrControl1'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'scrControl1'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,    NULL    ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'idScannerControl1'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'idScannerControl1'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,    NULL    ,  ''  ,    NULL    ,  'ITSOFT\aya.tarek' ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'accDepositer'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'accDepositer'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'btnDedupeChecking'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'btnDedupeChecking'  ,   -1   ,   -1   ,   -1   ,   0   ,   1   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek'  ,   1    ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO



IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'btnIdReader'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'btnIdReader'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,   312   ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'cboIDType'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'cboIDType'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = 'txtIdNumber'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '-1'  ,  'Teller'  ,  'txtIdNumber'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,    NULL    ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1     ,    NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO



IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_tlrDateOfBirth'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  '_tlrDateOfBirth'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO



IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_cboTLR_CountryOfIssuance'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  '_cboTLR_CountryOfIssuance'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      308   ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_tlrExpiryDate'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  '_tlrExpiryDate'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,    309   ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = '_cbo_TLR_Nationality'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '-1'  ,  'Teller'  ,  '_cbo_TLR_Nationality'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,    NULL    ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'SCRIdReader' ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'SCRIdReader'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'DateOfBirth'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'DateOfBirth'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'txtPhoneNumber'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'txtPhoneNumber'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek'  ,   1   ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'cboCountryOfIssuance'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'cboCountryOfIssuance'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,      313   ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'ExpiryDate'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'ExpiryDate'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1     ,   314   ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'cboNationality'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  'cboNationality'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek'  ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'txtDepositerName'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,    NULL    ,  'Teller'  ,  'txtDepositerName'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek'  ,   1   ,      NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO



IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = 'txtIdNumber'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  values( 807   ,    NULL    ,  'Teller'  ,  'txtIdNumber'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  ''  ,  ''  ,  ''  , 'ITSOFT\aya.tarek' ,   1   ,     NULL    ,    NULL    ,    NULL    ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = 'DepositPurpose'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '-1'  ,  'Teller'  ,  'DepositPurpose'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,    NULL    ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1  ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   IS NULL AND  FieldIDInPage   = '_lblTLR_TranPurpose'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,    NULL    ,  'Teller'  ,  '_lblTLR_TranPurpose'  ,   -1   ,   -1   ,   -1   ,   1   ,   0   ,  ''  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '7' AND  FieldIDInPage   = 'al_CreditAcct'   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  ) 
  Values( 807   ,  '7'  ,  'Teller'  ,  'al_CreditAcct'  ,   -1   ,   -1   ,   -1   ,   0   ,   0   ,  'TLR_ACCOUNT_DETAIL'  ,  ''  ,  ''  ,  'ITSOFT\aya.tarek' ,   1   ,    NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO                                      

IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   = '-1' AND  FieldIDInPage   = '_lblSorceOfFunds'    ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  , IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  '-1'  ,  'Teller'  ,  '_lblSorceOfFunds'  ,   -1   ,   -1   ,   -1   ,   1   ,   1   ,  'CTRBlank'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- Card Number
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND  FieldID   is null AND  FieldIDInPage   = '_Card_Number'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  Null  ,  'Teller'  ,  '_Card_Number'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_CARDNUMBER'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- CardHoldername
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND   FieldIDInPage   = '_Card_Holder_Name'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  Null  ,  'Teller'  ,  '_Card_Holder_Name'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_CARD_HOLDER_NAME'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO

-- picklist of card type
IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND   FieldIDInPage   = '_Card_Type'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  Null  ,  'Teller'  ,  '_Card_Type'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_CARD_TYPE'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO
 
 -- pos ref NO
 IF NOT EXISTS ( Select * From  dbo.RulesTranField_ex Where  TranID   = 807  AND   FieldIDInPage   = '_Pos_Ref_No'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranField_ex ( TranID  , FieldID  , Module  , FieldIDInPage  , FirstPage  , LastPage  , ControlPage  , Optional  , IsReadOnly  , TranFieldDescr  , DefaultValue  , FieldType  , Updator  , IsVisible  ,  IsReadOnlyConditionId  , IsVisibleConditionId  , IsOptionalConditionId  , fExpressionID  )  
 Values( 807   ,  Null  ,  'Teller'  ,  '_Pos_Ref_No'  ,   -1   ,   -1   ,   -1   ,   1   ,   0  ,  'TLR_POS_REFERENCE_NUMBER'  ,    NULL    ,    NULL    ,  'ITSOFT\aya.tarek'  ,   1   ,       NULL    ,    NULL    ,    NULL    ,    NULL ) 
END 
GO



---------------------------------
-- RulesTranErrorDescriptions ---
---------------------------------

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'ACCOUNT_NUMBER_REQUIRED'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'ACCOUNT_NUMBER_REQUIRED'  ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'COR_DENOMINATION_NOT_SET'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'COR_DENOMINATION_NOT_SET'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'COR_HAYRAT_NUMBER_ERROR'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'COR_HAYRAT_NUMBER_ERROR'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'CUSID_SCAN'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'CUSID_SCAN'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'EXCEED_CSH_DEP_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'EXCEED_CSH_DEP_LIMIT'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'IB_NOTNEGATIVE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'IB_NOTNEGATIVE'  , 'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'OPERATOR_ACCOUNT_EXPIRED'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'OPERATOR_ACCOUNT_EXPIRED'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'REJECT_OVER_CSH_DEP'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'REJECT_OVER_CSH_DEP'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_BIRTHDATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_BIRTHDATE'  , 'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_DIFF_DATE_FORMAT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_DIFF_DATE_FORMAT'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_EXPIRATIONDATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_EXPIRATIONDATE'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_FX_RECORD_LOCKED'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_FX_RECORD_LOCKED'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_INSUFFICIENT_DEPOSIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_INSUFFICIENT_DEPOSIT'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_OPERATORLOCKED_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_OPERATORLOCKED_ERRORDESC'  ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SEC_LOGIN_PWCH_ERRORMSG'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_SEC_LOGIN_PWCH_ERRORMSG'  ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGCHPW_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGCHPW_ERRORDESC'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGEMPTYMAIL_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGEMPTYMAIL_ERRORDESC'  , 'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGPW_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGPW_ERRORDESC'  , 'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGPWCH_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGPWCH_ERRORDESC'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TLR_SECLOGPWRESET_ERRORDESC'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_SECLOGPWRESET_ERRORDESC'  ,  'ITSOFT\aya.tarek' )
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranErrorDescriptions Where  TranName   = 'PointOfSaleDeposit' AND  Error_Name   = 'TRAN_ACCEPT_UNFUND'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranErrorDescriptions ( TranName  , Error_Name  , Updator  )  
 Values( 'PointOfSaleDeposit'  ,  'TRAN_ACCEPT_UNFUND'  ,  'ITSOFT\aya.tarek')
END 
GO

---------------------------------
-- RulesTranFldParam ------------
---------------------------------

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = '' AND  Param   = 'EnableScanPrint'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  ''  ,  'EnableScanPrint'  ,  '1'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = '_alCreditAccount' AND  Param   = 'SigCap'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  '_alCreditAccount'  ,  'SigCap'  ,  '_curAmount'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = '_chargeControl' AND  Param   = 'Charges'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  '_chargeControl'  ,  'Charges'  ,  'true'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'AvailableBalance'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'AvailableBalance'  ,  'TRUE'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'BlackListed'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'BlackListed'  ,  '0'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ProcessType'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ProcessType'  ,  'C'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ShowCustomerDetail'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ShowCustomerDetail'  ,  '1'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ValueDateAction'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )
   Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ValueDateAction'  ,  'N'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ValueDateBackDays'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ValueDateBackDays'  ,  '0'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ValueDateEnabled'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ValueDateEnabled'  ,  '0'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account' AND  Param   = 'ValueDateFutureDays'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )
  Values( 'PointOfSaleDeposit'  ,  'Account'  ,  'ValueDateFutureDays'  ,  '0'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO
IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Account_Balance' AND  Param   = 'Branch'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Account_Balance'  ,  'Branch'  ,  'E'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'AccountCurrency' AND  Param   = 'SpecialForeignCurrency'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  values( 'PointOfSaleDeposit'  ,  'AccountCurrency'  ,  'SpecialForeignCurrency'  ,  ''  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'accountto' AND  Param   = 'CheckTDAccount'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'accountto'  ,  'CheckTDAccount'  ,  '1'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Amount' AND  Param   = 'IsCashIn'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'Amount'  ,  'IsCashIn'  ,  '1'  ,  'GFSDOMAIN\mohgaber'  ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'Amount' AND  Param   = 'UseTCR'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'Amount'  ,  'UseTCR'  ,  '0'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'AmountCurrType' AND  Param   = 'CurrencyCategoryID'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'AmountCurrType'  ,  'CurrencyCategoryID'  ,  '2'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'ChargesControl' AND  Param   = 'ChargeDefaultAcc'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'ChargesControl'  ,  'ChargeDefaultAcc'  ,  'DP'  ,  'ITSOFT\SQLADMIN'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'CustomerID' AND  Param   = 'DisplayScanningPopup'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'CustomerID'  ,  'DisplayScanningPopup'  ,  '0'  ,  'ITSOFT\aya.tarek'  ,  'bit'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'CustomerID' AND  Param   = 'ScanningCustomerID'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'CustomerID'  ,  'ScanningCustomerID'  ,  '0'  ,  'ITSOFT\aya.tarek'  ,  'bit'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'CustomerType' AND  Param   = 'QuestCategoryID'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'CustomerType'  ,  'QuestCategoryID'  ,  '1'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DisplayReport' AND  Param   = 'DisplayReport'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'DisplayReport'  ,  'DisplayReport'  ,  'true'  ,  'ITSOFT\aya.tarek'  ,  'bit'  ,  '' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'FcyToFcy'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'FcyToFcy'  ,  'None'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'FcyToFcySame'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'FcyToFcySame'  ,  'DrawerTellerFCDU,VAULTFCDU'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'FcyToLcy'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'FcyToLcy'  ,  'DrawerTellerRBU,VAULTRBU'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'LcyToFcy'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'LcyToFcy'  ,  'None'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'DrawerType' AND  Param   = 'LcyToLcy'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'DrawerType'  ,  'LcyToLcy'  ,  'DrawerTellerRBU,VAULTRBU'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'EffectiveDateCharges' AND  Param   = 'EffectiveDateCharges'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'EffectiveDateCharges'  ,  'EffectiveDateCharges'  ,  '0'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'GLNumber' AND  Param   = 'ChargeAccountCategory'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'GLNumber'  ,  'ChargeAccountCategory'  ,  'ALL TYPES'  ,  'ITSOFT\aya.tarek' ,  'nvarchar'  ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'GLNumber' AND  Param   = 'ChargeDefaultAcct'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )
   Values( 'PointOfSaleDeposit'  ,  'GLNumber'  ,  'ChargeDefaultAcct'  ,  'GL'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'IDType' AND  Param   = 'AllowedIDType1Entries'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'IDType'  ,  'AllowedIDType1Entries'  ,  ''  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'IDValidationLimit' AND  Param   = 'IDValidationLimit'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'IDValidationLimit'  ,  'IDValidationLimit'  ,  '-1'  ,'ITSOFT\aya.tarek'  ,  'nvarchar'  ,  '' )
END 
GO


IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'PopupIDType' AND  Param   = 'AllowedIDType1Entries'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  )  
 Values( 'PointOfSaleDeposit'  ,  'PopupIDType'  ,  'AllowedIDType1Entries'  ,  ''  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL)  
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'TCR_CurrencyCategory' AND  Param   = 'TCR_CurrencyCategory'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'TCR_CurrencyCategory'  ,  'TCR_CurrencyCategory'  ,  ''  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL ) 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranFldParam Where  TranName   = 'PointOfSaleDeposit' AND  FieldName   = 'TLR_TOTAL_CHARGES_FORIGN' AND  Param   = 'IsCashIn'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranFldParam ( TranName  , FieldName  , Param  , Value  , Updator  , DataType  , Description  ) 
  Values( 'PointOfSaleDeposit'  ,  'TLR_TOTAL_CHARGES_FORIGN'  ,  'IsCashIn'  ,  '1'  ,  'ITSOFT\aya.tarek'  ,  'nvarchar'  ,    NULL  )
END 
GO


---------------------------------
-- RulesTranDescriptors ---------
---------------------------------
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BIRTHDATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'BIRTHDATE'  , 'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BUTTON_CANCEL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'BUTTON_CANCEL'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BUTTON_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'BUTTON_NO'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BUTTON_OK'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'BUTTON_OK'  , 'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'BUTTON_YES'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'BUTTON_YES'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_DETAIL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'COR_DETAIL'  ,  'ITSOFT\aya.tarek'  , 'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_MAIL_ADVICE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'COR_MAIL_ADVICE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_OK'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'COR_OK'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_OTHER_DETAIL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'COR_OTHER_DETAIL'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_PRINT_OPTION'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'COR_PRINT_OPTION'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_SELL_RATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'COR_SELL_RATE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'COR_SUMMARY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'COR_SUMMARY'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'IBAN'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'IBAN'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'ICSR_SBS_RIM_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'ICSR_SBS_RIM_NUMBER'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'IDINFO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'IDINFO'  ,  'ITSOFT\aya.tarek' ,  'ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'ILON_MPRSS_Charge_BT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'ILON_MPRSS_Charge_BT'  ,  'ITSOFT\aya.tarek'  ,  'ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'invalid_business_date'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'invalid_business_date'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'MOBILE_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'MOBILE_NO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'NotAllowedPrintCD'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'NotAllowedPrintCD'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACC_COMM'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ACC_COMM'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNT_ACTION_SUP'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ACCOUNT_ACTION_SUP'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNT_DETAIL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ACCOUNT_DETAIL'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Account_Question'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_Account_Question'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNT_STATUS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ACCOUNT_STATUS'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNT_TYPE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ACCOUNT_TYPE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ACCOUNTNUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ACCOUNTNUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_AMOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_AMOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BANK_CODE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BANK_CODE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BANK_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_BANK_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BENEFICIARY_ID_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BENEFICIARY_ID_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BENEFICIARY_ID_TYPE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BENEFICIARY_ID_TYPE'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BRANCH_CODE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BRANCH_CODE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_BUY_RATE_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_BUY_RATE_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CASH_DEPOSIT_DAILY_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CASH_DEPOSIT_DAILY_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CCND_PHONE_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CCND_PHONE_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CERTIFICATE_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CERTIFICATE_NO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_AMOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CHEQUE_AMOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_CURRENCY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CHEQUE_CURRENCY'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_DATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CHEQUE_DATE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CHEQUE_NO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_RETURN_REASON_AUTO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CHEQUE_RETURN_REASON_AUTO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CHEQUE_SEQUENCE_IN_FILE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CHEQUE_SEQUENCE_IN_FILE'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CONTACT_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CONTACT_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CREDITAMOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_CREDITAMOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CURRENCY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CURRENCY'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CUSTOMER_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CUSTOMER_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Dedupe_Checking'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_Dedupe_Checking'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DENOMINATION_BTN'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_DENOMINATION_BTN'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DEPOSITER_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_DEPOSITER_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DEPOSITOR_DETAL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_DEPOSITOR_DETAL'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DOWN_PAYMENT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_DOWN_PAYMENT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_DRAWER_AC_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_DRAWER_AC_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_EARLY_SETTLEMENT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_EARLY_SETTLEMENT'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_EFFECTIVEDATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_EFFECTIVEDATE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_EXCEED_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_EXCEED_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_EXPIRY_DATE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )
 Values( 807   ,  'TLR_EXPIRY_DATE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_FCY_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_FCY_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_FEES_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_FEES_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_FRACTION_NOT_ALLOWED'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_FRACTION_NOT_ALLOWED'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_FTD_UNFUNDED_ONLY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_FTD_UNFUNDED_ONLY'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_GTD_TKT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_GTD_TKT'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_GTDLIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_GTDLIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_HimSelf'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_HimSelf'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ID_Card_Reader'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ID_Card_Reader'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
 
GO
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ID_NUM'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ID_NUM'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_IDTYPE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_IDTYPE'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_INSUFFICIENT_DEPOSIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_INSUFFICIENT_DEPOSIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_INVALID_Busniess_Date'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_INVALID_Busniess_Date'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_IR_FileRefNo'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_IR_FileRefNo'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ISSUE_COUNTRY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_ISSUE_COUNTRY'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_NARRAIVE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_NARRAIVE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_NARRATIVE_SOURCE_OF_FUND'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_NARRATIVE_SOURCE_OF_FUND'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Net_Credit_Amount'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )
   Values( 807   ,  'TLR_Net_Credit_Amount'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_NO'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_NO'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_NSF_CHQ_FEE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_NSF_CHQ_FEE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_OTHER_SOURCE_OF_FUNDS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_OTHER_SOURCE_OF_FUNDS'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PAST_DUE_SETTLEMENT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_PAST_DUE_SETTLEMENT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Payee_Information'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_Payee_Information'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PAYEE_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_PAYEE_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PHONE_NUM'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_PHONE_NUM'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_POPUP_IDINFORMATION'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_POPUP_IDINFORMATION'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_POSTING_ACCOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_POSTING_ACCOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PRINT_CTS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_PRINT_CTS'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_PRINT_CTS_NOW'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_PRINT_CTS_NOW'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_Read_From_Card_Reader'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_Read_From_Card_Reader'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_RECEIPT_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_RECEIPT_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_REGULAR_SETTLEMENT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_REGULAR_SETTLEMENT'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_RELATION'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_RELATION'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_RETURN_COUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_RETURN_COUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SELL_RATE_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_SELL_RATE_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SO_BRANCH_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_SO_BRANCH_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SO_CHARGES'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_SO_CHARGES'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SO_NATIONALITY'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_SO_NATIONALITY'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_SOURCE_OF_FUNDS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_SOURCE_OF_FUNDS'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_TOTAL_CHARGES'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_TOTAL_CHARGES'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_TRANSACTION_PURPOSE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_TRANSACTION_PURPOSE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_TREASUREY_LIMIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_TREASUREY_LIMIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_UNFUNDED_FACE_AMOUNT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )
   Values( 807   ,  'TLR_UNFUNDED_FACE_AMOUNT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_UPDATED_ACCUM_AMT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_UPDATED_ACCUM_AMT'  , 'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_VALIDATE_EFF_DAYS'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_VALIDATE_EFF_DAYS'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek') 
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_YES'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  ) 
  Values( 807   ,  'TLR_YES'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_ZERO_CHARGES_FIXED_DEPOSIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_ZERO_CHARGES_FIXED_DEPOSIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

--Card Number 
IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CARDNUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CARDNUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

-- Card Holder Name 
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CARD_HOLDER_NAME'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CARD_HOLDER_NAME'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

--Card Type
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_CARD_TYPE'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_CARD_TYPE'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

--Pos ref_No
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_POS_REFERENCE_NUMBER'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_POS_REFERENCE_NUMBER'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO

-- trans name 
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'TLR_POINT_OF_SALE_DEPOSIT'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'TLR_POINT_OF_SALE_DEPOSIT'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO



--card details 
 IF NOT EXISTS ( Select * From  dbo.RulesTranDescriptors Where  TranID   = 807  AND  DSC_Name   = 'CRD_CARD_DETAIL'  ) 
BEGIN 
 INSERT INTO dbo.RulesTranDescriptors ( TranID  , DSC_Name  , Updator  , Creator  )  
 Values( 807   ,  'CRD_CARD_DETAIL'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO


---------------------------
-----------PickLists-------
exec p_next_id 'PickLists' ,1


--cardtype
IF NOT EXISTS ( Select * From  dbo.PickLists Where  AppID   = 1  AND  PickListID   =  559  AND  PickList_Name   = 'CardTypes'  ) 
BEGIN 
 INSERT INTO dbo.PickLists ( AppID  , PickListID  , PickList_Name  , Updator  , Creator  )  
 Values( 1   ,   559   ,  'CardTypes'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek')
END 
GO
 
------------------------------------------------
 
 
 GO
 
--PickList_Entries table :
--entries of Card Types

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 559  AND  DisplayOrder   =  0   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value  , Updator  , Creator  , CustomValues  )  
 Values( 559   ,   1   ,   0  ,  'TLR_NAPS'  ,  'NAPS'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek' ,  '<SubValues><mask></mask></SubValues>' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 559  AND  DisplayOrder   =  1   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value  , Updator  , Creator  , CustomValues  ) 
  Values( 559   ,   1   ,  1  ,  'TLR_CREDIT_CARD'  ,  'Credit card'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek'  ,  '<SubValues><mask>999999999</mask></SubValues>' )
END 
GO

IF NOT EXISTS ( Select * From  dbo.PickList_Entries Where  PickListID   = 559  AND  DisplayOrder   =  2   ) 
BEGIN 
 INSERT INTO dbo.PickList_Entries ( PickListID  , AppID  , DisplayOrder  , DescriptorName  , Value  , Updator  , Creator  , CustomValues  )  
 Values( 559   ,   1   ,   2  ,  'TLR_PREMIUN_CARD'  ,  'Premium card'  ,  'ITSOFT\aya.tarek','ITSOFT\aya.tarek'  ,  '<SubValues><mask>99999999999999999999</mask></SubValues>' )
END 
GO

---------------------------
-----------Totals setup-------
---------------------------

IF NOT EXISTS ( Select * From  RulesTotalsType Where  TotallingName   = 'PointOfSaleDeposit'  ) 
BEGIN 
 INSERT INTO RulesTotalsType ( TotallingName ,TotalsID,Developer,RowStatus,AppID )  
 Values( 'PointOfSaleDeposit' ,269, 'ITSOFT\aya.tarek',1,1)
END 
GO

IF EXISTS ( Select * From  RulesTranName Where  TransactionName  = 'PointOfSaleDeposit'  ) 
BEGIN 
 update RulesTranName set TotalsType ='PointOfSaleDeposit' Where  TransactionName  = 'PointOfSaleDeposit'
END 
GO



IF Not EXISTS ( Select * From  RulesTotals Where  TotalsID = 269) 
BEGIN 
 INSERT INTO RulesTotals ( TotalsID ,Sequence,AppID ,TranField,CurrencyFieldID,Bucket,BumpBy)  
 Values( 269, 1, 1,1129,1921,'Cash In',1)
END 
GO


------------------------------------------------------------------------------------------
-----  Developer     : Sara Badwy -----------------------------------------------------
-----  Creation Date : 25-Feb-2020  --------------------------------------------------------------
-----  Purpose       : INC000000260572 - Ethix Branch - G12 - Freezing------------ Defect GFSX13894 --------
------------------------------------------------------------------------------------------------
PRINT 'Start Script for Defect# GFSX13894'
GO
-------------------------------------------------------------------
---------------------------- SQLstrings ------------------------
-------------------------------------------------------------------
If  Exists(Select * From SQLstrings Where CacheGroup IS NOT NULL and AccessName ='GetSideMenuXML')
Begin
update SQLstrings set CacheGroup=NULL where AccessName ='GetSideMenuXML'
End
go
PRINT 'End Script for Defect# GFSX13894'
go


Print 'Begin:INC000000272180,Out clearing chq settle by file accepted but some chueqs is filed status 15,Sara Badwy'

------New Param -----------
  declare @ID int
select @ID = MAX(ParamID)+1 from RulesParam 

IF NOT EXISTS(SELECT * FROM RulesParam WHERE  ParamName = 'IncludeSettelmentFailed')
BEGIN
INSERT INTO RulesParam (ParamID, ParamName , Description , Parm_DSC , isGeneral , isCustomized , isDBCheck , DB_procName , ValuesTypes , DB_procValuesName )  
SELECT @ID, 'IncludeSettelmentFailed' , 'To Enable Search to get records with status [SettelmentFailed] ID=15 ' , NULL , 0 , 1 , 0 , '' , 'Static' , '' 
END
GO
---RulesParamValue
declare @ID int
select @ID =  ParamID from RulesParam where ParamName = 'IncludeSettelmentFailed'
If Not Exists(Select * From RulesParamValue Where ParamID = @ID and ParamValue = 'false')
Begin
INSERT INTO RulesParamValue (ParamID , ParamValue , UPdator )
SELECT @ID, 'false' , 'ITSOFT\Sara.Badwy'
END
If Not Exists(Select * From RulesParamValue Where ParamID = @ID and ParamValue = 'true')
Begin
INSERT INTO RulesParamValue (ParamID , ParamValue , UPdator )
SELECT @ID, 'true' , 'ITSOFT\Sara.Badwy'
END
GO
---RulesTranFldParam
If Not Exists(Select * From RulesTranFldParam Where TranName = 'OutwardClChequeSettlement' And FieldName = 'IncludeSettelmentFailed' And Param = 'IncludeSettelmentFailed')
Begin
 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,DataType,Description)
 Values ('OutwardClChequeSettlement','IncludeSettelmentFailed','IncludeSettelmentFailed','false','nvarchar',NULL)
End
go
Print 'End:INC000000272180,Out clearing chq settle by file accepted but some chueqs is filed status 15,Sara Badwy'
GO
print 'INC000000266035 : Issue in Field 70 , Sara Badwy : Start '
---------------------------------------------------------------------- RulesTranField Start --------------------------------------------------------------------------
--TLR_DRAWERS_NAME
IF NOT EXISTS ( Select * From  dbo.RulesTranField Where  TranID   = 354  AND  FieldID   =  1652   ) 
BEGIN 
 INSERT INTO dbo.RulesTranField ( TranID  , FieldID  , Optional  , ToHost  , FromHost  , DSC_Pattern  , Developer  , isDupable  , MaxArray  , Notes  , Updator  , IsReadOnly  , jTarget  , BindValue  , isReadOnlyImaging  , FieldAlias  , ShowInDWH  , IndexInDWH  )  
 SELECT 354   ,   1652   ,   1   ,   0   ,   0   ,    NULL    ,  'ITSOFT\sara.badwy'  ,   1   ,    NULL    ,  ''  ,  'ITSOFT\sara.badwy'  ,   0   ,    NULL    ,   0   ,   0   ,    NULL    ,   1   ,   -1 
END  
GO
---------------------------------------------------------------------- RulesTranField End --------------------------------------------------------------------------
print 'INC000000266035 : Issue in Field 70 , Sara Badwy : End '
GO
--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 DML Script'
GO

--------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal --
--------------------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105607)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105607,'TLR_NOMAPPINGFORNATINAML',0,'Labels','There are no mapping for the selected nationality in AML System \r Are you sure you want to continue?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105607 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105607,1025,N'�� ���� ����� ������� ������� �� ���� ������ ��� ������� \r �� ��� ����� �� ��� ���� �������ɿ','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105608)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105608,'TLR_AML_DWON',0,'Labels','AML web service is down, Are you sure you want to continue?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105608 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105608,1025,N'���� AML ��� ����� ����� � �� ���� �������� �������ɿ','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105609)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105609,'TLR_NOMAPPINGFORCUSTTYPE',0,'Labels','There are no mapping for the selected rim class in AML System \r Are you sure you want to continue?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105609 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105609,1025,N'�� ���� ����� ���� rim ������� �� ���� AML \ r �� ��� ����� �� ��� ���� �������ɿ','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105616)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105616,'AML_STATUS_PENDING',0,'Labels','AML Status is Pending','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105616 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105616,1025,N'���� ������ ��� ������� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

--------------------------
-- RulesTranDescriptors --
--------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_CRS_PEP_CUSTOMER')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (565,'TLR_CRS_PEP_CUSTOMER',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranDescriptors Where TranID = 578 And DSC_Name = 'TLR_CRS_PEP_CUSTOMER')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (578,'TLR_CRS_PEP_CUSTOMER',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',1)
End
GO

---------------------------
-- RulesErrorDescription --
---------------------------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1798)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1798,'AMLDOWN_ABORT_ACTION','Cannot continue the transaction � AML Web Service is down.','Cannot continue the transaction � AML Web Service is down.',4,'ErrDesc.hlp',1,'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1798)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1798,N'�� ���� ������ �������� � ���� AML Web Service �����',N'�� ���� ������ �������� � ���� AML Web Service �����','','ITSOFT\ahmed.orashed')
End
GO

--------------------------------
-- RulesTranErrorDescriptions --
--------------------------------
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('OpenPersonalRim','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenNonPersonalRim' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('OpenNonPersonalRim','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('EditPersonalRim','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditNonPersonalRim' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('EditNonPersonalRim','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'DPAccountOpening' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('DPAccountOpening','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

-----------------------
-- RulesTranField_ex --
-----------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldID IS NULL And FieldIDInPage = '_chkPoliticallyExposed')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,NULL,'Teller','_chkPoliticallyExposed',-1,-1,-1,1,0,'TLR_CRS_PEP_CUSTOMER','',NULL,N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField_ex Where TranID = 578 And FieldID IS NULL And FieldIDInPage = '_chkPoliticallyExposed')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (578,NULL,'Teller','_chkPoliticallyExposed',-1,-1,-1,1,0,'TLR_CRS_PEP_CUSTOMER','',NULL,N'ITSOFT\ahmed.orashed',0,NULL,NULL,NULL,NULL)
End
GO

----------------------------------
-- RulesParam & RulesParamValue --
----------------------------------
DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'AMLDown')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'AMLDown','Which Action will GFS Will take in case AML Service is down',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
		
		IF NOT EXISTS(Select * From RulesParamValue Where ParamID = @paramID And ParamValue = 'SKIP')
			BEGIN
				INSERT INTO RulesParamValue(ParamID,ParamValue,UPdator)
				VALUES (@paramID,N'SKIP',N'ITSOFT\ahmed.orashed')
			END
		IF NOT EXISTS(SELECT * FROM RulesParamValue WHERE ParamID = @paramID And ParamValue = 'ABORT')
			BEGIN 
				INSERT INTO RulesParamValue(ParamID,ParamValue,UPdator)
				VALUES (@paramID,N'ABORT',N'ITSOFT\ahmed.orashed')
			END
END
GO

DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'AMLExpressionName')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'AMLExpressionName','Used for generating reference number for AML Web Service',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
END
GO

-----------------------
-- RulesTranFldParam --
-----------------------
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'OpenPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('OpenPersonalRim','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'OpenPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('OpenPersonalRim','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'OpenNonPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('OpenNonPersonalRim','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'OpenNonPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('OpenNonPersonalRim','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'EditPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('EditPersonalRim','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'EditPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('EditPersonalRim','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'EditNonPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('EditNonPersonalRim','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'EditNonPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('EditNonPersonalRim','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'DPAccountOpening' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('DPAccountOpening','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'DPAccountOpening' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('DPAccountOpening','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

------------------------
-- ExternalWebService --
------------------------
IF NOT EXISTS(SELECT * FROM ExternalWebService WHERE WebServiceName = 'IMCPService')
BEGIN
 INSERT INTO ExternalWebService(WebServiceName,Description,WebServiceIP,MachineName,URL,RowStatus,Updator,Creator,UserName,Password,ApplyWSE,WebServiceMapName,Servicetype)
 VALUES ('IMCPService','MCP Service','10.10.13.201','10.10.13.201','http://g12devsql:9090/IMCPService.svc',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','GFSUSER','GFSPassWord',0,'IMCPService',N'WCF')
End
GO

-------------------------------------------------------------
-- ExternalWebServiceTran & ExternalWebServiceTranParamLst --
-------------------------------------------------------------

-- OpenPersonalRim

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 547)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (547,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','OpenPersonalRim_FCCMRequest.xsd',NULL)
	END
END
GO

-- OpenNonPersonalRim

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 565)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (565,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','OpenNonPersonalRim_FCCMRequest.xsd',NULL)
	END
END
GO

-- EditPersonalRim

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 564)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (564,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','EditPersonalRim_FCCMRequest.xsd',NULL)
	END
END
GO

-- EditNonPersonalRim

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 578)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (578,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','EditNonPersonalRim_FCCMRequest.xsd',NULL)
	END
END
GO

-- DPAccountOpening

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 534)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (534,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','DPAccountOpening_FCCMRequest.xsd',NULL)
	END
END
GO

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequestInquiry' AND TranID = -1)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (-1,'IMCPService','FCCMCaseStatusRequestInquiry',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequestInquiry')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','FCCMInquiry.xsd',NULL)
	END
END
GO

---------------------------------------------
-- RulesExpression & RulesExpressionDetail --
---------------------------------------------
DECLARE @ExpressionId int
SELECT @ExpressionId = MAX(ExpressionId) +1 from RulesExpression
IF NOT EXISTS(SELECT * FROM RulesExpression WHERE ExpressionName = 'AMLReferenceNumber')
BEGIN
 INSERT INTO RulesExpression(ExpressionId,ExpressionName,SerialNumberLength,PaddingCharacter,IsLeftPadded,ExpressionCategroyId)
 VALUES (@ExpressionId,'AMLReferenceNumber',7,'0',1,1)

 DECLARE @Id int
 SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 1)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,1,1,'"CIF_"',1,4,'0',1)
 END

 SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 2)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,2,1,'BusinessDate_YYYYMMDD',1,8,'0',1)
 END
END
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLStrings Where AccessID = 1100059)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100059,'Select_AML_NationalityMapping','p',1,'Globalfs','dbo.Select_AML_NationalityMapping',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select data from AML_NationalityMapping Table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100060)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100060,'Select_AML_CustomerTypeMapping','p',1,'Globalfs','dbo.Select_AML_CustomerTypeMapping',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select data from AML_CustomerTypeMapping Table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100062)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100062,'AMLInfo_InsertAndUpdate','p',0,'Globalfs','dbo.AMLInfo_InsertAndUpdate',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Insert and Update table AML_Info',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100065)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100065,'GetAMLPendingRequests','p',1,'Globalfs','dbo.GetAMLPendingRequests',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Get AML Pending Requests',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

--------------------
-- RulesTranField --
--------------------
If Not Exists(Select * From RulesTranField Where TranID = 534 And FieldID = 1297)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (534,1297,1,0,0,NULL,'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'AMLReferenceID',1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 534 And FieldID = 1154)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (534,1154,1,0,0,NULL,'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'AMLRiskRating',1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 534 And FieldID = 1359)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (534,1359,1,0,0,NULL,'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'AMLStatus',1,-1,NULL,NULL,NULL)
End
GO

---------------------------
-- HostCoreServiceFields --
---------------------------
DECLARE @ServiceID int , @FieldID int
SELECT @ServiceID = ServiceId FROM HostCoreService WHERE ServiceName = 'GetNonPersonalRimInfo'
If Not Exists(Select * From HostCoreServiceFields Where ServiceId = @ServiceID And FieldName = 'PoliticallyExposed')
BEGIN
 Select @FieldID = MAX(ISNULL(FieldId,0)) + 1 From HostCoreServiceFields Where ServiceId = @ServiceID 
 Insert Into HostCoreServiceFields(ServiceId,FieldId,FieldName,DataType,MaxArrayIndex,Optional,DefaultValue,Direction,Developer,Updator)
 Values (@ServiceID,@FieldID,'PoliticallyExposed','nvarchar',0,0,'','O','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

PRINT 'End... Script for CR# GFSY00793 DML Script'
GO
--==================================================================================================================================================================

--==================================================================================================================================================================
------------------------------------------------------------------------------------------
-----  Developer     : Mostafa Helmy -----------------------------------------------------
-----  Creation Date : 27-April-2020---------------------------------------------------
-----  Purpose       : ACM000000018134 - BARWA - AML Integration - CR# GFSY00793
------------------------------------------------------------------------------------------
PRINT 'Start Script for CR# GFSY00781'
GO
---------------------------
-- RulesErrorDescription --
---------------------------

If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1799)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1799,'AMLUnMatchedTran','Can not choose transaction type differs from the current opened transaction','Can not choose transaction type differs from the current opened transaction',4,'ErrDesc.hlp',1,'ITSOFT\mostafa.helmy',1)
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1799)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1799,N'�� ���� ��� ������ ����� ����� �� ��� �������� �������',N'�� ���� ��� ������ ����� ����� �� ��� �������� �������','','ITSOFT\mostafa.helmy')
End
GO
--------------------------------
-- RulesTranErrorDescriptions --
--------------------------------
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'AMLUnMatchedTran')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('OpenPersonalRim','AMLUnMatchedTran','ITSOFT\mostafa.helmy',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenNonPersonalRim' And Error_Name = 'AMLUnMatchedTran')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('OpenNonPersonalRim','AMLUnMatchedTran','ITSOFT\mostafa.helmy',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'DPAccountOpening' And Error_Name = 'AMLUnMatchedTran')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('DPAccountOpening','AMLUnMatchedTran','ITSOFT\mostafa.helmy',1)
End
GO
-------------------------------------------------------------------
----------------------------RulesDescriptor------------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105610)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105610,'TLR_AMLGeneral',0,'PickLists','General','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105611)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105611,'TLR_AMLInstitution',0,'PickLists','Institution','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105612)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105612,'TLR_AMLRetailPrivate',0,'PickLists','Retail Brokerage / Private Client','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105613)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105613,'TLR_AMLRetailBanking',0,'PickLists','Retail Banking','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105614)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105614,'TLR_AMLCorporate',0,'PickLists','Corporate / Wholesale Banking','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105615)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105615,'TLR_AMLEmployee',0,'PickLists','Employee Information','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go
--------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105587)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105587,'TLR_AMLProducts',0,'Labels','Products and Services','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105588)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105588,'TLR_AMLPEP',0,'Labels','PEP','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105589)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105589,'TLR_AMLDP',0,'PickLists','DP','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105590)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105590,'TLR_AMLLN',0,'PickLists','LN','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105593)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105593,'TLR_CS_TranStatus',0,'Labels','Transaction Status','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105594)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105594,'TLR_CS_TranType',0,'Labels','Transaction Type','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105597)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105597,'TLR_CS_Pending',0,'PickLists','Pending','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go


If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105598)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105598,'TLR_CS_Rejected',0,'PickLists','Rejected','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105601)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105601,'TLR_AMLBusinessLine',0,'Labels','Business Line','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105602)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105602,'TLR_AMLEconomicSector',0,'Labels','Economic Sector','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105620)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,LastChanged,RowStatus,EffectiveDate,ExpirationDate,Created,Updator)
 Values (1,1105620,'TLR_AML_All',0,'Labels','All','ITSOFT\mostafa.helmy','Apr 27 2020 11:07AM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 27 2020 11:06AM',N'ITSOFT\mostafa.helmy')
End
go

-------------------------------------------------------------------
----------------------------RulesDescriptorLocal-------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105620 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105620,1025,N'��','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105601 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105601,1025,N'�� �������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105602 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105602,1025,N'������ ���������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105598 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105598,1025,N'�����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105597 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105597,1025,N'��� ��������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105593 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105593,1025,N'���� ��������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105594 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105594,1025,N'��� ��������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105588 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105588,1025,N'����� ����� �������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105587 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105587,1025,N'������ ������','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105589 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105589,1025,N'�����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105590 And LCID = 1025)
Begin
Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
Values (1105590,1025,N'�����','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go

-------------------------------------------------------------------
----------------------------RulesTranDescriptors-------------------
------------------------------------------------------------------- 

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_SO_ADDRESS_LINE_2')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_SO_ADDRESS_LINE_2','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_SO_ADDRESS_LINE_1')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_SO_ADDRESS_LINE_1','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_POSTAL_CODE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_POSTAL_CODE','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_SO_COUNTRY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_SO_COUNTRY','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_PHONE_NUM')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_PHONE_NUM','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_PLACE_OF_BIRTH')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_PLACE_OF_BIRTH','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_LAST_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_LAST_NAME','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_FIRST_NAME')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_FIRST_NAME','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_PERSONAL_CUSTOMER_INFO')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_PERSONAL_CUSTOMER_INFO','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_NON_RESIDENT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_NON_RESIDENT','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_RESIDENT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_RESIDENT','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_RESIDENCY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_RESIDENCY','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_PERSONAL_CUSTOMER_CHECK')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_PERSONAL_CUSTOMER_CHECK','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go


If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_AMLProducts')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_AMLProducts','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_AMLPEP')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_AMLPEP','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_OCCUPATION')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_OCCUPATION','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_DATE_OF_BIRTH')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_DATE_OF_BIRTH','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_SO_NATIONALITY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_SO_NATIONALITY','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_RimClass')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_RimClass','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_SEARCH')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_SEARCH','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_AML_STATUS')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_AML_STATUS','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_AML_RISK_RATING')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_AML_RISK_RATING','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_AML_REF_ID')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_AML_REF_ID','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_CHECK_INFO')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_CHECK_INFO','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_ISSUE_COUNTRY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_ISSUE_COUNTRY','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_SO_EXP_DATE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_SO_EXP_DATE','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'IssueDate')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'IssueDate','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_ID_NUM')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_ID_NUM','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_IDTYPE')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_IDTYPE','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_ID1_INFORMATION')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_ID1_INFORMATION','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_CITY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_CITY','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_NONPERSONAL_CUSTOMER_CHECK')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_NONPERSONAL_CUSTOMER_CHECK','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_NONPERSONAL_CUSTOMER_INFO')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_NONPERSONAL_CUSTOMER_INFO','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_Name1')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_Name1','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_Name2')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_Name2','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_COUNTRY_OF_INCORP')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_COUNTRY_OF_INCORP','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_PHONE_1')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_PHONE_1','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_AMLBusinessLine')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_AMLBusinessLine','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_AMLEconomicSector')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_AMLEconomicSector','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_AMLEconomicSector')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_AMLEconomicSector','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
--------------------------------------------------------
If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_AMLBusinessLine')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_AMLBusinessLine','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_AMLEconomicSector')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_AMLEconomicSector','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_RimClass')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_RimClass','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_AMLPEP')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_AMLPEP','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_AMLProducts')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_AMLProducts','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 565 And DSC_Name = 'TLR_SO_NATIONALITY')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (565,'TLR_SO_NATIONALITY','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go
---------------------------------------

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_CS_TranType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_CS_TranType','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_CS_TranStatus')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_CS_TranStatus','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_RimClass')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_RimClass','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_AMLPEP')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_AMLPEP','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 547 And DSC_Name = 'TLR_AMLProducts')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (547,'TLR_AMLProducts','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_Reference_No')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_Reference_No','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

If Not Exists(Select * From RulesTranDescriptors Where TranID = 534 And DSC_Name = 'TLR_CS_TranType')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,LastChanged,Updator,Creator,Created,RowStatus,EffectiveDate,ExpirationDate)
 Values (534,'TLR_CS_TranType','Jan 29 2019  3:48PM',N'G',N'G','Jan 11 2010  3:48PM',1,'Jan  1 1901 12:00AM','Dec 31 9998 12:00AM')
End
go

-------------------------------------------------------------------
----------------------------picklists-------------------
-------------------------------------------------------------------

If Not Exists(Select * From picklists Where PickListID = 555)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,555,'TLR_AML_Products','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  3:13PM','Apr 12 2020  3:13PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1)
End
go

If Not Exists(Select * From picklists Where PickListID = 556)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,556,'TLR_AML_PEP','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  3:13PM','Apr 12 2020  3:13PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1)
End
go

If Not Exists(Select * From picklists Where PickListID = 557)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,557,'TLR_AMLStatus','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  3:13PM','Apr 12 2020  3:13PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1)
End
go

If Not Exists(Select * From picklists Where PickListID = 558)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,558,'TLR_AMLTranType','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  3:13PM','Apr 12 2020  3:13PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1)
End
go

If Not Exists(Select * From picklists Where PickListID = 560)
Begin
 Insert Into picklists(AppID,PickListID,PickList_Name,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus)
 Values (1,560,'TLR_AMLBusinessLine','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  3:13PM','Apr 12 2020  3:13PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1)
End
go
-------------------------------------------------------------------
----------------------------picklists_entries----------------------
-------------------------------------------------------------------
If Not Exists(Select * From picklist_entries Where PickListID = 556 And DisplayOrder = 1)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (556,1,1,'TLR_PL_1200004_0','1','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
If Not Exists(Select * From picklist_entries Where PickListID = 556 And DisplayOrder = 2)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (556,1,2,'TLR_PL_1200004_1','0','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From picklist_entries Where PickListID = 555 And DisplayOrder = 1)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (555,1,1,'TLR_AMLDP','DP','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
If Not Exists(Select * From picklist_entries Where PickListID = 555 And DisplayOrder = 2)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (555,1,2,'TLR_AMLLN','LN','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From picklist_entries Where PickListID = 557 And DisplayOrder = 1)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (557,1,1,'TLR_CS_Rejected','Rejected','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
If Not Exists(Select * From picklist_entries Where PickListID = 557 And DisplayOrder = 2)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (557,1,2,'TLR_CS_Pending','Pending','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
-----------

If Not Exists(Select * From picklist_entries Where PickListID = 558 And DisplayOrder = 0)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (558,1,0,'TLR_AML_All','All','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
If Not Exists(Select * From picklist_entries Where PickListID = 558 And DisplayOrder = 1)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (558,1,1,'TLR_OP_PERSONAL_RIM','OpenPersonalRim','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
If Not Exists(Select * From picklist_entries Where PickListID = 558 And DisplayOrder = 2)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (558,1,2,'TLR_OP_NONPERSONAL_RIM','OpenNonPersonalRim','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From picklist_entries Where PickListID = 558 And DisplayOrder = 3)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (558,1,3,'TLR_EDIT_PERSONAL_RIM','EditPersonalRim','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From picklist_entries Where PickListID = 558 And DisplayOrder = 4)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (558,1,4,'TLR_EDIT_NONPERSONAL_RIM','EditNonPersonalRim','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From picklist_entries Where PickListID = 558 And DisplayOrder = 5)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (558,1,5,'TLR_ACCOUNT_OPENING','DPAccountOpening','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
------------

If Not Exists(Select * From picklist_entries Where PickListID = 560 And DisplayOrder = 0)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (560,1,0,'TLR_AMLGeneral','a','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From picklist_entries Where PickListID = 560 And DisplayOrder = 1)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (560,1,1,'TLR_AMLInstitution','b','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From picklist_entries Where PickListID = 560 And DisplayOrder = 2)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (560,1,2,'TLR_AMLRetailPrivate','c','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From picklist_entries Where PickListID = 560 And DisplayOrder = 3)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (560,1,3,'TLR_AMLRetailBanking','d','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go

If Not Exists(Select * From picklist_entries Where PickListID = 560 And DisplayOrder = 4)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (560,1,4,'TLR_AMLCorporate','e','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go


If Not Exists(Select * From picklist_entries Where PickListID = 560 And DisplayOrder = 5)
Begin
 Insert Into picklist_entries(PickListID,AppID,DisplayOrder,DescriptorName,Value,EffectiveDate,ExpirationDate,LastChanged,Created,Updator,Creator,RowStatus,CustomValues)
 Values (560,1,5,'TLR_AMLEmployee','f','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM','Apr 12 2020  2:41PM','Apr 12 2020  2:41PM',N'ITSOFT\mostafa.helmy',N'ITSOFT\mostafa.helmy',1,NULL)
End
go
-------------------------------------------------------------------------------------------
------------------------------------RulesTranField_ex--------------------------------------
-------------------------------------------------------------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldIDInPage = 'cbo_AMLRimClass')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'996','Teller','cbo_AMLRimClass',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldIDInPage = 'cbo_AMLOccupation')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'1163','Teller','cbo_AMLOccupation',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldIDInPage = 'cbo_AMLProductsServices')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'160','Teller','cbo_AMLProductsServices',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldIDInPage = 'cbo_AMLPEP')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'186','Teller','cbo_AMLPEP',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldIDInPage = 'cbo_AMLEconomicSector')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'996','Teller','cbo_AMLEconomicSector',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go
--------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldIDInPage = 'cbo_AMLEconomicSector')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'996','Teller','cbo_AMLEconomicSector',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldIDInPage = 'cbo_AMLRimClass')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'996','Teller','cbo_AMLRimClass',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldIDInPage = 'cbo_AMLBusinessLine')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'1163','Teller','cbo_AMLBusinessLine',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldIDInPage = 'cbo_AMLProductsServices')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'160','Teller','cbo_AMLProductsServices',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 565 And FieldIDInPage = 'cbo_AMLPEP')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (565,'186','Teller','cbo_AMLPEP',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go
-----------------------------------------Open Account--------------------------------------------------------
If Not Exists(Select * From RulesTranField_ex Where TranID = 534 And FieldIDInPage = 'cbo_AMLEconomicSector')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (534,'','Teller','cbo_AMLEconomicSector',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 534 And FieldIDInPage = 'cbo_AMLNationality')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (534,'','Teller','cbo_AMLNationality',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 534 And FieldIDInPage = 'cbo_AMLProductsServices')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (534,'','Teller','cbo_AMLProductsServices',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 534 And FieldIDInPage = 'cbo_AMLOccupation')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (534,'','Teller','cbo_AMLOccupation',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go
-----------
If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldIDInPage = 'lbl_AMLRimClass')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'','Teller','lbl_AMLRimClass',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldIDInPage = 'lbl_AMLOccupation')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'','Teller','lbl_AMLOccupation',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldIDInPage = 'lbl_AMLProductsServices')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'','Teller','lbl_AMLProductsServices',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go

If Not Exists(Select * From RulesTranField_ex Where TranID = 547 And FieldIDInPage = 'lbl_AMLPEP')
Begin
 Insert Into RulesTranField_ex(TranID,FieldID,Module,FieldIDInPage,FirstPage,LastPage,ControlPage,Optional,IsReadOnly,TranFieldDescr,DefaultValue,FieldType,LastChanged,Updator,IsVisible,IsReadOnlyConditionId,IsVisibleConditionId,IsOptionalConditionId,fExpressionID)
 Values (547,'','Teller','lbl_AMLPEP',-1,-1,-1,1,1,NULL,NULL,NULL,'Apr  30 2020 12:00AM',N'ITSOFT\mostafa.helmy',0,NULL,NULL,NULL,NULL)
End
go
-------------------------------------------------------------------
-----------------------RulesParam----------------------------------
-------------------------------------------------------------------

	
If Not Exists(Select * From RulesParam Where  ParamName='CheckAML')
Begin
	DECLARE @ParamID INT
	SELECT @ParamID = MAX(ParamID) +1 FROM RulesParam
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@ParamID,'CheckAML','apply checking �AML� or not',NULL,0,0,0,'','Static','','May 03 2020  3:22PM',N'ITSOFT\mostafa.helmy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)


	
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenPersonalRim' And FieldName = 'DrawerType' And Param = 'CheckAML')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('OpenPersonalRim','DrawerType','CheckAML','1',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenNonPersonalRim' And FieldName = 'DrawerType' And Param = 'CheckAML')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('OpenNonPersonalRim','DrawerType','CheckAML','1',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'EditPersonalRim' And FieldName = 'DrawerType' And Param = 'CheckAML')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('EditPersonalRim','DrawerType','CheckAML','0',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'EditNonPersonalRim' And FieldName = 'DrawerType' And Param = 'CheckAML')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('EditNonPersonalRim','DrawerType','CheckAML','0',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'DPAccountOpening' And FieldName = 'DrawerType' And Param = 'CheckAML')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('DPAccountOpening','DrawerType','CheckAML','0',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End
End
go

If Not Exists(Select * From RulesParam Where  ParamName='RecheckAMLStatus')
Begin
	DECLARE @ParamID INT
	SELECT @ParamID = MAX(ParamID) +1 FROM RulesParam
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@ParamID,'RecheckAMLStatus','define the status can be resending for AML checking',NULL,0,0,0,'','Static','','May 03 2020  3:22PM',N'ITSOFT\mostafa.helmy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)


	
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenPersonalRim' And FieldName = 'AMLStatus' And Param = 'RecheckAMLStatus')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('OpenPersonalRim','AMLStatus','RecheckAMLStatus','Rejected,Pending',N'ITSOFT\mostafa.helmy','nvarchar','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenNonPersonalRim' And FieldName = 'AMLStatus' And Param = 'RecheckAMLStatus')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('OpenNonPersonalRim','AMLStatus','RecheckAMLStatus','Rejected,Pending',N'ITSOFT\mostafa.helmy','nvarchar','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenNonPersonalRim' And FieldName = 'AMLStatus' And Param = 'RecheckAMLStatus')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('OpenNonPersonalRim','AMLStatus','RecheckAMLStatus','Rejected,Pending',N'ITSOFT\mostafa.helmy','nvarchar','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'DPAccountOpening' And FieldName = 'AMLStatus' And Param = 'RecheckAMLStatus')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('DPAccountOpening','AMLStatus','RecheckAMLStatus','Rejected,Pending',N'ITSOFT\mostafa.helmy','nvarchar','May 03 2020 9:22AM',NULL)
	End
End
go
If Not Exists(Select * From RulesParam Where  ParamName='AMLOnBoardingWebService')
Begin
	DECLARE @ParamID INT
	SELECT @ParamID = MAX(ParamID) +1 FROM RulesParam
	 Insert Into RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Created,Updator,EffectiveDate,ExpirationDate,RowStatus)
	 Values (@ParamID,'AMLOnBoardingWebService','apply checking �AML� for on boarding web service',NULL,0,0,0,'','Static','','May 03 2020  3:22PM',N'ITSOFT\mostafa.helmy','Jan  1 1901 12:00AM','Dec 31 9998 12:00AM',1)


	
	If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenPersonalRim' And FieldName = 'NewWebService' And Param = 'AMLOnBoardingWebService')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('OpenPersonalRim','NewWebService','AMLOnBoardingWebService','0',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenNonPersonalRim' And FieldName = 'NewWebService' And Param = 'AMLOnBoardingWebService')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('OpenNonPersonalRim','NewWebService','AMLOnBoardingWebService','0',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'EditPersonalRim' And FieldName = 'NewWebService' And Param = 'AMLOnBoardingWebService')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('EditPersonalRim','NewWebService','AMLOnBoardingWebService','0',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'EditNonPersonalRim' And FieldName = 'NewWebService' And Param = 'AMLOnBoardingWebService')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('EditNonPersonalRim','NewWebService','AMLOnBoardingWebService','0',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End

	If Not Exists(Select * From RulesTranFldParam Where TranName = 'DPAccountOpening' And FieldName = 'NewWebService' And Param = 'AMLOnBoardingWebService')
	Begin
	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
	 Values ('DPAccountOpening','NewWebService','AMLOnBoardingWebService','0',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
	End
End

--If Not Exists(Select * From RulesTranFldParam Where TranName = 'OpenNonPersonalRim' And FieldName = 'PassportNoRequired' And Param = 'PassportNo')
--	Begin
--	 Insert Into RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,LastChanged,Description)
--	 Values ('OpenNonPersonalRim','PassportNoRequired','PassportNo','17',N'ITSOFT\mostafa.helmy','bit','May 03 2020 9:22AM',NULL)
--	End
--go
-------------------------------------------------------------------
----------------------------SQLstrings-----------------------------
-------------------------------------------------------------------

If Not Exists(Select * From SQLstrings Where AccessID = 1100063)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,LastChanged,Purpose,RowStatus,EffectiveDate,ExpirationDate,Created,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100063,'SELECTAML_INFO_OnBoard','p',1,'Globalfs','dbo.SelectAML_Info_OnBoard',0,NULL,NULL,'ITSOFT\mostafa.helmy','ITSOFT\mostafa.helmy','Mar 12 2019 11:53AM','selects all AML_Info table',1,'Jan  1 1900 12:00AM','Dec 31 9998 12:00AM','Mar 11 2012 12:00AM',' ','',0,0,1,NULL,NULL,0,0,0,0,1)
End
go
------------------------------------------------------------------
PRINT 'End Script for CR# GFSY00793'
GO
--Devolper	:	Ahmed Osman
--Date		:	[12/02/2020]		
--Reason	:	Issue# GFSX13947 - BDL - UAT - Rim No in edit rim journal
--==============================================================================

If Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1418)
Begin
 UPDATE RulesTranField SET FieldAlias = NULL WHERE TranID = 564 AND FieldID = 1418
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 564 And FieldID = 1442)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (564,1442,1,0,0,NULL,'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'RimNumber',0,-1,NULL,NULL,NULL)

End
GO
--Devolper	:	Mostafa  Helmy
--Date		:	[26/02/2020]		
--Reason	:	Issue# GFSX13932 - BDL - UAT - Layout Issue
--==============================================================================
-------------------------------------------------------------------
----------------------------RulesDescriptorLocal-------------------
-------------------------------------------------------------------
If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1104897 And LCID = 1036)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,LastChanged,Updator)
 Values (1104897,1036,N'Vous avez remplac� le message de subvention','ITSOFT\mostafa.helmy','Jan 01 2019 11:20AM',N'ITSOFT\mostafa.helmy')
End
go


--Devolper		:	Ahmed Osman
--Date			:	[10/02/2020]		
--Reason		:	Issue#GFSX13935 - BDL - UAT - Sold Remittance reversal issue
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1797)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1797,'TLR_REMITTANCE_CANNOT_REVERSE','Correction Not Allowed.','There are Remittance was paid , Cannot Reverse Transaction',6,'ErrDesc.hlp',1,N'ITSoft\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1797)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1797,N'���� ���� ��������� � �� ���� ��� ������',N'���� ���� ��������� � �� ���� ��� ������','','ITSOFT\ahmed.orashed')
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'SoldRemittancesAganistAccount' And Error_Name = 'TLR_REMITTANCE_CANNOT_REVERSE')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('SoldRemittancesAganistAccount','TLR_REMITTANCE_CANNOT_REVERSE','ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From SQLstrings Where AccessID = 1100035)
Begin
 Insert Into SQLstrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
 Values (1,1100035,'TLR_Check_Remittance_Status','p',1,'Globalfs','dbo.CheckRemittanceStatus',0,NULL,NULL,'ITSOFT\ahmed.orashed','ITSOFT\ahmed.orashed','Check Sold Remittance Status',1,' ','',0,0,1,NULL,NULL,0,0,0,0,0)
End
GO
--Devolper	:	Ahmed Osman
--Date		:	[12/02/2020]		
--Reason	:	Issue# GFSX13945 - BDL - UAT - Layout Issue
--==============================================================================

-----------------------
-- RulesDescriptor ----
-----------------------
If Not Exists(Select * From RulesDescriptor Where DescriptorID = 1105527)
Begin
 Insert Into RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 Values (1,1105527,'TLR_DEPOSITOR_DETAL_DEBIT',0,'Labels','Depositor Details',N'itsoft\ahmed.orashed',1,N'itsoft\ahmed.orashed')
End
GO

-----------------------
-- RulesTranDescriptors 
-----------------------

If Not Exists(Select * From RulesTranDescriptors Where TranID = 495 And DSC_Name = 'TLR_DEPOSITOR_DETAL_DEBIT')
Begin
 Insert Into RulesTranDescriptors(TranID,DSC_Name,Updator,Creator,RowStatus)
 Values (495,'TLR_DEPOSITOR_DETAL_DEBIT',N'itsoft\ahmed.orashed',N'itsoft\ahmed.orashed',1)
End
GO

--==================================================================================================================================================================
--Devolper	:	Ahmed Osman
--Date		:	[11/05/2020]		
--Reason	:	Enh GFSY00793 - BARWA - ACM000000018134 AML Integration
--=====================================================================

PRINT 'Start. Script for CR# GFSY00793 DML Script'
GO

--------------------------------------------
-- RulesDescriptor & RulesDescriptorLocal --
--------------------------------------------
IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105607)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105607,'TLR_NOMAPPINGFORNATINAML',0,'Labels','There are no mapping for the selected nationality in AML System \r Are you sure you want to continue?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105607 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105607,1025,N'�� ���� ����� ������� ������� �� ���� ������ ��� ������� \r �� ��� ����� �� ��� ���� �������ɿ','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105608)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105608,'TLR_AML_DWON',0,'Labels','AML web service is down, Are you sure you want to continue?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105608 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105608,1025,N'���� AML ��� ����� ����� � �� ���� �������� �������ɿ','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105609)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105609,'TLR_NOMAPPINGFORCUSTTYPE',0,'Labels','There are no mapping for the selected rim class in AML System \r Are you sure you want to continue?','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105609 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105609,1025,N'�� ���� ����� ���� rim ������� �� ���� AML \ r �� ��� ����� �� ��� ���� �������ɿ','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

IF NOT EXISTS(SELECT * FROM RulesDescriptor WHERE DescriptorID = 1105616)
BEGIN
 INSERT INTO RulesDescriptor(AppID,DescriptorID,Name,forVB,TypeName,Descriptor,Creator,RowStatus,Updator)
 VALUES (1,1105616,'AML_STATUS_PENDING',0,'Labels','AML Status is Pending','ITSOFT\ahmed.orashed',1,N'ITSOFT\ahmed.orashed')
END 
GO

If Not Exists(Select * From RulesDescriptorLocal Where DescriptorID = 1105616 And LCID = 1025)
Begin
 Insert Into RulesDescriptorLocal(DescriptorID,LCID,LocalDescription,Creator,Updator)
 Values (1105616,1025,N'���� ������ ��� ������� �����','ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed')
End
GO

---------------------------
-- RulesErrorDescription --
---------------------------
If Not Exists(Select * From RulesErrorDescription Where DescriptionNumber = 1798)
Begin
 Insert Into RulesErrorDescription(DescriptionNumber,Name,DetailText,DisplayText,ErrorNumber,Help,AppID,Developer,RowStatus)
 Values (1798,'AMLDOWN_ABORT_ACTION','Cannot continue the transaction � AML Web Service is down.','Cannot continue the transaction � AML Web Service is down.',4,'ErrDesc.hlp',1,'ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesLocalErrorDescription Where LanguageLCID = 1025 And DescriptionNumber = 1798)
Begin
 Insert Into RulesLocalErrorDescription(LanguageLCID,DescriptionNumber,DetailText,DisplayText,Help,Developer)
 Values (1025,1798,N'�� ���� ������ �������� � ���� AML Web Service �����',N'�� ���� ������ �������� � ���� AML Web Service �����','','ITSOFT\ahmed.orashed')
End
GO

--------------------------------
-- RulesTranErrorDescriptions --
--------------------------------
If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenPersonalRim' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('OpenPersonalRim','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'OpenNonPersonalRim' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('OpenNonPersonalRim','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditPersonalRim' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('EditPersonalRim','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'EditNonPersonalRim' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('EditNonPersonalRim','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

If Not Exists(Select * From RulesTranErrorDescriptions Where TranName = 'DPAccountOpening' And Error_Name = 'AMLDOWN_ABORT_ACTION')
Begin
 Insert Into RulesTranErrorDescriptions(TranName,Error_Name,Updator,RowStatus)
 Values ('DPAccountOpening','AMLDOWN_ABORT_ACTION','ITSOFT\ahmed.orashed',1)
End
GO

----------------------------------
-- RulesParam & RulesParamValue --
----------------------------------
DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'AMLDown')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'AMLDown','Which Action will GFS Will take in case AML Service is down',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
		
		IF NOT EXISTS(Select * From RulesParamValue Where ParamID = @paramID And ParamValue = 'SKIP')
			BEGIN
				INSERT INTO RulesParamValue(ParamID,ParamValue,UPdator)
				VALUES (@paramID,N'SKIP',N'ITSOFT\ahmed.orashed')
			END
		IF NOT EXISTS(SELECT * FROM RulesParamValue WHERE ParamID = @paramID And ParamValue = 'ABORT')
			BEGIN 
				INSERT INTO RulesParamValue(ParamID,ParamValue,UPdator)
				VALUES (@paramID,N'ABORT',N'ITSOFT\ahmed.orashed')
			END
END
GO

DECLARE @paramID int 
SELECT @paramID = MAX(ParamID) +1 FROM RulesParam
IF NOT EXISTS(SELECT * FROM RulesParam WHERE ParamName = 'AMLExpressionName')
	BEGIN
		INSERT INTO RulesParam(ParamID,ParamName,Description,Parm_DSC,isGeneral,isCustomized,isDBCheck,DB_procName,ValuesTypes,DB_procValuesName,Updator,RowStatus)
		VALUES (@paramID,'AMLExpressionName','Used for generating reference number for AML Web Service',NULL,0,1,0,'','Static','',N'ITSOFT\ahmed.orashed',1)
END
GO

-----------------------
-- RulesTranFldParam --
-----------------------
IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'OpenPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('OpenPersonalRim','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'OpenPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('OpenPersonalRim','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'OpenNonPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('OpenNonPersonalRim','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'OpenNonPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('OpenNonPersonalRim','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'EditPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('EditPersonalRim','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'EditPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('EditPersonalRim','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'EditNonPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('EditNonPersonalRim','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'EditNonPersonalRim' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('EditNonPersonalRim','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'DPAccountOpening' AND FieldName = 'AMLSerivce' AND Param = 'AMLDown')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('DPAccountOpening','AMLSerivce','AMLDown','ABORT',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

IF NOT EXISTS(SELECT * FROM RulesTranFldParam WHERE TranName = 'DPAccountOpening' AND FieldName = 'AMLSerivce' AND Param = 'AMLExpressionName')
BEGIN
 INSERT INTO RulesTranFldParam(TranName,FieldName,Param,Value,Updator,DataType,Description)
 VALUES ('DPAccountOpening','AMLSerivce','AMLExpressionName','AMLReferenceNumber',N'ITSOFT\ahmed.orashed','nvarchar',NULL)
END
GO

------------------------
-- ExternalWebService --
------------------------
IF NOT EXISTS(SELECT * FROM ExternalWebService WHERE WebServiceName = 'IMCPService')
BEGIN
 INSERT INTO ExternalWebService(WebServiceName,Description,WebServiceIP,MachineName,URL,RowStatus,Updator,Creator,UserName,Password,ApplyWSE,WebServiceMapName,Servicetype)
 VALUES ('IMCPService','MCP Service','10.10.13.201','10.10.13.201','http://g12devsql:9090/IMCPService.svc',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','GFSUSER','GFSPassWord',0,'IMCPService',N'WCF')
End
GO

-------------------------------------------------------------
-- ExternalWebServiceTran & ExternalWebServiceTranParamLst --
-------------------------------------------------------------

-- OpenPersonalRim

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 547)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (547,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','OpenPersonalRim_FCCMRequest.xsd',NULL)
	END
END
GO

-- OpenNonPersonalRim

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 565)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (565,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','OpenNonPersonalRim_FCCMRequest.xsd',NULL)
	END
END
GO

-- EditPersonalRim

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 564)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (564,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','EditPersonalRim_FCCMRequest.xsd',NULL)
	END
END
GO

-- EditNonPersonalRim

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 578)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (578,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','EditNonPersonalRim_FCCMRequest.xsd',NULL)
	END
END
GO

-- DPAccountOpening

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequest' AND TranID = 534)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (534,'IMCPService','FCCMCaseStatusRequest',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequest')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','DPAccountOpening_FCCMRequest.xsd',NULL)
	END
END
GO

DECLARE @ID int
SELECT @ID = MAX(ID) +1 from ExternalWebServiceTran
IF NOT EXISTS(SELECT * FROM ExternalWebServiceTran WHERE WebServiceName = 'IMCPService' AND MethodsMapName = 'FCCMCaseStatusRequestInquiry' AND TranID = -1)
BEGIN
	INSERT INTO ExternalWebServiceTran(TranID,WebServiceName,Methods,Updator,Creator,ID,MethodsMapName)
	VALUES (-1,'IMCPService','FCCMCaseStatusRequestInquiry',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed',@ID,'FCCMCaseStatusRequestInquiry')

	IF NOT EXISTS(SELECT * FROM ExternalWebServiceTranParamLst WHERE ParamListID = @ID AND ParamName = 'Request')
	BEGIN
	 INSERT INTO ExternalWebServiceTranParamLst(WSTranMethodID,ParamListName,ParamListID,ParamName,ParamType,ParamOrder,ParamValue,IsInput,Updator,Creator,XSD,XSLT)
	 VALUES (@ID,NULL,@ID,'Request','xmlstring',1,'',1,N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','FCCMInquiry.xsd',NULL)
	END
END
GO

---------------------------------------------
-- RulesExpression & RulesExpressionDetail --
---------------------------------------------
DECLARE @ExpressionId int
SELECT @ExpressionId = MAX(ExpressionId) +1 from RulesExpression
IF NOT EXISTS(SELECT * FROM RulesExpression WHERE ExpressionName = 'AMLReferenceNumber')
BEGIN
 INSERT INTO RulesExpression(ExpressionId,ExpressionName,SerialNumberLength,PaddingCharacter,IsLeftPadded,ExpressionCategroyId)
 VALUES (@ExpressionId,'AMLReferenceNumber',7,'0',1,1)

 DECLARE @Id int
 SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 1)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,1,1,'"CIF_"',1,4,'0',1)
 END

 SELECT @Id = MAX(Id) +1 from RulesExpressionDetail
 IF NOT EXISTS(SELECT * FROM RulesExpressionDetail Where Id = @Id AND ExpressionId = @ExpressionId AND Seq = 2)
 BEGIN
  INSERT INTO RulesExpressionDetail(Id,ExpressionId,Seq,IsPrevious,Expression,CastAsFormatedString,StringLength,PaddingCharacter,IsLeftPadded)
  VALUES (@Id,@ExpressionId,2,1,'BusinessDate_YYYYMMDD',1,8,'0',1)
 END
END
GO

----------------
-- SQLStrings --
----------------
If Not Exists(Select * From SQLStrings Where AccessID = 1100059)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100059,'Select_AML_NationalityMapping','p',1,'Globalfs','dbo.Select_AML_NationalityMapping',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select data from AML_NationalityMapping Table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100060)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100060,'Select_AML_CustomerTypeMapping','p',1,'Globalfs','dbo.Select_AML_CustomerTypeMapping',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Select data from AML_CustomerTypeMapping Table',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100062)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100062,'AMLInfo_InsertAndUpdate','p',0,'Globalfs','dbo.AMLInfo_InsertAndUpdate',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Insert and Update table AML_Info',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

If Not Exists(Select * From SQLStrings Where AccessID = 1100065)
Begin
Insert Into SQLStrings(AppID,AccessID,AccessName,CommandType,GetsRows,DataSource,AccessString,OutputsXML,OBSOLETE_XSLFile,OBSOLETE_XDRFile,Developer,Updator,Purpose,RowStatus,RScmdType,RScmd,ReadOnly,CacheMinutes,UseNewCacheRules,CacheGroup,CacheByUser,SkipTest,ExpirationDays,is_development_only,CommandTimeout,IsAuditable)
Values (1,1100065,'GetAMLPendingRequests','p',1,'Globalfs','dbo.GetAMLPendingRequests',0,'','',N'ITSOFT\ahmed.orashed',N'ITSOFT\ahmed.orashed','Get AML Pending Requests',1,' ','',0,-1,1,NULL,NULL,0,0,0,0,1)
End
GO

--------------------
-- RulesTranField --
--------------------
If Not Exists(Select * From RulesTranField Where TranID = 534 And FieldID = 1297)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (534,1297,1,0,0,NULL,'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'AMLReferenceID',1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 534 And FieldID = 1154)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (534,1154,1,0,0,NULL,'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'AMLRiskRating',1,-1,NULL,NULL,NULL)
End
GO

If Not Exists(Select * From RulesTranField Where TranID = 534 And FieldID = 1359)
Begin
 Insert Into RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,Developer,isDupable,MaxArray,Notes,Updator,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH,IsPrimaryKey,PrimaryKeyAlias,PrimaryKeySeq)
 Values (534,1359,1,0,0,NULL,'ITSOFT\ahmed.orashed',1,NULL,'',N'ITSOFT\ahmed.orashed',1,0,NULL,0,0,'AMLStatus',1,-1,NULL,NULL,NULL)
End
GO

PRINT 'End... Script for CR# GFSY00793 DML Script'
GO
--==================================================================================================================================================================
--Programmer : Mostafa Sayed
--Date       : [24/06/2020]
--Reason     : Issue#GFSX14106 - Date and time fields not journaled .....

IF NOT EXISTS(SELECT * FROM RulesTranField WHERE TranID = 380 AND FieldID = 226)
BEGIN
	 INSERT INTO RulesTranField(TranID,FieldID,Optional,ToHost,FromHost,DSC_Pattern,isDupable,MaxArray,Notes,RowStatus,IsReadOnly,jTarget,BindValue,isReadOnlyImaging,FieldAlias,ShowInDWH,IndexInDWH)
	 VALUES (380,226,1,0,0,NULL,1,NULL,'',1,0,NULL,0,0,NULL,0,-1)
END
GO